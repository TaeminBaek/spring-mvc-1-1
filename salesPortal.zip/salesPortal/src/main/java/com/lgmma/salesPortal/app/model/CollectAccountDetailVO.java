package com.lgmma.salesPortal.app.model;

public class CollectAccountDetailVO extends PagingParamVO {
	
	private String prmgubun;
	private String prmexecutionOption;
	private String prmkkber;
	private String prmsdate;
	private String prmedate;
	private String prmdistrChan;
	private String partnNumbAg;
	private String partnNameAg;
	private String accountName;
	private String cApprEmpId;
	private String cApprEmpNm;
	
	private String gubun;
	private String kkber;
	private String kkbtx; 
	private String trndt; 
	private String tridt;   
	private String vtweg; 
	private String vtext; 	
	private String kunnr;
	private String name1;
	private String text1;
	private String waers;
	private String tranamt;
	private String belnr;
	private String banktrnno;
	private String ename;
	
	public String getPrmgubun() {
		return prmgubun;
	}
	
	public void setPrmgubun(String prmgubun) {
		this.prmgubun = prmgubun;
	}
	
	public String getPrmexecutionOption() {
		return prmexecutionOption;
	}
	
	public void setPrmexecutionOption(String prmexecutionOption) {
		this.prmexecutionOption = prmexecutionOption;
	}
	
	public String getPrmkkber() {
		return prmkkber;
	}
	
	public void setPrmkkber(String prmkkber) {
		this.prmkkber = prmkkber;
	}
	
	public String getPrmsdate() {
		return prmsdate;
	}
	
	public void setPrmsdate(String prmsdate) {
		this.prmsdate = prmsdate;
	}
	
	public String getPrmedate() {
		return prmedate;
	}
	
	public void setPrmedate(String prmedate) {
		this.prmedate = prmedate;
	}
	
	public String getPrmdistrChan() {
		return prmdistrChan;
	}
	
	public void setPrmdistrChan(String prmdistrChan) {
		this.prmdistrChan = prmdistrChan;
	}
		
	public String getPartnNumbAg() {
		return partnNumbAg;
	}

	public void setPartnNumbAg(String partnNumbAg) {
		this.partnNumbAg = partnNumbAg;
	}

	public String getPartnNameAg() {
		return partnNameAg;
	}
	
	public void setPartnNameAg(String partnNameAg) {
		this.partnNameAg = partnNameAg;
	}
			
	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getcApprEmpId() {
		return cApprEmpId;
	}
	
	public void setcApprEmpId(String cApprEmpId) {
		this.cApprEmpId = cApprEmpId;
	}
	
	public String getcApprEmpNm() {
		return cApprEmpNm;
	}
	
	public void setcApprEmpNm(String cApprEmpNm) {
		this.cApprEmpNm = cApprEmpNm;
	}
	
	public String getGubun() {
		return gubun;
	}
	
	public void setGubun(String gubun) {
		this.gubun = gubun;
	}
	
	public String getKkber() {
		return kkber;
	}
	
	public void setKkber(String kkber) {
		this.kkber = kkber;
	}
	
	public String getKkbtx() {
		return kkbtx;
	}
	
	public void setKkbtx(String kkbtx) {
		this.kkbtx = kkbtx;
	}
	
	public String getTrndt() {
		return trndt;
	}
	
	public void setTrndt(String trndt) {
		this.trndt = trndt;
	}
	
	public String getTridt() {
		return tridt;
	}
	
	public void setTridt(String tridt) {
		this.tridt = tridt;
	}
	
	public String getVtweg() {
		return vtweg;
	}
	
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	
	public String getVtext() {
		return vtext;
	}
	
	public void setVtext(String vtext) {
		this.vtext = vtext;
	}
	
	public String getKunnr() {
		return kunnr;
	}
	
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	
	public String getName1() {
		return name1;
	}
	
	public void setName1(String name1) {
		this.name1 = name1;
	}
	
	public String getText1() {
		return text1;
	}
	
	public void setText1(String text1) {
		this.text1 = text1;
	}
	
	public String getWaers() {
		return waers;
	}
	
	public void setWaers(String waers) {
		this.waers = waers;
	}
	
	public String getTranamt() {
		return tranamt;
	}
	
	public void setTranamt(String tranamt) {
		this.tranamt = tranamt;
	}
	
	public String getBelnr() {
		return belnr;
	}
	
	public void setBelnr(String belnr) {
		this.belnr = belnr;
	}
	
	public String getBanktrnno() {
		return banktrnno;
	}
	
	public void setBanktrnno(String banktrnno) {
		this.banktrnno = banktrnno;
	}
	
	public String getEname() {
		return ename;
	}
	
	public void setEname(String ename) {
		this.ename = ename;
	}
	
}
