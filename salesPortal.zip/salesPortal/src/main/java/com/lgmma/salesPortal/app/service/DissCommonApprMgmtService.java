package com.lgmma.salesPortal.app.service;

import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissStepVO;

import java.util.List;
import java.util.Map;

public interface DissCommonApprMgmtService {

	int getDissMyApprListCount(ApprLineVO param);

	List<ApprLineVO> getDissMyApprList(ApprLineVO param);
	
	ApprLineVO getDissMyApprDetail(ApprLineVO param);
	
	int getDissMyApprReqListCount(ApprVO param);

	List<ApprVO> getDissMyApprReqList(ApprVO param);

	String saveDissCommonAppr(ApprVO apprVO, String apprStat, boolean smsFlag);

	List<ApprLineVO> getOrderedApprLineList(ApprVO apprVO);

	void deleteDissAppr(ApprVO apprVO);

	void approvalDissCommonAppr(ApprLineVO apprLineVO);

	void checkDissCommonAppr(ApprVO apprVO);

	ApprVO getApprInfoAll(ApprVO apprVO);

	boolean checkListApplActYn(ApprVO apprVO, String apprEmpId);

	List<ApprLineVO> getApprovalNextLineList(ApprVO apprVO);

	void sendDissApprSms(ApprVO param);

	void sendDissGateReviewMessage(String apprId, String taskId);

	void sendDissGateReviewCancelMessage(String apprId, String taskId);

	String getDissStepIngCheckMessage(DissApprCommonParamVO dissApprCommonParamVO);

	String checkDissDegreeCreateAuth(DissApprCommonParamVO dissApprCommonParamVO);

	String checkDissTaskEditAuth(DissApprCommonParamVO dissApprCommonParamVO);

	List<DissStepVO> getCompStepList(DissApprCommonParamVO dissApprCommonParamVO, String stepCd);

	List<DissStepVO> getCompStepList(DissApprCommonParamVO dissApprCommonParamVO, String stepCd, int degreeNo);
	
	void cancelGPortalApproval(String apprId, String apprEmpId, String apprMessage);

	void deleteGPortalApproval(String apprId, String apprEmpId);

	void addApprLine(ApprVO param);
	
	DissStepVO loadDissApprDoc(DissStepVO param);
}
