package com.lgmma.salesPortal.app.service;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissOneTeamMinutesVO;
import com.lgmma.salesPortal.app.model.DissOneTeamVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.model.DissTaskSpecInVO;
import com.lgmma.salesPortal.app.model.EmployVO;

public interface DissOneTeamService {
	
	void saveDissOneTeam(DissOneTeamVO param);
	
	void createDissOneTeam(DissOneTeamVO param);
	
	int getDissOneTeamListCount(DissOneTeamVO param);
	
	List<DissOneTeamVO> getDissOneTeamList(DissOneTeamVO param);
	
	List<DissOneTeamVO> getDissOneTeamLeaderTeamList();
	
	void updateDissOneTeam(DissOneTeamVO param);
	
	void deleteDissOneTeamAll(DissStepVO param);

	DissOneTeamVO getDissOneTeamInfo(DissOneTeamVO param);
	
	DissOneTeamVO getDissOneTeamMasterInfo(DissOneTeamVO param);
	
	DissOneTeamVO getDissOneTeamHisInfo(DissOneTeamVO param);
	
	void createAfterDeleteAllKpiHis(DissOneTeamVO param);
	
	void createAfterDeleteAllMemberHis(DissOneTeamVO param);
	
	void createAfterDeleteAllTaskSpecinHis(DissOneTeamVO param);
	
	void saveDissOneTeamApprovalAction(DissApprCommonParamVO param);
	
	List<DissTaskSpecInVO> getSpecInListWithTotalSaleGoal(DissTaskSpecInVO param);
	
	int getSpecInListWithTotalSaleGoalCnt(DissTaskSpecInVO param);
	
	String updateOneTeamDtl(DissOneTeamVO param);
	
	int getDissOneTeamMinutesListCount(DissOneTeamMinutesVO param);
	
	List<DissOneTeamMinutesVO> getDissOneTeamMinutesList(DissOneTeamMinutesVO param);
	
	void saveDissOneTeamMinutes(DissOneTeamMinutesVO param);
	
	DissOneTeamMinutesVO getDissOneTeamMinutesDetail(DissOneTeamMinutesVO param);
	
	void saveDissOneTeamMinutesApprovalAction(DissApprCommonParamVO param);
	
	void saveDissOneTeamCompleteAppr(DissOneTeamVO param);
	
	void deleteDissOneTeamAppr(DissApprCommonParamVO param);

	void deleteDissOneTeamMinutesAppr(DissApprCommonParamVO param);
	
	List<DissStepVO> getDissOneTeamStepList(DissStepVO param);
	
	List<EmployVO> loadEmployList(Map<String, String> param);
	
	String getApprFormContOneTeam(DissOneTeamVO param, String templeteFormContent);
	
	String getApprFormContOneTeamMinutes(DissOneTeamMinutesVO param, String templeteFormContent);
}
