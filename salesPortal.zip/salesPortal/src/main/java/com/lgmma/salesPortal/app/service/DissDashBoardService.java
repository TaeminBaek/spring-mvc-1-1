package com.lgmma.salesPortal.app.service;

import java.util.Map;

import com.lgmma.salesPortal.app.model.DissDashBoardVO;


public interface DissDashBoardService {
	
	public Map<String,DissDashBoardVO> getDissDashBoardMyIngCnt(DissDashBoardVO param);
	
	public DissDashBoardVO getDissDashBoardMyIngSpecInCnt(DissDashBoardVO param);
	
	public DissDashBoardVO getDissDashBoardMyIngImpDevCnt(DissDashBoardVO param);
	
	public DissDashBoardVO getDissDashBoardMyIngOneTeamCnt(DissDashBoardVO param);

	public Map<String,DissDashBoardVO> getDissDashBoardStepSpecInCnt(DissDashBoardVO param);
	
	public Map<String,DissDashBoardVO> getDissDashBoardStepImpDevCnt(DissDashBoardVO param);
}
