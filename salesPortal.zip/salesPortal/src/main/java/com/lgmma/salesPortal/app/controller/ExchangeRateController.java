package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.ExchangeRateVO;
import com.lgmma.salesPortal.app.service.ExchangeMgmtService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.Months;
import com.lgmma.salesPortal.common.util.DateUtil;
 
@Controller
@RequestMapping("/exchange")
public class ExchangeRateController {

	private static Logger logger = LoggerFactory.getLogger(ExchangeRateController.class); 

	@Autowired
	private ExchangeMgmtService exchangeMgmtService;

	@RequestMapping(value = "/exchangeMgmt")
	public ModelAndView exchangeMgmt(ModelAndView mav ) throws Exception {
		//logger.debug("######################HSHTEST["+DateUtil.getToday().substring(4, 6)+"]");
		mav.setViewName("exchange/exchangeMgmt");
		mav.addObject("monthsList"	, new ArrayList< Months >(Arrays.asList(Months.values())));
		mav.addObject("currentMm", DateUtil.getToday().substring(4, 6));
		mav.addObject("defaultYyyy"	, DateUtil.getCurrentYear());
		mav.addObject("defaultYm", DateUtil.getCurrentYear().concat(".").concat(DateUtil.getToday().substring(4, 6)));
		return mav;
	}

	@RequestMapping(value = "/getExchangeRateList.json")
	public Map getExchangeRateList(@RequestBody(required = true) @Valid ExchangeRateVO param) throws Exception {
		param.setSearchYyyyMm(param.getSearchYyyyMm().replaceAll("[.]", ""));
		return JsonResponse.asSuccess("storeData", exchangeMgmtService.getExchangeRateListAddAvg(param));
	}

	@RequestMapping(value = "/getExchangeRateMonAvgList.json")
	public Map getExchangeRateMonAvgList(@RequestBody(required = true) @Valid ExchangeRateVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", exchangeMgmtService.getExchangeRateMonAvgListAddAvg(param));
	}

}
