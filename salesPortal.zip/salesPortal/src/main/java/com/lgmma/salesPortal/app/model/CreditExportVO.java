package com.lgmma.salesPortal.app.model;

public class CreditExportVO extends PagingParamVO {
	private String kunnr;
	private String name1;
	private String landx;
	private String clasCode;
	private String zterm;
	private String ztermT;
	private String kvgr2;
	private String kvgrt;
	private String addAmnt;
	private String addcy;
	private String guarAmnt;
	private String guarcy;
	private String exprDate;
	private String klimkC;
	private String sauft;
	private String skfor;
	private String ssobl;
	private String remain;
	private String waers;

	//조회조건
	private String kkber;
	
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getLandx() {
		return landx;
	}
	public void setLandx(String landx) {
		this.landx = landx;
	}
	public String getClasCode() {
		return clasCode;
	}
	public void setClasCode(String clasCode) {
		this.clasCode = clasCode;
	}
	public String getZterm() {
		return zterm;
	}
	public void setZterm(String zterm) {
		this.zterm = zterm;
	}
	public String getZtermT() {
		return ztermT;
	}
	public void setZtermT(String ztermT) {
		this.ztermT = ztermT;
	}
	public String getKvgr2() {
		return kvgr2;
	}
	public void setKvgr2(String kvgr2) {
		this.kvgr2 = kvgr2;
	}
	public String getKvgrt() {
		return kvgrt;
	}
	public void setKvgrt(String kvgrt) {
		this.kvgrt = kvgrt;
	}
	public String getAddAmnt() {
		return addAmnt;
	}
	public void setAddAmnt(String addAmnt) {
		this.addAmnt = addAmnt;
	}
	public String getAddcy() {
		return addcy;
	}
	public void setAddcy(String addcy) {
		this.addcy = addcy;
	}
	public String getGuarAmnt() {
		return guarAmnt;
	}
	public void setGuarAmnt(String guarAmnt) {
		this.guarAmnt = guarAmnt;
	}
	public String getGuarcy() {
		return guarcy;
	}
	public void setGuarcy(String guarcy) {
		this.guarcy = guarcy;
	}
	public String getExprDate() {
		return exprDate;
	}
	public void setExprDate(String exprDate) {
		this.exprDate = exprDate;
	}
	public String getKlimkC() {
		return klimkC;
	}
	public void setKlimkC(String klimkC) {
		this.klimkC = klimkC;
	}
	public String getSauft() {
		return sauft;
	}
	public void setSauft(String sauft) {
		this.sauft = sauft;
	}
	public String getSkfor() {
		return skfor;
	}
	public void setSkfor(String skfor) {
		this.skfor = skfor;
	}
	public String getSsobl() {
		return ssobl;
	}
	public void setSsobl(String ssobl) {
		this.ssobl = ssobl;
	}
	public String getRemain() {
		return remain;
	}
	public void setRemain(String remain) {
		this.remain = remain;
	}
	public String getWaers() {
		return waers;
	}
	public void setWaers(String waers) {
		this.waers = waers;
	}
	public String getKkber() {
		return kkber;
	}
	public void setKkber(String kkber) {
		this.kkber = kkber;
	}

}
