package com.lgmma.salesPortal.app.model;

public class DissOneTeamMinutesVO extends PagingParamVO {
	//Table Column
	private String taskId;
	private String apprId;
	private String minutesAttendee;
	private String minutesYmd;
	private String minutesLoc;
	
	//OneTeam Column
	private String leaderEmpId;
	
	//Display Column
	private String taskName;
	private String apprTitle;
	private String leaderEmpNm;
	private String regiName;
	private String minutesYmdFmt;
	private String regiDateFmt;
	private String teamName;
	
	//품의
	private String saveType;
	private String apprStat;
	private ApprVO apprVO;

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getApprId() {
		return apprId;
	}

	public void setApprId(String apprId) {
		this.apprId = apprId;
	}

	public String getMinutesAttendee() {
		return minutesAttendee;
	}

	public void setMinutesAttendee(String minutesAttendee) {
		this.minutesAttendee = minutesAttendee;
	}

	public String getMinutesYmd() {
		return minutesYmd;
	}

	public void setMinutesYmd(String minutesYmd) {
		this.minutesYmd = minutesYmd;
	}

	public String getMinutesLoc() {
		return minutesLoc;
	}

	public void setMinutesLoc(String minutesLoc) {
		this.minutesLoc = minutesLoc;
	}

	public String getLeaderEmpId() {
		return leaderEmpId;
	}

	public void setLeaderEmpId(String leaderEmpId) {
		this.leaderEmpId = leaderEmpId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getApprTitle() {
		return apprTitle;
	}

	public void setApprTitle(String apprTitle) {
		this.apprTitle = apprTitle;
	}

	public String getLeaderEmpNm() {
		return leaderEmpNm;
	}

	public void setLeaderEmpNm(String leaderEmpNm) {
		this.leaderEmpNm = leaderEmpNm;
	}

	public String getRegiName() {
		return regiName;
	}

	public void setRegiName(String regiName) {
		this.regiName = regiName;
	}

	public String getMinutesYmdFmt() {
		return minutesYmdFmt;
	}

	public void setMinutesYmdFmt(String minutesYmdFmt) {
		this.minutesYmdFmt = minutesYmdFmt;
	}

	public String getRegiDateFmt() {
		return regiDateFmt;
	}

	public void setRegiDateFmt(String regiDateFmt) {
		this.regiDateFmt = regiDateFmt;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getSaveType() {
		return saveType;
	}

	public void setSaveType(String saveType) {
		this.saveType = saveType;
	}

	public String getApprStat() {
		return apprStat;
	}

	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}

	public ApprVO getApprVO() {
		return apprVO;
	}

	public void setApprVO(ApprVO apprVO) {
		this.apprVO = apprVO;
	}
}
