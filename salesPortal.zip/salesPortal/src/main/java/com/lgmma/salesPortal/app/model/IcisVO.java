package com.lgmma.salesPortal.app.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * @author nahong01
 * @description ICIS 조회용 VO
 */
public class IcisVO extends PagingParamVO {
	/* 컬럼 */
	private String peMonth;
	private String peVersion;
	private String saleEtcCd;
	private Integer qty;
	private Integer amt;
	private Float prc;

	/* view컬럼 */
	private String saleEtcNm;
	private String peMonthFr;
	private String peMonthTo;

	public String getPeMonth() {
		return peMonth;
	}

	public void setPeMonth(String peMonth) {
		this.peMonth = peMonth;
	}

	public String getPeVersion() {
		return peVersion;
	}

	public void setPeVersion(String peVersion) {
		this.peVersion = peVersion;
	}

	public String getSaleEtcCd() {
		return saleEtcCd;
	}

	public void setSaleEtcCd(String saleEtcCd) {
		this.saleEtcCd = saleEtcCd;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public Integer getAmt() {
		return amt;
	}

	public void setAmt(Integer amt) {
		this.amt = amt;
	}

	public Float getPrc() {
		return prc;
	}

	public void setPrc(Float prc) {
		this.prc = prc;
	}

	public String getSaleEtcNm() {
		return saleEtcNm;
	}

	public void setSaleEtcNm(String saleEtcNm) {
		this.saleEtcNm = saleEtcNm;
	}

	public String getPeMonthFr() {
		return peMonthFr;
	}

	public void setPeMonthFr(String peMonthFr) {
		this.peMonthFr = peMonthFr;
	}

	public String getPeMonthTo() {
		return peMonthTo;
	}

	public void setPeMonthTo(String peMonthTo) {
		this.peMonthTo = peMonthTo;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
	}
}
