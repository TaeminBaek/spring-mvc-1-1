package com.lgmma.salesPortal.security.controller;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.config.WebSecurityConfig;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;
import com.lgmma.salesPortal.security.authentication.CustomSavedRequestAwareAuthenticationSuccessHandler;
import com.lgmma.salesPortal.security.authentication.CustomUserDetailsService;
import com.lgmma.salesPortal.security.authentication.MenuLoaderService;
import com.lgmma.salesPortal.security.authentication.UserInfo;
import com.nets.sso.agent.authcheck.AuthCheck;
import com.nets.sso.common.AgentExceptionCode;
import com.nets.sso.common.Utility;
import com.nets.sso.common.enums.AuthStatus;

//org.springframework.security.web.access.ExceptionTranslationFilter
/**
 * @author jklee
 *
 */
@Controller
public class SecurityController {	
	
	private static Logger logger = LoggerFactory.getLogger(SecurityController.class); 

	@Autowired
	CustomUserDetailsService detailsService;

    @Autowired
    private MenuLoaderService menuLoaderService;
    
    @Autowired
    private MessageSourceAccessor messageSourceAccessor;

    public static String getBeforeUri(HttpServletRequest request)
	{
		String beforeRequestUri = (String)request.getAttribute(WebSecurityConfig.REQUSET_ATTRIBUTE_REQUEST_URI_BEFORE_SECURITY);
		return beforeRequestUri == null ? request.getRequestURI() : beforeRequestUri;
	}
	
	private boolean wasViewRequest(HttpServletRequest request) 
	{
		String beforeUri = getBeforeUri(request);
		String contextPath = request.getContextPath();
		boolean wasViewRequest = false;
		if("/".equals(beforeUri) || contextPath.equals(beforeUri) || beforeUri.indexOf("/view/") > -1 || beforeUri.indexOf("/user/") > -1)
		{
			wasViewRequest = true;
		}
		return wasViewRequest;
	}
	
	/**
	 * view 요청 페이지 없을 때. web.xml 에서 이 경로를 정의한다.
	 * @return
	 */
	@RequestMapping(value = "/view/error/404")
	public String viewError404()
	{
		return "/error/404";
	}
	/**
	 * 로그인 페이지 Back Door 
	 * view 요청과 ajax 요청을 구분하여 처리함.
	 * @return
	 */
	@RequestMapping(value = WebSecurityConfig.ADMIN_LOGIN_PAGE)
	public String loginRequired(HttpServletRequest request) {
		return "adminLoginPage";
	}
	
	/**
	 * 로그아웃 성공시. 
	 * CustomLogoutHandler, SecurityContextLogoutHandler, SimpleUrlLogoutSuccessHandler 거쳐서 여기 온다.
	 */
	@RequestMapping(value = WebSecurityConfig.LOGOUT_SUCCESS_URL)
	public String logoutSuccess(HttpServletRequest request)
	{
		//로그아웃 로그는 여기서 남긴다.
		//logger.debugln(request.getAttribute(WebSecurityConfig.USERNAME_PARAM_NAME) + " 로그아웃 성공...");
		return "redirect:/";
	}

	/**
	 * 요청 접근 권한 없을 때. CustomAccessDeniedHandler 거쳐서 여기 온다.
	 * view 요청과 ajax 요청을 구분하여 처리함.
	 */
/*
	@RequestMapping(value = WebSecurityConfig.ACCESS_DENIED_ERROR_URL)
	public Object error403(HttpServletRequest request)
	{
		String beforeUri = getBeforeUri(request);
		
		//로그는 여기서 남긴다.
		if(Util.getUserInfo() != null) {
			//logger.debugln(Util.getUserInfo().getUsername() + " 허용되지 않은 접근 시도 : " + beforeUri);			
		}
		
		if(wasViewRequest(request))
		{
			return "/error/403";
		}
		else
		{
			MappingJackson2JsonView jsonView = new MappingJackson2JsonView();
			ModelAndView mav = new ModelAndView(jsonView);
			mav.addAllObjects(JsonResponse.asFailure(new ServiceException("ERROR_ACCESS_DENIED")));
			return mav;	
		}
	}
*/	
	@RequestMapping(value = "/fullScreen")
    public ModelAndView fullScreen(@RequestParam(defaultValue="/home") String targetUrl) throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.addObject("targetUrl", targetUrl);
		mav.setViewName("fullScreen");
		return mav;
    }
	
    /**
     * G-Portal 에서 SSO
     * @param req
     * @param res
     * @return
     * @throws Exception
     **/ 
    @RequestMapping(value = "/SSOLogin")
    public void SSOLogin(HttpServletRequest req, HttpServletResponse res, @RequestParam(defaultValue="") String targetUrl) throws Exception {

        try{
        	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        	if (authentication != null){    
        		new SecurityContextLogoutHandler().logout(req, res, authentication);
        	}
            
            //SSO 용 변수
        	String logoffUrl = "";		// 로그오프 URL
        	String returnUrl = "";		// 되돌아 올 URL
        	String empNo = "";		// 로그온 된 사용자 사번
        	String loginOnUserInfo = "";		// 로그온 된 사용자 추가정보 
        	String errorMsg = "";		// 에러 메시지
        	
//        	인증객체생성 및 인증확인
        	AuthCheck auth = new AuthCheck(req, res);
        	//인증확인
        	AuthStatus status = auth.checkLogon();

        	try{
	        	//로그오프 URL
	    		logoffUrl = auth.getSsoProvider().getLogoffUrl(req, auth.getSsoSite().getSiteDNS()) + "?" +
				auth.getSsoProvider().getRequestSSOSiteParam() + "=" + auth.getSsoSite().getSiteDNS() + "&" +
				auth.getSsoProvider().getReturnUrlTagName() + "=" + Utility.uRLEncode(auth.getThisUrl(), "UTF-8");
			} catch (Exception e){
				logger.debug("@exception : "+e.toString());
			}
        	
//        	인증상태별 처리
        	if(status == AuthStatus.SSOFirstAccess) {
        		logger.debug("SSOFirstAccess");
        		//최초 접속
        		auth.trySSO();
        		
        	} else if(status == AuthStatus.SSOSuccess) {
        		logger.debug("SSOSuccess");
        		//인증성공
        		//returnUrl = req.getParameter(auth.getSsoProvider().getReturnUrlTagName());//?
        		if (Utility.isNullOrEmpty(returnUrl) == false) {
        		    res.sendRedirect(returnUrl);
        		}
        		//하기 인증정보를 이용하여, 내부인증을 만들어 사용하세요.
        		//로그인 사번
        		empNo = auth.getUserInfo("SAWN_IDXX");

        		//인증정보 모두 보기(화면에서 보고 싶을 때 주석을 제거 하세요)
        		if (auth.getUserInfoCollection() != null && auth.getUserInfoCollection().size() > 0){
        			for (Enumeration e = auth.getUserInfoCollection().keys(); e.hasMoreElements();){
        				if (Utility.isNullOrEmpty(loginOnUserInfo) == false)
        					loginOnUserInfo += "<br />";
        					String key = (String)e.nextElement();
        				loginOnUserInfo += key + ":" + auth.getUserInfoCollection().get(key);
        			}
        		}

        		//선입자를 끊고, 내가 인증 성공했을 경우, 선입자의 정보를 보여준다.
        		if (Utility.isNullOrEmpty(auth.getDuplicationIP()) == false){
        			String dupInfo = "(끊어진 사용자정보)\\nIP:" + auth.getDuplicationIP() + "\\nTime:" + auth.getDuplicationTime();
        			errorMsg = dupInfo;
        			throw new AuthenticationServiceException(errorMsg);
        		}
        		
        		/***************************기존 login 처리 로직 시작************************************************/
                if(empNo.equals("")){
                    String msg = "유효한 사원번호가 아닙니다.";
        			throw new AuthenticationServiceException(msg);
                } else {
                    // 사번의 암호해제
                    logger.debug("originEmpNo : " + empNo);
            		UserInfo user = (UserInfo) detailsService.loadEmpUser(empNo);
                    user.getAllowedMenuMap().put("01", menuLoaderService.getUserMenu(user, "UserMenu.xml"));
            		//SSO 를 통한 로그인에서는 CustomAuthenticationToken 에 등록할  password 가 없다.
            		authentication = new CustomAuthenticationToken(user.getUsername(), "password", user.getAuthorities(), user);
            		AuthenticationSuccessHandler authenticationSuccessHandler = null;
            		if(!targetUrl.equals("")) {
                		authenticationSuccessHandler = new CustomSavedRequestAwareAuthenticationSuccessHandler(targetUrl);
            		} else {
                		authenticationSuccessHandler = new CustomSavedRequestAwareAuthenticationSuccessHandler(WebSecurityConfig.LOGIN_SUCCESS_URL);
            		}
            		authenticationSuccessHandler.onAuthenticationSuccess(req, res, authentication);
                  	SecurityContext securityContext = SecurityContextHolder.getContext();
                  	securityContext.setAuthentication(authentication); 
                  	req.getSession().setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, securityContext);
                }
                /***************************기존 login 처리 로직 끝***********************************************/
        		
        		//사용자정보 조회 샘플
        		//String somethingUserInfo = auth.getUserInfo("조회할이름");	//조회할 이름은 프로젝트 시, 정해지면 전달해드립니다.
        	} else if(status == AuthStatus.SSOFail){
        		logger.debug("SSOFail");
        		//인증실패
        		if (auth.getErrCode() != AgentExceptionCode.NoException){
        			//errorMsg = auth.getErrCode().toString();
        			errorMsg = "SSO 로그인 세션 만료 - G포탈 재로그인 필요합니다.";
        			throw new AuthenticationServiceException(errorMsg);
        		}
        		if (auth.getErrCode() == AgentExceptionCode.SessionDuplicationCheckedFirstPriority ||
        				auth.getErrCode() == AgentExceptionCode.SessionDuplicationCheckedLastPriority){
        			errorMsg = "중복로그인 정보 IP:" + auth.getDuplicationIP() + " TIME:" + auth.getDuplicationTime();
        			throw new AuthenticationServiceException(errorMsg);
        		}
        		//로그오프를 해야하는 상황(MMA에는 기능 없음 LJE)
        		if (	auth.getErrCode() == AgentExceptionCode.SessionDuplicationCheckedLastPriority ||
        				auth.getErrCode() == AgentExceptionCode.TokenIdleTimeout ||
        				auth.getErrCode() == AgentExceptionCode.TokenExpired ||
        				auth.getErrCode() == AgentExceptionCode.NoExistUserIDSessionValue){
        			logger.debug("logoff : "+logoffUrl);
        		}
        		
        		//리턴 URL 설정
        		//returnUrl = req.getParameter(auth.getSsoProvider().getReturnUrlTagName());//???
        		if (Utility.isNullOrEmpty(returnUrl) == false) {
        		    returnUrl = Utility.uRLEncode(returnUrl, "UTF-8");
        		} else {
        		    returnUrl = Utility.uRLEncode(auth.getThisUrl(), "UTF-8");
        		}
        		//SSO 실패 시 정책에 따라 자체 로그인 페이지로 이동 시키거나, SSO 인증을 위한 포탈 로그인 페이지로 이동
        		//res.sendRedirect("http://ssodev.lgmma.com:8080/lgmma-portal/login.do");//개발
        		//res.sendRedirect("http://sso.lgmma.com:8080/lgmma-portal/login.do");//운영
        	} else if(status == AuthStatus.SSOUnAvailable){
        		logger.debug("SSOUnAvailable");
        		//SSO 장애 시 정책에 따라 자체 로그인 페이지로 이동 시키거나, SSO 인증을 위한 포탈 로그인 페이지로 이동
        		//response.sendRedirect("이동할 URL");
        		errorMsg = "현재 통합인증 서비스가 불가합니다.";
    			throw new AuthenticationServiceException(errorMsg);
        	} else if(status == AuthStatus.SSOAccessDenied){
        		logger.debug("SSOAccessDenied");
        		errorMsg = "인증은 되었지만, 현재 사이트에 접근 거부상태입니다";
    			throw new AuthenticationServiceException(errorMsg);
        	}
        }catch(Exception e){
			throw new AuthenticationServiceException(e.getMessage());
        }		
    }

	//개발자용 로그인
    @RequestMapping(value = "/adminLogin")
    public void adminLogin(HttpServletRequest req, HttpServletResponse res, @RequestParam String userId, @RequestParam String adminPwd, @RequestParam(defaultValue = "false") boolean isPartner) throws Exception {
        try{
    		logger.debug("userId : " + userId);
        	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        	if (authentication != null){    
        		new SecurityContextLogoutHandler().logout(req, res, authentication);
        	}
        	//로그인 타입별 처리
        	if(!adminPwd.equals("mmaadmin")) {
    			throw new BadCredentialsException(messageSourceAccessor.getMessage("fail.common.login"));
        	} else if(isPartner) {
        		//사용자 정보 생성
        		UserInfo user = (UserInfo) detailsService.loadPartnerUser(userId);
                //사용자 메뉴
                user.getAllowedMenuMap().put("01", menuLoaderService.getUserMenu(user, "UserMenu.xml"));
           		authentication = new CustomAuthenticationToken(user.getUsername(), "password", user.getAuthorities(), user);
           		AuthenticationSuccessHandler authenticationSuccessHandler = new CustomSavedRequestAwareAuthenticationSuccessHandler(WebSecurityConfig.PARTNER_LOGIN_SUCCESS_URL);
           		authenticationSuccessHandler.onAuthenticationSuccess(req, res, authentication);
           		SecurityContext securityContext = SecurityContextHolder.getContext();
               	securityContext.setAuthentication(authentication); 
               	req.getSession().setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, securityContext);
        	} else {
        		//사용자 정보 생성
        		UserInfo user = (UserInfo) detailsService.loadEmpUser(userId);
                //사용자 메뉴
                user.getAllowedMenuMap().put("01", menuLoaderService.getUserMenu(user, "UserMenu.xml"));
           		authentication = new CustomAuthenticationToken(user.getUsername(), "password", user.getAuthorities(), user);
           		AuthenticationSuccessHandler authenticationSuccessHandler = new CustomSavedRequestAwareAuthenticationSuccessHandler(WebSecurityConfig.EMP_LOGIN_SUCCESS_URL);
           		authenticationSuccessHandler.onAuthenticationSuccess(req, res, authentication);
           		SecurityContext securityContext = SecurityContextHolder.getContext();
               	securityContext.setAuthentication(authentication); 
               	req.getSession().setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, securityContext);
        	}
        }catch(Exception e){
			throw new AuthenticationServiceException(e.getMessage());
        }		
    }

	/**
	 * 파트너사용 로그인 페이지
	 * 로그인 실패때 ExceptionHandler 를 겸하고 있다. 
	 * @return
	 */
	@RequestMapping(value = WebSecurityConfig.PARTNER_LOGIN_PAGE)
	@ExceptionHandler(UsernameNotFoundException.class)
	public ModelAndView loginError(Exception e) {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("partnerLoginPage");
        mav.addObject("error", "true");
        mav.addObject("msg", e.getMessage());
        return mav;
	}

	//파트너용 로그인
    @RequestMapping(value = "/partnerLogin")
    public void partnerLogin(HttpServletRequest req, HttpServletResponse res, @RequestParam(required=true) String partnerId, @RequestParam(required=true) String partnerPwd) {
        try{
    		logger.debug("partnerId : " + partnerId);
        	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        	if (authentication != null){    
        		new SecurityContextLogoutHandler().logout(req, res, authentication);
        	}
        	//파트너용사용자 정보 생성
        	UserInfo user = (UserInfo) detailsService.loadPartnerUser(partnerId, partnerPwd);
        	//파트너사용자 메뉴
        	user.getAllowedMenuMap().put("01", menuLoaderService.getUserMenu(user, "PartnerMenu.xml"));

        	authentication = new CustomAuthenticationToken(user.getUsername(), partnerPwd, user.getAuthorities(), user);
        	AuthenticationSuccessHandler authenticationSuccessHandler = new CustomSavedRequestAwareAuthenticationSuccessHandler(WebSecurityConfig.PARTNER_LOGIN_SUCCESS_URL);
        	authenticationSuccessHandler.onAuthenticationSuccess(req, res, authentication);

        	SecurityContext securityContext = SecurityContextHolder.getContext();
        	securityContext.setAuthentication(authentication); 
        	req.getSession().setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, securityContext);
        }catch(Exception e){
			throw new UsernameNotFoundException(e.getMessage());
        }
    }
}
