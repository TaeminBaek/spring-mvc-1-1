package com.lgmma.salesPortal.app.model;

public class DissCustTestOrderVO extends PagingParamVO {

	//TB_D_CUSTTEST_ORDER
	private String stepId;				// 과제스텝ID
	private String orderId;             // 견본주문번호
	private String custTestResult;      // 고객테스트결과
	private String custTestFCd;         // 실패사유
	private String custTestFDtlCd;      // 실패사유상세
	
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCustTestResult() {
		return custTestResult;
	}
	public void setCustTestResult(String custTestResult) {
		this.custTestResult = custTestResult;
	}
	public String getCustTestFCd() {
		return custTestFCd;
	}
	public void setCustTestFCd(String custTestFCd) {
		this.custTestFCd = custTestFCd;
	}
	public String getCustTestFDtlCd() {
		return custTestFDtlCd;
	}
	public void setCustTestFDtlCd(String custTestFDtlCd) {
		this.custTestFDtlCd = custTestFDtlCd;
	}

}
