package com.lgmma.salesPortal.app.service.impl;

import com.lgmma.salesPortal.app.dao.CommonApprDao;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.model.SmsVO;
import com.lgmma.salesPortal.app.service.CommonApprMgmtService;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.GPortalRestService;
import com.lgmma.salesPortal.app.service.GportalPostProcess;
import com.lgmma.salesPortal.app.service.SmsService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.ApplState;
import com.lgmma.salesPortal.common.props.ApprConfType;
import com.lgmma.salesPortal.common.props.ApprLineType;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.ReqApplChkType;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Transactional
@Service
public class CommonApprMgmtServiceImpl implements CommonApprMgmtService {
	private static Logger logger = LoggerFactory.getLogger(CommonApprMgmtServiceImpl.class);
	@Autowired
	private CommonApprDao commonApprDao;

	@Autowired
	private GPortalRestService gPortalRestService;

	@Autowired
	private CommonFileService commonFileService;

	@Autowired
	private SmsService smsService;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Autowired
	private CommonService commonService;

	@Override
	public int getApprListCount(ApprVO param) {
		return commonApprDao.getApprListCount(param);
	}

	@Override
	public List<ApprVO> getApprList(ApprVO param) {
		return commonApprDao.getApprList(param);
	}

	@Override
	public ApprVO getAppr(ApprVO param) {
		return commonApprDao.getAppr(param);
	}

	/**
	 * 현재 미사용
	 */
	@Override
	public void saveAppr(ApprVO param) {
		commonApprDao.updateAppr(param);
	}

	/**
	 * 품의서 생성
	 */
	@Override
	public void createAppr(ApprVO param) {
		commonApprDao.createAppr(param);
		commonApprDao.deleteApprLineAll(param);
		createApprLine(param);
		// 저장후 필수 결재라인 체크
		checkReqApplChkType(param);
		ApprVO apprVO = new ApprVO();
		apprVO = getAppr(param);
		apprVO.setKeyId(param.getKeyId());
		// 최초 입력시에 업무테이블에 apprId 저장 호출
		GportalPostProcess gportalPostProcess = (GportalPostProcess) Util.getBean(ApprType.getApprType(param.getApprType()).getGpPostServiceBeanName());
		gportalPostProcess.saveApprId(apprVO);
		// 저장 후 요청처리
		if (ApprState.APPR_PROCEEDING.equals(ApprState.getApprState(param.getApprStat()))) {
			gPortalRestService.requestApproval(param);
		}
		// 저장시 바로 작성 완료인경우처리 완료후 후처리 바로호출
		if (ApprState.APPR_WRITE_COMPLETE.equals(ApprState.getApprState(param.getApprStat()))) {
			apprWriteCompleteProcess(apprVO);
		}
	}

	/**
	 * 품의서 저장
	 */
	@Override
	public void updateAppr(ApprVO param) {
		commonApprDao.updateAppr(param);
		commonApprDao.deleteApprLineAll(param);
		createApprLine(param);
		// 저장후 필수 결재라인 체크
		checkReqApplChkType(param);
		// 저장 후 요청처리
		if (ApprState.APPR_PROCEEDING.equals(ApprState.getApprState(param.getApprStat()))) {
			gPortalRestService.requestApproval(param);
		}
		ApprVO apprVO;
		apprVO = getAppr(param);
		// 저장시 바로 작성 완료인경우처리 완료 후 후처리 바로호출
		if (ApprState.APPR_WRITE_COMPLETE.equals(ApprState.getApprState(param.getApprStat()))) {
			apprWriteCompleteProcess(apprVO);
		}
	}

	/**
	 * 작성완료시 바로 후처리 작업
	 *
	 * @param apprVO
	 */
	private void apprWriteCompleteProcess(ApprVO apprVO) {
		GportalPostProcess gportalPostProcess = (GportalPostProcess) Util.getBean(ApprType.getApprType(apprVO.getApprType()).getGpPostServiceBeanName());
		gportalPostProcess.completeProcess(apprVO);
		apprVO = getApprInfoAll(apprVO);
		// 통보자 작성완료 메세지 처리
		if (!apprVO.getApprLineIList().isEmpty()) {
			for (ApprLineVO apprLineVO : apprVO.getApprLineIList()) {
				sendApprSmsForWriteCompILine(apprVO, apprLineVO.getApprEmpHpno());
			}
		}
	}

	/**
	 * 품의서 결재라인 저장
	 *
	 * @param param
	 */
	private void createApprLine(ApprVO param) {
		if (param.getApprLineList() != null && !param.getApprLineList().isEmpty()) {
			int lineNo = 0;
			for (ApprLineVO apprLineVo : param.getApprLineList()) {
				apprLineVo.setApprId(param.getApprId());
				apprLineVo.setApprLineNo(lineNo);
				commonApprDao.createApprLine(apprLineVo);
				lineNo++;
			}
		}
	}

	/**
	 * 필수결재라인체크
	 *
	 * @param param
	 */
	private void checkReqApplChkType(ApprVO param) {

		logger.debug("######################reqApplChkType[" + StringUtil.nullConvert(param.getReqApplChkType()) + "]");
		// 필수결재라인체크 값이 넘어오면 그때 체크
		if ("".equals(StringUtil.nullConvert(param.getReqApplChkType()))) {
			return;
		}
		// 결재상신일때만 체크
		if (!ApprState.APPR_PROCEEDING.getCode().equals(param.getApprStat())) {
			return;
		}

		// 결재라인을 모두 가져다가 작업(이미 저장된 내역확인)
		ApprVO apprVO = getApprInfoAll(param);
		for (String chkType : apprVO.getReqApplChkType().split(",")) {
			// 넘어온 체크코드별로 모두 AND 조건으로 체크
			logger.debug("######################loop chkType[" + chkType + "]");
			ReqApplChkType reqApplChkType = ReqApplChkType.getReqApplChkType(chkType);
			if (reqApplChkType == null) {
				throw new ServiceException("", "유효하지 않은 결재라인 체크 방식입니다.");
			}

			// 필수 결재자 팀 체크
			if (reqApplChkType.getaTeams() != null) {
				for (String value : reqApplChkType.getaTeams()) {
					String team = value;
					if ("SELFTEAM".equals(value)) team = apprVO.getTeamCode();
					int chkCnt = 0;
					for (ApprLineVO apprLineVO : apprVO.getApprLineAList()) {
						if (team.equals(apprLineVO.getApplTeamCd())) {
							chkCnt++;
						}
					}
					if (chkCnt == 0) {
						String valueName = commonService.getTeamName(team);
						throw new ServiceException("", "결재자중 필수팀[" + valueName + "]이 지정되지 않았습니다.");
					}
				}
			}
			// 필수 결재자 직위 체크
			if (reqApplChkType.getaPositions() != null) {
				for (String value : reqApplChkType.getaPositions()) {
					int chkCnt = 0;
					for (ApprLineVO apprLineVO : apprVO.getApprLineAList()) {
						if (value.equals(apprLineVO.getApplPosiCd())) {
							chkCnt++;
						}
					}
					if (chkCnt == 0) {
						String valueName = commonService.getPositionName(value);
						throw new ServiceException("", "결재자중 필수직위[" + valueName + "]가 지정되지 않았습니다.");
					}
				}
			}
			// 필수 협의자 팀 체크
			if (reqApplChkType.getcTeams() != null) {
				for (String value : reqApplChkType.getcTeams()) {
					String team = value;
					if ("SELFTEAM".equals(value)) team = apprVO.getTeamCode();
					int chkCnt = 0;
					for (ApprLineVO apprLineVO : apprVO.getApprLineCList()) {
						if (team.equals(apprLineVO.getApplTeamCd())) {
							chkCnt++;
						}
					}
					if (chkCnt == 0) {
						String valueName = commonService.getTeamName(team);
						throw new ServiceException("", "협의자중 필수팀[" + valueName + "]이 지정되지 않았습니다.");
					}
				}
			}
			// 필수 협의자 직위 체크
			if (reqApplChkType.getcPositions() != null) {
				for (String value : reqApplChkType.getcPositions()) {
					int chkCnt = 0;
					for (ApprLineVO apprLineVO : apprVO.getApprLineCList()) {
						if (value.equals(apprLineVO.getApplPosiCd())) {
							chkCnt++;
						}
					}
					if (chkCnt == 0) {
						String valueName = commonService.getPositionName(value);
						throw new ServiceException("", "협의자중 필수직위[" + valueName + "]가 지정되지 않았습니다.");
					}
				}
			}
			// 필수 참조자 팀 체크
			if (reqApplChkType.getrTeams() != null) {
				for (String value : reqApplChkType.getrTeams()) {
					String team = value;
					if ("SELFTEAM".equals(value)) team = apprVO.getTeamCode();
					int chkCnt = 0;
					for (ApprLineVO apprLineVO : apprVO.getApprLineRList()) {
						if (team.equals(apprLineVO.getApplTeamCd())) {
							chkCnt++;
						}
					}
					if (chkCnt == 0) {
						String valueName = commonService.getTeamName(team);
						throw new ServiceException("", "참조자중 필수팀[" + valueName + "]이 지정되지 않았습니다.");
					}
				}
			}
			// 필수 참조자 직위 체크
			if (reqApplChkType.getrPositions() != null) {
				for (String value : reqApplChkType.getrPositions()) {
					int chkCnt = 0;
					for (ApprLineVO apprLineVO : apprVO.getApprLineRList()) {
						if (value.equals(apprLineVO.getApplPosiCd())) {
							chkCnt++;
						}
					}
					if (chkCnt == 0) {
						String valueName = commonService.getPositionName(value);
						throw new ServiceException("", "참조자중 필수직위[" + valueName + "]가 지정되지 않았습니다.");
					}
				}
			}
			// 필수 통보자 팀 체크
			if (reqApplChkType.getiTeams() != null) {
				for (String value : reqApplChkType.getiTeams()) {
					String team = value;
					if ("SELFTEAM".equals(value)) team = apprVO.getTeamCode();
					int chkCnt = 0;
					for (ApprLineVO apprLineVO : apprVO.getApprLineIList()) {
						if (team.equals(apprLineVO.getApplTeamCd())) {
							chkCnt++;
						}
					}
					if (chkCnt == 0) {
						String valueName = commonService.getTeamName(team);
						throw new ServiceException("", "통보자중 필수팀[" + valueName + "]이 지정되지 않았습니다.");
					}
				}
			}
			// 필수 통보자 직위 체크
			if (reqApplChkType.getiPositions() != null) {
				for (String value : reqApplChkType.getiPositions()) {
					int chkCnt = 0;
					for (ApprLineVO apprLineVO : apprVO.getApprLineIList()) {
						if (value.equals(apprLineVO.getApplPosiCd())) {
							chkCnt++;
						}
					}
					if (chkCnt == 0) {
						String valueName = commonService.getPositionName(value);
						throw new ServiceException("", "통보자중 필수직위[" + valueName + "]가 지정되지 않았습니다.");
					}
				}
			}
		}

	}

	/**
	 * 품의서 삭제
	 */
	@Override
	public void deleteAppr(ApprVO param) {
		// 삭제시 결재라인먼저 삭제
		commonApprDao.deleteApprLineAll(param);
		commonApprDao.deleteAppr(param);
		;

		// 업무테이블 품의서id 삭제
		GportalPostProcess gportalPostProcess = (GportalPostProcess) Util.getBean(ApprType.getApprType(param.getApprType()).getGpPostServiceBeanName());
		gportalPostProcess.deleteApprId(param);
	}

	/**
	 * 결재라인 리스트 구하기
	 */
	@Override
	public List<ApprLineVO> getApprLineList(ApprVO param) {
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(param.getApprId());
		return commonApprDao.getApprLineList(apprLineVO);
	}

	/**
	 * 결재 라인정보를 모두 맵핑한 품의서 정보
	 */
	@Override
	public ApprVO getApprContainLineList(ApprVO param) {
		List<ApprLineVO> apprLineList = getApprLineList(param);
		param.setApprLineList(apprLineList);
		param = getApprLineListContainType(param);
		return param;
	}

	/**
	 * 품의서에 결재 라인별로 리스트를 생성 맵핑
	 */
	@Override
	public ApprVO getApprLineListContainType(ApprVO apprVO) {
		List<ApprLineVO> apprLineListA = new ArrayList<ApprLineVO>();
		List<ApprLineVO> apprLineListC = new ArrayList<ApprLineVO>();
		List<ApprLineVO> apprLineListI = new ArrayList<ApprLineVO>();
		List<ApprLineVO> apprLineListR = new ArrayList<ApprLineVO>();
		for (ApprLineVO apprLineVO : apprVO.getApprLineList()) {
			if (apprLineVO.getApprLineType().equals(ApprLineType.APPR_APROBE.getCode())) {
				apprLineListA.add(apprLineVO);
			}
			if (apprLineVO.getApprLineType().equals(ApprLineType.APPR_CONFIRM.getCode())) {
				apprLineListC.add(apprLineVO);
			}
			if (apprLineVO.getApprLineType().equals(ApprLineType.APPR_REFERENCE.getCode())) {
				apprLineListR.add(apprLineVO);
			}
			if (apprLineVO.getApprLineType().equals(ApprLineType.APPR_INFORM.getCode())) {
				apprLineListI.add(apprLineVO);
			}
		}
		apprVO.setApprLineAList(apprLineListA);
		apprVO.setApprLineCList(apprLineListC);
		apprVO.setApprLineRList(apprLineListR);
		apprVO.setApprLineIList(apprLineListI);
		return apprVO;
	}

	/**
	 * 결재 결과 처리
	 */
	@Override
	public void apprApplyResultFromGPortal(ApprVO apprVO, ApprLineVO apprLineVO, String forceExcute) {
		// 결재선 처리 전에 유효한 정보인지 체크한다.(중복처리 방지)
		Map rtMap = checkApprApplyResult(apprVO, apprLineVO, forceExcute);
		if ((boolean) rtMap.get("success")) {
			// 결재선 먼저 저장 후에 품의서 상태 변경한다.
			commonApprDao.updateApprLineFromGPortal(apprLineVO);
			commonApprDao.updateApprFromGPortal(apprVO);
		} else {
			throw new ServiceException("APPLYERROR", "잘못된 요청입니다.");
		}
	}

	/**
	 * 중복처리 방지
	 *
	 * @param apprVO
	 * @param apprLineVO
	 * @return
	 */
	private Map checkApprApplyResult(ApprVO apprVO, ApprLineVO apprLineVO, String forceExcute) {
		if ("Y".equals(StringUtil.nullConvert(forceExcute))) {
			return JsonResponse.asSuccess();
		}
		String checkYN = commonApprDao.checkApprApplyResult(apprLineVO);
		if ("Y".equals(checkYN)) {
			return JsonResponse.asSuccess();
		} else {
			return JsonResponse.asFailure("잘못된 요청입니다.");
		}
	}

	/**
	 * 품의서 접근권한 체크
	 */
	@Override
	public boolean apprAccessAuthCheck(ApprVO apprVO) {
		String authYn = StringUtil.isNullToString(commonApprDao.apprAccessAuthCheck(apprVO));
		return "Y".equals(authYn);
	}

	/**
	 * 결재라인,파일정보 모두 담은 품의서 구하기
	 */
	@Override
	public ApprVO getApprInfoAll(ApprVO apprVO) {
		apprVO = getAppr(apprVO);                    // 품의서 기본
		apprVO = getApprContainLineList(apprVO);            // 품의서 결재라인
		// 결재라인 순서 정규화
		apprVO.setApprLineList(getOrderedApprLineList(apprVO));

		// 첨부파일이 존재하면 첨부파일 리스트 셋팅
		if (!StringUtil.nullConvert(apprVO.getFileId()).equals("")) {
			// 파일리스트 정보
			FileVO fileVO = new FileVO();
			fileVO.setFileId(apprVO.getFileId());
			apprVO.setFileList(commonFileService.getFileList(fileVO));
		}
		return apprVO;
	}

	/**
	 * 결재리스트 정규화
	 */
	@Override
	public List<ApprLineVO> getOrderedApprLineList(ApprVO apprVO) {
		List<ApprLineVO> rtnApprLineList = new ArrayList<ApprLineVO>();

		// 합의자가 없는 경우는 결재자 리스트로
		getOrderedApprLineACList(apprVO, rtnApprLineList);
		// 참조자 리스트
		for (ApprLineVO apprRLine : apprVO.getApprLineRList()) {
			rtnApprLineList.add(apprRLine);
		}
		// 통보자 리스트
		for (ApprLineVO apprILine : apprVO.getApprLineIList()) {
			rtnApprLineList.add(apprILine);
		}

		return rtnApprLineList;
	}

	/**
	 * 결재리스트 정규화 중 결재자,합의자 정규화
	 *
	 * @param apprVO
	 * @param rtnApprLineList
	 */
	static void getOrderedApprLineACList(ApprVO apprVO, List<ApprLineVO> rtnApprLineList) {
		if (apprVO.getConfLoca() == null || apprVO.getConfLoca().length() == 0) {
			for (ApprLineVO apprALine : apprVO.getApprLineAList()) {
				rtnApprLineList.add(apprALine);
			}
			// 합의자가 있는 경우는 합의 위치에 따라서
		} else {
			// 합의위치가 첫번째 결재자인경우 : 합의자먼저 결재자 이후
			if (apprVO.getConfLoca().equals(apprVO.getApprLineAList().get(0).getApprEmpId())) {
				for (ApprLineVO apprCLine : apprVO.getApprLineCList()) {
					rtnApprLineList.add(apprCLine);
				}
				for (ApprLineVO apprALine : apprVO.getApprLineAList()) {
					rtnApprLineList.add(apprALine);
				}
				// 합의위치가 첫번째 결재자가 아닌경우 : 결재자 셋팅후 합의위치결재자 앞에 합의자 전체 셋팅
			} else {
				for (ApprLineVO apprALine : apprVO.getApprLineAList()) {
					if (apprVO.getConfLoca().equals(apprALine.getApprEmpId())) {
						for (ApprLineVO apprCLine : apprVO.getApprLineCList()) {
							rtnApprLineList.add(apprCLine);
						}
						rtnApprLineList.add(apprALine);
					} else {
						rtnApprLineList.add(apprALine);
					}
				}
			}
		}
	}

	/**
	 * 결재상태별 안내 문자 보내기
	 */
	@Override
	public void sendApprSms(ApprVO param) {
		DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
		transactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//transaction start
		TransactionStatus tx = transactionManager.getTransaction(transactionDefinition);

		ApprVO apprVO = getApprInfoAll(param);
		// 결재자,협의자만 리스트로 뽑는다.
		List<ApprLineVO> apprACLineList = new ArrayList<ApprLineVO>();
		for (ApprLineVO apprLineVO : apprVO.getApprLineList()) {
			if (apprLineVO.getApprLineType().equals(ApprLineType.APPR_APROBE.getCode())
					|| apprLineVO.getApprLineType().equals(ApprLineType.APPR_CONFIRM.getCode())
			) {
				apprACLineList.add(apprLineVO);
			}
		}

		try {
			if (!ApprState.getApprState(apprVO.getApprStat()).getEndYn()) {                                                    // 1. 품의진행인경우(결재라인을 순서대로 루프돌면서 처리)
				int idx = 0;
				boolean continueable = true;
				while (idx < apprACLineList.size() && continueable) {
					if (!ApplState.getApplState(apprACLineList.get(idx).getApplStat()).isApplYn()) {                                // 1-1. 현재 결재해야할 결재대기자일때까지 루프
						if (ApprLineType.APPR_CONFIRM.getCode().equals(apprACLineList.get(idx).getApprLineType())) {                    // 1-1-1. 협의자이면
							if (ApprConfType.APPR_CONF_TYPE_PARALLEL.getCode().equals(apprVO.getGwdcCode())) {                            // 1-1-1-1. 병렬이면(최초 협의자 인경우만 전체 협의요청 안내
								if (idx == 0
										|| ApprLineType.APPR_APROBE.getCode().equals(apprACLineList.get(idx - 1).getApprLineType())                // 1-1-1-1-1. 최초협의자 이면(협의자 모두에 협의요청안내)
								) {
									for (ApprLineVO apprCLineVO : apprVO.getApprLineCList()) {
										sendApprSmsToConf(apprVO, apprCLineVO.getApprEmpHpno());
									}
								}
							} else {                                                                                                        // 1-1-1-2. 직렬이면 순서대로 각각 협의요청 안내
								sendApprSmsToConf(apprVO, apprACLineList.get(idx).getApprEmpHpno());
							}
						} else {                                                                                                        // 1-1-2. 결재자이면 순서대로 결재요청 안내
							sendApprSmsToAppl(apprVO, apprACLineList.get(idx).getApprEmpHpno());
						}

						if (idx == 0) {                                                                                            // 1-2 최초 상신인경우 전체 참조자 안내
							for (ApprLineVO apprRLineVO : apprVO.getApprLineRList()) {
								sendApprSmsToRef(apprVO, apprRLineVO.getApprEmpHpno());
							}
						}
						continueable = false;    //  루프종료
					}
					idx++;
				}
			} else {                                                                                                            // 2. 품의서결재가 종료된경우
				if (ApprState.getApprState(apprVO.getApprStat()).isRejectYn()) {                                                    // 2-1. 반려인경우(기안자 반려안내)
					sendApprSmsForReject(apprVO);                                    // 기안자 반려 안내
				} else {                                                                                                            // 2-2. 승인완료인경우(기안자,통보자 승인완료안내)
					sendApprSmsForComplete(apprVO, apprVO.getSawnHpxxNum1());        // 기안자 승인완료 안내
					for (ApprLineVO apprILineVO : apprVO.getApprLineIList()) {            // 통보자 승인완료 안내
						sendApprSmsForComplete(apprVO, apprILineVO.getApprEmpHpno());
					}
				}
			}
		} catch (Exception e) {
			transactionManager.commit(tx);
			e.printStackTrace();
		}
	}

	/**
	 * 결재자 승인요청 문자
	 */
	public void sendApprSmsToAppl(ApprVO apprVO, String hpno) {
		String messageStr = "SalesPortal 품의서 승인요청이 있습니다. 제목[" + apprVO.getApprTitle() + "]";
		SmsVO smsVo = new SmsVO();
		smsVo.setTrPhone(hpno);
		smsVo.setTrMsg(messageStr);
		smsVo.setTrEtc1(apprVO.getApprId());
		smsService.sendSms(smsVo);
	}

	/**
	 * 합의자 합의요청 문자
	 */
	public void sendApprSmsToConf(ApprVO apprVO, String hpno) {
		String messageStr = "SalesPortal 품의서 합의요청이 있습니다. 제목[" + apprVO.getApprTitle() + "]";
		SmsVO smsVo = new SmsVO();
		smsVo.setTrPhone(hpno);
		smsVo.setTrMsg(messageStr);
		smsVo.setTrEtc1(apprVO.getApprId());
		smsService.sendSms(smsVo);
	}

	/**
	 * 참조자 상신시작 안내 문자
	 */
	public void sendApprSmsToRef(ApprVO apprVO, String hpno) {
		String messageStr = "SalesPortal 참조된 품의서가 있습니다. 제목[" + apprVO.getApprTitle() + "]";
		SmsVO smsVo = new SmsVO();
		smsVo.setTrPhone(hpno);
		smsVo.setTrMsg(messageStr);
		smsVo.setTrEtc1(apprVO.getApprId());
		smsService.sendSms(smsVo);
	}

	/**
	 * 결재완료 안내 문자(기안자,통보자)
	 */
	public void sendApprSmsForComplete(ApprVO apprVO, String hpno) {
		String messageStr = "SalesPortal 품의서가 승인완료 되었습니다. 제목[" + apprVO.getApprTitle() + "]";
		SmsVO smsVo = new SmsVO();
		smsVo.setTrPhone(hpno);
		smsVo.setTrMsg(messageStr);
		smsVo.setTrEtc1(apprVO.getApprId());
		smsService.sendSms(smsVo);
	}

	/**
	 * 결재반려 안내 문자(기안자)
	 */
	public void sendApprSmsForReject(ApprVO apprVO) {
		String messageStr = "SalesPortal 품의서가 반려 되었습니다. 제목[" + apprVO.getApprTitle() + "]";
		SmsVO smsVo = new SmsVO();
		smsVo.setTrPhone(apprVO.getSawnHpxxNum1());
		smsVo.setTrMsg(messageStr);
		smsVo.setTrEtc1(apprVO.getApprId());
		smsService.sendSms(smsVo);
	}

	/**
	 * 작성완료 통보자 안내 문자
	 */
	public void sendApprSmsForWriteCompILine(ApprVO apprVO, String hpno) {
		String messageStr = "통보자로 지정된 SalesPortal 문서가 작성완료 되었습니다. 제목[" + apprVO.getApprTitle() + "]";
		SmsVO smsVo = new SmsVO();
		smsVo.setTrPhone(hpno);
		smsVo.setTrMsg(messageStr);
		smsVo.setTrEtc1(apprVO.getApprId());
		smsService.sendSms(smsVo);
	}

}
