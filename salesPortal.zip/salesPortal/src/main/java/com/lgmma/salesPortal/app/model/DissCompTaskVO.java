package com.lgmma.salesPortal.app.model;

public class DissCompTaskVO extends PagingParamVO {

	//TB_D_COMPTASK
	private String stepId;        	  // 과제스텝ID
	private String compResult;    	  // 최종결과(실패/성공)
	private String failReason;    	  // 실패사유
	private String failEtcReason; 	  // 실패기타사유
	private String failReasonDtl; 	  // 실패사유상세
	private String afterPlan;     	  // 향후계획
	private String compGrade;     	  // 확정그레이드
	//조회
	private String compResultName;    // 최종결과명
	private String failReasonName;    // 실패사유명
	private String failReasonDtlName; // 실패사유상세명
	
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getCompResult() {
		return compResult;
	}
	public void setCompResult(String compResult) {
		this.compResult = compResult;
	}
	public String getFailReason() {
		return failReason;
	}
	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}
	public String getFailEtcReason() {
		return failEtcReason;
	}
	public void setFailEtcReason(String failEtcReason) {
		this.failEtcReason = failEtcReason;
	}
	public String getFailReasonDtl() {
		return failReasonDtl;
	}
	public void setFailReasonDtl(String failReasonDtl) {
		this.failReasonDtl = failReasonDtl;
	}
	public String getAfterPlan() {
		return afterPlan;
	}
	public void setAfterPlan(String afterPlan) {
		this.afterPlan = afterPlan;
	}
	public String getCompGrade() {
		return compGrade;
	}
	public void setCompGrade(String compGrade) {
		this.compGrade = compGrade;
	}
	public String getCompResultName() {
		return compResultName;
	}
	public void setCompResultName(String compResultName) {
		this.compResultName = compResultName;
	}
	public String getFailReasonName() {
		return failReasonName;
	}
	public void setFailReasonName(String failReasonName) {
		this.failReasonName = failReasonName;
	}
	public String getFailReasonDtlName() {
		return failReasonDtlName;
	}
	public void setFailReasonDtlName(String failReasonDtlName) {
		this.failReasonDtlName = failReasonDtlName;
	}
}
