package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissCompGradeDao;
import com.lgmma.salesPortal.app.model.DissCompGradeVO;

@Repository
public class DissCompGradeDaoImpl implements DissCompGradeDao{
	
	private static final String MAPPER_NAMESPACE = "DISSCOMPGRADE_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public DissCompGradeVO getDissCompGradeInfo(DissCompGradeVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissCompGradeInfo", param);
	}
	
	@Override
	public void createDissCompGrade(DissCompGradeVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissCompGrade", param);
	}
	
	@Override
	public void updateDissCompGrade(DissCompGradeVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissCompGrade", param);
	}
	
	@Override
	public void deleteDissCompGradeAll(DissCompGradeVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissCompGradeAll", param);
	}	

}
