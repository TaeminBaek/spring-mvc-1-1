package com.lgmma.salesPortal.app.model;

public class ProgramVO extends PagingParamVO{

	private String prgId;
	private String prgNm;
	private String prgUrl;
	private String useYn;
	private String remark;

	public String getPrgId() {
		return prgId;
	}

	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	public String getPrgNm() {
		return prgNm;
	}

	public void setPrgNm(String prgNm) {
		this.prgNm = prgNm;
	}

	public String getPrgUrl() {
		return prgUrl;
	}

	public void setPrgUrl(String prgUrl) {
		this.prgUrl = prgUrl;
	}

	public String getUseYn() {
		return useYn;
	}

	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}


}
