package com.lgmma.salesPortal.app.model;

public class SalesPriceChageRateVO extends PagingParamVO {
	
	private String spmon;
	private String salesOrg;
	private String salesOrgText;
	private String distrChan;
	private String distrChanText;
	private String pkunag;
	private String partnNameAg;
	private String salesMan;
	private String matnr;
	private String stwae;
	private String basme;
	private String unitPrice1;
	private String unitPrice2;
	private String gapPct;
	private String avgUnitPrice;
	private String avgGapPct;

	public String getSpmon() {
		return spmon;
	}
	public void setSpmon(String spmon) {
		this.spmon = spmon;
	}
	public String getSalesOrg() {
		return salesOrg;
	}
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	public String getSalesOrgText() {
		return salesOrgText;
	}
	public void setSalesOrgText(String salesOrgText) {
		this.salesOrgText = salesOrgText;
	}
	public String getDistrChan() {
		return distrChan;
	}
	public void setDistrChan(String distrChan) {
		this.distrChan = distrChan;
	}
	public String getDistrChanText() {
		return distrChanText;
	}
	public void setDistrChanText(String distrChanText) {
		this.distrChanText = distrChanText;
	}
	public String getPkunag() {
		return pkunag;
	}
	public void setPkunag(String pkunag) {
		this.pkunag = pkunag;
	}
	public String getPartnNameAg() {
		return partnNameAg;
	}
	public void setPartnNameAg(String partnNameAg) {
		this.partnNameAg = partnNameAg;
	}
	public String getSalesMan() {
		return salesMan;
	}
	public void setSalesMan(String salesMan) {
		this.salesMan = salesMan;
	}
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getStwae() {
		return stwae;
	}
	public void setStwae(String stwae) {
		this.stwae = stwae;
	}
	public String getBasme() {
		return basme;
	}
	public void setBasme(String basme) {
		this.basme = basme;
	}
	public String getUnitPrice1() {
		return unitPrice1;
	}
	public void setUnitPrice1(String unitPrice1) {
		this.unitPrice1 = unitPrice1;
	}
	public String getUnitPrice2() {
		return unitPrice2;
	}
	public void setUnitPrice2(String unitPrice2) {
		this.unitPrice2 = unitPrice2;
	}
	public String getGapPct() {
		return gapPct;
	}
	public void setGapPct(String gapPct) {
		this.gapPct = gapPct;
	}
	public String getAvgUnitPrice() {
		return avgUnitPrice;
	}
	public void setAvgUnitPrice(String avgUnitPrice) {
		this.avgUnitPrice = avgUnitPrice;
	}
	public String getAvgGapPct() {
		return avgGapPct;
	}
	public void setAvgGapPct(String avgGapPct) {
		this.avgGapPct = avgGapPct;
	}
		
}
	
	
	
