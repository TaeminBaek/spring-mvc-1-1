package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissImpDevVO;
import com.lgmma.salesPortal.app.model.DissScheduleVO;
import com.lgmma.salesPortal.app.model.DissStepVO;

public interface DissImpDevService {
	
	void createDissImpDev(DissImpDevVO param);
	
	int getDissTaskNameCount(DissImpDevVO param);
	
	int getDissImpDevListCount(DissImpDevVO param);
	
	List<DissImpDevVO> getDissImpDevList(DissImpDevVO param);
	
	List<DissImpDevVO> getDissImpDevLeaderTeamList();
	
	List<CommonCodeVO> getDissStepGroupToStepCdList(CommonCodeVO param);
	
	DissImpDevVO getDissImpDevDetail(DissImpDevVO param);
	
	void updateDissImpDevAll(DissImpDevVO param);
	
	void updateDissImpDev(DissImpDevVO param);

	void updateImpDevSchedule(DissImpDevVO param);

	void deleteImpDevScheduleEdit(DissImpDevVO param);

	void applDissImpDevScheduleEdit(DissApprCommonParamVO param);
	
	void deleteDissImpDevAll(DissStepVO param);
	
	void deleteDissImpDevApprType(DissImpDevVO param);
	
	void saveDissImpDevApprTypeRew(DissImpDevVO param);
	
	void saveDissImpDevApprType(DissImpDevVO param);
	
	void saveDissImpDevApprovalAction(DissStepVO param);
	
	DissImpDevVO getDissImpDevApprTypeDetail(DissStepVO param);
	
	DissImpDevVO getDissImpDevScheduleCommon(DissImpDevVO param);
	
	void createDissImpDevDegree(DissStepVO param);
	
	DissImpDevVO getDissImpDevStepRsltDetail(DissStepVO param);	
	
	DissImpDevVO getDissImpDevTaskBasicInfoDetail(DissStepVO param);

	List<DissImpDevVO> getDissImpDevListExcelDownload(DissImpDevVO param);

	String getApprFormContProposal(DissStepVO param, String templeteFormContent);//kjy	
	
	String getApprFormContPrescription(DissStepVO param, String templeteFormContent);//kjy
	
	String getApprFormContSampleEval(DissStepVO param, String templeteFormContent);//kjy

	void updateLeader(DissImpDevVO param);

	List<DissScheduleVO> getDissScheduleHisList(String stepId);
}
