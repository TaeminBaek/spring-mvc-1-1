package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.StatisticsCustSuppVO;
import com.lgmma.salesPortal.app.model.StatisticsOrderVO;


public interface StatisticsDao {

	List<StatisticsOrderVO> getStatOrderList(StatisticsOrderVO param);
	
	List<StatisticsOrderVO> getStatOrderView(StatisticsOrderVO param);
	
	List<StatisticsCustSuppVO> getStatCustSuppList(StatisticsCustSuppVO param);
	
	List<StatisticsCustSuppVO> getStatCustSuppView(StatisticsCustSuppVO param);

	List<StatisticsCustSuppVO> getStatCustSuppDetail(StatisticsCustSuppVO param);
}
