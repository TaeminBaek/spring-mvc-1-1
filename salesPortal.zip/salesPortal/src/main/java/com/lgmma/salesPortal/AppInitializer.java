package com.lgmma.salesPortal;

import javax.servlet.Filter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.filter.DelegatingFilterProxy;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import com.lgmma.salesPortal.config.EhcacheConfig;
import com.lgmma.salesPortal.config.PropertiesConfig;
import com.lgmma.salesPortal.config.TransactionConfig;
import com.lgmma.salesPortal.config.WebMvcConfig;
import com.lgmma.salesPortal.config.WebSecurityConfig;

public class AppInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		super.onStartup(servletContext);
	}

	/**
	 * 서블릿 필터 
	 */
	@Override
	protected Filter[] getServletFilters() {
		//인코딩 필터
		CharacterEncodingFilter encodingFilter = new CharacterEncodingFilter();
		encodingFilter.setEncoding("EUC-KR");
		encodingFilter.setForceEncoding(true);

		DelegatingFilterProxy httpLoggingFilter = new DelegatingFilterProxy("httpLoggingFilter");
		
		return new Filter[] {
			encodingFilter,
			httpLoggingFilter
		};
	}
	
	/**
	 * 루트 컨텍스트 컨피그
	 */
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] {
			WebMvcConfig.class,
			WebSecurityConfig.class,
			TransactionConfig.class,
			PropertiesConfig.class,
			EhcacheConfig.class
		};
	}

	/**
	 * DispatcherServlet 컨텍스트 컨피그. 필요할까?
	 */
	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] {
			
		};
	}

	/**
	 * DispatcherServlet url-pattern
	 */
	@Override
	protected String[] getServletMappings() {
		return new String[] {"/"};
	}

	/**
	 * 스프링 4.x 이상에서 DispatcherServlet 의 throwExceptionIfNoHandlerFound 파라미터가 false 일 때 (defalut 는 false)
	 * 핸들러 맵핑에서 핸들러를 찾지 못할 경우 response.sendError(HttpServletResponse.SC_NOT_FOUND); 를 한다.
	 * Ajax 요청일 경우 에러 메시지 보여주기 위해 true 로 하고 ExceptionResolver 에서 잡음.
	 */
	@Override
	protected void customizeRegistration(ServletRegistration.Dynamic registration) {
		registration.setInitParameter("throwExceptionIfNoHandlerFound", "true");
	}
	
}
