package com.lgmma.salesPortal.app.dao;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;
import com.lgmma.salesPortal.app.model.VocVO;

public interface CommonDao {

	List<EmployVO> getEmployList(EmployVO param);

	EmployVO getEmployByPosiCode(EmployVO param);

	int getEmployListCount(EmployVO param);
	
	List<CommonCodeVO> getCommonCodeComboList(CommonCodeVO param);

	EmployVO getEmployBySawnCode(String sawnCode);
	
	int getProductPopupCount(ProductVO param);
	
	List<ProductVO> getProductPopupList(ProductVO param);

	int getCustomerPopupCount(CompanyVO param);

	List<CompanyVO> getCustomerPopupList(CompanyVO param);

	int getWebAccountPopupCount(LoginUserVO param);

	List<LoginUserVO> getWebAccountPopupList(LoginUserVO param);

	CompanyVO checkCompanyBusinoDub(Map<String, String> param);

	Map getMemberNameMail(Map<String, String> param);
	
	String getKvgr3(String param);
	
	List<String> getKunnr(Map<String, String> param);
	
	List<VocVO> getVocSrvcList();
	
	List<VocVO> getVocSrvcDivxList(VocVO param);

	int getAgencyPopupCount(CompanyVO param);

	List<CompanyVO> getAgencyPopupList(CompanyVO param);

	int getSalePricePopupCount(SalePriceMasterVO param);

	List<SalePriceMasterVO> getSalePricePopupList(SalePriceMasterVO param);

	String getPositionName(String posiCode);

	String getTeamName(String teamCode);
	
	List<CommonCodeVO> getDissProdDivisionDList(CommonCodeVO param);
	
	List<CommonCodeVO> getDissFailReasonDtlList(CommonCodeVO param);

	ProductVO getProductDtl(ProductVO param);
}
