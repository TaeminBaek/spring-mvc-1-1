package com.lgmma.salesPortal.app.dao;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.DissOneTeamVO;
import com.lgmma.salesPortal.app.model.EmployVO;

public interface DissOneTeamDao {
	
	String createDissOneTeamCode();
	
	void createDissOneTeam(DissOneTeamVO param);
	
	int getDissOneTeamListCount(DissOneTeamVO param);
	
	List<DissOneTeamVO> getDissOneTeamList(DissOneTeamVO param);
	
	List<DissOneTeamVO> getDissOneTeamLeaderTeamList();
	
	DissOneTeamVO getDissOneTeamInfo(DissOneTeamVO param);
	
	DissOneTeamVO getDissOneTeamHisInfo(DissOneTeamVO param);
	
	void updateDissOneTeam(DissOneTeamVO param);
	
	void deleteDissOneTeamAll(DissOneTeamVO param);
	
	void createDissOneTeamHis(DissOneTeamVO param);
	
	void updateDissOneTeamHis(DissOneTeamVO param);
	
	void deleteDissOneTeamHisAll(DissOneTeamVO param);

	DissOneTeamVO getDissOneTeamInfoByApprId(DissOneTeamVO param);
	
	List<EmployVO> loadEmployList(Map<String, String> param);
	
	DissOneTeamVO getProdTypeTxt(DissOneTeamVO param);
}
