package com.lgmma.salesPortal.security.accessdecision;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDecisionVoter;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.FilterInvocation;
import org.springframework.stereotype.Component;

@Component
public class CustomAccessDecisionVoter implements AccessDecisionVoter<FilterInvocation> {
/*
	@Autowired SecurityLogService securityLogService;
*/
	public boolean supports(ConfigAttribute attribute) {
		return true;
	}

	public boolean supports(Class<?> clazz) {
		return FilterInvocation.class.isAssignableFrom(clazz);
	}

	/*
	 * 디폴트 AccessDecisionManager 인 AffirmativeBased 는...
	 * 등록된 여러 AccessDecisionVoter 들 중 하나라도 AccessDecisionVoter.ACCESS_GRANTED 를 리턴하면 사용자의 접근을 허용한다.
	 *//*
	@Override
	public int vote(Authentication authentication, FilterInvocation fi, Collection<ConfigAttribute> attributes) {
		boolean canAccess = true;
		
		HttpServletRequest req = fi.getHttpRequest();
		
		//요청 URI 와 해당 사용자가 해당 URI 에 대한 권한이 있는지 체크
		String requestUri = fi.getRequestUrl(); //req.getRequestURI();
		
		//사용자 정보 없는 건 ExceptionTranslationFilter 에 의해 걸러지도록 예외 안던진다.
		UserInfo userInfo = Util.getUserInfo();
		if(userInfo == null) 
		{
			canAccess = false;
		}
		else
		{
			//사용자의 메뉴 리스트
			List allowedUriList = userInfo.getAllowedViewUri();
			if(allowedUriList == null || allowedUriList.isEmpty()) 
			{
				canAccess = false;
			}			
			//해당 메뉴 뷰페이지 접근 권한 체크
			else if(requestUri!= null && requestUri.startsWith("/view/app/") && !allowedUriList.contains(req.getRequestURI())) 
			{
				canAccess = false;	
			}
			
			//Ajax 저장 요청 권한 체크. 
			if(requestUri.startsWith("/stdSave") && !requestUri.startsWith("/stdSave/index"))
			{
				boolean isHack = false;
				String x = req.getParameter("X_VAL"); //uuid
				String y = req.getParameter("Y_VAL"); //uuid
				String z = req.getParameter("Z_VAL"); //uuid+authType
				String c = req.getParameter("C_VAL"); //uuid+userRole
				String at = req.getParameter("AUTH_TYPE");
				if(!CustomAuthenticationProvider.passwordEncoder.matches(x, y)) {
					isHack = true;
					canAccess = false;
				}
				if(!CustomAuthenticationProvider.passwordEncoder.matches(x+at, z)) {
					isHack = true;
					canAccess = false;
				}
				if(!CustomAuthenticationProvider.passwordEncoder.matches(x+Util.getUserInfo("userRole"), c)) {
					isHack = true;
					canAccess = false;
				}
				
				String referer = Util.nvl(req.getHeader("referer"),"");
				String refererUri = referer.split("\\?")[0];				
				refererUri = refererUri.substring(Math.max(refererUri.indexOf("/view/app"),0));				
				String authType = Util.nvl(userInfo.getAllowedViewUriAuth().get(refererUri), "");
				if(authType.indexOf("M") < 0) {
					canAccess = false;
				}

				String uriMappingKey = req.getParameter("X_VAL");
				String mappingUri = userInfo.getAllowedViewUriMappingKey().get(uriMappingKey);
				String authTypeByMappingKey = Util.nvl(userInfo.getAllowedViewUriAuth().get(mappingUri), "");
				if(authTypeByMappingKey.indexOf("M") < 0) {
					canAccess = false;
				}

				if(!refererUri.equals(mappingUri)) {
					canAccess = false;
				}

				if(!requestUri.startsWith("/stdSave/order") && !requestUri.startsWith("/stdSave/ecm")) {
					String reqUri = requestUri.split("\\?")[0];
					String[] reqUriSplit = reqUri.split("/");
					if(reqUriSplit.length < 2) {
						canAccess = false;
					}else{
						String orgView = "/view/app/" + reqUriSplit[2];
						String authTypeByReqUri = Util.nvl(userInfo.getAllowedViewUriAuth().get(orgView), "");
						if(authTypeByReqUri.indexOf("M") < 0) {
							canAccess = false;
						}
					}
				}
				
				if(!canAccess && (isHack || requestUri.startsWith("/stdSave/noticeMgmt"))) {
					try{
						securityLogService.blockHacker(req);						
					}catch(Exception e){
						throw new AccessDeniedException(e.getMessage());
					}
				}
			}
			
			//게시판 첨부파일 경로 바로 치고 들어오면 차단
			if(requestUri.startsWith("/orsupload/notice")) 
			{
				securityLogService.blockHacker(req);
			}
						
			//인증된 사용자의 접근 제한에 걸릴 경우 예외 던져버림
			if(!canAccess && !Util.isIn(userInfo.getUserRole(), "ROLE_ADMIN", "ROLE_USER")) 
			{
				throw new AccessDeniedException("Access is denied");
			}
		}
		
		return canAccess ? AccessDecisionVoter.ACCESS_ABSTAIN : AccessDecisionVoter.ACCESS_DENIED;
	}
*/
	public int vote(Authentication arg0, FilterInvocation arg1, Collection<ConfigAttribute> arg2) {
		return 0;
	}
}
