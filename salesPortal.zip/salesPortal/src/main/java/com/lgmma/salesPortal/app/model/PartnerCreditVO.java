package com.lgmma.salesPortal.app.model;

public class PartnerCreditVO extends PagingParamVO {
	
	private String vtext ;				// 채권 구분

	// 채권현황 변수
	private String msale;				// 외상매입금
	private String mreca;				// 현금
	private String mrebi;				// 어음결제
	private String cbica;				// 어음현금화
	private String notbi;				// 어음/수표

	// 보유어음 변수

	private String txt30;				// 어음종류
	private String wort2;				// 발행인
	private String wbank;				// 지급은행	
	private String zfbdt;				// 만기일자	

	// 만기어음 변수 : 공통변수로 사용

	// 현금결제 변수
	private String buzei;				// 회계전표의 개별항목번호	SEQ NO

	// 공통 변수
	private String hkont;				// 계정번호
	private String budat;				// 전기일자
	private String zuonr;				// 어음번호
	private String dmbtr;				// 입금액
	private String txt20;				// 입금은행
	private String belnr;				// 전표번호

	// 고객정보
	private String mail;				// 메일
	private String hpx;					// 핸드폰
	private String logn_name;			// 핸드폰
	private String kunnr;				// 거래선
	private String spmon;				// 기준월
	private String vkorg;				// 영업조직
	private String compName;
	
	public String getVtext() {
		return vtext;
	}
	public void setVtext(String vtext) {
		this.vtext = vtext;
	}
	public String getMsale() {
		return msale;
	}
	public void setMsale(String msale) {
		this.msale = msale;
	}
	public String getMreca() {
		return mreca;
	}
	public void setMreca(String mreca) {
		this.mreca = mreca;
	}
	public String getMrebi() {
		return mrebi;
	}
	public void setMrebi(String mrebi) {
		this.mrebi = mrebi;
	}
	public String getCbica() {
		return cbica;
	}
	public void setCbica(String cbica) {
		this.cbica = cbica;
	}
	public String getNotbi() {
		return notbi;
	}
	public void setNotbi(String notbi) {
		this.notbi = notbi;
	}
	public String getTxt30() {
		return txt30;
	}
	public void setTxt30(String txt30) {
		this.txt30 = txt30;
	}
	public String getWort2() {
		return wort2;
	}
	public void setWort2(String wort2) {
		this.wort2 = wort2;
	}
	public String getWbank() {
		return wbank;
	}
	public void setWbank(String wbank) {
		this.wbank = wbank;
	}
	public String getZfbdt() {
		return zfbdt;
	}
	public void setZfbdt(String zfbdt) {
		this.zfbdt = zfbdt;
	}
	public String getBuzei() {
		return buzei;
	}
	public void setBuzei(String buzei) {
		this.buzei = buzei;
	}
	public String getHkont() {
		return hkont;
	}
	public void setHkont(String hkont) {
		this.hkont = hkont;
	}
	public String getBudat() {
		return budat;
	}
	public void setBudat(String budat) {
		this.budat = budat;
	}
	public String getZuonr() {
		return zuonr;
	}
	public void setZuonr(String zuonr) {
		this.zuonr = zuonr;
	}
	public String getDmbtr() {
		return dmbtr;
	}
	public void setDmbtr(String dmbtr) {
		this.dmbtr = dmbtr;
	}
	public String getTxt20() {
		return txt20;
	}
	public void setTxt20(String txt20) {
		this.txt20 = txt20;
	}
	public String getBelnr() {
		return belnr;
	}
	public void setBelnr(String belnr) {
		this.belnr = belnr;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getHpx() {
		return hpx;
	}
	public void setHpx(String hpx) {
		this.hpx = hpx;
	}
	public String getLogn_name() {
		return logn_name;
	}
	public void setLogn_name(String logn_name) {
		this.logn_name = logn_name;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getSpmon() {
		return spmon;
	}
	public void setSpmon(String spmon) {
		this.spmon = spmon;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
}
