package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.CodeGroupVO;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.DocTemplateVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.model.ProgramVO;
import com.lgmma.salesPortal.app.service.CommonApprMgmtService;
import com.lgmma.salesPortal.app.service.CommonCodeMgmtService;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.DocTemplateMgmtService;
import com.lgmma.salesPortal.app.service.ProgramMgmtService;
import com.lgmma.salesPortal.app.service.StockDisplayMgmtService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;

@Controller
@RequestMapping("/system") 
public class SystemController {

	@Autowired
	private ProgramMgmtService programMgmtService;

	@Autowired
	private CommonCodeMgmtService commonCodeMgmtService;

	@Autowired
	private StockDisplayMgmtService stockDisplayMgmtService;
	
	@Autowired
	private DocTemplateMgmtService docTemplateMgmtService;

	@Autowired
	private CommonApprMgmtService commonApprMgmtService;

	@Autowired
	private DissCommonApprMgmtService dissCommonApprMgmtService;

	@Autowired
	private CommonController commonController;

	
	@RequestMapping(value = "/codeGroupMgmt")
	public String codeGroupMgmt() throws Exception {
		return "system/codeGroupMgmt";
	}

	@RequestMapping(value = "/getCodeGroupList.json")
	public Map getCodeGroupList(@RequestBody(required = true) CodeGroupVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", commonCodeMgmtService.getCodeGroupCount(param), "storeData", commonCodeMgmtService.getCodeGroupList(param));
	}

	@RequestMapping(value = "/updateCodeGroup.json")
	public Map updateCodeGroup(@RequestBody CodeGroupVO param) throws Exception {
		commonCodeMgmtService.updateCodeGroup(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/createCodeGroup.json")
	public Map createCodeGroup(@RequestBody CodeGroupVO param) throws Exception {
		commonCodeMgmtService.createCodeGroup(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/commonCodeMgmt")
	public String commonCodeMgmt() throws Exception {
		return "system/commonCodeMgmt";
	}

	@RequestMapping(value = "/getCommonCodeList.json")
	public Map getCommonCodeList(@RequestBody(required = true) CommonCodeVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", commonCodeMgmtService.getCommonCodeCount(param), "storeData", commonCodeMgmtService.getCommonCodeList(param));
	}

	@RequestMapping(value = "/updateCommonCode.json")
	public Map updateCommonCode(@RequestBody CommonCodeVO param) throws Exception {
		commonCodeMgmtService.updateCommonCode(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/createCommonCode.json")
	public Map createCommonCode(@RequestBody CommonCodeVO param) throws Exception {
		commonCodeMgmtService.createCommonCode(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/programMgmt")
	public String programMgmt() throws Exception {
		return "system/programMgmt";
	}

	@RequestMapping(value = "/getProgramList.json")
	public Map getProgramList(@RequestBody(required = true) ProgramVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", programMgmtService.getProgramCount(param), "storeData", programMgmtService.getProgramList(param));
	}

	@RequestMapping(value = "/createProgram.json")
	public Map createProgram(@RequestBody ProgramVO param) throws Exception {
		programMgmtService.createProgram(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/updateProgram.json")
	public Map updateProgram(@RequestBody ProgramVO param) throws Exception {
		programMgmtService.updateProgram(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/stockDisplayMgmt")
	public ModelAndView stockDisplayMgmt(ModelAndView mav) throws Exception {
		mav.setViewName("system/stockDisplayMgmt");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		return mav;
	}

	@RequestMapping(value = "/getStockDisplayList.json")
	public Map getStockDisplayList(@RequestBody(required = true) ProductVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", stockDisplayMgmtService.getStockDisplayCount(param), "storeData", stockDisplayMgmtService.getStockDisplayList(param));
	}

	@RequestMapping(value = "/updateStockDisplay.json")
	public Map updateStockDisplayResult(@RequestBody List<ProductVO> paramList) throws Exception{
		stockDisplayMgmtService.updateStockDisplay(paramList);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/getProductsFromSap.json")
	public Map getProductsFromSap() throws Exception {
		stockDisplayMgmtService.getProductsFromSap();
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/docTemplateMgmt")
	public ModelAndView docTemplateMgmt(ModelAndView mav) throws Exception {
		mav.setViewName("system/docTemplateMgmt");
		return mav;
	}

	@RequestMapping(value = "/getDocTemplateList.json")
	public Map getDocTemplateList(@RequestBody(required = true) DocTemplateVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", docTemplateMgmtService.getDocTemplateCount(param) , "storeData", docTemplateMgmtService.getDocTemplateList(param));
	}

	@RequestMapping(value = "/updateDocTemplate.json")
	public Map updateDocTemplate(@RequestBody DocTemplateVO param) throws Exception {
		docTemplateMgmtService.updateDocTemplate(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/createDocTemplate.json")
	public Map createDocTemplate(@RequestBody DocTemplateVO param) throws Exception {
		docTemplateMgmtService.createDocTemplate(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/getNotDeletedTemplate.json")
	public Map getNotDeletedTemplate(@RequestBody DocTemplateVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", docTemplateMgmtService.getNotDeletedDocTemplateList(param).size() , "storeData", docTemplateMgmtService.getNotDeletedDocTemplateList(param));
	}

	@RequestMapping(value = "/apprMgmt")
	public ModelAndView apprMgmt(ModelAndView mav) throws Exception {
		mav.setViewName("system/apprMgmt");
		mav.addObject("apprType", new ArrayList< ApprType >(Arrays.asList(ApprType.values())));
		mav.addObject("defaultFrDay", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-3)));
		mav.addObject("defaultToDay", DateUtil.defaultFormatDate(DateUtil.getToday()));
		return mav;
	}

	@RequestMapping(value = "/getApprList.json")
	public Map getApprList(@RequestBody(required = true) ApprVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", commonApprMgmtService.getApprListCount(param) , "storeData", commonApprMgmtService.getApprList(param));
	}

	@RequestMapping(value = "/deleteAppr.json")
	public Map deleteAppr(@RequestBody(required=true) Map<String, String> param) throws Exception {
		dissCommonApprMgmtService.deleteGPortalApproval(param.get("apprId"), param.get("apprEmpId"));
		return JsonResponse.asSuccess("success", "삭제되었습니다");
	}
}
