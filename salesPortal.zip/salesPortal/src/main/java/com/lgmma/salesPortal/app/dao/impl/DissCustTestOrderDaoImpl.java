package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissCustTestOrderDao;
import com.lgmma.salesPortal.app.model.DissCustTestOrderVO;

@Repository
public class DissCustTestOrderDaoImpl implements DissCustTestOrderDao{
	
	private static final String MAPPER_NAMESPACE = "DISSCUSTTESTORDER_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;
	
	@Override
	public List<DissCustTestOrderVO> getDissCustTestOrderList(DissCustTestOrderVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissCustTestOrderList", param);
	}
	
	@Override
	public void createDissCustTestOrder(DissCustTestOrderVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissCustTestOrder", param);
	}
	
	@Override
	public void updateDissCustTestOrder(DissCustTestOrderVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissCustTestOrder", param);
	}
	
	@Override
	public void deleteDissCustTestOrderAll(DissCustTestOrderVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissCustTestOrderAll", param);
	}	

}
