package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.ProgramVO;

public interface ProgramDao {
	
	public int getProgramCount(ProgramVO param);

	List<ProgramVO> getProgramList(ProgramVO param);

	public void createProgram(ProgramVO param);

	public void updateProgram(ProgramVO param);


}
