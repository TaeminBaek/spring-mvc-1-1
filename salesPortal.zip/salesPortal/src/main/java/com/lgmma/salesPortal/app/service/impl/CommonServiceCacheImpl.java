package com.lgmma.salesPortal.app.service.impl;

import com.lgmma.salesPortal.app.dao.CommonCodeDao;
import com.lgmma.salesPortal.app.dao.CommonDao;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.service.CommonServiceCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@Service
public class CommonServiceCacheImpl implements CommonServiceCache {

	@Autowired
	private CommonCodeDao commonCodeDao;

	@Cacheable( cacheNames="getCommonCodeDbAllCache")
	@Override
	public List<CommonCodeVO> getCommonCodeDbAll() {
		return commonCodeDao.getCommonCodeDbAll();
	}
}
