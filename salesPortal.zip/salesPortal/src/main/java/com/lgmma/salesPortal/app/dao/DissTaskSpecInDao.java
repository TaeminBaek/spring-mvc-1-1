package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissTaskSpecInVO;

public interface DissTaskSpecInDao {
	
	void createDissTaskSpecIn(DissTaskSpecInVO param);
	
	List<DissTaskSpecInVO> getDissTaskSpecInList(DissTaskSpecInVO param);
	
	void deleteDissTaskSpecInAll(DissTaskSpecInVO param);
	
	void createDissTaskSpecInHis(DissTaskSpecInVO param);
	
	void deleteDissTaskSpecInHisAll(DissTaskSpecInVO param);
	
	List<DissTaskSpecInVO> getDissTaskSpecInHisList(DissTaskSpecInVO param);
	
	void updateDissTaskSpecIn(DissTaskSpecInVO param);
	
	void updateDissTaskSpecInHis(DissTaskSpecInVO param);
	
	List<DissTaskSpecInVO> getSpecInListWithTotalSaleGoal(DissTaskSpecInVO param);
	
	int getSpecInListWithTotalSaleGoalCnt(DissTaskSpecInVO param);
}
