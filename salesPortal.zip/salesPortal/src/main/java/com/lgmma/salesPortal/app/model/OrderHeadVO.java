package com.lgmma.salesPortal.app.model;

import java.util.Collections;
import java.util.List;

import javax.validation.Valid;

public class OrderHeadVO extends PagingParamVO {
	

	// TBS_ORDERHEAD
	private int eordHdid;    //주문 ID
	private int eitmHdid;    //주문 ID
	private String tvkotVkorg;  //주문제품군ID      
	private String tvkotVtext;  //주문제품군명      
	private String eordComp;    //주문처ID
	private String eoreName;    //주문처명 
	private String saleComp;    //판매처ID
	private String partnerYn;    //판매처 파트너 여부
	private String saleCompName;    //판매처명
	private String coaxIsxx;    //시험성적서첨부여부
	private String veslCond;    //운임조건
	private String coaxIsxxName;    //시험성적서첨부여부
	private String veslCondName;    //운임조건
	private String lognName;	//주문자
	private String hpxxNumx;	//주문자 전번
	private String compCode;	//erp판매처
	private String kunnr;		//SAP판매처코드
	private String bigoText;		//비고
	private String regiGubn;		//등록구분 P파트너 C임직원
	private String orderType;		//주문유형 ZBOR > 전자상거래  ZDOR > 특가
	private String vkbur; //관리팀 코드
	private String division; //관리팀 코드
	private String divisionText; //관리팀 코드
	
	private String saleManCode; //판매처 담당 영업사원코드
	private String saleManName; //판매처 담당 영업사원이름

	private String partnNumbZ7; //실재인도처 아이디
	private String partnNameZ7; //실재인도처 명
	private String priceList;
	private String erpxIdxx;
	
	
	@Valid
	private List<OrderItemVO> itemList = Collections.emptyList();    //제품
	private List<ItemDeliveryVO> itemDeliveryList = Collections.emptyList();    //출하정보

	public String getSaleManCode() {
		return saleManCode;
	}

	public void setSaleManCode(String saleManCode) {
		this.saleManCode = saleManCode;
	}

	public String getSaleManName() {
		return saleManName;
	}

	public void setSaleManName(String saleManName) {
		this.saleManName = saleManName;
	}

	public String getCompCode() {
		return compCode;
	}

	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	
	public String getKunnr() {
		return kunnr;
	}

	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}

	public String getEoreName() {
		return eoreName;
	}

	public void setEoreName(String eoreName) {
		this.eoreName = eoreName;
	}

	public String getLognName() {
		return lognName;
	}

	public void setLognName(String lognName) {
		this.lognName = lognName;
	}

	public String getHpxxNumx() {
		return hpxxNumx;
	}

	public void setHpxxNumx(String hpxxNumx) {
		this.hpxxNumx = hpxxNumx;
	}

	public int getEitmHdid() {
		return eitmHdid;
	}

	public void setEitmHdid(int eitmHdid) {
		this.eitmHdid = eitmHdid;
	}

	public int getEordHdid() {
		return eordHdid;
	}

	public void setEordHdid(int eordHdid) {
		this.eordHdid = eordHdid;
	}

	public String getTvkotVkorg() {
		return tvkotVkorg;
	}

	public void setTvkotVkorg(String tvkotVkorg) {
		this.tvkotVkorg = tvkotVkorg;
	}

	public String getTvkotVtext() {
		return tvkotVtext;
	}

	public void setTvkotVtext(String tvkotVtext) {
		this.tvkotVtext = tvkotVtext;
	}

	public String getEordComp() {
		return eordComp;
	}

	public void setEordComp(String eordComp) {
		this.eordComp = eordComp;
	}

	public String getSaleComp() {
		return saleComp;
	}

	public void setSaleComp(String saleComp) {
		this.saleComp = saleComp;
	}

	public String getSaleName() {
		return saleCompName;
	}

	public void setSaleName(String saleName) {
		this.saleCompName = saleName;
	}

	public String getCoaxIsxx() {
		return coaxIsxx;
	}

	public void setCoaxIsxx(String coaxIsxx) {
		this.coaxIsxx = coaxIsxx;
	}

	public String getVeslCond() {
		return veslCond;
	}

	public void setVeslCond(String veslCond) {
		this.veslCond = veslCond;
	}

	public List<OrderItemVO> getItemList() {
		return itemList;
	}

	public void setItemList(List<OrderItemVO> itemList) {
		this.itemList = itemList;
	}

	public String getSaleCompName() {
		return saleCompName;
	}

	public void setSaleCompName(String saleCompName) {
		this.saleCompName = saleCompName;
	}

	public String getBigoText() {
		return bigoText;
	}

	public void setBigoText(String bigoText) {
		this.bigoText = bigoText;
	}

	public List<ItemDeliveryVO> getItemDeliveryList() {
		return itemDeliveryList;
	}

	public void setItemDeliveryList(List<ItemDeliveryVO> itemDeliveryList) {
		this.itemDeliveryList = itemDeliveryList;
	}

	public String getCoaxIsxxName() {
		return coaxIsxxName;
	}

	public void setCoaxIsxxName(String coaxIsxxName) {
		this.coaxIsxxName = coaxIsxxName;
	}

	public String getVeslCondName() {
		return veslCondName;
	}

	public void setVeslCondName(String veslCondName) {
		this.veslCondName = veslCondName;
	}

	public String getRegiGubn() {
		return regiGubn;
	}

	public void setRegiGubn(String regiGubn) {
		this.regiGubn = regiGubn;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getPartnerYn() {
		return partnerYn;
	}

	public void setPartnerYn(String partnerYn) {
		this.partnerYn = partnerYn;
	}

	public String getPartnNumbZ7() {
		return partnNumbZ7;
	}

	public void setPartnNumbZ7(String partnNumbZ7) {
		this.partnNumbZ7 = partnNumbZ7;
	}

	public String getPartnNameZ7() {
		return partnNameZ7;
	}

	public void setPartnNameZ7(String partnNameZ7) {
		this.partnNameZ7 = partnNameZ7;
	}

	public String getPriceList() {
		return priceList;
	}

	public void setPriceList(String priceList) {
		this.priceList = priceList;
	}

	public String getErpxIdxx() {
		return erpxIdxx;
	}

	public void setErpxIdxx(String erpxIdxx) {
		this.erpxIdxx = erpxIdxx;
	}

	public String getVkbur() {
		return vkbur;
	}

	public void setVkbur(String vkbur) {
		this.vkbur = vkbur;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getDivisionText() {
		return divisionText;
	}

	public void setDivisionText(String divisionText) {
		this.divisionText = divisionText;
	}

}
