package com.lgmma.salesPortal.common.model;

public class SapMasterCode {
	private String zgubun;
	private String zcode;
	private String ztext;

	public String getZgubun() {
		return zgubun;
	}
	public void setZgubun(String zgubun) {
		this.zgubun = zgubun;
	}
	public String getZcode() {
		return zcode;
	}
	public void setZcode(String zcode) {
		this.zcode = zcode;
	}
	public String getZtext() {
		return ztext;
	}
	public void setZtext(String ztext) {
		this.ztext = ztext;
	}

}
