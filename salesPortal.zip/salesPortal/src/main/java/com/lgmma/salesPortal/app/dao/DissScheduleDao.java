package com.lgmma.salesPortal.app.dao;

import java.util.List;
import com.lgmma.salesPortal.app.model.DissScheduleVO;

public interface DissScheduleDao {	

	void createDissSchedule(DissScheduleVO param);
	
	List<DissScheduleVO> getDissScheduleList(DissScheduleVO param);

	List<DissScheduleVO> getDissScheduleHisList(DissScheduleVO param);

	void mergeDissSchedule(DissScheduleVO param);
	
	void deleteDissScheduleAll(DissScheduleVO param);
	
	void createDissScheduleHis(DissScheduleVO param);
	
	void mergeDissScheduleHis(DissScheduleVO param);
	
	void deleteDissScheduleHisAll(DissScheduleVO param);
	
	void updateDissScheduleCompYmd(DissScheduleVO param);
	
	void updateDissScheduleHisCompYmd(DissScheduleVO param);
	
	void updateDissScheduleCompGoalYmd(DissScheduleVO param);
	
	DissScheduleVO getDissScheduleDetail(DissScheduleVO param);
	
	List<DissScheduleVO> getDissScheduleStepRsltList(DissScheduleVO param);
	
	void deleteDissSchedule(DissScheduleVO param);
	
	void deleteDissScheduleHis(DissScheduleVO param);
	
	void createDissScheduleHisBySelect(DissScheduleVO param);

	String chkSalesTeam(DissScheduleVO param);

	String chkTSTeam(DissScheduleVO param);

	void updateDissSchedule(DissScheduleVO param);
}
