package com.lgmma.salesPortal.app.service;

import java.io.UnsupportedEncodingException;

import com.lgmma.salesPortal.app.model.ApprVO;

public interface GPortalListTypeRestService {

	void requestApproval(ApprVO paramApprVO);

	void sendApproval(ApprVO paramApprVO, String apprEmpId);

	void deleteApproval(String apprId, String apprEmpId, String apprMessage);
	
	String approvalAtcionFromGPortal(String apprId, String apprEmpId, String apprStatus, String apprEmpComment) throws UnsupportedEncodingException;
}
