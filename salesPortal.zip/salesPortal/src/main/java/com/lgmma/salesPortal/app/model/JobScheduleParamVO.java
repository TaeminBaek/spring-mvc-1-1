package com.lgmma.salesPortal.app.model;

public class JobScheduleParamVO extends PagingParamVO {
	/* columns */
	private String frYmd;
	private String toYmd;

	public String getFrYmd() {
		return frYmd;
	}

	public void setFrYmd(String frYmd) {
		this.frYmd = frYmd;
	}

	public String getToYmd() {
		return toYmd;
	}

	public void setToYmd(String toYmd) {
		this.toYmd = toYmd;
	}
}
