package com.lgmma.salesPortal.common.props;

public enum ApprSecrCode {
/**
 * 품의서 보안설정 으로서
*/
	 APPR_SECR_ALL(	"00016"	,"전체보안"		, "G" ,"0")
	,APPR_SECR_ORG(	"00017"	,"소속부서보안"	, "G" ,"0")
	,APPR_SECR_EMP(	"00085"	,"결재자보안"	, "S" ,"1")
	;
	String code		= null;
	String name		= null;
	String gwScrt	= null;	// 그룹웨어보안설정
	String gpScrt	= null;	// GPortal 보안설정

	private ApprSecrCode(String code, String name	,String gwScrt, String gpScrt) {
		this.code	= code;
		this.name	= name;
		this.gwScrt	= gwScrt;
		this.gpScrt	= gpScrt;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGwScrt() {
		return gwScrt;
	}

	public void setGwScrt(String gwScrt) {
		this.gwScrt = gwScrt;
	}

	public String getGpScrt() {
		return gpScrt;
	}

	public void setGpScrt(String gpScrt) {
		this.gpScrt = gpScrt;
	}

	public static ApprSecrCode getApprSecrCode(String code) {
		for(ApprSecrCode type : ApprSecrCode.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
}
