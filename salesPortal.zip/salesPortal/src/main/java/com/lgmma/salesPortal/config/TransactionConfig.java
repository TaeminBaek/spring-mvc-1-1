package com.lgmma.salesPortal.config;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.TypeHandler;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;

import com.lgmma.salesPortal.common.factory.CustomSqlSessionFactoryBean;
import com.lgmma.salesPortal.common.mybatis.typehandler.XssGlobalTypeHandler;

import net.sf.log4jdbc.Log4jdbcProxyDataSource;
import net.sf.log4jdbc.tools.Log4JdbcCustomFormatter;
import net.sf.log4jdbc.tools.LoggingType;

@Configuration
@EnableTransactionManagement
//@MapperScan(annotationClass=Repository.class, basePackages={"com.lgmma.salesPortal.app"}) //마이바티스 매퍼 스캔
public class TransactionConfig implements TransactionManagementConfigurer
{
	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	/**
	 * 데이터 소스
	 1. JNDI - 톰캣의 경우 context.xml 에서 접속 정보 정의
		JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		DataSource dataSource = dsLookup.getDataSource("oracleDataSource");
		return dataSource;				
	 2. 하드코딩
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		dataSource.setUrl("jdbc:oracle:thin:@localhost:1521:LOCALDEV");
		dataSource.setUsername("scott");
		dataSource.setPassword("tiger");	
	 3. 오라클 전용 하드코딩
		OracleDataSource dataSource = null;
		try {
			dataSource = new OracleDataSource();
			dataSource.setURL("jdbc:oracle:thin:@localhost:1521:JOOBOK");
			dataSource.setUser("scott");
			dataSource.setPassword("tiger");
		} catch (SQLException e) { 
			e.printStackTrace();
			throw new DataAccessResourceFailureException("fali to create datasource...", e);
		}
	 */
	@Primary
	@Bean(name="dataSource")
	public DataSource dataSource()
	{		
/*
 * 스프링 권장 datasource
 * 제우스와 호환이 안되어 사용 안함...
*/
		/*
		JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		DataSource dataSource = dsLookup.getDataSource(messageSourceAccessor.getMessage("jndi.datasource.name"));
		
		Log4JdbcCustomFormatter formatter=new Log4JdbcCustomFormatter();
		formatter.setLoggingType(LoggingType.MULTI_LINE);
		formatter.setSqlPrefix("SQL : \n");
		
		Log4jdbcProxyDataSource  dataSourcePDS = new Log4jdbcProxyDataSource(dataSource);
		dataSourcePDS.setLogFormatter(formatter);
		
		return dataSourcePDS;
*/
		Context ctx = null;
		DataSource dataSource = null;
		try {
			ctx = new InitialContext();
			dataSource = (DataSource) ctx.lookup(messageSourceAccessor.getMessage("jndi.datasource.name"));
//			dataSource = (DataSource) ctx.lookup("jdbc/salesPortalDS");	//jeus
//			dataSource = (DataSource) ctx.lookup("java:/comp/env/jdbc/salesPortalDS"); //tomcat
			Log4JdbcCustomFormatter formatter=new Log4JdbcCustomFormatter();
			formatter.setLoggingType(LoggingType.MULTI_LINE);
			formatter.setSqlPrefix("SQL : \n");
			
			Log4jdbcProxyDataSource  dataSourcePDS = new Log4jdbcProxyDataSource(dataSource);
			dataSourcePDS.setLogFormatter(formatter);
		} catch (NamingException e) {
			e.printStackTrace();
		}
		return dataSource;
	}
	
    /**
     * 트랜잭션 메니저
     */
	@Primary
    @Bean(name="transactionManager")
    public PlatformTransactionManager transactionManager()
    {
        DataSourceTransactionManager transactionManager = new DataSourceTransactionManager();
        transactionManager.setDataSource(dataSource());
        //transactionManager.setTransactionSynchronization(DataSourceTransactionManager.SYNCHRONIZATION_ALWAYS);
        return transactionManager;
    }
    
    /**
     * Transactional 어노테이션 사용시 트랜잭션 메니저 지정안할 경우 기본 트랜잭션 메니저 설정
     * Bean 아님
     */
	@Override
	public PlatformTransactionManager annotationDrivenTransactionManager() 
	{
		return transactionManager();
	}
    
	/**
	 * 마이바티스 세션 팩토리. 
	 */
	@Primary
	@Bean(name="sqlSessionFactory")
	public SqlSessionFactory sqlSessionFactory() throws Exception
	{
		//새버 재시작 안하고 mapper 리로드하기 위한 빈
		SqlSessionFactoryBean factoryBean = CustomSqlSessionFactoryBean.getInstance();
		//운영시에는 이걸로
		//SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
		factoryBean.setDataSource(dataSource());
		factoryBean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:/sql/**/*.xml"));
		factoryBean.setTypeHandlers(new TypeHandler[] {new XssGlobalTypeHandler()});
		SqlSessionFactory sqlSessionFactory = factoryBean.getObject();
		sqlSessionFactory.getConfiguration().setMapUnderscoreToCamelCase(true);
		return sqlSessionFactory;
	}
	
    /**
     * 마이바티스 세션 템플릿
     * xml mappr 에서 파라미터가 Map 타입이고, #{변수명} 사용시 해당 값이 널일 경우 #{변수명, jdbcType=VARCHAR} 와 같이 jdbcType 을 지정해줘야 한다.
     * 일괄 적용을 위해 아래와 같이 setJdbcTypeForNull 을 설정함.
     * CustomSqlSessionFactoryBean 에서 refresh 할 때도 아래와 같이 함.
     * @throws Exception 
     */
	@Primary
    @Bean(name="sqlSession")
    public SqlSessionTemplate sqlSessionTemplate(@Qualifier("sqlSessionFactory") SqlSessionFactory sqlSessionFactory) throws Exception
    {
    	sqlSessionFactory.getConfiguration().setJdbcTypeForNull(JdbcType.NULL);
    	return new SqlSessionTemplate(sqlSessionFactory);
    }
    
    /**
     * SMS 용 데이터소스
     */
	@Bean(name="smsDataSource")
	public DataSource smsDataSource()
	{		
		Context ctx = null;
		DataSource dataSource = null;
		try {
			ctx = new InitialContext();
			dataSource = (DataSource) ctx.lookup(messageSourceAccessor.getMessage("jndi.smsDataSource.name"));
			Log4JdbcCustomFormatter formatter=new Log4JdbcCustomFormatter();
			formatter.setLoggingType(LoggingType.MULTI_LINE);
			formatter.setSqlPrefix("SQL : \n");
			
			Log4jdbcProxyDataSource  dataSourcePDS = new Log4jdbcProxyDataSource(dataSource);
			dataSourcePDS.setLogFormatter(formatter);
		} catch (NamingException e) {
			e.printStackTrace();
		}
		return dataSource;
	}
	
    /**
     * SMS 용 트랜잭션 메니저
     */
    @Bean(name="smsTransactionManager")
    public PlatformTransactionManager smsTransactionManager()
    {
        DataSourceTransactionManager transactionManager = new DataSourceTransactionManager();
        transactionManager.setDataSource(smsDataSource());
        //transactionManager.setTransactionSynchronization(DataSourceTransactionManager.SYNCHRONIZATION_ALWAYS);
        return transactionManager;
    }
    
	/**
	 * SMS 용 마이바티스 세션 팩토리. 
	 */
	@Bean(name="smsSqlSessionFactory")
	public SqlSessionFactory smsSqlSessionFactory() throws Exception
	{
		SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
		factoryBean.setDataSource(smsDataSource());
		factoryBean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:/sql/SmsSql.xml"));
		SqlSessionFactory sqlSessionFactory = factoryBean.getObject();
		sqlSessionFactory.getConfiguration().setMapUnderscoreToCamelCase(true);
		return sqlSessionFactory;
	}
	
    /**
     * SMS 용 마이바티스 세션 템플릿
     * xml mappr 에서 파라미터가 Map 타입이고, #{변수명} 사용시 해당 값이 널일 경우 #{변수명, jdbcType=VARCHAR} 와 같이 jdbcType 을 지정해줘야 한다.
     * 일괄 적용을 위해 아래와 같이 setJdbcTypeForNull 을 설정함.
     * CustomSqlSessionFactoryBean 에서 refresh 할 때도 아래와 같이 함.
     * @throws Exception 
     */
    @Bean(name="smsSqlSession")
    public SqlSessionTemplate smsSqlSessionTemplate(@Qualifier("smsSqlSessionFactory") SqlSessionFactory sqlSessionFactory) throws Exception
    {
    	sqlSessionFactory.getConfiguration().setJdbcTypeForNull(JdbcType.NULL);
    	return new SqlSessionTemplate(sqlSessionFactory);
    }

    /**
     * MSSQL 용 데이터소스
     */
	@Bean(name="msSqlDataSource")
	public DataSource msSqlDataSource()
	{
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(messageSourceAccessor.getMessage("mssql.server.url"));
		dataSource.setUsername(messageSourceAccessor.getMessage("mssql.server.user"));
		dataSource.setPassword(messageSourceAccessor.getMessage("mssql.server.pass"));
		Log4JdbcCustomFormatter formatter=new Log4JdbcCustomFormatter();
		formatter.setLoggingType(LoggingType.MULTI_LINE);
		formatter.setSqlPrefix("SQL : \n");

		Log4jdbcProxyDataSource  dataSourcePDS = new Log4jdbcProxyDataSource(dataSource);
		dataSourcePDS.setLogFormatter(formatter);
		return dataSource;
	}
	
    /**
     * MSSQL 용 트랜잭션 메니저
     */
    @Bean(name="msSqlTransactionManager")
    public PlatformTransactionManager msSqlTransactionManager()
    {
        DataSourceTransactionManager transactionManager = new DataSourceTransactionManager();
        transactionManager.setDataSource(msSqlDataSource());
        
        //transactionManager.setTransactionSynchronization(DataSourceTransactionManager.SYNCHRONIZATION_ALWAYS);
        return transactionManager;
    }
    
	/**
	 * MSSQL 용 마이바티스 세션 팩토리. 
	 */
	@Bean(name="msSqlSessionFactory")
	public SqlSessionFactory msSqlSessionFactory() throws Exception
	{
		SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
		factoryBean.setDataSource(msSqlDataSource());
		factoryBean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:/sql/MsSql.xml"));
		SqlSessionFactory sqlSessionFactory = factoryBean.getObject();
		sqlSessionFactory.getConfiguration().setMapUnderscoreToCamelCase(true);
		return sqlSessionFactory;
	}
	
    /**
     * MSSQL 용 마이바티스 세션 템플릿
     * xml mappr 에서 파라미터가 Map 타입이고, #{변수명} 사용시 해당 값이 널일 경우 #{변수명, jdbcType=VARCHAR} 와 같이 jdbcType 을 지정해줘야 한다.
     * 일괄 적용을 위해 아래와 같이 setJdbcTypeForNull 을 설정함.
     * CustomSqlSessionFactoryBean 에서 refresh 할 때도 아래와 같이 함.
     * @throws Exception 
     */
    @Bean(name="msSqlSession")
    public SqlSessionTemplate msSqlSessionTemplate(@Qualifier("msSqlSessionFactory") SqlSessionFactory sqlSessionFactory) throws Exception
    {
    	sqlSessionFactory.getConfiguration().setJdbcTypeForNull(JdbcType.NULL);
    	return new SqlSessionTemplate(sqlSessionFactory);
    }

}
