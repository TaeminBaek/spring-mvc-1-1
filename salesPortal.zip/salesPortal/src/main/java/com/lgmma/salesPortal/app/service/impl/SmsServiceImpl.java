package com.lgmma.salesPortal.app.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import com.lgmma.salesPortal.app.dao.SmsDao;
import com.lgmma.salesPortal.app.model.SmsVO;
import com.lgmma.salesPortal.app.service.SmsService;
import com.lgmma.salesPortal.common.util.StringUtil;

@Transactional(transactionManager = "smsTransactionManager")
@Service
public class SmsServiceImpl implements SmsService {

	@Autowired
	private SmsDao smsDao;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	@Override
	public void sendSms(SmsVO param) {
//		if(!StringUtil.nullConvert(param.getTrPhone()).equals("")) {
			String receiverNo = messageSourceAccessor.getMessage("sms.test.receiver", "");
			if(!receiverNo.equals("")) {
				param.setTrPhone(receiverNo);
			}
			if(!StringUtil.nullConvert(param.getTrPhone()).equals("")) {
				param.setTrPhone(StringUtil.remove(param.getTrPhone(), '-'));
				param.setTrCallback(messageSourceAccessor.getMessage("sms.callback.phone"));
				//메시지 길이가 컬럼의 length 160 초과하면 나눠서 보낸다. 3바이트로 계산
				Iterable<String> ite = Splitter.fixedLength(52).split(param.getTrMsg());
				String[] eachMsg = Iterables.toArray(ite, String.class);
				for(String msg : eachMsg ) {
					SmsVO vo = param;
					vo.setTrMsg(msg);
					smsDao.createSms(param);
				}
			}
//		}
	}

}
