package com.lgmma.salesPortal.app.model;


public class StatisticsOrderVO extends PagingParamVO {

	//조회조건
	private String qryType;
	private String sdate;
	private String edate;
	
	//리스트
	private String strProcStat;
	private String strProcStatName;
	private String strM01;      
	private String strM02;      
	private String strM03;      
	private String strM04;      
	private String strM05;      
	private String strM06;      
	private String strM07;      
	private String strM08;      
	private String strM09;      
	private String strM10;      
	private String strM11;      
	private String strM12;      
	private String strTotal;
	
	//뷰
	private String strTeamName;
	private String strSawnName;
	private String strTeamCnt;
	private String strCnt;
	private String strRespTime;
	private String strAvgTime;
	
	
	public String getStrTeamCnt() {
		return strTeamCnt;
	}
	public void setStrTeamCnt(String strTeamCnt) {
		this.strTeamCnt = strTeamCnt;
	}
	public String getStrTeamName() {
		return strTeamName;
	}
	public void setStrTeamName(String strTeamName) {
		this.strTeamName = strTeamName;
	}
	public String getStrSawnName() {
		return strSawnName;
	}
	public void setStrSawnName(String strSawnName) {
		this.strSawnName = strSawnName;
	}
	public String getStrCnt() {
		return strCnt;
	}
	public void setStrCnt(String strCnt) {
		this.strCnt = strCnt;
	}
	public String getStrRespTime() {
		return strRespTime;
	}
	public void setStrRespTime(String strRespTime) {
		this.strRespTime = strRespTime;
	}
	public String getStrAvgTime() {
		return strAvgTime;
	}
	public void setStrAvgTime(String strAvgTime) {
		this.strAvgTime = strAvgTime;
	}
	public String getQryType() {
		return qryType;
	}
	public void setQryType(String qryType) {
		this.qryType = qryType;
	}
	public String getSdate() {
		return sdate;
	}
	public void setSdate(String sdate) {
		this.sdate = sdate;
	}
	public String getEdate() {
		return edate;
	}
	public void setEdate(String edate) {
		this.edate = edate;
	}
	public String getStrProcStat() {
		return strProcStat;
	}
	public void setStrProcStat(String strProcStat) {
		this.strProcStat = strProcStat;
	}
	public String getStrProcStatName() {
		return strProcStatName;
	}
	public void setStrProcStatName(String strProcStatName) {
		this.strProcStatName = strProcStatName;
	}
	public String getStrM01() {
		return strM01;
	}
	public void setStrM01(String strM01) {
		this.strM01 = strM01;
	}
	public String getStrM02() {
		return strM02;
	}
	public void setStrM02(String strM02) {
		this.strM02 = strM02;
	}
	public String getStrM03() {
		return strM03;
	}
	public void setStrM03(String strM03) {
		this.strM03 = strM03;
	}
	public String getStrM04() {
		return strM04;
	}
	public void setStrM04(String strM04) {
		this.strM04 = strM04;
	}
	public String getStrM05() {
		return strM05;
	}
	public void setStrM05(String strM05) {
		this.strM05 = strM05;
	}
	public String getStrM06() {
		return strM06;
	}
	public void setStrM06(String strM06) {
		this.strM06 = strM06;
	}
	public String getStrM07() {
		return strM07;
	}
	public void setStrM07(String strM07) {
		this.strM07 = strM07;
	}
	public String getStrM08() {
		return strM08;
	}
	public void setStrM08(String strM08) {
		this.strM08 = strM08;
	}
	public String getStrM09() {
		return strM09;
	}
	public void setStrM09(String strM09) {
		this.strM09 = strM09;
	}
	public String getStrM10() {
		return strM10;
	}
	public void setStrM10(String strM10) {
		this.strM10 = strM10;
	}
	public String getStrM11() {
		return strM11;
	}
	public void setStrM11(String strM11) {
		this.strM11 = strM11;
	}
	public String getStrM12() {
		return strM12;
	}
	public void setStrM12(String strM12) {
		this.strM12 = strM12;
	}
	public String getStrTotal() {
		return strTotal;
	}
	public void setStrTotal(String strTotal) {
		this.strTotal = strTotal;
	}
	
	
}
