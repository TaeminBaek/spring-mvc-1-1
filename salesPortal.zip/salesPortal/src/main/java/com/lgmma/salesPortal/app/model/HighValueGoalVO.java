package com.lgmma.salesPortal.app.model;

import java.util.List;

public class HighValueGoalVO extends PagingParamVO {
	private String yyyy;
	private String vkorg;
	private String grupCode;
	private String highValue;
	private String highValueName;
	private String challengeGoal;
	private String bigo;
	
	//고부가 콤보
	//comboType(콤보 타입 구분) : 년도_영업조직코드 (eg. 2018_3000)
	//comboList : 콤보타입에 따른 고부가항목 리스트 데이터
	private String comboType;
	private List<HighValueGoalVO> comboList;
	
	//고부가 CG 실적
	private String qtySum;		// 누계 실적
	private String cgPercent;	// 진척률
	
	public String getYyyy() {
		return yyyy;
	}
	public void setYyyy(String yyyy) {
		this.yyyy = yyyy;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	
	public String getGrupCode() {
		return grupCode;
	}
	public void setGrupCode(String grupCode) {
		this.grupCode = grupCode;
	}
	public String getHighValue() {
		return highValue;
	}
	public void setHighValue(String highValue) {
		this.highValue = highValue;
	}
	public String getHighValueName() {
		return highValueName;
	}
	public void setHighValueName(String highValueName) {
		this.highValueName = highValueName;
	}
	public String getChallengeGoal() {
		return challengeGoal;
	}
	public void setChallengeGoal(String challengeGoal) {
		this.challengeGoal = challengeGoal;
	}
	public String getBigo() {
		return bigo;
	}
	public void setBigo(String bigo) {
		this.bigo = bigo;
	}
	public String getComboType() {
		return comboType;
	}
	public void setComboType(String comboType) {
		this.comboType = comboType;
	}
	public List<HighValueGoalVO> getComboList() {
		return comboList;
	}
	public void setComboList(List<HighValueGoalVO> comboList) {
		this.comboList = comboList;
	}
	public String getQtySum() {
		return qtySum;
	}
	public void setQtySum(String qtySum) {
		this.qtySum = qtySum;
	}
	public String getCgPercent() {
		return cgPercent;
	}
	public void setCgPercent(String cgPercent) {
		this.cgPercent = cgPercent;
	}
	
}
