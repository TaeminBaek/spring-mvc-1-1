package com.lgmma.salesPortal.app.model;

public class DisplayOrderLotVO extends PagingParamVO{
	
	//ZSDE02_DISPLAY_ORDER_LOT
	private String I_VBELN   ;   //판매오더
	private String E_RETURN  ;   //리턴메시지
	private String E_SUBRC   ;   //리턴코드
	
	private String vbeln     ;   //판매 문서
	private String posnr     ;   //판매 문서 품목
	private String vgbel     ;   //참조 문서의 문서 번호
	private String vgpos     ;   //참조품목의 품목번호
	private String matnr     ;   //자재 번호
	private String kwmeng    ;   //판매 단위의 누적 오더 수량
	private String lfimg     ;   //실제수량납품 (판매단위)
	private String charg     ;   //배치 번호
	private String meins     ;   //기본 단위

	public String getI_VBELN() {
		return I_VBELN;
	}
	public void setI_VBELN(String i_VBELN) {
		I_VBELN = i_VBELN;
	}
	public String getE_RETURN() {
		return E_RETURN;
	}
	public void setE_RETURN(String e_RETURN) {
		E_RETURN = e_RETURN;
	}
	public String getE_SUBRC() {
		return E_SUBRC;
	}
	public void setE_SUBRC(String e_SUBRC) {
		E_SUBRC = e_SUBRC;
	}
	public String getVbeln() {
		return vbeln;
	}
	public void setVbeln(String vbeln) {
		this.vbeln = vbeln;
	}
	public String getPosnr() {
		return posnr;
	}
	public void setPosnr(String posnr) {
		this.posnr = posnr;
	}
	public String getVgbel() {
		return vgbel;
	}
	public void setVgbel(String vgbel) {
		this.vgbel = vgbel;
	}
	public String getVgpos() {
		return vgpos;
	}
	public void setVgpos(String vgpos) {
		this.vgpos = vgpos;
	}
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getKwmeng() {
		return kwmeng;
	}
	public void setKwmeng(String kwmeng) {
		this.kwmeng = kwmeng;
	}
	public String getLfimg() {
		return lfimg;
	}
	public void setLfimg(String lfimg) {
		this.lfimg = lfimg;
	}
	public String getCharg() {
		return charg;
	}
	public void setCharg(String charg) {
		this.charg = charg;
	}
	public String getMeins() {
		return meins;
	}
	public void setMeins(String meins) {
		this.meins = meins;
	}
	
	

}
