package com.lgmma.salesPortal.app.model;

public class DissRecipeVO extends PagingParamVO {

	//TB_D_RECIPE
	private String  recipeId;			// 처방ID
	private String  taskId;              // 과제ID
	private String  taskType;            // 과제구분
	private Integer recipeNo;            // 처방번호
	private String  recipeTxt;           // 처방내용
	private String  recipeEmpId;         // 처방등록자
	private String  fileId;              // 첨부파일
	private String  useYn;               // 사용여부
	//조회
	private String  regiYmd;				// 처방등록일
	private String  stepId;				// 스텝ID
	private String  recipeEmpNm;			//처방담당자명
	private String  recipeEmpTeamName;		//처방담당자팀코드명
	private String  recipeEmpPosiName;		//처방담당자직위코드명
	
	public String getRecipeId() {
		return recipeId;
	}
	public void setRecipeId(String recipeId) {
		this.recipeId = recipeId;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public Integer getRecipeNo() {
		return recipeNo;
	}
	public void setRecipeNo(Integer recipeNo) {
		this.recipeNo = recipeNo;
	}
	public String getRecipeTxt() {
		return recipeTxt;
	}
	public void setRecipeTxt(String recipeTxt) {
		this.recipeTxt = recipeTxt;
	}
	public String getRecipeEmpId() {
		return recipeEmpId;
	}
	public void setRecipeEmpId(String recipeEmpId) {
		this.recipeEmpId = recipeEmpId;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getRegiYmd() {
		return regiYmd;
	}
	public void setRegiYmd(String regiYmd) {
		this.regiYmd = regiYmd;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getRecipeEmpNm() {
		return recipeEmpNm;
	}
	public void setRecipeEmpNm(String recipeEmpNm) {
		this.recipeEmpNm = recipeEmpNm;
	}
	public String getRecipeEmpTeamName() {
		return recipeEmpTeamName;
	}
	public void setRecipeEmpTeamName(String recipeEmpTeamName) {
		this.recipeEmpTeamName = recipeEmpTeamName;
	}
	public String getRecipeEmpPosiName() {
		return recipeEmpPosiName;
	}
	public void setRecipeEmpPosiName(String recipeEmpPosiName) {
		this.recipeEmpPosiName = recipeEmpPosiName;
	}
	
}
