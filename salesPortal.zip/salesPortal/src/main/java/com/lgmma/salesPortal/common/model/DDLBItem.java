package com.lgmma.salesPortal.common.model;

public class DDLBItem {

	private String code;
	private String text;
	private String codeNum2;
	private boolean selected;
	public DDLBItem() {
	}
	public DDLBItem(String code, String text) {
		super();
		this.code = code;
		this.text = text;
	}
	public DDLBItem(String code, String text, boolean selected) {
		super();
		this.code = code;
		this.text = text;
		this.selected = selected;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getCodeNum2() {
		return codeNum2;
	}
	public void setCodeNum2(String codeNum2) {
		this.codeNum2 = codeNum2;
	}
	public boolean isSelected() {
		return selected;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
}
