package com.lgmma.salesPortal.security.authentication;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;

public class CustomLoginUrlAuthenticationEntryPoint extends LoginUrlAuthenticationEntryPoint {

    @Autowired
    private MessageSourceAccessor messageSourceAccessor;
    
	public CustomLoginUrlAuthenticationEntryPoint(String loginFormUrl) {
		super(loginFormUrl);
	}

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
		response.setContentType("text/html; charset=UTF-8");
		response.setStatus(HttpStatus.UNAUTHORIZED.value());
		boolean ajaxFlag = false;
		if( "XMLHttpRequest".equals(request.getHeader("x-requested-with")) ) {
			ajaxFlag = true;
		}
		if(ajaxFlag) {
			// 세션 종료메시지는 common.js ajaxSetup() 에서 보여준다. 
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
//			response.getWriter().write("{\"message\":\""+messageSourceAccessor.getMessage("fail.common.session.expired")+"\", \"code\":\"OK\", \"success\":false}");
//			response.getWriter().flush();
//			response.getWriter().close();
		} else {
			response.getWriter().write("<script language='javascript' type='text/javascript'>alert('" + messageSourceAccessor.getMessage("fail.common.session.expired") + "');self.opener=self;window.close();</script>");
			response.getWriter().flush();
			response.getWriter().close();
		}
	}
}
