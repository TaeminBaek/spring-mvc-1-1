package com.lgmma.salesPortal.app.model;

public class DissDailyVO extends PagingParamVO {
	private String dailyActId;
	private String custCode;
	private String custName;
	private String taskId;
	private String taskType;
	private String regiCustYn;
	private String actType;
	private String custCtqYn;
	private String custCtqItem01;
	private String custCtqItem02;
	private String custCtqItem03;
	private String custCtqItem04;
	private String custCtqItem05;
	private String custCtqItem06;
	private String custCtqItem07;
	private String custCtqItem08;
	private String devItemYn;
	private String devItem01;
	private String devItem02;
	private String devItem03;
	private String devItem04;
	private String devItem05;
	private String devItem06;
	private String devItem07;
	private String curUseItemYn;
	private String curUseItem01;
	private String curUseItem02;
	private String curUseItem03;
	private String curUseItem04;
	private String curUseItem05;
	private String checkItemScheduleYn;
	private String checkItemSchedule01;
	private String checkItemSchedule02;
	private String checkItemSchedule03;
	private String checkItemSchedule04;
	private String checkItemSchedule05;
	private String checkItemSchedule06;
	private String etcComment;
	private String title;
	private String apprId;
	private String actYmd;
	private String companionNm1;
	private String companionId1;
	private String companionTeamNm1;
	private String companionTeamId1;
	private String companionNm2;
	private String companionId2;
	private String companionTeamNm2;
	private String companionTeamId2;
	private String companionNm3;
	private String companionId3;
	private String companionTeamNm3;
	private String companionTeamId3;
	private String painPointYn;
	private String painPoint;
	private String painPointNm;
	private String painPointTeamCheck;
	private String painPointTeam;
	
	//품의
	private ApprVO apprVO;
	private String apprFormCont;
	
	//search condition
	private String scCustName;
	private String scTaskId;
	private String scRegiName;
	private String scActType;
	private String scMeetingType;
	private String scFrRegiYmd;
	private String scToRegiYmd;
	private String scTitle;
	private String scFrActYmd;
	private String scToActYmd;
	
	//display column
	private String taskName;
	private String actTypeNm;
	private String meetingTypeNm;
	private String actYmdFmt;
	private String regiName;
	private String regiDateFmt;
	private String apprStat;
	private String kunnr;
	
	//통계
	private String scYyyy;        // 집계년도
    private String teamName;      // 팀명
    private String devLevelName;  // 개발등급명
    private String empCnt;        // 대상인원
    private String mm01Cnt;
    private String mm02Cnt;
    private String mm03Cnt;
    private String mm04Cnt;
    private String mm05Cnt;
    private String mm06Cnt;
    private String mm07Cnt;
    private String mm08Cnt;
    private String mm09Cnt;
    private String mm10Cnt;
    private String mm11Cnt;
    private String mm12Cnt;
    private String totCnt;
    private String mm01Per;
    private String mm02Per;
    private String mm03Per;
    private String mm04Per;
    private String mm05Per;
    private String mm06Per;
    private String mm07Per;
    private String mm08Per;
    private String mm09Per;
    private String mm10Per;
    private String mm11Per;
    private String mm12Per;
    private String totPer;
	
	public String getDailyActId() {
		return dailyActId;
	}
	public void setDailyActId(String dailyActId) {
		this.dailyActId = dailyActId;
	}
	public String getCustCode() {
		return custCode;
	}
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getRegiCustYn() {
		return regiCustYn;
	}
	public void setRegiCustYn(String regiCustYn) {
		this.regiCustYn = regiCustYn;
	}
	public String getActType() {
		return actType;
	}
	public void setActType(String actType) {
		this.actType = actType;
	}
	public String getCustCtqYn() {
		return custCtqYn;
	}
	public void setCustCtqYn(String custCtqYn) {
		this.custCtqYn = custCtqYn;
	}
	public String getCustCtqItem01() {
		return custCtqItem01;
	}
	public void setCustCtqItem01(String custCtqItem01) {
		this.custCtqItem01 = custCtqItem01;
	}
	public String getCustCtqItem02() {
		return custCtqItem02;
	}
	public void setCustCtqItem02(String custCtqItem02) {
		this.custCtqItem02 = custCtqItem02;
	}
	public String getCustCtqItem03() {
		return custCtqItem03;
	}
	public void setCustCtqItem03(String custCtqItem03) {
		this.custCtqItem03 = custCtqItem03;
	}
	public String getCustCtqItem04() {
		return custCtqItem04;
	}
	public void setCustCtqItem04(String custCtqItem04) {
		this.custCtqItem04 = custCtqItem04;
	}
	public String getCustCtqItem05() {
		return custCtqItem05;
	}
	public void setCustCtqItem05(String custCtqItem05) {
		this.custCtqItem05 = custCtqItem05;
	}
	public String getCustCtqItem06() {
		return custCtqItem06;
	}
	public void setCustCtqItem06(String custCtqItem06) {
		this.custCtqItem06 = custCtqItem06;
	}
	public String getCustCtqItem07() {
		return custCtqItem07;
	}
	public void setCustCtqItem07(String custCtqItem07) {
		this.custCtqItem07 = custCtqItem07;
	}
	public String getCustCtqItem08() {
		return custCtqItem08;
	}
	public void setCustCtqItem08(String custCtqItem08) {
		this.custCtqItem08 = custCtqItem08;
	}
	public String getDevItemYn() {
		return devItemYn;
	}
	public void setDevItemYn(String devItemYn) {
		this.devItemYn = devItemYn;
	}
	public String getDevItem01() {
		return devItem01;
	}
	public void setDevItem01(String devItem01) {
		this.devItem01 = devItem01;
	}
	public String getDevItem02() {
		return devItem02;
	}
	public void setDevItem02(String devItem02) {
		this.devItem02 = devItem02;
	}
	public String getDevItem03() {
		return devItem03;
	}
	public void setDevItem03(String devItem03) {
		this.devItem03 = devItem03;
	}
	public String getDevItem04() {
		return devItem04;
	}
	public void setDevItem04(String devItem04) {
		this.devItem04 = devItem04;
	}
	public String getDevItem05() {
		return devItem05;
	}
	public void setDevItem05(String devItem05) {
		this.devItem05 = devItem05;
	}
	public String getDevItem06() {
		return devItem06;
	}
	public void setDevItem06(String devItem06) {
		this.devItem06 = devItem06;
	}
	public String getDevItem07() {
		return devItem07;
	}
	public void setDevItem07(String devItem07) {
		this.devItem07 = devItem07;
	}
	public String getCurUseItemYn() {
		return curUseItemYn;
	}
	public void setCurUseItemYn(String curUseItemYn) {
		this.curUseItemYn = curUseItemYn;
	}
	public String getCurUseItem01() {
		return curUseItem01;
	}
	public void setCurUseItem01(String curUseItem01) {
		this.curUseItem01 = curUseItem01;
	}
	public String getCurUseItem02() {
		return curUseItem02;
	}
	public void setCurUseItem02(String curUseItem02) {
		this.curUseItem02 = curUseItem02;
	}
	public String getCurUseItem03() {
		return curUseItem03;
	}
	public void setCurUseItem03(String curUseItem03) {
		this.curUseItem03 = curUseItem03;
	}
	public String getCurUseItem04() {
		return curUseItem04;
	}
	public void setCurUseItem04(String curUseItem04) {
		this.curUseItem04 = curUseItem04;
	}
	public String getCurUseItem05() {
		return curUseItem05;
	}
	public void setCurUseItem05(String curUseItem05) {
		this.curUseItem05 = curUseItem05;
	}
	public String getCheckItemScheduleYn() {
		return checkItemScheduleYn;
	}
	public void setCheckItemScheduleYn(String checkItemScheduleYn) {
		this.checkItemScheduleYn = checkItemScheduleYn;
	}
	public String getCheckItemSchedule01() {
		return checkItemSchedule01;
	}
	public void setCheckItemSchedule01(String checkItemSchedule01) {
		this.checkItemSchedule01 = checkItemSchedule01;
	}
	public String getCheckItemSchedule02() {
		return checkItemSchedule02;
	}
	public void setCheckItemSchedule02(String checkItemSchedule02) {
		this.checkItemSchedule02 = checkItemSchedule02;
	}
	public String getCheckItemSchedule03() {
		return checkItemSchedule03;
	}
	public void setCheckItemSchedule03(String checkItemSchedule03) {
		this.checkItemSchedule03 = checkItemSchedule03;
	}
	public String getCheckItemSchedule04() {
		return checkItemSchedule04;
	}
	public void setCheckItemSchedule04(String checkItemSchedule04) {
		this.checkItemSchedule04 = checkItemSchedule04;
	}
	public String getCheckItemSchedule05() {
		return checkItemSchedule05;
	}
	public void setCheckItemSchedule05(String checkItemSchedule05) {
		this.checkItemSchedule05 = checkItemSchedule05;
	}
	public String getCheckItemSchedule06() {
		return checkItemSchedule06;
	}
	public void setCheckItemSchedule06(String checkItemSchedule06) {
		this.checkItemSchedule06 = checkItemSchedule06;
	}
	public String getEtcComment() {
		return etcComment;
	}
	public void setEtcComment(String etcComment) {
		this.etcComment = etcComment;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getActYmd() {
		return actYmd;
	}
	public void setActYmd(String actYmd) {
		this.actYmd = actYmd;
	}
	public String getCompanionNm1() {
		return companionNm1;
	}
	public void setCompanionNm1(String companionNm1) {
		this.companionNm1 = companionNm1;
	}
	public String getCompanionId1() {
		return companionId1;
	}
	public void setCompanionId1(String companionId1) {
		this.companionId1 = companionId1;
	}
	public String getCompanionTeamNm1() {
		return companionTeamNm1;
	}
	public void setCompanionTeamNm1(String companionTeamNm1) {
		this.companionTeamNm1 = companionTeamNm1;
	}
	public String getCompanionTeamId1() {
		return companionTeamId1;
	}
	public void setCompanionTeamId1(String companionTeamId1) {
		this.companionTeamId1 = companionTeamId1;
	}
	public String getCompanionNm2() {
		return companionNm2;
	}
	public void setCompanionNm2(String companionNm2) {
		this.companionNm2 = companionNm2;
	}
	public String getCompanionId2() {
		return companionId2;
	}
	public void setCompanionId2(String companionId2) {
		this.companionId2 = companionId2;
	}
	public String getCompanionTeamNm2() {
		return companionTeamNm2;
	}
	public void setCompanionTeamNm2(String companionTeamNm2) {
		this.companionTeamNm2 = companionTeamNm2;
	}
	public String getCompanionTeamId2() {
		return companionTeamId2;
	}
	public void setCompanionTeamId2(String companionTeamId2) {
		this.companionTeamId2 = companionTeamId2;
	}
	public String getCompanionNm3() {
		return companionNm3;
	}
	public void setCompanionNm3(String companionNm3) {
		this.companionNm3 = companionNm3;
	}
	public String getCompanionId3() {
		return companionId3;
	}
	public void setCompanionId3(String companionId3) {
		this.companionId3 = companionId3;
	}
	public String getCompanionTeamNm3() {
		return companionTeamNm3;
	}
	public void setCompanionTeamNm3(String companionTeamNm3) {
		this.companionTeamNm3 = companionTeamNm3;
	}
	public String getCompanionTeamId3() {
		return companionTeamId3;
	}
	public void setCompanionTeamId3(String companionTeamId3) {
		this.companionTeamId3 = companionTeamId3;
	}
	public ApprVO getApprVO() {
		return apprVO;
	}
	public void setApprVO(ApprVO apprVO) {
		this.apprVO = apprVO;
	}
	public String getApprFormCont() {
		return apprFormCont;
	}
	public void setApprFormCont(String apprFormCont) {
		this.apprFormCont = apprFormCont;
	}
	public String getScCustName() {
		return scCustName;
	}
	public void setScCustName(String scCustName) {
		this.scCustName = scCustName;
	}
	public String getScTaskId() {
		return scTaskId;
	}
	public void setScTaskId(String scTaskId) {
		this.scTaskId = scTaskId;
	}
	public String getScRegiName() {
		return scRegiName;
	}
	public void setScRegiName(String scRegiName) {
		this.scRegiName = scRegiName;
	}
	public String getScActType() {
		return scActType;
	}
	public void setScActType(String scActType) {
		this.scActType = scActType;
	}
	public String getScMeetingType() {
		return scMeetingType;
	}
	public void setScMeetingType(String scMeetingType) {
		this.scMeetingType = scMeetingType;
	}
	public String getScFrRegiYmd() {
		return scFrRegiYmd;
	}
	public void setScFrRegiYmd(String scFrRegiYmd) {
		this.scFrRegiYmd = scFrRegiYmd;
	}
	public String getScToRegiYmd() {
		return scToRegiYmd;
	}
	public void setScToRegiYmd(String scToRegiYmd) {
		this.scToRegiYmd = scToRegiYmd;
	}
	public String getScTitle() {
		return scTitle;
	}
	public void setScTitle(String scTitle) {
		this.scTitle = scTitle;
	}
	public String getScFrActYmd() {
		return scFrActYmd;
	}
	public void setScFrActYmd(String scFrActYmd) {
		this.scFrActYmd = scFrActYmd;
	}
	public String getScToActYmd() {
		return scToActYmd;
	}
	public void setScToActYmd(String scToActYmd) {
		this.scToActYmd = scToActYmd;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getActTypeNm() {
		return actTypeNm;
	}
	public void setActTypeNm(String actTypeNm) {
		this.actTypeNm = actTypeNm;
	}
	public String getMeetingTypeNm() {
		return meetingTypeNm;
	}
	public void setMeetingTypeNm(String meetingTypeNm) {
		this.meetingTypeNm = meetingTypeNm;
	}
	public String getActYmdFmt() {
		return actYmdFmt;
	}
	public void setActYmdFmt(String actYmdFmt) {
		this.actYmdFmt = actYmdFmt;
	}
	public String getRegiName() {
		return regiName;
	}
	public void setRegiName(String regiName) {
		this.regiName = regiName;
	}
	public String getRegiDateFmt() {
		return regiDateFmt;
	}
	public void setRegiDateFmt(String regiDateFmt) {
		this.regiDateFmt = regiDateFmt;
	}
	public String getApprStat() {
		return apprStat;
	}
	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getScYyyy() {
		return scYyyy;
	}
	public void setScYyyy(String scYyyy) {
		this.scYyyy = scYyyy;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getEmpCnt() {
		return empCnt;
	}
	public void setEmpCnt(String empCnt) {
		this.empCnt = empCnt;
	}
	public String getMm01Cnt() {
		return mm01Cnt;
	}
	public void setMm01Cnt(String mm01Cnt) {
		this.mm01Cnt = mm01Cnt;
	}
	public String getMm02Cnt() {
		return mm02Cnt;
	}
	public void setMm02Cnt(String mm02Cnt) {
		this.mm02Cnt = mm02Cnt;
	}
	public String getMm03Cnt() {
		return mm03Cnt;
	}
	public void setMm03Cnt(String mm03Cnt) {
		this.mm03Cnt = mm03Cnt;
	}
	public String getMm04Cnt() {
		return mm04Cnt;
	}
	public void setMm04Cnt(String mm04Cnt) {
		this.mm04Cnt = mm04Cnt;
	}
	public String getMm05Cnt() {
		return mm05Cnt;
	}
	public void setMm05Cnt(String mm05Cnt) {
		this.mm05Cnt = mm05Cnt;
	}
	public String getMm06Cnt() {
		return mm06Cnt;
	}
	public void setMm06Cnt(String mm06Cnt) {
		this.mm06Cnt = mm06Cnt;
	}
	public String getMm07Cnt() {
		return mm07Cnt;
	}
	public void setMm07Cnt(String mm07Cnt) {
		this.mm07Cnt = mm07Cnt;
	}
	public String getMm08Cnt() {
		return mm08Cnt;
	}
	public void setMm08Cnt(String mm08Cnt) {
		this.mm08Cnt = mm08Cnt;
	}
	public String getMm09Cnt() {
		return mm09Cnt;
	}
	public void setMm09Cnt(String mm09Cnt) {
		this.mm09Cnt = mm09Cnt;
	}
	public String getMm10Cnt() {
		return mm10Cnt;
	}
	public void setMm10Cnt(String mm10Cnt) {
		this.mm10Cnt = mm10Cnt;
	}
	public String getMm11Cnt() {
		return mm11Cnt;
	}
	public void setMm11Cnt(String mm11Cnt) {
		this.mm11Cnt = mm11Cnt;
	}
	public String getMm12Cnt() {
		return mm12Cnt;
	}
	public void setMm12Cnt(String mm12Cnt) {
		this.mm12Cnt = mm12Cnt;
	}
	public String getTotCnt() {
		return totCnt;
	}
	public void setTotCnt(String totCnt) {
		this.totCnt = totCnt;
	}
	public String getMm01Per() {
		return mm01Per;
	}
	public void setMm01Per(String mm01Per) {
		this.mm01Per = mm01Per;
	}
	public String getMm02Per() {
		return mm02Per;
	}
	public void setMm02Per(String mm02Per) {
		this.mm02Per = mm02Per;
	}
	public String getMm03Per() {
		return mm03Per;
	}
	public void setMm03Per(String mm03Per) {
		this.mm03Per = mm03Per;
	}
	public String getMm04Per() {
		return mm04Per;
	}
	public void setMm04Per(String mm04Per) {
		this.mm04Per = mm04Per;
	}
	public String getMm05Per() {
		return mm05Per;
	}
	public void setMm05Per(String mm05Per) {
		this.mm05Per = mm05Per;
	}
	public String getMm06Per() {
		return mm06Per;
	}
	public void setMm06Per(String mm06Per) {
		this.mm06Per = mm06Per;
	}
	public String getMm07Per() {
		return mm07Per;
	}
	public void setMm07Per(String mm07Per) {
		this.mm07Per = mm07Per;
	}
	public String getMm08Per() {
		return mm08Per;
	}
	public void setMm08Per(String mm08Per) {
		this.mm08Per = mm08Per;
	}
	public String getMm09Per() {
		return mm09Per;
	}
	public void setMm09Per(String mm09Per) {
		this.mm09Per = mm09Per;
	}
	public String getMm10Per() {
		return mm10Per;
	}
	public void setMm10Per(String mm10Per) {
		this.mm10Per = mm10Per;
	}
	public String getMm11Per() {
		return mm11Per;
	}
	public void setMm11Per(String mm11Per) {
		this.mm11Per = mm11Per;
	}
	public String getMm12Per() {
		return mm12Per;
	}
	public void setMm12Per(String mm12Per) {
		this.mm12Per = mm12Per;
	}
	public String getTotPer() {
		return totPer;
	}
	public void setTotPer(String totPer) {
		this.totPer = totPer;
	}
	public String getDevLevelName() {
		return devLevelName;
	}
	public void setDevLevelName(String devLevelName) {
		this.devLevelName = devLevelName;
	}
	public String getPainPointYn() {
		return painPointYn;
	}
	public void setPainPointYn(String painPointYn) {
		this.painPointYn = painPointYn;
	}
	public String getPainPoint() {
		return painPoint;
	}
	public void setPainPoint(String painPoint) {
		this.painPoint = painPoint;
	}
	public String getPainPointNm() {
		return painPointNm;
	}
	public void setPainPointNm(String painPointNm) {
		this.painPointNm = painPointNm;
	}
	public String getPainPointTeam() {
		return painPointTeam;
	}
	public void setPainPointTeam(String painPointTeam) {
		this.painPointTeam = painPointTeam;
	}
	public String getPainPointTeamCheck() {
		return painPointTeamCheck;
	}
	public void setPainPointTeamCheck(String painPointTeamCheck) {
		this.painPointTeamCheck = painPointTeamCheck;
	}
}
