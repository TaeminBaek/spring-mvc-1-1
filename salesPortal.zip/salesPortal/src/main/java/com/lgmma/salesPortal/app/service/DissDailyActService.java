package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissDailyVO;

public interface DissDailyActService {
	
	void saveDissDailyAct(DissDailyVO param);
	
	void createDissDailyAct(DissDailyVO param);
	
	int getDissDailyActListCount(DissDailyVO param);
	
	List<DissDailyVO> getDissDailyActList(DissDailyVO param);

	DissDailyVO getDissDailyActInfo(DissDailyVO param);
	
	DissDailyVO getDissDailyActDetail(DissDailyVO param);

	DissDailyVO getDissDailyActDetailLast(DissDailyVO param);

	void updateDissDailyAct(DissDailyVO param);
	
	void deleteDissDailyAct(DissDailyVO param);
	
	void saveDissDailyActApprovalAction(DissApprCommonParamVO param);
	
	List<DissDailyVO> getDissDailyActStatList(DissDailyVO param);

	List<DissDailyVO> getDissDailyActListExcelDownload(DissDailyVO param);

	List<DissDailyVO> getDissDailyActStatInfoExcelDownload(DissDailyVO param);

	List<DissDailyVO> getDissDailyActStatInfoExcelDownload2(DissDailyVO param);
	
	String getApprFormContDailyAct(DissDailyVO param, String templeteFormContent);
}
