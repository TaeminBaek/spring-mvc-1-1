package com.lgmma.salesPortal.app.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.dao.LoginDao;
import com.lgmma.salesPortal.app.model.CompCreditVO;
import com.lgmma.salesPortal.app.model.CompDamboVO;
import com.lgmma.salesPortal.app.model.CompEtcSaleYearVO;
import com.lgmma.salesPortal.app.model.CompOrganEditVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.GenVocVO;
import com.lgmma.salesPortal.app.model.NewCompOrganEditVO;
import com.lgmma.salesPortal.app.model.OrganVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.service.CompanyService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.util.NiceXMLParser;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.UserInfo;

@Transactional
@Service
public class CompanyServiceImpl implements CompanyService {
	
	private final String FNC_SAP_DAMBO_CONFIRM = "ZSDE01_SECURITY_CHANGE";
	private final String FNC_SAP_CUSTOMER_CHANGE2 = "ZSDE01_CUSTOMER_CHANGE2";

	private static Logger logger = LoggerFactory.getLogger(CompanyServiceImpl.class); 

	@Autowired
	private CompanyDao companyDao;
	
	@Autowired
	private LoginDao loginDao;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	@Autowired
	private MailingService mailingService;
	
	@Autowired
	private JcoConnector jcoConnector;
	
	@Autowired
	private NiceXMLParser niceXMLParser;
	
	@Override
	public int getCompanyCount(CompanyVO param) {
		return companyDao.getCompanyCount(param);
	}

	@Override
	public List<CompanyVO> getCompanyList(CompanyVO param) {
		return companyDao.getCompanyList(param);
	}

	@Override
	public CompanyVO getCompanyDetail(CompanyVO param) {
		return companyDao.getCompanyDetail(param);
	}
	
	@Override
	public OrganVO getCompanyEtc(OrganVO param) {
		OrganVO organVO = companyDao.getCompanyEtc(param);
		if(organVO != null)
			organVO.setEtcSaleYearList(companyDao.getCompanyEtcSaleYearList(param));
		
		return organVO;
	}
	
	@Override
	public int getCompanyEtcKunnrCount(OrganVO param) {
		return companyDao.getCompanyEtcKunnrCount(param);
	}
	
	@Override
	public void saveCompanyEtc(OrganVO param) {
		CompanyVO companyVO = new CompanyVO();
		companyVO.setCompCode(param.getCompCode());
		companyVO.setVkorg(param.getVkorg());
		//null point exception 방지
		companyVO = (CompanyVO) StringUtil.nullToEmptyString(companyDao.getCompanyDetail(companyVO));

		OrganVO organVo = (OrganVO) StringUtil.nullToEmptyString(companyDao.getCompanyEtc(param));
		
		//영업사원 변경시 sap 전송
		if(!organVo.getSaleMan1().equals(param.getSaleMan1()) && organVo.getErpxSend().equals("S")) {
			JcoTableParam organTableParam = new JcoTableParam();
			Map<String, Object> outputParams = new HashMap<String, Object>();
			Map<String, Object> organ = new HashMap<String, Object>();
            organ = new HashMap();
            organ.put("PARTN_NUMB", companyVO.getKunnr());   // 고객번호
            organ.put("SALES_ORG", param.getVkorg());         // 판매조직
            organ.put("PERNR", StringUtils.leftPad(param.getSaleMan1(), 8, "0"));         // 영업사원
            organ.put("SALES_DIST", organVo.getBzirk());              // 판매구역
            organ.put("SALES_OFF", organVo.getVkbur());               // 사업장
            organ.put("SALES_GRP", organVo.getVkgrp());               // 영업그룹
            organ.put("CURRENCY", organVo.getWaers());                // 통화
            organ.put("CUST_GRP1", organVo.getKvgr1());               // 고객그룹 1
            organ.put("CUST_GRP2", organVo.getKvgr2());               // 고객그룹 2
            organ.put("CUST_GRP3", organVo.getKvgr3());               // 고객그룹 3
            organ.put("CUST_GRP4", organVo.getKvgr4());               // 고객그룹 4
            organ.put("CUST_GRP5", organVo.getKvgr5());               // 고객그룹 5
            organ.put("INCOTERMS1", "");                 // 인도조건 (파트 1)
            organ.put("INCOTERMS2", "");                 // 인도조건 (파트 2)
            organ.put("PMNTTRMS", "");                   // 지급조건키
            organ.put("ACCNT_ASGN", organVo.getKtgrd());              // 해당고객의 계정지정그룹
            organ.put("GRADE", companyVO.getCompGrade());
            organ.put("ZTERM", organVo.getMonyCond());                   //지급조건

            organTableParam.put("T_LIST", organ);					

			jcoConnector.executeFunction(FNC_SAP_CUSTOMER_CHANGE2, null, outputParams, organTableParam);			
            // 전송성공:0보다 큰 정수, 실패:-1, 사업자등록번호 중복:0
			String eReturn = outputParams.get("E_RETURN").toString().trim();
			int rtnCode = Integer.parseInt((outputParams.get("E_SUBRC")).toString());
			if(rtnCode > 0) {	//성공
				logger.debug(eReturn);
			} else {	//실패 rfc2
				logger.error(eReturn);
				ServiceException ex = new ServiceException();
				ex.setErrorMsg("ERP 담당자 변경시 오류가 발생하였습니다. : " + eReturn);
				throw ex;
			}
		}
		//회사_조직별 정보의 추가정보 수정	
		companyDao.updateEtc(param);
		// 영업조직 체크추가
		if(!param.getAddOrg().equals("")){
			companyDao.createEtcAddOrg(param);
		}
		//회사 년도별 매출 삭제
		companyDao.deleteEtcSaleYear(param);
		//회사 년도별 매출 등록
		for(CompEtcSaleYearVO etcSaleYearListVO : param.getEtcSaleYearList()){
			companyDao.createEtcSaleYear(etcSaleYearListVO);
		}
	}
	
	@Override
	public int getDamboCount(CompDamboVO param) {
		return companyDao.getDamboCount(param);
	}

	@Override
	public List<CompDamboVO> getDamboList(CompDamboVO param) {
		return companyDao.getDamboList(param);
	}
	
	@Override
	public void updateDambo(CompDamboVO param) {
		String history_msg = "";
		CompDamboVO compDamboVO = new CompDamboVO();
		compDamboVO.setCompDamboId(param.getCompDamboId());
		compDamboVO.setStart(0);
		compDamboVO.setPageSize(1);
		compDamboVO = companyDao.getDamboList(compDamboVO).get(0);
		
		if(!StringUtil.isNullToString(compDamboVO.getCustGubun()).equals(param.getCustGubun())){
            if(!history_msg.equals("")){history_msg += "\r\n";}
            history_msg += "업체구분 수정";
        }
        if(!StringUtil.isNullToString(compDamboVO.getVkorg()).equals(param.getVkorg())){
            if(!history_msg.equals("")){history_msg += "\r\n";}
            history_msg += "제품군 수정";
        }
        if(!StringUtil.isNullToString(compDamboVO.getDambo()).equals(param.getDambo())){
            if(!history_msg.equals("")){history_msg += "\r\n";}
            history_msg += "설정액 수정";
        }
        if(!StringUtil.isNullToString(compDamboVO.getTitle()).equals(param.getTitle())){
            if(!history_msg.equals("")){history_msg += "\r\n";}
            history_msg += "담보내역 수정";
        }
        if(!StringUtil.isNullToString(compDamboVO.getUseYn()).equals(param.getUseYn())){
            if(!history_msg.equals("")){history_msg += "\r\n";}
            history_msg += "사용여부 수정";
        }
        if(!StringUtil.isNullToString(compDamboVO.getStartDate()).equals(param.getStartDate())){
            if(!history_msg.equals("")){history_msg += "\r\n";}
            history_msg += "설정일 수정";
        }
        if(!StringUtil.isNullToString(compDamboVO.getEndDate()).equals(param.getEndDate())){
            if(!history_msg.equals("")){history_msg += "\r\n";}
            history_msg += "만기일 수정";
        }
        
        param.setHistoryMsg(history_msg);
        param.setCfnYn("N");
		companyDao.updateDambo(param);
		companyDao.createDamboHistory(param);
		
		//담보 담당자
		List<UserInfo> creditEmpList = loginDao.getCreditEmpUserInfo("");
		for(UserInfo creditEmp : creditEmpList) {
			Map<String, String> paramMap = new HashMap<String, String>();
			paramMap.put("history_msg", history_msg);
			paramMap.put("NAME1", param.getName1());
			paramMap.put("TITEL", param.getTitle());
			
	        SendMailVO sendMailVO = new SendMailVO();
			sendMailVO.setMailType(MailType.COMPANY_DAMBO_UPDATE_TO_CUSTOMER);
			sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
			sendMailVO.setParams(paramMap);
			sendMailVO.setReceiverEmail(creditEmp.getMailAddr());
			mailingService.sendMail(sendMailVO);
		}
	}
	
	@Override
	public void createDambo(CompDamboVO param) {
		param.setCfnYn("N");
		
		param.setHistoryMsg("최초 등록");
		
		companyDao.createDambo(param);
		companyDao.createDamboHistory(param);
		
		//담보 담당자
		List<UserInfo> creditEmpList = loginDao.getCreditEmpUserInfo("");
		for(UserInfo creditEmp : creditEmpList) {
			Map<String, String> paramMap = new HashMap<String, String>();
			paramMap.put("NAME1", param.getName1());
			paramMap.put("TITEL", param.getTitle());
			
	        SendMailVO sendMailVO = new SendMailVO();
			sendMailVO.setMailType(MailType.COMPANY_DAMBO_CREATE_TO_CUSTOMER);
			sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
			sendMailVO.setParams(paramMap);
			sendMailVO.setReceiverEmail(creditEmp.getMailAddr());
			mailingService.sendMail(sendMailVO);
		}
	}
	
	@Override
	public void confirmDambo(CompDamboVO param) {
		String history_msg = "";
		CompDamboVO compDamboVO = new CompDamboVO();
		compDamboVO.setCompDamboId(param.getCompDamboId());
		compDamboVO.setStart(0);
		compDamboVO.setPageSize(1);
		compDamboVO = companyDao.getDamboList(compDamboVO).get(0);
        
		param.setCfnYn("Y");
		
		 if(!compDamboVO.getCfnYn().equals(param.getCfnYn())){
             if(!history_msg.equals("")){history_msg += "\r\n";}
             history_msg += "담보확인(확인자:"+param.getUpdtIdxx()+")";
         }
		
        param.setHistoryMsg(history_msg);
        
		companyDao.updateDambo(param);
		companyDao.createDamboHistory(param);
		
        Map<String, Object> inputParams = new HashMap<String, Object>();
		Map<String, Object> outputParams = new HashMap<String, Object>();
		JcoTableParam tableParam = new JcoTableParam();
        
		List<CompDamboVO> confirmList = companyDao.getConfirmDamboList(param);
        
		List<Map<String, Object>> itemList = new ArrayList<Map<String, Object>>();
        
        for(int i=0; i< confirmList.size(); i++){
			Map itemMap = new HashMap();
			
			itemMap = new HashMap();
			itemMap.put("VKORG", StringUtil.decode(confirmList.get(i).getVkorg(),"" ,"3000"));
			itemMap.put("KUNNR", confirmList.get(i).getKunnr());
			itemMap.put("GUAR_AMNT", confirmList.get(i).getGuarAmnt());
			itemMap.put("WAERS","KRW");
			
			itemList.add(itemMap);
        }
        tableParam.put("T_SECURITY",itemList);
        
        jcoConnector.executeFunction(FNC_SAP_DAMBO_CONFIRM, inputParams, tableParam);
        
        List<Map> resultList = (List<Map>) tableParam.get("T_SECURITY");
        String subrc = "";
        String msg = "";
        ServiceException se = new ServiceException();
        if(resultList.size() > 0) {
	        for(Map result : resultList) {
	        	subrc = StringUtil.nullConvert(result.get("SUBRC"));
				msg = StringUtil.nullConvert(result.get("MSG"));
	        }
	        
			if(subrc.equals("F")) {
				param.setCfnYn("N");
				param.setHistoryMsg(msg);
	        	companyDao.updateDambo(param);
	        	companyDao.createDamboHistory(param);
				se.setErrorMsg(msg.toString());
				throw se;
			}
			
			//담보 담당자
			List<UserInfo> creditEmpList = loginDao.getCreditEmpUserInfo("");
			for(UserInfo creditEmp : creditEmpList) {
				Map<String, String> paramMap = new HashMap<String, String>();
				paramMap.put("history_msg", history_msg);
				
		        SendMailVO sendMailVO = new SendMailVO();
				sendMailVO.setMailType(MailType.COMPANY_DAMBO_CONFIRM_TO_CUSTOMER);
				sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
				sendMailVO.setReceiverEmail(creditEmp.getMailAddr());
				sendMailVO.setParams(paramMap);
				mailingService.sendMail(sendMailVO);
			}
	    }else {
	    	param.setCfnYn("N");
			param.setHistoryMsg(msg);
        	companyDao.updateDambo(param);
        	companyDao.createDamboHistory(param);
			se.setErrorMsg(msg.toString());
			throw se;
	    }
	}
	
	@Override
	public int getCreditCount(CompCreditVO param) {
		return companyDao.getCreditCount(param);
	}

	@Override
	public List<CompCreditVO> getCreditList(CompCreditVO param) {
		return companyDao.getCreditList(param);
	}
	
	@Override
	public int getSampleDocCount(GenVocVO param) {
		return companyDao.getSampleDocCount(param);
	}

	@Override
	public List<GenVocVO> getSampleDocList(GenVocVO param) {
		return companyDao.getSampleDocList(param);
	}

	@Override
	public void createCredit(CompCreditVO param) {
		companyDao.createCredit(param);
	}

	@Override
	public Long getAddAmntSum(CompanyVO param) {
		return companyDao.getAddAmntSum(param);
	}

	@Override
	public void updateCredit(CompCreditVO param) {
		companyDao.updateCredit(param);
	}

	@Override
	public CompOrganEditVO updateCompBasic(CompOrganEditVO editVO) {
		editVO = (CompOrganEditVO) StringUtil.nullToEmptyString(editVO);
		editVO.setCompEditId(Util.getUUID());
		editVO.setApprType(ApprType.APPR_TYPE_MODIFY_CUST.getCode());
		CompanyVO newCompanyVO = new CompanyVO();
		newCompanyVO.setCompCode(editVO.getCompCode());
		newCompanyVO.setVkorg(editVO.getVkorg());

		newCompanyVO = (CompanyVO) StringUtil.nullToEmptyString(companyDao.getCompanyDetail(newCompanyVO));
		newCompanyVO.setOrganVO((OrganVO) StringUtil.nullToEmptyString(newCompanyVO.getOrganVO()));

		if(newCompanyVO.getOrganVO().getErpxSend().equals("")) {	//SAP 미등록 고객
			editVO.setApprReqYn("N");	//품의서 작성 필요 없음
			mergeCompanyVO(editVO, newCompanyVO);
			companyDao.createCompOrganEdit(editVO);
			companyDao.updateCompany(newCompanyVO);
			companyDao.updateOrgan(newCompanyVO.getOrganVO());
		} else {	//SAP 등록고객
			if(checkNeedErpTrans(newCompanyVO, editVO)) {	//SAP 전송이 필요한 경우 품의서를 작성케 한다.
				editVO.setApprReqYn("Y");	//품의서 작성 필요
				if(!editVO.getTelf1().equals("") && !editVO.getTelf2().equals("")) {
					editVO.setTelf1(editVO.getTelf1() + "-");
				}
				if(!editVO.getTelf2().equals("") && !editVO.getTelf3().equals("")) {
					editVO.setTelf2(editVO.getTelf2() + "-");
				}
				if(!editVO.getTelfx1().equals("") && !editVO.getTelfx2().equals("")) {
					editVO.setTelfx1(editVO.getTelfx1() + "-");
				}
				if(!editVO.getTelfx2().equals("") && !editVO.getTelfx3().equals("")) {
					editVO.setTelfx2(editVO.getTelfx2() + "-");
				}
				editVO.setTelf1Full(editVO.getTelf1() + editVO.getTelf2() + editVO.getTelf3());
				editVO.setTelfx(editVO.getTelfx1() + editVO.getTelfx2() + editVO.getTelfx3());
				companyDao.createCompOrganEdit(editVO);
			} else {
				editVO.setApprReqYn("N");	//품의서 작성 필요 없음
				mergeCompanyVO(editVO, newCompanyVO);
				companyDao.createCompOrganEdit(editVO);
				companyDao.updateCompany(newCompanyVO);
				companyDao.updateOrgan(newCompanyVO.getOrganVO());
			}
		}
		return editVO;
	}

	public void mergeCompanyVO(CompOrganEditVO editVO, CompanyVO newCompanyVO) {
		newCompanyVO.setVkorg(editVO.getVkorg());
		newCompanyVO.setCompCode(editVO.getCompCode());
		newCompanyVO.setName1(editVO.getName1());
		newCompanyVO.setJ1kfrepre(editVO.getJ1kfrepre());
		newCompanyVO.setStcd2(editVO.getStcd2());
		newCompanyVO.setCompGrade(editVO.getCompGrade());

		if(!editVO.getTelf1().equals("") && !editVO.getTelf2().equals("")) {
			editVO.setTelf1(editVO.getTelf1() + "-");
		}
		if(!editVO.getTelf2().equals("") && !editVO.getTelf3().equals("")) {
			editVO.setTelf2(editVO.getTelf2() + "-");
		}
		if(!editVO.getTelfx1().equals("") && !editVO.getTelfx2().equals("")) {
			editVO.setTelfx1(editVO.getTelfx1() + "-");
		}
		if(!editVO.getTelfx2().equals("") && !editVO.getTelfx3().equals("")) {
			editVO.setTelfx2(editVO.getTelfx2() + "-");
		}
		editVO.setTelf1Full(editVO.getTelf1() + editVO.getTelf2() + editVO.getTelf3());
		editVO.setTelfx(editVO.getTelfx1() + editVO.getTelfx2() + editVO.getTelfx3());
		newCompanyVO.setTelf1Full(editVO.getTelf1() + editVO.getTelf2() + editVO.getTelf3());
		newCompanyVO.setTelfx(editVO.getTelfx1() + editVO.getTelfx2() + editVO.getTelfx3());

		newCompanyVO.setPostlz(editVO.getPostlz());
		newCompanyVO.setStrasPre(editVO.getStrasPre());
		newCompanyVO.setStras(editVO.getStras());
		newCompanyVO.setPostlz2(editVO.getPostlz2());
		newCompanyVO.setStras2Pre(editVO.getStras2Pre());
		newCompanyVO.setStras2(editVO.getStras2());
		newCompanyVO.setUmsat(editVO.getUmsat());
		newCompanyVO.setJmzah(editVO.getJmzah());
		newCompanyVO.setMadeDate(editVO.getMadeDate());
		newCompanyVO.setHomePage(editVO.getHomePage());
		newCompanyVO.setCeoFullNm(editVO.getCeoFullNm());
		newCompanyVO.setCeoEtcNm(editVO.getCeoEtcNm());
		newCompanyVO.setUpdtIdxx(editVO.getUpdtIdxx());
		//국가, 운송지역도 수정가능
		newCompanyVO.setLand1(editVO.getLand1());
		newCompanyVO.setLzone(editVO.getLzone());
		//정도경영추가
		newCompanyVO.setCeoBirthday(editVO.getCeoBirthday());
		newCompanyVO.setStockYn    (editVO.getStockYn    ());
		newCompanyVO.setReportYn   (editVO.getReportYn   ());
		newCompanyVO.setReportType (editVO.getReportType ());
		newCompanyVO.setTradeItem  (editVO.getTradeItem  ());
		newCompanyVO.setRelationLg (editVO.getRelationLg ());

		newCompanyVO.getOrganVO().setKvgr1(editVO.getKvgr1());
		newCompanyVO.getOrganVO().setKvgr2(editVO.getKvgr2());
		newCompanyVO.getOrganVO().setKvgr3(editVO.getKvgr3());
		newCompanyVO.getOrganVO().setKvgr4(editVO.getKvgr4());
		newCompanyVO.getOrganVO().setKvgr5(editVO.getKvgr5());
		newCompanyVO.getOrganVO().setMonyCond(editVO.getMonyCond());
		newCompanyVO.getOrganVO().setBasiBigo(editVO.getBasiBigo());
		newCompanyVO.getOrganVO().setUpdtIdxx(editVO.getUpdtIdxx());
		newCompanyVO.getOrganVO().setFileId(editVO.getFileId());
		newCompanyVO.getOrganVO().setBzirk(editVO.getBzirk());
	}

	private boolean checkNeedErpTrans(CompanyVO companyVO, CompOrganEditVO editVO) {
	    if(!companyVO.getName1().equals(editVO.getName1())) return true;
	    if(!companyVO.getJ1kfrepre().equals(editVO.getJ1kfrepre())) return true;
	    if(!companyVO.getCeoFullNm().equals(editVO.getCeoFullNm())) return true;
	    if(!companyVO.getCeoEtcNm().equals(editVO.getCeoEtcNm())) return true;
	    if(!(companyVO.getTelf1() + companyVO.getTelf2() + companyVO.getTelf3()).equals(editVO.getTelf1() + editVO.getTelf2() + editVO.getTelf3())) return true;
	    if(!companyVO.getPostlz().equals(editVO.getPostlz())) return true;
	    if(!(companyVO.getStrasPre() + companyVO.getStras()).equals(editVO.getStrasPre() + editVO.getStras())) return true;
	    if(!companyVO.getOrganVO().getKvgr1().equals(editVO.getKvgr1())) return true;
	    if(!companyVO.getOrganVO().getKvgr2().equals(editVO.getKvgr2())) return true;
	    if(!companyVO.getOrganVO().getKvgr3().equals(editVO.getKvgr3())) return true;
	    if(!companyVO.getOrganVO().getKvgr4().equals(editVO.getKvgr4())) return true;
	    if(!companyVO.getOrganVO().getKvgr5().equals(editVO.getKvgr5())) return true;
	    if(!companyVO.getOrganVO().getMonyCond().equals(editVO.getMonyCond())) return true;
	    if(!companyVO.getOrganVO().getBzirk().equals(editVO.getBzirk())) return true;
	    //국가, 운송지역 수정가능하게 2019.01.15 김화실요청
	    if(!companyVO.getLand1().equals(editVO.getLand1())) return true;
	    if(!companyVO.getLzone().equals(editVO.getLzone())) return true;
	    //정도경영 추가항목에 대한 체크 추가
	    if(!companyVO.getCeoBirthday().equals(editVO.getCeoBirthday())) return true;
	    if(!companyVO.getReportYn   ().equals(editVO.getReportYn   ())) return true;
	    if(!companyVO.getReportType ().equals(editVO.getReportType ())) return true;
	    if(!companyVO.getStockYn    ().equals(editVO.getStockYn    ())) return true;
	    if(!companyVO.getRelationLg ().equals(editVO.getRelationLg ())) return true;

	    return false;
	}

	@Override
	public List<NewCompOrganEditVO> getCompOrganEditList(CompOrganEditVO param) {
		return companyDao.getCompOrganEditList(param);
	}

	@Override
	public void deleteCompOrganEdit(CompOrganEditVO param) {
		companyDao.deleteCompOrganEdit(param);
	}

	@Override
	public NewCompOrganEditVO createCompBasic(NewCompOrganEditVO editVO) {
		editVO.setCompEditId(Util.getUUID());
		editVO.setApprReqYn("Y");	//품의서 작성 필요
		editVO.setApprType(ApprType.APPR_TYPE_NEW_CUST.getCode());
		if(!editVO.getTelf1().equals("") && !editVO.getTelf2().equals("")) {
			editVO.setTelf1(editVO.getTelf1() + "-");
		}
		if(!editVO.getTelf2().equals("") && !editVO.getTelf3().equals("")) {
			editVO.setTelf2(editVO.getTelf2() + "-");
		}
		if(!editVO.getTelfx1().equals("") && !editVO.getTelfx2().equals("")) {
			editVO.setTelfx1(editVO.getTelfx1() + "-");
		}
		if(!editVO.getTelfx2().equals("") && !editVO.getTelfx3().equals("")) {
			editVO.setTelfx2(editVO.getTelfx2() + "-");
		}
		editVO.setTelf1Full(editVO.getTelf1() + editVO.getTelf2() + editVO.getTelf3());
		editVO.setTelfx(editVO.getTelfx1() + editVO.getTelfx2() + editVO.getTelfx3());

		companyDao.createNewCompOrganEdit(editVO);
		return editVO;
	}

	@Override
	public String getCompanyCreditGrade(String stcd) {
		/*
		String nodeNames[] = {};
		String kisGrade = "";
		HashMap tmpNode;
		try {
			tmpNode = niceXMLParser.readXml(nodeNames, StringUtil.remove(StringUtil.nullConvert(stcd), '-'));
			kisGrade = (String)tmpNode.get("KIS_GRADE");
		} catch (IOException e) {
			throw new ServiceException("fail.get.companygrade");
		}
		return exchangeValue(kisGrade);
		*/

		String kisGrade = companyDao.getCompanyCreditGrade(stcd);
		if(kisGrade == null)	throw new ServiceException("fail.get.companygrade");
		return exchangeValue(kisGrade);
	}

	@Override
	public String exchangeValue(String compGrade){
		String rtnVal = "";

		if(compGrade.equals("AAA")||compGrade.equals("AA+")||compGrade.equals("AA")||compGrade.equals("AA-")
		||compGrade.equals("AA0")){ // 기존 Nice 평가등급
			rtnVal = "A1";
		}else if(compGrade.equals("A+")||compGrade.equals("A")||compGrade.equals("A-")
		||compGrade.equals("A0")){ // 기존 Nice 평가등급
			rtnVal = "A2";
		}else if(compGrade.equals("BBB+")||compGrade.equals("BBB")||compGrade.equals("BBB-")||compGrade.equals("BB+")||compGrade.equals("BB")||compGrade.equals("BB-")
		||compGrade.equals("BBB0")||compGrade.equals("BB0")){ // 기존 Nice 평가등급
			rtnVal = "B";
		}else if(compGrade.equals("B+")||compGrade.equals("B")||compGrade.equals("B-")||compGrade.equals("CCC+")||compGrade.equals("CCC")||compGrade.equals("CCC-")
		||compGrade.equals("B0")||compGrade.equals("CCC0")){ // 기존 Nice 평가등급
			rtnVal = "C1";
		}else if(compGrade.equals("CC")||compGrade.equals("C")||compGrade.equals("D")
		||compGrade.equals("R1")||compGrade.equals("R2")||compGrade.equals("R3")||compGrade.equals("F1")||compGrade.equals("F2")// 나머지 등급
		||compGrade.equals("CC+")){ // 기존 Nice 평가등급
			rtnVal = "C2";
		}else if(compGrade.equals("NR")){
			rtnVal = "";
		}

		return rtnVal;
	}
	
	
	@Override
	public int getDamboItemListCount(CompDamboVO param) {
		return companyDao.getDamboItemListCount(param);
	}
}
