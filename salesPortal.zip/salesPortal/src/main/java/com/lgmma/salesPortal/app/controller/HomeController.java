package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.HighValueGoalVO;
import com.lgmma.salesPortal.app.model.IcisVO;
import com.lgmma.salesPortal.app.model.OrderListVO;
import com.lgmma.salesPortal.app.model.VocVO;
import com.lgmma.salesPortal.app.model.WorkStatVO;
import com.lgmma.salesPortal.app.service.HighValueMgmtService;
import com.lgmma.salesPortal.app.service.MsService;
import com.lgmma.salesPortal.app.service.OrderService;
import com.lgmma.salesPortal.app.service.VocMgmtService;
import com.lgmma.salesPortal.app.service.WorkStatMgmtService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.Util;

@Controller
public class HomeController {
	
	@Autowired
	OrderService orderService;
	
	@Autowired
	VocMgmtService vocMgmtService;
	
	@Autowired
	WorkStatMgmtService workStatMgmtService;
	
	@Autowired
	HighValueMgmtService highValueMgmtService;
	
	@Autowired
	MsService msService;
	
	@RequestMapping(value = "/home")
	public String homePage(ModelAndView mav) throws Exception {
		return "home";
	}

	//Home화면 미확정 주문 리스트
	@RequestMapping(value = "/getToBeConfirmOrderList.json")
	public Map getToBeConfirmOrderList(@RequestBody(required = false) OrderListVO param) throws Exception {
		String today = Util.getToday();
		String prevMonth = DateUtil.addMonth(Util.getToday(), -1);
		param.setSdate(prevMonth);
		param.setEdate(today);
		return JsonResponse.asSuccess("storeData", orderService.getOrderConfirmList(param));
	}
	
	//Home화면 고객서비스 리스트
	@RequestMapping(value = "/getHomeVocList.json")
	public Map getHomeVocList(@RequestBody(required = false) VocVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", vocMgmtService.getVocList(param));
	}
	
	//Home화면 매출
	@RequestMapping(value = "/getMonthlySalesStatList.json")
	public Map getMonthlySalesStatList(@RequestBody WorkStatVO param) throws Exception {
		List<List<WorkStatVO>> returnList = workStatMgmtService.getMonthlySalesStatList(param);
		
		List<WorkStatVO> makeSalesTicksList = new ArrayList<WorkStatVO>();
		
		for(int i=0; i<returnList.size(); i++) {
			for(int j=0; j<returnList.get(i).size(); j++) {
				makeSalesTicksList.add(returnList.get(i).get(j));
			}
		}
		
		Double[] ticksArr = workStatMgmtService.sortDataAndGetTicks("sales", makeSalesTicksList);
		return JsonResponse.asSuccess("storeData", returnList, "ticksArr", ticksArr);
	}
	
	//Home화면 영업이익
	@RequestMapping(value = "/getMonthlyProfitStatList.json")
	public Map getMonthlyProfitStatList(@RequestBody WorkStatVO param) throws Exception {
		Map<String,List<WorkStatVO>> returnList = workStatMgmtService.getNetProfitList(param);
		
		Map<String,Double[]> ticksArrMap = new HashMap<String, Double[]>();
		ticksArrMap.put("mmaTicksArr", workStatMgmtService.sortDataAndGetTicks("profit", returnList.get("mmaProfit")));
		ticksArrMap.put("pmmaTicksArr", workStatMgmtService.sortDataAndGetTicks("profit", returnList.get("pmmaProfit")));
		
		return JsonResponse.asSuccess("storeData", returnList, "ticksArrMap", ticksArrMap);
	}
	
	//Home화면 MMA ICIS
	@RequestMapping(value = "/getIcisList.json" )
	public Map getIcisList() throws Exception {
		IcisVO param = new IcisVO();
		String toDay = DateUtil.getToday();
		param.setPeMonthFr(DateUtil.addMonth(toDay, -6).substring(0, 6));
		param.setPeMonthTo(DateUtil.addMonth(toDay, 5).substring(0, 6));
		List<IcisVO>	icisList	= msService.getIcisList(param);
		return JsonResponse.asSuccess("storeData", icisList);
	}
	//Home화면 고부가 CG 실적
	@RequestMapping(value = "/getHighValueCGResultList.json" )
	public Map getHighValueCGResultList(@RequestBody HighValueGoalVO param) throws Exception {
		List<HighValueGoalVO> returnList = highValueMgmtService.getHighValueCGResultList(param);
		return JsonResponse.asSuccess("storeData", returnList);
	}
	@RequestMapping(value = "/html/{htmlPage}")
	public String homePage(@PathVariable String htmlPage) throws Exception {
		return htmlPage;
	}

}
