package com.lgmma.salesPortal.app.service.impl;

import com.github.underscore.lodash.$;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.service.CommonApprMgmtService;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.app.service.GPortalRestService;
import com.lgmma.salesPortal.app.service.GportalPostProcess;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.props.*;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Service
public class GPortalRestServiceImpl implements GPortalRestService {
	private final String GP_FORM_ID = "SFA";// 그룹포탈 문서양식코드(운영,개발 동일)
	private static Logger logger = LoggerFactory.getLogger(GPortalRestServiceImpl.class); 

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private CommonApprMgmtService commonApprMgmtService;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;

	@Autowired
	private CommonFileService commonFileService;

	/**
	 * 
	 * */
	private HttpEntity<?> apiClientHttpEntity(String appType, MultiValueMap<String, Object> param) {
		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.set("Content-Type", "application/" + appType);
		return new HttpEntity<Object>(param, requestHeaders);
	}

	/**
	 * 
	 * */
	private String sendRequest(MultiValueMap<String, Object> param, String mehhod) {
		String baseUrl = messageSourceAccessor.getMessage("gportal.approval.rest.url", "");
		HttpEntity<?> requestEntity = apiClientHttpEntity("x-www-form-urlencoded", param);
		URI uri = URI.create(baseUrl + mehhod);
		return sendApprInfoTask(uri, requestEntity);
	}

	/**
	 *  
	 * */
	private String sendApprInfoTask(URI uri, HttpEntity<?> requestEntity) {
		ResponseEntity<String> responseEntity = restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class);
		Map<String, List<String>> resultMap = (Map<String, List<String>>) $.fromXml(responseEntity.getBody());
		List<String> resultList = (List<String>) resultMap.get("value");
		return resultList.get(0); // "S" 이면 성공
	}

	/**
	 * 결재요청 GPortal 전송 작업
	 */
	@Override
	public void requestApproval(ApprVO paramApprVO) {
		ApprVO apprVO = commonApprMgmtService.getApprContainLineList(commonApprMgmtService.getAppr(paramApprVO));
		MultiValueMap<String, Object> param = new LinkedMultiValueMap<String, Object>();

		String APPR_LINE_TYPE = (apprVO.getGwdcCode() == null) ? "0":ApprConfType.getApprApprConfType(apprVO.getGwdcCode()).getGpConfType();

		param.add("FORM_ID"				, GP_FORM_ID);																	// GP 결재양식ID
		param.add("APPR_TITLE"			, "[SalesPortal]"+apprVO.getApprTitle());														// 문서타이틀
		param.add("USER_ID"				, apprVO.getSawnId());															// 기안자사원ID
		param.add("APPKEY_01"			, apprVO.getApprId());															// 업무키01 - salesPortal의 결재ID
		param.add("APPKEY_02"			, "");																			// 업무키02
		param.add("APPKEY_03"			, "");																			// 업무키03
		param.add("APPKEY_04"			, "");																			// 업무키04
		param.add("APPKEY_05"			, "");																			// 업무키05
		param.add("FORM_EDITOR_DATA"	, apprVO.getFormCont());														// 본문내용
		param.add("APPR_SECURITY_TYPE"	, ApprSecrCode.getApprSecrCode(apprVO.getSecrCode()).getGpScrt());				// 부서내 공개여부
		param.add("APPR_LINE_TYPE"		, APPR_LINE_TYPE);																// 협의유형(default:0)
		param.add("IS_EMERGENCY"		, "0");																			// 긴급여부(1:긴급,0:일반)
		param.add("APPR_DOC_NO"			, "");																			// GP 문서번호
		param.add("APPR_PERIOD_CD"		, ApprSaveCode.getApprGwScrt(apprVO.getSaveCode()).getGpApprPeriodCd());		// 보존년한
		//param.add("APPR_PERIOD_CD"		, "APPRCODE0008");		// 보존년한

		setApprACLineList(param, apprVO);	// 결재라인
		setApprILineList(param, apprVO);	// 통보자
		setApprRLineList(param, apprVO);	// 참조자
		setFileList(param,apprVO);			// 파일리스트 셋팅

		//throw new ServiceException("fail.common.appr.sendRequest");

		// G PORTAL 문서 전송
		if("S".equals(sendRequest(param, "/report"))) {
			// 상신 후 sms 보내기
			commonApprMgmtService.sendApprSms(apprVO);
		}else {
			// 실패시 문서생성오류 및 롤백
			throw new ServiceException("fail.common.appr.sendRequest");
		}

	}

	/**
	 * 첨부파일 리스트 작성
	 * */
	private void setFileList(MultiValueMap<String, Object> param, ApprVO apprVO) {
		String fileLinkName		= "";
		String fileLinkUrl		= "";
		final String link = messageSourceAccessor.getMessage("file.download.url","");

		FileVO paramFileVO = new FileVO();
		// 첨부파일ID가 있으면
		if(apprVO.getFileId() != null && !apprVO.getFileId().isEmpty()) {
			paramFileVO.setFileId(apprVO.getFileId());
			paramFileVO.setFilePathCd(FilePath.FILE_PATH_APPR.getCode());
			List<FileVO> fileList = commonFileService.getFileList(paramFileVO);
			// 첨부파일이 실제 등록되어있다면
			if(!fileList.isEmpty()) {
				Function<FileVO,String> fileVoFilterFileNmAlias = new Function<FileVO, String>(){
					public String apply(FileVO fileVO) {
						return fileVO.getFileNmAlias(); 
					}
				};
				Function<FileVO,String> fileVoFilterDownLinkUrl = new Function<FileVO, String>(){
					public String apply(FileVO fileVO) {
						return link.concat(fileVO.getFileItemId());
					}
				};

				List<String> fileNameList		= Lists.transform(fileList,fileVoFilterFileNmAlias);
				List<String> fileDownLinkList	= Lists.transform(fileList,fileVoFilterDownLinkUrl);
				fileLinkName	= Joiner.on(";").join(fileNameList);
				fileLinkUrl		= Joiner.on(";").join(fileDownLinkList);
				param.add("FILE_LINK_NAME", fileLinkName);
				param.add("FILE_LINK_URL", fileLinkUrl);
			}
		}
	}

	/**
	 * 결재라인 생성
	 * */
	private void setApprACLineList(MultiValueMap<String, Object> param, ApprVO apprVO) {
		String next_appr_type		= "";
		String next_approver		= "";
		String next_approver_type	= "";

		// 사원ID로 리스트 만들기
		Function<ApprLineVO,String> apprLineVoFilterEmpSawnId = new Function<ApprLineVO,String>(){
			public String apply(ApprLineVO apprLineVO) {
				return apprLineVO.getApprEmpSawnId();
			}
		};
		// 결재타입 리스트 만들기
		Function<ApprLineVO,String> apprLineVoFilterApprLineType = new Function<ApprLineVO,String>(){
			public String apply(ApprLineVO apprLineVO) {
				return ApprLineType.getApprLineType(apprLineVO.getApprLineType()).getGpLineType();
			}
		};
		// 결재자유형 리스트 만들기
		Function<ApprLineVO,String> apprLineVoFilterGPApprLineType = new Function<ApprLineVO,String>(){
			public String apply(ApprLineVO apprLineVO) {
				return "0";
			}
		};

		// 만들어진 리스트로 최종 문자열 만들기
		List<ApprLineVO> apprLineVOList			= getApprACLineList(apprVO);
		List<String> next_appr_type_list		= Lists.transform(apprLineVOList, apprLineVoFilterApprLineType);
		List<String> next_approver_list			= Lists.transform(apprLineVOList, apprLineVoFilterEmpSawnId);
		List<String> next_approver_type_list	= Lists.transform(apprLineVOList, apprLineVoFilterGPApprLineType);
		next_appr_type		= Joiner.on(";").join(next_appr_type_list);
		next_approver		= Joiner.on(";").join(next_approver_list);
		next_approver_type	= Joiner.on(";").join(next_approver_type_list);

		// 최종 문자열을 담기
		param.add("NEXT_APPR_TYPE"		, next_appr_type); 		// 결재 타입(0:결재, 1:합의(필수), 2:합의(선택)) - 구분자 ;
		param.add("NEXT_APPROVER"		, next_approver);		// 결재자	- 구분자 ;
		param.add("NEXT_APPROVER_TYPE"	, next_approver_type);	// 결재자 유형(사용자:0, 그룹:1) - 구분자 ;
	}

	/**
	 * 결재&합의자 순서 정렬 리턴
	 * */
	private List<ApprLineVO> getApprACLineList(ApprVO apprVO){
		List<ApprLineVO> rtnApprLineList = new ArrayList<ApprLineVO>();

		// 합의자가 없는 경우는 결재자 리스트로
        CommonApprMgmtServiceImpl.getOrderedApprLineACList(apprVO, rtnApprLineList);
        return rtnApprLineList;
	}

	/**
	 * 참조자 리스트 셋팅
	 * */
	private void setApprRLineList(MultiValueMap<String, Object> param, ApprVO apprVO) {
		String read_user = "";
		// 사원ID로 리스트 만들기
		Function<ApprLineVO,String> apprLineVoFilterEmpSawnId = new Function<ApprLineVO,String>(){
			public String apply(ApprLineVO apprLineVO) {
				return apprLineVO.getApprEmpSawnId();
			}
		};
		List<ApprLineVO> apprLineVOList	= apprVO.getApprLineRList();
		List<String> read_user_list			= Lists.transform(apprLineVOList, apprLineVoFilterEmpSawnId);
		read_user = Joiner.on(";").join(read_user_list);
		param.add("REFERENCE_ID", read_user);
	}

	/**
	 * 통보자 리스트 셋팅
	 * */
	private void setApprILineList(MultiValueMap<String, Object> param, ApprVO apprVO) {
		String read_user = "";
		// 사원ID로 리스트 만들기
		Function<ApprLineVO,String> apprLineVoFilterEmpSawnId = new Function<ApprLineVO,String>(){
			public String apply(ApprLineVO apprLineVO) {
				return apprLineVO.getApprEmpSawnId();
			}
		};
		List<ApprLineVO> apprLineVOList		= apprVO.getApprLineIList();
		List<String> read_user_list			= Lists.transform(apprLineVOList, apprLineVoFilterEmpSawnId);
		read_user = Joiner.on(";").join(read_user_list);
		param.add("READ_USER", read_user);
	}

	/**
	 * gportal 에서 넘어온 결재결과 처리
	 */
	@Override
	public void approvalAtcionFromGPortal(String apprId, String apprEmpId, String apprStatus, String apprEmpComment, String forceExcute) throws UnsupportedEncodingException {
		logger.debug("#########################approvalAtcionFromGPortal Start");
		ApprVO		apprVO		= new ApprVO();
		ApprLineVO	apprLineVO	= new ApprLineVO();

		// 인코딩 되어서 넘어온 코멘트를 디코드 하여 저장(두번 인코딩 되어있어서 두번 디코딩한다.)
		String decodedApprEmpComment =  URLDecoder.decode(StringUtil.nullConvert(apprEmpComment),"UTF-8");
		decodedApprEmpComment = URLDecoder.decode(decodedApprEmpComment,"UTF-8");

		// 품의공통 결재자 테이블 결과 저장
		apprLineVO.setApprId(apprId);
		apprLineVO.setApprEmpId(apprEmpId);	// 쿼리에서 펑션으로 사번으로 변경
		apprLineVO.setUpdtIdxx(apprEmpId);	// 쿼리에서 펑션으로 사번으로 변경
		apprLineVO.setApplStat(ApprGPortalApprovalReturnType.getApprGPortalApprovalReturnType(apprStatus).getApplState());
		apprLineVO.setApprLineComment(decodedApprEmpComment);

		// 품의공통 테이블 결과 상태 저장
		apprVO.setApprId(apprId);
		apprVO.setApprStat(ApprGPortalApprovalReturnType.getApprGPortalApprovalReturnType(apprStatus).getApprState());
		apprVO.setUpdtIdxx(apprEmpId);	// 쿼리에서 펑션으로 사번으로 변경

		// 품의서 저장 서비스
		commonApprMgmtService.apprApplyResultFromGPortal(apprVO, apprLineVO, forceExcute);

		// 품의서 정보조회후 후처리
		apprVO = commonApprMgmtService.getAppr(apprVO);
		// 품의서 결과 상태에 따른 후처리 START
		// 완료 후처리
		if(ApprGPortalApprovalReturnType.GP_APPL_COMPLETE.getCode().equals(apprStatus)) {
			GportalPostProcess gportalPostProcess = (GportalPostProcess)Util.getBean(ApprType.getApprType(apprVO.getApprType()).getGpPostServiceBeanName());
			gportalPostProcess.completeProcess(apprVO);
		}

		// 반려 후처리
		if(ApprGPortalApprovalReturnType.GP_APPL_REJECT.getCode().equals(apprStatus)
				||
				ApprGPortalApprovalReturnType.GP_APPL_DISAGREE.getCode().equals(apprStatus)
				) {
			GportalPostProcess gportalPostProcess = (GportalPostProcess)Util.getBean(ApprType.getApprType(apprVO.getApprType()).getGpPostServiceBeanName());
			gportalPostProcess.rejectProcess(apprVO);
		}
		// 품의서 결과 상태에 따른 후처리 END

		// 결재결과 처리 후 sms 보내기
		commonApprMgmtService.sendApprSms(apprVO);
	}

}
