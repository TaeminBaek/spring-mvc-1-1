package com.lgmma.salesPortal.app.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.dao.StockDisplayDao;
import com.lgmma.salesPortal.app.model.ProductStockVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.service.StockDisplayMgmtService;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.props.Vkorg;

@Service
public class StockDisplayMgmtServiceImpl implements StockDisplayMgmtService{
	
	private final String FNC_PRODUCT_MASTER = "ZSDE01_MASTER_SELECT_MQ";

	@Autowired
	private StockDisplayDao stockDisplayDao;

	@Autowired
	private JcoConnector jcoConnector;

	@Override
	public int getStockDisplayCount(ProductVO param) {
		return stockDisplayDao.getStockDisplayCount(param);
	}

	@Override
	public List<ProductVO> getStockDisplayList(ProductVO param) {
		return stockDisplayDao.getStockDisplayList(param);
	}

	@Override
	public void updateStockDisplay(List<ProductVO> paramList) {
		for(ProductVO productVo : paramList) {
			stockDisplayDao.updateStockDisplay(productVo);
		}
		
	}

	@Override
	public void getProductsFromSap() {
		JcoTableParam tableParam = null;
		
		for(Vkorg org : Vkorg.values()) {
			tableParam = new JcoTableParam();
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("SIGN", "I");
			paramMap.put("OPTION", "EQ");
			paramMap.put("LOW", org.getCode());
			paramMap.put("HIGH", null);
			tableParam.put("SALESORGRANGE", paramMap);

			jcoConnector.executeFunction(FNC_PRODUCT_MASTER, tableParam);
			List<ProductVO> productList = (List<ProductVO>) tableParam.get("T_MATNRINFO", ProductVO.class);
			stockDisplayDao.mergeProduct(productList);
		}
	}

	@Override
	public int getProductInStockCount(ProductStockVO param) {
		return stockDisplayDao.getProductInStockCount(param);
	}

	@Override
	public List<ProductStockVO> getProductInStockList(ProductStockVO param) {
		return stockDisplayDao.getProductInStockList(param);
	}
	
}
