package com.lgmma.salesPortal.app.service.impl;

import com.lgmma.salesPortal.app.dao.CommonCodeDao;
import com.lgmma.salesPortal.app.dao.CommonDao;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;
import com.lgmma.salesPortal.app.model.OrderProdJindVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;
import com.lgmma.salesPortal.app.model.SapOrderShipListVO;
import com.lgmma.salesPortal.app.model.VocVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.CommonServiceCache;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Transactional
@Service
public class CommonServiceImpl implements CommonService {
	
	private final String FNC_ORDER_OPTION_LIST = "ZSDE01_MASTER_SELECT";
	private final String FNC_ORDER_JIND = "ZSDE01_MASTER_SELECT_CQ";
	private final String FNC_ORDER_DELIVER_LIST = "ZSDE02_SELECT_SHIPMENT";
	private final String FNC_ORDER_PROD_PRICE = "ZSDE01_MASTER_SELECT_MQ1";
	
	
    @Autowired
    private CommonDao commonDao;

	@Autowired
	private CommonCodeDao commonCodeDao;

	@Autowired
	private JcoConnector jcoConnector;

	@Autowired
	private CommonServiceCache commonServiceCache;

	@Override
	public List<EmployVO> getEmployList(EmployVO param) {
		return commonDao.getEmployList(param);
	}

	@Override
	public int getEmployListCount(EmployVO param) {
		return commonDao.getEmployListCount(param);
	}
	
	@Override
	public List<OrderProdJindVO> getOrderProductList(OrderProdJindVO param) {
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> outputParams = null;
		Map<String, Object> inputParams = new HashMap<String, Object>();
		
		inputParams.put("I_GUBUN","CA");
		
			// 제품군
			Map<String, Object> paramMap_vkorg = new HashMap<String, Object>();
			paramMap_vkorg.put("SIGN", "I");
			paramMap_vkorg.put("OPTION", "EQ");
			paramMap_vkorg.put("LOW", param.getTvkotVkorg());
			paramMap_vkorg.put("HIGH", null);
			tableParam.put("SALESORGRANGE", paramMap_vkorg);
			
			//ERP코드
			Map<String, Object> paramMap_saleCd = new HashMap<String, Object>();
			paramMap_saleCd.put("SIGN", "I");
			paramMap_saleCd.put("OPTION", "EQ");
			paramMap_saleCd.put("LOW", param.getCompCode());
			paramMap_saleCd.put("HIGH", null);
			tableParam.put("CUSTOMERRANGE", paramMap_saleCd);

			jcoConnector.executeFunction(FNC_ORDER_OPTION_LIST ,inputParams ,outputParams ,tableParam);
			List<OrderProdJindVO> productList = (List<OrderProdJindVO>) tableParam.get("T_MATNR", OrderProdJindVO.class);
		return productList;
	}
	
	@Override
	public List<OrderProdJindVO> getOrderDeliverList(OrderProdJindVO param) {
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> outputParams = null;
		Map<String, Object> inputParams = new HashMap<String, Object>();
		
		inputParams.put("I_GUBUN","CA");
		
		// 제품군
		Map<String, Object> paramMap_vkorg = new HashMap<String, Object>();
		paramMap_vkorg.put("SIGN", "I");
		paramMap_vkorg.put("OPTION", "EQ");
		paramMap_vkorg.put("LOW", param.getTvkotVkorg());
		paramMap_vkorg.put("HIGH", null);
		tableParam.put("SALESORGRANGE", paramMap_vkorg);

		//ERP코드
		Map<String, Object> paramMap_saleCd = new HashMap<String, Object>();
		paramMap_saleCd.put("SIGN", "I");
		paramMap_saleCd.put("OPTION", "EQ");
		paramMap_saleCd.put("LOW", param.getCompCode());
		paramMap_saleCd.put("HIGH", null);
		tableParam.put("CUSTOMERRANGE", paramMap_saleCd);

		jcoConnector.executeFunction(FNC_ORDER_OPTION_LIST ,inputParams ,outputParams ,tableParam);
		List<Map> partnerList = (List<Map>) tableParam.get("T_BAPIPARNR");
		List<HashMap> deliverListTemp = new ArrayList<HashMap>();
		for(Map item : partnerList) {
			if(item.get("PARTN_ROLE").equals("WE")) {
				item.put("NAME", item.get("NAME").toString().replace("　",""));
				deliverListTemp.add((HashMap) item);
			}
		}
		tableParam.put("T_DELIVER", deliverListTemp);

		return (List<OrderProdJindVO>) tableParam.get("T_DELIVER", OrderProdJindVO.class);
		
	}
	
	
	@Override
	public List<CommonCodeVO> getCommonCodeComboList(CommonCodeVO param) {
		return commonDao.getCommonCodeComboList(param);
	}

	@Override
	public EmployVO getEmployBySawnCode(String sawnCode) {
		return commonDao.getEmployBySawnCode(sawnCode);
	}
	
	@Override
	public int getProductPopupCount(ProductVO param) {
		return commonDao.getProductPopupCount(param);
	}
	
	@Override
	public List<ProductVO> getProductPopupList(ProductVO param) {
		return commonDao.getProductPopupList(param);
	}

	@Override
	public int getCustomerPopupCount(CompanyVO param) {
		return commonDao.getCustomerPopupCount(param);
	}

	@Override
	public List<CompanyVO> getCustomerPopupList(CompanyVO param) {
		return commonDao.getCustomerPopupList(param);
	}

	@Override
	public int getWebAccountPopupCount(LoginUserVO param) {
		return commonDao.getWebAccountPopupCount(param);
	}

	@Override
	public List<LoginUserVO> getWebAccountPopupList(LoginUserVO param) {
		return commonDao.getWebAccountPopupList(param);
	}
	
	@Override
	public List<OrderProdJindVO> getOrderJindSearch(OrderProdJindVO param) {
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> outputParams = new HashMap<String, Object>();
		Map<String, Object> inputParams = new HashMap<String, Object>();
		Map<String, Object> struct_buyer = new HashMap<String, Object>();
		
		struct_buyer.put("SIGN", "I");
		struct_buyer.put("OPTION", "EQ");
		struct_buyer.put("LOW", param.getJindIdxx());
		struct_buyer.put("HIGH", null);
		tableParam.put("CUSTOMERRANGE", struct_buyer);

		jcoConnector.executeFunction(FNC_ORDER_JIND, tableParam);
		List<OrderProdJindVO> orderJind = (List<OrderProdJindVO>) tableParam.get("T_KNA1", OrderProdJindVO.class);
		for(OrderProdJindVO OrderProdJindVO : orderJind) {
			OrderProdJindVO.setPostlCode(OrderProdJindVO.getPSTLZ());
			OrderProdJindVO.setStreet(OrderProdJindVO.getSTRAS());
			OrderProdJindVO.setTelephone(OrderProdJindVO.getTELF1());
		}
		
		return orderJind;
	}
	
	@Override
	public List<SapOrderShipListVO> getOrderDeliverSearch(SapOrderShipListVO param) {
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> inputParams = new HashMap<String, Object>();
		Map<String, Object> outputParams = new HashMap<String, Object>();

		inputParams.put("I_VKORG",param.getTvkotVkorg());
		
		Map<String, Object> struct_table = new HashMap<String, Object>();
			
		struct_table.put("VBELN", param.getVbeln());
		struct_table.put("POSNR", param.getPosnr());
		
		tableParam.put("T_INPUT", struct_table);
		List<SapOrderShipListVO> orderDeliverList = null;
		jcoConnector.executeFunction(FNC_ORDER_DELIVER_LIST ,inputParams ,outputParams ,tableParam);
		orderDeliverList = (List<SapOrderShipListVO>) tableParam.get("T_LIST", SapOrderShipListVO.class);
			
		return orderDeliverList;
	}

	@Override
	public CompanyVO checkCompanyBusinoDub(Map<String, String> param) {
		return commonDao.checkCompanyBusinoDub(param);
	}
	
	@Override
	public List<OrderProdJindVO> getOrderProdPricesSearch(OrderProdJindVO param) {
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> inputParams = null;
		Map<String, Object> outputParams = null;

		Map<String, Object> table_organ = new HashMap<String, Object>();
		
		table_organ.put("SIGN", "I");
		table_organ.put("OPTION", "EQ");
		table_organ.put("LOW", param.getTvkotVkorg());
		table_organ.put("HIGH", null);
		tableParam.put("SALESORGRANGE", table_organ);
		
		Map<String, Object> table_buyer = new HashMap<String, Object>();
		
		table_buyer.put("SIGN", "I");
		table_buyer.put("OPTION", "EQ");
		table_buyer.put("LOW", param.getCompCode());
		table_buyer.put("HIGH", null);
		tableParam.put("CUSTOMERRANGE", table_buyer);
		
		Map<String, Object> table_indo = new HashMap<String, Object>();
		
		table_indo.put("SIGN", "I");
		table_indo.put("OPTION", "EQ");
		table_indo.put("LOW", param.getJindIdxx());
		table_indo.put("HIGH", null);
		tableParam.put("KUNWERANGE", table_indo);
			
		if(param.getMatnr() != null && !param.getMatnr().equals("")) {
			Map<String, Object> table_prod = new HashMap<String, Object>();
			table_prod.put("SIGN", "I");
			table_prod.put("OPTION", "EQ");
			table_prod.put("LOW", param.getJindIdxx());
			table_prod.put("HIGH", null);
			tableParam.put("MATNRRANGE", table_prod);
		}
			
		List<OrderProdJindVO> orderProdPriceList = null;
		jcoConnector.executeFunction(FNC_ORDER_PROD_PRICE ,inputParams ,outputParams ,tableParam);
		orderProdPriceList = (List<OrderProdJindVO>) tableParam.get("T_MATNRINFO", OrderProdJindVO.class);
			
		return orderProdPriceList;
	}
	
	@Override
	public String getKvgr3(String param) {
		return commonDao.getKvgr3(param);
	}
	
	@Override
	public List<String> getKunnr(Map<String, String> param) {
		return commonDao.getKunnr(param);
	}

	@Override
	public List<VocVO> getVocSrvcList() {
		return commonDao.getVocSrvcList();
	}
	
	@Override
	public List<VocVO> getVocSrvcDivxList(VocVO param) {				
		return commonDao.getVocSrvcDivxList(param);
	}
	
	@Override
	public int getAgencyPopupCount(CompanyVO param) {
		return commonDao.getAgencyPopupCount(param);
	}

	@Override
	public List<CompanyVO> getAgencyPopupList(CompanyVO param) {
		return commonDao.getAgencyPopupList(param);
	}

	@Override
	public int getSalePricePopupCount(SalePriceMasterVO param) {
		return commonDao.getSalePricePopupCount(param);
	}

	@Override
	public List<SalePriceMasterVO> getSalePricePopupList(SalePriceMasterVO param) {
		return commonDao.getSalePricePopupList(param);
	}

	@Override
	public String getPositionName(String posiCode) {
		return commonDao.getPositionName(posiCode);
	}

	@Override
	public String getTeamName(String teamCode) {
		return commonDao.getTeamName(teamCode);
	}

	@Override
	public List<CommonCodeVO> getCommonCodeDbAll() {
		return commonServiceCache.getCommonCodeDbAll();
	}

	@Override
	public List<CommonCodeVO> getDissProdDivisionDList(CommonCodeVO param) {
		return commonDao.getDissProdDivisionDList(param);
	}
	
	@Override
	public List<CommonCodeVO> getDissFailReasonDtlList(CommonCodeVO param) {
		return commonDao.getDissFailReasonDtlList(param);
	}

	@Override
	public ProductVO getProductDtl(ProductVO param) {
		return commonDao.getProductDtl(param);
	}
}
