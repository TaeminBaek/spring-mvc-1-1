package com.lgmma.salesPortal.app.model;

public class DissKpiVO extends PagingParamVO {

	//TB_D_KPI
	private String kpiId;           //KPI_ID
	private String taskId;          //과제ID
	private String taskType;        //과제구분
	private String kpiName;         //항목명
	private String kpiUnit;         //단위
	private String preExcuteVal;    //활동전
	private String goalVal;         //목표
	private String nowVal;          //현수준
	private String rivalComp;       //경쟁사
	private String rivalCompVal;    //경쟁사수준
	private String expectCompYmd;   //완료예정일
	private String compYmd;         //완료일
	private String mngEmpId;        //담당자	
	private String recipeId;        //처방ID
	private String devResult;       //개발결과
	private String ftResult;        //FT결과
	private String tsEvalRslt;      //TS평가결과
	private String curValStdYmd;    //현재수준설정일
	//HIS
	private String stepId;
	//처방
	private Integer recipeNo;
	private Integer degreeNo;
	private String recipeTxt;	
	//차수현황
	private String fileId;
	
	private String mngEmpNm;        //담당자명	
	
	public String getKpiId() {
		return kpiId;
	}

	public void setKpiId(String kpiId) {
		this.kpiId = kpiId;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getKpiName() {
		return kpiName;
	}

	public void setKpiName(String kpiName) {
		this.kpiName = kpiName;
	}

	public String getKpiUnit() {
		return kpiUnit;
	}

	public void setKpiUnit(String kpiUnit) {
		this.kpiUnit = kpiUnit;
	}

	public String getPreExcuteVal() {
		return preExcuteVal;
	}

	public void setPreExcuteVal(String preExcuteVal) {
		this.preExcuteVal = preExcuteVal;
	}

	public String getGoalVal() {
		return goalVal;
	}

	public void setGoalVal(String goalVal) {
		this.goalVal = goalVal;
	}

	public String getNowVal() {
		return nowVal;
	}

	public void setNowVal(String nowVal) {
		this.nowVal = nowVal;
	}

	public String getRivalComp() {
		return rivalComp;
	}

	public void setRivalComp(String rivalComp) {
		this.rivalComp = rivalComp;
	}

	public String getRivalCompVal() {
		return rivalCompVal;
	}

	public void setRivalCompVal(String rivalCompVal) {
		this.rivalCompVal = rivalCompVal;
	}

	public String getExpectCompYmd() {
		return expectCompYmd;
	}

	public void setExpectCompYmd(String expectCompYmd) {
		this.expectCompYmd = expectCompYmd;
	}

	public String getCompYmd() {
		return compYmd;
	}

	public void setCompYmd(String compYmd) {
		this.compYmd = compYmd;
	}

	public String getMngEmpId() {
		return mngEmpId;
	}

	public void setMngEmpId(String mngEmpId) {
		this.mngEmpId = mngEmpId;
	}

	public String getRecipeId() {
		return recipeId;
	}

	public void setRecipeId(String recipeId) {
		this.recipeId = recipeId;
	}

	public String getDevResult() {
		return devResult;
	}

	public void setDevResult(String devResult) {
		this.devResult = devResult;
	}

	public String getFtResult() {
		return ftResult;
	}

	public void setFtResult(String ftResult) {
		this.ftResult = ftResult;
	}

	public String getTsEvalRslt() {
		return tsEvalRslt;
	}

	public void setTsEvalRslt(String tsEvalRslt) {
		this.tsEvalRslt = tsEvalRslt;
	}

	public String getCurValStdYmd() {
		return curValStdYmd;
	}

	public void setCurValStdYmd(String curValStdYmd) {
		this.curValStdYmd = curValStdYmd;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public Integer getRecipeNo() {
		return recipeNo;
	}

	public void setRecipeNo(Integer recipeNo) {
		this.recipeNo = recipeNo;
	}

	public Integer getDegreeNo() {
		return degreeNo;
	}

	public void setDegreeNo(Integer degreeNo) {
		this.degreeNo = degreeNo;
	}

	public String getRecipeTxt() {
		return recipeTxt;
	}

	public void setRecipeTxt(String recipeTxt) {
		this.recipeTxt = recipeTxt;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getMngEmpNm() {
		return mngEmpNm;
	}

	public void setMngEmpNm(String mngEmpNm) {
		this.mngEmpNm = mngEmpNm;
	}
}
