package com.lgmma.salesPortal.app.service;
import java.util.List;

import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.HighValueGoalVO;

public interface HighValueMgmtService {
	
	void updateHighValue(List<DirectOrderItemVO> paramList);
	
	int getHighValueGoalCount(HighValueGoalVO param);
	
	List<HighValueGoalVO> getHighValueGoalList(HighValueGoalVO param);

	List<CommonCodeVO> getHighValueCodeList(HighValueGoalVO param);
	
	void createHighValueGoal(List<HighValueGoalVO> paramList);
	
	void updateHighValueGoal(List<HighValueGoalVO> paramList);

	void deleteHighValueGoal(HighValueGoalVO param);

	List<CommonCodeVO> getYearHighValueCodeList(HighValueGoalVO param);

	List<HighValueGoalVO> getHighValueCGResultList(HighValueGoalVO param);
}
