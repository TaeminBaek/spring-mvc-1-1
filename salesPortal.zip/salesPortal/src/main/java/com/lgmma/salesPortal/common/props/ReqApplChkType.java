package com.lgmma.salesPortal.common.props;

import java.util.Arrays;
import java.util.List;

public enum ReqApplChkType {
/**
 * 품의서 필수결재라인 체크기준으로서
*/
	APPL_REQ_LINE_DEFAULT(	"000"	,"기본 체크 안함"
			 ,null	// 결재자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			 ,null	// 결재자필수직위리스트
			 ,null	// 협의자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			 ,null	// 협의자필수직위리스트
			 ,null	// 참조자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			 ,null	// 참조자필수직위리스트
			 ,null	// 통보자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			 ,null	// 통보자필수직위리스트
			 )
	,APPL_REQ_LINE_001(	"100"	,"여신체크"
			 ,Arrays.asList("SELFTEAM")	// 결재자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			 ,null	// 결재자필수직위리스트
			 ,null	// 협의자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			 ,null	// 협의자필수직위리스트
			 ,null	// 참조자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			 ,null	// 참조자필수직위리스트
			 ,null	// 통보자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			 ,null	// 통보자필수직위리스트
			 )
	;
	String code				= null;		// 채크구분코드
	String name				= null;		// 채크구분코드명
	List<String> aTeams		= null;		// 결재자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
	List<String> aPositions	= null;		// 결재자필수직위리스트
	List<String> cTeams		= null;		// 협의자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
	List<String> cPositions	= null;		// 협의자필수직위리스트
	List<String> rTeams		= null;		// 참조자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
	List<String> rPositions	= null;		// 참조자필수직위리스트
	List<String> iTeams		= null;		// 통보자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
	List<String> iPositions	= null;		// 통보자필수직위리스트

	private ReqApplChkType(String code, String name
			, List<String> aTeams		//결재자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			, List<String> aPositions	//결재자필수직위리스트
			, List<String> cTeams		//협의자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			, List<String> cPositions	//협의자필수직위리스트
			, List<String> rTeams		//참조자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			, List<String> rPositions	//참조자필수직위리스트
			, List<String> iTeams		//통보자필수팀리스트("SELFTEAM" 이 있으면 기안자부서체크)
			, List<String> iPositions	//통보자필수직위리스트
			) {
		this.code		= code;
		this.name		= name;
		this.aTeams		= aTeams;
		this.aPositions	= aPositions;
		this.cTeams		= cTeams;
		this.cPositions	= cPositions;
		this.rTeams		= rTeams;
		this.rPositions	= rPositions;
		this.iTeams		= iTeams;
		this.iPositions	= iPositions;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getaTeams() {
		return aTeams;
	}

	public void setaTeams(List<String> aTeams) {
		this.aTeams = aTeams;
	}

	public List<String> getaPositions() {
		return aPositions;
	}

	public void setaPositions(List<String> aPositions) {
		this.aPositions = aPositions;
	}

	public List<String> getcTeams() {
		return cTeams;
	}

	public void setcTeams(List<String> cTeams) {
		this.cTeams = cTeams;
	}

	public List<String> getcPositions() {
		return cPositions;
	}

	public void setcPositions(List<String> cPositions) {
		this.cPositions = cPositions;
	}

	public List<String> getrTeams() {
		return rTeams;
	}

	public void setrTeams(List<String> rTeams) {
		this.rTeams = rTeams;
	}

	public List<String> getrPositions() {
		return rPositions;
	}

	public void setrPositions(List<String> rPositions) {
		this.rPositions = rPositions;
	}

	public List<String> getiTeams() {
		return iTeams;
	}

	public void setiTeams(List<String> iTeams) {
		this.iTeams = iTeams;
	}

	public List<String> getiPositions() {
		return iPositions;
	}

	public void setiPositions(List<String> iPositions) {
		this.iPositions = iPositions;
	}

	public static ReqApplChkType getReqApplChkType(String code) {
		for(ReqApplChkType type : ReqApplChkType.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
}
