package com.lgmma.salesPortal.common.props;

public enum ApprSaveCode {
/**
 * 품의서 보존년한으로서
*/
	 APPR_SAVE_CODE_1(		"00018"	,"1년"	,"APPRCODE0005")
	,APPR_SAVE_CODE_2(		"00019"	,"2년"	,"APPRCODE0006")
	,APPR_SAVE_CODE_3(		"00020"	,"3년"	,"APPRCODE0007")
	,APPR_SAVE_CODE_5(		"00021"	,"5년"	,"APPRCODE0008")
	,APPR_SAVE_CODE_7(		"00022"	,"7년"	,"120000800788")
	,APPR_SAVE_CODE_10(		"00023"	,"10년"	,"120000800747")
	,APPR_SAVE_CODE_FOREVER("00024"	,"영구"	,"120000800790")
	;
	String code		= null;
	String name		= null;
	String gpApprPeriodCd = null; // GPortal 보존년한코드

	private ApprSaveCode(String code, String name, String gpApprPeriodCd) {
		this.code	= code;
		this.name	= name;
		this.gpApprPeriodCd = gpApprPeriodCd;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGpApprPeriodCd() {
		return gpApprPeriodCd;
	}

	public void setGpApprPeriodCd(String gpApprPeriodCd) {
		this.gpApprPeriodCd = gpApprPeriodCd;
	}

	public static ApprSaveCode getApprGwScrt(String code) {
		for(ApprSaveCode type : ApprSaveCode.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
}
