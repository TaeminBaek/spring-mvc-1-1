package com.lgmma.salesPortal.app.service.impl;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.dao.DirectOrderDao;
import com.lgmma.salesPortal.app.dao.SalePriceMasterDao;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.DirectOrderSimpleVO;
import com.lgmma.salesPortal.app.model.OrderProdJindVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.model.SalePriceCloseDtlVO;
import com.lgmma.salesPortal.app.model.SalePriceCloseVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterHisVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.CompanyService;
import com.lgmma.salesPortal.app.service.DirectOrderService;
import com.lgmma.salesPortal.app.service.SalePriceMasterMgmtService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.model.DDLBItem;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.Konwa;
import com.lgmma.salesPortal.common.props.OrderStatus;
import com.lgmma.salesPortal.common.props.SalePriceMasterPriceListType;
import com.lgmma.salesPortal.common.props.SalePriceMasterSpKind;
import com.lgmma.salesPortal.common.props.SalePriceMasterUnitType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.props.Vtweg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

@Transactional
@Service
public class SalePriceMasterMgmtServiceImpl implements SalePriceMasterMgmtService {
	private static Logger logger = LoggerFactory.getLogger(SalePriceMasterMgmtServiceImpl.class); 
	private final String FNC_SAP_CREATE_SALEPRICE = "ZSDE07_CREATE_SALES_PRICE";			// 판가 생성
	private final String FNC_SAP_CANCEL_BILLING = "ZSDE07_CANCEL_BILLING";			// 빌링취소
	private final String FNC_SAP_POST_BILLING = "ZSDE07_POST_BILLING";			// 빌링생성
	private final String FNC_SAP_FOB_PRICE = "ZSDE07_DISPLAY_FOB_PRICE";		// FOB 물대 DISPLAY
	
	@Autowired
	private SalePriceMasterDao salePriceMasterDao;
	
	@Autowired
	private DirectOrderDao directOrderDao;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private DirectOrderService directOrderService;

	@Autowired
	private SapSearchService sapSearchService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private JcoConnector jcoConnector;
	
	@Override
	public int getsalePriceMasterListCount(SalePriceMasterVO param) {
		return salePriceMasterDao.getsalePriceMasterListCount(param);
	}

	@Override
	public List<SalePriceMasterVO> getsalePriceMasterList(SalePriceMasterVO param) throws Exception {
		List<SalePriceMasterVO> returnList = new ArrayList<SalePriceMasterVO>();

		//인도처 이름 받아오기
		for(SalePriceMasterVO returnVo : salePriceMasterDao.getsalePriceMasterList(param)) {
			OrderProdJindVO indoVo = new OrderProdJindVO();
			indoVo.setJindIdxx(returnVo.getIndoKunnr());
			List<OrderProdJindVO> jindList = commonService.getOrderJindSearch(indoVo);
			if(jindList.size() != 0) {
				String indoName = jindList.get(0).getNAME1();
				returnVo.setIndoName(indoName);
			}
			
			//최종인도처 존재할 경우
			if(returnVo.getSpTypeKind().equals("PATNR")) {
				OrderProdJindVO lastIndoVo = new OrderProdJindVO();
				lastIndoVo.setJindIdxx(returnVo.getSpType());
				List<OrderProdJindVO> finalJindList = commonService.getOrderJindSearch(lastIndoVo);
				if(finalJindList.size() != 0) {
					String lastIndoName = finalJindList.get(0).getNAME1();
					returnVo.setFinalIndo(lastIndoName);
				}
				
			}
			
			returnList.add(returnVo);
		}
		return returnList;
	}
	
	@Override
	public SalePriceMasterVO getsalePriceMasterDetail(SalePriceMasterVO param) {
		SalePriceMasterVO returnVo = salePriceMasterDao.getsalePriceMasterDetail(param);
		
		//인도처 이름 받아오기
		OrderProdJindVO indoVo = new OrderProdJindVO();
		indoVo.setJindIdxx(returnVo.getIndoKunnr());
		List<OrderProdJindVO> jindList = commonService.getOrderJindSearch(indoVo);
		if(jindList.size() != 0) {
			String indoName = jindList.get(0).getNAME1();
			returnVo.setIndoName(indoName);
		}
		
		//최종인도처 존재할 경우
		if(returnVo.getSpTypeKind().equals("PATNR")) {
			OrderProdJindVO lastIndoVo = new OrderProdJindVO();
			lastIndoVo.setJindIdxx(returnVo.getSpType());
			List<OrderProdJindVO> finalJindList = commonService.getOrderJindSearch(lastIndoVo);
			if(finalJindList.size() != 0) {
				String lastIndoName = finalJindList.get(0).getNAME1();
				returnVo.setFinalIndo(lastIndoName);
			}
		}
		
		List<SalePriceMasterHisVO> hisList = salePriceMasterDao.getsalePriceMasterHisList(param);
		returnVo.setHisList(hisList);
		return returnVo;
	}

	@Override
	public int duplicateChkSalePriceMaster(SalePriceMasterHisVO param) {
		return salePriceMasterDao.duplicateChkSalePriceMaster(param);
	}

	@Override
	public void salePriceMasterExcelUpload(SalePriceMasterHisVO param) {
		// 고객코드
		CompanyVO companyVO = new CompanyVO();
		companyVO.setVkorg(param.getVkorg());
		companyVO.setKunnr(param.getKunnr());
		companyVO.setUserType("E");
		companyVO.setPageSize(100);

		// 제품코드
		ProductVO productVO = new ProductVO();
		productVO.setVkorg(param.getVkorg());
		productVO.setMatnr(param.getMatnr());

		if (Vkorg.getVkorg(param.getVkorg()) == null												// 영업조직
		|| Vtweg.getVtweg(param.getVtweg()) == null													// 유통경로
		|| companyService.getCompanyList(companyVO).size() == 0										// 고객코드
		|| param.getKunnr().length() != 10															// 고객코드 (자릿수)
		|| SalePriceMasterSpKind.getSalePriceMasterSpKind(param.getSpTypeKind()) == null			// 판가구분유형
		|| ("PLTYP".equals(param.getSpTypeKind()) ? SalePriceMasterPriceListType.getSalePriceMasterPriceListType(param.getSpType()) == null : false)	// 판가구분
		|| SalePriceMasterUnitType.getSalePriceMasterUnitType(param.getKmein()) == null				// 조건단위
		|| Konwa.getKonwa(param.getKonwa()) == null													// 통화
		|| !DateUtil.checkDate(param.getSpStaYmd())													// 적용기간 시작
		|| !DateUtil.checkDate(param.getSpEndYmd())													// 적용기간 종료
		|| commonService.getProductDtl(productVO) == null)											// 제품코드
			throw new ServiceException("", "입력값이 올바르지 않습니다.");

		// 인도처 코드 체크
		OrderProdJindVO orderProdJindVO = new OrderProdJindVO();
		orderProdJindVO.setCompCode(param.getKunnr());
		orderProdJindVO.setTvkotVkorg(param.getVkorg());

		// 고객 인도처 리스트를 모두 가져와서 확인
		boolean indoChk = false;
		List<OrderProdJindVO> deliverList = commonService.getOrderDeliverList(orderProdJindVO);
		for (OrderProdJindVO vo : deliverList)
			if (vo.getPartnNumb().equals(param.getIndoKunnr())) {
				indoChk = true;
				break;
			}

		if (!indoChk)	throw new ServiceException("", "입력값이 올바르지 않습니다.");

		// 판가구분이 실제 인도처인 경우
		if("PATNR".equals(param.getSpTypeKind()) && indoChk) {
			indoChk = false;
			for (OrderProdJindVO vo : deliverList)
				if (vo.getPartnNumb().equals(param.getSpType())) {
					indoChk = true;
					break;
				}
		}

		if (!indoChk)	throw new ServiceException("", "입력값이 올바르지 않습니다.");

		createSalePriceMaster(param);
	}

	@Override
	public void createSalePriceMaster(SalePriceMasterHisVO param) {
		// history 저장
		salePriceMasterDao.createSalePriceMasterHis(param);

		// 마스터 저장 처리 시작
		mergeSalePriceMaster(param);
	}

	/**
	 * 마스터 저장처리 작업(단건처리)
	 * -- 이력구간을 자동으로 정리하면서 저장처리
	 * @param param
	 */
	private void mergeSalePriceMaster(SalePriceMasterHisVO param) {
		// 히스토리 객체를 마스터 객체로 변환
		SalePriceMasterVO sourceSalePriceMasterVO = copySalePriceMasterHisVOToMasterVO(param);
		
		String prevMonth = DateUtil.addMonth(Util.getToday(), -1).substring(0, 6);
		if(Integer.parseInt(param.getSpStaYmd()) < Integer.parseInt(prevMonth+"01")) {
			throw new ServiceException("","판가 시작일이 유효하지 않습니다.");
		}
		
		// 기존 기준 내역이 없었던 최초 입력이면 종료일자를 99991231 로 바꿔서 입력 처리
		if(salePriceMasterDao.checkSalePriceMasterMergeTargetCnt(sourceSalePriceMasterVO) == 0) {
			sourceSalePriceMasterVO.setSpEndYmd("99991231");
			salePriceMasterDao.createSalePriceMasterMergeTarget(sourceSalePriceMasterVO);
		}else {
			// 이력에 걸리는 데이타를 찾아서 시작일 순으로 loop 돌면서 처리
			for(SalePriceMasterVO salePriceMasterVO: salePriceMasterDao.getSalePriceMasterMergeTargetList(sourceSalePriceMasterVO)) {
				// 1. 소스 시작일 종료일 사이에 있는 값이면 당건은 삭제
				if(	Integer.parseInt(salePriceMasterVO.getSpStaYmd()) >= Integer.parseInt(sourceSalePriceMasterVO.getSpStaYmd())
					&&
					Integer.parseInt(salePriceMasterVO.getSpEndYmd()) <= Integer.parseInt(sourceSalePriceMasterVO.getSpEndYmd())
				) {
					salePriceMasterDao.deleteSalePriceMasterMergeTarget(salePriceMasterVO);
				}else {
					// 2. 소스가 당건 기간보다 작으면 소스이전건,소스이후건으로 분리후에 이전건 업데이트 이후건 인서트
					if(	Integer.parseInt(salePriceMasterVO.getSpStaYmd()) < Integer.parseInt(sourceSalePriceMasterVO.getSpStaYmd())
						&&
						Integer.parseInt(salePriceMasterVO.getSpEndYmd()) > Integer.parseInt(sourceSalePriceMasterVO.getSpEndYmd())
					) {
						SalePriceMasterVO beforeMaster	= (SalePriceMasterVO)salePriceMasterVO.clone();
						SalePriceMasterVO afterMaster	= (SalePriceMasterVO)salePriceMasterVO.clone();
						beforeMaster.setSpEndYmd(DateUtil.addDay(sourceSalePriceMasterVO.getSpStaYmd(),-1));
						afterMaster.setSpStaYmd(DateUtil.addDay(sourceSalePriceMasterVO.getSpEndYmd(),1));
						salePriceMasterDao.updateSalePriceMasterMergeTarget(beforeMaster);
						salePriceMasterDao.createSalePriceMasterMergeTarget(afterMaster);
					}else {
						// 3. 소스 시작일 종료일 에 당건 시작일이 걸리면 당건 삭제 후 당건의 시작일을 소스종료일 +1 일로 변경후 입력
						if(	Integer.parseInt(salePriceMasterVO.getSpStaYmd()) >= Integer.parseInt(sourceSalePriceMasterVO.getSpStaYmd())
							&&
							Integer.parseInt(salePriceMasterVO.getSpStaYmd()) <= Integer.parseInt(sourceSalePriceMasterVO.getSpEndYmd())
						) {
							salePriceMasterDao.deleteSalePriceMasterMergeTarget(salePriceMasterVO);
							salePriceMasterVO.setSpStaYmd(DateUtil.addDay(sourceSalePriceMasterVO.getSpEndYmd(),1));
							salePriceMasterDao.createSalePriceMasterMergeTarget(salePriceMasterVO);
						}else {
							// 4. 소스 시작일 종료일 에 당건 종료일이 걸리면 당건 종료일을 소스시작일 -1 일로 변경후 업데이트
							if(	Integer.parseInt(salePriceMasterVO.getSpEndYmd()) >= Integer.parseInt(sourceSalePriceMasterVO.getSpStaYmd())
								&&
								Integer.parseInt(salePriceMasterVO.getSpEndYmd()) <= Integer.parseInt(sourceSalePriceMasterVO.getSpEndYmd())
							) {
								salePriceMasterVO.setSpEndYmd(DateUtil.addDay(sourceSalePriceMasterVO.getSpStaYmd(),-1));
								salePriceMasterDao.updateSalePriceMasterMergeTarget(salePriceMasterVO);
							}
						}
					}
				}
			}
			// 마지막에 소스 데이타 입력후 종료
			salePriceMasterDao.createSalePriceMasterMergeTarget(sourceSalePriceMasterVO);
		}
		// 판가마스터 수정이후 SAP전송 처리
		sendSalePriceMasterToSap(sourceSalePriceMasterVO);
	}

	private void sendSalePriceMasterToSap(SalePriceMasterVO salePriceMasterVO) {
		
		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		SalePriceMasterSpKind salePriceMasterSpKind = SalePriceMasterSpKind.getSalePriceMasterSpKind(salePriceMasterVO.getSpTypeKind());
		inputParam.put("I_GUBUN", salePriceMasterSpKind.getRfcGubun());
		inputParam.put("I_PERSNO", salePriceMasterVO.getRegiIdxx());
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("VKORG", salePriceMasterVO.getVkorg());   		//판매 조직
		paramMap.put("VTWEG", salePriceMasterVO.getVtweg());		//유통 경로
		paramMap.put("KUNNR", salePriceMasterVO.getKunnr());		//고객 번호
		paramMap.put("KUNWE", salePriceMasterVO.getIndoKunnr());	//납품처
		paramMap.put(salePriceMasterSpKind.getRfcColNmByGubun(), salePriceMasterVO.getSpType());	//가격리스트유형 or 최종인도처
		paramMap.put("MATNR", salePriceMasterVO.getMatnr().trim());	//자재 번호
		paramMap.put("KBETR", salePriceMasterVO.getPrice());		//판가
		paramMap.put("KONWA", salePriceMasterVO.getKonwa());		//통화
		paramMap.put("KPEIN", "1");									//조건가격결정단위
		paramMap.put("KMEIN", salePriceMasterVO.getKmein());		//조건단위
		paramMap.put("DATAB", salePriceMasterVO.getSpStaYmd());		//조건 레코드의 효력 시작일
		paramMap.put("DATBI", salePriceMasterVO.getSpEndYmd());		//조건 레코드의 효력 종료일
		tableParam.put("IT_DATA", paramMap);
		
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		
		logger.debug("I_GUBUN["+salePriceMasterSpKind.getRfcGubun()+"]");  
		logger.debug("I_PERSNO["+salePriceMasterVO.getRegiIdxx()+"]");  
		logger.debug("VKORG["+salePriceMasterVO.getVkorg()+"]");   		
		logger.debug("VTWEG["+salePriceMasterVO.getVtweg()+"]");		
		logger.debug("KUNNR["+salePriceMasterVO.getKunnr()+"]");		
		logger.debug("KUNWE["+salePriceMasterVO.getIndoKunnr()+"]");	
		logger.debug("SPTYPE_KIND["+salePriceMasterSpKind.getRfcColNmByGubun()+"]");	
		logger.debug("SPTYPE["+ salePriceMasterVO.getSpType()+"]");	
		logger.debug("MATNR["+salePriceMasterVO.getMatnr()+"]");		
		logger.debug("PRICE["+salePriceMasterVO.getPrice()+"]");		
		logger.debug("KONWA["+salePriceMasterVO.getKonwa()+"]");		
		logger.debug("KMEIN["+salePriceMasterVO.getKmein()+"]");		
		logger.debug("DATAB["+salePriceMasterVO.getSpStaYmd()+"]");		
		logger.debug("DATBI["+salePriceMasterVO.getSpEndYmd()+"]");		
		
		jcoConnector.executeFunction(FNC_SAP_CREATE_SALEPRICE, inputParam, outputParam, tableParam);
		
		String returnMsg = (String) outputParam.get("E_RETURN");
		Integer returnCode = (Integer) outputParam.get("E_SUBRC");
		logger.debug("#######SalePriceMasterToSap returnMsg["+returnMsg+"], returnCode["+returnCode+"]");
		
		if(returnCode != 0){
			throw new ServiceException(String.valueOf(returnCode),returnMsg);
		}
	}
	
	/**
	 * history 객체를 마스터 객체로 변환
	 * @param salePriceMasterHisVO
	 * @return
	 */
	private SalePriceMasterVO copySalePriceMasterHisVOToMasterVO(SalePriceMasterHisVO salePriceMasterHisVO) {
		SalePriceMasterVO salePriceMasterVO = new SalePriceMasterVO();
		salePriceMasterVO.setVkorg(salePriceMasterHisVO.getVkorg());
		salePriceMasterVO.setVtweg(salePriceMasterHisVO.getVtweg());
		salePriceMasterVO.setKunnr(salePriceMasterHisVO.getKunnr());
		salePriceMasterVO.setIndoKunnr(salePriceMasterHisVO.getIndoKunnr());
		salePriceMasterVO.setMatnr(salePriceMasterHisVO.getMatnr());
		salePriceMasterVO.setSpType(salePriceMasterHisVO.getSpType());
		salePriceMasterVO.setSpStaYmd(salePriceMasterHisVO.getSpStaYmd());
		salePriceMasterVO.setSpEndYmd(salePriceMasterHisVO.getSpEndYmd());
		salePriceMasterVO.setSpTypeKind(salePriceMasterHisVO.getSpTypeKind());
		salePriceMasterVO.setKonwa(salePriceMasterHisVO.getKonwa());
		salePriceMasterVO.setKmein(salePriceMasterHisVO.getKmein());
		salePriceMasterVO.setPrice(salePriceMasterHisVO.getPrice());
		salePriceMasterVO.setBigoText(salePriceMasterHisVO.getBigoText());
		salePriceMasterVO.setRegiIdxx(salePriceMasterHisVO.getRegiIdxx());
		salePriceMasterVO.setUpdtIdxx(salePriceMasterHisVO.getUpdtIdxx());

		return salePriceMasterVO;
	}

	/**
	 * history 마스터 객체를 history 객체로 변환
	 * @param salePriceMasterHisVO
	 * @return
	 */
	private SalePriceMasterHisVO copyMasterVOToSalePriceMasterHisVO(SalePriceMasterVO salePriceMasterVO) {
		SalePriceMasterHisVO salePriceMasterHisVO = new SalePriceMasterHisVO();
		salePriceMasterHisVO.setVkorg(salePriceMasterVO.getVkorg());
		salePriceMasterHisVO.setVtweg(salePriceMasterVO.getVtweg());
		salePriceMasterHisVO.setKunnr(salePriceMasterVO.getKunnr());
		salePriceMasterHisVO.setIndoKunnr(salePriceMasterVO.getIndoKunnr());
		salePriceMasterHisVO.setMatnr(salePriceMasterVO.getMatnr());
		salePriceMasterHisVO.setSpType(salePriceMasterVO.getSpType());
		salePriceMasterHisVO.setSpStaYmd(salePriceMasterVO.getSpStaYmd());
		salePriceMasterHisVO.setSpEndYmd(salePriceMasterVO.getSpEndYmd());
		salePriceMasterHisVO.setSpTypeKind(salePriceMasterVO.getSpTypeKind());
		salePriceMasterHisVO.setKonwa(salePriceMasterVO.getKonwa());
		salePriceMasterHisVO.setKmein(salePriceMasterVO.getKmein());
		salePriceMasterHisVO.setPrice(salePriceMasterVO.getPrice());
		salePriceMasterHisVO.setBigoText(salePriceMasterVO.getBigoText());
		salePriceMasterHisVO.setRegiIdxx(salePriceMasterVO.getRegiIdxx());
		salePriceMasterHisVO.setUpdtIdxx(salePriceMasterVO.getUpdtIdxx());
		salePriceMasterHisVO.setWorkGroupId(Util.getUUID());
		salePriceMasterHisVO.setSpCreYmd(DateUtil.getToday());

		return salePriceMasterHisVO;
	}

	@Override
	public void createMultiSalePriceMaster(SalePriceMasterHisVO param) {
		// 작업대상 리스트 선언
		List<SalePriceMasterHisVO> salePriceMasterHisList = new ArrayList<SalePriceMasterHisVO>();
		String workGroupId = Util.getUUID();
		
		// 받아온 기준으로 판매처에 인도처 리스트를 구한다.
		OrderProdJindVO indoVo = new OrderProdJindVO();
		indoVo.setTvkotVkorg(param.getVkorg());
		indoVo.setCompCode(param.getKunnr());
		List<OrderProdJindVO> indoList = commonService.getOrderDeliverList(indoVo);

		// 작업대상 리스트에 인도처리스트 맵핑
		for(OrderProdJindVO indo : indoList) {
			SalePriceMasterHisVO hisVo = (SalePriceMasterHisVO) param.clone();
			hisVo.setWorkGroupId(workGroupId);
			hisVo.setIndoKunnr(indo.getPartnNumb());
			salePriceMasterHisList.add(hisVo);
		}

		// 인도처 리스트 만큼 히스토리 저장
		for(SalePriceMasterHisVO hisVo : salePriceMasterHisList) {
			createSalePriceMaster(hisVo);
		}
	}

	@Override
	public void createMonthlyClose(SalePriceCloseVO param) {
		salePriceMasterDao.deleteMonthlyCloseDetail(param);
		salePriceMasterDao.createMonthlyClose(param);
	}

	@Override
	public int getMonthlyCloseListCount(SalePriceCloseVO param) {
		return salePriceMasterDao.getMonthlyCloseListCount(param);
	}

	@Override
	public List<SalePriceCloseVO> getMonthlyCloseList(SalePriceCloseVO param) {
		return salePriceMasterDao.getMonthlyCloseList(param);
	}

	@Override
	public void cancelBilling(DirectOrderMasterVO[] orderList) {
		for(DirectOrderMasterVO orderVO : orderList) {
			cancelBilling(orderVO);
		}
	}

	private void cancelBilling(DirectOrderMasterVO orderVO) {
		if(orderVO.getVbeln() != null && !orderVO.getVbeln().equals("")) {
			JcoTableParam tableParam = new JcoTableParam();
			Map<String, Object> inputParam = new HashMap<String, Object>();
			inputParam.put("I_PERSNO", orderVO.getRegiIdxx());

			Map<String, Object> outputParam = new HashMap<String, Object>();
			Map<String, Object> orderMap = new HashMap<String, Object>();
			orderMap.put("SIGN", "I");
			orderMap.put("OPTION", "EQ");
			orderMap.put("LOW", orderVO.getVbeln());
			orderMap.put("HIGH", "");
			tableParam.put("VBELNRANGE", orderMap);

			jcoConnector.executeFunction(FNC_SAP_CANCEL_BILLING, inputParam, outputParam, tableParam);

			boolean isSuccess = false;
		    StringBuffer message = new StringBuffer();
			if(outputParam.get("E_SUBRC").toString().equals("0")) {
				logger.error(outputParam.get("E_RETURN").toString().trim() + " : " + orderVO.getVbeln());
				message.append(outputParam.get("E_RETURN").toString().trim() + " : " + orderVO.getVbeln() +"\n");
				isSuccess = true;
			}
			if(!isSuccess) {
				logger.error(outputParam.get("E_RETURN").toString().trim() + " : " + orderVO.getVbeln());
				message.append(outputParam.get("E_RETURN").toString().trim() + " : " + orderVO.getVbeln() +"\n");
				ServiceException se = new ServiceException();
				se.setErrorMsg("ERP : 오더번호 " + orderVO.getVbeln() + " " + message.toString());
				throw se;
			}
		}
	}

	@Override
	public void postBilling(DirectOrderMasterVO[] orderList) {
		for(DirectOrderMasterVO orderVO : orderList) {
			postBilling(orderVO);
		}
	}

	private void postBilling(DirectOrderMasterVO orderVO) {
		if(orderVO.getVbeln() != null && !orderVO.getVbeln().equals("")) {
			JcoTableParam tableParam = new JcoTableParam();
			Map<String, Object> inputParam = new HashMap<String, Object>();
			inputParam.put("I_PERSNO", orderVO.getRegiIdxx());

			Map<String, Object> outputParam = new HashMap<String, Object>();
			Map<String, Object> orderMap = new HashMap<String, Object>();
			orderMap.put("SIGN", "I");
			orderMap.put("OPTION", "EQ");
			orderMap.put("LOW", orderVO.getVbeln());
			orderMap.put("HIGH", "");
			tableParam.put("VBELNRANGE", orderMap);

			jcoConnector.executeFunction(FNC_SAP_POST_BILLING, inputParam, outputParam, tableParam);

			boolean isSuccess = false;
		    StringBuffer message = new StringBuffer();
			if(outputParam.get("E_SUBRC").toString().equals("0")) {
				logger.error(outputParam.get("E_RETURN").toString().trim() + " : " + orderVO.getVbeln());
				message.append(outputParam.get("E_RETURN").toString().trim() + " : " + orderVO.getVbeln() +"\n");
				isSuccess = true;
			}
			if(!isSuccess) {
				logger.error(outputParam.get("E_RETURN").toString().trim() + " : " + orderVO.getVbeln());
				message.append(outputParam.get("E_RETURN").toString().trim() + " : " + orderVO.getVbeln() +"\n");
				ServiceException se = new ServiceException();
				se.setErrorMsg("ERP : 오더번호 " + orderVO.getVbeln() + " " + message.toString());
				throw se;
			}
		}
	}

	@Override
	public int getPriceMasterExistsOrderListCount(SalePriceCloseVO param) {
		return salePriceMasterDao.getPriceMasterExistsOrderListCount(param);
	}

	@Override
	public List<SalePriceMasterVO> getPriceMasterExistsOrderList(SalePriceCloseVO param) {
		List<SalePriceMasterVO> returnList = salePriceMasterDao.getPriceMasterExistsOrderList(param);
		OrderProdJindVO indoVo = null;
		//인도처 이름 받아오기
		for(SalePriceMasterVO returnVo : returnList) {
			indoVo = new OrderProdJindVO();
			indoVo.setJindIdxx(returnVo.getIndoKunnr());
			List<OrderProdJindVO> jindList = commonService.getOrderJindSearch(indoVo);
			if(jindList.size() != 0) {
				String indoName = jindList.get(0).getNAME1();
				returnVo.setIndoName(indoName);
			}
			//최종인도처 존재할 경우
			if(returnVo.getSpTypeKind().equals("PATNR")) {
				indoVo.setJindIdxx(returnVo.getSpType());
				List<OrderProdJindVO> finalJindList = commonService.getOrderJindSearch(indoVo);
				if(finalJindList.size() != 0) {
					String lastIndoName = finalJindList.get(0).getNAME1();
					returnVo.setFinalIndo(lastIndoName);
				}
			}
		}
		return returnList;
	}

	@Override
	public int getOrderByPriceListCount(SalePriceMasterVO param) {
		return salePriceMasterDao.getOrderByPriceListCount(param);
	}

	@Override
	public List<DirectOrderMasterVO> getOrderByPriceList(SalePriceMasterVO param) {
		List<DirectOrderMasterVO> masterList = salePriceMasterDao.getOrderByPriceList(param);
		if(masterList.size() > 0) {
			directOrderService.setSapOrderStatus(null, masterList);
		}
		return masterList;
	}

	@Override
	public SalePriceCloseVO getSingleMonthlyClose(SalePriceCloseVO param) {
		return salePriceMasterDao.getSingleMonthlyClose(param);
	}

	@Override
	public void confirmPriceMasterAndUpdateOrder(SalePriceMasterVO param) {
		String spStaYmd = param.getSpStaYmd();
		param.setSpStaYmd(param.getSearchDate());
		//해당 주문 조회
		List<DirectOrderMasterVO> orderMasterList = salePriceMasterDao.getOrderByPriceList(param);
		//판가마스터 변경
		param.setBigoText("판가월마감 확정판가");
		param.setSpStaYmd(spStaYmd);
		createSalePriceMaster(copyMasterVOToSalePriceMasterHisVO(param));

		List<DirectOrderItemVO> itemList = null;
		
		for(DirectOrderMasterVO orderMaster : orderMasterList) {
			itemList = new ArrayList<DirectOrderItemVO>();
			orderMaster.setUpdtIdxx(param.getUpdtIdxx());
			orderMaster.setOrderItemList(directOrderDao.getDirectOrderItemList(orderMaster.getOrderId()));
			for(DirectOrderItemVO item : orderMaster.getOrderItemList()) {
				if(param.getMatnr().equals(item.getMaterial()) && param.getKmein().equals(item.getCondUnit()) && param.getKonwa().equals(item.getCurrency())) {
					item.setPr00Price(param.getPrice());
					itemList.add(item);
				}
			}
			directOrderService.updateDirectOrderSkipShipment(orderMaster);
		}
	}

	@Override
	public List<SalePriceCloseDtlVO> getMonthlyCloseDetailList(SalePriceCloseVO param) {
		SalePriceCloseVO salePriceCloseVO = (SalePriceCloseVO) StringUtil.nullToEmptyString(salePriceMasterDao.getSingleMonthlyClose(param));
		List<DDLBItem> land1List = sapSearchService.getSapCommonCodeList("06");
		List<SalePriceCloseDtlVO> returnList;

		if(!(salePriceCloseVO.getWorkStat().equals("I") || salePriceCloseVO.getApprStat().equals(ApprState.APPR_REJECT.getCode()) || salePriceCloseVO.getApprStat().equals(ApprState.CONF_REJECT.getCode()))) { //작성완료 이고 반려가 아니면 수정불가
			returnList = salePriceMasterDao.getMonthlyCloseDetailListAfterFinish(param);
			OrderProdJindVO indoVo = null;
			//인도처 이름 받아오기
			for(SalePriceCloseDtlVO returnVo : returnList) {
				indoVo = new OrderProdJindVO();
				indoVo.setJindIdxx(returnVo.getIndoKunnr());
				List<OrderProdJindVO> jindList = commonService.getOrderJindSearch(indoVo);
				if(jindList.size() != 0) {
					String indoName = jindList.get(0).getNAME1();
					returnVo.setIndoName1(indoName);
				}
				//최종인도처 존재할 경우
				if(returnVo.getSpTypeKind().equals("PATNR")) {
					indoVo.setJindIdxx(returnVo.getSpType());
					List<OrderProdJindVO> finalJindList = commonService.getOrderJindSearch(indoVo);
					if(finalJindList.size() != 0) {
						String lastIndoName = finalJindList.get(0).getNAME1();
						returnVo.setFinalIndoName1(lastIndoName);
					}
				}
			}
		} else {
			returnList = salePriceMasterDao.getMonthlyCloseDetailListBeforeFinish(param);
		}

		for(SalePriceCloseDtlVO closeVO : returnList) {
			closeVO = (SalePriceCloseDtlVO)StringUtil.nullToEmptyString(closeVO);
			closeVO.setPriceGap(BigDecimal.valueOf(closeVO.getPrice()).subtract(BigDecimal.valueOf(closeVO.getPrePrice01())).doubleValue());
			for(DDLBItem item : land1List)
				if(closeVO.getLand1().equals(item.getCode())) {
					closeVO.setLand1(item.getText());
					break;
				}
		}
		setFobData(returnList);

		return returnList;
	}

	@Override
	public void updateMonthlyClose(SalePriceCloseVO param) {
		salePriceMasterDao.updateMonthlyClose(param);
		if(param.getSalePriceCloseDtlList().size() > 0) {
			salePriceMasterDao.deleteMonthlyCloseDetail(param);
		}
		for(SalePriceCloseDtlVO detail : param.getSalePriceCloseDtlList()) {
			detail.setRegiIdxx(param.getRegiIdxx());
			detail.setUpdtIdxx(param.getUpdtIdxx());
			salePriceMasterDao.insertMonthlyCloseDetail(detail);
		}
	}

	@Override
	public void updateMonthlyCloseApprId(SalePriceCloseVO[] params) {
		for(SalePriceCloseVO param : params) {
			salePriceMasterDao.updateMonthlyCloseApprId(param);
		}
	}

	@Override
	public int getDifferentOrderPriceAndMasterCount(DirectOrderSimpleVO param) {
		return salePriceMasterDao.getDifferentOrderPriceAndMasterCount(param);
	}

	@Override
	public List<DirectOrderSimpleVO> getDifferentOrderPriceAndMasterList(DirectOrderSimpleVO param) {
		return salePriceMasterDao.getDifferentOrderPriceAndMasterList(param);
	}

	@Override
	public void updateOrderPriceByPriceMaster(DirectOrderSimpleVO[] params) {
		DirectOrderMasterVO orderMaster = null;
		for(DirectOrderSimpleVO param : params) {
			//해당 주문 조회
			orderMaster = directOrderDao.getDirectOrderMaster(param.getOrderId());
			orderMaster.setUpdtIdxx(param.getUpdtIdxx());
			orderMaster.setOrderItemList(directOrderDao.getDirectOrderItemList(orderMaster.getOrderId()));
			for(DirectOrderItemVO item : orderMaster.getOrderItemList()) {
				if(param.getSeq() == item.getSeq()) {
					item.setPr00Price(param.getPrice());
				}
			}
			//진행상태 가져오기
			directOrderService.setSapOrderStatus(null, Arrays.asList(orderMaster));
			if(orderMaster.getProcStat().equals(OrderStatus.BILLING_COMPLETE.getCode())) {	//빌링단계까지 진행되었으면 취소후 수정하고 다시 빌링생성
				cancelBilling(orderMaster);
				logger.debug("주문번호 : " + orderMaster.getOrderId() + " 처리중");
				for(int i = 1 ; i < 20 ; i++) {	//빌링이 최종취소 될때까지 시간이 걸린다.. 얼마나 걸리는진 모른다...
					try {
						Thread.sleep(500);	//0.5초 대기
						directOrderService.setSapOrderStatus(null, Arrays.asList(orderMaster));
						if(!orderMaster.getProcStat().equals(OrderStatus.BILLING_COMPLETE.getCode())) {
							directOrderService.updateDirectOrderSkipShipment(orderMaster);
							postBilling(orderMaster);
							logger.debug("주문번호 : " + orderMaster.getOrderId() + " 처리완료 " + i + " seconds");
							continue;
						}
					} catch (InterruptedException e) {
						logger.error(e.getMessage());
					}
				}
			} else {
				directOrderService.updateDirectOrderSkipShipment(orderMaster);
			}
		}
	}

	@Override
	public void changeSalePriceCloseStatus(SalePriceCloseVO param) {
		salePriceMasterDao.changeSalePriceCloseStatus(param);
	}

	@Override
	public void updateOrderByNewPriceMaster(DirectOrderMasterVO param) {
		DirectOrderMasterVO orderMaster = directOrderDao.getDirectOrderMaster(param.getOrderId());
		orderMaster.setUpdtIdxx(param.getUpdtIdxx());
		orderMaster.setOrderItemList(directOrderDao.getDirectOrderItemList(orderMaster.getOrderId()));
		for(DirectOrderItemVO item : orderMaster.getOrderItemList()) {
			if(param.getSeq().equals(item.getSeq()+"")) {
				item.setPr00Price(Integer.parseInt(param.getPr00Price()));
				item.setPriceListI(param.getPriceListI());
			}
		}
		directOrderService.updateDirectOrderSkipShipment(orderMaster);
	}

	private void setFobData(List<SalePriceCloseDtlVO> closeList) {
		JcoTableParam tableParam = new JcoTableParam();
		List<HashMap> closeListTemp = new ArrayList<HashMap>();
		Map<String, Object> inputParam = new HashMap<String, Object>();

		if(closeList.size() > 0)
			inputParam.put("I_SPMON", closeList.get(0).getYyyymm().replace(".", ""));

		for(SalePriceCloseDtlVO closeVO : closeList) {
			HashMap<String, Object> closeMap = new HashMap<String, Object>();
			closeMap.put("MATNR", closeVO.getMatnr());
			closeMap.put("VTWEG", closeVO.getVtweg());
			closeMap.put("WAERK", closeVO.getKonwa());
			closeMap.put("KUNNR", closeVO.getKunnr());
			closeMap.put("SALETYP", closeVO.getSpType());
			closeMap.put("ZEKUNWE", closeVO.getIndoKunnr());
			closeMap.put("SALEQNTY", closeVO.getMatnrCnt());
			closeMap.put("SALEAMT4", closeVO.getPrePrice03());
			closeMap.put("SALEAMT3", closeVO.getPrePrice02());
			closeMap.put("SALEAMT2", closeVO.getPrePrice01());
			closeMap.put("SALEAMT1", closeVO.getPrice());

			closeListTemp.add(closeMap);
		}
		tableParam.put("IT_DATA", closeListTemp);

		jcoConnector.executeFunction(FNC_SAP_FOB_PRICE, inputParam, tableParam);
		List<SalePriceCloseDtlVO> output = (List<SalePriceCloseDtlVO>) tableParam.get("ET_DATA", SalePriceCloseDtlVO.class);

		for(int i = 0; i < closeList.size(); i++) {
			SalePriceCloseDtlVO close = closeList.get(i);
			SalePriceCloseDtlVO data = output.get(i);

			boolean krw = "KRW".equals(close.getKonwa());

//			String price3 = close.getPrePrice03() + "";
//			String price2 = close.getPrePrice02() + "";
//			String price1 = close.getPrePrice01() + "";
//			String price0 = close.getPrice() + "";
//			String priceGap = close.getPriceGap() + "";
//
//			int length3 = price3.substring(price3.indexOf(".") + 1).length();
//			int length2 = price2.substring(price2.indexOf(".") + 1).length();
//			int length1 = price1.substring(price1.indexOf(".") + 1).length();
//			int length0 = price0.substring(price0.indexOf(".") + 1).length();
//			int lengthGap = priceGap.substring(priceGap.indexOf(".") + 1).length();

			close.setPackUnit("1000".equals(close.getVkorg()) && ("DRUM".equals(data.getPackUnit()) || "BULK".equals(data.getPackUnit())) ? data.getPackUnit() : "");
			close.setFobamt4(NumberFormat.getInstance().format(krw ? Math.round(Double.parseDouble(data.getFobamt4())) : Math.round(Double.parseDouble(data.getFobamt4()) * Math.pow(10, 3)) / Math.pow(10, 3)));
			close.setFobamt3(NumberFormat.getInstance().format(krw ? Math.round(Double.parseDouble(data.getFobamt3())) : Math.round(Double.parseDouble(data.getFobamt3()) * Math.pow(10, 3)) / Math.pow(10, 3)));
			close.setFobamt2(NumberFormat.getInstance().format(krw ? Math.round(Double.parseDouble(data.getFobamt2())) : Math.round(Double.parseDouble(data.getFobamt2()) * Math.pow(10, 3)) / Math.pow(10, 3)));
			close.setFobamt1(NumberFormat.getInstance().format(krw ? Math.round(Double.parseDouble(data.getFobamt1())) : Math.round(Double.parseDouble(data.getFobamt1()) * Math.pow(10, 3)) / Math.pow(10, 3)));
			close.setFobamtGap(NumberFormat.getInstance().format(krw ? Math.round(Double.parseDouble(data.getFobamt1()) - Double.parseDouble(data.getFobamt2())) : Math.round((Double.parseDouble(data.getFobamt1()) - Double.parseDouble(data.getFobamt2())) * Math.pow(10, 3)) / Math.pow(10, 3)));
		}
	}
}
