package com.lgmma.salesPortal.partnerapp.controller;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.controller.CommonController;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;
import com.lgmma.salesPortal.app.model.OrganVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.CompanyService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.app.service.WebAccountService;
import com.lgmma.salesPortal.common.model.DDLBItem;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;


@Controller
@RequestMapping("/partner")
public class PartnerSalesExpController {

	@Autowired
	CommonService commonService;
	
	@Autowired
	SapSearchService sapSearchService;
	
	@Autowired
	CommonController commonController;
	
	@RequestMapping(value = "/partnerSalesExpInfo")
	public ModelAndView partnerSalesExpInfo(ModelAndView mav) throws Exception {
		String param = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getSawnCode();
		mav.setViewName("partner/salesExp/partnerSalesExpInfo");
		mav.addObject("vkorgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("defaultYm", DateUtil.getCurrentYear().concat(".").concat(DateUtil.getToday().substring(4, 6)));
		mav.addObject("kvgr3", commonService.getKvgr3(param));
		return mav;
	}

	@RequestMapping(value = "/getPartSalesExpList.json")
	public Map getPartSalesExpList(@RequestParam(required=false) String ispmon, @RequestParam(required=false) String ivkorg, @RequestParam(required=false) String ikvgr3) throws Exception {
		List<Map> partSalesExpList = sapSearchService.getPartSalesExpList(ispmon, ivkorg, ikvgr3);
		
		for(Map sales : partSalesExpList) {
			sales.put("note", sales.get("NOTE"));
			sales.put("value3", sales.get("VALUE3"));
			sales.put("value1", sales.get("VALUE1"));
			sales.put("kvgr3", sales.get("KVGR3"));
		}
		return JsonResponse.asSuccess("storeData", partSalesExpList);
	}
	
	@RequestMapping(value = "/getPartSalesExpView.json")
	public Map getPartSalesExpView(@RequestParam(required=false) String ispmon, @RequestParam(required=false) String ivkorg, @RequestParam(required=false) String ikunnr, @RequestParam(required=false) String ikvgr3) throws Exception {
		List<Map> partSalesExpView = sapSearchService.getPartSalesExpView(ispmon, ivkorg, ikunnr,  ikvgr3);
		
		for(Map sales : partSalesExpView) {
			sales.put("note", sales.get("NOTE"));
			sales.put("value1", sales.get("VALUE1"));
			sales.put("value2", sales.get("VALUE2"));
			sales.put("sort", sales.get("SORT"));	
		}
		return JsonResponse.asSuccess("storeData", partSalesExpView);
	}
}
