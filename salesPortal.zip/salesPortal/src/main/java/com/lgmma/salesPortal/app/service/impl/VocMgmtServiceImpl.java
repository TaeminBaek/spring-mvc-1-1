package com.lgmma.salesPortal.app.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.dao.VocDao;
import com.lgmma.salesPortal.app.model.OrderProdJindVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.model.VocActPopVO;
import com.lgmma.salesPortal.app.model.VocActVO;
import com.lgmma.salesPortal.app.model.VocGradeVO;
import com.lgmma.salesPortal.app.model.VocSendMailToCustVO;
import com.lgmma.salesPortal.app.model.VocSendMailToEmpVO;
import com.lgmma.salesPortal.app.model.VocTypeVO;
import com.lgmma.salesPortal.app.model.VocVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.VocMgmtService;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;
import com.lgmma.salesPortal.security.authentication.UserInfo;

@Service
public class VocMgmtServiceImpl implements VocMgmtService{
	
	private final String FNC_SAP_INDO_NM = "ZSDE01_MASTER_SELECT";	

	@Autowired
	VocDao vocDao;
	
    @Autowired
	private JcoConnector jcoConnector;	
    
    @Autowired
    private MailingService mailingService;
    
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private MessageSourceAccessor messageSourceAccessor;	
	@Override
	public int getVocListCount(VocVO param) {
		return vocDao.getVocListCount(param);
	}

	@Override
	public List<VocVO> getVocList(VocVO param) {
		return vocDao.getVocList(param);
	}

	@Override
	public VocVO getVocDetail(VocVO param) {
		UserInfo loginUserInfo = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo();
		String loginUserType = loginUserInfo.getUserType();
		//VOC상세조회
		VocVO returnItem = vocDao.getVocDetail(param);
				
		if(returnItem.getTvkotVkorg() != null && returnItem.getTvkotVkorg() != "") {
			returnItem.setVkorgText(Vkorg.getVkorg(returnItem.getTvkotVkorg()).getName());
		}
		if(returnItem.getReqxDate() != null && returnItem.getReqxDate() != ""
			&& returnItem.getReqxHour() != null && returnItem.getReqxHour() != "") {
			returnItem.setReqxDtFmt(returnItem.getReqxDate().replace("-", ".") + " " +returnItem.getReqxHour()+":00");
		}

		if(returnItem.getIndoIdxx() != null && returnItem.getIndoIdxx() != "") {
			//ERP인도처명 AS-IS			
//    		JcoTableParam tableParam = new JcoTableParam();
//    		Map<String, Object> outputParams = null;
//    		Map<String, Object> inputParams = new HashMap<String, Object>();
//    		
//    		inputParams.put("I_GUBUN","CA");
//
//			Map<String, Object> paramMap_IndoIdxx = new HashMap<String, Object>();
//			paramMap_IndoIdxx.put("SIGN", "I");
//			paramMap_IndoIdxx.put("OPTION", "EQ");
//			paramMap_IndoIdxx.put("LOW", returnItem.getIndoIdxx());
//			paramMap_IndoIdxx.put("HIGH", null);
//			tableParam.put("CUSTOMERRANGE", paramMap_IndoIdxx);
//
//			jcoConnector.executeFunction(FNC_SAP_INDO_NM ,inputParams ,outputParams ,tableParam);
//			List<Map> partnerList = (List<Map>) tableParam.get("T_BAPIPARNR");
//			List<HashMap> deliverListTemp = new ArrayList<HashMap>();
//			for(Map item : partnerList) {
//				if(item.get("PARTN_ROLE").equals("WE")) {
//					returnItem.setIndoName(StringUtil.isNullToString(item.get("NAME")));
//					break;
//				}
//			}
			//인도처 명 맵핑 TO-BE
			OrderProdJindVO paramJind = new OrderProdJindVO();
			paramJind.setCompCode(returnItem.getIndoIdxx());
			paramJind.setTvkotVkorg(returnItem.getTvkotVkorg());
			List<OrderProdJindVO> indoList = commonService.getOrderDeliverList(paramJind);
			if(indoList != null){
				for(OrderProdJindVO indo : indoList){
					if(indo.getPartnNumb().equals(returnItem.getIndoIdxx())){
						returnItem.setIndoName(indo.getName());
					}
				}
			}
		}
		//제품조회
		List<VocGradeVO> vocGradeList = vocDao.getVocGradeList(param); 
		returnItem.setVocGradeList(vocGradeList);
		//임직원 로그인시
		if(StringUtil.isNullToString(loginUserType).equals("E")) {
			//Activity 조회
			List<VocActVO> vocActList = vocDao.getVocActList(param); 
			returnItem.setVocActList(vocActList);
		}
		//VOC세부유형 조회
		List<VocTypeVO> vocTypeList = vocDao.getVocTypeList(param); 
		returnItem.setTypeCodeList(vocTypeList);
		//파트너사 로그인시
		if(StringUtil.isNullToString(loginUserType).equals("P")) {
			//VOC 접수 이력
			VocActVO vocCustActInputHis = vocDao.getVocCustActInputHis(param); 
			returnItem.setVocCustActInputHis(vocCustActInputHis);
			//VOC 답변 이력
			VocActVO vocCustActAnswerHis = vocDao.getVocCustActAnswerHis(param); 
			returnItem.setVocCustActAnswerHis(vocCustActAnswerHis);
		}
		return returnItem; 
	}
	
	@Override
	public List<VocActVO> getVocActList(VocVO param) {
		return vocDao.getVocActList(param);
	}
	
	@Override
	public void createVocMgmt(VocVO param) {
		String srvcCode = param.getSrvcCode();
		String divxCode = param.getDivxCode();
		int cntTypeCode = param.getTypeCodeList().size();
		//고객서비스접수 등록
		vocDao.createVoc(param);
		//Activity활동 등록
		vocDao.createVocAct(param);
		//기존샘플요청_샘플
		if(srvcCode.equals("S006") && divxCode.equals("001")) {
			for(VocGradeVO vo : param.getVocGradeList()) {
				vo.setVocxIdxx(param.getVocxIdxx());
				vocDao.createVocGrade(vo);
			}
		}
		//VOC 세부유형 등록
		if(cntTypeCode > 0) {
			for(VocTypeVO vo : param.getTypeCodeList()) {
				vo.setTypeCode(vo.getTypeCode());
				vo.setVocxIdxx(param.getVocxIdxx());
				vocDao.createVocType(vo);
			}
		}
		//메일전송 : 임직원
		VocSendMailToEmpVO vocSendMailToEmpVO = (VocSendMailToEmpVO)StringUtil.nullToEmptyString(vocDao.getVocSendMailToEmp(param));
		
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("VOC_ORG", vocSendMailToEmpVO.getVocOrg());
		paramMap.put("REG_COMP", vocSendMailToEmpVO.getRegComp());
		paramMap.put("REQ_COMP", vocSendMailToEmpVO.getReqComp());
		paramMap.put("REG_NAME", vocSendMailToEmpVO.getRegName());
		paramMap.put("REG_HP", vocSendMailToEmpVO.getRegHp());
		paramMap.put("REG_DATE", vocSendMailToEmpVO.getRegDate());
		paramMap.put("SVC_NAME", vocSendMailToEmpVO.getSvcName());
		paramMap.put("SCV_DIV", vocSendMailToEmpVO.getScvDiv());
		paramMap.put("REQ_TITL", vocSendMailToEmpVO.getReqTitl());
		paramMap.put("REQ_TEXT", StringUtil.htmlEncodeWithBR(vocSendMailToEmpVO.getReqText()).replace("<br>", "<br>&nbsp;"));

		SendMailVO sendMailVO = new SendMailVO();
		sendMailVO.setSenderEmail(vocSendMailToEmpVO.getRegEmail());
		sendMailVO.setReceiverEmail(vocSendMailToEmpVO.getEmpEmail());
		sendMailVO.setReceiverName(vocSendMailToEmpVO.getEmpName());
		sendMailVO.setParams(paramMap);
		sendMailVO.setMailType(MailType.VOC_REGISTER_TO_SALES);
		sendMailVO.setTitle("[SFA]고객서비스 - "+vocSendMailToEmpVO.getReqTitl());

		mailingService.sendMail(sendMailVO);
	}
	
	@Override
	public void updateVocMgmt(VocVO param) {
		
		String srvcCode = param.getSrvcCode();
		String divxCode = param.getDivxCode();
		int cntTypeCode = param.getTypeCodeList().size();
		//VOC 제품 삭제
		vocDao.deleteVocGrade(param);
		//VOC 상세 유형 삭제
		vocDao.deleteVocType(param);
		//고객서비스접수 수정
		vocDao.updateVoc(param);
		//기존샘플요청_샘플
		if(srvcCode.equals("S006") && divxCode.equals("001")) {
			for(VocGradeVO vo : param.getVocGradeList()) {
				vo.setVocxIdxx(param.getVocxIdxx());
				vocDao.createVocGrade(vo);
			}
		}
		//VOC 세부유형 등록
		if(cntTypeCode > 0) {
			for(VocTypeVO vo : param.getTypeCodeList()) {
				vo.setTypeCode(vo.getTypeCode());
				vo.setVocxIdxx(param.getVocxIdxx());
				vocDao.createVocType(vo);
			}
		}
		//메일전송 : 임직원
		VocSendMailToEmpVO vocSendMailToEmpVO = (VocSendMailToEmpVO)StringUtil.nullToEmptyString(vocDao.getVocSendMailToEmp(param));
		
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("VOC_ORG", vocSendMailToEmpVO.getVocOrg());
		paramMap.put("REG_COMP", vocSendMailToEmpVO.getRegComp());
		paramMap.put("REQ_COMP", vocSendMailToEmpVO.getReqComp());
		paramMap.put("REG_NAME", vocSendMailToEmpVO.getRegName());
		paramMap.put("REG_HP", vocSendMailToEmpVO.getRegHp());
		paramMap.put("REG_DATE", vocSendMailToEmpVO.getRegDate());
		paramMap.put("SVC_NAME", vocSendMailToEmpVO.getSvcName());
		paramMap.put("SCV_DIV", vocSendMailToEmpVO.getScvDiv());
		paramMap.put("REQ_TITL", vocSendMailToEmpVO.getReqTitl());
		paramMap.put("REQ_TEXT", StringUtil.htmlEncodeWithBR(vocSendMailToEmpVO.getReqText()).replace("<br>", "<br>&nbsp;"));

		SendMailVO sendMailVO = new SendMailVO();
		sendMailVO.setSenderEmail(vocSendMailToEmpVO.getRegEmail());		
		sendMailVO.setReceiverEmail(vocSendMailToEmpVO.getEmpEmail());
		sendMailVO.setReceiverName(vocSendMailToEmpVO.getEmpName());
		sendMailVO.setParams(paramMap);
		sendMailVO.setMailType(MailType.VOC_REGISTER_TO_SALES);
		sendMailVO.setTitle("[SFA]고객서비스 - "+vocSendMailToEmpVO.getReqTitl());

		mailingService.sendMail(sendMailVO);
	}
	
	@Override
	public void deleteVocMgmt(VocVO param) {
		//VOC 고객서비스접수 삭제
		vocDao.deleteVoc(param);
		//VOC 제품 삭제
		vocDao.deleteVocGrade(param);
		//VOC 상세 유형 삭제
		vocDao.deleteVocType(param);
		//VOC Activity활동 삭제
		vocDao.deleteVocAct(param);
	}
	
	@Override
	public VocActPopVO getVocActPop(VocActVO param) {
		VocActPopVO returnItem = vocDao.getVocActPop(param);
		
		return returnItem;
	}	
	
	@Override
	public VocActPopVO getPersonFind(VocActVO param) {
		VocActPopVO returnItem = vocDao.getPersonFind(param);
		
		return returnItem;
	}		
	
	@Override
	public VocActPopVO getActivityName(VocActPopVO param) {
		VocActPopVO returnItem = vocDao.getActivityName(param);
		
		return returnItem;
	}
	
	@Override
	public void saveVocActPop(VocActPopVO param) {
		String vocxStat = param.getVocxStat();
		int workSeqx = 0;
        String actxCode = ""; //activity code
        String acptIdxx = ""; //처리자id
        String mustIsxx = ""; //프로세스 상태 
        String stat ="";      //voc 상태
        String oldActxCode = param.getActxCode(); //메일 보낼시 사용
        int oldVactIdxx = param.getVactIdxx(); //메일 보낼시 사용        
		
		workSeqx = param.getLevlNumx()+1;

		//Vocact 업데이트
		vocDao.updateVocActPop(param);		
		//상태변경
		if(param.getActxCode().equals("A002")) {
			stat = "P";
		}else if(param.getActxCode().equals("A021")) {
			stat = "C";
		}else if(!param.getActxCode().equals("A021") && param.getLevlNumx() == 3) {
			stat = "S";
		}
		//접수,진행중(접수이후처음단계),답변처리일경우 고객 tbs_voc테이블에 진행상태 update
		if(param.getActxCode().equals("A002") || param.getActxCode().equals("A021") 
				|| (!param.getActxCode().equals("A021") && param.getLevlNumx() == 3)) {
			param.setVocxStat(stat);
			vocDao.updateVocActPopStat(param);
		}
		//접수 다음 Activity
		if(param.getActxCode().equals("A002")){
			//샘플 접수는 다음 Activity 품의
			if(param.getSrvcCode().equals("S006")
					&& param.getDivxCode().equals("001")) {
				actxCode = "A003";
			//이외엔 답변완료
			}else {
				actxCode = "A021";
			}
			//품의 다음 Activity			
		}else if(param.getActxCode().equals("A003")){		
			actxCode = "A021";
		}
		//답변완료 종료
		if(!param.getActxCode().equals("A021")){
			//다음 ACT 등록
			param.setActxCode(actxCode);
			param.setLevlNumx(workSeqx);		
			vocDao.createVocActPop(param);
		}
		//메일전송시 변경
		param.setActxCode(oldActxCode);
		param.setVactIdxx(oldVactIdxx);
		
		String fromName = "";
		//직원 메일 주소 정보
		VocSendMailToEmpVO vocSendMailToEmpVOInfo = vocDao.getVocSendMailToEmpInfo(param);
		//발신자 명
		fromName = vocSendMailToEmpVOInfo.getFromName();
		//내부 직원 메일 발송
		if(!StringUtil.isNullToString(vocSendMailToEmpVOInfo.getToMail()).equals("") 
				&& !StringUtil.isNullToString(vocSendMailToEmpVOInfo.getToMail()).equals("")){
			//직원 메일 내용 정보
			List<VocSendMailToEmpVO> vocSendMailToEmpVOIn = vocDao.getVocSendMailToEmpInList(param);
			if(vocSendMailToEmpVOIn != null) {
				//메일전송 : 임직원 내부
				Map<String, String> paramMap = new HashMap<String, String>();
				paramMap.put("VOCX_IDXX",vocSendMailToEmpVOIn.get(0).getVocxIdxx());
				paramMap.put("SRVC_CODE",vocSendMailToEmpVOIn.get(0).getSrvcCode());
				paramMap.put("DIVX_CODE",vocSendMailToEmpVOIn.get(0).getDivxCode());
				paramMap.put("SRVC_NAME",vocSendMailToEmpVOIn.get(0).getSrvcName());
				paramMap.put("DIVX_NAME",vocSendMailToEmpVOIn.get(0).getDivxName());
				paramMap.put("TITL_TEXT",vocSendMailToEmpVOIn.get(0).getTitlText());
				paramMap.put("ACPT_DATE",vocSendMailToEmpVOIn.get(0).getAcptDate());
				paramMap.put("CONT_TEXT",StringUtil.htmlEncodeWithBR(vocSendMailToEmpVOIn.get(0).getContText()));
				paramMap.put("REGI_COMPNAME",vocSendMailToEmpVOIn.get(0).getRegiCompname());
				paramMap.put("ACTX_NAME",vocSendMailToEmpVOIn.get(0).getActxName());
				paramMap.put("FROM_NAME",fromName);
				if(!param.getActxCode().equals("A021")) {
					paramMap.put("VOCX_IDXX1",vocSendMailToEmpVOIn.get(1).getVocxIdxx());
					paramMap.put("SRVC_CODE1",vocSendMailToEmpVOIn.get(1).getSrvcCode());
					paramMap.put("DIVX_CODE1",vocSendMailToEmpVOIn.get(1).getDivxCode());
					paramMap.put("SRVC_NAME1",vocSendMailToEmpVOIn.get(1).getSrvcName());
					paramMap.put("DIVX_NAME1",vocSendMailToEmpVOIn.get(1).getDivxName());
					paramMap.put("TITL_TEXT1",vocSendMailToEmpVOIn.get(1).getTitlText());
					paramMap.put("ACPT_DATE1",vocSendMailToEmpVOIn.get(1).getAcptDate());
					paramMap.put("CONT_TEXT1",StringUtil.htmlEncodeWithBR(vocSendMailToEmpVOIn.get(1).getContText()));
					paramMap.put("REGI_COMPNAME1",vocSendMailToEmpVOIn.get(1).getRegiCompname());
					paramMap.put("ACTX_NAME1",vocSendMailToEmpVOIn.get(1).getActxName());					
				}
				SendMailVO sendMailVOIn = new SendMailVO();
				sendMailVOIn.setSenderEmail(vocSendMailToEmpVOInfo.getFromMail());
				sendMailVOIn.setReceiverEmail(vocSendMailToEmpVOInfo.getToMail());
				sendMailVOIn.setParams(paramMap);
				
				if(param.getActxCode().equals("A021")) {
					sendMailVOIn.setMailType(MailType.VOC_REGISTER_IN_ONE_TO_SALES);
				}else {
					sendMailVOIn.setMailType(MailType.VOC_REGISTER_IN_TO_SALES);
				}
				sendMailVOIn.setTitle("[SFA 고객 서비스 (VOC ID : " + param.getVocxIdxx()+"/Activity :"+vocSendMailToEmpVOIn.get(0).getActxName()+") ] 가 등록되었습니다.");

				mailingService.sendMail(sendMailVOIn);
			}
		}
		//접수 답변시 고객 메일전송
		if(!StringUtil.isNullToString(param.getActxCode()).equals("") 
				&& (param.getActxCode().equals("A002") || param.getActxCode().equals("A021"))) {
			//고객 메일 내용 정보
			VocSendMailToCustVO vocSendMailToCustVO = vocDao.getVocSendMailToCustOut(param);
			
			Map<String, String> paramCustMap = new HashMap<String, String>();
			paramCustMap.put("VOCX_IDXX", vocSendMailToCustVO.getVocxIdxx());
			paramCustMap.put("REQX_DATE", vocSendMailToCustVO.getReqxDate());
			paramCustMap.put("REQX_HOUR", vocSendMailToCustVO.getReqxHour());
			paramCustMap.put("REGI_DATE", vocSendMailToCustVO.getRegiDate());
			paramCustMap.put("TITL_TEXT", vocSendMailToCustVO.getTitlText());
			paramCustMap.put("CONT_TEXT", StringUtil.htmlEncodeWithBR(vocSendMailToCustVO.getContText()));
			paramCustMap.put("LONG_TEXT1",StringUtil.htmlEncodeWithBR(vocSendMailToCustVO.getLongText1()));
			paramCustMap.put("ACTX_NAME", vocSendMailToCustVO.getActxName());
			paramCustMap.put("SRVC_NAME", vocSendMailToCustVO.getSrvcName());
			paramCustMap.put("DIVX_NAME", vocSendMailToCustVO.getDivxName());
			paramCustMap.put("TO_MAIL", vocSendMailToCustVO.getToMail());

			SendMailVO sendMailVO = new SendMailVO();
			sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
			sendMailVO.setReceiverEmail(vocSendMailToCustVO.getToMail());
			sendMailVO.setParams(paramCustMap);
			sendMailVO.setMailType(MailType.VOC_REGISTER_OUT_TO_CUSTOMER);
			sendMailVO.setTitle("[LX MMA 고객 서비스 (VOC ID : " + param.getVocxIdxx()+"/처리단계 :"+vocSendMailToCustVO.getActxName()+") ] 가 등록되었습니다.");

			mailingService.sendMail(sendMailVO);
		}
//기존 프로세스	
//		//기존 제품 SAMPLE 요청
//		if(param.getSrvcCode().equals("S006")) {
//			if(param.getLevlNumx() == 2 
//					&& param.getDivxCode().equals("001") 
//					&& StringUtil.isNullToString(param.getFildFlag1()).equals("N")) {
//				workSeqx = param.getLevlNumx()+2;
//			}
//		}
//
//		//다음 Activity를 구하는 함수
//		param.setWorkSeqx(workSeqx);
//		VocActPopVO vocActPopVO = vocDao.getActivityName(param);
//		
//		if(vocActPopVO != null && !StringUtil.isNullToString(vocActPopVO.getActxCode()).equals("")) {
//			actxCode = StringUtil.isNullToString(vocActPopVO.getActxCode());
//			workSeqx = vocActPopVO.getWorkSeqx();
//			mustIsxx = StringUtil.isNullToString(vocActPopVO.getMustIsxx());
//			param.setActxCode(actxCode);
//			//다음담당자가 지정되지 않은경우 다음 Activity지정자(TS)로 할당
//			if(StringUtil.isNullToString(param.getAcptIdxx()) == "") {
//				acptIdxx = StringUtil.isNullToString(vocActPopVO.getAcptIdxx());
//				param.setAcptIdxx(acptIdxx);
//			}
//		}else {
//			return;
//		}
//		// 옵션 일경우 는 다음 Activity지정에 해당되는 'A031'을 할당
//		if(mustIsxx.equals("O")) {
//			actxCode = "A031";
//		}


		//param.setAcptIdxx(acptIdxx);
		//param.setLevlNumx(workSeqx);
//		//다음 ACT 등록
//		vocDao.createVocActPop(param);
	}		
	@Override
	public VocVO getVocIdxx(VocActVO param) {
		//VOC상세조회
		VocVO returnItem = vocDao.getVocIdxx(param);
		return returnItem;
	}
	//품의 후처리
	//파라미터 : vactIdxx, regiIdxx
	@Override
	public void saveVocActAppr(VocActPopVO param) {
		//VOC 품의 완료시 품의 단계 완료처리 
		vocDao.updateVocActApprVoc(param);
		//품의 완료시 VOC ACT 답변 단계 등록 
		vocDao.insertVocActApprVocAct(param);
// 품의후 메일전송 주석처리 2018.10.19		
//		String fromName = "";
//		//직원 메일 주소 정보
//		VocSendMailToEmpVO vocSendMailToEmpVOInfo = vocDao.getVocSendMailToEmpInfoAppr(param);
//		//발신자 명
//		fromName = vocSendMailToEmpVOInfo.getFromName();
//		//내부 직원 메일 발송
//		if(!StringUtil.isNullToString(vocSendMailToEmpVOInfo.getToMail()).equals("") 
//				&& !StringUtil.isNullToString(vocSendMailToEmpVOInfo.getToMail()).equals("")){
//			//직원 메일 내용 정보
//			List<VocSendMailToEmpVO> vocSendMailToEmpVOIn = vocDao.getVocSendMailToEmpInApprList(param);
//			if(vocSendMailToEmpVOIn != null) {
//				//메일전송 : 임직원 내부
//				Map<String, String> paramMap = new HashMap<String, String>();
//				paramMap.put("VOCX_IDXX",vocSendMailToEmpVOIn.get(0).getVocxIdxx());
//				paramMap.put("SRVC_CODE",vocSendMailToEmpVOIn.get(0).getSrvcCode());
//				paramMap.put("DIVX_CODE",vocSendMailToEmpVOIn.get(0).getDivxCode());
//				paramMap.put("SRVC_NAME",vocSendMailToEmpVOIn.get(0).getSrvcName());
//				paramMap.put("DIVX_NAME",vocSendMailToEmpVOIn.get(0).getDivxName());
//				paramMap.put("TITL_TEXT",vocSendMailToEmpVOIn.get(0).getTitlText());
//				paramMap.put("ACPT_DATE",vocSendMailToEmpVOIn.get(0).getAcptDate());
//				paramMap.put("CONT_TEXT",StringUtil.htmlEncodeWithBR(vocSendMailToEmpVOIn.get(0).getContText()));
//				paramMap.put("REGI_COMPNAME",vocSendMailToEmpVOIn.get(0).getRegiCompname());
//				paramMap.put("ACTX_NAME",vocSendMailToEmpVOIn.get(0).getActxName());
//				paramMap.put("FROM_NAME",fromName);
//				paramMap.put("VOCX_IDXX1",vocSendMailToEmpVOIn.get(1).getVocxIdxx());
//				paramMap.put("SRVC_CODE1",vocSendMailToEmpVOIn.get(1).getSrvcCode());
//				paramMap.put("DIVX_CODE1",vocSendMailToEmpVOIn.get(1).getDivxCode());
//				paramMap.put("SRVC_NAME1",vocSendMailToEmpVOIn.get(1).getSrvcName());
//				paramMap.put("DIVX_NAME1",vocSendMailToEmpVOIn.get(1).getDivxName());
//				paramMap.put("TITL_TEXT1",vocSendMailToEmpVOIn.get(1).getTitlText());
//				paramMap.put("ACPT_DATE1",vocSendMailToEmpVOIn.get(1).getAcptDate());
//				paramMap.put("CONT_TEXT1",StringUtil.htmlEncodeWithBR(vocSendMailToEmpVOIn.get(1).getContText()));
//				paramMap.put("REGI_COMPNAME1",vocSendMailToEmpVOIn.get(1).getRegiCompname());
//				paramMap.put("ACTX_NAME1",vocSendMailToEmpVOIn.get(1).getActxName());					
//
//				SendMailVO sendMailVOIn = new SendMailVO();
//				sendMailVOIn.setSenderEmail(vocSendMailToEmpVOInfo.getFromMail());
//				sendMailVOIn.setReceiverEmail(vocSendMailToEmpVOInfo.getToMail());
//				sendMailVOIn.setReceiverName(vocSendMailToEmpVOInfo.getToName());
//				sendMailVOIn.setParams(paramMap);
//
//				sendMailVOIn.setMailType(MailType.VOC_REGISTER_IN_TO_SALES);
//
//				sendMailVOIn.setTitle("[SFA 고객 서비스 (VOC ID : " + vocSendMailToEmpVOIn.get(0).getVocxIdxx()+"/Activity :"+vocSendMailToEmpVOIn.get(0).getActxName()+") ] 가 등록되었습니다.");
//
//				mailingService.sendMail(sendMailVOIn);
//			}
//		}		
	}	
}
