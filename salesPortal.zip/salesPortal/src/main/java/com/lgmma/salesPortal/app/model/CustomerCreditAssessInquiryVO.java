package com.lgmma.salesPortal.app.model;

public class CustomerCreditAssessInquiryVO extends PagingParamVO {

	private String kedCd          ;
	private String kedName        ;
	private String businessNumber ;
	private String ceoName        ;
	private String baseDate       ;
	private String creditRating   ;
	private String creditRatingStr;
	private String settlementDate ;
	private String rsOpenDate     ;
	private String rsCloseDate    ;
	private String cashFlow       ;
	private double totalSales     ;
	private double operatingProfit;
	public String getKedCd() {
		return kedCd;
	}
	public void setKedCd(String kedCd) {
		this.kedCd = kedCd;
	}
	public String getKedName() {
		return kedName;
	}
	public void setKedName(String kedName) {
		this.kedName = kedName;
	}
	public String getBusinessNumber() {
		return businessNumber;
	}
	public void setBusinessNumber(String businessNumber) {
		this.businessNumber = businessNumber;
	}
	public String getCeoName() {
		return ceoName;
	}
	public void setCeoName(String ceoName) {
		this.ceoName = ceoName;
	}
	public String getBaseDate() {
		return baseDate;
	}
	public void setBaseDate(String baseDate) {
		this.baseDate = baseDate;
	}
	public String getCreditRating() {
		return creditRating;
	}
	public void setCreditRating(String creditRating) {
		this.creditRating = creditRating;
	}
	public String getCreditRatingStr() {
		return creditRatingStr;
	}
	public void setCreditRatingStr(String creditRatingStr) {
		this.creditRatingStr = creditRatingStr;
	}
	public String getSettlementDate() {
		return settlementDate;
	}
	public void setSettlementDate(String settlementDate) {
		this.settlementDate = settlementDate;
	}
	public String getRsOpenDate() {
		return rsOpenDate;
	}
	public void setRsOpenDate(String rsOpenDate) {
		this.rsOpenDate = rsOpenDate;
	}
	public String getRsCloseDate() {
		return rsCloseDate;
	}
	public void setRsCloseDate(String rsCloseDate) {
		this.rsCloseDate = rsCloseDate;
	}
	public String getCashFlow() {
		return cashFlow;
	}
	public void setCashFlow(String cashFlow) {
		this.cashFlow = cashFlow;
	}
	public double getTotalSales() {
		return totalSales;
	}
	public void setTotalSales(double totalSales) {
		this.totalSales = totalSales;
	}
	public double getOperatingProfit() {
		return operatingProfit;
	}
	public void setOperatingProfit(double operatingProfit) {
		this.operatingProfit = operatingProfit;
	}		
}
