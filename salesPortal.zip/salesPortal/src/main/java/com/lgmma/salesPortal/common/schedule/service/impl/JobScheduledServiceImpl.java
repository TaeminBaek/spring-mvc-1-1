package com.lgmma.salesPortal.common.schedule.service.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.lgmma.salesPortal.app.dao.ExchangeRateDao;
import com.lgmma.salesPortal.app.dao.LoginDao;
import com.lgmma.salesPortal.app.model.CollectExpectedDateVO;
import com.lgmma.salesPortal.app.model.CompOrganByErpVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.DirectOrderMigVO;
import com.lgmma.salesPortal.app.model.DisplayOrderLotVO;
import com.lgmma.salesPortal.app.model.DissDelayGateReviewAlarmVO;
import com.lgmma.salesPortal.app.model.DissDelayTaskAlarmVO;
import com.lgmma.salesPortal.app.model.ExchangeRateVO;
import com.lgmma.salesPortal.app.model.JobScheduleParamVO;
import com.lgmma.salesPortal.app.model.NiceCompGradeVO;
import com.lgmma.salesPortal.app.model.ProductStockVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.model.SampleOrderMasterVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.service.CompanyService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.model.SapExchangeRate;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.schedule.dao.JobScheduledDao;
import com.lgmma.salesPortal.common.schedule.service.JobScheduledService;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.NiceXMLParser;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.security.authentication.UserInfo;
import com.mysql.jdbc.StringUtils;

@Service
public class JobScheduledServiceImpl implements JobScheduledService {

	private static Logger logger = LoggerFactory.getLogger(JobScheduledServiceImpl.class);

	private final String FNC_PRODUCT_MASTER         = "ZSDE01_MASTER_SELECT_MQ2"; // 자재마스터가져오기(기존 rfc 에서 단종여부 추가됨)
	private final String FNC_PRODUCT_STOCK_MASTER   = "ZSDE02_CURR_STOCK";        // 재고마스터가져오기
	private final String FNC_EXCHANGE_RATE           = "ZFI_FOREX_RATE";            // 일별환율정보가져오기
	private final String FNC_SAP_SEARCH_ORDER       = "ZSDE02_DISPLAY_ORDER_LIST"; // 주문정보 조회
	private final String FNC_SAP_CUST_INFO_SEARCH   = "ZSDE01_MASTER_SELECT_AP2"; // 판매처기본정보조회
	private final String FNC_SEND_CUST_GRADE_INFO   = "ZSDE01_CREDIT_LEVEL_CHANGE"; // 평가등급 erp 전송
	private final String FNC_SEND_CUST_WATCH_GRADE_INFO   = "ZSDE01_WATCHGRD_CHANGE"; // watch등급 erp 전송
	private final String FNC_SECURITY_CHANGE   = "ZSDE01_SECURITY_CHANGE"; // 담보수정
	private final String FNC_SAP_MONTHLY_SALES   = "ZFB_MONTHLY_SALES_DATA"; // SAP 월매출 정보 가져오기

	private Session session = null;
	private Channel channel = null;
	private ChannelSftp channelSftp = null;

	@Autowired
	private JobScheduledDao jobScheduledDao;

	@Autowired
	private ExchangeRateDao exchangeRateDao;

	@Autowired
	private JcoConnector jcoConnector;

	@Autowired
	private LoginDao loginDao;

	@Autowired
	private MailingService mailingService;

	@Autowired
	private ThreadPoolTaskExecutor updateOrderWadatIstJobScheduledExecutor;
	
	@Autowired
	private NiceXMLParser niceXMLParser;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private MessageSourceAccessor messageSourceAccessor;

	@Autowired
	private SapSearchService sapSearchService;

	private String nodeNames[] = {
			"grade",
			"watch_dcls_grdnm",
			"watchgrd"
	};

	@Async("jobScheduledExecutor")
	@Override
	public void excProductsFromSap() {
		JcoTableParam<Object> tableParam = null;

		for (Vkorg org : Vkorg.values()) {
			tableParam = new JcoTableParam<Object>();
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("SIGN", "I");
			paramMap.put("OPTION", "EQ");
			paramMap.put("LOW", org.getCode());
			paramMap.put("HIGH", null);
			tableParam.put("SALESORGRANGE", paramMap);

			jcoConnector.executeFunction(FNC_PRODUCT_MASTER, tableParam);
			List<ProductVO> productList = (List<ProductVO>) tableParam.get("T_MATNRINFO", ProductVO.class);
			jobScheduledDao.mergeProduct(productList);
		}
	}

	@Async("jobScheduledExecutor")
	@Override
	public void excProductStocksFromSap() {
		JcoTableParam<Object> tableParam = null;
		tableParam = new JcoTableParam<Object>();
/*
 * 전체 재고를 가져오기위해 input 을 제거
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("SIGN", "I");
		paramMap.put("OPTION", "EQ");
		paramMap.put("LOW", null);
		paramMap.put("HIGH", null);
		tableParam.put("SPARTRANGE", paramMap);
*/
		jcoConnector.executeFunction(FNC_PRODUCT_STOCK_MASTER, tableParam);
		List<ProductStockVO> productStockList = (List<ProductStockVO>) tableParam.get("T_STOCK", ProductStockVO.class);
		// 테이블 전체 삭제 후
		jobScheduledDao.deleteProductStockAll();
		// 모두 신규로 넣는다.
		jobScheduledDao.insertProductStocks(productStockList);
	}

	@Async("jobScheduledExecutor")
	@Override
	public void excExchangeRateFromSap() {

		JcoTableParam<?> tableParam = new JcoTableParam<Object>();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		tableParam.put("IT_RATE", paramMap);

		String yyyymmdd = DateUtil.getToday();
		//테스트(개발쪽 하기 일자가 마지막 데이타)
		//yyyymmdd = "20180115";

		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_DATE", yyyymmdd);
		Map<String, Object> outputParam = new HashMap<String, Object>();

		jcoConnector.executeFunction(FNC_EXCHANGE_RATE, inputParam, outputParam, tableParam);

		List<SapExchangeRate> sapExchangeRateList = (List<SapExchangeRate>) tableParam.get("IT_RATE", SapExchangeRate.class);
		ExchangeRateVO exchangeRateVO = new ExchangeRateVO();
		if (sapExchangeRateList.size() > 0) {
			int checkCnt = 0; // 유효한 데이타가 있는지 체크
			for (SapExchangeRate sapExchangeRate : sapExchangeRateList) {
				if (sapExchangeRate.getExFromCurrCD().equals("USD")) {
					exchangeRateVO.setUsdxRate(sapExchangeRate.getExToBamt());
					checkCnt++;
				}
				if (sapExchangeRate.getExFromCurrCD().equals("JPY")) {
					exchangeRateVO.setJpyxRate(sapExchangeRate.getExToBamt());
					checkCnt++;
				}
				if (sapExchangeRate.getExFromCurrCD().equals("EUR")) {
					exchangeRateVO.setEuroRate(sapExchangeRate.getExToBamt());
					checkCnt++;
				}
				if (sapExchangeRate.getExFromCurrCD().equals("CNY")) {
					exchangeRateVO.setCnyxRate(sapExchangeRate.getExToBamt());
					checkCnt++;
				}
				if (sapExchangeRate.getExFromCurrCD().equals("GBP")) {
					exchangeRateVO.setGbpxRate(sapExchangeRate.getExToBamt());
					checkCnt++;
				}
				if (sapExchangeRate.getExFromCurrCD().equals("SGD")) {
					exchangeRateVO.setSgdxRate(sapExchangeRate.getExToBamt());
					checkCnt++;
				}
			}
			// 유효한 데이타가 있으면 실행 하고 그렇지 않으면 스킵
			if (checkCnt > 0) {
				exchangeRateVO.setYyyyMmdd(yyyymmdd);
				exchangeRateVO.setRegiIdxx("BATCH");
				exchangeRateVO.setUpdtIdxx("BATCH");
				exchangeRateDao.mergeExchangeRate(exchangeRateVO);
			}
		}
	}

	/**
	 * 주문의 출하일자 를 SAP과 동기화
	 * @param jobScheduleParamVO
	 */
	@Async("updateOrderWadatIstMainJobScheduledExecutor")
	@Override
	public void excUpdateOrderWadatIstFromSap(JobScheduleParamVO jobScheduleParamVO) {
		JobScheduleParamVO jparamVO = (JobScheduleParamVO) StringUtil.nullToEmptyString(jobScheduleParamVO);

		List<SampleOrderMasterVO> orderMasterVOList = jobScheduledDao.getUpdateOrderWadatIstList(jparamVO);
		for (SampleOrderMasterVO updateOrder : orderMasterVOList) {
			UpdateOrderWadatIstTask task = new UpdateOrderWadatIstTask(updateOrder);
			updateOrderWadatIstJobScheduledExecutor.execute(task);
		}
	}

	/**
	 * erp상의 판매처 기본정보를 모두 가져온다.
	 * (삭제 후 모두 insert)
	 */
	@Override
	public void excSyncCompOrganByErp() {
		// 조건을 넣지 않고 모두 가져오기
		JcoTableParam<Object> tableParam = null;
		tableParam = new JcoTableParam<Object>();
		Map<String, Object> inputParam = new HashMap<String, Object>();
		Map<String, Object> outputParam = new HashMap<String, Object>();

		/* 조건을 넣지 않고 모두 가져오기
		Map<String, Object> customerrangeMap = new HashMap<String, Object>();
		customerrangeMap.put("SIGN", "I");
		customerrangeMap.put("OPTION", "EQ");
		customerrangeMap.put("LOW", null);
		customerrangeMap.put("HIGH", null);
		tableParam.put("CUSTOMERRANGE", customerrangeMap);

		Map<String, Object> bapiRangesvkorgMap = new HashMap<String, Object>();
		bapiRangesvkorgMap.put("SIGN", "I");
		bapiRangesvkorgMap.put("OPTION", "EQ");
		bapiRangesvkorgMap.put("LOW", null);
		bapiRangesvkorgMap.put("HIGH", null);
		tableParam.put("BAPI_RANGESVKORG", bapiRangesvkorgMap);
		*/
		//jcoConnector.executeFunction(FNC_SAP_CUST_INFO_SEARCH, tableParam);
		jcoConnector.executeFunction(FNC_SAP_CUST_INFO_SEARCH, inputParam, outputParam, tableParam, false);
		List<CompOrganByErpVO> CompOrganByErpList = (List<CompOrganByErpVO>) tableParam.get("T_CUSTOMER", CompOrganByErpVO.class);
		if(CompOrganByErpList.size() > 0){
			jobScheduledDao.deleteCompOrganByErp();
			for(CompOrganByErpVO compOrganByErpVO : CompOrganByErpList){
				logger.debug("###################");
				logger.debug(compOrganByErpVO.toString());
				jobScheduledDao.insertCompOrganByErp(compOrganByErpVO);
			}
		}
	}

	@Override
	public void excOrderLotFromSap(DisplayOrderLotVO param) {
		JcoTableParam tableParam = new JcoTableParam();

		Map<String, Object> inputParam = new HashMap<String, Object>();
		Map<String, Object> outputParam = new HashMap<String, Object>();

		inputParam.put("I_VBELN",param.getI_VBELN()); 

		jcoConnector.executeFunction("ZSDE02_DISPLAY_ORDER_LOT", inputParam, outputParam, tableParam);

		List<DisplayOrderLotVO> list = (List<DisplayOrderLotVO>) tableParam.get("ET_DATA", DisplayOrderLotVO.class);
		if(list.size() > 0){
				logger.debug("###################");
				logger.debug(list.toString());
		}
	}

	private class UpdateOrderWadatIstTask implements Runnable {
		private SampleOrderMasterVO updateOrder;
		public UpdateOrderWadatIstTask(SampleOrderMasterVO updateOrder) {
			this.updateOrder = updateOrder;
		}

		@Override
		public void run() {
			JcoTableParam<?> tableParam = new JcoTableParam<Object>();
			Map<String, Object> paramMap = new HashMap<String, Object>();
			tableParam.put("ET_DATA", paramMap);

			Map<String, Object> inputParam = new HashMap<String, Object>();
			inputParam.put("I_VBELN", this.updateOrder.getVbeln());
			Map<String, Object> outputParam = new HashMap<String, Object>();

			jcoConnector.executeFunction(FNC_SAP_SEARCH_ORDER, inputParam, outputParam, tableParam, false);

			List<DirectOrderMigVO> directOrderMigVOList = (List<DirectOrderMigVO>) tableParam.get("ET_DATA", DirectOrderMigVO.class);
			if (directOrderMigVOList.size() > 0) {
				DirectOrderMigVO directOrderMigVO = (DirectOrderMigVO) StringUtil.nullToEmptyString(directOrderMigVOList.get(0));
				// 출하일자가 변경될수도 있기 때문에 무조건 UPDATE 한다.
				//logger.debug(directOrderMigVO.toString());
				//if(!StringUtil.nullConvert(directOrderMigVO.getWadatIst()).isEmpty()) {
					this.updateOrder.setWadatIst(directOrderMigVO.getWadatIst());
					jobScheduledDao.excUpdateOrderWadatIstFromSapByVbeln(this.updateOrder);
				//}
			}
		}

	}

	@Async("jobScheduledExecutor")
	@Override
	public void exeUpdateCompGradeFromNICE(String stcd2) {
		//스켸쥴러에서는 전체를 대상으로 하기때문에 stcd2 = "" 로 호출
		NiceCompGradeVO vo = new NiceCompGradeVO();
		vo.setStcd2(stcd2);

		Map<String, String> tmpNode = null;
		NiceCompGradeVO niceVo = null;
		//대상선정
		List<NiceCompGradeVO> compList = jobScheduledDao.getCompListForUpdateGrade(vo);
		for(NiceCompGradeVO compVo : compList) {
			try {
				//등급 가져오기
				logger.debug("----------------------------------------");
				do {
					tmpNode = niceXMLParser.readXml(nodeNames, StringUtil.nullConvert(compVo.getStcd2()));
				} while (!"".equals(StringUtil.nullConvert(tmpNode.get("ERROR"))));

				niceVo = new NiceCompGradeVO();
				niceVo.setKisGrade(tmpNode.get("KIS_GRADE"));
				niceVo.setWatchGrade(tmpNode.get("WATCH_GRADE"));
				niceVo.setCfGrade(tmpNode.get("CF_GRADE"));
				niceVo.setOtStop(tmpNode.get("OT_STOP"));
				niceVo.setStMg(tmpNode.get("ST_MG"));
				niceVo.setWatchGradeCode(tmpNode.get("WATCH_GRADE_CODE"));

				NiceCompGradeVO finalVo = jobScheduledDao.getFinalCompGrade(compVo);

				if(finalVo == null)
					finalVo = new NiceCompGradeVO();

				finalVo = (NiceCompGradeVO) StringUtil.nullToEmptyString(finalVo);

				StringBuffer sb = new StringBuffer();
				if(!niceVo.getKisGrade().equals(finalVo.getKisGrade())) {
					sb.append("KIS신용등급 : "+finalVo.getKisGrade()+" -> "+niceVo.getKisGrade()+" <br>");
				}
				if(!niceVo.getWatchGrade().equals(finalVo.getWatchGrade())) {
					sb.append("WATCH등급 : "+finalVo.getWatchGrade()+" -> "+niceVo.getWatchGrade()+" <br>");
				}
				if(!niceVo.getCfGrade().equals(finalVo.getCfGrade())) {
					sb.append("현금흐름 : "+finalVo.getCfGrade()+" -> "+niceVo.getCfGrade()+" <br>");
				}
				if(!niceVo.getOtStop().equals(finalVo.getOtStop())) {
					sb.append("당좌거래정지/부도 : "+finalVo.getOtStop()+" -> "+niceVo.getOtStop()+" <br>");
				}
				if(!niceVo.getStMg().equals(finalVo.getStMg())) {
					sb.append("법정관리/화의 : "+finalVo.getStMg()+" -> "+niceVo.getStMg()+" <br>");
				}
				niceVo.setModiNote(sb.toString());
				niceVo.setCompFlag(niceVo.getModiNote().equals("") ? "N" : "Y");
				niceVo.setKisdate(DateUtil.getToday());
				niceVo.setStcd2(compVo.getOrgiStcd());
				jobScheduledDao.createNiceCompanyGrade(niceVo);

				CompanyVO companyVo = new CompanyVO();
				companyVo.setCompGrade(companyService.exchangeValue(niceVo.getKisGrade()));
				companyVo.setWatchGrade(niceVo.getWatchGradeCode());
				companyVo.setStcd2(compVo.getOrgiStcd());

				jobScheduledDao.updateCompanyGrade(companyVo);
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		logger.debug("----------------------------------------");
	}

	@Async("jobScheduledExecutor")
	@Override
	public void exeSendCompGradeToERP(String kunnr) {
		CompanyVO companyVo = new CompanyVO();
		companyVo.setKunnr(kunnr);

		//대상선정
		List<CompanyVO> compList = jobScheduledDao.getCompListForSendGradeToERP(companyVo);

		JcoTableParam tableParam = new JcoTableParam();
		List<Map<String, String>> compGradeList = new ArrayList<Map<String, String>>(); 
		Map<String, String> companyGrade = null;

		for(CompanyVO compVo : compList) {
			companyGrade = new HashMap<String, String>();
			companyGrade.put("VKORG", StringUtils.isNullOrEmpty(compVo.getVkorg()) ? "3000" : compVo.getVkorg());
			companyGrade.put("KUNNR", StringUtil.nullConvert(compVo.getKunnr()));
			companyGrade.put("GRADE", StringUtil.nullConvert(compVo.getCompGrade()));
            compGradeList.add(companyGrade);
		}
		tableParam.put("T_CREDIT_LEVEL", compGradeList);
		jcoConnector.executeFunction(FNC_SEND_CUST_GRADE_INFO, tableParam);

        List<Map> rtnRows = (List<Map>) tableParam.get("T_CREDIT_LEVEL");

        logger.debug("=============================ERP CREDIT_GRADE RECEIVE START=============================");
        for(Map row : rtnRows)
          logger.debug("=====T_CREDIT_LEVEL : RECEIVE ===== VKORG : " + StringUtil.nullConvert(row.get("VKORG")) + ", KUNNR : " + StringUtil.nullConvert(row.get("KUNNR")) + ", GRADE : " + StringUtil.nullConvert(row.get("GRADE")) + ", SUBRC : " + StringUtil.nullConvert(row.get("SUBRC")) + ", MSG : " + StringUtil.nullConvert(row.get("MSG")));

        // 전체 일 경우 watch_grade 추가하여 새로운 RFC에 보냄 20170922 이동엽D , 김도균D
        if(StringUtils.isNullOrEmpty(kunnr)) {
        	compGradeList = new ArrayList<Map<String, String>>();
        	tableParam = new JcoTableParam();
    		//대상선정
    		List<NiceCompGradeVO> niceGradeList = jobScheduledDao.getNiceCompGradeListForSendToERP();

    		for(NiceCompGradeVO niceGradeVo : niceGradeList) {
    			companyGrade = new HashMap<String, String>();
    			companyGrade.put("KDATE", StringUtil.nullConvert(niceGradeVo.getKisdate()));
    			companyGrade.put("STCD2", StringUtil.nullConvert(niceGradeVo.getStcd2()));
    			companyGrade.put("KGRDCD", StringUtil.nullConvert(niceGradeVo.getKisGrade()));
    			companyGrade.put("WGRDCD", StringUtil.nullConvert(niceGradeVo.getWatchGradeCode()));
    			companyGrade.put("WGRDTXT", StringUtil.nullConvert(niceGradeVo.getWatchGrade()));
    			companyGrade.put("CFGRD", StringUtil.nullConvert(niceGradeVo.getCfGrade()));
    			companyGrade.put("OTSTOP", StringUtil.nullConvert(niceGradeVo.getOtStop()));
    			companyGrade.put("STMG", StringUtil.nullConvert(niceGradeVo.getStMg()));
    			companyGrade.put("CFLAG", StringUtil.nullConvert(niceGradeVo.getCompFlag()));
    			companyGrade.put("MODITXT", StringUtil.nullConvert(niceGradeVo.getModiNote()));

                compGradeList.add(companyGrade);
    		}
    		tableParam.put("T_WATCH_GRADE", compGradeList);
    		jcoConnector.executeFunction(FNC_SEND_CUST_WATCH_GRADE_INFO, tableParam);
        }
	}

	/* (non-Javadoc)
	 * @see com.lgmma.salesPortal.app.service.JobScheduledService#exeSendDamboExpiredMailERP()
	 * 담보 만료시 담보 담당자에 메일전송, erp 에 금액전송
	 * step 1. 유효기간이 하루라도 지난 담보에 대하여 사용여부와 확인여부를 N으로 업데이트
	 * step 2. 사용중인 담보에 대하여 만료일이 7일전 or 오늘 인 건을 가져와 안내 메일을 보낸다. 
	 * step 3. 현 담보금액(사용여부가 N 이면 0 으로)을 담보수정 RFC 를 호출하여 ERP 에 전송한다. 
	 */
	@Async("jobScheduledExecutor")
	@Override
	public void exeSendDamboExpiredMailERP() {
		// step 1.
		jobScheduledDao.updateExpiredDambo();
		// step 2.
		sendExpiredDamboEmail();
		//step 3.
		sendCurrentDamboToErp();
	}

	private void sendCurrentDamboToErp() {
		List<Map> currentDamboList = jobScheduledDao.getCurrentDamboList();

		JcoTableParam tableParam = new JcoTableParam();
		List<Map<String, String>> compDamboList = new ArrayList<Map<String, String>>(); 
		Map<String, String> companyDambo = null;

		for(Map<String, String> dambo : currentDamboList) {
			companyDambo = new HashMap<String, String>();
			companyDambo.put("VKORG", StringUtils.isNullOrEmpty(dambo.get("VKORG")) ? "3000" : dambo.get("VKORG"));
			companyDambo.put("KUNNR", StringUtil.nullConvert(dambo.get("KUNNR")));
			companyDambo.put("GUAR_AMNT", StringUtil.nullConvert(dambo.get("GUAR_AMNT")));
			companyDambo.put("WAERS", "KRW");
			compDamboList.add(companyDambo);
		}
		tableParam.put("T_SECURITY", compDamboList);
		jcoConnector.executeFunction(FNC_SECURITY_CHANGE, tableParam);

		List<Map> rtnRows = (List<Map>) tableParam.get("T_SECURITY");

        logger.debug("=============================ERP T_SECURITY RECEIVE START=============================");
        for(Map row : rtnRows)
          logger.debug("=====T_SECURITY : RECEIVE ===== VKORG : " + StringUtil.nullConvert(row.get("VKORG")) + ", KUNNR : " + StringUtil.nullConvert(row.get("KUNNR")) + ", GUAR_AMNT : " + StringUtil.nullConvert(row.get("GUAR_AMNT")) + ", WAERS : " + StringUtil.nullConvert(row.get("WAERS")) + ", SUBRC : " + StringUtil.nullConvert(row.get("SUBRC")) + ", MSG : " + StringUtil.nullConvert(row.get("MSG")));
	}

	private void sendExpiredDamboEmail() {
		List<Map> damboList = jobScheduledDao.getToBeExpiredDamboList();
		if(damboList.size() > 0) {
			//담보 담당자
			List<UserInfo> creditEmpList = loginDao.getCreditEmpUserInfo("");
			List<String> creditEmailList = new ArrayList<String>(); 
			for(UserInfo creditEmp : creditEmpList) {
				if(!StringUtil.nullConvert(creditEmp.getMailAddr()).equals(""))
					creditEmailList.add(creditEmp.getMailAddr());
			}
			
			for(Map dambo : damboList) {
				List<String> receiverList = new ArrayList<String>();
				receiverList.addAll(creditEmailList);	//담보 담당자 add
				if(!StringUtil.nullConvert(dambo.get("SALES_MAIL")).equals(""))
					receiverList.add((String) dambo.get("SALES_MAIL"));
				if(!StringUtil.nullConvert(dambo.get("REGI_MAIL")).equals(""))
					receiverList.add((String) dambo.get("REGI_MAIL"));

				Map<String, String> paramMap = new HashMap<String, String>();
				paramMap.put("MESSAGE", dambo.get("NAME1") + " 업체의 담보유효일이 임박하였습니다.");
				if(((String)dambo.get("DDAY")).equals("0")) {
					paramMap.put("MESSAGE", dambo.get("NAME1") + " 업체의 담보유효일이 만료되었습니다.");
				}

				for(String receiverEmail : receiverList) {
					SendMailVO sendMailVO = new SendMailVO();
					sendMailVO.setMailType(MailType.COMPANY_DAMBO_EXPIRED_TO_EMP);
					sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
					sendMailVO.setParams(paramMap);
					sendMailVO.setReceiverEmail(receiverEmail);
					mailingService.sendMail(sendMailVO);
				}
			}
		}
	}

	@Async("jobScheduledExecutor")
	@Override
	public void exeSendMailDISSDelayTaskAlarm(){
		String url = messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=";
		String specInTaskListUrl    = "";
		String impDevTaskListUrl    = "";

		List<DissDelayTaskAlarmVO> dissDelayTaskAlarmVOList = jobScheduledDao.getDissDelayTaskList();
		if(dissDelayTaskAlarmVOList.size() > 0){
			for(DissDelayTaskAlarmVO dissDelayTaskAlarmVO : dissDelayTaskAlarmVOList){
				Map<String,String> mailParamMap = new HashMap<>();
				dissDelayTaskAlarmVO = (DissDelayTaskAlarmVO) StringUtil.nullToEmptyString(dissDelayTaskAlarmVO);
				mailParamMap.put("taskName",dissDelayTaskAlarmVO.getTaskName());
				
				try {
					specInTaskListUrl   = url + URLEncoder.encode("/dissSpecIn/dissSpecInList","UTF-8") + "?taskId=" + dissDelayTaskAlarmVO.getTaskId();
					impDevTaskListUrl   = url + URLEncoder.encode("/dissImpDev/dissImpDevList","UTF-8") + "?taskId=" + dissDelayTaskAlarmVO.getTaskId();
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
				
				if("SPECIN".equals(dissDelayTaskAlarmVO.getTaskType())){
					mailParamMap.put("taskTypeName","SPEC-IN");
					mailParamMap.put("taskListUrl",specInTaskListUrl);
					mailParamMap.put("stepGroupName",dissDelayTaskAlarmVO.getStepGroupName());
					mailParamMap.put("compGoalYmd",dissDelayTaskAlarmVO.getCompGoalYmd());

					SendMailVO sendMailVO1 = new SendMailVO();
					sendMailVO1.setTitle("D.I.S.S. SPEC-IN 과제 일정지연 알림");
					sendMailVO1.setMailType(MailType.DISS_DELAY_TASK_ALARM);
					sendMailVO1.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
					sendMailVO1.setReceiverEmail(dissDelayTaskAlarmVO.getSalesEmpMail());
					sendMailVO1.setParams(mailParamMap);
					mailingService.sendMail(sendMailVO1);

					if(!dissDelayTaskAlarmVO.getDevEmpMail().equals("")
					&& !dissDelayTaskAlarmVO.getSalesEmpMail().equals(dissDelayTaskAlarmVO.getTsEmpMail())) {
						SendMailVO sendMailVO2 = new SendMailVO();
						sendMailVO2.setTitle("D.I.S.S. SPEC-IN 과제 일정지연 알림");
						sendMailVO2.setMailType(MailType.DISS_DELAY_TASK_ALARM);
						sendMailVO2.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
						sendMailVO2.setReceiverEmail(dissDelayTaskAlarmVO.getTsEmpMail());
						sendMailVO2.setParams(mailParamMap);
						mailingService.sendMail(sendMailVO2);
					}

					if(!dissDelayTaskAlarmVO.getSalesEmpMail().equals(dissDelayTaskAlarmVO.getDevEmpMail())
					&& (dissDelayTaskAlarmVO.getDevEmpMail().equals("") || !dissDelayTaskAlarmVO.getTsEmpMail().equals(dissDelayTaskAlarmVO.getDevEmpMail()))
					&& !dissDelayTaskAlarmVO.getDevEmpMail().equals("")) {
						SendMailVO sendMailVO3 = new SendMailVO();
						sendMailVO3.setTitle("D.I.S.S. SPEC-IN 과제 일정지연 알림");
						sendMailVO3.setMailType(MailType.DISS_DELAY_TASK_ALARM);
						sendMailVO3.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
						sendMailVO3.setReceiverEmail(dissDelayTaskAlarmVO.getDevEmpMail());
						sendMailVO3.setParams(mailParamMap);
						mailingService.sendMail(sendMailVO3);
					}
				}else{
					mailParamMap.put("taskTypeName","제품개선개발");
					mailParamMap.put("taskListUrl",impDevTaskListUrl);
					mailParamMap.put("stepGroupName",dissDelayTaskAlarmVO.getStepGroupName());
					mailParamMap.put("compGoalYmd",dissDelayTaskAlarmVO.getCompGoalYmd());

					SendMailVO sendMailVO1 = new SendMailVO();
					sendMailVO1.setTitle("D.I.S.S. 제품개선개발 과제 일정지연 알림");
					sendMailVO1.setMailType(MailType.DISS_DELAY_TASK_ALARM);
					sendMailVO1.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
					sendMailVO1.setReceiverEmail(dissDelayTaskAlarmVO.getLeaderEmpMail());
					sendMailVO1.setParams(mailParamMap);
					mailingService.sendMail(sendMailVO1);
					
					if(!dissDelayTaskAlarmVO.getLeaderEmpMail().equals(dissDelayTaskAlarmVO.getDevEmpMail())
						&& !dissDelayTaskAlarmVO.getDevEmpMail().equals("")) {
						SendMailVO sendMailVO2 = new SendMailVO();
						sendMailVO2.setTitle("D.I.S.S. 제품개선개발 과제 일정지연 알림");
						sendMailVO2.setMailType(MailType.DISS_DELAY_TASK_ALARM);
						sendMailVO2.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
						sendMailVO2.setReceiverEmail(dissDelayTaskAlarmVO.getDevEmpMail());
						sendMailVO2.setParams(mailParamMap);
						mailingService.sendMail(sendMailVO2);
					}
				}
			}
		}
	}
	
	@Async("jobScheduledExecutor")
	@Override
	public void exeSendMailDISSDelayGateReviewAlarm() {
		String url = messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=";
		String specInTaskListUrl = "";
		
		List<DissDelayGateReviewAlarmVO> dissDelayGateReviewAlarmVOList = jobScheduledDao.getDissDelayGateReviewList();
		
		if(dissDelayGateReviewAlarmVOList.size() > 0){
			for(DissDelayGateReviewAlarmVO dissDelayTaskAlarmVO : dissDelayGateReviewAlarmVOList){
				Map<String,String> mailParamMap = new HashMap<>();
				dissDelayTaskAlarmVO = (DissDelayGateReviewAlarmVO) StringUtil.nullToEmptyString(dissDelayTaskAlarmVO);

				try {
					specInTaskListUrl   = url + URLEncoder.encode("/dissSpecIn/dissSpecInList","UTF-8") + "?taskId=" + dissDelayTaskAlarmVO.getTaskId();
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
				
				mailParamMap.put("taskName",dissDelayTaskAlarmVO.getTaskName());
				mailParamMap.put("taskListUrl",specInTaskListUrl);
				mailParamMap.put("regiYmd",dissDelayTaskAlarmVO.getRegiYmd());

				SendMailVO sendMailVO = new SendMailVO();
				sendMailVO.setTitle("D.I.S.S. SPEC-IN GATE REVIEW 지연 알림");
				sendMailVO.setMailType(MailType.DISS_DELAY_GATEREVIEW_ALARM);
				sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
				sendMailVO.setReceiverEmail(dissDelayTaskAlarmVO.getTsEmpMail());
				sendMailVO.setParams(mailParamMap);
				mailingService.sendMail(sendMailVO);
			}
		}
	}

	@Async("jobScheduledExecutor")
	@Override
	public void exeUpdateExpCompanyGradeFromSap(String kunnr) {
		CompanyVO param = new CompanyVO();
		param.setKunnr(kunnr);

		List<CompanyVO> companyList = jobScheduledDao.getErpExpCompanyList(param);

		for(CompanyVO company : companyList) {
			try {
				company.setCompGrade(sapSearchService.getExpCompanyCredit(company).get("E_CLASCODE"));
				jobScheduledDao.updateExpCompGrade(company);
			} catch (Exception e) {}
		}
	}

	@Override
	public void exeGetMonthlySalesFromSap(String yyyyMm) {
        if(StringUtils.isNullOrEmpty(yyyyMm)) {
            logger.debug("yyyyMm == null nothing to do");
        } else {
    		JcoTableParam tableParam = new JcoTableParam();

    		Map<String, Object> inputParam = new HashMap<String, Object>();
    		Map<String, Object> outputParam = new HashMap<String, Object>();

    		inputParam.put("I_CMONTH", yyyyMm); //년월
    		
    		jcoConnector.executeFunction(FNC_SAP_MONTHLY_SALES, inputParam, outputParam, tableParam);
    		if(outputParam.get("E_FLAG").equals("S")) {	//성공
    			// 테이블 전체 삭제 후
    			jobScheduledDao.deleteMonthlySales(yyyyMm);
    			// 모두 신규로 넣는다.
    			jobScheduledDao.insertMonthlySales((List<Map>)tableParam.get("ET_ITAB"));
    		}
        }
	}

	@Async("jobScheduledExecutor")
	@Override
	public void exeUpdateKedInfo() {
		connectInit();
		download();
		disconnect();

		String fileName = "lgmma_" + DateUtil.getToday() + ".jar";
		String downPath = "D:/applicationUploadFolder/salesPortal/enpinfo/";
		try {
			ZipFile zip = new ZipFile(new File(downPath + fileName));
	
			for (Enumeration e = zip.entries(); e.hasMoreElements();) {
				ZipEntry entry = (ZipEntry) e.nextElement();
				System.out.println("File name: " + entry.getName() + "; size: " + entry.getSize() + "; compressed size: " + entry.getCompressedSize());
				BufferedReader br = new BufferedReader(new InputStreamReader(zip.getInputStream(entry), "euc-kr"));

				String s = "";
				switch(entry.getName()) {
				case "KED50E1_lgmma.txt": // KED50E1_lgmma.txt 일별경보리스트, Table_Name : TB_KED_EW_ALERT
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
							
							String[] line = (" " + s +" ").split("\\|");
							
							int i = 0;
							paramMap.put("ewCd", line[i++].trim());
							paramMap.put("standDate", line[i++].trim());
							paramMap.put("ewRating", line[i++].trim());
							paramMap.put("ewRatingDv", line[i++].trim());
							paramMap.put("shotTermBank", line[i++].trim());
							paramMap.put("shotTermNormal", line[i++].trim());
							paramMap.put("shotTermCorpCard", line[i++].trim());
							paramMap.put("defaultCompany", line[i++].trim());
							paramMap.put("defaultOwner", line[i++].trim());
							paramMap.put("publicInfoCmp", line[i++].trim());
							paramMap.put("publicInfoOwner", line[i++].trim());
							paramMap.put("checkingAccount", line[i++].trim());
							paramMap.put("closedAccount", line[i++].trim());
							paramMap.put("overdue", line[i++].trim());
							paramMap.put("workout", line[i++].trim());
							paramMap.put("disposition", line[i++].trim());
							paramMap.put("creditRating", line[i++].trim());
							paramMap.put("litigationInfo", line[i++].trim());
							paramMap.put("financialInfo", line[i++].trim());
							paramMap.put("inquiryHis", line[i++].trim());
							paramMap.put("relatedInfo", line[i++].trim());
							paramMap.put("creditInfo", line[i++].trim());
	
							jobScheduledDao.mergeKedEwAlert(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5001_lgmma.txt": // KED5001_lgmma.txt EW코드등록현황, Table_Name : TB_KED_EW_STATUS
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
							
							String[] line = (" " + s +" ").split("\\|");
							
							int i = 0;
							paramMap.put("ewCd", line[i++].trim());
							paramMap.put("registeredCompany", line[i++].trim());
							paramMap.put("registeredOwnerName", line[i++].trim());
							paramMap.put("regDate", line[i++].trim());
							paramMap.put("chgDate", line[i++].trim());
							paramMap.put("businessNumber", line[i++].trim());
							paramMap.put("corporationNumber", line[i++].trim());
							paramMap.put("registrationNumber", line[i++].trim());
							paramMap.put("delYn", line[i++].trim());
	
							jobScheduledDao.mergeKedEwStatus(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5002_lgmma.txt":	//  // KED5002_lgmma.txt 업체개요, Table_Name : TB_KED_COMPANY
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
	
							String[] line = (" " + s +" ").split("\\|");
	
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("kedName", line[i++].trim());
							paramMap.put("tradeName", line[i++].trim());
							paramMap.put("englishName", line[i++].trim());
							paramMap.put("enterpriseType", line[i++].trim());
							paramMap.put("companyScale", line[i++].trim());
							paramMap.put("graduationDate", line[i++].trim());
							paramMap.put("enterpriseForm", line[i++].trim());
							paramMap.put("establishmentForm", line[i++].trim());
							paramMap.put("corporateStatus", line[i++].trim());
							paramMap.put("corporateStatusChangeDate", line[i++].trim());
							paramMap.put("publicInstitution", line[i++].trim());
							paramMap.put("ventureBusiness", line[i++].trim());
							paramMap.put("businessTypeBackForth", line[i++].trim());
							paramMap.put("businessCategory", line[i++].trim());
							paramMap.put("financeIndustryCode", line[i++].trim());
							paramMap.put("groupCode", line[i++].trim());
							paramMap.put("groupName", line[i++].trim());
							paramMap.put("corporationNumber", line[i++].trim());
							paramMap.put("establishmentDate", line[i++].trim());
							paramMap.put("disclosureCode", line[i++].trim());
							paramMap.put("businessReportNumber", line[i++].trim());
							paramMap.put("listingDate", line[i++].trim());
							paramMap.put("delistingDate", line[i++].trim());
							paramMap.put("creditInstitutionCode", line[i++].trim());
							paramMap.put("creditInstitutionName", line[i++].trim());
							paramMap.put("checkingBank", line[i++].trim());
							paramMap.put("transactionBankName", line[i++].trim());
							paramMap.put("settlementBaseDate", line[i++].trim());
							paramMap.put("homePage", line[i++].trim());
							paramMap.put("email", line[i++].trim());
							paramMap.put("informationStandardDate", line[i++].trim());
							paramMap.put("businessNumber", line[i++].trim());
							paramMap.put("addressZipCode", line[i++].trim());
							paramMap.put("addressZipCodeAddress", line[i++].trim());
							paramMap.put("remainingAddress", line[i++].trim());
							paramMap.put("phoneNumber", line[i++].trim());
							paramMap.put("faxNumber", line[i++].trim());
							paramMap.put("workerNumber", line[i++].trim().replaceAll(",", ""));
							paramMap.put("productName", line[i++].trim());
							paramMap.put("industryCode", line[i++].trim());
							paramMap.put("relatedKedCode", line[i++].trim());
							paramMap.put("relatedEstablishmentDate", line[i++].trim());
							paramMap.put("roadNameZipCode", line[i++].trim());
							paramMap.put("roadNameZipCodeAddress", line[i++].trim());
							paramMap.put("roadNameRemainingAddress", line[i++].trim());
							paramMap.put("roadNameAddressConfirmation", line[i++].trim());
							paramMap.put("confirmLocationAddress", line[i++].trim());
	
							jobScheduledDao.mergeKedCompany(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5003_lgmma.txt": // KED5003_lgmma.txt 주요재무정보, Table_Name : TB_KED_FINANCIAL_INFOMATION
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
	
							String[] line = (" " + s +" ").split("\\|");
	
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("baseDate", line[i++].trim());
							paramMap.put("totalAssets", line[i++].trim().replaceAll(",", ""));
							paramMap.put("paidInCapital", line[i++].trim().replaceAll(",", ""));
							paramMap.put("totalEquity", line[i++].trim().replaceAll(",", ""));
							paramMap.put("totalSales", line[i++].trim().replaceAll(",", ""));
							paramMap.put("operatingProfit", line[i++].trim().replaceAll(",", ""));
							paramMap.put("netIncome", line[i++].trim().replaceAll(",", "").trim());
	
							jobScheduledDao.mergeKedFinancialInfo(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5004_lgmma.txt": // KED5004_lgmma.txt 대표자정보, Table_Name : TB_KED_REPRESENTATIVE_INFO
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
	
							String[] line = (" " + s +" ").split("\\|");
	
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("characterCode", line[i++].trim());
							paramMap.put("infoStandardDate", line[i++].trim());
							paramMap.put("representativeName", line[i++].trim());
							paramMap.put("izno", line[i++].trim());
							paramMap.put("classificationCode", line[i++].trim());
							paramMap.put("representativeDisplayYn", line[i++].trim());
							paramMap.put("inaugurationDate", line[i++].trim());
							paramMap.put("retirementDate", line[i++].trim());
							paramMap.put("incumbentYn", line[i++].trim());
							paramMap.put("spot", line[i++].trim());
							paramMap.put("businessForm", line[i++].trim());
							paramMap.put("yearRepresentative", line[i++].trim().replaceAll(",", ""));
							paramMap.put("monthRepresentative", line[i++].trim().replaceAll(",", ""));
							paramMap.put("employmentYear", line[i++].trim().replaceAll(",", ""));
							paramMap.put("employmentMonth", line[i++].trim().replaceAll(",", ""));
							paramMap.put("flatCode", line[i++].trim());
							paramMap.put("relationCode", line[i++].trim());
							paramMap.put("abilityCode", line[i++].trim());
							paramMap.put("ordinaryStock", line[i++].trim().replaceAll(",", ""));
							paramMap.put("preferredStock", line[i++].trim().replaceAll(",", ""));
							paramMap.put("stockOption", line[i++].trim().replaceAll(",", ""));
							paramMap.put("remark", line[i++].trim());
	
							jobScheduledDao.mergeKedRepresentativeInfo(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5005_lgmma.txt": // KED5005_lgmma.txt 대표자인물정보, Table_Name : TB_KED_PERSON_INFO
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
	
							String[] line = (" " + s +" ").split("\\|");
	
							int i = 0;
							paramMap.put("personCode", line[i++].trim());
							paramMap.put("personName", line[i++].trim());
							paramMap.put("personEngName", line[i++].trim());
							paramMap.put("izno", line[i++].trim());
							paramMap.put("birthday", line[i++].trim());
							paramMap.put("classificationCode", line[i++].trim());
							paramMap.put("nationality", line[i++].trim());
							paramMap.put("phoneNumber", line[i++].trim());
							paramMap.put("faxNumber", line[i++].trim());
							paramMap.put("email", line[i++].trim());
							paramMap.put("zipCode", line[i++].trim());
							paramMap.put("zipCodeAddress", line[i++].trim());
							paramMap.put("remainingAddress", line[i++].trim());
							paramMap.put("familyMatterCode", line[i++].trim());
							paramMap.put("familyMatterContents", line[i++].trim());
							paramMap.put("healtehState", line[i++].trim());
							paramMap.put("hobby", line[i++].trim());
							paramMap.put("religion", line[i++].trim());
							paramMap.put("specialty", line[i++].trim());
							paramMap.put("certificate", line[i++].trim());
							paramMap.put("awardContents", line[i++].trim());
							paramMap.put("residenceZipCode", line[i++].trim());
							paramMap.put("residenceZipCodeAddress", line[i++].trim());
							paramMap.put("residenceRemainingAddress", line[i++].trim());
							paramMap.put("siteScaleM", line[i++].trim().replaceAll(",", ""));
							paramMap.put("siteScaleP", line[i++].trim().replaceAll(",", ""));
							paramMap.put("buildingScaleM", line[i++].trim().replaceAll(",", ""));
							paramMap.put("buildingScaleP", line[i++].trim().replaceAll(",", ""));
							paramMap.put("residenceDv", line[i++].trim());
							paramMap.put("residenceQuoteCharter", line[i++].trim().replaceAll(",", ""));
							paramMap.put("residenceQuoteBasedate", line[i++].trim());
							paramMap.put("residenceQuoteSource", line[i++].trim());
							paramMap.put("owner", line[i++].trim());
							paramMap.put("ownerIzno", line[i++].trim());
							paramMap.put("ownerIznoRelation", line[i++].trim());
							paramMap.put("leaseDeposit", line[i++].trim().replaceAll(",", ""));
							paramMap.put("monthlyRentCost", line[i++].trim().replaceAll(",", ""));
							paramMap.put("ownYn", line[i++].trim());
							paramMap.put("rightPrejudiceYn", line[i++].trim());
							paramMap.put("guaranteeOfferYn", line[i++].trim());
							paramMap.put("guaranteeSettingPrice", line[i++].trim().replaceAll(",", ""));
							paramMap.put("settingContents", line[i++].trim());
							paramMap.put("income", line[i++].trim().replaceAll(",", ""));
							paramMap.put("propertyTaxPay", line[i++].trim().replaceAll(",", ""));
							paramMap.put("realEstatePay", line[i++].trim().replaceAll(",", ""));
							paramMap.put("remark", line[i++].trim());
							paramMap.put("standardDate", line[i++].trim());
							paramMap.put("roadNameZipCode", line[i++].trim());
							paramMap.put("roadNameZipCodeAddress", line[i++].trim());
							paramMap.put("roadNameRemainingAddress", line[i++].trim());
							paramMap.put("roadNameConfirmYn", line[i++].trim());
							paramMap.put("addreassConfirmYn", line[i++].trim());
							paramMap.put("roadNameResidenceZipCode", line[i++].trim());
							paramMap.put("roadNameResidenceZipCodeAddress", line[i++].trim());
							paramMap.put("roadNameResidenceRemainingAddress", line[i++].trim());
							paramMap.put("roadNameResidenceConfirmYn", line[i++].trim());
							paramMap.put("residenceConfirmYn", line[i++].trim());
	
							jobScheduledDao.mergeKedPersonInfo(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5008_lgmma.txt": // KED5008_lgmma.txt 경영진주요정보, Table_Name : TB_KED_EXECUTIVE_INFO
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
	
							String[] line = (" " + s +" ").split("\\|");
	
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("personCode", line[i++].trim());
							paramMap.put("infoStandardDate", line[i++].trim());
							paramMap.put("personName", line[i++].trim());
							paramMap.put("personIzno", line[i++].trim());
							paramMap.put("executiveDvCode", line[i++].trim());
							paramMap.put("registrredYn", line[i++].trim());
							paramMap.put("inaugurationDate", line[i++].trim());
							paramMap.put("retirementDate", line[i++].trim());
							paramMap.put("incumbentYn", line[i++].trim());
							paramMap.put("spot", line[i++].trim());
							paramMap.put("chargeTask", line[i++].trim());
							paramMap.put("seviceYear", line[i++].trim().replaceAll(",", ""));
							paramMap.put("yearRepresentative", line[i++].trim().replaceAll(",", ""));
							paramMap.put("monthRepresentative", line[i++].trim().replaceAll(",", ""));
							paramMap.put("relationCode", line[i++].trim());
							paramMap.put("ordinaryStock", line[i++].trim().replaceAll(",", ""));
							paramMap.put("preferredStock", line[i++].trim().replaceAll(",", ""));
							paramMap.put("stockOption", line[i++].trim().replaceAll(",", ""));
							paramMap.put("remark", line[i++].trim());
	
							jobScheduledDao.mergeKedExecutiveInfo(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5009_lgmma.txt": // KED5009_lgmma.txt 기업연혁, Table_Name : TB_KED_ENTERPRISE_INFO
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
	
							String[] line = (" " + s +" ").split("\\|");
	
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("serialNumber", line[i++].trim());
							paramMap.put("historyDv", line[i++].trim());
							paramMap.put("historyDate", line[i++].trim());
							paramMap.put("historyContents", line[i++].trim());
							paramMap.put("remark", line[i++].trim());
							paramMap.put("infoStandardDate", line[i++].trim());
	
							jobScheduledDao.mergeKedEnterpriseInfo(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5010_lgmma.txt": // KED5010_lgmma.txt 목적사업, Table_Name : TB_KED_PURPOSE_BUSINESS
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
							
							String[] line = (" " + s +" ").split("\\|");
							
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("baseMonth", line[i++].trim());
							paramMap.put("serialNumber", line[i++].trim());
							paramMap.put("purposeBusiness", line[i++].trim());
							paramMap.put("remark", line[i++].trim());
							paramMap.put("infoStandardDate", line[i++].trim());
	
							jobScheduledDao.mergeKedPurposeBusiness(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5011_lgmma.txt": // KED5011_lgmma.txt 관계회사, Table_Name : TB_KED_RELATION_COMPANY
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
							
							String[] line = (" " + s +" ").split("\\|");
							
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("infoStandardDate", line[i++].trim());
							paramMap.put("serialNumber", line[i++].trim());
							paramMap.put("associatedCompayName", line[i++].trim());
							paramMap.put("coporationNumber", line[i++].trim());
							paramMap.put("associatedKedCd", line[i++].trim());
							paramMap.put("associatedRpsName", line[i++].trim());
							paramMap.put("associatedZipCode", line[i++].trim());
							paramMap.put("associatedZipCodeAddress", line[i++].trim());
							paramMap.put("associatedRemainingAddress", line[i++].trim());
							paramMap.put("associatedBusinessCategory", line[i++].trim());
							paramMap.put("associatedMainProd", line[i++].trim());
							paramMap.put("associatedSattlemetnDate", line[i++].trim());
							paramMap.put("associatedCapital", line[i++].trim().replaceAll(",", ""));
							paramMap.put("associatedTotalAssets", line[i++].trim().replaceAll(",", ""));
							paramMap.put("associatedTotalSales", line[i++].trim().replaceAll(",", ""));
							paramMap.put("associatedNetIncome", line[i++].trim().replaceAll(",", ""));
							paramMap.put("equityRatio", line[i++].trim().replaceAll(",", ""));
							paramMap.put("purchaseAmount", line[i++].trim().replaceAll(",", ""));
							paramMap.put("purchaseAmountWeight", line[i++].trim().replaceAll(",", ""));
							paramMap.put("salesAmount", line[i++].trim().replaceAll(",", ""));
							paramMap.put("salesAmountWeight", line[i++].trim().replaceAll(",", ""));
							paramMap.put("guaranteePayment", line[i++].trim().replaceAll(",", ""));
							paramMap.put("totAmountBonds", line[i++].trim().replaceAll(",", ""));
							paramMap.put("totAmountDebt", line[i++].trim().replaceAll(",", ""));
							paramMap.put("relevantContent", line[i++].trim());
							paramMap.put("roadNameZipCode", line[i++].trim());
							paramMap.put("roadNameZipCodeAddress", line[i++].trim());
							paramMap.put("roadNameRemainingAddress", line[i++].trim());
							paramMap.put("roadNameResidenceConfirmYn", line[i++].trim());
							paramMap.put("associatedAddressConfirmYn", line[i++].trim());
	
							jobScheduledDao.mergeKedRelationCompany(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5013_lgmma.txt": // KED5013_lgmma.txt 주주현황, Table_Name : TB_KED_HOLDER_STATUS
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
							
							String[] line = (" " + s +" ").split("\\|");
							
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("infoStandardDate", line[i++].trim());
							paramMap.put("serialNumber", line[i++].trim());
							paramMap.put("shareholderDv", line[i++].trim());
							paramMap.put("shareholderName", line[i++].trim());
							paramMap.put("kedPersonCode", line[i++].trim());
							paramMap.put("corporationNumber", line[i++].trim());
							paramMap.put("realEstateRsCode", line[i++].trim());
							paramMap.put("companyRsCode", line[i++].trim());
							paramMap.put("ownershipStock", line[i++].trim().replaceAll(",", ""));
							paramMap.put("commonStock", line[i++].trim().replaceAll(",", ""));
							paramMap.put("preferredStock", line[i++].trim().replaceAll(",", ""));
							paramMap.put("equityRatio", line[i++].trim().replaceAll(",", ""));
							paramMap.put("commonStockRatio", line[i++].trim().replaceAll(",", ""));
							paramMap.put("preferredStockRatio", line[i++].trim().replaceAll(",", ""));
							paramMap.put("ownershipStockAmount", line[i++].trim().replaceAll(",", ""));
							paramMap.put("remark", line[i++].trim());
	
							jobScheduledDao.mergeKedHolderStatus(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5014_lgmma.txt": // KED5014_lgmma.txt 사업장, Table_Name : TB_KED_WORKSPACE
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
							
							String[] line = (" " + s +" ").split("\\|");
							
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("workspaceDv", line[i++].trim());
							paramMap.put("serialNumber", line[i++].trim());
							paramMap.put("businessNumber", line[i++].trim());
							paramMap.put("workspaceName", line[i++].trim());
							paramMap.put("mainBusinessYn", line[i++].trim());
							paramMap.put("operationStatus", line[i++].trim());
							paramMap.put("registrationStatus", line[i++].trim());
							paramMap.put("locationZipCode", line[i++].trim());
							paramMap.put("locationZipCodeAddress", line[i++].trim());
							paramMap.put("locationRemainingAddress", line[i++].trim());
							paramMap.put("phoneNumber", line[i++].trim());
							paramMap.put("faxNumber", line[i++].trim());
							paramMap.put("taxOfficeName", line[i++].trim());
							paramMap.put("mainProd", line[i++].trim());
							paramMap.put("locationCondition", line[i++].trim());
							paramMap.put("pollutionConntrolYn", line[i++].trim());
							paramMap.put("complexName", line[i++].trim());
							paramMap.put("otherLocationCondition", line[i++].trim());
							paramMap.put("landSizeM", line[i++].trim().replaceAll(",", ""));
							paramMap.put("landSizeP", line[i++].trim().replaceAll(",", ""));
							paramMap.put("buildingSizeM", line[i++].trim().replaceAll(",", ""));
							paramMap.put("buildingSizeP", line[i++].trim().replaceAll(",", ""));
							paramMap.put("owner", line[i++].trim());
							paramMap.put("ownerCorporationNumber", line[i++].trim());
							paramMap.put("ownerRsCode", line[i++].trim());
							paramMap.put("possessionStatus", line[i++].trim());
							paramMap.put("leaseDeposit", line[i++].trim().replaceAll(",", ""));
							paramMap.put("leaseDepositAmountCode", line[i++].trim());
							paramMap.put("monthlyRent", line[i++].trim().replaceAll(",", ""));
							paramMap.put("monthlyRentAmountCode", line[i++].trim());
							paramMap.put("violationStatus", line[i++].trim());
							paramMap.put("collateralSecurityYn", line[i++].trim());
							paramMap.put("settingAmount", line[i++].trim().replaceAll(",", ""));
							paramMap.put("settingContents", line[i++].trim());
							paramMap.put("remark", line[i++].trim());
							paramMap.put("infoStandardDate", line[i++].trim());
							paramMap.put("roadNameZipCode", line[i++].trim());
							paramMap.put("roadNameZipCodeAddress", line[i++].trim());
							paramMap.put("roadNameRemainingAddress", line[i++].trim());
							paramMap.put("roadNameResidenceConfirmYn", line[i++].trim());
							paramMap.put("locationResidenceConfirmYn", line[i++].trim());
	
							jobScheduledDao.mergeKedWorkspace(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED50024_lgmma.txt": // KED5024_lgmma.txt 지적재산권, Table_Name : TB_KED_INTELLECTUAL_RIGHT
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
							
							String[] line = (" " + s +" ").split("\\|");
							
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("serialNumber", line[i++].trim());
							paramMap.put("domesticDv", line[i++].trim());
							paramMap.put("intellectualRightKind", line[i++].trim());
							paramMap.put("intellectualRightName", line[i++].trim());
							paramMap.put("registrationStatus", line[i++].trim());
							paramMap.put("registrationDate", line[i++].trim());
							paramMap.put("registrationNo", line[i++].trim());
							paramMap.put("rightContents", line[i++].trim());
							paramMap.put("rightHolder", line[i++].trim());
							paramMap.put("companyRsCode", line[i++].trim());
							paramMap.put("remark", line[i++].trim());
							paramMap.put("infoStandardDate", line[i++].trim());
	
							jobScheduledDao.mergeKedIntellectualRight(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5026_lgmma.txt": // KED5026_lgmma.txt 주요거래처, Table_Name : TB_KED_MAJOR_CUSTOMER
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
							
							String[] line = (" " + s +" ").split("\\|");
							
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("infoStandardDate", line[i++].trim());
							paramMap.put("purchaseDv", line[i++].trim());
							paramMap.put("serialNumber", line[i++].trim());
							paramMap.put("amonutStartDate", line[i++].trim());
							paramMap.put("amonutEndDate", line[i++].trim());
							paramMap.put("custName", line[i++].trim());
							paramMap.put("phoneNumber", line[i++].trim());
							paramMap.put("businessNumber", line[i++].trim());
							paramMap.put("custKedCd", line[i++].trim());
							paramMap.put("domesticDv", line[i++].trim());
							paramMap.put("transactionType", line[i++].trim());
							paramMap.put("prodName", line[i++].trim());
							paramMap.put("prodCode", line[i++].trim());
							paramMap.put("annualAmount", line[i++].trim().replaceAll(",", ""));
							paramMap.put("transactionRatio", line[i++].trim().replaceAll(",", ""));
							paramMap.put("transactionPeriod", line[i++].trim().replaceAll(",", ""));
							paramMap.put("cashPaymentRatio", line[i++].trim().replaceAll(",", ""));
							paramMap.put("creditPaymentRatio", line[i++].trim().replaceAll(",", ""));
							paramMap.put("creditPaymentPeriod", line[i++].trim().replaceAll(",", ""));
							paramMap.put("otherTerms", line[i++].trim());
							paramMap.put("remark", line[i++].trim());
	
							jobScheduledDao.mergeKedMajorCustomer(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5041_lgmma.txt": // KED5041_lgmma.txt 종합신용등급, Table_Name : TB_KED_OVERALL_CREDIT_RATING
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
							
							String[] line = (" " + s +" ").split("\\|");
							
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("registratonDate", line[i++].trim());
							paramMap.put("evalutionDate", line[i++].trim());
							paramMap.put("settlementDate", line[i++].trim());
							paramMap.put("ratingClass", line[i++].trim());
							paramMap.put("creditRating", line[i++].trim());
							paramMap.put("modelEvalutionDate", line[i++].trim());
							paramMap.put("invMothodDv", line[i++].trim());
							paramMap.put("rsOpenDate", line[i++].trim());
							paramMap.put("rsCloseDate", line[i++].trim());
	
							jobScheduledDao.mergeKedOverallCreditRating(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5050_lgmma.txt": // KED5050_lgmma.txt 현금흐름등급, Table_Name : TB_KED_CASH_FLOW_CLASS
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
							
							String[] line = (" " + s +" ").split("\\|");
							
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("standardDate", line[i++].trim());
							paramMap.put("financialInfoDv", line[i++].trim());
							paramMap.put("settlementDv", line[i++].trim());
							paramMap.put("accountCode", line[i++].trim());
							paramMap.put("itemValue", line[i++].trim().replaceAll(",", ""));
							paramMap.put("itemString", line[i++].trim());
	
							jobScheduledDao.mergeKedCashFlowClass(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				case "KED5063_lgmma.txt": // KED5063_lgmma.txt (신회계)재무비율Data, Table_Name : TB_KED_FINANCIAL_RATIO
					while ((s = br.readLine()) != null) {
						try {
							Map<String, String> paramMap = new HashMap<String, String>();
							
							String[] line = (" " + s +" ").split("\\|");
							
							int i = 0;
							paramMap.put("kedCd", line[i++].trim());
							paramMap.put("standardDate", line[i++].trim());
							paramMap.put("settlementDv", line[i++].trim());
							paramMap.put("accountPCode", line[i++].trim());
							paramMap.put("financialInfoDv", line[i++].trim());
							paramMap.put("financialIndustry", line[i++].trim());
							paramMap.put("reportDv", line[i++].trim());
							paramMap.put("accountCode", line[i++].trim());
							paramMap.put("itemValue", line[i++].trim().replaceAll(",", ""));
							paramMap.put("calcError", line[i++].trim());
							paramMap.put("infoStandardDate", line[i++].trim());
	
							jobScheduledDao.mergeKedFinancialRatio(paramMap);
						} catch (Exception e1) {e1.printStackTrace();}
					}
					break;

				default:
					break;
				}
			}

			zip.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	@Async("jobScheduledExecutor")
	@Override
	public void exeUploadKedCompanyInfo() {
		String path = "/home/lgmma/enplist";
		String fileName = DateUtil.getToday() + ".txt";
		String writePath = "D:/applicationUploadFolder/salesPortal/enplist/";
//		String writePath = "D:/SalesPortal/enplist/";

		String txt = "";

		for(NiceCompGradeVO compVo : jobScheduledDao.getCompListForUploadKed())
			txt += compVo.getStcd2() + "000" + compVo.getStcd2() + String.format("%-63s", "") + "1N\n";

		if(!"".equals(txt)) {
			try {
				File f = new File(writePath + fileName);
				if(f.exists())	f.delete();

				BufferedWriter fw = new BufferedWriter(new FileWriter(writePath + fileName, true));

				fw.write(txt.substring(0, txt.length() - 1));
				fw.flush();
				fw.close();

				connectInit();

				channelSftp.cd(path);
				FileInputStream fis = new FileInputStream(f);
				channelSftp.put(fis, f.getName());
				fis.close();

				disconnect();
			} catch (Exception e) {e.printStackTrace();}
		}
	}

	@Override
	public void exeSendCollectExpectedDateMail() {
		CollectExpectedDateVO param = new CollectExpectedDateVO();
		param = (CollectExpectedDateVO)StringUtil.nullToEmptyString(param);
		param.setGjahr(new SimpleDateFormat("yyyy.MM.dd").format(new Date()));
		param.setRemainingday("7");
		param.setSalesOrg("");

		List<UserInfo> userInfoList = jobScheduledDao.getSalesEmpInfoAll();
		String receiverEmail4000 = "";
		String receiverEmail7426 = ""; //이주영선임 추가
		String receiverEmail4001 = "";
		String receiverEmail5000 = "";

		for(UserInfo user : userInfoList) {
			if("H4000".equals(user.getTeamCode()) && "AF0".equals(user.getPosiCode())) {			//영업담당
				receiverEmail4000 = user.getMailAddr();
			} else if("H4001".equals(user.getTeamCode()) && "DC_4".equals(user.getPosiCode())) {	//M영업팀장
				receiverEmail4001 = user.getMailAddr();
			} else if("H5000".equals(user.getTeamCode()) && "DC_4".equals(user.getPosiCode())) {	//P영업팀장
				receiverEmail5000 = user.getMailAddr();
			} else if("07426".equals(user.getSawnCode())) {                                         //이주영선임 영업담당자와 똑같은 메일 받기위해 추가
				receiverEmail7426 = user.getMailAddr();
			}
		}

		Map<String,String> paramMap = new HashMap<>();
		List<CollectExpectedDateVO> resultList = sapSearchService.getCollectExpectedDateList(param);

		if(resultList.size() > 0) {
			// 영업담당
			paramMap.put("result", makeCollectExpectedDateResult(resultList));
			SendMailVO sendMailVO4000 = new SendMailVO();
			sendMailVO4000.setMailType(MailType.COLLECT_EXPECTED_DATE);
			sendMailVO4000.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
			sendMailVO4000.setParams(paramMap);
			sendMailVO4000.setReceiverEmail(receiverEmail4000);
			mailingService.sendMail(sendMailVO4000);
			
			//이주영선임
			paramMap.put("result", makeCollectExpectedDateResult(resultList));
			SendMailVO sendMailV7426 = new SendMailVO();
			sendMailVO4000.setMailType(MailType.COLLECT_EXPECTED_DATE);
			sendMailVO4000.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
			sendMailVO4000.setParams(paramMap);
			sendMailVO4000.setReceiverEmail(receiverEmail7426);
			mailingService.sendMail(sendMailV7426);

			// 재경담당자
			for(UserInfo user : loginDao.getCreditEmpUserInfo("")) {
				SendMailVO sendMailVO = new SendMailVO();
				sendMailVO.setMailType(MailType.COLLECT_EXPECTED_DATE);
				sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
				sendMailVO.setParams(paramMap);
				sendMailVO.setReceiverEmail(user.getMailAddr());
				mailingService.sendMail(sendMailVO);
			}
		}

		param.setSalesOrg("1000");
		resultList = sapSearchService.getCollectExpectedDateList(param);
		if(resultList.size() > 0) {
			// MMA영업팀
			paramMap.put("result", makeCollectExpectedDateResult(resultList));
			SendMailVO sendMailVO4001 = new SendMailVO();
			sendMailVO4001.setMailType(MailType.COLLECT_EXPECTED_DATE);
			sendMailVO4001.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
			sendMailVO4001.setParams(paramMap);
			sendMailVO4001.setReceiverEmail(receiverEmail4001);
			mailingService.sendMail(sendMailVO4001);
		}

		param.setSalesOrg("3000");
		resultList = sapSearchService.getCollectExpectedDateList(param);
		if(resultList.size() > 0) {
			// PMMA영업팀
			paramMap.put("result", makeCollectExpectedDateResult(resultList));
			SendMailVO sendMailVO5000 = new SendMailVO();
			sendMailVO5000.setMailType(MailType.COLLECT_EXPECTED_DATE);
			sendMailVO5000.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
			sendMailVO5000.setParams(paramMap);
			sendMailVO5000.setReceiverEmail(receiverEmail5000);
			mailingService.sendMail(sendMailVO5000);
		}

		// 영업담당자별
		for(UserInfo user : userInfoList) {
			param.setSalesOrg(user.getVkorg());
			param.setcApprEmpId(user.getSawnCode());
			resultList = sapSearchService.getCollectExpectedDateList(param);
			if(resultList.size() > 0) {
				paramMap.put("result", makeCollectExpectedDateResult(resultList));
				SendMailVO sendMailVO = new SendMailVO();
				sendMailVO.setMailType(MailType.COLLECT_EXPECTED_DATE);
				sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
				sendMailVO.setParams(paramMap);
				sendMailVO.setReceiverEmail(user.getMailAddr());
				mailingService.sendMail(sendMailVO);
			}
		}
	}

	@Override
	public void test() {
		
	}

	private void connectInit(){
		String uid = "lgmma";
		String pwd = "lgmmaked12!@";
		String host = "218.55.37.150";
		int port = 22;

		JSch jsch = new JSch();

		try {
			session = jsch.getSession(uid, host, port);
			session.setPassword(pwd);

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);

			session.connect();

			channel = session.openChannel("sftp");
			channel.connect();
		} catch (JSchException e) {
			e.printStackTrace();
		}

		channelSftp = (ChannelSftp) channel;
	}

	private void disconnect() {
		channelSftp.quit();
		session.disconnect();
	}

	private void download() {
		InputStream in = null;
		FileOutputStream out = null;

		String path = "/home/lgmma/enpinfo";
		String fileName = "lgmma_" + (DateUtil.defaultFormatDate(DateUtil.getToday()).replace(".", "")) + ".jar";
		String downPath = "D:/applicationUploadFolder/salesPortal/enpinfo/";

		try {
			File f = new File(downPath + fileName);
			if(f.exists())	f.delete();

			channelSftp.cd(path);
			in = channelSftp.get(fileName);
			out = new FileOutputStream(new File(downPath + fileName));

			int i;
			while ((i = in.read()) != -1)
				out.write(i);

			out.close();
			in.close();
		} catch (SftpException se) {
			se.printStackTrace();
		} catch (java.io.IOException e) {
			e.printStackTrace();
		}
	}

	@Async("jobScheduledExecutor")
	@Override
	public void exeUpdateCompGradeFromCretop() {
		NiceCompGradeVO vo = new NiceCompGradeVO();
		vo.setStcd2("");

		List<NiceCompGradeVO> compList = jobScheduledDao.getCompListForUpdateGrade(vo);
		for(NiceCompGradeVO compVo : compList) {
			try {
				//등급 가져오기
				Map<String, String> tmpNode = jobScheduledDao.getKedToNiceGrade(compVo.getStcd2());
				NiceCompGradeVO finalVo = jobScheduledDao.getFinalCompGrade(compVo);

				if(finalVo == null)
					finalVo = new NiceCompGradeVO();
				finalVo = (NiceCompGradeVO) StringUtil.nullToEmptyString(finalVo);

				boolean chk = tmpNode.get("WATCH_GRADE_CODE").trim().equals("");

				NiceCompGradeVO niceVo = new NiceCompGradeVO();
				niceVo.setKisGrade(tmpNode.get("KIS_GRADE").trim());
				niceVo.setWatchGrade(chk ? finalVo.getWatchGrade() : tmpNode.get("WATCH_GRADE").trim());
				niceVo.setCfGrade(tmpNode.get("CF_GRADE").trim());
				niceVo.setOtStop(tmpNode.get("OT_STOP").trim());
				niceVo.setStMg(tmpNode.get("ST_MG").trim());
				niceVo.setWatchGradeCode(chk ? finalVo.getWatchGradeCode() : tmpNode.get("WATCH_GRADE_CODE").trim());

				StringBuffer sb = new StringBuffer();
				if(!niceVo.getKisGrade().equals(finalVo.getKisGrade())) {
					sb.append("KIS신용등급 : " + finalVo.getKisGrade() + " -> " + niceVo.getKisGrade() + " ");
				}
				if(!niceVo.getWatchGrade().equals(finalVo.getWatchGrade())) {
					sb.append("WATCH등급 : " + finalVo.getWatchGrade() + " -> " + niceVo.getWatchGrade() + " ");
				}
				if(!niceVo.getCfGrade().equals(finalVo.getCfGrade())) {
					sb.append("현금흐름 : " + finalVo.getCfGrade() + " -> " + niceVo.getCfGrade() + " ");
				}
				if(!niceVo.getOtStop().equals(finalVo.getOtStop())) {
					sb.append("당좌거래정지/부도 : " + finalVo.getOtStop() + " -> " + niceVo.getOtStop() + " ");
				}
				if(!niceVo.getStMg().equals(finalVo.getStMg())) {
					sb.append("법정관리/화의 : " + finalVo.getStMg() + " -> " + niceVo.getStMg() + " ");
				}
				niceVo.setModiNote(sb.toString());
				niceVo.setCompFlag(niceVo.getModiNote().equals("") ? "N" : "Y");
				niceVo.setKisdate(DateUtil.getToday());
				niceVo.setStcd2(compVo.getOrgiStcd());
				jobScheduledDao.createNiceCompanyGrade(niceVo);

				CompanyVO companyVo = new CompanyVO();
				companyVo.setCompGrade(companyService.exchangeValue(niceVo.getKisGrade()));
				companyVo.setWatchGrade(niceVo.getWatchGradeCode());
				companyVo.setStcd2(compVo.getOrgiStcd());

				jobScheduledDao.updateCompanyGrade(companyVo);
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		logger.debug("----------------------------------------");
	}

	private String makeCollectExpectedDateResult(List<CollectExpectedDateVO> resultList) {
		String result = "";
		DecimalFormat formatter = new DecimalFormat("###,###.##");

		for(CollectExpectedDateVO data : resultList) {
			result += "<tr>"
					+ "<td style='text-align:center;'>" + data.getEname() + "</td>"
					+ "<td style='text-align:center;'>" + data.getKunnr() + "</td>"
					+ "<td>" + data.getName1() + "</td>"
					+ "<td>" + data.getCivno() + "</td>"
					+ "<td style='text-align:center;'>" + data.getFkdat() + "</td>"
					+ "<td style='text-align:right;'>" + formatter.format(Double.parseDouble(data.getDmbtr())) + "</td>"
					+ "<td style='text-align:center;'>" + data.getZfbdt() + "</td>"
					+ "<td style='text-align:right;'>" + data.getDtcnt() + "</td>"
					+ "</tr>";
		}
		return result;
	}
}
