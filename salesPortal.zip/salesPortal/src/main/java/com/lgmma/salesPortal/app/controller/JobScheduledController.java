package com.lgmma.salesPortal.app.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lgmma.salesPortal.app.model.DirectOrderMigVO;
import com.lgmma.salesPortal.app.model.DisplayOrderLotVO;
import com.lgmma.salesPortal.app.model.IcisVO;
import com.lgmma.salesPortal.app.model.JobScheduleParamVO;
import com.lgmma.salesPortal.app.service.CacheEvictService;
import com.lgmma.salesPortal.app.service.DirectOrderMigService;
import com.lgmma.salesPortal.app.service.MsService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.model.DDLBItem;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.schedule.service.JobScheduledService;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;

@Controller
@RequestMapping("/jobScheduled") 
public class JobScheduledController {
	private static Logger logger = LoggerFactory.getLogger(JobScheduledController.class); 

	@Autowired
	private JobScheduledService jobScheduledService;

	@Autowired
	private SapSearchService sapSearchService;

	@Autowired
	private CacheEvictService cacheEvictService;

	@Autowired
	private DirectOrderMigService directOrderMigService;

	@Autowired
	private MsService msService;

	/**
	 * 자재마스터 ERP에서 가져오기 수작업
	 * */
	@RequestMapping(value = "/excProductsFromSap.json")
	public Map excProductsFromSap() throws Exception {
		jobScheduledService.excProductsFromSap();
		return JsonResponse.asSuccessMsg("success", "저장되었습니다");
	}

	/**
	 * 재고마스터 ERP에서 가져오기 수작업
	 * */
	@RequestMapping(value = "/excProductStocksFromSap.json")
	public Map excProductStocksFromSap() throws Exception {
		jobScheduledService.excProductStocksFromSap();
		return JsonResponse.asSuccessMsg("success", "저장되었습니다");
	}

	/**
	 * 일별환율정보 ERP에서 가져오기 수작업
	 * */
	@RequestMapping(value = "/excExchangeRateFromSap.json")
	public Map excExchangeRateFromSap() throws Exception {
		jobScheduledService.excExchangeRateFromSap();
		return JsonResponse.asSuccessMsg("success", "저장되었습니다");
	}

	/**
	 * SAP 공통코드 가져오기 테스트
	 * @param zgubun
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/commonCodeListFromSap.json")
	public Map commonCodeListFromSap(String zgubun) throws Exception {
		List<DDLBItem> commonCodeList = sapSearchService.getSapCommonCodeList(zgubun);
		logger.debug("######################commonCodeListFromSap [ zgubun : "+zgubun+" ] ");
		for(DDLBItem l : commonCodeList)
			logger.debug("######################code : "+l.getCode()+", text : "+l.getText());
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	/**
	 * SAP 공통코드 캐시 초기화
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/cacheEvictSapRfcCommonCodeCache.json")
	public Map cacheEvictSapRfcCommonCodeCache() throws Exception {
		cacheEvictService.sapRfcCommonCodeCacheEvict();
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	/**
	 * 홈화면 차트 SAP 데이타 캐시 초기화
	 * @return
	 */
	@RequestMapping(value = "/cacheEvictSapRfcHomeChartCache.json")
	public Map cacheEvictSapRfcHomeChartCache() {
		cacheEvictService.sapRfcHomeChartCacheEvict();
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	/**
	 * 공통코드 모두 조회 데이타 캐시 초기화
	 * @return
	 */
	@RequestMapping(value = "/cacheEvictGetCommonCodeDbAllCache.json")
	public Map cacheEvictGetCommonCodeDbAllCache() {
		cacheEvictService.getCommonCodeDbAllCacheEvict();
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	/**
	 * 주문내역 MIG from sap 
	 * 운영에서 함부로 작업하지 말것!!!!
	 * sample url : http://local.salesportal.lgmmadev.com/jobScheduled/createDirectOrderMig.json?iDocDateF=20180601&iDocDateT=20180831
	 * @return
	 */
	@RequestMapping(value = "/createDirectOrderMig.json")
	public Map createDirectOrderMig(DirectOrderMigVO param) {
		/* 조건을 넣지 않으면 전체를 가져오게 되므로 위험하다.
			- 다음 조건중에서 판단해서 반드시 넣고 실행해야함
			private String iSalesOrg;
			private String iDistrChan;
			private String iDocDateF;
			private String iDocDateT;
			private String iVbeln;
		*/
		param = (DirectOrderMigVO) StringUtil.nullToEmptyString(param);
		if(param.getiVbeln().isEmpty()){
			if(param.getiDocDateF().isEmpty() || param.getiDocDateT().isEmpty()) {
				return JsonResponse.asFailure("sap 오더번호가 지정 되지 않은 경우 기간은 필수 입니다.");
			}
		}

		directOrderMigService.createDirectOrderMig(param);
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	//Home화면 MMA ICIS Test
	@RequestMapping(value = "/getIcisList.json" )
	public Map getIcisList(IcisVO param) throws Exception {
		String toDay = DateUtil.getToday();
		param.setPeMonthFr(DateUtil.addMonth(toDay, -6).substring(0, 6));
		param.setPeMonthTo(DateUtil.addMonth(toDay, 5).substring(0, 6));
		List<IcisVO>	icisList	= msService.getIcisList(param);
		return JsonResponse.asSuccess("storeData", icisList);
	}

	/**
	 * sap에서 주문 출하일자 맞추기
	 * @return
	 */
	@RequestMapping(value = "/excUpdateOrderWadatIstFromSap.json")
	public Map excUpdateOrderWadatIstFromSap(JobScheduleParamVO param) {
		jobScheduledService.excUpdateOrderWadatIstFromSap(param);

		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	/**
	 * sap에서 판매처정보전체가져오기
	 * @return
	 */
	@RequestMapping(value = "/excSyncCompOrganByErp.json")
	public Map excSyncCompOrganByErp() {
		jobScheduledService.excSyncCompOrganByErp();
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	/**
	 * sap에서 주문 Lot 번호 가져오기
	 * @return
	 */
	@RequestMapping(value = "/excOrderLotFromSap.json")
	public Map excOrderLotFromSap(String vbeln) {
		//0300151125	0300151127	0300151136	0300151141
		DisplayOrderLotVO param = new DisplayOrderLotVO();
		param.setI_VBELN(vbeln);
		jobScheduledService.excOrderLotFromSap(param);
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	/**
	 * NICE 평가정보를 조회 하여 tbc_company_grade 에 인서트 하고 TB_COMPANY 를 업데이트 한다. 
	 */
	@RequestMapping(value = "/exeUpdateCompGradeFromNICE.json")
	public void exeUpdateCompGradeFromNICE(@RequestParam(defaultValue = "") String stcd2) {
		jobScheduledService.exeUpdateCompGradeFromNICE(stcd2);
	}
	
	/**
	 * 평가정보를 ERP 에 전송. 
	 */
	@RequestMapping(value = "/exeSendCompGradeToERP.json")
	public void exeSendCompGradeToERP(@RequestParam(defaultValue = "") String kunnr) {
		jobScheduledService.exeSendCompGradeToERP(kunnr);
	}
	
	/**
	 * 담보 만료시 담당자에 메일전송, ERP에 담보금액 전송. 
	 */
	@RequestMapping(value = "/exeSendDamboExpiredMailERP.json")
	public void exeSendDamboExpiredMailERP() {
		jobScheduledService.exeSendDamboExpiredMailERP();
	}

	/**
	 * DISS 지연과제 지연 알람메일 보내기
	 * @return
	 */
	@RequestMapping(value = "/exeSendMailDISSDelayTaskAlarm.json")
	public Map exeSendMailDISSDelayTaskAlarm() {
		jobScheduledService.exeSendMailDISSDelayTaskAlarm();
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}
	
	/**
	 * DISS GateReview 지연 알람메일 보내기
	 * @return
	 */
	@RequestMapping(value = "/exeSendMailDISSDelayGateReviewAlarm.json")
	public Map exeSendMailDISSDelayGateReviewAlarm() {
		jobScheduledService.exeSendMailDISSDelayGateReviewAlarm();
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	/**
	 * 수출 거래선 신용등급 Update
	 * @return
	 */
	@RequestMapping(value = "/exeUpdateExpCompanyGradeFromSap.json")
	public Map exeUpdateExpCompanyGradeFromSap(@RequestParam(defaultValue = "") String kunnr) {
		jobScheduledService.exeUpdateExpCompanyGradeFromSap(kunnr);
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	/**
	 * 월매출 정보를 SAP에서 수신 
	 */
	@RequestMapping(value = "/exeGetMonthlySalesFromERP.json")
	public Map exeGetMonthlySalesFromERP(@RequestParam(required = true) String fromYyyyMm, @RequestParam(required = true) String toYyyyMm) {
		fromYyyyMm = fromYyyyMm + "01";
		toYyyyMm = toYyyyMm + "01";
		String yyyyMm = "";
		int i = 0;
		if(DateUtil.checkDate(fromYyyyMm) && DateUtil.checkDate(toYyyyMm)) {
			do {
				yyyyMm = DateUtil.addMonth(fromYyyyMm, i);
				jobScheduledService.exeGetMonthlySalesFromSap(yyyyMm.substring(0, 6));
				i++;
			} while (!yyyyMm.equals(toYyyyMm));
		} else {
			return JsonResponse.asFailure("날짜 형식이 올바르지 않습니다. yyyymm 형식으로 입력 하시기 바랍니다.");
		}
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	@RequestMapping(value = "/exeUpdateKedInfo.json")
	public Map exeUpdateKedInfo() throws Exception{
		jobScheduledService.exeUpdateKedInfo();
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	@RequestMapping(value = "/exeUploadKedCompanyInfo.json")
	public Map exeUploadKedCompanyInfo() {
		jobScheduledService.exeUploadKedCompanyInfo();
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	@RequestMapping(value = "/exeUpdateCompGradeFromCretop.json")
	public Map exeUpdateCompGradeFromCretop() {
		jobScheduledService.exeUpdateCompGradeFromCretop();
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}

	@RequestMapping(value = "/exeSendCollectExpectedDateMail.json")
	public void exeSendCollectExpectedDateMail() {
		jobScheduledService.exeSendCollectExpectedDateMail();
	}

	@RequestMapping(value = "/test.json")
	public Map test() {
		jobScheduledService.test();
		return JsonResponse.asSuccessMsg("success", "완료되었습니다.");
	}
}
