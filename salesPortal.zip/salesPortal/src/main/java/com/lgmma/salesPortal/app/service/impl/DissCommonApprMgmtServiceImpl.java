package com.lgmma.salesPortal.app.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.lgmma.salesPortal.app.dao.CommonApprDao;
import com.lgmma.salesPortal.app.dao.CommonDao;
import com.lgmma.salesPortal.app.dao.DissImpDevDao;
import com.lgmma.salesPortal.app.dao.DissMemberDao;
import com.lgmma.salesPortal.app.dao.DissOneTeamDao;
import com.lgmma.salesPortal.app.dao.DissOneTeamMinutesDao;
import com.lgmma.salesPortal.app.dao.DissScheduleDao;
import com.lgmma.salesPortal.app.dao.DissSpecInDao;
import com.lgmma.salesPortal.app.dao.DissStepDao;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissImpDevVO;
import com.lgmma.salesPortal.app.model.DissMemberVO;
import com.lgmma.salesPortal.app.model.DissOneTeamMinutesVO;
import com.lgmma.salesPortal.app.model.DissOneTeamVO;
import com.lgmma.salesPortal.app.model.DissScheduleVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.model.SmsVO;
import com.lgmma.salesPortal.app.service.CommonApprMgmtService;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.GPortalListTypeRestService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.SmsService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.props.ApplState;
import com.lgmma.salesPortal.common.props.ApprConfType;
import com.lgmma.salesPortal.common.props.ApprLineType;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.util.StringUtil;

@Transactional
@Service
public class DissCommonApprMgmtServiceImpl implements DissCommonApprMgmtService {
	private static Logger logger = LoggerFactory.getLogger(DissCommonApprMgmtServiceImpl.class);
	@Autowired
	private CommonApprDao commonApprDao;

	@Autowired
	private CommonDao commonDao;

	@Autowired
	private CommonApprMgmtService commonApprMgmtService;

	@Autowired
	private CommonFileService commonFileService;

	@Autowired
	private SmsService smsService;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Autowired
	private GPortalListTypeRestService gPortalListTypeRestService;

	@Autowired
	private DissStepDao dissStepDao;

	@Autowired
	private DissScheduleDao dissScheduleDao;

	@Autowired
	private DissOneTeamMinutesDao dissOneTeamMinutesDao;

	@Autowired
	private DissOneTeamDao dissOneTeamDao;

	@Autowired
	private DissSpecInDao dissSpecInDao;

	@Autowired
	private DissImpDevDao dissImpDevDao;

	@Autowired
	private DissMemberDao dissMemberDao;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;

	@Autowired
	private MailingService mailingService;

	@Override
	public int getDissMyApprListCount(ApprLineVO param) {
		return commonApprDao.getDissMyApprListCount(param);
	}

	@Override
	public List<ApprLineVO> getDissMyApprList(ApprLineVO param) {
		if(!param.getLoginEmpId().equals(param.getRegiIdxx()))
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
		return commonApprDao.getDissMyApprList(param);
	}
	
	@Override
	public ApprLineVO getDissMyApprDetail(ApprLineVO param) {
		return commonApprDao.getDissMyApprDetail(param);
	}

	@Override
	public int getDissMyApprReqListCount(ApprVO param) {
		return commonApprDao.getDissMyApprReqListCount(param);
	}

	@Override
	public List<ApprVO> getDissMyApprReqList(ApprVO param) {
		return commonApprDao.getDissMyApprReqList(param);
	}

	/**
	 * DISS 공통 품의서 저장처리(결재요청및이전단계용)
	 *
	 * @param apprVO
	 * @param apprStat
	 * @param smsFlag - 메세지를 보낼지 안 보낼지 설정
	 * @return
	 */
	@Override
	public String saveDissCommonAppr(ApprVO apprVO, String apprStat, boolean smsFlag) {
		// 품의서 상태 확인
		ApprState apprState = ApprState.getApprState(apprStat);
		apprVO.setApprStat(apprState.getCode());
		apprVO = (ApprVO) StringUtil.nullToEmptyString(apprVO);

		// 결재라인 정규화 작업
		apprVO.setApprLineList(getOrderedApprLineList(apprVO));

		// 품의서 기본 validation 체크
		checkDissCommonAppr(apprVO);

		// 품의서의 결재자 필수 여부가 없고 결재 요청 이면서 결재자리스트가 없으면 바로 완료 처리
		if (!ApprType.getApprType(apprVO.getApprType()).isReqApprLineYn()
				&& apprVO.getApprLineAList().isEmpty()
				&& ApprState.APPR_PROCEEDING.getCode().equals(apprStat)
		) {
			// 작성완료 처리
			apprVO.setApprStat(ApprState.APPR_WRITE_COMPLETE.getCode());
		}

		// 입력 수정 작업
		ApprVO checkApprVO = commonApprDao.getAppr(apprVO);
		if (checkApprVO == null) {   // 결과 없으면 입력
			// DISS 품의서는 목록연동방식을 사용한다.
			apprVO.setGpSendType(ApprType.getApprType(apprVO.getApprType()).getGpSendType());
			commonApprDao.createAppr(apprVO);
		} else {                      // 결과 있으면 수정
			// 작성자 외에 param 위변조로 작업금지(스펙인 등록의 경우에는 영업담당자,TS담당자로 체크)
			if(ApprType.APPR_TYPE_DISS_SPECIN_REG.getCode().equals(apprVO.getApprType())){
				// 과제 정보를 가져오기 위해 apprId로 스텝 정보를 먼저 구한다.
				DissStepVO dissStepVO = new DissStepVO();
				dissStepVO.setApprId(apprVO.getApprId());
				dissStepVO = dissStepDao.getDissStepByApprId(dissStepVO);
				// 스텝정보에서 과제ID 를 구해 과제 정보를 구한다.
				DissSpecInVO dissSpecInVO = new DissSpecInVO();
				dissSpecInVO.setTaskId(dissStepVO.getTaskId());
				dissSpecInVO = dissSpecInDao.getDissSpecInInfo(dissSpecInVO);
				// 과제 정보에 영업담당자,TS담당자가 현재 로그인한 사원인지 체크 한다.
				if(!(dissSpecInVO.getSalesEmpId().equals(apprVO.getUpdtIdxx()) || dissSpecInVO.getTsEmpId().equals(apprVO.getUpdtIdxx()))){
					throw new ServiceException("", "올바른 사용자 접근이 아닙니다.\n(SPEC-IN 등록 품의는 과제 영업담당자,TS담당자만 수정이 가능합니다.)");
				}
			}else{
				if(!checkApprVO.getRegiIdxx().equals(apprVO.getUpdtIdxx())){
					throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
				}
			}
			commonApprDao.updateAppr(apprVO);
		}

		// 결재라인 저장
		commonApprDao.deleteApprLineAll(apprVO);
		createApprLine(apprVO);

		// 작성완료 처리된 내역이면 SMS 보내고 완료 처리 끝
		if (!ApprType.getApprType(apprVO.getApprType()).isReqApprLineYn()
				&& apprVO.getApprLineAList().isEmpty()
				&& ApprState.APPR_WRITE_COMPLETE.getCode().equals(apprVO.getApprStat())
		) {
			// SMS 보내고 완료
			if(!smsFlag)	sendDissApprSms(apprVO);
		} else {
			// 작성완료 처리된 내역이 아니고 결재 요청인경우 gportal 결재목록 연동처리(SMS발송)
			if (ApprState.APPR_PROCEEDING.equals(apprState)) {
				gPortalListTypeRestService.requestApproval(apprVO);
			}
		}

		return apprVO.getApprId();
	}

	/**
	 * DISS 공통 품의서 저장 시 기본 Validation check
	 *
	 * @param apprVO
	 */
	@Override
	public void checkDissCommonAppr(ApprVO apprVO) {

		List<ApprLineVO> apprLineList = new ArrayList<ApprLineVO>();
		//기본 필수 체크
		if (apprVO.getApprType() == null || apprVO.getApprType().isEmpty()) {
			throw new ServiceException("", "문서유형을 선택해야 합니다.");
		}
		/*
		if(StringUtil.isEmpty(apprVO.getSecrCode())) {
			throw new ServiceException("","보안설정을 반드시 지정해야 합니다.");
		}
		if(StringUtil.isEmpty(apprVO.getSaveCode())) {
			throw new ServiceException("","보존년한을 반드시 지정해야 합니다.");
		}
		*/

		if (apprVO.getApprTitle().isEmpty())
			throw new ServiceException("", "품의서 제목이 입력되지 않았습니다.");

		if (ApprType.getApprType(apprVO.getApprType()).isReqApprLineYn() && apprVO.getApprLineAList().isEmpty())
			throw new ServiceException("", "결재라인을 반드시 지정해야 합니다.");

		// 결재라인 지정시 결재자는 반드시 지정되도록
		if (!"Y".equals(StringUtil.nullConvert(apprVO.getLineAYn()))) {
			if ("Y".equals(StringUtil.nullConvert(apprVO.getLineCYn())))
				throw new ServiceException("", "합의자 지정시 결재자를 반드시 지정해야 합니다.");
			if ("Y".equals(StringUtil.nullConvert(apprVO.getLineRYn())))
				throw new ServiceException("", "참조자 지정시 결재자를 반드시 지정해야 합니다.");
		}

		// 견본일정 공지인경우 통보자 반드시 지정 하도록
		if (ApprType.APPR_TYPE_DISS_SAMPLE_NOTICE.getCode().equals(apprVO.getApprType())) {
			if (!"Y".equals(StringUtil.nullConvert(apprVO.getLineIYn()))) throw new ServiceException("", "견본일정공지시 통보자가 지정되어야 합니다.");
		}

		// 결재라인별 체크 ####################################################### START
		if ("Y".equals(StringUtil.nullConvert(apprVO.getLineAYn()))) {
			if (apprVO.getApprLineAList().isEmpty()) throw new ServiceException("", "결재자가 지정되지 않았습니다.");
			for(ApprLineVO apprLineVO : apprVO.getApprLineAList()){
				// 지정된 자가결재 대상이 아닌데 결재라인에 본인이 있으면 에러
				if(apprLineVO.getApprEmpId().equals(apprVO.getUpdtIdxx()) && checkDissSelfApprLine(apprVO))
					throw new ServiceException("", "본인을 결재자로 지정 할 수 없습니다.");
			}
		}
		if ("Y".equals(StringUtil.nullConvert(apprVO.getLineCYn()))) {
			if (apprVO.getApprLineCList().isEmpty()) throw new ServiceException("", "합의자가 지정되지 않았습니다.");
			if (StringUtil.isEmpty(apprVO.getGwdcCode())) throw new ServiceException("", "합의방법이 지정되지 않았습니다.");
			if (StringUtil.isEmpty(apprVO.getConfLoca())) throw new ServiceException("", "합의위치가 지정되지 않았습니다.");
			for(ApprLineVO apprLineVO : apprVO.getApprLineCList()){
				if(apprLineVO.getApprEmpId().equals(apprVO.getUpdtIdxx()))
					throw new ServiceException("", "본인을 합의자로 지정 할 수 없습니다.");
			}
		}
		if ("Y".equals(StringUtil.nullConvert(apprVO.getLineRYn()))) {
			if (apprVO.getApprLineRList().isEmpty()) throw new ServiceException("", "참조자가 지정되지 않았습니다.");
			for(ApprLineVO apprLineVO : apprVO.getApprLineRList()){
				if(apprLineVO.getApprEmpId().equals(apprVO.getUpdtIdxx()))
					throw new ServiceException("", "본인을 참조자로 지정 할 수 없습니다.");
			}
		}
		if ("Y".equals(StringUtil.nullConvert(apprVO.getLineIYn()))) {
			if (apprVO.getApprLineIList().isEmpty()) throw new ServiceException("", "통보자가 지정되지 않았습니다.");
			for(ApprLineVO apprLineVO : apprVO.getApprLineIList()){
				if(apprLineVO.getApprEmpId().equals(apprVO.getUpdtIdxx()))
					throw new ServiceException("", "본인을 통보자로 지정 할 수 없습니다.");
			}
		}
		// 결재라인별 체크 ####################################################### END
	}

	/**
	 * 게이트 리뷰시 지정된 사번이 결재의뢰 인경우 자가 결재가 가능 하도록 체크
	 * @param apprVO
	 * @return
	 */
	private boolean checkDissSelfApprLine(ApprVO apprVO){
		// 고일영 책임은 모두 가능
//		if("05157".equals(apprVO.getUpdtIdxx()))
//			return false;

		boolean rtnVal = true;

		if(ApprType.APPR_TYPE_DISS_SPECIN_REG.getCode().equals(apprVO.getApprType())){			// SPEC-IN 등록
			//06128:윤여근,03112:도창주,05157:고일영
			String[] passTargetEmpList = {"06128","03112","05157"};
			for(String testEmpId:passTargetEmpList){
				if(testEmpId.equals(apprVO.getUpdtIdxx())){
					rtnVal = false;
				}
			}
		} else if (ApprType.APPR_TYPE_DISS_SAMPLE.getCode().equals(apprVO.getApprType())) {		// 견본등록
			String[] passTargetEmpList = {"03112","05157"};
			for(String testEmpId:passTargetEmpList){
				if(testEmpId.equals(apprVO.getUpdtIdxx())){
					rtnVal = false;
				}
			}
		} else if (ApprType.APPR_TYPE_DISS_CUSTTEST.getCode().equals(apprVO.getApprType())) {	// 고객Test/결과 등록
			String[] passTargetEmpList = {"03112","05157"};
			for(String testEmpId:passTargetEmpList){
				if(testEmpId.equals(apprVO.getUpdtIdxx())){
					rtnVal = false;
				}
			}
		} else if (ApprType.APPR_TYPE_DISS_COMPLETE.getCode().equals(apprVO.getApprType())) {	// 과제완료결과등록
			String[] passTargetEmpList = {"03112","05157"};
			for(String testEmpId:passTargetEmpList){
				if(testEmpId.equals(apprVO.getUpdtIdxx())){
					rtnVal = false;
				}
			}
		} else if (ApprType.APPR_TYPE_DISS_SPECIN_SCHEDULE_EDIT.getCode().equals(apprVO.getApprType())) {	// SPEC-IN 일정 수정
			String[] passTargetEmpList = {"03112","05157"};
			for(String testEmpId:passTargetEmpList){
				if(testEmpId.equals(apprVO.getUpdtIdxx())){
					rtnVal = false;
				}
			}
		} else if (ApprType.APPR_TYPE_DISS_IMPDEV_SCHEDULE_EDIT.getCode().equals(apprVO.getApprType())) {	// 제품개선개발 일정 수정
			String[] passTargetEmpList = {"03112","05157"};
			for(String testEmpId:passTargetEmpList){
				if(testEmpId.equals(apprVO.getUpdtIdxx())){
					rtnVal = false;
				}
			}
		} else if (ApprType.APPR_TYPE_DISS_DAILY_ACT.getCode().equals(apprVO.getApprType())) {	// Daily 활동
			String[] passTargetEmpList = {"05157"};
			for(String testEmpId:passTargetEmpList){
				if(testEmpId.equals(apprVO.getUpdtIdxx())){
					rtnVal = false;
				}
			}
		}
		return rtnVal;
	}

	/**
	 * 결재리스트 정규화
	 */
	@Override
	public List<ApprLineVO> getOrderedApprLineList(ApprVO apprVO) {
		List<ApprLineVO> rtnApprLineList = new ArrayList<ApprLineVO>();

		// 결재자,협의자 정규화
		getOrderedApprLineACList(apprVO, rtnApprLineList);
		// 참조자 리스트
		for (ApprLineVO apprRLine : apprVO.getApprLineRList())
			rtnApprLineList.add(apprRLine);
		// 통보자 리스트
		for (ApprLineVO apprILine : apprVO.getApprLineIList())
			rtnApprLineList.add(apprILine);

		return rtnApprLineList;
	}

	/**
	 * 결재리스트 정규화 중 결재자,합의자 정규화
	 *
	 * @param apprVO
	 * @param rtnApprLineList
	 */
	private void getOrderedApprLineACList(ApprVO apprVO, List<ApprLineVO> rtnApprLineList) {
		if (apprVO.getConfLoca() == null || apprVO.getConfLoca().length() == 0) {
			for (ApprLineVO apprALine : apprVO.getApprLineAList())
				rtnApprLineList.add(apprALine);
			// 합의자가 있는 경우는 합의 위치에 따라서
		} else {
			// 합의위치가 첫번째 결재자인경우 : 합의자먼저 결재자 이후
			if (apprVO.getConfLoca().equals(apprVO.getApprLineAList().get(0).getApprEmpId())) {
				for (ApprLineVO apprCLine : apprVO.getApprLineCList())
					rtnApprLineList.add(apprCLine);
				for (ApprLineVO apprALine : apprVO.getApprLineAList())
					rtnApprLineList.add(apprALine);
			// 합의위치가 첫번째 결재자가 아닌경우 : 결재자 셋팅후 합의위치결재자 앞에 합의자 전체 셋팅
			} else {
				for (ApprLineVO apprALine : apprVO.getApprLineAList()) {
					if (apprVO.getConfLoca().equals(apprALine.getApprEmpId())) {
						for (ApprLineVO apprCLine : apprVO.getApprLineCList())
							rtnApprLineList.add(apprCLine);
						rtnApprLineList.add(apprALine);
					} else {
						rtnApprLineList.add(apprALine);
					}
				}
			}
		}
	}

	/**
	 * 품의서 결재라인 저장
	 *
	 * @param param
	 */
	private void createApprLine(ApprVO param) {
		if (param.getApprLineList() != null && !param.getApprLineList().isEmpty()) {
			int lineNo = 0;
			for (ApprLineVO apprLineVO : param.getApprLineList()) {
				apprLineVO.setApprId(param.getApprId());
				apprLineVO.setApprLineNo(lineNo);
				apprLineVO.setRegiIdxx(param.getRegiIdxx());
				apprLineVO.setUpdtIdxx(param.getUpdtIdxx());
				commonApprDao.createApprLine(apprLineVO);
				lineNo++;
			}
		}
	}

	/**
	 * 품의서 삭제(임시저장인경우 만 사용)
	 *
	 * @param apprVO
	 */
	@Override
	public void deleteDissAppr(ApprVO apprVO) {
		apprVO = (ApprVO) StringUtil.nullToEmptyString(apprVO);

		// 결재라인 삭제
		commonApprDao.deleteApprLineAll(apprVO);
		// 품의서 기본 삭제
		commonApprDao.deleteAppr(apprVO);
	}

	/**
	 * DISS 공통 품의서 결재액션(결재자,협의자 승인,협의,반려 처리)
	 *
	 * @param apprLineVO 필수(apprId,apprEmpId,applStat),선택(apprLineComment) 를 셋팅 하여 호출할것
	 */
	@Override
	public void approvalDissCommonAppr(ApprLineVO apprLineVO) {
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(apprLineVO.getApprId());
		apprVO = getApprInfoAll(apprVO);
		apprVO.setUpdtIdxx(apprLineVO.getUpdtIdxx());   // 변경자 셋팅

		if(!apprLineVO.getApprEmpId().equals(apprLineVO.getUpdtIdxx()))	throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");

		// 결재유효한 품의서 인지 체크
		if (ApprState.getApprState(apprVO.getApprStat()).getEndYn())	throw new ServiceException("", "품의가 끝난 품의서 입니다.");

		// 다음 결재자 리스트를 구한다
		List<ApprLineVO> nextLineList = getApprovalNextLineList(apprVO);

		// 현재 결재행위자가 유효한 결재권자인지 체크한다.
		final String targetApprEmpId = apprLineVO.getApprEmpId();
		boolean isApprLineEmp = FluentIterable.from(nextLineList).anyMatch(new Predicate<ApprLineVO>() {
			@Override
			public boolean apply(ApprLineVO input) {
				return input.getApprEmpId().equals(targetApprEmpId);
			}
		});

		if (!isApprLineEmp)	throw new ServiceException("", "잘못된 결재(순번,권한) 요청 입니다.");

		// 결재자 유형을 셋팅한다.
		for (ApprLineVO tmpApprLineVO : nextLineList) {
			if (tmpApprLineVO.getApprEmpId().equals(targetApprEmpId))
				apprLineVO.setApprLineType(tmpApprLineVO.getApprLineType());
		}

		// 결재라인 업데이트
		commonApprDao.updateApprLineStatApprovalResult(apprLineVO);
		apprVO.setApprId(apprLineVO.getApprId());
		apprVO = getApprInfoAll(apprVO);
		apprVO.setUpdtIdxx(apprLineVO.getUpdtIdxx());   // 변경자 셋팅
		// 품의서상태 결정
		if (ApplState.getApplState(apprLineVO.getApplStat()).isRejectYn()) {
			// 반려인 경우 결재반려인지 협의 반려인지
			apprVO.setApprStat((ApprLineType.APPR_CONFIRM.getCode().equals(apprLineVO.getApprLineType())) ? ApprState.CONF_REJECT.getCode() : ApprState.APPR_REJECT.getCode());
		} else {
			// 승인이거나 협의 인경우 - 다시한번 다음 결재자 리스트를 구한다.
			nextLineList = getApprovalNextLineList(apprVO);
			if (nextLineList.isEmpty()) {
				// 다음 결재자가 없으면 품의서상태 품의완료
				apprVO.setApprStat(ApprState.APPR_COMPLETE.getCode());
			} else {
				// 다음 결재자가 있으면 품의서 상태 품의중
				apprVO.setApprStat(ApprState.APPR_PROCEEDING.getCode());
			}
		}
		// 품의서 상태 저장
		commonApprDao.updateApprStatApprovalResult(apprVO);

		// gportal 품의목록 연동 처리(SMS 발송)
		gPortalListTypeRestService.sendApproval(apprVO, apprLineVO.getApprEmpId());
	}

	/**
	 * 단건 품의서의 전체 정보 구하기
	 *
	 * @param apprVO
	 * @return
	 */
	@Override
	public ApprVO getApprInfoAll(ApprVO apprVO) {
		// 품의서 기본
		apprVO = commonApprDao.getAppr(apprVO);
		// 품의서 결재선
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(apprVO.getApprId());
		apprVO.setApprLineList(commonApprDao.getApprLineList(apprLineVO));

		// 결재라인 구분별 결재선 맵핑
		commonApprMgmtService.getApprLineListContainType(apprVO);

		// 첨부파일 리스트 맵핑
		setApprFileList(apprVO);

		return apprVO;
	}

	/**
	 * 품의서 첨부파일 리스트 맵핑
	 *
	 * @param apprVO
	 */
	private void setApprFileList(ApprVO apprVO) {
		// 첨부파일이 존재하면 첨부파일 리스트 셋팅
		if (!"".equals(StringUtil.nullConvert(apprVO.getFileId()))) {
			// 파일리스트 정보
			FileVO fileVO = new FileVO();
			fileVO.setFileId(apprVO.getFileId());
			apprVO.setFileList(commonFileService.getFileList(fileVO));
		}
	}

	/**
	 * 현재 결재자가 마지막 결재자인지 체크
	 *
	 * @param apprVO
	 * @param apprEmpId
	 * @return
	 */
	@Override
	public boolean checkListApplActYn(ApprVO apprVO, String apprEmpId) {
		apprVO = getApprInfoAll(apprVO);
		if (apprVO.getApprLineAList().get(apprVO.getApprLineAList().size() - 1).getApprEmpId().equals(apprEmpId)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public List<ApprLineVO> getApprovalNextLineList(ApprVO apprVO) {

		apprVO = (ApprVO) StringUtil.nullToEmptyString(getApprInfoAll(apprVO));

		List<ApprLineVO> rtnApprLineVOList = new ArrayList<ApprLineVO>();

		// 결재라인 전체를 돌면서 체크
		for (ApprLineVO apprLineVO : apprVO.getApprLineList()) {
			// 결재권자이면
			if (ApprLineType.getApprLineType(apprLineVO.getApprLineType()).isApprActionLineYn()) {
				// 미결상태결재자만
				if (ApplState.APPL_WAITING.equals(ApplState.getApplState(apprLineVO.getApplStat()))) {
					// 병렬이면 협의자 전체
					if (!"".equals(apprVO.getGwdcCode())
							&& ApprConfType.APPR_CONF_TYPE_PARALLEL.equals(ApprConfType.getApprApprConfType(apprVO.getGwdcCode()))
					) {
						// 협의자 이면
						if (ApprLineType.APPR_CONFIRM.getCode().equals(apprLineVO.getApprLineType())) {
							rtnApprLineVOList.add(apprLineVO);
						} else {
							// 이전결재자가 있으면 바로 리턴(협의자가 셋팅되어 있을테니)
							if (rtnApprLineVOList.size() > 0) {
								return rtnApprLineVOList;
							} else {
								// 없으면 결재자최초이니 결재자 셋팅하고 리턴
								rtnApprLineVOList.add(apprLineVO);
								return rtnApprLineVOList;
							}
						}
					} else {
						// 직렬이면 협의자,결재자 구분없이 셋팅하고 바로 리턴
						rtnApprLineVOList.add(apprLineVO);
						return rtnApprLineVOList;
					}
				}
			}
		}
		return rtnApprLineVOList;
	}

	/**
	 * 결재상태별 안내 문자 보내기
	 */
	@Override
	public void sendDissApprSms(ApprVO param) {
		DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
		transactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//transaction start
		TransactionStatus tx = transactionManager.getTransaction(transactionDefinition);

		ApprVO apprVO = getApprInfoAll(param);
		// 결재자,협의자만 리스트로 뽑는다.
		List<ApprLineVO> apprACLineList = new ArrayList<ApprLineVO>();
		for (ApprLineVO apprLineVO : apprVO.getApprLineList()) {
			if (apprLineVO.getApprLineType().equals(ApprLineType.APPR_APROBE.getCode())
			|| apprLineVO.getApprLineType().equals(ApprLineType.APPR_CONFIRM.getCode())
			) {
				apprACLineList.add(apprLineVO);
			}
		}

		try {
			// 1. 품의진행인경우(결재라인을 순서대로 루프돌면서 처리)
			if (!ApprState.getApprState(apprVO.getApprStat()).getEndYn()) {
				int idx = 0;
				boolean continueable = true;
				while (idx < apprACLineList.size() && continueable) {
					// 1-1. 현재 결재해야할 결재대기자일때까지 루프
					if (!ApplState.getApplState(apprACLineList.get(idx).getApplStat()).isApplYn()) {
						// 1-1-1. 협의자이면
						if (ApprLineType.APPR_CONFIRM.getCode().equals(apprACLineList.get(idx).getApprLineType())) {
							// 1-1-1-1. 병렬이면(최초 협의자 인경우만 전체 협의요청 안내)
							if (ApprConfType.APPR_CONF_TYPE_PARALLEL.getCode().equals(apprVO.getGwdcCode())) {
								// 1-1-1-1-1. 최초협의자 이면(협의자 모두에 협의요청안내)
								if (idx == 0 || ApprLineType.APPR_APROBE.getCode().equals(apprACLineList.get(idx - 1).getApprLineType())) {
									for (ApprLineVO apprCLineVO : apprVO.getApprLineCList()) {
										sendDissApprSmsToConf(apprVO, apprCLineVO);
									}
								}
							// 1-1-1-2. 직렬이면 순서대로 각각 협의요청 안내
							} else {
								sendDissApprSmsToConf(apprVO, apprACLineList.get(idx));
							}
						// 1-1-2. 결재자이면 순서대로 결재요청 안내
						} else {
							sendDissApprSmsToAppl(apprVO, apprACLineList.get(idx));
						}

						// 1-2 최초 상신인경우 전체 참조자 안내
						if (idx == 0) {
							for (ApprLineVO apprRLineVO : apprVO.getApprLineRList()) {
								sendDissApprSmsToRef(apprVO, apprRLineVO);
							}
						}
						// 루프종료
						continueable = false;
					}
					idx++;
				}
			// 2. 품의서결재가 종료된경우
			} else {
				// 2-1. 반려인경우(기안자,참조자,중간결재선 반려안내)
				if (ApprState.getApprState(apprVO.getApprStat()).isRejectYn()) {
					ApprLineVO apprLineVO = new ApprLineVO();
					apprLineVO.setApprEmpId(apprVO.getRegiIdxx());
					apprLineVO.setApprEmpHpno(apprVO.getSawnHpxxNum1());
					apprLineVO.setApprEmpEmail(apprVO.getSawnMailAddr());
					sendDissApprSmsForReject(apprVO,apprLineVO);				// 기안자 반려 안내
					for (ApprLineVO apprALineVO : apprVO.getApprLineAList())	// 결재자 반려 안내 (최종 결재자 제외)
						sendDissApprSmsForReject(apprVO, apprALineVO);
					for (ApprLineVO apprCLineVO : apprVO.getApprLineCList())	// 합의자 반려 안내
						sendDissApprSmsForReject(apprVO, apprCLineVO);
					for (ApprLineVO apprRLineVO : apprVO.getApprLineRList())	// 참조자 반려 안내
						sendDissApprSmsForReject(apprVO, apprRLineVO);
				// 2-3. 작성완료인경우
				} else if (ApprState.APPR_WRITE_COMPLETE.getCode().equals(apprVO.getApprStat())) {
					for (ApprLineVO apprILineVO : apprVO.getApprLineIList())	// 통보자 작성완료 안내
						sendDissApprSmsForWriteComplete(apprVO, apprILineVO);
				// 2-2. 승인완료인경우(기안자,최종결재 제외 모든 결재선 승인완료안내)
				} else {
					ApprLineVO apprLineVO = new ApprLineVO();
					apprLineVO.setApprEmpId(apprVO.getRegiIdxx());
					apprLineVO.setApprEmpHpno(apprVO.getSawnHpxxNum1());
					apprLineVO.setApprEmpEmail(apprVO.getSawnMailAddr());
					sendDissApprSmsForComplete(apprVO, apprLineVO);				// 기안자 승인완료 안내
					for (ApprLineVO apprALineVO : apprVO.getApprLineAList())	// 결재자 승인완료 안내 (최종 결재자 제외)
						sendDissApprSmsForComplete(apprVO, apprALineVO);
					for (ApprLineVO apprCLineVO : apprVO.getApprLineCList())	// 합의자 승인완료 안내
						sendDissApprSmsForComplete(apprVO, apprCLineVO);
					for (ApprLineVO apprRLineVO : apprVO.getApprLineRList())	// 참조자 승인완료 안내
						sendDissApprSmsForComplete(apprVO, apprRLineVO);
					for (ApprLineVO apprILineVO : apprVO.getApprLineIList())	// 통보자 승인완료 안내
						sendDissApprSmsForComplete(apprVO, apprILineVO);
				}
			}
		} catch (Exception e) {
			transactionManager.commit(tx);
			e.printStackTrace();
		}
	}

	/**
	 * 게이트리뷰 요청 안내 메세지 보내기
	 *
	 * @param apprId
	 * @param taskId
	 */
	@Override
	public void sendDissGateReviewMessage(String apprId, String taskId){
		DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
		transactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//transaction start
		TransactionStatus tx = transactionManager.getTransaction(transactionDefinition);

		try{
			ApprVO apprVO = new ApprVO();
			apprVO.setApprId(apprId);
			apprVO = getApprInfoAll(apprVO);
			DissSpecInVO dissSpecInVO = new DissSpecInVO();
			dissSpecInVO.setTaskId(taskId);
			dissSpecInVO = dissSpecInDao.getDissSpecInInfo(dissSpecInVO);

			ApprLineVO apprLineVO = new ApprLineVO();
			apprLineVO.setApprEmpId(dissSpecInVO.getTsEmpId());
			apprLineVO.setApprEmpEmail(dissSpecInVO.getTsEmpMail());
			apprLineVO.setApprEmpHpno(dissSpecInVO.getTsEmpHpno());

			sendDissApprSmsForGateReview(apprVO,apprLineVO,true);
		} catch (Exception e) {
			transactionManager.commit(tx);
			e.printStackTrace();
		}
	}

	@Override
	public void sendDissGateReviewCancelMessage(String apprId, String taskId) {
		DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
		transactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//transaction start
		TransactionStatus tx = transactionManager.getTransaction(transactionDefinition);

		try{
			ApprVO apprVO = new ApprVO();
			apprVO.setApprId(apprId);
			apprVO = getApprInfoAll(apprVO);
			DissSpecInVO dissSpecInVO = new DissSpecInVO();
			dissSpecInVO.setTaskId(taskId);
			dissSpecInVO = dissSpecInDao.getDissSpecInInfo(dissSpecInVO);

			ApprLineVO apprLineVO = new ApprLineVO();
			apprLineVO.setApprEmpId(dissSpecInVO.getTsEmpId());
			apprLineVO.setApprEmpEmail(dissSpecInVO.getTsEmpMail());
			apprLineVO.setApprEmpHpno(dissSpecInVO.getTsEmpHpno());

			sendDissApprSmsForGateReview(apprVO,apprLineVO,false);
		} catch (Exception e) {
			transactionManager.commit(tx);
			e.printStackTrace();
		}
	}

	/**
	 * DISS 공통 팝업 스텝 체크 메세지
	 *
	 * @param dissApprCommonParamVO
	 * @return checkMessage
	 */
	@Override
	public String getDissStepIngCheckMessage(DissApprCommonParamVO dissApprCommonParamVO) {
		String rtnMessage = "";

		// taskId 가 존재 하고 stepId 가 없는 경우(신규스텝 입력인경우)
		if (!dissApprCommonParamVO.getTaskId().isEmpty()  // 과제ID가 있고
				&& dissApprCommonParamVO.getStepId().isEmpty()  // 스텝ID가 없고
				&& !ApprType.APPR_TYPE_DISS_DAILY_ACT.getCode().equals(dissApprCommonParamVO.getApprType()) // 데일리 활동 제외
		) {
			// 현재 로그인한 사원이 해당스텝 권한자인지 체크
			rtnMessage = getCheckTaskStepAuthMessage(dissApprCommonParamVO);
			if (!"".equals(rtnMessage)) return rtnMessage;

			// 진행중인 과제스텝 있는지 체크
			rtnMessage = getCheckTaskIngMessage(dissApprCommonParamVO);
			if (!"".equals(rtnMessage)) return rtnMessage;

			// 유효스텝 진행 체크
			rtnMessage = getCheckTaskValidStepMessage(dissApprCommonParamVO);
			if (!"".equals(rtnMessage)) return rtnMessage;
		}

		return rtnMessage;
	}

	/**
	 * 현재 로그인한 사원이 해당스텝 권한자인지 체크
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 */
	private String getCheckTaskStepAuthMessage(DissApprCommonParamVO dissApprCommonParamVO) {
		String rtnMessage = "";

		String sEmpId = dissApprCommonParamVO.getUpdtIdxx();      // 현재 로그인한 사원
		String apprType = dissApprCommonParamVO.getApprType();   // 현재 품의서
		String taskId = dissApprCommonParamVO.getTaskId();        // 과제ID

		// 과제의 스케쥴 정보를 가져온다.
		DissScheduleVO scheduleVOParam = new DissScheduleVO();
		scheduleVOParam.setTaskId(taskId);
		List<DissScheduleVO> dissScheduleVOList = dissScheduleDao.getDissScheduleList(scheduleVOParam);

		List<DissMemberVO> dissMemberList = null;

		if("IMPDEV".equals(dissApprCommonParamVO.getTaskType())) {
			DissMemberVO dissMemberVOParam = new DissMemberVO();
			dissMemberVOParam.setTaskId(dissApprCommonParamVO.getTaskId());
			dissMemberList = dissMemberDao.getDissMemberList(dissMemberVOParam);
		}

		rtnMessage = "일정의 지정 담당자만 작성 할 수 있습니다.";
		// 개발제안서,컬러개발제안 체크
		if (ApprType.APPR_TYPE_DISS_IMPDEV_PROPOSAL.getCode().equals(apprType)
		|| ApprType.APPR_TYPE_DISS_SPECIN_COLOR_PROPOSAL.getCode().equals(apprType)
		|| ApprType.APPR_TYPE_DISS_IMPDEV_LEVEL_CHG.getCode().equals(apprType)) {
			DissScheduleVO checkDissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(getChkTargetSchedule(dissScheduleVOList, "200"));
			if (!(sEmpId.equals(checkDissScheduleVO.getEmpId()) || sEmpId.equals(checkDissScheduleVO.getDevEmpId()))) {
				return "개발제안 " + rtnMessage;
			}
		}
		// 개발결과
		if (ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode().equals(apprType)) {
			DissScheduleVO checkDissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(getChkTargetSchedule(dissScheduleVOList, "300"));
			if (!(sEmpId.equals(checkDissScheduleVO.getDevEmpId()))) {
				return rtnMessage;
			}
		}
		// 컬러개발결과
		if (ApprType.APPR_TYPE_DISS_SPECIN_COLOR_PRESCRIPTION.getCode().equals(apprType)) {
			DissScheduleVO checkDissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(getChkTargetSchedule(dissScheduleVOList, "300"));
			if (!(sEmpId.equals(checkDissScheduleVO.getEmpId()))) {
				return rtnMessage;
			}
		}
		// TS견본검증결과
		if (ApprType.APPR_TYPE_DISS_IMPDEV_SAMPLEEVAL.getCode().equals(apprType)) {
			DissScheduleVO checkDissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(getChkTargetSchedule(dissScheduleVOList, "300"));
			if (!(sEmpId.equals(checkDissScheduleVO.getEmpId()))) {
				return rtnMessage;
			}
		}
		// 견본일정공지,견본등록
		if (ApprType.APPR_TYPE_DISS_SAMPLE_NOTICE.getCode().equals(apprType)
			|| ApprType.APPR_TYPE_DISS_SAMPLE.getCode().equals(apprType)) {
			// 제품개선개발의 경우 영업팀 멤버로 등록되었으면 작성 가능하도록 수정
			if("IMPDEV".equals(dissApprCommonParamVO.getTaskType()))
				for(DissMemberVO member : dissMemberList)
					if(sEmpId.equals(member.getMngEmpId()) && "SP".equals(member.getMemberType()))
						return "";

			DissScheduleVO checkDissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(getChkTargetSchedule(dissScheduleVOList, "400"));
			if (!(sEmpId.equals(checkDissScheduleVO.getEmpId()) || sEmpId.equals(checkDissScheduleVO.getDevEmpId()))) {
				return "견본 " + rtnMessage;
			}
		}
		// 고객승인/고객테스트결과보고
		if (ApprType.APPR_TYPE_DISS_CUSTTEST.getCode().equals(apprType)) {
			DissScheduleVO checkDissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(getChkTargetSchedule(dissScheduleVOList, "500"));
			// 제품개선개발의 경우 제품개발팀 및 TS팀 멤버로 등록되었으면 작성 가능하도록 수정
			if("IMPDEV".equals(dissApprCommonParamVO.getTaskType()))
				for(DissMemberVO member : dissMemberList)
					if(sEmpId.equals(member.getMngEmpId()) && ("RND".equals(member.getMemberType()) || "TC".equals(member.getMemberType())))
						return "";

			if (!(sEmpId.equals(checkDissScheduleVO.getEmpId()))) {
				return "고객Test/승인 " + rtnMessage;
			}
		}
		// 개발완료
		if (ApprType.APPR_TYPE_DISS_COMPLETE.getCode().equals(apprType)) {
			DissScheduleVO checkDissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(getChkTargetSchedule(dissScheduleVOList, "600"));
			if (!(sEmpId.equals(checkDissScheduleVO.getEmpId()))) {
				return "개발완료 " + rtnMessage;
			}
		}
		// 규격제정/개정
		if (ApprType.APPR_TYPE_DISS_COMPGRADE.getCode().equals(apprType)) {
			DissScheduleVO checkDissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(getChkTargetSchedule(dissScheduleVOList, "700"));
			if (!(sEmpId.equals(checkDissScheduleVO.getEmpId()))) {
				return "규격제정/개정 " + rtnMessage;
			}
		}
		// 양산이관
		if (ApprType.APPR_TYPE_DISS_MASSTRANS.getCode().equals(apprType)) {
			DissScheduleVO checkDissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(getChkTargetSchedule(dissScheduleVOList, "700"));
			if (!(sEmpId.equals(checkDissScheduleVO.getDevEmpId()))) {
				return "양산이관 " + rtnMessage;
			}
		}
		// 원팀과제완료
		if (ApprType.APPR_TYPE_DISS_ONETEAM_COMPLETE.getCode().equals(apprType)) {
			DissOneTeamVO dissOneTeamVOParam = new DissOneTeamVO();
			dissOneTeamVOParam.setTaskId(taskId);
			DissOneTeamVO dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(dissOneTeamDao.getDissOneTeamInfo(dissOneTeamVOParam));
			if (!sEmpId.equals(dissOneTeamVO.getLeaderEmpId())) {
				return "리더만 작성 가능 합니다.";
			}
		}
		// 스펙인 일정수정
		if(ApprType.APPR_TYPE_DISS_SPECIN_SCHEDULE_EDIT.getCode().equals(apprType)){
			DissSpecInVO dissSpecInVOParam = new DissSpecInVO();
			dissSpecInVOParam.setTaskId(taskId);
			DissSpecInVO dissSpecInVO = (DissSpecInVO)StringUtil.nullToEmptyString(dissSpecInDao.getDissSpecInInfo(dissSpecInVOParam));
			if(!(sEmpId.equals(dissSpecInVO.getSalesEmpId()) || sEmpId.equals(dissSpecInVO.getTsEmpId()))) {
				return "SPEC-IN 일정수정은 과제의 영업담당자,TS담당자만 가능합니다.";
			}
		}
		// 원팀과제정보 수정
		if (ApprType.APPR_TYPE_DISS_ONETEAM_UPDATE_COMMON.getCode().equals(apprType)
				|| ApprType.APPR_TYPE_DISS_ONETEAM_UPDATE_PERFORMANCE.getCode().equals(apprType)
		) {
			DissOneTeamVO dissOneTeamVOParam = new DissOneTeamVO();
			dissOneTeamVOParam.setTaskId(taskId);
			DissOneTeamVO dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(dissOneTeamDao.getDissOneTeamInfo(dissOneTeamVOParam));
			if (!sEmpId.equals(dissOneTeamVO.getLeaderEmpId())) {
				return "리더만 수정 가능 합니다.";
			}
		}

		return "";
	}

	/**
	 * 스케쥴 리스트에서 해당 일정코드의 VO 리턴
	 *
	 * @param scheduleVOList
	 * @param stepGroup
	 * @return
	 */
	private DissScheduleVO getChkTargetSchedule(List<DissScheduleVO> scheduleVOList, String stepGroup) {
		DissScheduleVO rtnDissScheduleVO = new DissScheduleVO();
		for (DissScheduleVO dissScheduleVO : scheduleVOList) {
			dissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(dissScheduleVO);
			if (stepGroup.equals(dissScheduleVO.getStepGroup())) {
				rtnDissScheduleVO = dissScheduleVO;
				break;
			}
		}
		return rtnDissScheduleVO;
	}

	/**
	 * 진행중인 스텝,품의서가 있는지 확인한다.
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 */
	private String getCheckTaskIngMessage(DissApprCommonParamVO dissApprCommonParamVO) {

		// 진행중인 스텝이 있는지 체크
		String chkMessage = getCheckTaskStepIngMessage(dissApprCommonParamVO);
		if(!"".equals(chkMessage)) return chkMessage;

		//원팀과제완료 등록시 원팀회의록 품의진행중여부 체크
		if (ApprType.APPR_TYPE_DISS_ONETEAM_COMPLETE.getCode().equals(dissApprCommonParamVO.getApprType())) {
			DissOneTeamMinutesVO dissOneTeamMinutesVO = new DissOneTeamMinutesVO();
			dissOneTeamMinutesVO.setTaskId(dissApprCommonParamVO.getTaskId());
			List<ApprVO> checkOneTeamMinutesList = dissOneTeamMinutesDao.getDissOneTeamMinutesIngList(dissOneTeamMinutesVO);
			if (checkOneTeamMinutesList.size() > 0) {
				StringBuffer rtnMessage = new StringBuffer();
				ApprVO tmpApprVO = checkOneTeamMinutesList.get(0);
				rtnMessage.append("[" + tmpApprVO.getApprStatName() + "]상태의 [");
				rtnMessage.append(tmpApprVO.getApprTypeName() + "]이 존재합니다. ");
				rtnMessage.append("\n진행중인 [" + tmpApprVO.getApprTypeName() + "] 품의 완료 후 다시 시도하시기 바랍니다.");
				return rtnMessage.toString();
			}
		}

		return "";
	}

	/**
	 * step 사용과제 진행 스텝체크
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 */
	private String getCheckTaskStepIngMessage(DissApprCommonParamVO dissApprCommonParamVO){
		// 진행중인 스텝이 있는지 체크
		DissStepVO dissStepVOParam = new DissStepVO();
		dissStepVOParam.setTaskId(dissApprCommonParamVO.getTaskId());
		dissStepVOParam = (DissStepVO) StringUtil.nullToEmptyString(dissStepVOParam);
		List<DissStepVO> checkStepList = dissStepDao.getDissStepIngList(dissStepVOParam);
		StringBuffer rtnMessage = new StringBuffer();
		// 진행중인 스텝이 있는지 체크
		if (checkStepList.size() > 0) {
			String apprType = dissApprCommonParamVO.getApprType();
			String taskType = dissApprCommonParamVO.getTaskType();

			if("IMPDEV".equals(taskType)) {
				if (ApprType.APPR_TYPE_DISS_SAMPLE.getCode().equals(apprType)
				|| ApprType.APPR_TYPE_DISS_CUSTTEST.getCode().equals(apprType)
				|| "차수생성".equals(dissApprCommonParamVO.getApprType())) {
					for(DissStepVO checkStep : checkStepList) {
						if(!ApprType.APPR_TYPE_DISS_SAMPLE.getCode().equals(checkStep.getApprType())
						&& !ApprType.APPR_TYPE_DISS_CUSTTEST.getCode().equals(checkStep.getApprType()) ) {
							rtnMessage.append("[" + checkStep.getApprStatName() + "]상태의 [");
							rtnMessage.append(checkStep.getStepNm() + "]단계가 존재합니다.");
							rtnMessage.append("\n진행중인 [" + checkStep.getStepNm() + "]단계 완료 후 다시 시도하시기 바랍니다.");
							return rtnMessage.toString();
						}
					}
				} else if (ApprType.APPR_TYPE_DISS_SPECIN_SCHEDULE_EDIT.getCode().equals(apprType)) {
					for(DissStepVO checkStep : checkStepList) {
						if(ApprType.APPR_TYPE_DISS_SPECIN_SCHEDULE_EDIT.getCode().equals(checkStep.getApprType())) {
							rtnMessage.append("[" + checkStep.getApprStatName() + "]상태의 [");
							rtnMessage.append(checkStep.getStepNm() + "]단계가 존재합니다.");
							rtnMessage.append("\n진행중인 [" + checkStep.getStepNm() + "]단계 완료 후 다시 시도하시기 바랍니다.");
							return rtnMessage.toString();
						}
					}
				} else {
					DissStepVO tmpDissStepVO = checkStepList.get(0);
					rtnMessage.append("[" + tmpDissStepVO.getApprStatName() + "]상태의 [");
					rtnMessage.append(tmpDissStepVO.getStepNm() + "]단계가 존재합니다.");
					rtnMessage.append("\n진행중인 [" + tmpDissStepVO.getStepNm() + "]단계 완료 후 다시 시도하시기 바랍니다.");
					return rtnMessage.toString();
				}
			} else if("SPECIN".equals(taskType)) {
				if (ApprType.APPR_TYPE_DISS_SAMPLE.getCode().equals(apprType)) {
					// SPEC-IN 등록 시 견본품의를 동시 진행할 수 있도록 수정
					// SPEC-IN 등록 품의가 진행중일 때 견본품의를 할 수 있는 경우는 등록시 품의 병렬 진행만 가능
					for(DissStepVO checkStep : checkStepList) {
						if(!ApprType.APPR_TYPE_DISS_SPECIN_REG.getCode().equals(checkStep.getApprType())
						&& !ApprType.APPR_TYPE_DISS_SAMPLE.getCode().equals(checkStep.getApprType())) {
							rtnMessage.append("[" + checkStep.getApprStatName() + "]상태의 [");
							rtnMessage.append(checkStep.getStepNm() + "]단계가 존재합니다.");
							rtnMessage.append("\n진행중인 [" + checkStep.getStepNm() + "]단계 완료 후 다시 시도하시기 바랍니다.");
							return rtnMessage.toString();
						}
					}
				} else if (ApprType.APPR_TYPE_DISS_SPECIN_SCHEDULE_EDIT.getCode().equals(apprType)) {
					for(DissStepVO checkStep : checkStepList) {
						if(ApprType.APPR_TYPE_DISS_SPECIN_SCHEDULE_EDIT.getCode().equals(checkStep.getApprType())) {
							rtnMessage.append("[" + checkStep.getApprStatName() + "]상태의 [");
							rtnMessage.append(checkStep.getStepNm() + "]단계가 존재합니다.");
							rtnMessage.append("\n진행중인 [" + checkStep.getStepNm() + "]단계 완료 후 다시 시도하시기 바랍니다.");
							return rtnMessage.toString();
						}
					}
				} else {
					DissStepVO tmpDissStepVO = checkStepList.get(0);
					rtnMessage.append("[" + tmpDissStepVO.getApprStatName() + "]상태의 [");
					rtnMessage.append(tmpDissStepVO.getStepNm() + "]단계가 존재합니다.");
					rtnMessage.append("\n진행중인 [" + tmpDissStepVO.getStepNm() + "]단계 완료 후 다시 시도하시기 바랍니다.");
					return rtnMessage.toString();
				}
			} else {
				DissStepVO tmpDissStepVO = checkStepList.get(0);
				rtnMessage.append("[" + tmpDissStepVO.getApprStatName() + "]상태의 [");
				rtnMessage.append(tmpDissStepVO.getStepNm() + "]단계가 존재합니다.");
				rtnMessage.append("\n진행중인 [" + tmpDissStepVO.getStepNm() + "]단계 완료 후 다시 시도하시기 바랍니다.");
				return rtnMessage.toString();
			}
		}
		return "";
	}

	/**
	 * 유효 스텝 진행 체크
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 */
	private String getCheckTaskValidStepMessage(DissApprCommonParamVO dissApprCommonParamVO) {
		int taskMaxDegreeNo = 0;
		String taskType = dissApprCommonParamVO.getTaskType();    // 현재 과제구분
		String apprType = dissApprCommonParamVO.getApprType();   // 현재 품의서
		String taskId = dissApprCommonParamVO.getTaskId();        // 과제ID
		String devType = "";                                        // 스펙인개발유형
		String devLevel = "";                                        // 스펙인개발단계

		///개선개발,스펙인 인경우 최종 차수 구하기
		if ("IMPDEV".equals(taskType) || "SPECIN".equals(taskType)) {
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setTaskId(taskId);
			taskMaxDegreeNo = dissStepDao.getDissStepMaxDegreeNo(dissStepVO);

			// 스펙인일정수정,양산이관,규격제정개정이 아니면 이미 완료된 과제인지 체크
			if (!ApprType.APPR_TYPE_DISS_COMPGRADE.getCode().equals(apprType)
			&& !ApprType.APPR_TYPE_DISS_MASSTRANS.getCode().equals(apprType)
			&& !ApprType.APPR_TYPE_DISS_SPECIN_SCHEDULE_EDIT.getCode().equals(apprType)) {
				List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "600100");
				if (stepVOList.size() > 0) {
					return "이미 완료된 과제입니다.";
				}
			}
		}

		if ("SPECIN".equals(taskType)) {
			DissSpecInVO dissSpecInVOParam = new DissSpecInVO();
			dissSpecInVOParam.setTaskId(taskId);
			dissSpecInVOParam = dissSpecInDao.getDissSpecInInfo(dissSpecInVOParam);
			devType = dissSpecInVOParam.getDevType();
			devLevel = dissSpecInVOParam.getDevLevel();
		}

		// 컬러개발제안
		if (ApprType.APPR_TYPE_DISS_SPECIN_COLOR_PROPOSAL.getCode().equals(apprType)) {
			List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "200500");
			if (stepVOList.size() > 0) {
				return "이미 완료된 컬러개발 제안서가 존재 합니다.";
			}
		}
		// 개발제안
		if (ApprType.APPR_TYPE_DISS_IMPDEV_PROPOSAL.getCode().equals(apprType)) {
			List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "200100");
			if (stepVOList.size() > 0) {
				return "이미 완료된 개발 제안서가 존재 합니다.";
			}
		}
		// 등급변경
		if (ApprType.APPR_TYPE_DISS_IMPDEV_LEVEL_CHG.getCode().equals(apprType)) {
			List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "200100");
			if (stepVOList.size() == 0) {
				return "완료된 개발제안서가 있어야 합니다.";
			}
		}

		// 컬러개발결과
		if (ApprType.APPR_TYPE_DISS_SPECIN_COLOR_PRESCRIPTION.getCode().equals(apprType)) {
			List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "200500");
			if (stepVOList.size() == 0) {
				return "먼저 컬러개발 제안이 완료 되어야 합니다.";
			}
			stepVOList = getCompStepList(dissApprCommonParamVO, "300500", taskMaxDegreeNo);
			if (stepVOList.size() > 0) {
				return "현재 " + taskMaxDegreeNo + "차수에 이미 완료된 컬러개발 결과가 있습니다.";
			}
		}

		// 개발결과
		if (ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode().equals(apprType)) {
			List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "200100");
			if (stepVOList.size() == 0) {
				return "먼저 개발제안이 완료 되어야 합니다.";
			}
			stepVOList = getCompStepList(dissApprCommonParamVO, "300320", taskMaxDegreeNo);
			if (stepVOList.size() > 0) {
				return "현재 " + taskMaxDegreeNo + "차수에 이미 완료된 개발 결과가 있습니다.";
			}
		}

		// TS견본검증
		if (ApprType.APPR_TYPE_DISS_IMPDEV_SAMPLEEVAL.getCode().equals(apprType)) {
			if ("IMPDEV".equals(taskType) || "30010".equals(devType)) {
				List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "300320", taskMaxDegreeNo);
				if (stepVOList.size() == 0) {
					return "현재 " + taskMaxDegreeNo + "차수에 완료된 개발 결과가 있어야 합니다.";
				}
			}
			if ("20010".equals(devType)) {
				List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "300500", taskMaxDegreeNo);
				if (stepVOList.size() == 0) {
					return "현재 " + taskMaxDegreeNo + "차수에 완료된 컬러개발 결과가 있어야 합니다.";
				}
			}
			List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "300800", taskMaxDegreeNo);
			if (stepVOList.size() > 0) {
				return "현재 " + taskMaxDegreeNo + "차수에 이미 완료된 TS견본검증(평가) 결과가 있습니다.";
			}
		}

		// 견본등록
		if (ApprType.APPR_TYPE_DISS_SAMPLE.getCode().equals(apprType)) {
			if ("20010".equals(devType)) {
				List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "300500");
				if (stepVOList.size() == 0) {
					return "완료된 컬러개발 결과가 있어야 합니다.";
				}
			} else if ("30010".equals(devType)) {
				/*
				// 견본검증 결과 완료 리스트를 구한다.
				List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "300800", taskMaxDegreeNo);
				int passCnt = 0;
				// 검증결과가 PASS 인 내역 카운트
				for (DissStepVO dissStepVO : stepVOList) {
					dissStepVO = (DissStepVO) StringUtil.nullToEmptyString(dissStepVO);
					if ("PASS".equals(dissStepVO.getStepRslt())) {
						passCnt++;
					}
				}
				// 패스된 검증결과가 있어야 견본을 등록 할수 있다.
				if (passCnt == 0) {
					return "현재 " + taskMaxDegreeNo + "차수에 성공한 TS견본검증(평가) 결과가 없습니다.";
				}
				*/
				List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "300320");
				if (stepVOList.size() == 0) {
					return "완료된 소재개발 결과가 있어야 합니다.";
				}
			} else if("IMPDEV".equals(taskType)) {
				// 현재 과제의 모든 검증결과를 조회
				List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "300800");
				// 패스된 검증결과가 있어야 견본을 등록 할수 있다.
				if(stepVOList.size() == 0) {
					return "성공한 TS견본검증(평가) 결과가 없습니다.";
				}
			}
		}

		// 고객테스트
		if (ApprType.APPR_TYPE_DISS_CUSTTEST.getCode().equals(apprType)) {
			if(!("SPECIN".equals(taskType) && "10010".equals(devType))) {
				List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "300320", taskMaxDegreeNo);
				List<DissStepVO> stepVOListColor = getCompStepList(dissApprCommonParamVO, "300500", taskMaxDegreeNo);
				if (stepVOList.size() == 0 && stepVOListColor.size() == 0) {
					return "현재 " + taskMaxDegreeNo + "차수에 완료된 개발 결과가 있어야 합니다.";
				}
			}

			/*
			// 제품개선개발 중합의 경우 견본송부 체크 제외
			if("SPECIN".equals(taskType)) {
				// 먼저 품의 완료된 견본이 있는지 확인
				stepVOList = getCompStepList(dissApprCommonParamVO, "400200", taskMaxDegreeNo);
				if (stepVOList.size() == 0) {
					return "현재 " + taskMaxDegreeNo + "차수에 품의완료 견본등록건이 있어야 합니다.";
				}

				// 	주문확정된 견본 등록건이 있는지 체크 한다.
				int chkCnt = 0;
				for (DissStepVO dissStepVO : stepVOList) {
					dissStepVO = (DissStepVO) StringUtil.nullToEmptyString(dissStepVO);
					if (!"".equals(dissStepVO.getVbeln())) {
						chkCnt++;
					}
				}
				if (chkCnt == 0) {
					return "현재 " + taskMaxDegreeNo + "차수에 주문확정된 견본등록건이 있어야 합니다.";
				}
			} else {
				DissImpDevVO dissImpDevVO = new DissImpDevVO();
				dissImpDevVO.setTaskId(taskId);
				dissImpDevVO = dissImpDevDao.getDissImpDevDetail(dissImpDevVO);

				if(!"P".equals(dissImpDevVO.getProcessType())) {
					stepVOList = getCompStepList(dissApprCommonParamVO, "400200");
					if(stepVOList.size() == 0)
						return "품의완료 견본등록건이 있어야 합니다.";
				}
			}

			stepVOList = getCompStepList(dissApprCommonParamVO, "500100", taskMaxDegreeNo);
			// 제품개선개발 및 기존자재의 경우 한 차수 내에 여러 차례 등록가능
			if ("SPECIN".equals(taskType) && !"10010".equals(devType) && stepVOList.size() > 0) {
				return "현재 " + taskMaxDegreeNo + "차수에 이미 완료된 고객테스트 결과가 있습니다.";
			}
			*/
		}

		// 과제개발완료
		if (ApprType.APPR_TYPE_DISS_COMPLETE.getCode().equals(apprType)) {
			List<DissStepVO> stepVOList = new ArrayList<>();
			// 개선개발인경우 개발결과 완료건을 체크 한다.
			if ("IMPDEV".equals(taskType)) {
				stepVOList = getCompStepList(dissApprCommonParamVO, "300320", taskMaxDegreeNo);
				if (stepVOList.size() == 0) {
					return "현재 " + taskMaxDegreeNo + "차수에 완료된 개발 결과가 있어야 합니다.";
				}

				// 견본검증 결과 완료 리스트를 구한다.
				stepVOList = getCompStepList(dissApprCommonParamVO, "300800", taskMaxDegreeNo);
				int passCnt = 0;
				// 검증결과가 PASS 인 내역 카운트
				for (DissStepVO dissStepVO : stepVOList) {
					dissStepVO = (DissStepVO) StringUtil.nullToEmptyString(dissStepVO);
					if ("PASS".equals(dissStepVO.getStepRslt())) {
						passCnt++;
					}
				}
				// 패스된 검증결과가 있어야 개발완료를 할수 있음
				if (passCnt == 0) {
					return "현재 " + taskMaxDegreeNo + "차수에 성공한 TS견본검증(평가) 결과가 없습니다.";
				}
			} else {
				if ("20010".equals(devType)) {
					List<DissStepVO> stepVOListColor = getCompStepList(dissApprCommonParamVO, "300500", taskMaxDegreeNo);
					stepVOList = getCompStepList(dissApprCommonParamVO, "300800", taskMaxDegreeNo);
					if (stepVOList.size() == 0 && stepVOListColor.size() == 0) {
						return "현재 " + taskMaxDegreeNo + "차수에 완료된 TS견본검증(평가) 결과가 없습니다.";
					}
				}
			}

			stepVOList = getCompStepList(dissApprCommonParamVO, "600100");
			if (stepVOList.size() > 0) {
				return "이미 완료된 과제개발완료 결과가 있습니다.";
			}
		}

		// 규격제정/개정
		if (ApprType.APPR_TYPE_DISS_COMPGRADE.getCode().equals(apprType)) {
			List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "600100");
			if (stepVOList.size() == 0) {
				return "완료된 과제만 등록 가능 합니다.";
			}

			int passCnt = 0;
			for (DissStepVO dissStepVO : stepVOList) {
				dissStepVO = (DissStepVO) StringUtil.nullToEmptyString(dissStepVO);
				if ("PASS".equals(dissStepVO.getCompResult())) {
					passCnt++;
				}
			}
			if (passCnt == 0) {
				return "성공한 개발완료 과제만 작성 가능 합니다.";
			}

			stepVOList = getCompStepList(dissApprCommonParamVO, "700200", taskMaxDegreeNo);
			if (stepVOList.size() > 0) {
				return "이미 완료된 규격제정/개정 결과가 있습니다.";
			}
		}

		// 양산이관
		if (ApprType.APPR_TYPE_DISS_MASSTRANS.getCode().equals(apprType)) {
			List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "600100");
			if (stepVOList.size() == 0) {
				return "완료된 과제만 등록 가능 합니다.";
			}
			stepVOList = getCompStepList(dissApprCommonParamVO, "700100", taskMaxDegreeNo);
			if (stepVOList.size() > 0) {
				return "이미 완료된 양산이관 결과가 있습니다.";
			}
			stepVOList = getCompStepList(dissApprCommonParamVO, "700200", taskMaxDegreeNo);
			if (stepVOList.size() == 0) {
				return "완료된 규격제정/개정 결과가 없습니다.";
			}
		}

		// 원팀 과제 수정,완료
		if(ApprType.APPR_TYPE_DISS_ONETEAM_UPDATE_PERFORMANCE.getCode().equals(apprType)
				|| ApprType.APPR_TYPE_DISS_ONETEAM_UPDATE_COMMON.getCode().equals(apprType)
				|| ApprType.APPR_TYPE_DISS_ONETEAM_COMPLETE.getCode().equals(apprType)
		){
			List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "110900");
			if (stepVOList.size() > 0) {
				return "이미 완료된 과제입니다.";
			}
		}

		return "";
	}

	/**
	 * 과제 차수 생성권한 및 유효성 체크
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 */
	@Override
	public String checkDissDegreeCreateAuth(DissApprCommonParamVO dissApprCommonParamVO){
		int taskMaxDegreeNo = 0;
		String taskType = dissApprCommonParamVO.getTaskType();    // 현재 과제구분
		String taskId = dissApprCommonParamVO.getTaskId();        // 과제ID
		String chkTargetEmpId = dissApprCommonParamVO.getUpdtIdxx(); // 로그인한 대상

		// 권한자 체크
		if("SPECIN".equals(taskType)){
			DissSpecInVO dissSpecInVOParam = new DissSpecInVO();
			dissSpecInVOParam.setTaskId(taskId);
			DissSpecInVO dissSpecInVO = (DissSpecInVO)StringUtil.nullToEmptyString(dissSpecInDao.getDissSpecInInfo(dissSpecInVOParam));
			if(!(chkTargetEmpId.equals(dissSpecInVO.getSalesEmpId()) || chkTargetEmpId.equals(dissSpecInVO.getTsEmpId()))) {
				return "차수생성은 과제의 영업담당자,TS담당자만 가능합니다.";
			}
		}else if("IMPDEV".equals(taskType)){
			DissImpDevVO dissImpDevVOParam = new DissImpDevVO();
			dissImpDevVOParam.setTaskId(taskId);
			DissImpDevVO dissImpDevVO = (DissImpDevVO) StringUtil.nullToEmptyString(dissImpDevDao.getDissImpDevDetail(dissImpDevVOParam));
			if(!chkTargetEmpId.equals(dissImpDevVO.getLeaderEmpId())){
				return "차수생성은 과제 리더만 가능 합니다.";
			}
			dissApprCommonParamVO.setApprType("차수생성");
		}

		// 진행중인 스텝이 있는지 체크
		String chkMessage = getCheckTaskStepIngMessage(dissApprCommonParamVO);
		if(!"".equals(chkMessage)) return chkMessage;

		// 스텝 체크
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setTaskId(taskId);
		taskMaxDegreeNo = dissStepDao.getDissStepMaxDegreeNo(dissStepVO);

		List<DissStepVO> stepVOList = getCompStepList(dissApprCommonParamVO, "600100");
		if (stepVOList.size() > 0) {
			return "이미 완료된 과제입니다.";
		}

		// 견본검증 결과 완료 리스트를 구한다.
		/* 견본검증결과 체크 삭제
		stepVOList = getCompStepList(dissApprCommonParamVO, "300800", taskMaxDegreeNo);
		if(stepVOList.size() == 0){
			return "현재 "+ taskMaxDegreeNo +"차수에 완료된 TS견본검증(평가) 결과가 없습니다.";
		}
		*/

		/* 고객 테스트에서 실패 시에도 차수 생성 가능하여 위에까지만 체크
		int passCnt = 0;
		// 검증결과가 PASS 아닌 내역 카운트
		for (DissStepVO chkDissStepVO : stepVOList) {
			chkDissStepVO = (DissStepVO) StringUtil.nullToEmptyString2(chkDissStepVO);
			if ("FAIL".equals(chkDissStepVO.getStepRslt())) {
				passCnt++;
			}
		}
		// 실패검증이 있을시에만 차수 생성
		if (passCnt == 0) {
			return "현재 " + taskMaxDegreeNo + "차수에 TS견본검증(평가) 실패 결과가 없습니다.";
		}
		*/

		return "";
	}

	/**
	 * 과제 수정 권한 체크
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 */
	@Override
	public String checkDissTaskEditAuth(DissApprCommonParamVO dissApprCommonParamVO){
		dissApprCommonParamVO = (DissApprCommonParamVO) StringUtil.nullToEmptyString(dissApprCommonParamVO);
		String taskType = dissApprCommonParamVO.getTaskType();    // 현재 과제구분
		String taskId = dissApprCommonParamVO.getTaskId();        // 과제ID
		String chkTargetEmpId = dissApprCommonParamVO.getUpdtIdxx(); // 로그인한 대상

		// 권한자 체크
		if("SPECIN".equals(taskType)){
			DissSpecInVO dissSpecInVOParam = new DissSpecInVO();
			dissSpecInVOParam.setTaskId(taskId);
			DissSpecInVO dissSpecInVO = (DissSpecInVO)StringUtil.nullToEmptyString(dissSpecInDao.getDissSpecInInfo(dissSpecInVOParam));
			if(!(chkTargetEmpId.equals(dissSpecInVO.getSalesEmpId()) || chkTargetEmpId.equals(dissSpecInVO.getTsEmpId()))) {
				return "수정은 과제의 영업담당자,TS담당자만 가능합니다.";
			}
		}else if("IMPDEV".equals(taskType)){
			DissImpDevVO dissImpDevVOParam = new DissImpDevVO();
			dissImpDevVOParam.setTaskId(taskId);
			DissImpDevVO dissImpDevVO = (DissImpDevVO) StringUtil.nullToEmptyString(dissImpDevDao.getDissImpDevDetail(dissImpDevVOParam));
			if(!chkTargetEmpId.equals(dissImpDevVO.getLeaderEmpId())){
				return "수정은 과제 리더만 가능 합니다.";
			}
		}

		// 진행중인 스텝이 있는지 체크
		String chkMessage = getCheckTaskStepIngMessage(dissApprCommonParamVO);
		if(!"".equals(chkMessage)) return chkMessage;

		return "";
	}

	/**
	 * 과제의 품의 완료된 지정 스텝 리스트를 반환
	 *
	 * @param dissApprCommonParamVO
	 * @param stepCd
	 * @return
	 */
	@Override
	public List<DissStepVO> getCompStepList(DissApprCommonParamVO dissApprCommonParamVO, String stepCd) {
		DissStepVO dissStepVOParam = new DissStepVO();
		dissStepVOParam.setTaskId(dissApprCommonParamVO.getTaskId());
		dissStepVOParam.setStepCd(stepCd);
		List<DissStepVO> stepVOList = new ArrayList<>();
		stepVOList = dissStepDao.getDissStepCompAppr(dissStepVOParam);
		return stepVOList;
	}

	/**
	 * 과제의 품의 완료된 지정 스텝 리스트를 반환 (차수별)
	 *
	 * @param dissApprCommonParamVO
	 * @param stepCd
	 * @return
	 */
	@Override
	public List<DissStepVO> getCompStepList(DissApprCommonParamVO dissApprCommonParamVO, String stepCd, int degreeNo) {
		DissStepVO dissStepVOParam = new DissStepVO();
		dissStepVOParam.setTaskId(dissApprCommonParamVO.getTaskId());
		dissStepVOParam.setStepCd(stepCd);
		dissStepVOParam.setDegreeNo(degreeNo);
		List<DissStepVO> stepVOList = new ArrayList<>();
		stepVOList = dissStepDao.getDissStepCompAppr(dissStepVOParam);
		return stepVOList;
	}

	@Override
	public void cancelGPortalApproval(String apprId, String apprEmpId, String apprMessage) {
		ApprVO apprVO = new ApprVO();
		ApprLineVO apprLineVO = new ApprLineVO();
		apprVO.setApprId(apprId);
		apprLineVO.setApprId(apprId);
		commonApprDao.cancelAppr(apprVO);
		commonApprDao.cancelApprLine(apprLineVO);
		gPortalListTypeRestService.deleteApproval(apprId, apprEmpId, apprMessage);
	}

	@Override
	public void deleteGPortalApproval(String apprId, String apprEmpId) {
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(apprId);
		commonApprDao.deleteAppr(apprVO);
		commonApprDao.deleteApprLineAll(apprVO);
		gPortalListTypeRestService.deleteApproval(apprId, apprEmpId, "");
	}

	@Override
	public void addApprLine(ApprVO param) {
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(param.getApprId());
		apprVO.setLineIYn("Y");
		commonApprDao.updateApprLineYn(apprVO);
		apprVO = commonApprDao.getAppr(apprVO);
		apprVO.setUpdtIdxx(param.getRegiIdxx());

		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(param.getApprId());
		List<String> apprLineList = new ArrayList<String>();
		for(ApprLineVO apprLine : commonApprDao.getApprLineList(apprLineVO))
			apprLineList.add(apprLine.getApprEmpId());

		int idx = apprLineList.size();

		for(ApprLineVO apprLine : param.getApprLineList())
			if(!apprLineList.contains(apprLine.getApprEmpId())) {
				EmployVO employVO = commonDao.getEmployBySawnCode(apprLine.getApprEmpId());
				apprLine.setApprEmpEmail(employVO.getMailAddr());
				apprLine.setApprId(param.getApprId());
				apprLine.setApprLineType("I");
				apprLine.setApprLineNo(idx++);
				apprLine.setApprEmpId(employVO.getSawnCode());
				apprLine.setApplTeamNm(employVO.getTeamName());
				apprLine.setApplPosiNm(employVO.getPosiName());
				apprLine.setRegiIdxx(param.getRegiIdxx());
				apprLine.setUpdtIdxx(param.getRegiIdxx());
				commonApprDao.createApprLine(apprLine);
	
				String messageStr = "D.I.S.S. 통보 지정된 품의서가 있습니다. 제목[" + apprVO.getApprTitle() + "]";
				sendDissApprEmail(apprVO, MailType.DISS_APPR_COMPLETE_NOTI, messageStr, apprLine, false, "");
			}
	}

	@Override
	public DissStepVO loadDissApprDoc(DissStepVO param) {
		DissStepVO dissStepVO = commonApprDao.loadDissApprDoc(param);
		return dissStepVO;
	}

	/**
	 * 결재자 승인요청 메세지
	 */
	private void sendDissApprSmsToAppl(ApprVO apprVO, ApprLineVO apprLineVO) {
		String hpno = apprLineVO.getApprEmpHpno();
		String messageStr = "D.I.S.S. 품의서 승인요청이 있습니다. 제목[" + apprVO.getApprTitle() + "]";
		SmsVO smsVo = new SmsVO();
		smsVo.setTrPhone(hpno);
		smsVo.setTrMsg(messageStr);
		smsVo.setTrEtc1(apprVO.getApprId());
		if(!apprVO.getApprType().equals("900"))	//Daily활동의 경우 제외
			smsService.sendSms(smsVo);

		sendDissApprEmail(apprVO, MailType.DISS_APPR_REQUEST_APPL, messageStr, apprLineVO,false, "승인");
	}

	/**
	 * 협의자 협의요청 문자
	 */
	private void sendDissApprSmsToConf(ApprVO apprVO, ApprLineVO apprLineVO) {
		String hpno = apprLineVO.getApprEmpHpno();
		String messageStr = "D.I.S.S. 품의서 합의요청이 있습니다. 제목[" + apprVO.getApprTitle() + "]";
		SmsVO smsVo = new SmsVO();
		smsVo.setTrPhone(hpno);
		smsVo.setTrMsg(messageStr);
		smsVo.setTrEtc1(apprVO.getApprId());
		if(!apprVO.getApprType().equals("900"))	//Daily활동의 경우 제외
			smsService.sendSms(smsVo);

		sendDissApprEmail(apprVO, MailType.DISS_APPR_REQUEST_APPL, messageStr, apprLineVO,false, "합의");
	}

	/**
	 * Gate Review 요청문자
	 * @param stat - true : GateReview 요청, false : GateReview 반려
	 */
	private void sendDissApprSmsForGateReview(ApprVO apprVO, ApprLineVO apprLineVO, boolean stat) {
		String hpno = apprLineVO.getApprEmpHpno();
		String messageStr = stat ? "D.I.S.S. SPEC-IN GATE REVIEW 요청이 있습니다." : "D.I.S.S. SPEC-IN 과제가 GATE REVIEW 단계에서 반려(취소)되었습니다.";
		SmsVO smsVo = new SmsVO();
		smsVo.setTrPhone(hpno);
		smsVo.setTrMsg(messageStr);
		smsVo.setTrEtc1(apprVO.getApprId());
		smsService.sendSms(smsVo);
		sendDissApprEmail(apprVO, stat ? MailType.DISS_REQUEST_GATEREVIEW : MailType.DISS_REQUEST_GATEREVIEW_CANCEL, messageStr, apprLineVO,false, "");
	}

	/**
	 * 참조자 상신시작 안내 문자
	 */
	private void sendDissApprSmsToRef(ApprVO apprVO, ApprLineVO apprLineVO) {
		String hpno = apprLineVO.getApprEmpHpno();
		String messageStr = "참조된 D.I.S.S. 품의서가 있습니다. 제목[" + apprVO.getApprTitle() + "]";
		SmsVO smsVo = new SmsVO();
		smsVo.setTrPhone(hpno);
		smsVo.setTrMsg(messageStr);
		smsVo.setTrEtc1(apprVO.getApprId());
		if(!apprVO.getApprType().equals("900"))	//Daily활동의 경우 제외
			smsService.sendSms(smsVo);

		sendDissApprEmail(apprVO, MailType.DISS_APPR_REFERENCE, messageStr, apprLineVO,false, "");
	}

	/**
	 * 결재완료 안내 문자(작성자 포함, 최종 결재자 제외, 결재라인 전체)
	 */
	private void sendDissApprSmsForComplete(ApprVO apprVO, ApprLineVO apprLineVO) {
		// 품의 최종 결재자 제외
		if(!apprVO.getUpdtIdxx().equals(apprLineVO.getApprEmpId())) {
			EmployVO employVO = commonDao.getEmployBySawnCode(apprVO.getUpdtIdxx());
			String apprType = apprVO.getApprType().equals("201") ? "Gate Review " : "";
			String hpno = apprLineVO.getApprEmpHpno();
			String messageStr = "D.I.S.S. " + apprType + "품의서가(" + employVO.getSawnName() + "/" + employVO.getPosiName() + ") 승인완료 되었습니다. 제목[" + apprVO.getApprTitle() + "]";
			SmsVO smsVo = new SmsVO();
			smsVo.setTrPhone(hpno);
			smsVo.setTrMsg(messageStr);
			smsVo.setTrEtc1(apprVO.getApprId());
			if(!apprVO.getApprType().equals("900"))	//Daily활동의 경우 제외
				smsService.sendSms(smsVo);

			// 결재라인 구분
			if(apprVO.getRegiIdxx().equals(apprLineVO.getApprEmpId())) {	// 작성자
				sendDissApprEmail(apprVO, MailType.DISS_APPR_COMPLETE_REGISTER, messageStr, apprLineVO, true, "승인완료");
			} else if(apprLineVO.getApprLineType().equals(ApprLineType.APPR_APROBE.getCode())) {	// 결재자
				sendDissApprEmail(apprVO, MailType.DISS_APPR_COMPLETE_APPL, messageStr, apprLineVO, false, "승인완료");
			} else if(apprLineVO.getApprLineType().equals(ApprLineType.APPR_CONFIRM.getCode())) {	// 합의자
				sendDissApprEmail(apprVO, MailType.DISS_APPR_COMPLETE_CONFIRM, messageStr, apprLineVO, false, "승인완료");
			} else if(apprLineVO.getApprLineType().equals(ApprLineType.APPR_REFERENCE.getCode())) {	// 참조자
				sendDissApprEmail(apprVO, MailType.DISS_APPR_COMPLETE_REFERENCE, messageStr, apprLineVO, false, "승인완료");
			} else if(apprLineVO.getApprLineType().equals(ApprLineType.APPR_INFORM.getCode())) {	// 통보자
				sendDissApprEmail(apprVO, MailType.DISS_APPR_COMPLETE_NOTI, messageStr, apprLineVO, false, "승인완료");
			}
		}
	}

	/**
	 * 작성완료 안내 문자(통보자)
	 */
	private void sendDissApprSmsForWriteComplete(ApprVO apprVO, ApprLineVO apprLineVO) {
		String hpno = apprLineVO.getApprEmpHpno();
		String messageStr = "D.I.S.S. 문서가 작성완료 되었습니다. 제목[" + apprVO.getApprTitle() + "]";
		SmsVO smsVo = new SmsVO();
		smsVo.setTrPhone(hpno);
		smsVo.setTrMsg(messageStr);
		smsVo.setTrEtc1(apprVO.getApprId());
		if(!apprVO.getApprType().equals("900"))	//Daily활동의 경우 제외
			smsService.sendSms(smsVo);

		sendDissApprEmail(apprVO, MailType.DISS_APPR_COMPLETE_NOTI, messageStr, apprLineVO,false, "");
	}

	/**
	 * 결재반려 안내 문자(기안자, 최종결재 제외 결재자, 합의자, 참조자)
	 */
	private void sendDissApprSmsForReject(ApprVO apprVO, ApprLineVO apprLineVO) {
		// 반려자 제외
		if(!apprVO.getUpdtIdxx().equals(apprLineVO.getApprEmpId())
		&& !(ApplState.APPL_WAITING.getCode().equals(apprLineVO.getApplStat()) && // 결재자, 합의자 중 미결자 제외
			(apprLineVO.getApprLineType().equals(ApprLineType.APPR_APROBE.getCode()) || apprLineVO.getApprLineType().equals(ApprLineType.APPR_CONFIRM.getCode())))) {
			String hpno = apprLineVO.getApprEmpHpno();
			String messageStr = "D.I.S.S. 품의서가 반려 되었습니다. 제목[" + apprVO.getApprTitle() + "]";
			SmsVO smsVo = new SmsVO();
			smsVo.setTrPhone(hpno);
			smsVo.setTrMsg(messageStr);
			smsVo.setTrEtc1(apprVO.getApprId());
			if(!apprVO.getApprType().equals("900"))	//Daily활동의 경우 제외
				smsService.sendSms(smsVo);

			if(apprVO.getRegiIdxx().equals(apprLineVO.getApprEmpId())) {	// 작성자
				sendDissApprEmail(apprVO, MailType.DISS_APPR_COMPLETE_REGISTER, messageStr, apprLineVO,true, "반려");
			} else if(apprLineVO.getApprLineType().equals(ApprLineType.APPR_APROBE.getCode())) {	// 결재자
				sendDissApprEmail(apprVO, MailType.DISS_APPR_COMPLETE_APPL, messageStr, apprLineVO,false, "반려");
			} else if(apprLineVO.getApprLineType().equals(ApprLineType.APPR_CONFIRM.getCode())) {	// 합의자
				sendDissApprEmail(apprVO, MailType.DISS_APPR_COMPLETE_CONFIRM, messageStr, apprLineVO,false, "반려");
			} else if(apprLineVO.getApprLineType().equals(ApprLineType.APPR_REFERENCE.getCode())) {	// 참조자
				sendDissApprEmail(apprVO, MailType.DISS_APPR_COMPLETE_REFERENCE, messageStr, apprLineVO,false, "반려");
			}
		}
	}

	/**
	 * 이메일 알람 보내기
	 *
	 * @param apprVO 품의서정보
	 * @param mailType 메일타입
	 * @param mailTitle 메일제목
	 * @param apprLineVO 수신자정보(email)
	 * @param myReqYn 내용청결재함여부 true : 나의요청진행현황  /   false : 결재함
	 */
	private void sendDissApprEmail(ApprVO apprVO, MailType mailType, String mailTitle, ApprLineVO apprLineVO, Boolean myReqYn, String apprActName){

		Map<String,String> mailParamMap = new HashMap<>();
		String dissApprListUrl      = messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=";
		String dissMyApprListUrl    = messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=";
		String specInTaskListUrl    = messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=";
		String impDevTaskListUrl    = messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=";
		String oneTeamTaskListUrl   = messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=";
		// URL Encoding
		try {
			dissApprListUrl     = dissApprListUrl + URLEncoder.encode("/dissAppr/dissMyApprInfo","UTF-8") + "?apprId=" + apprVO.getApprId();
			dissMyApprListUrl   = dissMyApprListUrl + URLEncoder.encode("/dissAppr/dissMyApprReqInfo","UTF-8") + "?apprId=" + apprVO.getApprId();
			specInTaskListUrl   = specInTaskListUrl + URLEncoder.encode("/dissSpecIn/dissSpecInList","UTF-8") + "?apprId=" + apprVO.getApprId();
			impDevTaskListUrl   = impDevTaskListUrl + URLEncoder.encode("/dissImpDev/dissImpDevList","UTF-8") + "?apprId=" + apprVO.getApprId();
			oneTeamTaskListUrl  = oneTeamTaskListUrl + URLEncoder.encode("/dissOneTeam/dissOneTeamList","UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		// 결재리스트 링크 분기
		if(myReqYn){
			mailParamMap.put("dissApprListUrl",dissMyApprListUrl);
		}else{
			mailParamMap.put("dissApprListUrl",dissApprListUrl);
		}

		mailParamMap.put("apprActName",apprActName);
		mailParamMap.put("apprTitle", apprVO.getApprTitle());

		// 과제명,과제리스트 분기
		if(ApprType.APPR_TYPE_DISS_DAILY_ACT.getCode().equals(apprVO.getApprType())){ // 데일리활동 인 경우
			mailParamMap.put("taskName",""); // 데일리활동 품의는 과제 없이
			mailParamMap.put("taskListUrl",""); // 데일리활동 품의는 과제리스트 링크 없이
		}else{
			// 원팀과제 회의록은 스텝을 사용 하지 않으므로 따로 구한다.
			if(ApprType.APPR_TYPE_DISS_ONETEAM_REPORT.getCode().equals(apprVO.getApprType())){ // 원팀과제 회의록인경우
				DissOneTeamVO dissOneTeamVOParam = new DissOneTeamVO();
				dissOneTeamVOParam.setApprId(apprVO.getApprId());
				DissOneTeamVO dissOneTeamVO = dissOneTeamDao.getDissOneTeamInfoByApprId(dissOneTeamVOParam);
				mailParamMap.put("taskName",dissOneTeamVO.getTaskName());
				mailParamMap.put("taskListUrl",oneTeamTaskListUrl + "?taskId=" + dissOneTeamVO.getTaskId());
			}else{                                                                                // 데일리활동,원팀과제가 아니면 리스트형 품의서는 모두 step 사용
				DissStepVO dissStepVO = new DissStepVO();
				dissStepVO.setApprId(apprVO.getApprId());
				dissStepVO = dissStepDao.getDissStepByApprId(dissStepVO);
				mailParamMap.put("taskName",dissStepVO.getTaskName());
				if("SPECIN".equals(dissStepVO.getTaskType())){
					mailParamMap.put("taskListUrl",specInTaskListUrl);
				}else if("IMPDEV".equals(dissStepVO.getTaskType())){
					mailParamMap.put("taskListUrl",impDevTaskListUrl);
				}else if("ONETEAM".equals(dissStepVO.getTaskType())){
					mailParamMap.put("taskListUrl",oneTeamTaskListUrl + "?apprId=" + apprVO.getApprId());
				}
			}
		}

		EmployVO employVO = commonDao.getEmployBySawnCode(apprVO.getRegiIdxx());

		SendMailVO sendMailVO = new SendMailVO();
		sendMailVO.setTitle(mailTitle);
		sendMailVO.setMailType(mailType);
		sendMailVO.setSenderEmail(employVO.getSawnName() + "/" +employVO.getPosiName() + " <" + employVO.getMailAddr() + ">");
		sendMailVO.setReceiverEmail(apprLineVO.getApprEmpEmail());
		sendMailVO.setParams(mailParamMap);
		mailingService.sendMail(sendMailVO);
	}

}
