package com.lgmma.salesPortal.app.model;

public class DissDashBoardVO extends PagingParamVO{
	// My 진행중
	private Integer totCnt;
	private Integer compCnt;
	private Integer ingCnt;
	private Integer onCnt;
	private Integer offCnt;
	private String loginEmpId;
	
	// My 결재
	private String applStat;
	// 일정 별 My 할일
	private String stepGroup;
	private String stepCd;
	private Integer tempSaveCnt;
	private Integer apprProceedingCnt;
	private Integer apprRejectCnt;
	private Integer confRejectCnt;
	private Integer apprCompleteCnt;
	private Integer writeCompleteCnt;
	private Integer myRegiCnt;
	
	//링크용
	private String myIngYn;
	private String scTaskStat;
	private String scStepCd;
	private String scApprStat;
	
	private String taskType;
	public Integer getTotCnt() {
		return totCnt;
	}
	public void setTotCnt(Integer totCnt) {
		this.totCnt = totCnt;
	}
	public Integer getCompCnt() {
		return compCnt;
	}
	public void setCompCnt(Integer compCnt) {
		this.compCnt = compCnt;
	}
	public Integer getIngCnt() {
		return ingCnt;
	}
	public void setIngCnt(Integer ingCnt) {
		this.ingCnt = ingCnt;
	}
	public Integer getOnCnt() {
		return onCnt;
	}
	public void setOnCnt(Integer onCnt) {
		this.onCnt = onCnt;
	}
	public Integer getOffCnt() {
		return offCnt;
	}
	public void setOffCnt(Integer offCnt) {
		this.offCnt = offCnt;
	}
	public String getLoginEmpId() {
		return loginEmpId;
	}
	public void setLoginEmpId(String loginEmpId) {
		this.loginEmpId = loginEmpId;
	}
	public String getApplStat() {
		return applStat;
	}
	public void setApplStat(String applStat) {
		this.applStat = applStat;
	}
	public String getStepGroup() {
		return stepGroup;
	}
	public void setStepGroup(String stepGroup) {
		this.stepGroup = stepGroup;
	}
	public String getStepCd() {
		return stepCd;
	}
	public void setStepCd(String stepCd) {
		this.stepCd = stepCd;
	}

	public Integer getTempSaveCnt() {
		return tempSaveCnt;
	}
	public void setTempSaveCnt(Integer tempSaveCnt) {
		this.tempSaveCnt = tempSaveCnt;
	}
	public Integer getApprProceedingCnt() {
		return apprProceedingCnt;
	}
	public void setApprProceedingCnt(Integer apprProceedingCnt) {
		this.apprProceedingCnt = apprProceedingCnt;
	}
	public Integer getApprRejectCnt() {
		return apprRejectCnt;
	}
	public void setApprRejectCnt(Integer apprRejectCnt) {
		this.apprRejectCnt = apprRejectCnt;
	}
	public Integer getConfRejectCnt() {
		return confRejectCnt;
	}
	public void setConfRejectCnt(Integer confRejectCnt) {
		this.confRejectCnt = confRejectCnt;
	}
	public Integer getApprCompleteCnt() {
		return apprCompleteCnt;
	}
	public void setApprCompleteCnt(Integer apprCompleteCnt) {
		this.apprCompleteCnt = apprCompleteCnt;
	}
	public Integer getWriteCompleteCnt() {
		return writeCompleteCnt;
	}
	public void setWriteCompleteCnt(Integer writeCompleteCnt) {
		this.writeCompleteCnt = writeCompleteCnt;
	}
	public Integer getMyRegiCnt() {
		return myRegiCnt;
	}
	public void setMyRegiCnt(Integer myRegiCnt) {
		this.myRegiCnt = myRegiCnt;
	}
	public String getMyIngYn() {
		return myIngYn;
	}
	public void setMyIngYn(String myIngYn) {
		this.myIngYn = myIngYn;
	}
	public String getScTaskStat() {
		return scTaskStat;
	}
	public void setScTaskStat(String scTaskStat) {
		this.scTaskStat = scTaskStat;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getScStepCd() {
		return scStepCd;
	}
	public void setScStepCd(String scStepCd) {
		this.scStepCd = scStepCd;
	}
	public String getScApprStat() {
		return scApprStat;
	}
	public void setScApprStat(String scApprStat) {
		this.scApprStat = scApprStat;
	}

}