package com.lgmma.salesPortal.app.model;

import java.util.Collections;
import java.util.List;

import org.hibernate.validator.constraints.NotBlank;

import com.lgmma.salesPortal.common.model.validation.Max2Byte;

public class OrganVO extends PagingParamVO {
	private String vkorg;
	private String compCode;
	private String bzirk;
	private String vkbur;
	private String vkgrp;
	private String kdgrp;
	private String waers;
	private String kkber;
	private String ktgrd;
	private String kvgr1;
	private String kvgr2;
	private String kvgr3;
	private String kvgr4;
	private String kvgr5;
	private String vtweg;
	private String spart;
	private String prodItem1;
	private String sendAre1;
	private String releCom1;
	private String mainBan1;
	private String mainBan2;
	private String mainBan3;
	private String mainBan4;
	private String mainBan5;
	private String majrFac1;
	private String compLevl1;
	private String compLevl2;
	private String compLevl1Text;
	private String compLevl2Text;
	private String custInfo;
	private String usgeGrad;
	private String usgeQtyx;
	private int salePric;
	private String partProd;
	@NotBlank(message="담당영업사원{errors.required}")
	private String saleMan1;
	private String saleMan2;
	private String saleMan3;
	private String monyCond;
	private String monyDate;
	private String factExis;
	private String flexMort;
	private String credBigo;
	@Max2Byte(value=500, eng=1000, message="비고{errors.maxlength.kor}")
	private String basiBigo;
	private String erpxSman;
	private String erpxSday;
	private String erpxSend;
	private String dealIdxx;
	private String dealName;
	private String useYn;
	private String erpxSendTeam;
	private String sawnName;
	private String addOrg;
	private String guarExptYmd;
	private String fileId;
	private String guraExpt;
	private String fileName;
	@Max2Byte(value=10, eng=10, message="ERP인도처코드{errors.maxlength.kor}")
	private String erpIndoCode;
	@Max2Byte(value=50, eng=100, message="계약서용 고객명{errors.maxlength.kor}")
	private String contractName;
	@Max2Byte(value=50, eng=100, message="계약서용 주소1{errors.maxlength.kor}")
	private String contractAddr1;
	@Max2Byte(value=50, eng=100, message="계약서용 주소2{errors.maxlength.kor}")
	private String contractAddr2;
	@Max2Byte(value=50, eng=100, message="계약서용 주소3{errors.maxlength.kor}")
	private String contractAddr3;
	@Max2Byte(value=50, eng=100, message="계약서용 주소4{errors.maxlength.kor}")
	private String contractAddr4;

	private List<CompEtcSaleYearVO> etcSaleYearList = Collections.emptyList();    //년도별매출
	

	public List<CompEtcSaleYearVO> getEtcSaleYearList() {
		return etcSaleYearList;
	}
	public void setEtcSaleYearList(List<CompEtcSaleYearVO> etcSaleYearList) {
		this.etcSaleYearList = etcSaleYearList;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getAddOrg() {
		return addOrg;
	}
	public void setAddOrg(String addOrg) {
		this.addOrg = addOrg;
	}
	public String getSawnName() {
		return sawnName;
	}
	public void setSawnName(String sawnName) {
		this.sawnName = sawnName;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getBzirk() {
		return bzirk;
	}
	public void setBzirk(String bzirk) {
		this.bzirk = bzirk;
	}
	public String getVkbur() {
		return vkbur;
	}
	public void setVkbur(String vkbur) {
		this.vkbur = vkbur;
	}
	public String getVkgrp() {
		return vkgrp;
	}
	public void setVkgrp(String vkgrp) {
		this.vkgrp = vkgrp;
	}
	public String getKdgrp() {
		return kdgrp;
	}
	public void setKdgrp(String kdgrp) {
		this.kdgrp = kdgrp;
	}
	public String getWaers() {
		return waers;
	}
	public void setWaers(String waers) {
		this.waers = waers;
	}
	public String getKkber() {
		return kkber;
	}
	public void setKkber(String kkber) {
		this.kkber = kkber;
	}
	public String getKtgrd() {
		return ktgrd;
	}
	public void setKtgrd(String ktgrd) {
		this.ktgrd = ktgrd;
	}
	public String getKvgr1() {
		return kvgr1;
	}
	public void setKvgr1(String kvgr1) {
		this.kvgr1 = kvgr1;
	}
	public String getKvgr2() {
		return kvgr2;
	}
	public void setKvgr2(String kvgr2) {
		this.kvgr2 = kvgr2;
	}
	public String getKvgr3() {
		return kvgr3;
	}
	public void setKvgr3(String kvgr3) {
		this.kvgr3 = kvgr3;
	}
	public String getKvgr4() {
		return kvgr4;
	}
	public void setKvgr4(String kvgr4) {
		this.kvgr4 = kvgr4;
	}
	public String getKvgr5() {
		return kvgr5;
	}
	public void setKvgr5(String kvgr5) {
		this.kvgr5 = kvgr5;
	}
	public String getVtweg() {
		return vtweg;
	}
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	public String getSpart() {
		return spart;
	}
	public void setSpart(String spart) {
		this.spart = spart;
	}
	public String getProdItem1() {
		return prodItem1;
	}
	public void setProdItem1(String prodItem1) {
		this.prodItem1 = prodItem1;
	}
	public String getSendAre1() {
		return sendAre1;
	}
	public void setSendAre1(String sendAre1) {
		this.sendAre1 = sendAre1;
	}
	public String getReleCom1() {
		return releCom1;
	}
	public void setReleCom1(String releCom1) {
		this.releCom1 = releCom1;
	}
	public String getMainBan1() {
		return mainBan1;
	}
	public void setMainBan1(String mainBan1) {
		this.mainBan1 = mainBan1;
	}
	public String getMainBan2() {
		return mainBan2;
	}
	public void setMainBan2(String mainBan2) {
		this.mainBan2 = mainBan2;
	}
	public String getMainBan3() {
		return mainBan3;
	}
	public void setMainBan3(String mainBan3) {
		this.mainBan3 = mainBan3;
	}
	public String getMainBan4() {
		return mainBan4;
	}
	public void setMainBan4(String mainBan4) {
		this.mainBan4 = mainBan4;
	}
	public String getMainBan5() {
		return mainBan5;
	}
	public void setMainBan5(String mainBan5) {
		this.mainBan5 = mainBan5;
	}
	public String getMajrFac1() {
		return majrFac1;
	}
	public void setMajrFac1(String majrFac1) {
		this.majrFac1 = majrFac1;
	}
	public String getCompLevl1() {
		return compLevl1;
	}
	public void setCompLevl1(String compLevl1) {
		this.compLevl1 = compLevl1;
	}
	public String getCompLevl2() {
		return compLevl2;
	}
	public void setCompLevl2(String compLevl2) {
		this.compLevl2 = compLevl2;
	}
	public String getCustInfo() {
		return custInfo;
	}
	public void setCustInfo(String custInfo) {
		this.custInfo = custInfo;
	}
	public String getUsgeGrad() {
		return usgeGrad;
	}
	public void setUsgeGrad(String usgeGrad) {
		this.usgeGrad = usgeGrad;
	}
	public String getUsgeQtyx() {
		return usgeQtyx;
	}
	public void setUsgeQtyx(String usgeQtyx) {
		this.usgeQtyx = usgeQtyx;
	}
	public int getSalePric() {
		return salePric;
	}
	public void setSalePric(int salePric) {
		this.salePric = salePric;
	}
	public String getPartProd() {
		return partProd;
	}
	public void setPartProd(String partProd) {
		this.partProd = partProd;
	}
	public String getSaleMan1() {
		return saleMan1;
	}
	public void setSaleMan1(String saleMan1) {
		this.saleMan1 = saleMan1;
	}
	public String getSaleMan2() {
		return saleMan2;
	}
	public void setSaleMan2(String saleMan2) {
		this.saleMan2 = saleMan2;
	}
	public String getSaleMan3() {
		return saleMan3;
	}
	public void setSaleMan3(String saleMan3) {
		this.saleMan3 = saleMan3;
	}
	public String getMonyCond() {
		return monyCond;
	}
	public void setMonyCond(String monyCond) {
		this.monyCond = monyCond;
	}
	public String getMonyDate() {
		return monyDate;
	}
	public void setMonyDate(String monyDate) {
		this.monyDate = monyDate;
	}
	public String getFactExis() {
		return factExis;
	}
	public void setFactExis(String factExis) {
		this.factExis = factExis;
	}
	public String getFlexMort() {
		return flexMort;
	}
	public void setFlexMort(String flexMort) {
		this.flexMort = flexMort;
	}
	public String getCredBigo() {
		return credBigo;
	}
	public void setCredBigo(String credBigo) {
		this.credBigo = credBigo;
	}
	public String getBasiBigo() {
		return basiBigo;
	}
	public void setBasiBigo(String basiBigo) {
		this.basiBigo = basiBigo;
	}
	public String getErpxSman() {
		return erpxSman;
	}
	public void setErpxSman(String erpxSman) {
		this.erpxSman = erpxSman;
	}
	public String getErpxSday() {
		return erpxSday;
	}
	public void setErpxSday(String erpxSday) {
		this.erpxSday = erpxSday;
	}
	public String getErpxSend() {
		return erpxSend;
	}
	public void setErpxSend(String erpxSend) {
		this.erpxSend = erpxSend;
	}
	public String getDealIdxx() {
		return dealIdxx;
	}
	public void setDealIdxx(String dealIdxx) {
		this.dealIdxx = dealIdxx;
	}
	public String getDealName() {
		return dealName;
	}
	public void setDealName(String dealName) {
		this.dealName = dealName;
	}
	public String getUseFlag() {
		return useYn;
	}
	public void setUseFlag(String useYn) {
		this.useYn = useYn;
	}
	public String getErpxSendTeam() {
		return erpxSendTeam;
	}
	public void setErpxSendTeam(String erpxSendTeam) {
		this.erpxSendTeam = erpxSendTeam;
	}
	public String getGuarExptYmd() {
		return guarExptYmd;
	}
	public void setGuarExptYmd(String guarExptYmd) {
		this.guarExptYmd = guarExptYmd;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getCompLevl1Text() {
		return compLevl1Text;
	}
	public void setCompLevl1Text(String compLevl1Text) {
		this.compLevl1Text = compLevl1Text;
	}
	public String getCompLevl2Text() {
		return compLevl2Text;
	}
	public void setCompLevl2Text(String compLevl2Text) {
		this.compLevl2Text = compLevl2Text;
	}
	public String getGuraExpt() {
		return guraExpt;
	}
	public void setGuraExpt(String guraExpt) {
		this.guraExpt = guraExpt;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getErpIndoCode() {
		return erpIndoCode;
	}
	public void setErpIndoCode(String erpIndoCode) {
		this.erpIndoCode = erpIndoCode;
	}
	public String getContractName() {
		return contractName;
	}
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}
	public String getContractAddr1() {
		return contractAddr1;
	}
	public void setContractAddr1(String contractAddr1) {
		this.contractAddr1 = contractAddr1;
	}
	public String getContractAddr2() {
		return contractAddr2;
	}
	public void setContractAddr2(String contractAddr2) {
		this.contractAddr2 = contractAddr2;
	}
	public String getContractAddr3() {
		return contractAddr3;
	}
	public void setContractAddr3(String contractAddr3) {
		this.contractAddr3 = contractAddr3;
	}
	public String getContractAddr4() {
		return contractAddr4;
	}
	public void setContractAddr4(String contractAddr4) {
		this.contractAddr4 = contractAddr4;
	}
}
