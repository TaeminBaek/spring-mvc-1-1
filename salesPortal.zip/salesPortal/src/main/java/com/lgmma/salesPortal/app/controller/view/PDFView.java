package com.lgmma.salesPortal.app.controller.view;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.html2pdf.resolver.font.DefaultFontProvider;
import com.itextpdf.io.font.FontProgramFactory;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.font.FontProvider;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.config.viewresolver.AbstractITextPdfView;

@Component
public class PDFView extends AbstractITextPdfView {
 
    protected void buildPdfDocument(Map<String, Object> model, PdfWriter writer,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
        response.setHeader("Content-Disposition", "filename=\"" + model.get("fileName") + "\";");
        response.setHeader("Content-Transfer-Encoding", "binary");
        response.setContentType("application/pdf");

        ConverterProperties properties = new ConverterProperties();
        FontProvider fontProvider = new DefaultFontProvider(true, false, false);
//        fontProvider.addFont(FontProgramFactory.createFont(Util.getServerUrl(request) + "/web-resource/fonts/BATANG.TTC,1"));
        fontProvider.addFont(FontProgramFactory.createFont(Util.getServerUrl(request) + "/web-resource/fonts/GULIM.TTC,1"));
        fontProvider.addFont(FontProgramFactory.createFont(Util.getServerUrl(request) + "/web-resource/fonts/BATANG.TTC,1"));
        fontProvider.addFont(FontProgramFactory.createFont(Util.getServerUrl(request) + "/web-resource/fonts/MALGUN.TTF"));
        fontProvider.addFont(FontProgramFactory.createFont(Util.getServerUrl(request) + "/web-resource/fonts/NotoSansCJKkr-Light.otf"));
        fontProvider.addFont(FontProgramFactory.createFont(Util.getServerUrl(request) + "/web-resource/fonts/NotoSansCJKkr-Regular.otf"));
        fontProvider.addFont(FontProgramFactory.createFont(Util.getServerUrl(request) + "/web-resource/fonts/NotoSansCJKkr-Regular.otf"));
        fontProvider.addFont(FontProgramFactory.createFont(Util.getServerUrl(request) + "/web-resource/fonts/NotoSansCJKkr-Bold.otf"));
        properties.setFontProvider(fontProvider);
		HtmlConverter.convertToPdf((String)model.get("src"), response.getOutputStream(), properties);
    }

}


