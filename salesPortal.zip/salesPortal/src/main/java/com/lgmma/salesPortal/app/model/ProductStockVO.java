package com.lgmma.salesPortal.app.model;

public class ProductStockVO extends PagingParamVO {
	private String matnr;
	private String vkorg;
	private String werks;
	private String lgort;
	private String spart;
	private String matkl;
	private String mtart;
	private String mvgr1;
	private String mvgr2;
	private String mvgr3;
	private String mvgr4;
	private String mvgr5;
	private String charg;
	private String clabs;
	private String cumlm;
	private String cinsm;
	private String ceinm;
	private String cspem;
	private String cretm;
	private String lgobe;
	private String maktx;
	private double npkClabs;
	private double npkCinsm;
	private double npkCspem;
	private double wc2Clabs;
	private double wc2Cinsm;
	private double wc2Cspem;
	private double dpClabs ;
	private double dpCinsm ;
	private double dpCspem ;
	private String meins;
	
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getWerks() {
		return werks;
	}
	public void setWerks(String werks) {
		this.werks = werks;
	}
	public String getLgort() {
		return lgort;
	}
	public void setLgort(String lgort) {
		this.lgort = lgort;
	}
	public String getSpart() {
		return spart;
	}
	public void setSpart(String spart) {
		this.spart = spart;
	}
	public String getMatkl() {
		return matkl;
	}
	public void setMatkl(String matkl) {
		this.matkl = matkl;
	}
	public String getMtart() {
		return mtart;
	}
	public void setMtart(String mtart) {
		this.mtart = mtart;
	}
	public String getMvgr1() {
		return mvgr1;
	}
	public void setMvgr1(String mvgr1) {
		this.mvgr1 = mvgr1;
	}
	public String getMvgr2() {
		return mvgr2;
	}
	public void setMvgr2(String mvgr2) {
		this.mvgr2 = mvgr2;
	}
	public String getMvgr3() {
		return mvgr3;
	}
	public void setMvgr3(String mvgr3) {
		this.mvgr3 = mvgr3;
	}
	public String getMvgr4() {
		return mvgr4;
	}
	public void setMvgr4(String mvgr4) {
		this.mvgr4 = mvgr4;
	}
	public String getMvgr5() {
		return mvgr5;
	}
	public void setMvgr5(String mvgr5) {
		this.mvgr5 = mvgr5;
	}
	public String getCharg() {
		return charg;
	}
	public void setCharg(String charg) {
		this.charg = charg;
	}
	public String getClabs() {
		return clabs;
	}
	public void setClabs(String clabs) {
		this.clabs = clabs;
	}
	public String getCumlm() {
		return cumlm;
	}
	public void setCumlm(String cumlm) {
		this.cumlm = cumlm;
	}
	public String getCinsm() {
		return cinsm;
	}
	public void setCinsm(String cinsm) {
		this.cinsm = cinsm;
	}
	public String getCeinm() {
		return ceinm;
	}
	public void setCeinm(String ceinm) {
		this.ceinm = ceinm;
	}
	public String getCspem() {
		return cspem;
	}
	public void setCspem(String cspem) {
		this.cspem = cspem;
	}
	public String getCretm() {
		return cretm;
	}
	public void setCretm(String cretm) {
		this.cretm = cretm;
	}
	public String getLgobe() {
		return lgobe;
	}
	public void setLgobe(String lgobe) {
		this.lgobe = lgobe;
	}
	public String getMaktx() {
		return maktx;
	}
	public void setMaktx(String maktx) {
		this.maktx = maktx;
	}
	public double getNpkClabs() {
		return npkClabs;
	}
	public void setNpkClabs(double npkClabs) {
		this.npkClabs = npkClabs;
	}
	public double getNpkCinsm() {
		return npkCinsm;
	}
	public void setNpkCinsm(double npkCinsm) {
		this.npkCinsm = npkCinsm;
	}
	public double getNpkCspem() {
		return npkCspem;
	}
	public void setNpkCspem(double npkCspem) {
		this.npkCspem = npkCspem;
	}
	public double getWc2Clabs() {
		return wc2Clabs;
	}
	public void setWc2Clabs(double wc2Clabs) {
		this.wc2Clabs = wc2Clabs;
	}
	public double getWc2Cinsm() {
		return wc2Cinsm;
	}
	public void setWc2Cinsm(double wc2Cinsm) {
		this.wc2Cinsm = wc2Cinsm;
	}
	public double getWc2Cspem() {
		return wc2Cspem;
	}
	public void setWc2Cspem(double wc2Cspem) {
		this.wc2Cspem = wc2Cspem;
	}
	public double getDpClabs() {
		return dpClabs;
	}
	public void setDpClabs(double dpClabs) {
		this.dpClabs = dpClabs;
	}
	public double getDpCinsm() {
		return dpCinsm;
	}
	public void setDpCinsm(double dpCinsm) {
		this.dpCinsm = dpCinsm;
	}
	public double getDpCspem() {
		return dpCspem;
	}
	public void setDpCspem(double dpCspem) {
		this.dpCspem = dpCspem;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}

	public String getMeins() {
		return meins;
	}

	public void setMeins(String meins) {
		this.meins = meins;
	}
}
