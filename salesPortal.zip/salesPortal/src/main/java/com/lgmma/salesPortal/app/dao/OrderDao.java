package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.OrderHeadVO;
import com.lgmma.salesPortal.app.model.OrderItemVO;
import com.lgmma.salesPortal.app.model.OrderListVO;
import com.lgmma.salesPortal.app.model.OrderSaleNameListVO;


public interface OrderDao {

	int getOrderCount(OrderListVO param);
	
	List<OrderListVO> getOrderList(OrderListVO param);
	
	OrderHeadVO getOrderDetail(OrderHeadVO param);
	
	List<OrderItemVO> getOrderItemList(OrderItemVO param);
	
	int getSaleNameCount(OrderSaleNameListVO param);
	
	List<OrderSaleNameListVO> getSaleNameList(OrderSaleNameListVO param);
	
	void createOrderHead(OrderHeadVO param);
	void createOrderItem(OrderItemVO param);
	
	void updateOrderItem(OrderItemVO param);
	
	void deleteOrderItem(OrderItemVO param);
	
	int getOrderConfirmCount(OrderListVO param);
	
	List<OrderListVO> getOrderConfirmList(OrderListVO param);
	
	OrderHeadVO getOrderConfirmDetail(OrderHeadVO param);
	
	List<OrderItemVO> getOrderConfirmItemList(OrderItemVO param);
	
	List<OrderListVO> getSapOrderCompCodeList(OrderListVO param);

	void updateOrderHead(OrderHeadVO param);

	void deleteAllOrderItem(OrderHeadVO param);

	void deleteOrderHead(OrderHeadVO param);

	OrderItemVO getOrderItem(OrderItemVO param);

	void updateConfirmOrderItem(OrderItemVO item);

	OrderHeadVO getConfirmedEaslesOrderHead(String orderId);

	void createConfirmOrderItem(OrderItemVO newItem);

	void deleteConfirmOrderItem(OrderItemVO oriItem);

	void updateOrderItemComment(OrderItemVO param);

}
