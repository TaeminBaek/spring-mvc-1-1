package com.lgmma.salesPortal.partnerapp.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.PartnerCreditVO;
import com.lgmma.salesPortal.app.service.CreditMgmtService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.Util;


@Controller
@RequestMapping("/partner")
public class PartnerCreditController {

	private static Logger logger = LoggerFactory.getLogger(PartnerCreditController.class); 
	@Autowired
	CreditMgmtService creditMgmtService;
	
	@RequestMapping(value = "/creditInfo")
	public ModelAndView creditInfo(ModelAndView mav) throws Exception {
		mav.setViewName("partner/credit/creditInfo");
		
		logger.debug("######sawnIdxx	["+Util.getUserInfo("sawnIdxx")+"]");
		//PMMA 만 사용
		mav.addObject("vkorg", "3000");
		mav.addObject("vkorgText", Vkorg.getVkorg("3000").getName());
		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6));
		return mav;
	}
	
	@RequestMapping(value = "/getCreditList.json")
	public Map getCreditList(@RequestBody PartnerCreditVO param) throws Exception {
		logger.debug("######getSpmon	["+param.getSpmon()+"]");
		logger.debug("######getVkorg	["+param.getVkorg()+"]");
		logger.debug("######getKunnr	["+param.getKunnr()+"]");
		return JsonResponse.asSuccess("storeData", creditMgmtService.getParterCreditInfo(param));
	}
	
	@RequestMapping(value = "/getCreditHoldList.json")
	public Map getCreditHoldList(@RequestBody PartnerCreditVO param) throws Exception {
		List<PartnerCreditVO> returnList = creditMgmtService.getParterCreditHoldInfo(param);
		for(PartnerCreditVO l : returnList) {
			logger.debug("##getCreditHoldList####getTxt30	["+l.getTxt30()+"]");
			logger.debug("##getCreditHoldList####getWort2	["+l.getWort2()+"]");
			logger.debug("##getCreditHoldList####getWbank	["+l.getWbank()+"]");
			logger.debug("##getCreditHoldList####getZfbdt	["+l.getZfbdt()+"]");
			logger.debug("##getCreditHoldList####getZuonr	["+l.getZuonr()+"]");
			logger.debug("##getCreditHoldList####getDmbtr	["+l.getDmbtr()+"]");
			logger.debug("##getCreditHoldList####getBudat	["+l.getBudat()+"]");
		}
		return JsonResponse.asSuccess("storeData", returnList);
	}
	
	@RequestMapping(value = "/getCreditExpiredList.json")
	public Map getCreditExpiredList(@RequestBody PartnerCreditVO param) throws Exception {
		List<PartnerCreditVO> returnList = creditMgmtService.getParterCreditExpiredInfo(param);
		for(PartnerCreditVO l : returnList) {
			logger.debug("##getCreditExpiredList####getBudat	["+l.getBudat()+"]");
			logger.debug("##getCreditExpiredList####getHkont	["+l.getHkont()+"]");
			logger.debug("##getCreditExpiredList####getZuonr	["+l.getZuonr()+"]");
			logger.debug("##getCreditExpiredList####getDmbtr	["+l.getDmbtr()+"]");
			logger.debug("##getCreditExpiredList####getTxt20	["+l.getTxt20()+"]");
		}
		return JsonResponse.asSuccess("storeData", returnList);
	}
	
	@RequestMapping(value = "/getCreditCashList.json")
	public Map getCreditCashList(@RequestBody PartnerCreditVO param) throws Exception {
		List<PartnerCreditVO> returnList = creditMgmtService.getParterCreditCashInfo(param);
		for(PartnerCreditVO l : returnList) {
			logger.debug("##getCreditCashList####getBudat	["+l.getBudat()+"]");
			logger.debug("##getCreditCashList####getHkont	["+l.getHkont()+"]");
			logger.debug("##getCreditCashList####getDmbtr	["+l.getDmbtr()+"]");
			logger.debug("##getCreditCashList####getTxt20	["+l.getTxt20()+"]");
		}
		return JsonResponse.asSuccess("storeData", returnList);
	}
	
	@RequestMapping(value = "/getCreditBillList.json")
	public Map getCreditBillList(@RequestBody PartnerCreditVO param) throws Exception {
		List<PartnerCreditVO> returnList = creditMgmtService.getParterCreditBillInfo(param);
		for(PartnerCreditVO l : returnList) {
			logger.debug("##getCreditBillList####getTxt30	["+l.getTxt30()+"]");
			logger.debug("##getCreditBillList####getWort2	["+l.getWort2()+"]");
			logger.debug("##getCreditBillList####getWbank	["+l.getWbank()+"]");
			logger.debug("##getCreditBillList####getZfbdt	["+l.getZfbdt()+"]");
			logger.debug("##getCreditBillList####getZuonr	["+l.getZuonr()+"]");
			logger.debug("##getCreditBillList####getDmbtr	["+l.getDmbtr()+"]");
			logger.debug("##getCreditBillList####getBudat	["+l.getBudat()+"]");
		}
		return JsonResponse.asSuccess("storeData", returnList);
	}

}
