package com.lgmma.salesPortal.app.model;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

import com.lgmma.salesPortal.common.model.validation.BusinessNo;
import com.lgmma.salesPortal.common.model.validation.Max2Byte;

public class CompOrganEditVO extends PagingParamVO {
	private String compEditId;
	private String vkorg;
	private String vkorgText;
	private String compCode;
	private String kunnr;
	@NotBlank(message="고객명{errors.required}")
	@Max2Byte(value=21, eng=42, message="고객명{errors.maxlength.kor}")
	private String name1;
	@NotBlank(message="대표자명{errors.required}")
	@Max2Byte(value=5, eng=10, message="대표자명{errors.maxlength.kor}")
	private String j1kfrepre;
//	@NotBlank(message="대표자 생년월일{errors.required}")
	private String ceoBirthday;
	@BusinessNo(required=false, message="{errors.businessno}")
	private String stcd2;
//	@NotBlank(message="신용등급{errors.required}")
	private String compGrade;
	private String telf1Full;
	@NotBlank(message="전화번호{errors.required}")
	@Pattern(regexp="^[0-9|-]*$", message="{errors.phone}")
	private String telf1;
	@NotBlank(message="전화번호{errors.required}")
	@Pattern(regexp="^[0-9|-]*$", message="{errors.phone}")
	private String telf2;
	@NotBlank(message="전화번호{errors.required}")
	@Pattern(regexp="^[0-9|-]*$", message="{errors.phone}")
	private String telf3;
	private String telfx;
	@Pattern(regexp="^[0-9|-]*$", message="{errors.fax}")
	private String telfx1;
	@Pattern(regexp="^[0-9|-]*$", message="{errors.fax}")
	private String telfx2;
	@Pattern(regexp="^[0-9|-]*$", message="{errors.fax}")
	private String telfx3;
	private String postlz;
	private String strasPre;
	private String stras;
	@Max2Byte(value=17, eng=34, message="사업장주소{errors.maxlength.kor}")
	private String strasFull;
	private String postlz2;
	private String stras2Pre;
	private String stras2;
	@Max2Byte(value=17, eng=34, message="본점주소{errors.maxlength.kor}")
	private String stras2Full;
	private int umsat;
	private int jmzah;
	private String madeDate;
	private String homePage;
	@NotBlank(message="국가구분{errors.required}")
	private String land1;
	private String land1Text;
	private String lzone;
	private String lzoneText;
	@NotBlank(message="고객그룹1{errors.required}")
	private String kvgr1;
	@NotBlank(message="고객그룹2{errors.required}")
	private String kvgr2;
	@NotBlank(message="고객그룹3{errors.required}")
	private String kvgr3;
	@NotBlank(message="고객그룹4{errors.required}")
	private String kvgr4;
	@NotBlank(message="고객그룹5{errors.required}")
	private String kvgr5;
	@NotBlank(message="수금조건{errors.required}")
	private String monyCond;
	private String kvgr1Text;
	private String kvgr2Text;
	private String kvgr3Text;
	private String kvgr4Text;
	private String kvgr5Text;
	private String monyCondText;
	@Max2Byte(value=500, eng=1000, message="비고{errors.maxlength.kor}")
	private String basiBigo;
	private String fileId;
	private String apprId;
	private String apprReqYn;
	@Max2Byte(value=15, eng=30, message="대표자명2{errors.maxlength.kor}")
	private String ceoFullNm;
	@Max2Byte(value=15, eng=30, message="추가 대표자명{errors.maxlength.kor}")
	private String ceoEtcNm;
	private String apprType;
	private String apprStat;
	private String apprStatName;
	private String erpxSend;
	private String regiName;
	private String apprEndDate;
	@Max2Byte(value=25, eng=50, message="주요거래품목{errors.maxlength.kor}")
	private String tradeItem;
	private String reportYn;
	private String reportType;
	private String reportTypeText;
	private String stockYn;
	@Max2Byte(value=50, eng=100, message="대표자와 LG의 관계{errors.maxlength.kor}")
	private String relationLg;
	private String bzirk;

	public String getCompEditId() {
		return compEditId;
	}
	public void setCompEditId(String compEditId) {
		this.compEditId = compEditId;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getJ1kfrepre() {
		return j1kfrepre;
	}
	public void setJ1kfrepre(String j1kfrepre) {
		this.j1kfrepre = j1kfrepre;
	}
	public String getCeoBirthday() {
		return ceoBirthday;
	}
	public void setCeoBirthday(String ceoBirthday) {
		this.ceoBirthday = ceoBirthday;
	}
	public String getStcd2() {
		return stcd2;
	}
	public void setStcd2(String stcd2) {
		this.stcd2 = stcd2;
	}
	public String getTelf1() {
		return telf1;
	}
	public void setTelf1(String telf1) {
		this.telf1 = telf1;
	}
	public String getPostlz() {
		return postlz;
	}
	public void setPostlz(String postlz) {
		this.postlz = postlz;
	}
	public String getStrasPre() {
		return strasPre;
	}
	public void setStrasPre(String strasPre) {
		this.strasPre = strasPre;
	}
	public String getStras() {
		return stras;
	}
	public void setStras(String stras) {
		this.stras = stras;
	}
	public String getPostlz2() {
		return postlz2;
	}
	public void setPostlz2(String postlz2) {
		this.postlz2 = postlz2;
	}
	public String getStras2Pre() {
		return stras2Pre;
	}
	public void setStras2Pre(String stras2Pre) {
		this.stras2Pre = stras2Pre;
	}
	public String getStras2() {
		return stras2;
	}
	public void setStras2(String stras2) {
		this.stras2 = stras2;
	}
	public int getUmsat() {
		return umsat;
	}
	public void setUmsat(int umsat) {
		this.umsat = umsat;
	}
	public int getJmzah() {
		return jmzah;
	}
	public void setJmzah(int jmzah) {
		this.jmzah = jmzah;
	}
	public String getMadeDate() {
		return madeDate;
	}
	public void setMadeDate(String madeDate) {
		this.madeDate = madeDate;
	}
	public String getHomePage() {
		return homePage;
	}
	public void setHomePage(String homePage) {
		this.homePage = homePage;
	}
	public String getKvgr1() {
		return kvgr1;
	}
	public void setKvgr1(String kvgr1) {
		this.kvgr1 = kvgr1;
	}
	public String getKvgr2() {
		return kvgr2;
	}
	public void setKvgr2(String kvgr2) {
		this.kvgr2 = kvgr2;
	}
	public String getKvgr3() {
		return kvgr3;
	}
	public void setKvgr3(String kvgr3) {
		this.kvgr3 = kvgr3;
	}
	public String getKvgr4() {
		return kvgr4;
	}
	public void setKvgr4(String kvgr4) {
		this.kvgr4 = kvgr4;
	}
	public String getKvgr5() {
		return kvgr5;
	}
	public void setKvgr5(String kvgr5) {
		this.kvgr5 = kvgr5;
	}
	public String getMonyCond() {
		return monyCond;
	}
	public void setMonyCond(String monyCond) {
		this.monyCond = monyCond;
	}
	public String getBasiBigo() {
		return basiBigo;
	}
	public void setBasiBigo(String basiBigo) {
		this.basiBigo = basiBigo;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getApprReqYn() {
		return apprReqYn;
	}
	public void setApprReqYn(String apprReqYn) {
		this.apprReqYn = apprReqYn;
	}
	public String getTelf1Full() {
		return telf1Full;
	}
	public void setTelf1Full(String telf1Full) {
		this.telf1Full = telf1Full;
	}
	public String getTelf2() {
		return telf2;
	}
	public void setTelf2(String telf2) {
		this.telf2 = telf2;
	}
	public String getTelf3() {
		return telf3;
	}
	public void setTelf3(String telf3) {
		this.telf3 = telf3;
	}
	public String getTelfx1() {
		return telfx1;
	}
	public void setTelfx1(String telfx1) {
		this.telfx1 = telfx1;
	}
	public String getTelfx2() {
		return telfx2;
	}
	public void setTelfx2(String telfx2) {
		this.telfx2 = telfx2;
	}
	public String getTelfx3() {
		return telfx3;
	}
	public void setTelfx3(String telfx3) {
		this.telfx3 = telfx3;
	}
	public String getTelfx() {
		return telfx;
	}
	public void setTelfx(String telfx) {
		this.telfx = telfx;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getStrasFull() {
		return strasFull;
	}
	public void setStrasFull(String strasFull) {
		this.strasFull = strasFull;
	}
	public String getStras2Full() {
		return stras2Full;
	}
	public void setStras2Full(String stras2Full) {
		this.stras2Full = stras2Full;
	}
	public String getCeoFullNm() {
		return ceoFullNm;
	}
	public void setCeoFullNm(String ceoFullNm) {
		this.ceoFullNm = ceoFullNm;
	}
	public String getCeoEtcNm() {
		return ceoEtcNm;
	}
	public void setCeoEtcNm(String ceoEtcNm) {
		this.ceoEtcNm = ceoEtcNm;
	}
	public String getCompGrade() {
		return compGrade;
	}
	public void setCompGrade(String compGrade) {
		this.compGrade = compGrade;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getApprStat() {
		return apprStat;
	}
	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}
	public String getApprStatName() {
		return apprStatName;
	}
	public void setApprStatName(String apprStatName) {
		this.apprStatName = apprStatName;
	}
	public String getVkorgText() {
		return vkorgText;
	}
	public void setVkorgText(String vkorgText) {
		this.vkorgText = vkorgText;
	}
	public String getKvgr1Text() {
		return kvgr1Text;
	}
	public void setKvgr1Text(String kvgr1Text) {
		this.kvgr1Text = kvgr1Text;
	}
	public String getKvgr2Text() {
		return kvgr2Text;
	}
	public void setKvgr2Text(String kvgr2Text) {
		this.kvgr2Text = kvgr2Text;
	}
	public String getKvgr3Text() {
		return kvgr3Text;
	}
	public void setKvgr3Text(String kvgr3Text) {
		this.kvgr3Text = kvgr3Text;
	}
	public String getKvgr4Text() {
		return kvgr4Text;
	}
	public void setKvgr4Text(String kvgr4Text) {
		this.kvgr4Text = kvgr4Text;
	}
	public String getKvgr5Text() {
		return kvgr5Text;
	}
	public void setKvgr5Text(String kvgr5Text) {
		this.kvgr5Text = kvgr5Text;
	}
	public String getMonyCondText() {
		return monyCondText;
	}
	public void setMonyCondText(String monyCondText) {
		this.monyCondText = monyCondText;
	}
	public String getErpxSend() {
		return erpxSend;
	}
	public void setErpxSend(String erpxSend) {
		this.erpxSend = erpxSend;
	}
	public String getRegiName() {
		return regiName;
	}
	public void setRegiName(String regiName) {
		this.regiName = regiName;
	}
	public String getApprEndDate() {
		return apprEndDate;
	}
	public void setApprEndDate(String apprEndDate) {
		this.apprEndDate = apprEndDate;
	}
	public String getApprType() {
		return apprType;
	}
	public void setApprType(String apprType) {
		this.apprType = apprType;
	}
	public String getTradeItem() {
		return tradeItem;
	}
	public void setTradeItem(String tradeItem) {
		this.tradeItem = tradeItem;
	}
	public String getReportYn() {
		return reportYn;
	}
	public void setReportYn(String reportYn) {
		this.reportYn = reportYn;
	}
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	public String getStockYn() {
		return stockYn;
	}
	public void setStockYn(String stockYn) {
		this.stockYn = stockYn;
	}
	public String getRelationLg() {
		return relationLg;
	}
	public void setRelationLg(String relationLg) {
		this.relationLg = relationLg;
	}
	public String getReportTypeText() {
		return reportTypeText;
	}
	public void setReportTypeText(String reportTypeText) {
		this.reportTypeText = reportTypeText;
	}
	public String getLand1() {
		return land1;
	}
	public void setLand1(String land1) {
		this.land1 = land1;
	}
	public String getLand1Text() {
		return land1Text;
	}
	public void setLand1Text(String land1Text) {
		this.land1Text = land1Text;
	}
	public String getLzone() {
		return lzone;
	}
	public void setLzone(String lzone) {
		this.lzone = lzone;
	}
	public String getLzoneText() {
		return lzoneText;
	}
	public void setLzoneText(String lzoneText) {
		this.lzoneText = lzoneText;
	}
	public String getBzirk() {
		return bzirk;
	}
	public void setBzirk(String bzirk) {
		this.bzirk = bzirk;
	}
}
