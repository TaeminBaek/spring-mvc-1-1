package com.lgmma.salesPortal.app.service.impl;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.dao.LoginDao;
import com.lgmma.salesPortal.app.dao.WebAccountDao;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.LoginMastVO;
import com.lgmma.salesPortal.app.model.LoginReqVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;
import com.lgmma.salesPortal.app.service.WebAccountService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.security.authentication.UserInfo;


@Transactional
@Service
public class WebAccountServiceImpl implements WebAccountService {
	
    @Autowired
    private WebAccountDao webAccountDao;
    
    @Autowired
    private LoginDao loginDao;
    
    @Autowired
    private CompanyDao companyDao;
    
	@Override
	public int getNewWebAccountRequestsCount(LoginReqVO param) {
		return webAccountDao.getNewWebAccountRequestsCount(param);
	}

	@Override
	public List<LoginReqVO> getNewWebAccountRequests(LoginReqVO param) {
		return webAccountDao.getNewWebAccountRequests(param);
	}

	@Override
	public LoginReqVO getWebAccountRequestDetail(LoginReqVO param) {
		return webAccountDao.getWebAccountRequestDetail(param);
	}

	@Override
	public void updateWebAccountStatus(LoginReqVO param) {
		if(param.getServGrad().equals("A")) {	//승인
			//아이디 중복 체크
			int existsLoginIdCnt = webAccountDao.getExistsLoginIdCount(param.getLognIdxx());
			if(existsLoginIdCnt > 0) {
				throw new ServiceException("fail.common.id.dup");
			}
			//TBS_LOGINCOMP 에 동일사업자번호가 있으면 update or insert  
			int existsBizCnt = webAccountDao.getExistsBizNumCount(param.getBizxNumx());
			if(existsBizCnt > 0) {	//TBS_LOGINCOMP update
				webAccountDao.updateLoginCompByLoginReq(param);
			} else { //TBS_LOGINCOMP insert
				webAccountDao.createLoginCompByLoginReq(param);
			}
			//TBS_LOGINUSER에 사용자 계정 생성
			webAccountDao.createLoginUser(param);
			
/*
			//TBS_LOGINMAST(사용자별 고객) 에 대표여부를 'Y'로 해서 저장 
			customerDao.createLoginMast(param);
			//TBC_ORGAN(영업조직별 고객) 신규고객이면 영업조직별 고객에 생성
			int existsOrgCnt = customerDao.getExistsOrgCount(param);
			if(existsOrgCnt == 0) {	//TBC_ORGAN insert
				customerDao.createOrgan(param);
			}			
*/
		}
		webAccountDao.updateWebAccountStatus(param);
	}

	@Override
	public int getWebAccountListCount(LoginUserVO param) {
		return webAccountDao.getWebAccountListCount(param);
	}

	@Override
	public List<LoginUserVO> getWebAccountList(LoginUserVO param) {
		return webAccountDao.getWebAccountList(param);
	}

	@Override
	public LoginUserVO getWebAccountDetail(LoginUserVO param) {
		return webAccountDao.getWebAccountDetail(param);
	}

	@Override
	public int getWebAccountCompListCount(LoginMastVO param) {
		return webAccountDao.getWebAccountCompListCount(param);
	}

	@Override
	public List<LoginMastVO> getWebAccountCompList(LoginMastVO param) {
		return webAccountDao.getWebAccountCompList(param);
	}

	@Override
	public void initWebAccountPassword(LoginUserVO param) {
		webAccountDao.initWebAccountPassword(param);
	}

	@Override
	public void updateWebAccountDetail(LoginUserVO param) {
		webAccountDao.updateLoginUser(param);
		webAccountDao.updateLoginComp(param);
	}

	@Override
	public void deleteLoginMast(LoginMastVO param) {
		webAccountDao.deleteLoginMast(param);
	}

	@Override
	public void createLoginMast(LoginMastVO param) {
		webAccountDao.createLoginMast(param);
	}

	@Override
	public void moveCustOfWebAccount(List<Map<String, String>> fromLoginMastList) {
		for(Map<String, String> loginMast : fromLoginMastList) {
			webAccountDao.moveCustOfWebAccount(loginMast);
		}
	}

	//파트너 화면에서 개인정보와 패스워드 변경시
	@Override
	public void updatePartnerWebAccountDetail(LoginUserVO param) {
		LoginUserVO beforeVO = webAccountDao.getWebAccountDetail(param);
		
		//화면에서 넘어온 정보롤 세팅
		beforeVO.setLognPwdx(StringUtil.encrypt(param.getNewPassword()));
		beforeVO.setPostCode(param.getPostCode());
		beforeVO.setPostAddr1(param.getPostAddr1());
		beforeVO.setPostAddr2(param.getPostAddr2());
		beforeVO.setTelxNum1(param.getTelxNum1());
		beforeVO.setTelxNum2(param.getTelxNum2());
		beforeVO.setTelxNum3(param.getTelxNum3());
		beforeVO.setHpxxNum1(param.getHpxxNum1());
		beforeVO.setHpxxNum2(param.getHpxxNum2());
		beforeVO.setHpxxNum3(param.getHpxxNum3());
		beforeVO.setDeptName(param.getDeptName());
		beforeVO.setDeptPosi(param.getDeptPosi());
		beforeVO.setMailAddr(param.getMailAddr());
		beforeVO.setBigoText(param.getBigoText());
		beforeVO.setPassDate("Y");
		beforeVO.setRegiIdxx(param.getRegiIdxx());
		beforeVO.setUpdtIdxx(param.getUpdtIdxx());

		//null 이 select 되면 업데이트시 오류가 발생하여 null String 으로 변환
		beforeVO.setCompCode        (StringUtil.nullConvert(beforeVO.getCompCode        ()));
		beforeVO.setCompName        (StringUtil.nullConvert(beforeVO.getCompName        ()));
		beforeVO.setLognIdxx        (StringUtil.nullConvert(beforeVO.getLognIdxx        ()));
		beforeVO.setLognPwdx        (StringUtil.nullConvert(beforeVO.getLognPwdx        ()));
		beforeVO.setNewPassword     (StringUtil.nullConvert(beforeVO.getNewPassword     ()));
		beforeVO.setLognName        (StringUtil.nullConvert(beforeVO.getLognName        ()));
		beforeVO.setJumnNumx        (StringUtil.nullConvert(beforeVO.getJumnNumx        ()));
		beforeVO.setMailAddr        (StringUtil.nullConvert(beforeVO.getMailAddr        ()));
		beforeVO.setDeptName        (StringUtil.nullConvert(beforeVO.getDeptName        ()));
		beforeVO.setDeptPosi        (StringUtil.nullConvert(beforeVO.getDeptPosi        ()));
		beforeVO.setTelxNum1        (StringUtil.nullConvert(beforeVO.getTelxNum1        ()));
		beforeVO.setTelxNum2        (StringUtil.nullConvert(beforeVO.getTelxNum2        ()));
		beforeVO.setTelxNum3        (StringUtil.nullConvert(beforeVO.getTelxNum3        ()));
		beforeVO.setHpxxNum1        (StringUtil.nullConvert(beforeVO.getHpxxNum1        ()));
		beforeVO.setHpxxNum2        (StringUtil.nullConvert(beforeVO.getHpxxNum2        ()));
		beforeVO.setHpxxNum3        (StringUtil.nullConvert(beforeVO.getHpxxNum3        ()));
		beforeVO.setBigoText        (StringUtil.nullConvert(beforeVO.getBigoText        ()));
		beforeVO.setDeptIdxx        (StringUtil.nullConvert(beforeVO.getDeptIdxx        ()));
		beforeVO.setDeptPmma        (StringUtil.nullConvert(beforeVO.getDeptPmma        ()));
		beforeVO.setLognIdyn        (StringUtil.nullConvert(beforeVO.getLognIdyn        ()));
		beforeVO.setPassDate        (StringUtil.nullConvert(beforeVO.getPassDate        ()));
		beforeVO.setCeoxName        (StringUtil.nullConvert(beforeVO.getCeoxName        ()));
		beforeVO.setBizxNumx        (StringUtil.nullConvert(beforeVO.getBizxNumx        ()));
		beforeVO.setPostCode        (StringUtil.nullConvert(beforeVO.getPostCode        ()));
		beforeVO.setPostAddr1       (StringUtil.nullConvert(beforeVO.getPostAddr1       ()));
		beforeVO.setPostAddr2       (StringUtil.nullConvert(beforeVO.getPostAddr2       ()));
		beforeVO.setFaxxNum1        (StringUtil.nullConvert(beforeVO.getFaxxNum1        ()));
		beforeVO.setFaxxNum2        (StringUtil.nullConvert(beforeVO.getFaxxNum2        ()));
		beforeVO.setFaxxNum3        (StringUtil.nullConvert(beforeVO.getFaxxNum3        ()));
		beforeVO.setMadeDate        (StringUtil.nullConvert(beforeVO.getMadeDate        ()));
		beforeVO.setProdPmma        (StringUtil.nullConvert(beforeVO.getProdPmma        ()));
		beforeVO.setProdMma         (StringUtil.nullConvert(beforeVO.getProdMma         ()));
		beforeVO.setPartFlag        (StringUtil.nullConvert(beforeVO.getPartFlag        ()));
		beforeVO.setKvgr3           (StringUtil.nullConvert(beforeVO.getKvgr3           ()));
		beforeVO.setMmaSalesEmpName (StringUtil.nullConvert(beforeVO.getMmaSalesEmpName ()));
		beforeVO.setPmmaSalesEmpName(StringUtil.nullConvert(beforeVO.getPmmaSalesEmpName()));
		beforeVO.setMailId          (StringUtil.nullConvert(beforeVO.getMailId          ()));
		beforeVO.setMailDomain      (StringUtil.nullConvert(beforeVO.getMailDomain      ()));
		beforeVO.setVkorg           (StringUtil.nullConvert(beforeVO.getVkorg           ()));
		beforeVO.setCompTelxNum1    (StringUtil.nullConvert(beforeVO.getCompTelxNum1    ()));
		beforeVO.setCompTelxNum2    (StringUtil.nullConvert(beforeVO.getCompTelxNum2    ()));
		beforeVO.setCompTelxNum3    (StringUtil.nullConvert(beforeVO.getCompTelxNum3    ()));

		//암호화된 기존비번 가져오기
		UserInfo userInfo = loginDao.getPartnerUserInfo(beforeVO.getLognIdxx());
		//암호화된 입력한 기존비번 가져오기
		String sha64Password  = loginDao.getEncryptPwd(StringUtil.encrypt(param.getLognPwdx()));
		if(!userInfo.getPassword().equals(sha64Password)) {
			throw new ServiceException("fail.common.pwd.diffrent");
		}
		webAccountDao.updateLoginUser(beforeVO);
		webAccountDao.initWebAccountPassword(beforeVO);
		webAccountDao.updateLoginComp(beforeVO);
/*
 * 기존로직은 TB_COMPANY 를 업데이트 하고 있음
 * 판매처 정보는 품의를 받고 수정후 ERP 전송해야 함
		CompanyVO companyVO= new CompanyVO();
		companyVO.setCompCode(beforeVO.getCompCode());
		companyVO = companyDao.getCompanyDetail(companyVO);

		companyVO.setPostlz2(param.getPostCode());
		companyVO.setStras2(param.getPostAddr1() + " " + param.getPostAddr2());
		companyVO.setTelf1(param.getTelxNum1() + "-" + param.getTelxNum1() + "-" + param.getTelxNum1());
		companyVO.setRegiIdxx(beforeVO.getRegiIdxx());
		companyVO.setUpdtIdxx(beforeVO.getUpdtIdxx());

		companyDao.updateCompany(companyVO);
*/
	}

}
