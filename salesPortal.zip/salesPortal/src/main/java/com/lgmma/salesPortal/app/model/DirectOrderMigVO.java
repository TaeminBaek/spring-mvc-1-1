package com.lgmma.salesPortal.app.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * @author nahong01
 * @description 주문마이그를 위한 임시VO
 */
public class DirectOrderMigVO extends PagingParamVO {
	private String workId;
	private String vbeln;
	private String seq;
	private String docType;
	private String ordReason;
	private String salesOrg;
	private String distrChan;
	private String division;
	private String reqDateH;
	private String priceDate;
	private String shipCond;
	private String shipType;
	private String purchNoC;
	private String docDate;
	private String pmnttrms;
	private String incoterms1;
	private String incoterms2;
	private String assNumber;
	private String accntAsgn;
	private String priceList;
	private String zzroute;
	private String zbkqYn;
	private String zzland1;
	private String zztrnsWay1;
	private String zztrnsWay2;
	private String zztrnsQty1;
	private String zztrnsQty2;
	private String zdptbg;
	private String partnNumbAg;
	private String partnNumbWe;
	private String partnNameWe;
	private String partnNumbVe;
	private String partnNumbZ4;
	private String partnNumbZ6;
	private String partnNumbZ7;
	private String partnNameZ7;
	private String unloadPt;
	private String bigoZ002;
	private String bigoZ012;
	private String bigoZ014;
	private String bigoZ025;
	private String condType;
	private String condValue;
	private String partnNumbZ4Name;
	private String partnNumbZ4Empnm;
	private String partnNumbZ4Telephone;
	private String price;
	private String wadatIst;
	private String material;
	private String plant;
	private String storeLoc;
	private String reqDate;
	private String reqQty;
	private String pr00Price;
	private String currency;
	private String condUnit;
	private String condPUnt;
	private String reasonRej;
	private String priceListI;
	private String iSalesOrg;
	private String iDistrChan;
	private String iDocDateF;
	private String iDocDateT;
	private String iVbeln;

	private String R_ERRCODE;
	private String R_ERRMESG;

	private String procExcuteYn;


	public String getWorkId() {
		return workId;
	}
	public void setWorkId(String workId) {
		this.workId = workId;
	}
	public String getVbeln() {
		return vbeln;
	}
	public void setVbeln(String vbeln) {
		this.vbeln = vbeln;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getOrdReason() {
		return ordReason;
	}
	public void setOrdReason(String ordReason) {
		this.ordReason = ordReason;
	}
	public String getSalesOrg() {
		return salesOrg;
	}
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	public String getDistrChan() {
		return distrChan;
	}
	public void setDistrChan(String distrChan) {
		this.distrChan = distrChan;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getReqDateH() {
		return reqDateH;
	}
	public void setReqDateH(String reqDateH) {
		this.reqDateH = reqDateH;
	}
	public String getPriceDate() {
		return priceDate;
	}
	public void setPriceDate(String priceDate) {
		this.priceDate = priceDate;
	}
	public String getShipCond() {
		return shipCond;
	}
	public void setShipCond(String shipCond) {
		this.shipCond = shipCond;
	}
	public String getShipType() {
		return shipType;
	}
	public void setShipType(String shipType) {
		this.shipType = shipType;
	}
	public String getPurchNoC() {
		return purchNoC;
	}
	public void setPurchNoC(String purchNoC) {
		this.purchNoC = purchNoC;
	}
	public String getDocDate() {
		return docDate;
	}
	public void setDocDate(String docDate) {
		this.docDate = docDate;
	}
	public String getPmnttrms() {
		return pmnttrms;
	}
	public void setPmnttrms(String pmnttrms) {
		this.pmnttrms = pmnttrms;
	}
	public String getIncoterms1() {
		return incoterms1;
	}
	public void setIncoterms1(String incoterms1) {
		this.incoterms1 = incoterms1;
	}
	public String getIncoterms2() {
		return incoterms2;
	}
	public void setIncoterms2(String incoterms2) {
		this.incoterms2 = incoterms2;
	}
	public String getAssNumber() {
		return assNumber;
	}
	public void setAssNumber(String assNumber) {
		this.assNumber = assNumber;
	}
	public String getAccntAsgn() {
		return accntAsgn;
	}
	public void setAccntAsgn(String accntAsgn) {
		this.accntAsgn = accntAsgn;
	}
	public String getPriceList() {
		return priceList;
	}
	public void setPriceList(String priceList) {
		this.priceList = priceList;
	}
	public String getZzroute() {
		return zzroute;
	}
	public void setZzroute(String zzroute) {
		this.zzroute = zzroute;
	}
	public String getZbkqYn() {
		return zbkqYn;
	}
	public void setZbkqYn(String zbkqYn) {
		this.zbkqYn = zbkqYn;
	}
	public String getZzland1() {
		return zzland1;
	}
	public void setZzland1(String zland1) {
		this.zzland1 = zzland1;
	}
	public String getZztrnsWay1() {
		return zztrnsWay1;
	}
	public void setZztrnsWay1(String zztrnsWay1) {
		this.zztrnsWay1 = zztrnsWay1;
	}
	public String getZztrnsWay2() {
		return zztrnsWay2;
	}
	public void setZztrnsWay2(String zztrnsWay2) {
		this.zztrnsWay2 = zztrnsWay2;
	}
	public String getZztrnsQty1() {
		return zztrnsQty1;
	}
	public void setZztrnsQty1(String zztrnsQty1) {
		this.zztrnsQty1 = zztrnsQty1;
	}
	public String getZztrnsQty2() {
		return zztrnsQty2;
	}
	public void setZztrnsQty2(String zztrnsQty2) {
		this.zztrnsQty2 = zztrnsQty2;
	}
	public String getZdptbg() {
		return zdptbg;
	}
	public void setZdptbg(String zdptbg) {
		this.zdptbg = zdptbg;
	}
	public String getPartnNumbAg() {
		return partnNumbAg;
	}
	public void setPartnNumbAg(String partnNumbAg) {
		this.partnNumbAg = partnNumbAg;
	}
	public String getPartnNumbWe() {
		return partnNumbWe;
	}
	public void setPartnNumbWe(String partnNumbWe) {
		this.partnNumbWe = partnNumbWe;
	}
	public String getPartnNumbVe() {
		return partnNumbVe;
	}
	public void setPartnNumbVe(String partnNumbVe) {
		this.partnNumbVe = partnNumbVe;
	}
	public String getPartnNumbZ4() {
		return partnNumbZ4;
	}
	public void setPartnNumbZ4(String partnNumbZ4) {
		this.partnNumbZ4 = partnNumbZ4;
	}
	public String getPartnNumbZ6() {
		return partnNumbZ6;
	}
	public void setPartnNumbZ6(String partnNumbZ6) {
		this.partnNumbZ6 = partnNumbZ6;
	}
	public String getPartnNumbZ7() {
		return partnNumbZ7;
	}
	public void setPartnNumbZ7(String partnNumbZ7) {
		this.partnNumbZ7 = partnNumbZ7;
	}
	public String getUnloadPt() {
		return unloadPt;
	}
	public void setUnloadPt(String unloadPt) {
		this.unloadPt = unloadPt;
	}
	public String getBigoZ002() {
		return bigoZ002;
	}
	public void setBigoZ002(String bigoZ002) {
		this.bigoZ002 = bigoZ002;
	}
	public String getBigoZ012() {
		return bigoZ012;
	}
	public void setBigoZ012(String bigoZ005) {
		this.bigoZ012 = bigoZ012;
	}
	public String getBigoZ014() {
		return bigoZ014;
	}
	public void setBigoZ014(String bigoZ014) {
		this.bigoZ014 = bigoZ014;
	}
	public String getCondType() {
		return condType;
	}
	public void setCondType(String condType) {
		this.condType = condType;
	}
	public String getCondValue() {
		return condValue;
	}
	public void setCondValue(String condValue) {
		this.condValue = condValue;
	}
	public String getPartnNumbZ4Name() {
		return partnNumbZ4Name;
	}
	public void setPartnNumbZ4Name(String partnNumbZ4Name) {
		this.partnNumbZ4Name = partnNumbZ4Name;
	}
	public String getPartnNumbZ4Empnm() {
		return partnNumbZ4Empnm;
	}
	public void setPartnNumbZ4Empnm(String partnNumbZ4Empnm) {
		this.partnNumbZ4Empnm = partnNumbZ4Empnm;
	}
	public String getPartnNumbZ4Telephone() {
		return partnNumbZ4Telephone;
	}
	public void setPartnNumbZ4Telephone(String partnNumbZ4Telephone) {
		this.partnNumbZ4Telephone = partnNumbZ4Telephone;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getStoreLoc() {
		return storeLoc;
	}
	public void setStoreLoc(String storeLoc) {
		this.storeLoc = storeLoc;
	}
	public String getReqDate() {
		return reqDate;
	}
	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}
	public String getReqQty() {
		return reqQty;
	}
	public void setReqQty(String reqQty) {
		this.reqQty = reqQty;
	}
	public String getPr00Price() {
		return pr00Price;
	}
	public void setPr00Price(String pr00Price) {
		this.pr00Price = pr00Price;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCondUnit() {
		return condUnit;
	}
	public void setCondUnit(String condUnit) {
		this.condUnit = condUnit;
	}
	public String getCondPUnt() {
		return condPUnt;
	}
	public void setCondPUnt(String condPUnt) {
		this.condPUnt = condPUnt;
	}
	public String getReasonRej() {
		return reasonRej;
	}
	public void setReasonRej(String reasonRej) {
		this.reasonRej = reasonRej;
	}
	public String getiSalesOrg() {
		return iSalesOrg;
	}
	public void setiSalesOrg(String iSalesOrg) {
		this.iSalesOrg = iSalesOrg;
	}
	public String getiDistrChan() {
		return iDistrChan;
	}
	public void setiDistrChan(String iDistrChan) {
		this.iDistrChan = iDistrChan;
	}
	public String getiDocDateF() {
		return iDocDateF;
	}
	public void setiDocDateF(String iDocDateF) {
		this.iDocDateF = iDocDateF;
	}
	public String getiDocDateT() {
		return iDocDateT;
	}
	public void setiDocDateT(String iDocDateT) {
		this.iDocDateT = iDocDateT;
	}
	public String getiVbeln() {
		return iVbeln;
	}
	public void setiVbeln(String iVbeln) {
		this.iVbeln = iVbeln;
	}
	public String getBigoZ025() {
		return bigoZ025;
	}
	public void setBigoZ025(String bigoZ025) {
		this.bigoZ025 = bigoZ025;
	}
	
	public String getR_ERRCODE() {
		return R_ERRCODE;
	}
	public void setR_ERRCODE(String r_ERRCODE) {
		R_ERRCODE = r_ERRCODE;
	}
	public String getR_ERRMESG() {
		return R_ERRMESG;
	}
	public void setR_ERRMESG(String r_ERRMESG) {
		R_ERRMESG = r_ERRMESG;
	}
	public String getPartnNameWe() {
		return partnNameWe;
	}
	public void setPartnNameWe(String partnNameWe) {
		this.partnNameWe = partnNameWe;
	}
	public String getPartnNameZ7() {
		return partnNameZ7;
	}
	public void setPartnNameZ7(String partnNameZ7) {
		this.partnNameZ7 = partnNameZ7;
	}

	public String getWadatIst() {
		return wadatIst;
	}

	public void setWadatIst(String wadatIst) {
		this.wadatIst = wadatIst;
	}

	public String getProcExcuteYn() {
		return procExcuteYn;
	}

	public void setProcExcuteYn(String procExcuteYn) {
		this.procExcuteYn = procExcuteYn;
	}

	public String getPriceListI() {
		return priceListI;
	}

	public void setPriceListI(String priceListI) {
		this.priceListI = priceListI;
	}
}
