package com.lgmma.salesPortal.common.props;

import java.util.Arrays;
import java.util.List;

public enum PeriodCodes 
{    
     /** 입력기간 검증용 단계별 상태코드
      * 
	  * 목표-합의요청				A030
	  * 목표-합의완료               A050
	  * 중간점검(1차)-본인입력      C020
	  * 중간점검(2차)-본인입력      D020
	  * 중간점검1차-평가자입력      C030
	  * 중간점검2차-평가자입력      D030
	  * 평가진행-본인평가           B030
	  * 평가진행-상대화평가완료     B070
      */
     GOAL_REQUEST     ("A030", Arrays.asList("A010","A020","A040"))
    ,GOAL_CONFIRM     ("A050", Arrays.asList("A030")) 
    ,INT_FIRST_SELF   ("C020", Arrays.asList("C010","C020"))
    ,INT_SECOND_SELF  ("D020", Arrays.asList("D010","D020"))
    ,INT_FIRST_APPR   ("C030", Arrays.asList("C022","C030"))
    ,INT_SECOND_APPR  ("D030", Arrays.asList("D022","D030"))
    ,APPR_SELF        ("B030", Arrays.asList("A050","B020"))
    ,APPR_FINISH      ("B070", Arrays.asList("B030","B040","B045"))
    ;
    
    String codeValue = null;
    List<String> supportCodeList = null;
    
    PeriodCodes(String value)
    {
        this.codeValue = value;
    }
    
    PeriodCodes(String value, List<String> supportCodeList)
    {
        this.codeValue = value;
        this.supportCodeList = supportCodeList;
    }
    
    public String getCode()
    {
        return this.codeValue;
    }
    
    public List<String> getSupportCodeList()
    {
        return this.supportCodeList;
    }
    public boolean isSupport(String compareCode)
    {
    	return this.supportCodeList.contains(compareCode);
    }
}
