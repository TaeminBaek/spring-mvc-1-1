package com.lgmma.salesPortal.common.exception;

public class ServiceExceptionWithCommit extends ServiceException
{

	/**
	 * 생성자 - 기본
	 */
	public ServiceExceptionWithCommit() 
	{
		
	}

	/**
	 * 생성자 - 코드
	 */
	public ServiceExceptionWithCommit(String errorCode) 
	{
		super(errorCode);
	}

	/**
	 * 생성자 - 코드 + 메시지
	 */
	public ServiceExceptionWithCommit(String errorCode, String errorMsg) 
	{
		super(errorCode, errorMsg);
	}
	
	/**
	 * 생성자 - 코드 + 치환 문자 배열
	 */
	public ServiceExceptionWithCommit(String errorCode, Object[] rep) 
	{
		super(errorCode, rep);
	}

	/**
	 * 생성자 - 코드 + 메시지 + 치환 문자 배열
	 */
	public ServiceExceptionWithCommit(String errorCode, String errorMsg, Object[] rep) 
	{
		super(errorCode, errorMsg, rep);
	}
	
	/**
	 * 생성자 - 다른 예외 중접
	 */
	public ServiceExceptionWithCommit(Throwable th)
	{
		super(th);
	}
}
