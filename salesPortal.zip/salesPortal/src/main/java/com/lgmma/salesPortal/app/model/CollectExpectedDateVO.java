package com.lgmma.salesPortal.app.model;

public class CollectExpectedDateVO extends PagingParamVO {
	
	private String salesOrg;
	private String distrChan;
	private String gjahr;
	private String partnNumbAg;
	private String partnNameAg;
	private String cApprEmpId;	
	private String cApprEmpNm;
	private String remainingday;

	private String ename;
	private String kunnr;
	private String name1; 
	private String civno; 
	private String fkdat;  	
	private String dmbtr; 
	private String zfbdt; 	
	private String dtcnt;
	
	public String getSalesOrg() {
		return salesOrg;
	}
	
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
			
	public String getDistrChan() {
		return distrChan;
	}

	public void setDistrChan(String distrChan) {
		this.distrChan = distrChan;
	}

	public String getGjahr() {
		return gjahr;
	}

	public void setGjahr(String gjahr) {
		this.gjahr = gjahr;
	}

	public String getPartnNumbAg() {
		return partnNumbAg;
	}
	
	public void setPartnNumbAg(String partnNumbAg) {
		this.partnNumbAg = partnNumbAg;
	}
	
	public String getPartnNameAg() {
		return partnNameAg;
	}
	
	public void setPartnNameAg(String partnNameAg) {
		this.partnNameAg = partnNameAg;
	}
	
	public String getcApprEmpId() {
		return cApprEmpId;
	}
	
	public void setcApprEmpId(String cApprEmpId) {
		this.cApprEmpId = cApprEmpId;
	}
	
	public String getcApprEmpNm() {
		return cApprEmpNm;
	}
	
	public void setcApprEmpNm(String cApprEmpNm) {
		this.cApprEmpNm = cApprEmpNm;
	}
	
	public String getRemainingday() {
		return remainingday;
	}
	
	public void setRemainingday(String remainingday) {
		this.remainingday = remainingday;
	}
	
	public String getEname() {
		return ename;
	}
	
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	public String getKunnr() {
		return kunnr;
	}
	
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	
	public String getName1() {
		return name1;
	}
	
	public void setName1(String name1) {
		this.name1 = name1;
	}
	
	public String getCivno() {
		return civno;
	}
	
	public void setCivno(String civno) {
		this.civno = civno;
	}
	
	public String getFkdat() {
		return fkdat;
	}
	
	public void setFkdat(String fkdat) {
		this.fkdat = fkdat;
	}
	
	public String getDmbtr() {
		return dmbtr;
	}
	
	public void setDmbtr(String dmbtr) {
		this.dmbtr = dmbtr;
	}
	
	public String getZfbdt() {
		return zfbdt;
	}
	
	public void setZfbdt(String zfbdt) {
		this.zfbdt = zfbdt;
	}
	
	public String getDtcnt() {
		return dtcnt;
	}
	
	public void setDtcnt(String dtcnt) {
		this.dtcnt = dtcnt;
	}
	
	
}
	
	

	
	
			


		
		
		
	
