package com.lgmma.salesPortal.app.model;

public class CreditLimitRateVO extends PagingParamVO {

	private String salesOrg;	
	private String gjahr;		
	private String partnNumbAg;
	private String partnNameAg;
	private String cApprEmpId;	
	private String cApprEmpNm;
	
	private String vkorg;
	private String kunnr;
	private String name1;
	private String waers;
	private String ename;
	private String cdateYesinlim;
	private String cdateSinyonglim;
	private String cdateAddlim;	
	private String cdateDambolim;
	private String cdateBohumlim;
	private String cdatePerBm;	
	private String cdatePer6BmAv;
	private String cdatePer3BmAv;
	private String cdateYesinBe1;	
	private String cdateYesinBe2;
	private String cdateYesinBe3;
	private String cdateYesinBe4;
	private String cdateYesinBe5;	
	private String cdateYesinBe6;
	
	public String getSalesOrg() {
		return salesOrg;
	}
	
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	
	public String getGjahr() {
		return gjahr;
	}
	
	public void setGjahr(String gjahr) {
		this.gjahr = gjahr;
	}
	
	public String getcApprEmpId() {
		return cApprEmpId;
	}
	
	public void setcApprEmpId(String cApprEmpId) {
		this.cApprEmpId = cApprEmpId;
	}
	
	public String getcApprEmpNm() {
		return cApprEmpNm;
	}
	
	public void setcApprEmpNm(String cApprEmpNm) {
		this.cApprEmpNm = cApprEmpNm;
	}
	
	public String getVkorg() {
		return vkorg;
	}
	
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	
	public String getKunnr() {
		return kunnr;
	}
	
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	
	public String getName1() {
		return name1;
	}
	
	public void setName1(String name1) {
		this.name1 = name1;
	}
	
	public String getWaers() {
		return waers;
	}
	
	public void setWaers(String waers) {
		this.waers = waers;
	}
	
	public String getEname() {
		return ename;
	}
	
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	public String getCdateYesinlim() {
		return cdateYesinlim;
	}
	
	public void setCdateYesinlim(String cdateYesinlim) {
		this.cdateYesinlim = cdateYesinlim;
	}
	
	public String getCdateSinyonglim() {
		return cdateSinyonglim;
	}
	
	public void setCdateSinyonglim(String cdateSinyonglim) {
		this.cdateSinyonglim = cdateSinyonglim;
	}
	
	public String getCdateAddlim() {
		return cdateAddlim;
	}
	
	public void setCdateAddlim(String cdateAddlim) {
		this.cdateAddlim = cdateAddlim;
	}
	
	public String getCdateDambolim() {
		return cdateDambolim;
	}
	
	public void setCdateDambolim(String cdateDambolim) {
		this.cdateDambolim = cdateDambolim;
	}
	
	public String getCdateBohumlim() {
		return cdateBohumlim;
	}
	
	public void setCdateBohumlim(String cdateBohumlim) {
		this.cdateBohumlim = cdateBohumlim;
	}
	
	public String getCdatePerBm() {
		return cdatePerBm;
	}
	
	public void setCdatePerBm(String cdatePerBm) {
		this.cdatePerBm = cdatePerBm;
	}
	
	public String getCdatePer6BmAv() {
		return cdatePer6BmAv;
	}
	
	public void setCdatePer6BmAv(String cdatePer6BmAv) {
		this.cdatePer6BmAv = cdatePer6BmAv;
	}
	
	public String getCdatePer3BmAv() {
		return cdatePer3BmAv;
	}
	
	public void setCdatePer3BmAv(String cdatePer3BmAv) {
		this.cdatePer3BmAv = cdatePer3BmAv;
	}
	
	public String getCdateYesinBe1() {
		return cdateYesinBe1;
	}
	
	public void setCdateYesinBe1(String cdateYesinBe1) {
		this.cdateYesinBe1 = cdateYesinBe1;
	}
	
	public String getCdateYesinBe2() {
		return cdateYesinBe2;
	}
	
	public void setCdateYesinBe2(String cdateYesinBe2) {
		this.cdateYesinBe2 = cdateYesinBe2;
	}
	
	public String getCdateYesinBe3() {
		return cdateYesinBe3;
	}
	
	public void setCdateYesinBe3(String cdateYesinBe3) {
		this.cdateYesinBe3 = cdateYesinBe3;
	}
	
	public String getCdateYesinBe4() {
		return cdateYesinBe4;
	}
	
	public void setCdateYesinBe4(String cdateYesinBe4) {
		this.cdateYesinBe4 = cdateYesinBe4;
	}
	
	public String getCdateYesinBe5() {
		return cdateYesinBe5;
	}
	
	public void setCdateYesinBe5(String cdateYesinBe5) {
		this.cdateYesinBe5 = cdateYesinBe5;
	}
	
	public String getCdateYesinBe6() {
		return cdateYesinBe6;
	}
	
	public void setCdateYesinBe6(String cdateYesinBe6) {
		this.cdateYesinBe6 = cdateYesinBe6;
	}

	public String getPartnNumbAg() {
		return partnNumbAg;
	}

	public void setPartnNumbAg(String partnNumbAg) {
		this.partnNumbAg = partnNumbAg;
	}

	public String getPartnNameAg() {
		return partnNameAg;
	}

	public void setPartnNameAg(String partnNameAg) {
		this.partnNameAg = partnNameAg;
	}
	

}
