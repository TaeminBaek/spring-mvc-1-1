package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.StatisticsCustSuppVO;
import com.lgmma.salesPortal.app.model.StatisticsOrderVO;
import com.lgmma.salesPortal.app.service.StatisticsService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.Months;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;


@Controller
@RequestMapping("/statistics") 
public class StatisticsController {

	@Autowired
	private CommonController commonController;
	
	@Autowired
	private StatisticsService statisticsService;

	@RequestMapping(value = "/statOrder")
	public ModelAndView statOrderInfo(ModelAndView mav) throws Exception {
		mav.setViewName("statistics/statOrder");
		mav.addObject("yearItem", commonController.getYearsDDLB().get("items"));
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("monthsItem"	, new ArrayList< Months >(Arrays.asList(Months.values())));
		mav.addObject("currentMm", DateUtil.getToday().substring(4, 6));
		mav.addObject("defaultYyyyMm",DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6));
		return mav;
	}
	
	@RequestMapping(value = "/getStatOrderList.json")
	public Map getStatOrderList(@RequestBody(required = false) StatisticsOrderVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", statisticsService.getStatOrderList(param));
	}
	
	@RequestMapping(value = "/getStatOrderView.json")
	public Map getStatOrderView(@RequestBody(required = false) StatisticsOrderVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", statisticsService.getStatOrderView(param));
	}
	
	@RequestMapping(value = "/statCustSupp")
	public ModelAndView statCustSuppInfo(ModelAndView mav) throws Exception {
		mav.setViewName("statistics/statCustSupp");
		mav.addObject("yearItem", commonController.getYearsDDLB().get("items"));
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("monthsItem"	, new ArrayList< Months >(Arrays.asList(Months.values())));
		mav.addObject("currentMm", DateUtil.getToday().substring(4, 6));
		mav.addObject("defaultYyyyMm",DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6));
		return mav;
	}
	
	@RequestMapping(value = "/getStatCustSuppList.json")
	public Map getStatCustSuppList(@RequestBody(required = false) StatisticsCustSuppVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", statisticsService.getStatCustSuppList(param));
	}
	
	@RequestMapping(value = "/getStatCustSuppView.json")
	public Map getStatCustSuppView(@RequestBody(required = false) StatisticsCustSuppVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", statisticsService.getStatCustSuppView(param));
	}
	
	@RequestMapping(value = "/getStatCustSuppDetail.json")
	public Map getStatCustSuppDetail(@RequestBody(required = false) StatisticsCustSuppVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", statisticsService.getStatCustSuppDetail(param));
	}
	
}
