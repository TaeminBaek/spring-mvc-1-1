package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DiagnosisDao;
import com.lgmma.salesPortal.app.model.SalePriceCloseVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;

@Repository
public class DiagnosisDaoImpl implements DiagnosisDao {

    private static final String MAPPER_NAMESPACE = "DIAGNOSIS_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public List<SalePriceMasterVO> getSalePriceChangeRateList(SalePriceCloseVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSalePriceChangeRateList", param);
	}
}
