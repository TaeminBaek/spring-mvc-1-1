package com.lgmma.salesPortal.common.props;

public enum Times {
/**
 * 시간으로서
*/
	 TIME_00("00","00")
	,TIME_01("01","01")
	,TIME_02("02","02")
	,TIME_03("03","03")
	,TIME_04("04","04")
	,TIME_05("05","05")
	,TIME_06("06","06")
	,TIME_07("07","07")
	,TIME_08("08","08")
	,TIME_09("09","09")
	,TIME_10("10","10")
	,TIME_11("11","11")
	,TIME_12("12","12")
	,TIME_13("13","13")
	,TIME_14("14","14")
	,TIME_15("15","15")
	,TIME_16("16","16")
	,TIME_17("17","17")
	,TIME_18("18","18")
	,TIME_19("19","19")
	,TIME_20("20","20")
	,TIME_21("21","21")
	,TIME_22("22","22")
	,TIME_23("23","23")
	;
	String code = null;
	String name = null;

	private Times(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
