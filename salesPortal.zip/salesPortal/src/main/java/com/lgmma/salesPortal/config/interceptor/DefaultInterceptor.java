package com.lgmma.salesPortal.config.interceptor;

import com.lgmma.salesPortal.common.model.MenuItem;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;
import org.springframework.http.HttpMethod;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DefaultInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		String menuId = "";
		MenuItem allowMenus = ((CustomAuthenticationToken) SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getAllowedMenuMap().get("01");
		MenuItem selectedMenu = null;
		if(allowMenus != null) {
			setAllMenuSelectedFalse(allowMenus);
		
			//파트너사 비번 변경일이 2개월 초과시 정보변경 페이지로
			if(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().isPwdExpired()) {
				menuId = "cefdd122ede24ef7b6c759919de47617";
				response.sendRedirect("/partner/webAccountInfo");
			}
			if(request.getParameter("menuId") != null && !request.getParameter("menuId").equals("")) {
				menuId = request.getParameter("menuId");
			}
			if(!menuId.equals("")) {
				//menuId 에 해당하는 메뉴를 찾는다.
				selectedMenu = findMenuItemById(menuId, allowMenus);
				//자신과 상위 메뉴를 모두 selected = true 로...
				setParentMenuSelectedTrue(selectedMenu, allowMenus);
			} else {	//getRequestURI 로 찾는다.
				selectedMenu = findMenuItemByURI(request.getRequestURI(), allowMenus);
				//자신과 상위 메뉴를 모두 selected = true 로...
				setParentMenuSelectedTrue(selectedMenu, allowMenus);
			}
		}
		if(selectedMenu != null && !selectedMenu.isVisible())
			throw new NoHandlerFoundException(HttpMethod.GET.toString(), request.getRequestURI(), null);

		return super.preHandle(request, response, handler);
	}

	private MenuItem findMenuItemByURI(String requestURI, MenuItem parent) {
		if(parent.getUrl().equals(requestURI))
			return parent;
		if(parent.getMenuItems() != null && parent.getMenuItems().size() > 0) {
			for(int i = 0 ; i < parent.getMenuItems().size() ; i ++) {
				MenuItem child = findMenuItemByURI(requestURI, parent.getMenuItems().get(i));
				if(child != null)
					return child;
			}
		}
		return null;
	}

	private void setParentMenuSelectedTrue(MenuItem child, MenuItem allowMenus) {
		if(child != null) {
			child.setSelected(true);
			if(!child.getParentId().equals("")) {
				MenuItem parentMenu = findMenuItemById(child.getParentId(), allowMenus);
				setParentMenuSelectedTrue(parentMenu, allowMenus);
			}
		}
	}

	private MenuItem findMenuItemById(String menuId, MenuItem parent) {
		if(parent.getId().equals(menuId))
			return parent;
		if(parent.getMenuItems() != null && parent.getMenuItems().size() > 0) {
			for(int i = 0 ; i < parent.getMenuItems().size() ; i ++) {
				MenuItem child = findMenuItemById(menuId, parent.getMenuItems().get(i));
				if(child != null)
					return child;
			}
		}
		return null;
	}

	private void setAllMenuSelectedFalse(MenuItem allowedMenus) {
		if(allowedMenus != null) {
			allowedMenus.setSelected(false);
			if(allowedMenus.getMenuItems() != null && allowedMenus.getMenuItems().size() > 0) {
				for(int i = 0 ; i < allowedMenus.getMenuItems().size() ; i ++) {
					setAllMenuSelectedFalse(allowedMenus.getMenuItems().get(i));
				}
			}
		}
	}

}
