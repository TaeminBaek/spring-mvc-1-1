package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.HighValueGoalVO;


public interface HighValueGoalDao {
	

	int getHighValueGoalCount(HighValueGoalVO param);
	
	List<HighValueGoalVO> getHighValueGoalList(HighValueGoalVO param);

	List<CommonCodeVO> getHighValueCodeList(HighValueGoalVO param);

	void createHighValueGoal(HighValueGoalVO param);
	
	void updateHighValueGoal(HighValueGoalVO param);

	void deleteHighValueGoal(HighValueGoalVO param);

	List<CommonCodeVO> getYearHighValueCodeList(HighValueGoalVO param);
	
	List<HighValueGoalVO> getHighValueCGResultList(HighValueGoalVO param);

}
