package com.lgmma.salesPortal.app.service.impl;

import com.github.underscore.lodash.$;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.lgmma.salesPortal.app.dao.CommonApprDao;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.service.CommonApprMgmtService;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.DissDailyActService;
import com.lgmma.salesPortal.app.service.DissImpDevService;
import com.lgmma.salesPortal.app.service.DissOneTeamService;
import com.lgmma.salesPortal.app.service.DissPublicService;
import com.lgmma.salesPortal.app.service.DissSampleOrderService;
import com.lgmma.salesPortal.app.service.DissSpecInService;
import com.lgmma.salesPortal.app.service.GPortalListTypeRestService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.props.ApplState;
import com.lgmma.salesPortal.common.props.ApprGPortalApprovalReturnType;
import com.lgmma.salesPortal.common.props.ApprLineType;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.URLDecoder;
import java.util.List;
import java.util.Map;


@Service
public class GPortalListTypeRestServiceImpl implements GPortalListTypeRestService {
	private final String GP_FORM_ID = "SALESPORTALLIST";// 그룹포탈 목록연동방식 문서양식코드(운영,개발 동일)
	private static Logger logger = LoggerFactory.getLogger(GPortalListTypeRestServiceImpl.class);
	private final String targetUri = "/dissAppr/dissMyApprInfo";

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private DissCommonApprMgmtService dissCommonApprMgmtService;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	@Autowired
	private CommonApprMgmtService commonApprMgmtService;
	
	@Autowired
	private DissSpecInService dissSpecInService;
	
	@Autowired
	private DissSampleOrderService dissSampleOrderService;
	
	@Autowired
	private DissPublicService dissPublicService;
	
	@Autowired
	private DissImpDevService dissImpDevService;
	
	@Autowired
	private DissOneTeamService dissOneTeamService;
	
	@Autowired
	private DissDailyActService dissDailyActService;
	
	@Autowired
	private CommonApprDao commonApprDao;
	
	

	/**
	 * 
	 * */
	private HttpEntity<?> apiClientHttpEntity(String appType, MultiValueMap<String, Object> param) {
		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.set("Content-Type", "application/" + appType);
		return new HttpEntity<Object>(param, requestHeaders);
	}

	/**
	 * 
	 * */
	private String sendRequest(MultiValueMap<String, Object> param, String method) {
		String baseUrl = messageSourceAccessor.getMessage("gportal.list.approval.rest.url", "");
		HttpEntity<?> requestEntity = apiClientHttpEntity("x-www-form-urlencoded", param);
		URI uri = URI.create(baseUrl + method);
		return sendApprInfoTask(uri, requestEntity);
	}

	/**
	 *  
	 * */
	private String sendApprInfoTask(URI uri, HttpEntity<?> requestEntity) {
		ResponseEntity<String> responseEntity = restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class);
		Map<String, List<String>> resultMap = (Map<String, List<String>>) $.fromXml(responseEntity.getBody());
		List<String> resultList = (List<String>) resultMap.get("value");
		return resultList.get(0); // "S" 이면 성공
	}

	/**
	 * 최초결재요청 GPortal 전송 작업
	 */
	@Override
	public void requestApproval(ApprVO paramApprVO) {
		String ssoUrl = messageSourceAccessor.getMessage("salesportal.sso.target.url", "");
		String encodedTargetUri = targetUri;
		// targetUri 는 인코딩 해서
		try {
			encodedTargetUri = URLEncoder.encode(targetUri, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			logger.error(e.getMessage());
		}
		
		if(paramApprVO.getApprId() != null && !"".equals(paramApprVO.getApprId()))
			encodedTargetUri += "?apprId=" + paramApprVO.getApprId();

		// 결재정보가 이미 저장 되어있어야함
		ApprVO apprVO = dissCommonApprMgmtService.getApprInfoAll(paramApprVO);
		String templeteFormContent = paramApprVO.getTempleteFormContent();

		MultiValueMap<String, Object> param = new LinkedMultiValueMap<String, Object>();
		param.add("FORM_ID", GP_FORM_ID);
		param.add("APPR_TITLE", "[D.I.S.S_"+apprVO.getApprTypeName()+"]"+apprVO.getApprTitle());
		param.add("USER_ID", apprVO.getSawnId());   // 사번이 아닌 사원ID 전송
		param.add("APPKEY_01", apprVO.getApprId());
		param.add("APPKEY_02", "");
		param.add("APPKEY_03", "");
		param.add("APPKEY_04", "");
		param.add("APPKEY_05", "");
		param.add("FORM_EDITOR_DATA", (templeteFormContent != null && !"".equals(templeteFormContent)) ? templeteFormContent : apprVO.getFormCont());
		param.add("APPR_SECURITY_TYPE", "0");
		param.add("IS_EMERGENCY", "0");
		param.add("APP_URL", ssoUrl+"?targetUrl="+ encodedTargetUri);
		param.add("APPR_DOC_NO", "");

		// 참조자 리스트 셋팅
		setApprRLineList(param,apprVO);

		// 다음결재자 리스트 생성
		List<ApprLineVO> apprLineVOList = dissCommonApprMgmtService.getApprovalNextLineList(apprVO);
		setSendApprLineList(param,apprLineVOList);

		// G PORTAL 품의 목록 전송
		if("S".equals(sendRequest(param, "/report"))) {
			// 상신 후 sms 보내기
			dissCommonApprMgmtService.sendDissApprSms(apprVO);
		}else {
			// 실패시 문서생성오류 및 롤백
			throw new ServiceException("fail.common.appr.sendRequest");
		}
	}

	/**
	 * 결재 GPortal 전송 작업
	 */
	@Override
	public void sendApproval(ApprVO paramApprVO, String apprEmpId) {

		List<ApprLineVO> nextApprLineVOList = dissCommonApprMgmtService.getApprovalNextLineList(paramApprVO);

		ApprLineVO actApprLineVO = new ApprLineVO();
		for(ApprLineVO apprLineVO:paramApprVO.getApprLineList()){
			if(apprLineVO.getApprEmpId().equals(apprEmpId)){
				actApprLineVO = apprLineVO;
				break;
			}
		}
		actApprLineVO = (ApprLineVO) StringUtil.nullToEmptyString(actApprLineVO);

		MultiValueMap<String, Object> param = new LinkedMultiValueMap<String, Object>();
		param.add("FORM_ID", GP_FORM_ID);
		param.add("USER_ID", actApprLineVO.getApprEmpSawnId()); // 사번이 아닌 사원ID전송
		param.add("APPKEY_01", actApprLineVO.getApprId());
		param.add("APPKEY_02", "");
		param.add("APPKEY_03", "");
		param.add("APPKEY_04", "");
		param.add("APPKEY_05", "");
		param.add("APPR_STATUS", ApplState.getApplState(actApprLineVO.getApplStat()).getListTypeGpApplStat()); // 결재자 결재에 따른 상태 맵핑
		param.add("APPR_MESSAGE", actApprLineVO.getApprLineComment());

		// 다음 결재자가 존재하면 다음 결재라인 맵핑
		if(!nextApprLineVOList.isEmpty() && !ApprState.getApprState(paramApprVO.getApprStat()).isRejectYn()) {
			setSendApprLineList(param, nextApprLineVOList);
		}

		// G PORTAL 품의 목록 전송
		if("S".equals(sendRequest(param, "/approval"))) {
			// 전송 성공 후 sms 보내기
			dissCommonApprMgmtService.sendDissApprSms(paramApprVO);
		}else {
			// 실패시 문서생성오류 및 롤백
			throw new ServiceException("","GPortal 결재 연동시 오류가 발생 하였습니다.");
		}
	}
	
	@Override
	public void deleteApproval(String apprId, String apprEmpId, String apprMessage) {
		MultiValueMap<String, Object> param = new LinkedMultiValueMap<String, Object>();
		param.add("FORM_ID", GP_FORM_ID);
		param.add("USER_ID", apprEmpId);
		param.add("APPKEY_01", apprId);
		param.add("APPKEY_02", "");
		param.add("APPKEY_03", "");
		param.add("APPKEY_04", "");
		param.add("APPKEY_05", "");
		param.add("APPR_MESSAGE", apprMessage);
		
		// G PORTAL 품의 목록 전송
		if("S".equals(sendRequest(param, "/delete"))) {
			logger.debug("D.I.S.S. 결재문서 결재회수(apprId : " + apprId + ")");
		}else {
			// 실패시 문서회수오류 및 롤백
			throw new ServiceException("","GPortal 결재 회수시 오류가 발생 하였습니다.");
		}
	}

	/**
	 * 참조자 리스트 셋팅
	 * */
	private void setApprRLineList(MultiValueMap<String, Object> param, ApprVO apprVO) {
		if(!(apprVO.getApprLineRList() == null || apprVO.getApprLineRList().isEmpty())){
			String read_user = "";
			// 사번이 아닌 사원ID로 리스트 만들기
			Function<ApprLineVO,String> apprLineVoFilterEmpSawnId = new Function<ApprLineVO,String>(){
				public String apply(ApprLineVO apprLineVO) {
					return apprLineVO.getApprEmpSawnId();
				}
			};
			List<ApprLineVO> apprLineVOList	= apprVO.getApprLineRList();
			List<String> read_user_list			= Lists.transform(apprLineVOList, apprLineVoFilterEmpSawnId);
			read_user = Joiner.on(";").join(read_user_list);
			param.add("REFERENCE_ID", read_user);
		}
	}

	/**
	 * GPortal용 다음결재자 결재라인 생성
	 * */
	private void setSendApprLineList(MultiValueMap<String, Object> param, List<ApprLineVO> apprLineVOList) {
		String next_appr_type		= "";
		String next_approver		= "";
		String next_approver_type	= "";

		// 사번이 아닌 사원ID로 리스트 만들기
		Function<ApprLineVO,String> apprLineVoFilterEmpSawnId = new Function<ApprLineVO,String>(){
			public String apply(ApprLineVO apprLineVO) {
				return apprLineVO.getApprEmpSawnId();
			}
		};
		// 결재타입 리스트 만들기
		Function<ApprLineVO,String> apprLineVoFilterApprLineType = new Function<ApprLineVO,String>(){
			public String apply(ApprLineVO apprLineVO) {
				return ApprLineType.getApprLineType(apprLineVO.getApprLineType()).getGpLineType();
			}
		};
		// 결재자유형 리스트 만들기
		Function<ApprLineVO,String> apprLineVoFilterGPApprLineType = new Function<ApprLineVO,String>(){
			public String apply(ApprLineVO apprLineVO) {
				return "0";
			}
		};

		// 만들어진 리스트로 최종 문자열 만들기
		List<String> next_appr_type_list		= Lists.transform(apprLineVOList, apprLineVoFilterApprLineType);
		List<String> next_approver_list			= Lists.transform(apprLineVOList, apprLineVoFilterEmpSawnId);
		List<String> next_approver_type_list	= Lists.transform(apprLineVOList, apprLineVoFilterGPApprLineType);
		next_appr_type		= Joiner.on(";").join(next_appr_type_list);
		next_approver		= Joiner.on(";").join(next_approver_list);
		next_approver_type	= Joiner.on(";").join(next_approver_type_list);

		// 최종 문자열을 담기
		param.add("NEXT_APPR_TYPE"		, next_appr_type); 		// 결재 타입(0:결재, 1:합의(필수), 2:합의(선택)) - 구분자 ;
		param.add("NEXT_APPROVER"		, next_approver);		// 결재자	- 구분자 ;
		param.add("NEXT_APPROVER_TYPE"	, next_approver_type);	// 결재자 유형(사용자:0, 그룹:1) - 구분자 ;
	}
	
	/**
	 * GPortal 결재처리
	 *
	 */
	@Override
	public String approvalAtcionFromGPortal(String apprId, String apprEmpId, String apprStatus, String apprEmpComment) throws UnsupportedEncodingException {
		logger.debug("#########################approvalAtcionFromGPortal Start");
		ApprVO		          apprVO     = new ApprVO();
		DissApprCommonParamVO paramVO    = new DissApprCommonParamVO();
		DissStepVO            dissStepVO = new DissStepVO();
		String                applStat   = "";
		String                apprType   = "";

		// 인코딩 되어서 넘어온 코멘트를 디코드 하여 저장(두번 인코딩 되어있어서 두번 디코딩한다.)
		String decodedApprEmpComment =  URLDecoder.decode(StringUtil.nullConvert(apprEmpComment),"UTF-8");
		decodedApprEmpComment = URLDecoder.decode(decodedApprEmpComment,"UTF-8");

		// apprStatus 셋업 (GPortal에서 넘어오는 값 => 2:승인, 3:반려, 4:합의)
		if(apprStatus.equals("2"))		applStat = ApprGPortalApprovalReturnType.GP_APPL_APPROVE.getApplState();
		else if(apprStatus.equals("3"))	applStat = ApprGPortalApprovalReturnType.GP_APPL_REJECT.getApplState();
		else if(apprStatus.equals("4"))	applStat = ApprGPortalApprovalReturnType.GP_APPL_AGREE.getApplState();

		// apprVO 셋업
		apprVO.setApprId(apprId);
		apprVO.setUpdtIdxx(apprEmpId);
		apprVO = commonApprMgmtService.getAppr(apprVO);

		//스펙IN은 GateReview 스텝으로 설정한다.
		if(apprVO.getApprType().equals("201"))
			dissStepVO.setStepCd("100200");

		apprType = apprVO.getApprType();

		// dissStepVO 셋업
		dissStepVO.setApprId(apprId);

		// 원팀활동내역, Daily활동은 step테이블에 존재하지 않는다.
		if(!apprType.equals(ApprType.APPR_TYPE_DISS_ONETEAM_REPORT.getCode()) && !apprType.equals(ApprType.APPR_TYPE_DISS_DAILY_ACT.getCode()))
			dissStepVO = commonApprDao.getGportalDissStepByApprId(dissStepVO);

		dissStepVO.setApplStat(applStat);
		dissStepVO.setApprLineComment(decodedApprEmpComment);
		dissStepVO.setApprType(apprVO.getApprType());
		dissStepVO.setApprLineType(applStat);
		dissStepVO.setUpdtIdxx(apprEmpId);

		//paramVO 셋업
		paramVO.setApprId(apprId);
		paramVO.setApprEmpId(apprEmpId);
		paramVO.setApplStat(applStat);
		paramVO.setApprLineComment(decodedApprEmpComment);
		paramVO.setApprType(apprVO.getApprType());
		paramVO.setRegiIdxx(apprVO.getRegiIdxx());
		paramVO.setUpdtIdxx(apprEmpId);
		paramVO.setTaskId(dissStepVO.getTaskId());
		paramVO.setStepId(dissStepVO.getStepId());
		paramVO.setApprLineType(applStat);

		//값이 null로 들어가면 후속처리시 조건에 안걸리기 때문에 공백으로 처리해줌.
		paramVO.setRelApprId(apprVO.getRelApprId() == null ? "" : apprVO.getRelApprId());

		//품의서별 분기
		try {
			if(apprType.equals(ApprType.APPR_TYPE_DISS_SPECIN_REG.getCode())) {
				//SPEC-IN등록
				dissSpecInService.applActDissSpecInAfterGateReview(paramVO);

				if(!paramVO.getRelApprId().equals("")) {
					dissSampleOrderService.saveDissSampleOrderAfterApproval(paramVO);
				}
			}
			if(apprType.equals(ApprType.APPR_TYPE_DISS_SPECIN_COLOR_PRESCRIPTION.getCode())) {
				//컬러개발결과등록
				dissSpecInService.applColorPrescription(paramVO);
			}
			if(apprType.equals(ApprType.APPR_TYPE_DISS_SAMPLE_NOTICE.getCode())) {
				//견본일정공지
				dissPublicService.applSampleOrderNotice(paramVO);
			}
			if(apprType.equals(ApprType.APPR_TYPE_DISS_SAMPLE.getCode())) {
				//DISS견본품의
				if(!paramVO.getRelApprId().equals("")) {
					dissStepVO.setApprId(apprVO.getRelApprId());
					dissStepVO.setStepCd("100200");
					dissStepVO = commonApprDao.getGportalDissStepByApprId(dissStepVO);

					paramVO.setApprId(apprVO.getRelApprId());
					paramVO.setApprType(ApprType.APPR_TYPE_DISS_SPECIN_REG.getCode());
					paramVO.setStepId(dissStepVO.getStepId());
					paramVO.setRelApprId(apprId);
					dissSpecInService.applActDissSpecInAfterGateReview(paramVO);
					dissSampleOrderService.saveDissSampleOrderAfterApproval(paramVO);
//					return "Spec-In 등록품의서를 먼저 승인하세요.";
				} else {
					dissSampleOrderService.applDissSampleOrder(paramVO);
					dissSampleOrderService.saveDissSampleOrderAfterApproval(paramVO);
				}
			}
			if(apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode()) || apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_SAMPLEEVAL.getCode()) ||
			   apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_PLAN.getCode())      || apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_RESULT.getCode())  ||
			   apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_COMPOUND.getCode())     || apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PROPOSAL.getCode())     ) {
				//소재개발결과등록 || TS견본검증결과보고 || F/Test계획 || F/Test결과 || Comp'd처방 || 개선개발제안서
				dissImpDevService.saveDissImpDevApprovalAction(dissStepVO);
			}
			if(apprType.equals(ApprType.APPR_TYPE_DISS_CUSTTEST.getCode())  || apprType.equals(ApprType.APPR_TYPE_DISS_COMPLETE.getCode()) ||
			   apprType.equals(ApprType.APPR_TYPE_DISS_MASSTRANS.getCode()) || apprType.equals(ApprType.APPR_TYPE_DISS_COMPGRADE.getCode())   ) {
				//고객TEST결과등록 || 과제완료결과등록 || 	양산이관보고 || 	규격제정/개정
				dissPublicService.saveDissPublicApprovalAction(dissStepVO);		
			}
			if(apprType.equals(ApprType.APPR_TYPE_DISS_SPECIN_COLOR_PROPOSAL.getCode())) {
				//컬러개발제안서
				dissSpecInService.applColorProposal(paramVO);
			}
			if(apprType.equals(ApprType.APPR_TYPE_DISS_ONETEAM_REG.getCode()) || apprType.equals(ApprType.APPR_TYPE_DISS_ONETEAM_COMPLETE.getCode())) {
				//원팀과제등록 || 원팀과제완료
				dissOneTeamService.saveDissOneTeamApprovalAction(paramVO);
			}
			if(apprType.equals(ApprType.APPR_TYPE_DISS_ONETEAM_REPORT.getCode())) {
				//원팀과제활동내역
				dissOneTeamService.saveDissOneTeamMinutesApprovalAction(paramVO);
			}
			if(apprType.equals(ApprType.APPR_TYPE_DISS_DAILY_ACT.getCode())) {
				//DAILY활동
				dissDailyActService.saveDissDailyActApprovalAction(paramVO);
			}
			return "S";

		}catch(ServiceException e) {
			if(e.getErrorMsg() != null)	logger.error(e.getErrorMsg());
			return "시스템담당자에게 문의하세요.";
		}catch(Exception e) {
			if(e.getMessage() != null)	logger.error(e.getMessage());
			return  "시스템담당자에게 문의하세요.";
		}
	}

}
