package com.lgmma.salesPortal.app.service;
import java.util.List;

import com.lgmma.salesPortal.app.model.ItemDeliveryVO;
import com.lgmma.salesPortal.app.model.OrderHeadVO;
import com.lgmma.salesPortal.app.model.OrderItemVO;
import com.lgmma.salesPortal.app.model.OrderListVO;
import com.lgmma.salesPortal.app.model.OrderSaleNameListVO;



public interface OrderService {

	int getOrderCount(OrderListVO param);
	
	List<OrderListVO> getOrderList(OrderListVO param) throws Exception;
	
	int getSapOrderCount(OrderListVO param) throws Exception;
	
	List<OrderListVO> getSapOrderList(OrderListVO param) throws Exception;
	
	int getTotOrderCount(OrderListVO param) throws Exception;
	
	List<OrderListVO> getTotOrderList(OrderListVO param) throws Exception;
	
	OrderHeadVO getOrderDetail(OrderHeadVO param);
	
	List<OrderItemVO> getOrderItemList(OrderItemVO param) throws Exception;

	int getSaleNameCount(OrderSaleNameListVO param);
	
	List<OrderSaleNameListVO> getSaleNameList(OrderSaleNameListVO param) throws Exception;
	
	void createOrder(OrderHeadVO param) throws Exception;
	
	void updateOrderItem(List<OrderItemVO> param) throws Exception;
	
	void deleteOrderItem(List<OrderItemVO> param) throws Exception;
	
	int getOrderConfirmCount(OrderListVO param);
	
	List<OrderListVO> getOrderConfirmList(OrderListVO param) throws Exception;
	
	OrderHeadVO getOrderConfirmDetail(OrderHeadVO param);
	
	List<OrderItemVO> getOrderConfirmItemList(OrderItemVO param) throws Exception;

	List<ItemDeliveryVO> getOrderDeliveryInfo(int eordHdid);

	OrderHeadVO getOrderDetailForUpdate(OrderHeadVO param);

	void updateOrder(OrderHeadVO param);

	void deleteOrder(OrderHeadVO param);

	OrderHeadVO getOrderHead(OrderHeadVO param);

	void confirmOrder(OrderHeadVO param);

	void rejectOrder(OrderHeadVO param);

	OrderHeadVO getOrderDetailForCopy(OrderHeadVO param);

	OrderHeadVO getConfirmedEaslesOrderDetail(String orderId);

	void updateEaslesOrder(OrderHeadVO param);

	void updateEaslesOrderComment(OrderHeadVO param);

	void deleteEaslesOrder(OrderHeadVO param);

	void updateEaslesOrderPriceMaster(OrderHeadVO param);
	
}
