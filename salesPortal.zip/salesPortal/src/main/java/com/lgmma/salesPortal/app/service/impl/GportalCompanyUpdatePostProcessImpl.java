package com.lgmma.salesPortal.app.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.CompOrganEditVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.model.NewCompOrganEditVO;
import com.lgmma.salesPortal.app.model.OrganVO;
import com.lgmma.salesPortal.app.model.SmsVO;
import com.lgmma.salesPortal.app.service.CompanyService;
import com.lgmma.salesPortal.app.service.GportalPostProcess;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.app.service.SmsService;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.util.StringUtil;

import freemarker.template.Configuration;

@Transactional
@Service
public class GportalCompanyUpdatePostProcessImpl implements GportalPostProcess {

	private static Logger logger = LoggerFactory.getLogger(GportalCompanyUpdatePostProcessImpl.class); 

	private final String REPORT_TEMPLATE_COMP_UPDATE = "REPORT_TEMPLATE_COMP_UPDATE";

	private final String FNC_SAP_CUSTOMER_CHANGE1 = "ZSDE01_CUSTOMER_CHANGE1";
	private final String FNC_SAP_CUSTOMER_CHANGE2 = "ZSDE01_CUSTOMER_CHANGE2";

	@Autowired
	private JcoConnector jcoConnector;
	
	@Autowired
	private SmsService smsService;
	
	@Autowired
	private CompanyDao companyDao;
	
	@Autowired
	private SapSearchService sapSearchService;
	
	@Autowired
	private CommonFileServiceImpl commonFileService;
	
	@Autowired
	private CompanyService companyService;
	
    @Autowired
    @Qualifier(value="reportFreemarkerConfiguration")
    private Configuration reportTemplateConfiguration;
    
	@Autowired
    private PlatformTransactionManager transactionManager;

    @Override
	public void saveApprId(ApprVO apprVO) {
		CompOrganEditVO param = new CompOrganEditVO();
		param.setCompEditId(apprVO.getKeyId());
		param.setApprId(apprVO.getApprId());
		companyDao.updateCompOrgEditApprId(param);
	}

	@Override
	public void deleteApprId(ApprVO apprVO) {
		CompOrganEditVO param = new CompOrganEditVO();
		param.setApprId(apprVO.getApprId());
		companyDao.updateCompOrgEditIdToNull(param);
	}

	@Override
	public void completeProcess(ApprVO apprVO) {
		DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
		transactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//transaction start
		TransactionStatus tx = transactionManager.getTransaction(transactionDefinition);

		NewCompOrganEditVO param = new NewCompOrganEditVO();
		param.setApprId(apprVO.getApprId());
		NewCompOrganEditVO vo = (NewCompOrganEditVO) StringUtil.nullToEmptyString(companyDao.getCompOrganEditDetail(param));
		
		if(vo != null) {
			// 타 영업조직에 erp 전송상태가 S 인 건으로 존재하는지 확인 
            // erp에 전송할려는 영업조직은 신규이나 이미 다른 영업조직이 있는 경우는 gubun=B
            // ex) mma를 생성하고자 하는경우 pmma로 생성된 거래선이 있는경우는 영업조직 추가이다.
			//기존 소스에 서도 실제 사용하지는 않음
/*
			Map<String, String> paramMap = new HashMap<String, String>();
			paramMap.put("vkorg", vo.getVkorg());
			paramMap.put("compCode", vo.getCompCode());
			paramMap.put("erpxSend", "S");
			int existCount = companyDao.countOtherOrganExists(paramMap);
*/
			CompanyVO companyVO = new CompanyVO();
			companyVO.setCompCode(vo.getCompCode());
			companyVO.setVkorg(vo.getVkorg());
			//null point exception 방지
			companyVO = (CompanyVO) StringUtil.nullToEmptyString(companyDao.getCompanyDetail(companyVO));
			try {
				Map<String, Object> outputParams = new HashMap<String, Object>();
				JcoTableParam tableParam = new JcoTableParam();

				Map<String, Object> company = new HashMap<String, Object>();
	            company.put("PARTN_NUMB", vo.getKunnr());              // 고객번호
	            company.put("SALES_ORG", vo.getVkorg());               // 영업조직
	            company.put("NAME1", vo.getName1());                   // 이름 1
	            company.put("SORT1", companyVO.getSortl());                   // 검색어 1
//	            company.put("SORT2", vo.getCompCode());                   // 검색어 2 회사코드를 32바이트로 변경하면서 더이상 넘기지 않음 
	            company.put("STREET", vo.getStrasFull());                  // 번지 및 상세주소
                company.put("POSTL_CODE", companyVO.getPostlz());              // 우편번호
	            company.put("CITY", "");                 // 도시
	            company.put("COUNTRY", vo.getLand1());           // 국가키
	            company.put("TRANSPZONE", vo.getLzone());        // 운송지역 또는 상품납품지역
	            company.put("TELEPHONE", vo.getTelf1Full());        // 첫번째 전화번호
	            company.put("FAX_NUMBER", vo.getTelfx());        // 팩스번호
	            company.put("SMTP_ADDR", "");            // 전자메일주소
	            company.put("LIFNR", "");                      // 공급업체 또는 채권자 계정번호
	            company.put("STCD1", vo.getCeoBirthday());                      // 대표자주민번호                       
	            company.put("STCD2", StringUtil.remove(vo.getStcd2(), '-'));      //사업자등록번호                           
	            company.put("STCEG", vo.getStcd2()); //stcd2           // 사업자등록번호
	            company.put("J_1KFREPRE", vo.getJ1kfrepre());         // 대표자 이름
	            company.put("CEOFNM", vo.getCeoFullNm().equals("") ? "." : vo.getCeoFullNm());         // 대표자이름1 (1이 있고 2가 없으면 전송오류 발생 . 으로 강제 replace)                          
	            company.put("CEOENM", vo.getCeoEtcNm().equals("") ? "." : vo.getCeoEtcNm());         // 대표자이름 2                          
	            company.put("J_1KFTBUS", companyVO.getJ1kftbus());           // 사업유형
	            company.put("J_1KFTIND", companyVO.getJ1kftind());           // 산업유형
				tableParam.put("T_LIST", company);


				Map<String, Object> ethics = new HashMap<String, Object>();
				ethics.put("BUKRS", "1000");      //회사 코드                                
				ethics.put("ZVSEQ", "");      //매핑키                                   
				ethics.put("KUNNR", vo.getKunnr());      //고객 번호 1                              
				ethics.put("ZVNAME", vo.getName1());      //이름 1                                   
				ethics.put("INDTYP", vo.getJ1kftind());      //산업유형                                 
				ethics.put("ZITEM", vo.getTradeItem());      //주요거래품목                             
				ethics.put("ZSPNY", vo.getReportYn());      //신고대상 거래선 여부                     
				ethics.put("ZSPTY", vo.getReportType());      //신고대상 유형                            
				ethics.put("ZSTOCK", vo.getStockYn());      //상장여부                                 
				ethics.put("STCD2", StringUtil.remove(vo.getStcd2(), '-'));      //사업자등록번호                           
				ethics.put("REPRES", vo.getJ1kfrepre());      //대표자 이름                              
				ethics.put("ZDPSCN", vo.getCeoBirthday());      //대표자 주민번호                          
				ethics.put("ZDPLG", vo.getRelationLg());      //대표자와 LG의 관계                       
                tableParam.put("T_ETHICS", ethics);

				jcoConnector.executeFunction(FNC_SAP_CUSTOMER_CHANGE1, null, outputParams, tableParam);			
					
	            // 전송성공:0보다 큰 정수, 실패:-1, 사업자등록번호 중복:0
	            String eReturn = outputParams.get("E_RETURN").toString().trim();
				int rtnCode = Integer.parseInt((outputParams.get("E_SUBRC")).toString());

				if(rtnCode > 0) {	//성공
					logger.debug(eReturn);

					OrganVO organVo= new OrganVO();
					organVo.setCompCode(vo.getCompCode());
					organVo.setVkorg(vo.getVkorg());
					//null point exception 방지
					organVo = (OrganVO) StringUtil.nullToEmptyString(companyDao.getCompanyEtc(organVo));
					companyVO.setOrganVO(organVo);

					JcoTableParam organTableParam = new JcoTableParam();
					Map<String, Object> organ = new HashMap<String, Object>();
		            organ = new HashMap();
		            organ.put("PARTN_NUMB", vo.getKunnr());   // 고객번호
		            organ.put("SALES_ORG", vo.getVkorg());         // 판매조직
		            organ.put("SALES_DIST", vo.getBzirk());              // 판매구역
		            organ.put("SALES_OFF", organVo.getVkbur());               // 사업장
		            organ.put("SALES_GRP", organVo.getVkgrp());               // 영업그룹
		            organ.put("CURRENCY", organVo.getWaers());                // 통화
		            organ.put("CUST_GRP1", vo.getKvgr1());               // 고객그룹 1
		            organ.put("CUST_GRP2", vo.getKvgr2());               // 고객그룹 2
		            organ.put("CUST_GRP3", vo.getKvgr3());               // 고객그룹 3
		            organ.put("CUST_GRP4", vo.getKvgr4());               // 고객그룹 4
		            organ.put("CUST_GRP5", vo.getKvgr5());               // 고객그룹 5
		            organ.put("INCOTERMS1", "");                 // 인도조건 (파트 1)
		            organ.put("INCOTERMS2", "");                 // 인도조건 (파트 2)
		            organ.put("PMNTTRMS", "");                   // 지급조건키
		            organ.put("ACCNT_ASGN", organVo.getKtgrd());              // 해당고객의 계정지정그룹
		            organ.put("GRADE", companyVO.getCompGrade());
		            organ.put("ZTERM", vo.getMonyCond());                   //지급조건
		            organTableParam.put("T_LIST", organ);					

					jcoConnector.executeFunction(FNC_SAP_CUSTOMER_CHANGE2, null, outputParams, organTableParam);			
		            // 전송성공:0보다 큰 정수, 실패:-1, 사업자등록번호 중복:0
		            eReturn = outputParams.get("E_RETURN").toString().trim();
					rtnCode = Integer.parseInt((outputParams.get("E_SUBRC")).toString());
					if(rtnCode > 0) {	//성공
						logger.debug(eReturn);
			            vo.setErpxSend("S");
						companyService.mergeCompanyVO(vo, companyVO);
						companyDao.updateCompany(companyVO);
						companyVO.getOrganVO().setErpxSday("sysdate");	//updateOrgan 쿼리에서 erp 전송정보를 업데이트 하기위함
						companyVO.getOrganVO().setErpxSendTeam("N");
						companyVO.getOrganVO().setErpxSend("S");
						companyVO.getOrganVO().setErpxSman(apprVO.getRegiIdxx());
						companyDao.updateOrgan(companyVO.getOrganVO());
					} else {	//실패 rfc2
						logger.error(eReturn);
						vo.setErpxSend("F");
					}
				} else {	//실패 rfc1
					logger.error(eReturn);
					vo.setErpxSend("F");
				}
				companyDao.updateCompEditErpStat(vo);

		        if(rtnCode > 0) {	//성공
					//기안자 sms 전송
					SmsVO smsVo = new SmsVO();
					smsVo.setTrPhone(apprVO.getSawnHpxxNum1());
					smsVo.setTrMsg(vo.getName1() + " [" + vo.getKunnr() + "]의 수정된 정보가 ERP에 전송되었습니다.");
					smsVo.setTrEtc1(vo.getApprId());
					smsService.sendSms(smsVo);
		        } else {	//실패
					SmsVO smsVo = new SmsVO();
					smsVo.setTrPhone(apprVO.getSawnHpxxNum1());
					smsVo.setTrMsg(vo.getName1() + " [" + vo.getKunnr() + "]의 정보 수정건의 ERP 전송에 실패하었습니다. 실패사유 - " + eReturn);
					smsVo.setTrEtc1(vo.getApprId());
					smsService.sendSms(smsVo);
		        }
			} catch (Exception e) {
				//메일이나 SMS 전송시 오류가 발생해도 커밋은 해야한다.
		        transactionManager.commit(tx);
				throw e;
			}
		}
	}

	@Override
	public void rejectProcess(ApprVO apprVO) {
		CompOrganEditVO param = new CompOrganEditVO();
		param.setApprId(apprVO.getApprId());
	}

	@Override
	public String getApprContent(String compEditId) {
		NewCompOrganEditVO param = new NewCompOrganEditVO();
		param.setCompEditId(compEditId);
		NewCompOrganEditVO vo = (NewCompOrganEditVO) StringUtil.nullToEmptyString(companyDao.getCompOrganEditDetail(param));
		CompanyVO companyVo = new CompanyVO();
		companyVo.setCompCode(vo.getCompCode());
		companyVo.setVkorg(vo.getVkorg());
		companyVo = (CompanyVO) StringUtil.nullToEmptyString(companyDao.getCompanyDetail(companyVo));
		companyVo.setOrganVO((OrganVO) StringUtil.nullToEmptyString(companyVo.getOrganVO()));
		companyVo.setLimitAmount(StringUtil.setComma(companyVo.getLimitAmount()));

		OrganVO organVo= new OrganVO();
		organVo.setCompCode(vo.getCompCode());
		organVo.setVkorg(vo.getVkorg());
		//null point exception 방지
		organVo = (OrganVO) StringUtil.nullToEmptyString(companyDao.getCompanyEtc(organVo));
		
		vo.setKvgr1Text(sapSearchService.getMasterCodeName("10", vo.getKvgr1()));
		vo.setKvgr2Text(sapSearchService.getMasterCodeName("11", vo.getKvgr2()));
		vo.setKvgr3Text(sapSearchService.getMasterCodeName("12", vo.getKvgr3()));
		vo.setKvgr4Text(sapSearchService.getMasterCodeName("13", vo.getKvgr4()));
		vo.setKvgr5Text(sapSearchService.getMasterCodeName("14", vo.getKvgr5()));
		vo.setMonyCondText(sapSearchService.getMasterCodeName("28", vo.getMonyCond()));
		vo.setBzirk(sapSearchService.getMasterCodeName("25", vo.getBzirk()));

		organVo.setWaers(sapSearchService.getMasterCodeName("26", organVo.getWaers()));
		organVo.setKtgrd(sapSearchService.getMasterCodeName("08", organVo.getKtgrd()));
		organVo.setVkbur(sapSearchService.getMasterCodeName("02", organVo.getVkbur()));
		organVo.setVkgrp(sapSearchService.getMasterCodeName("03", organVo.getVkgrp()));
		organVo.setBzirk(sapSearchService.getMasterCodeName("25", organVo.getBzirk()));

		FileVO fileVO = new FileVO();
		fileVO.setFileId(vo.getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("editVo", vo);
		map.put("companyVo", companyVo);
		map.put("organVo", organVo);
		map.put("fileVoList", fileVoList);
    	try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate(REPORT_TEMPLATE_COMP_UPDATE + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
    	return "";
	}
}
