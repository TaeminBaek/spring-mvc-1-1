package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissScheduleDao;
import com.lgmma.salesPortal.app.model.DissScheduleVO;

@Repository
public class DissScheduleDaoImpl implements DissScheduleDao{
	
	private static final String MAPPER_NAMESPACE = "DISS_SCHEDULE_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public void createDissSchedule(DissScheduleVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissSchedule", param);
	}

	@Override
	public List<DissScheduleVO> getDissScheduleList(DissScheduleVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissScheduleList", param);
	}

	@Override
	public List<DissScheduleVO> getDissScheduleHisList(DissScheduleVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissScheduleHisList", param);
	}

	@Override
	public void mergeDissSchedule(DissScheduleVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeDissSchedule", param);
	}

	@Override
	public void deleteDissScheduleAll(DissScheduleVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissScheduleAll", param);
	}
	
	@Override
	public void createDissScheduleHis(DissScheduleVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissScheduleHis", param);
	}
	
	@Override
	public void mergeDissScheduleHis(DissScheduleVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeDissScheduleHis", param);
	}
	
	@Override
	public void deleteDissScheduleHisAll(DissScheduleVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissScheduleHisAll", param);
	}
	
	@Override
	public void updateDissScheduleCompYmd(DissScheduleVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissScheduleCompYmd", param);
	}
	
	@Override
	public void updateDissScheduleHisCompYmd(DissScheduleVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissScheduleHisCompYmd", param);
	}
	
	@Override
	public void updateDissScheduleCompGoalYmd(DissScheduleVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissScheduleCompGoalYmd", param);
	}
	
	@Override
	public DissScheduleVO getDissScheduleDetail(DissScheduleVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissScheduleDetail", param);
	}
	
	@Override
	public List<DissScheduleVO> getDissScheduleStepRsltList(DissScheduleVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissScheduleStepRsltList", param);
	}
	
	@Override
	public void deleteDissSchedule(DissScheduleVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissSchedule", param);
	}
	
	@Override
	public void deleteDissScheduleHis(DissScheduleVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissScheduleHis", param);
	}
	
	@Override
	public void createDissScheduleHisBySelect(DissScheduleVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissScheduleHisBySelect", param);
	}

	@Override
	public String chkSalesTeam(DissScheduleVO param){
		return sqlSession.selectOne(MAPPER_NAMESPACE + "chkSalesTeam", param);
	}

	@Override
	public String chkTSTeam(DissScheduleVO param){
		return sqlSession.selectOne(MAPPER_NAMESPACE + "chkTSTeam", param);
	}

	@Override
	public void updateDissSchedule(DissScheduleVO param){
		sqlSession.update(MAPPER_NAMESPACE + "updateDissSchedule",param);
	}
}
