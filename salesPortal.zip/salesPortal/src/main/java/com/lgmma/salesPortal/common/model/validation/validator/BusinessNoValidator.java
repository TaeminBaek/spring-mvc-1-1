package com.lgmma.salesPortal.common.model.validation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.lgmma.salesPortal.common.model.validation.BusinessNo;

public class BusinessNoValidator implements ConstraintValidator<BusinessNo, String> {

	private boolean required;
	@Override
	public void initialize(BusinessNo constraintAnnotation) {
		required = constraintAnnotation.required();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if(!value.equals("") || required) {
			return checkBusinoValid(value);
		} else {
			return true;
		}
	}

	private boolean checkBusinoValid(String value) {
		String pattern = "\\d{3}-\\d{2}-\\d{5}";
		
		if(!value.matches(pattern)) {
			return false;
		}
		String compNumber = value.replaceAll("-", ""); 
		 
		int hap = 0; 
		int temp = 0; 
		int check[] = {1,3,7,1,3,7,1,3,5};  //사업자번호 유효성 체크 필요한 수 

		if(compNumber.length() != 10)    //사업자번호의 길이가 맞는지를 확인한다. 
		return false; 

		for(int i=0; i < 9; i++){ 
		if(compNumber.charAt(i) < '0' || compNumber.charAt(i) > '9')  //숫자가 아닌 값이 들어왔는지를 확인한다. 
				return false;  
			 
			hap = hap + (Character.getNumericValue(compNumber.charAt(i)) * check[temp]); //검증식 적용 
			temp++; 
		} 
			 
		hap += (Character.getNumericValue(compNumber.charAt(8))*5)/10; 

		if ((10 - (hap%10))%10 == Character.getNumericValue(compNumber.charAt(9))) //마지막 유효숫자와 검증식을 통한 값의 비교 
			return true; 
		else 
			return false; 
	}
}
