package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissTaskResultVO;

public interface DissTaskResultDao {
	
	DissTaskResultVO getDissTaskResultDetail(DissTaskResultVO param);
	
	void createDissTaskResult(DissTaskResultVO param);
	
	void updateDissTaskResult(DissTaskResultVO param);
	
	void deleteDissTaskResultAll(DissTaskResultVO param);
	
	List<DissTaskResultVO> getDissTaskResultSaleEmpList(DissTaskResultVO param);
}
