package com.lgmma.salesPortal.app.model;

public class CustBondOverdueInformationVO extends PagingParamVO {
	
	private String salesOrg;
	private String partnNameAg;
	private String partnNumbAg;
	private String gjahr;				
	private String cApprEmpId;	
	private String cApprEmpNm;
	
	private String vkorg;
	private String vtweg;
	private String kunnr;
	private String name1;
	private String ename;
	private String cdateWrb;
	private String cdateYenTot;
	private String cdateYenZa;
	private String cdateYenZb;
	private String cdateYenZc;
	private String cdatePer;
	private String cdate2beWrb;
	private String cdate2beTot;
	private String cdate2beZa;
	private String cdate2beZb;
	private String cdate2beZc;
	private String cdate2bePer;
	private String cdate3beWrb;
	private String cdate3beTot;
	private String cdate3beZa;
	private String cdate3beZb;
	private String cdate3beZc;
	private String cdate3bePer;
	private String cdate4beWrb;
	private String cdate4beTot;
	private String cdate4beZa;
	private String cdate4beZb;
	private String cdate4beZc;
	private String cdate4bePer;
	private String cdate5beWrb;
	private String cdate5beTot;
	private String cdate5beZa;
	private String cdate5beZb;
	private String cdate5beZc;
	private String cdate5bePer;
	private String cdate6beWrb;
	private String cdate6beTot;
	private String cdate6beZa;
	private String cdate6beZb;
	private String cdate6beZc;
	private String cdate6bePer;
	
	public String getSalesOrg() {
		return salesOrg;
	}
	
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	
	public String getPartnNameAg() {
		return partnNameAg;
	}
	
	public void setPartnNameAg(String partnNameAg) {
		this.partnNameAg = partnNameAg;
	}
	
	public String getPartnNumbAg() {
		return partnNumbAg;
	}
	
	public void setPartnNumbAg(String partnNumbAg) {
		this.partnNumbAg = partnNumbAg;
	}
	
	public String getGjahr() {
		return gjahr;
	}
	
	public void setGjahr(String gjahr) {
		this.gjahr = gjahr;
	}
	
	public String getcApprEmpId() {
		return cApprEmpId;
	}
	
	public void setcApprEmpId(String cApprEmpId) {
		this.cApprEmpId = cApprEmpId;
	}
	
	public String getcApprEmpNm() {
		return cApprEmpNm;
	}
	
	public void setcApprEmpNm(String cApprEmpNm) {
		this.cApprEmpNm = cApprEmpNm;
	}
	
	public String getVkorg() {
		return vkorg;
	}
	
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	
	public String getVtweg() {
		return vtweg;
	}
	
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	
	public String getKunnr() {
		return kunnr;
	}
	
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	
	public String getName1() {
		return name1;
	}
	
	public void setName1(String name1) {
		this.name1 = name1;
	}
	
	public String getEname() {
		return ename;
	}
	
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	public String getCdateWrb() {
		return cdateWrb;
	}
	
	public void setCdateWrb(String cdateWrb) {
		this.cdateWrb = cdateWrb;
	}
	
	public String getCdateYenTot() {
		return cdateYenTot;
	}
	
	public void setCdateYenTot(String cdateYenTot) {
		this.cdateYenTot = cdateYenTot;
	}
	
	public String getCdateYenZa() {
		return cdateYenZa;
	}
	
	public void setCdateYenZa(String cdateYenZa) {
		this.cdateYenZa = cdateYenZa;
	}
	
	public String getCdateYenZb() {
		return cdateYenZb;
	}
	
	public void setCdatevenZb(String cdatevenZb) {
		this.cdateYenZb = cdateYenZb;
	}
	
	public String getCdateYenZc() {
		return cdateYenZc;
	}
	
	public void setCdateYenZc(String cdateYenZc) {
		this.cdateYenZc = cdateYenZc;
	}
	
	public String getCdatePer() {
		return cdatePer;
	}
	
	public void setCdatePer(String cdatePer) {
		this.cdatePer = cdatePer;
	}
	
	public String getCdate2beWrb() {
		return cdate2beWrb;
	}
	
	public void setCdate2beWrb(String cdate2beWrb) {
		this.cdate2beWrb = cdate2beWrb;
	}
	
	public String getCdate2beTot() {
		return cdate2beTot;
	}
	
	public void setCdate2beTot(String cdate2beTot) {
		this.cdate2beTot = cdate2beTot;
	}
	
	public String getCdate2beZa() {
		return cdate2beZa;
	}
	
	public void setCdate2beZa(String cdate2beZa) {
		this.cdate2beZa = cdate2beZa;
	}
	
	public String getCdate2beZb() {
		return cdate2beZb;
	}
	
	public void setCdate2beZb(String cdate2beZb) {
		this.cdate2beZb = cdate2beZb;
	}
	
	public String getCdate2beZc() {
		return cdate2beZc;
	}
	
	public void setCdate2beZc(String cdate2beZc) {
		this.cdate2beZc = cdate2beZc;
	}
	
	public String getCdate2bePer() {
		return cdate2bePer;
	}
	
	public void setCdate2bePer(String cdate2bePer) {
		this.cdate2bePer = cdate2bePer;
	}
	
	public String getCdate3beWrb() {
		return cdate3beWrb;
	}
	
	public void setCdate3beWrb(String cdate3beWrb) {
		this.cdate3beWrb = cdate3beWrb;
	
	}
	
	public String getCdate3beTot() {
		return cdate3beTot;
	}
	
	public void setCdate3beTot(String cdate3beTot) {
		this.cdate3beTot = cdate3beTot;
	}
	
	public String getCdate3beZa() {
		return cdate3beZa;
	}
	
	public void setCdate3beZa(String cdate3beZa) {
		this.cdate3beZa = cdate3beZa;
	}
	
	public String getCdate3beZb() {
		return cdate3beZb;
	}
	
	public void setCdate3beZb(String cdate3beZb) {
		this.cdate3beZb = cdate3beZb;
	}
	
	public String getCdate3beZc() {
		return cdate3beZc;
	}
	
	public void setCdate3beZc(String cdate3beZc) {
		this.cdate3beZc = cdate3beZc;
	}
	
	public String getCdate3bePer() {
		return cdate3bePer;
	}
	
	public void setCdate3bePer(String cdate3bePer) {
		this.cdate3bePer = cdate3bePer;
	}
	
	public String getCdate4beWrb() {
		return cdate4beWrb;
	}
	
	public void setCdate4beWrb(String cdate4beWrb) {
		this.cdate4beWrb = cdate4beWrb;
	}
	
	public String getCdate4beTot() {
		return cdate4beTot;
	}
	
	public void setCdate4beTot(String cdate4beTot) {
		this.cdate4beTot = cdate4beTot;
	}
	
	public String getCdate4beZa() {
		return cdate4beZa;
	}
	
	public void setCdate4beZa(String cdate4beZa) {
		this.cdate4beZa = cdate4beZa;
	}
	
	public String getCdate4beZb() {
		return cdate4beZb;
	}
	
	public void setCdate4beZb(String cdate4beZb) {
		this.cdate4beZb = cdate4beZb;
	}
	
	public String getCdate4beZc() {
		return cdate4beZc;
	}
	
	public void setCdate4beZc(String cdate4beZc) {
		this.cdate4beZc = cdate4beZc;
	}
	
	public String getCdate4bePer() {
		return cdate4bePer;
	}
	
	public void setCdate4bePer(String cdate4bePer) {
		this.cdate4bePer = cdate4bePer;
	}
	
	public String getCdate5beWrb() {
		return cdate5beWrb;
	}
	
	public void setCdate5beWrb(String cdate5beWrb) {
		this.cdate5beWrb = cdate5beWrb;
	}
	
	public String getCdate5beTot() {
		return cdate5beTot;
	}
	
	public void setCdate5beTot(String cdate5beTot) {
		this.cdate5beTot = cdate5beTot;
	}
	
	public String getCdate5beZa() {
		return cdate5beZa;
	}
	
	public void setCdate5beZa(String cdate5beZa) {
		this.cdate5beZa = cdate5beZa;
	}
	
	public String getCdate5beZb() {
		return cdate5beZb;
	}
	
	public void setCdate5beZb(String cdate5beZb) {
		this.cdate5beZb = cdate5beZb;
	}
	
	public String getCdate5beZc() {
		return cdate5beZc;
	}
	
	public void setCdate5beZc(String cdate5beZc) {
		this.cdate5beZc = cdate5beZc;
	}
	
	public String getCdate5bePer() {
		return cdate5bePer;
	}
	
	public void setCdate5bePer(String cdate5bePer) {
		this.cdate5bePer = cdate5bePer;
	}
	
	public String getCdate6beWrb() {
		return cdate6beWrb;
	}
	
	public void setCdate6beWrb(String cdate6beWrb) {
		this.cdate6beWrb = cdate6beWrb;
	}
	
	public String getCdate6beTot() {
		return cdate6beTot;
	}
	
	public void setCdate6beTot(String cdate6beTot) {
		this.cdate6beTot = cdate6beTot;
	}
	
	public String getCdate6beZa() {
		return cdate6beZa;
	}
	
	public void setCdate6beZa(String cdate6beZa) {
		this.cdate6beZa = cdate6beZa;
	}
	
	public String getCdate6beZb() {
		return cdate6beZb;
	}
	
	public void setCdate6beZb(String cdate6beZb) {
		this.cdate6beZb = cdate6beZb;
	}
	
	public String getCdate6beZc() {
		return cdate6beZc;
	}
	
	public void setCdate6beZc(String cdate6beZc) {
		this.cdate6beZc = cdate6beZc;
	}
	
	public String getCdate6bePer() {
		return cdate6bePer;
	}
	
	public void setCdate6bePer(String cdate6bePer) {
		this.cdate6bePer = cdate6bePer;
	}
	

}
