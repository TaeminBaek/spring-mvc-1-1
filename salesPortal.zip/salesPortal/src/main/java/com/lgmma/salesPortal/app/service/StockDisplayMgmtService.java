package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.ProductStockVO;
import com.lgmma.salesPortal.app.model.ProductVO;

public interface StockDisplayMgmtService {

	int getStockDisplayCount(ProductVO param);

	List<ProductVO> getStockDisplayList(ProductVO param);

	void updateStockDisplay(List<ProductVO> paramList);

	void getProductsFromSap();

	int getProductInStockCount(ProductStockVO param);

	List<ProductStockVO> getProductInStockList(ProductStockVO param);

}
