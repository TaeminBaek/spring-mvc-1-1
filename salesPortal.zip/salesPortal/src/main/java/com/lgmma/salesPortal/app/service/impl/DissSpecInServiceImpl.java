package com.lgmma.salesPortal.app.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.lgmma.salesPortal.app.dao.CommonApprDao;
import com.lgmma.salesPortal.app.dao.CommonCodeDao;
import com.lgmma.salesPortal.app.dao.CommonDao;
import com.lgmma.salesPortal.app.dao.DissImpDevDao;
import com.lgmma.salesPortal.app.dao.DissSampleOrderDao;
import com.lgmma.salesPortal.app.dao.DissScheduleDao;
import com.lgmma.salesPortal.app.dao.DissSpecInDao;
import com.lgmma.salesPortal.app.dao.DissSpecInSaleGoalDao;
import com.lgmma.salesPortal.app.dao.DissStepDao;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissExcelDownloadVO;
import com.lgmma.salesPortal.app.model.DissSampleOrderItemVO;
import com.lgmma.salesPortal.app.model.DissSampleOrderMasterVO;
import com.lgmma.salesPortal.app.model.DissScheduleVO;
import com.lgmma.salesPortal.app.model.DissSpecInSaleGoalVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.service.CommonApprMgmtService;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.DissPublicService;
import com.lgmma.salesPortal.app.service.DissSampleOrderService;
import com.lgmma.salesPortal.app.service.DissSpecInService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.props.ApplState;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

import freemarker.template.Configuration;

@Service
public class DissSpecInServiceImpl implements DissSpecInService {

	private static Logger logger = LoggerFactory.getLogger(DissSpecInServiceImpl.class);
	
	private final String REPORT_TEMPLATE_DISS_SPECIN_GATE_REVIEW = "REPORT_TEMPLATE_DISS_SPECIN_GATE_REVIEW";
	private final String REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER_NOTICE = "REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER_NOTICE";

	@Autowired
	DissSpecInDao dissSpecInDao;

	@Autowired
	DissSpecInSaleGoalDao dissSpecInSaleGoalDao;

	@Autowired
	DissStepDao dissStepDao;

	@Autowired
	DissScheduleDao dissScheduleDao;

	@Autowired
	CommonCodeDao commonCodeDao;

	@Autowired
	DissCommonApprMgmtService dissCommonApprMgmtService;

	@Autowired
	CommonApprMgmtService commonApprMgmtService;

	@Autowired
	SapSearchService sapSearchService;

	@Autowired
	CommonApprDao commonApprDao;

	@Autowired
	DissPublicService dissPublicService;

	@Autowired
	DissSampleOrderDao dissSampleOrderDao;

	@Autowired
	DissSampleOrderService dissSampleOrderService;
	
	@Autowired
	private CommonFileService commonFileService;

	@Autowired
	CommonDao commonDao;

	@Autowired
	DissImpDevDao dissImpDevDao;

	@Autowired
	private MailingService mailingService;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;

	@Autowired
    @Qualifier(value="reportFreemarkerConfiguration")
    private Configuration reportTemplateConfiguration;
	
	/**
	 * SpecIn 리스트 조회
	 *
	 * @param param
	 * @return
	 */
	@Override
	public List<DissSpecInVO> getDissSpecInList(DissSpecInVO param) {
		return dissSpecInDao.getDissSpecInList(param);
	}

	/**
	 * SpecIn 리스트 카운트 조회
	 *
	 * @param param
	 * @return
	 */
	@Override
	public int getDissSpecInListCount(DissSpecInVO param) {
		return dissSpecInDao.getDissSpecInListCount(param);
	}

	/**
	 * 스펙인 상세 조회
	 *
	 * @param dissSpecInVOParam
	 * @return
	 */
	@Override
	public DissSpecInVO getDissSpecInInfo(DissSpecInVO dissSpecInVOParam) {
		DissSpecInVO dissSpecInVO = dissSpecInDao.getDissSpecInInfo(dissSpecInVOParam);
		dissSpecInVO.setNationNm(sapSearchService.getSapCommonCodeName("37", StringUtil.nullConvert(dissSpecInVO.getNationCd())));
		return dissSpecInVO;
	}

	/**
	 * 스펙인 상세 조회
	 *
	 * @param dissSpecInVOParam
	 * @return
	 */
	@Override
	public DissSpecInVO getDissSpecInInfoHis(DissSpecInVO dissSpecInVOParam) {
		DissSpecInVO dissSpecInVO = dissSpecInDao.getDissSpecInInfoHis(dissSpecInVOParam);
		dissSpecInVO.setNationNm(sapSearchService.getSapCommonCodeName("37", StringUtil.nullConvert(dissSpecInVO.getNationCd())));
		return dissSpecInVO;
	}

	/**
	 * 스펙인기본정보 전체조회
	 *
	 * @param dissSpecInVOParam
	 * @return
	 */
	@Override
	public DissSpecInVO getDissSpecInInfoAll(DissSpecInVO dissSpecInVOParam) {
		dissSpecInVOParam = (DissSpecInVO)StringUtil.nullToEmptyString(dissSpecInVOParam);

		// 현재 기준 정보
		DissSpecInVO dissSpecInVO = getDissSpecInInfo(dissSpecInVOParam);
		// 스케쥴 리스트 조회(현재 적용 최종 스케쥴)
		if("".equals(dissSpecInVOParam.getStepId())) {
			dissSpecInVO.setDissScheduleList(getDissScheduleList(dissSpecInVO.getTaskId()));
		} else {
			if (dissSpecInVOParam.getApprType().equals(ApprType.APPR_TYPE_DISS_SPECIN_REG.getCode())) {
				dissSpecInVO.setDissScheduleList(getDissScheduleListHis(dissSpecInVOParam.getStepId()));
			} else {
				dissSpecInVO.setDissScheduleList(getDissScheduleList(dissSpecInVO.getTaskId()));
			}
		}
		// 매출목표 리스트 조회(현재 적용 최종 매출 목표리스트)
		dissSpecInVO.setDissSpecInSaleGoalList(getDissSpecInSaleGoalList(dissSpecInVO.getTaskId()));
		// 매출목표 리스트 조회(최초 매출 목표리스트)
		dissSpecInVO.setDissSpecInSaleGoalListFirst(getDissSpecInSaleGoalListFist(dissSpecInVO.getTaskId()));

		return dissSpecInVO;
	}

	/**
	 * 스펙인기본정보 전체조회(His)
	 *
	 * @param dissSpecInVOParam
	 * @return
	 */
	@Override
	public DissSpecInVO getDissSpecInInfoHisAll(DissSpecInVO dissSpecInVOParam) {
		// 해당 스텝의 기준 정보
		DissSpecInVO dissSpecInVO = getDissSpecInInfoHis(dissSpecInVOParam);
		// 해당 스텝의 스케쥴 리스트 조회
		dissSpecInVO.setDissScheduleList(getDissScheduleListHis(dissSpecInVO.getStepId()));
		// 해당 스텝의 매출목표 리스트 조회
		dissSpecInVO.setDissSpecInSaleGoalList(getDissSpecInSaleGoalListHis(dissSpecInVO.getStepId()));
		return dissSpecInVO;
	}

	/**
	 * DISS 스케쥴 리스트 조회
	 *
	 * @param taskId
	 * @return
	 */
	@Override
	public List<DissScheduleVO> getDissScheduleList(String taskId) {
		DissScheduleVO dissScheduleVO = new DissScheduleVO();
		dissScheduleVO.setTaskId(taskId);

		return dissScheduleDao.getDissScheduleList(dissScheduleVO);
	}

	/**
	 * DISS 스케쥴 리스트 조회
	 *
	 * @param stepId
	 * @return
	 */
	@Override
	public List<DissScheduleVO> getDissScheduleListHis(String stepId) {
		DissScheduleVO dissScheduleVO = new DissScheduleVO();
		dissScheduleVO.setStepId(stepId);

		return dissScheduleDao.getDissScheduleHisList(dissScheduleVO);
	}

	/**
	 * DISS 매출목표 리스트 조회
	 *
	 * @param taskId
	 * @return
	 */
	@Override
	public List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalList(String taskId) {
		return dissSpecInSaleGoalDao.getDissSpecInSaleGoalList(taskId);
	}

	/**
	 * DISS 매출목표 리스트 조회(최초 등록 매출목표)
	 *
	 * @param taskId
	 * @return
	 */
	@Override
	public List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalListFist(String taskId) {
		return dissSpecInSaleGoalDao.getDissSpecInSaleGoalListFirst(taskId);
	}

	/**
	 * DISS 매출목표 리스트 조회(By Step)
	 *
	 * @param stepId
	 * @return
	 */
	@Override
	public List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalListHis(String stepId) {
		return dissSpecInSaleGoalDao.getDissSpecInSaleGoalListHis(stepId);
	}

	/**
	 * SpecIn 작성 저장
	 *
	 * @param param
	 */
	@Override
	public void saveDissSpecIn(DissSpecInVO param) {
		//logger.debug(param.toString());

		// TODO-HSH 추후 주석을 풀어 적용 해야함
		//TS 담당자가 TS팀 소속 인지 체크
		//dissPublicService.chkTSTeam(param.getTsEmpId());
		boolean insertYn = false;
		// 입력인지 수정인지 확인
		if ("".equals(param.getTaskId())) {       // insert
			insertYn = true;
			param.setTaskId(Util.getUUID());
			param.setApprId(Util.getUUID());
			dissSpecInDao.createDissSpecIn(param);

			// Step 입력(최초 등록시에는 1차수를 먼저 무조건 생성
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setStepId(Util.getUUID());
			dissStepVO.setTaskId(param.getTaskId());
			dissStepVO.setStepCd("300900");
			dissStepVO.setTaskType("SPECIN");
			dissStepVO.setDegreeNo(1);
			dissStepVO.setRegiIdxx(param.getRegiIdxx());
			dissStepVO.setUpdtIdxx(param.getUpdtIdxx());
			dissStepDao.createDissStep(dissStepVO);

			// 작성Step 입력
			dissStepVO.setStepId(Util.getUUID());
			dissStepVO.setStepCd("100100");
			dissStepVO.setApprId(param.getApprId());
			dissStepDao.createDissStep(dissStepVO);
			// 최초 입력시에는 품의서 ID 셋팅
			param.getApprVO().setApprId(param.getApprId());
			param.setDissStepVO(dissStepVO);
		} else {                                  // update
			dissSpecInDao.updateDissSpecIn(param);
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setStepId(param.getStepId());
			param.setDissStepVO(dissStepVO);
		}

		// 입력인지 수정인지(history 저장용)
		param.setInsertYn(insertYn);
		// 스케쥴등록
		deleteSpecInScheduleAndInsertAll(param);
		// 목표등록
		deleteSpecInSaleGoalAndInsertAll(param, 1);

		param.getApprVO().setRegiIdxx(param.getRegiIdxx());
		param.getApprVO().setUpdtIdxx(param.getUpdtIdxx());
	}

	/**
	 * SpecIn 삭제
	 *
	 * @param dissSpecInVO
	 */
	@Override
	public void deleteDissSpecIn(DissSpecInVO dissSpecInVO) {
		DissStepVO stepParam = new DissStepVO();
		stepParam.setTaskId(dissSpecInVO.getTaskId());
		List<DissStepVO> stepVOList = dissStepDao.getDissStepAll(stepParam);
		for (DissStepVO dissStepVO : stepVOList) {
			dissStepVO = (DissStepVO) StringUtil.nullToEmptyString(dissStepVO);
			// 하위 스케쥴 삭제
			DissScheduleVO scheduleParam = new DissScheduleVO();
			scheduleParam.setStepId(dissStepVO.getStepId());
			dissScheduleDao.deleteDissScheduleHisAll(scheduleParam);
			// 하위 목표 삭제
			DissSpecInSaleGoalVO saleGoalParam = new DissSpecInSaleGoalVO();
			saleGoalParam.setStepId(dissStepVO.getStepId());
			dissSpecInSaleGoalDao.deleteDissSpecInSaleGoalAllHis(saleGoalParam);
			// 하위 스펙인히스토리 삭제
			DissSpecInVO specInParam = new DissSpecInVO();
			specInParam.setStepId(dissStepVO.getStepId());
			dissSpecInDao.deleteDissSpecInHis(specInParam);
			// 품의서 삭제
			if (!"".equals(dissStepVO.getApprId())) {
				ApprVO apprParam = new ApprVO();
				apprParam.setApprId(dissStepVO.getApprId());
				ApprVO checkApprVO = commonApprDao.getAppr(apprParam);
				if (!checkApprVO.getRegiIdxx().equals(dissSpecInVO.getUpdtIdxx())) {
					throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
				}
				commonApprDao.deleteApprLineAll(apprParam);
				commonApprDao.deleteAppr(apprParam);
			}
		}
		// 스텝 모두 삭제
		dissStepDao.deleteDissStepAll(stepParam);
		// 원본 목표삭제
		DissSpecInSaleGoalVO saleGoalParam = new DissSpecInSaleGoalVO();
		saleGoalParam.setTaskId(dissSpecInVO.getTaskId());
		dissSpecInSaleGoalDao.deleteDissSpecInSaleGoalAll(saleGoalParam);
		// 원본 스케쥴 삭제
		DissScheduleVO scheduleParam = new DissScheduleVO();
		scheduleParam.setTaskId(dissSpecInVO.getTaskId());
		dissScheduleDao.deleteDissScheduleAll(scheduleParam);
		// 원본 스펙인 마스터 삭제
		dissSpecInDao.deleteDissSpecIn(dissSpecInVO);
	}

	/**
	 * SpecIn History 저장
	 *
	 * @param param
	 */
	@Override
	public void saveDissSpecInHis(DissSpecInVO param) {
		param.setStepId(param.getDissStepVO().getStepId());
		if (param.isInsertYn()) {
			dissSpecInDao.createDissSpecInHis(param);
		} else {
			dissSpecInDao.updateDissSpecInHis(param);
		}
	}

	/**
	 * SpecIn 임시 저장
	 *
	 * @param param
	 */
	@Override
	public void tempSaveDissSpecIn(DissSpecInVO param) {
		saveDissSpecIn(param);
		saveDissSpecInHis(param); // 스텝별 히스토리 저장
		deleteSpecInScheduleAndInsertAllHis(param);
		deleteSpecInSaleGoalAndInsertAllHis(param);
		// 품의서 공통 서비스 호출 처리(품의서는 임시저장)
		param.getApprVO().setUpdtIdxx(param.getUpdtIdxx());
		param.getApprVO().setRegiIdxx(param.getRegiIdxx());
		dissCommonApprMgmtService.saveDissCommonAppr(param.getApprVO(), ApprState.TEMP_SAVE.getCode(), false);
	}

	/**
	 * GateReview 요청 저장
	 *
	 * @param param
	 */
	@Override
	public void reqGateReview(DissSpecInVO param) {
		// GateReview 처리 시 결재 요청자(TS담당자)가 결재라인에 포함된 것으로 인식되는 현상 방지
		for(ApprLineVO apprLineVO : param.getApprVO().getApprLineRList())
			if(apprLineVO.getApprEmpId().equals(param.getTsEmpId()))
				throw new ServiceException("", "TS 담당자는 결재라인에 추가할 수 없습니다.");
		for(ApprLineVO apprLineVO : param.getApprVO().getApprLineIList())
			if(apprLineVO.getApprEmpId().equals(param.getTsEmpId()))
				throw new ServiceException("", "TS 담당자는 결재라인에 추가할 수 없습니다.");

		saveDissSpecIn(param);
		// 스텝별 히스토리 저장
		saveDissSpecInHis(param);
		deleteSpecInSaleGoalAndInsertAllHis(param);
		deleteSpecInScheduleAndInsertAllHis(param);

		// Gate Review 단계 스텝 생성
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(Util.getUUID());
		dissStepVO.setTaskId(param.getTaskId());
		dissStepVO.setStepCd("100200");
		dissStepVO.setTaskType("SPECIN");
		dissStepVO.setDegreeNo(1);
		dissStepVO.setApprId(param.getApprVO().getApprId());
		dissStepVO.setRegiIdxx(param.getRegiIdxx());
		dissStepVO.setUpdtIdxx(param.getUpdtIdxx());
		dissStepDao.createDissStep(dissStepVO);

		// gateReview 단계 History 입력
		param.setInsertYn(true);
		param.setDissStepVO(dissStepVO);
		param.setStepId(dissStepVO.getStepId());

		saveDissSpecInHis(param);
		deleteSpecInSaleGoalAndInsertAllHis(param);
		deleteSpecInScheduleAndInsertAllHis(param);

		// 품의서 공통 서비스 호출 처리(품의서는 임시저장)
		param.getApprVO().setUpdtIdxx(param.getUpdtIdxx());
		param.getApprVO().setRegiIdxx(param.getRegiIdxx());
		dissCommonApprMgmtService.saveDissCommonAppr(param.getApprVO(), ApprState.TEMP_SAVE.getCode(), false);
		// 게이트리뷰 요청 알람
		dissCommonApprMgmtService.sendDissGateReviewMessage(dissStepVO.getApprId(), dissStepVO.getTaskId());
	}

	/**
	 * SpecIn 매출목표 전체삭제후 입력
	 *
	 * @param param
	 * @param seq
	 */
	@Override
	public void deleteSpecInSaleGoalAndInsertAll(DissSpecInVO param, Integer seq) {
		DissSpecInSaleGoalVO paramSpecInSaleGoalVO = new DissSpecInSaleGoalVO();
		paramSpecInSaleGoalVO.setTaskId(param.getTaskId());
		paramSpecInSaleGoalVO.setSeq(seq);
		dissSpecInSaleGoalDao.deleteDissSpecInSaleGoalAll(paramSpecInSaleGoalVO);

		List<DissSpecInSaleGoalVO> dissSpecInSaleGoalVOList = param.getDissSpecInSaleGoalList();
		if (dissSpecInSaleGoalVOList != null) {
			for (DissSpecInSaleGoalVO dissSpecInSaleGoalVO : dissSpecInSaleGoalVOList) {
				dissSpecInSaleGoalVO.setTaskId(param.getTaskId());
				dissSpecInSaleGoalVO.setSalegoalId(Util.getUUID());
				dissSpecInSaleGoalVO.setSeq(seq);
				dissSpecInSaleGoalVO.setRegiIdxx(param.getRegiIdxx());
				dissSpecInSaleGoalVO.setUpdtIdxx(param.getUpdtIdxx());
				dissSpecInSaleGoalDao.createDissSpecInSaleGoal(dissSpecInSaleGoalVO);
			}
		}
	}

	/**
	 * SpecIn 매출목표 전체삭제후 입력(His)
	 *
	 * @param param
	 */
	@Override
	public void deleteSpecInSaleGoalAndInsertAllHis(DissSpecInVO param) {
		DissSpecInSaleGoalVO paramSpecInSaleGoalVO = new DissSpecInSaleGoalVO();
		paramSpecInSaleGoalVO.setStepId(param.getDissStepVO().getStepId());
		dissSpecInSaleGoalDao.deleteDissSpecInSaleGoalAllHis(paramSpecInSaleGoalVO);

		List<DissSpecInSaleGoalVO> dissSpecInSaleGoalVOList = param.getDissSpecInSaleGoalList();
		if (dissSpecInSaleGoalVOList != null) {
			for (DissSpecInSaleGoalVO dissSpecInSaleGoalVO : dissSpecInSaleGoalVOList) {
				dissSpecInSaleGoalVO.setStepId(param.getDissStepVO().getStepId());
				dissSpecInSaleGoalVO.setSalegoalId(Util.getUUID());
				dissSpecInSaleGoalVO.setSeq(0);
				dissSpecInSaleGoalVO.setRegiIdxx(param.getRegiIdxx());
				dissSpecInSaleGoalVO.setUpdtIdxx(param.getUpdtIdxx());
				dissSpecInSaleGoalDao.createDissSpecInSaleGoalHis(dissSpecInSaleGoalVO);
			}
		}
	}

	/**
	 * SpecIn 스케쥴 전체 삭제후 입력
	 *
	 * @param param
	 */
	@Override
	public void deleteSpecInScheduleAndInsertAll(DissSpecInVO param) {
		List<DissScheduleVO> dissScheduleVOList = param.getDissScheduleList();

		// schedule 전체 삭제
		DissScheduleVO dissScheduleVOParam = new DissScheduleVO();
		dissScheduleVOParam.setTaskId(param.getTaskId());
		dissScheduleDao.deleteDissScheduleAll(dissScheduleVOParam);

		// 스케쥴 입력
		if (dissScheduleVOList != null) {
			for (DissScheduleVO dissScheduleVO : dissScheduleVOList) {
				dissScheduleVO.setTaskId(param.getTaskId());
				dissScheduleVO.setTaskType("SPECIN");
				dissScheduleVO.setEmpId(param.getSalesEmpId());
				dissScheduleVO.setRegiIdxx(param.getRegiIdxx());
				dissScheduleVO.setUpdtIdxx(param.getUpdtIdxx());
				// 견본송부일정 인경우 영업팀소속 담당자인지 체크
				if ("400".equals(dissScheduleVO.getStepGroup())) {
					//dissPublicService.chkSalesTeam(dissScheduleVO.getEmpId());
				}
				dissScheduleDao.createDissSchedule(dissScheduleVO);
			}
		}
	}

	/**
	 * SpecIn 스케쥴 전체 삭제후 입력(His)
	 *
	 * @param param
	 */
	@Override
	public void deleteSpecInScheduleAndInsertAllHis(DissSpecInVO param) {
		List<DissScheduleVO> dissScheduleVOList = param.getDissScheduleList();

		// schedule 전체 삭제
		DissScheduleVO dissScheduleVOParam = new DissScheduleVO();
		dissScheduleVOParam.setStepId(param.getDissStepVO().getStepId());
		dissScheduleDao.deleteDissScheduleHisAll(dissScheduleVOParam);

		// 스케쥴 입력
		if (dissScheduleVOList != null) {
			for (DissScheduleVO dissScheduleVO : dissScheduleVOList) {
				dissScheduleVO.setStepId(dissScheduleVOParam.getStepId());
				dissScheduleVO.setTaskType("SPECIN");
				dissScheduleVO.setRegiIdxx(param.getRegiIdxx());
				dissScheduleVO.setUpdtIdxx(param.getUpdtIdxx());

				// 견본송부일정 인경우 영업팀소속 담당자인지 체크
				if ("400".equals(dissScheduleVO.getStepGroup())) {
					//dissPublicService.chkSalesTeam(dissScheduleVO.getEmpId());
				}

				dissScheduleDao.createDissScheduleHis(dissScheduleVO);
			}
		}
	}

	/**
	 * SpecIn GateReview 저장(히스토리를 보면서 작업한다.)
	 *
	 * @param dissSpecInVO
	 */
	@Override
	public void saveSpecInGateReview(DissSpecInVO dissSpecInVO) {
		dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInVO);

		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(dissSpecInVO.getStepId());
		dissSpecInVO.setDissStepVO(dissStepVO);

		// 과제 마스터 업데이트
		dissSpecInDao.updateDissSpecInGateReviewHis(dissSpecInVO);

		// 스케쥴 저장
		deleteSpecInScheduleAndInsertAllHis(dissSpecInVO);

		// 매출목표 저장
		deleteSpecInSaleGoalAndInsertAllHis(dissSpecInVO);
	}

	/**
	 * SpecIn GateReview 임시저장
	 *
	 * @param dissSpecInVO
	 */
	@Override
	public void tempSaveSpecInGateReview(DissSpecInVO dissSpecInVO) {
		// 과제 마스터,일정,매출목표 저장
		saveSpecInGateReview(dissSpecInVO);
		
		// xxxxxxxxxx test		
		dissSpecInVO.getApprVO().setTempleteFormContent(getApprFormCont(dissSpecInVO));
		
		// 품의서 공통 서비스 호출 처리(임시저장)
		dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
		dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());
		dissCommonApprMgmtService.saveDissCommonAppr(dissSpecInVO.getApprVO(), ApprState.TEMP_SAVE.getCode(), false);
	}

	/**
	 * SpecIn GateReview 확정
	 *
	 * @param dissSpecInVO
	 */
	@Override
	public void compSpecInGateReview(DissSpecInVO dissSpecInVO) {
		String relApprId = dissSpecInVO.getApprVO().getRelApprId();
		ApprVO apprVO = (ApprVO) StringUtil.nullToEmptyString(commonApprDao.getAppr(dissSpecInVO.getApprVO()));
		if(relApprId.equals("") && !apprVO.getRelApprId().equals(""))
			throw new ServiceException("", "영업담당자가 견본품의를 추가로 등록하였습니다.\n현재 창을 닫고 새로고침 후 다시 진행하시기 바랍니다.");

		// 과제 마스터,일정,매출목표 저장
		saveSpecInGateReview(dissSpecInVO);
		// 품의서 공통 서비스 호출 처리(게이트 리뷰 완료 되면 품의 상신 진행)
		dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
		dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());
		
		// 업무테이블 품의서 기초내용 작성 호출 20200520 kjy		
		dissSpecInVO.getApprVO().setTempleteFormContent(getApprFormCont(dissSpecInVO));
		
		dissCommonApprMgmtService.saveDissCommonAppr(dissSpecInVO.getApprVO(), ApprState.APPR_PROCEEDING.getCode(), false);		
		
		if(!relApprId.equals("")) {
			ApprVO relApprVO = new ApprVO();
			relApprVO.setApprId(relApprId);
			relApprVO = commonApprDao.getAppr(relApprVO);
			commonApprMgmtService.getApprContainLineList(relApprVO);
			
			// 업무테이블 품의서 기초내용 작성 호출 20200520 kjy			
			DissSampleOrderMasterVO dissSampleOrderMasterVO = new DissSampleOrderMasterVO();			
			dissSampleOrderMasterVO.setApprVO(relApprVO);	
			
			DissStepVO relStepVO = new DissStepVO();
			relStepVO.setApprId(dissSpecInVO.getApprVO().getRelApprId());
			
			dissSampleOrderMasterVO.setStepId(dissStepDao.getDissStepByApprId(relStepVO).getStepId());
			dissSampleOrderMasterVO.setTaskId(dissSpecInVO.getTaskId());
			relApprVO.setTempleteFormContent(dissSampleOrderService.getApprFormCont(dissSampleOrderMasterVO));
			
			dissCommonApprMgmtService.saveDissCommonAppr(relApprVO, ApprState.APPR_PROCEEDING.getCode(), true);
		}
	}
	
	/**
	 * DISS SPEC-IN 등록 품위 내용 
	 *
	 * @param DissSpecInVO	 
	 * @return
	 */
	@Override
	public String getApprFormCont(DissSpecInVO param) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();
		String templeteFormContent = null;
		
		// 스펙인 기본정보 조회
		DissSpecInVO dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(getDissSpecInInfoHisAll(param));							
		
		List<DissScheduleVO> dissScheduleList = new ArrayList<DissScheduleVO>();
		for(DissScheduleVO schedule : dissSpecInVO.getDissScheduleList()) {			
			dissScheduleList.add((DissScheduleVO)StringUtil.nullToEmptyString(schedule));					
		}
		
		List<DissSpecInSaleGoalVO> dissSaleGoalList = new ArrayList<DissSpecInSaleGoalVO>();		
		for(DissSpecInSaleGoalVO saleGoal : dissSpecInVO.getDissSpecInSaleGoalList()) {
			dissSaleGoalList.add((DissSpecInSaleGoalVO)StringUtil.nullToEmptyString(saleGoal));					
		}
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getApprVO().getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);		
		
		//logger.debug("param.getApprVO.getRelApprId = " + param.getApprVO().getRelApprId()); 
		
		dissSpecInVO.setRelApprId(param.getApprVO().getRelApprId());		
				
		map.put("dissSpecInVO", dissSpecInVO);		
		map.put("dissScheduleList", dissScheduleList);		
		map.put("dissSaleGoalList", dissSaleGoalList);
		map.put("fileVoList", fileVoList);
		
		// 견본품의 내용 조회 
		if(!param.getApprVO().getRelApprId().equals("")) {
			
			ApprVO relApprVO = new ApprVO();
			relApprVO.setApprId(param.getApprVO().getRelApprId());
			relApprVO = commonApprDao.getAppr(relApprVO);			
			
			DissSampleOrderMasterVO dissSampleOrderMasterVO = new DissSampleOrderMasterVO();			
			dissSampleOrderMasterVO.setApprVO(relApprVO);			
			
			DissStepVO relStepVO = new DissStepVO();
			relStepVO.setApprId(param.getApprVO().getRelApprId());
			
			dissSampleOrderMasterVO.setStepId(dissStepDao.getDissStepByApprId(relStepVO).getStepId());			
			
			DissSampleOrderMasterVO dissSampleOrderVO = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(dissSampleOrderService.searchSampleOrderInfo(dissSampleOrderMasterVO));
						
			List<DissSampleOrderItemVO> dissSampleOrderList = new ArrayList<DissSampleOrderItemVO>();
			for(DissSampleOrderItemVO sampleOrder : dissSampleOrderVO.getDissSampleOrderItemList()) {			
				dissSampleOrderList.add((DissSampleOrderItemVO)StringUtil.nullToEmptyString(sampleOrder));
			}			
			
			
			templeteFormContent = relApprVO.getFormCont();			
						
			map.put("dissSampleOrderVO"  , dissSampleOrderVO);		
			map.put("dissSampleOrderList", dissSampleOrderList);
			map.put("templeteFormContent", templeteFormContent);			
		}		
		
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate(REPORT_TEMPLATE_DISS_SPECIN_GATE_REVIEW + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}

	@Override
	public void cancelSpecInGateReview(DissSpecInVO dissSpecInVO) {
		if(!"100200".equals(dissSpecInDao.getDissSpecInInfoHis(dissSpecInVO).getStepCd())) {
			throw new ServiceException("", "GateReview 취소를 진행할 수 있는 상태가 아닙니다.");
		}

		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(dissSpecInVO.getStepId());
		dissStepDao.deleteDissStep(dissStepVO);

		ApprVO relApprVO = new ApprVO();
		relApprVO.setApprId(dissSpecInVO.getApprVO().getApprId());
		relApprVO = commonApprDao.getAppr(relApprVO);

		if(!dissSpecInVO.getApprVO().getRelApprId().equals("")) {
			dissStepVO.setApprId(dissSpecInVO.getApprVO().getRelApprId());
			dissStepVO = dissStepDao.getDissStepByApprId(dissStepVO);

			DissSampleOrderMasterVO dissSampleOrderMasterVO = new DissSampleOrderMasterVO();
			dissSampleOrderMasterVO.setOrderId(dissStepVO.getOrderId());
			dissSampleOrderMasterVO.setApprVO(new ApprVO());
			dissSampleOrderMasterVO.getApprVO().setApprId(dissSpecInVO.getApprVO().getRelApprId());
			// 견본품의 삭제
			dissCommonApprMgmtService.deleteDissAppr(dissSampleOrderMasterVO.getApprVO());
			// 견본오더마스터 삭제
			dissSampleOrderDao.deleteDissSampleOrderMaster(dissSampleOrderMasterVO.getOrderId());
			// 견본오더아이템 삭제
			dissSampleOrderDao.deleteDissSampleOrderItemAll(dissSampleOrderMasterVO.getOrderId());

			dissStepDao.deleteDissStep(dissStepVO);
			// 이전스텝 최종 복구
			dissStepDao.updateStepLastYnYByStepCd(dissStepVO);

			relApprVO.setRelApprId("");
			commonApprDao.updateRelApprId(relApprVO);
		}

		dissCommonApprMgmtService.sendDissGateReviewCancelMessage(dissSpecInVO.getApprVO().getApprId(), dissSpecInVO.getTaskId());
	}

	/**
	 * SpecIn GateReview TS담당자 변경(이관)
	 *
	 * @param dissSpecInVO
	 */
	@Override
	public void changeTsEmpGateReview(DissSpecInVO dissSpecInVO) {
		// TODO-HSH 추후 주석을 풀어 적용 해야함
		//TS담당자가 TS 팀 소속인지 체크
		//dissPublicService.chkTSTeam(param.getTsEmpId());
		dissSpecInDao.changeTsEmpGateReviewHis(dissSpecInVO);
		dissSpecInDao.changeTsEmpGateReview(dissSpecInVO);
		
		if(dissSpecInVO.getTsEmpId().equals(""))
			return;

		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(dissSpecInVO.getStepId());
		dissStepVO = dissStepDao.getDissStep(dissStepVO);
		// 게이트리뷰 요청 알람
		dissCommonApprMgmtService.sendDissGateReviewMessage(dissStepVO.getApprId(), dissStepVO.getTaskId());
	}
	
	/**
	 * 스펙인 게이트리뷰 Spec-In 등급 변경
	 *
	 * @param dissSpecInVO
	 */
	@Override
	public void changeSpecInDevLevel(DissSpecInVO dissSpecInVO) {
		dissSpecInDao.changeSpecInDevLevelHis(dissSpecInVO);
		dissSpecInDao.changeSpecInDevLevel(dissSpecInVO);
	}


	/**
	 * SpecIn 결재액션 처리
	 *
	 * @param dissApprCommonParamVO
	 */
	@Override
	@Transactional
	public void applActDissSpecInAfterGateReview(DissApprCommonParamVO dissApprCommonParamVO) {
		// 결재 액션 파라미터 셋팅
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(dissApprCommonParamVO.getApprId());                     // 품의서ID
		apprLineVO.setApprEmpId(dissApprCommonParamVO.getApprEmpId());              // 결재자사번
		apprLineVO.setApprLineComment(dissApprCommonParamVO.getApprLineComment());  // 결재자의견
		apprLineVO.setApplStat(dissApprCommonParamVO.getApplStat());                 // 결재자 결재결과
		apprLineVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());

		// 마지막 결재자 결재 완료면 후처리 작업
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(dissApprCommonParamVO.getApprId());
		if (dissCommonApprMgmtService.checkListApplActYn(apprVO, dissApprCommonParamVO.getApprEmpId())
				&& ApplState.APPL_APPROVE.getCode().equals(dissApprCommonParamVO.getApplStat())
		) {
			DissSpecInVO dissSpecInVOParam = new DissSpecInVO();
			dissSpecInVOParam.setStepId(dissApprCommonParamVO.getStepId());
			dissSpecInVOParam.setTaskId(dissApprCommonParamVO.getTaskId());

			DissSpecInVO dissSpecInVOHis = getDissSpecInInfoHisAll(dissSpecInVOParam);

			// SpecIn 히스토리 내역으로 원본테이블 업데이트
			dissSpecInVOHis.setTaskId(dissSpecInVOParam.getTaskId());
			dissSpecInVOHis.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());
			dissSpecInDao.updateDissSpecIn(dissSpecInVOHis);

			// SpecIn 매출목표 히스토리 내역으로 원본테이블 교체
			DissSpecInSaleGoalVO dissSpecInSaleGoalVO = new DissSpecInSaleGoalVO();
			dissSpecInSaleGoalVO.setTaskId(dissSpecInVOHis.getTaskId());
			dissSpecInSaleGoalDao.deleteDissSpecInSaleGoalAll(dissSpecInSaleGoalVO);
			for (DissSpecInSaleGoalVO tmpDissSpecInSaleGoalVO : dissSpecInVOHis.getDissSpecInSaleGoalList()) {
				tmpDissSpecInSaleGoalVO.setTaskId(dissSpecInVOHis.getTaskId());
				dissSpecInSaleGoalDao.createDissSpecInSaleGoal(tmpDissSpecInSaleGoalVO);
			}

			// SpecIn 스케쥴 히스토리 내역으로 원본테이블 교체
			DissScheduleVO dissScheduleVO = new DissScheduleVO();
			dissScheduleVO.setTaskId(dissSpecInVOHis.getTaskId());
			dissScheduleDao.deleteDissScheduleAll(dissScheduleVO);
			for (DissScheduleVO tmpDissScheduleVO : dissSpecInVOHis.getDissScheduleList()) {
				tmpDissScheduleVO.setTaskId(dissSpecInVOHis.getTaskId());
				dissScheduleDao.createDissSchedule(tmpDissScheduleVO);
			}
		}

		// DISS 공통 품의서 결재 호출
		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);


		if(!dissApprCommonParamVO.getRelApprId().equals("")) {
			ApprVO relApprVO = new ApprVO();
			relApprVO.setApprId(dissApprCommonParamVO.getRelApprId());
			relApprVO = commonApprDao.getAppr(relApprVO);

			DissStepVO stepVO = new DissStepVO();
			stepVO.setApprId(dissApprCommonParamVO.getRelApprId());
			stepVO = dissStepDao.getDissStepByApprId(stepVO);

			DissApprCommonParamVO dissRelApprCommonParamVO = new DissApprCommonParamVO();
			dissRelApprCommonParamVO.setApprId(relApprVO.getApprId());
			dissRelApprCommonParamVO.setApprType(relApprVO.getApprType());
			dissRelApprCommonParamVO.setApprLineComment(dissApprCommonParamVO.getApprLineComment());
			dissRelApprCommonParamVO.setApplStat(dissApprCommonParamVO.getApplStat());
			dissRelApprCommonParamVO.setTaskId(dissApprCommonParamVO.getTaskId());
			dissRelApprCommonParamVO.setStepId(stepVO.getStepId());
			dissRelApprCommonParamVO.setApprEmpId(dissApprCommonParamVO.getUpdtIdxx());
			dissRelApprCommonParamVO.setRegiIdxx(dissApprCommonParamVO.getRegiIdxx());
			dissRelApprCommonParamVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());
			dissSampleOrderService.applDissSampleOrder(dissRelApprCommonParamVO);

			// 반려되거나 GateReview의 다음 결재자가 없으면 relApprId 삭제
			if(ApplState.getApplState(apprLineVO.getApplStat()).isRejectYn() || dissCommonApprMgmtService.getApprovalNextLineList(apprVO).isEmpty()) {
				apprVO.setRelApprId("");
				relApprVO.setRelApprId("");
				commonApprDao.updateRelApprId(apprVO);
				commonApprDao.updateRelApprId(relApprVO);
			}
		}
	}

	/**
	 * 스펙인 과제 반려건 재작성
	 * -- 게이트리뷰단계에서 품의서가 반려된 경우 사용
	 *    - 신규로 스펙인 등록 단계 및 품의서는 임시저장 상태로 생성한다.
	 *
	 * @param param
	 */
	@Override
	public void dissSpecInRewrite(DissSpecInVO param){
		DissSpecInVO dissSpecInVO = getDissSpecInInfoAll(param);
		if(!param.getUpdtIdxx().equals(dissSpecInVO.getRegiIdxx())){
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
		}

		List<ApprLineVO> apprLineAList = param.getApprVO().getApprLineAList();
		List<ApprLineVO> apprLineCList = param.getApprVO().getApprLineCList();
		List<ApprLineVO> apprLineRList = param.getApprVO().getApprLineRList();
		List<ApprLineVO> apprLineIList = param.getApprVO().getApprLineIList();
		boolean chk = true;

		for(int i = 0; i < apprLineAList.size() && chk; i++) {
			if(param.getUpdtIdxx().equals(apprLineAList.get(i).getApprEmpId())) {
				apprLineAList.remove(i);
				if(apprLineAList.size() == 0)	param.getApprVO().setLineAYn("N");
				chk = false;
			}
		}
		for(int i = 0; i < apprLineCList.size() && chk; i++) {
			if(param.getUpdtIdxx().equals(apprLineCList.get(i).getApprEmpId())) {
				apprLineCList.remove(i);
				if(apprLineCList.size() == 0)	param.getApprVO().setLineCYn("N");
				chk = false;
			}
		}
		for(int i = 0; i < apprLineRList.size() && chk; i++) {
			if(param.getUpdtIdxx().equals(apprLineRList.get(i).getApprEmpId())) {
				apprLineRList.remove(i);
				if(apprLineRList.size() == 0)	param.getApprVO().setLineRYn("N");
				chk = false;
			}
		}
		for(int i = 0; i < apprLineIList.size() && chk; i++) {
			if(param.getUpdtIdxx().equals(apprLineIList.get(i).getApprEmpId())) {
				apprLineIList.remove(i);
				if(apprLineIList.size() == 0)	param.getApprVO().setLineIYn("N");
				chk = false;
			}
		}
		
		dissSpecInVO.setApprVO(param.getApprVO());
		dissSpecInVO.setTaskId("");
		dissSpecInVO.setApprId("");
		dissSpecInVO.setRegiIdxx(param.getRegiIdxx());
		dissSpecInVO.setUpdtIdxx(param.getUpdtIdxx());
		tempSaveDissSpecIn(dissSpecInVO);
	}

	/**
	 * 스펙인 과제 기본정보 상세 조회
	 *
	 * @param dissStepVO
	 * @return DissSpecInVO
	 */
	@Override
	public DissSpecInVO getDissSpecInTaskBasicInfoDetail(DissStepVO dissStepVO) {
		String stepId = dissStepVO.getStepId();
		String apprType = dissStepVO.getApprType();
		DissSpecInVO returnItem;
		DissSpecInVO dissSpecInVOParam = new DissSpecInVO();
		dissSpecInVOParam.setStepId(stepId);
		dissSpecInVOParam.setTaskId(dissStepVO.getTaskId());
		if ("".equals(stepId)) {
			//스펙인 과제 마스터 조회
			returnItem = dissSpecInDao.getDissSpecInInfo(dissSpecInVOParam);
		} else {
			//SPEC-IN등록 HIS 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_SPECIN_REG.getCode())) {
				returnItem = dissSpecInDao.getDissSpecInInfoHis(dissSpecInVOParam);
			} else {
				returnItem = dissSpecInDao.getDissSpecInInfo(dissSpecInVOParam);
			}
		}

		return returnItem;
	}

	/**
	 * 스펙인 컬러개발제안서 저장처리
	 *
	 * @param dissSpecInVO
	 */
	@Override
	public void saveColorProposal(DissSpecInVO dissSpecInVO) {
		if ("".equals(dissSpecInVO.getSaveMode())) {
			throw new ServiceException("", "컬러개발 제안 처리 구분이 지정되지 않았습니다.");
		}

		if ("TMP".equals(dissSpecInVO.getSaveMode())) { // 임시저장인경우
			// 기본저장
			saveColorProposalTables(dissSpecInVO);
			// 공통 결재 저장액션
			dissSpecInVO.getApprVO().setApprId(dissSpecInVO.getApprId()); // 기본저장시 apprId 셋팅
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
			dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());
			dissCommonApprMgmtService.saveDissCommonAppr(dissSpecInVO.getApprVO(), ApprState.TEMP_SAVE.getCode(), false);
		} else if ("REQ".equals(dissSpecInVO.getSaveMode())) {  // 결재요청인경우
			// 기본저장
			saveColorProposalTables(dissSpecInVO);
			// 공통 결재 저장액션
			dissSpecInVO.getApprVO().setApprId(dissSpecInVO.getApprId()); // 기본저장시 apprId 셋팅
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
			dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());
			
			//kjy
			dissSpecInVO.setApprType(dissSpecInVO.getApprVO().getApprType());	
			// 업무테이블 품의서 기초내용 작성 호출  kjy
			String templeteFormContent = dissSpecInVO.getApprVO().getFormCont();
			dissSpecInVO.getApprVO().setTempleteFormContent(getApprFormContColorProposal(dissSpecInVO, templeteFormContent));
			
			dissCommonApprMgmtService.saveDissCommonAppr(dissSpecInVO.getApprVO(), ApprState.APPR_PROCEEDING.getCode(), false);
		} else if ("DEL".equals(dissSpecInVO.getSaveMode())) { // 삭제인경우
			// 품의서 삭제
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
			dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());

			ApprVO checkApprVO = commonApprDao.getAppr(dissSpecInVO.getApprVO());
			if (!checkApprVO.getRegiIdxx().equals(dissSpecInVO.getUpdtIdxx())) {
				throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
			}
			dissCommonApprMgmtService.deleteDissAppr(dissSpecInVO.getApprVO());
			// 스텝삭제
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setStepId(dissSpecInVO.getStepId());
			dissStepVO.setStepCd(dissSpecInVO.getStepCd());
			dissStepVO.setTaskId(dissSpecInVO.getTaskId());
			dissStepDao.deleteDissStep(dissStepVO);
			// 이전스텝 최종 복구
			dissStepDao.updateStepLastYnYByStepCd(dissStepVO);
		} else if ("REW".equals(dissSpecInVO.getSaveMode())) { // 반려건 재작성 인경우
			dissSpecInVO.setStepId(""); // 스텝ID를 지우고 저장처리
			// 기본저장
			saveColorProposalTables(dissSpecInVO);
			// 공통 결재 저장액션
			dissSpecInVO.getApprVO().setApprId(dissSpecInVO.getApprId()); // 기본저장시 apprId 셋팅
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
			dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());
			dissCommonApprMgmtService.saveDissCommonAppr(dissSpecInVO.getApprVO(), ApprState.TEMP_SAVE.getCode(), false);
		}
	}
	
	/**
	 * DISS SPEC-IN color 제안서
	 *
	 * @param DissStepVO	 
	 * @return
	 */
	@Override
	public String getApprFormContColorProposal(DissSpecInVO param, String templeteFormContent) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();		
		DissSpecInVO dissSpecInVO = new DissSpecInVO();		
		String template = null;		
		//String apprType = param.getApprType();		
		
		// 헤더 조회.		
		dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(getDissSpecInInfoAll(param));
		dissSpecInVO.setTaskType(param.getTaskType());	
		
		map.put("dissSpecInVO"  , dissSpecInVO);
		
		template = REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER_NOTICE;  // spec-in, 제품개선 공통 템플릿.	
		
		//일정조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getTaskId());				
		
		List<DissScheduleVO> getDissScheduleList = dissScheduleDao.getDissScheduleList(paramSchedule);		
		
		List<DissScheduleVO> dissScheduleList = new ArrayList<DissScheduleVO>();
		for(DissScheduleVO schedule : getDissScheduleList) {
			dissScheduleList.add((DissScheduleVO)StringUtil.nullToEmptyString(schedule));
		}		
		
		map.put("dissScheduleList"	 , dissScheduleList);
		map.put("templeteFormContent", templeteFormContent);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getApprVO().getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);		
		
		map.put("fileVoList", fileVoList);
				
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}	


	/**
	 * DISS 컬러개발 제안서 저장 (결재의뢰 까지 사용)
	 *
	 * @param dissSpecInVO
	 */
	private void saveColorProposalTables(DissSpecInVO dissSpecInVO) {
		if ("".equals(dissSpecInVO.getStepId())) { // stepId 가 없으면 insert
			String tmpStepId = Util.getUUID();   // 스텝ID
			String tmpApprId = Util.getUUID();   // 품의서ID 생성

			dissSpecInVO.setApprId(tmpApprId);
			dissSpecInVO.setStepId(tmpStepId);
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setStepId(tmpStepId);
			dissStepVO.setStepCd(dissSpecInVO.getStepCd());
			dissStepVO.setTaskId(dissSpecInVO.getTaskId());
			// 이전 견본 스텝 LastYn N으로
			dissStepDao.updateDissStepLastYn(dissStepVO);

			dissStepVO.setTaskType("SPECIN"); // 스펙인으로 셋팅
			dissStepVO.setApprId(tmpApprId);
			dissStepVO.setDegreeNo(dissSpecInVO.getDegreeNo());
			dissStepVO.setRegiIdxx(dissSpecInVO.getRegiIdxx());
			dissStepVO.setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
			// 컬러개발 스텝 생성
			dissStepDao.createDissStep(dissStepVO);

			// 품의서 등록,수정자 셋팅
			dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
		} else { // stepId가 있으면 update
			// 품의서 수정자 셋팅
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
		}
	}

	/**
	 * DISS 스펙인 컬러개발제안 품의 결재 처리
	 *
	 * @param dissApprCommonParamVO
	 */
	@Override
	public void applColorProposal(DissApprCommonParamVO dissApprCommonParamVO) {
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(dissApprCommonParamVO.getApprId());                     // 품의서ID
		apprLineVO.setApprEmpId(dissApprCommonParamVO.getApprEmpId());              // 결재자사번
		apprLineVO.setApprLineComment(dissApprCommonParamVO.getApprLineComment());  // 결재자의견
		apprLineVO.setApplStat(dissApprCommonParamVO.getApplStat());                 // 결재자 결재결과
		apprLineVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());

		// 마지막 결재자 결재 완료 이면 후처리 작업
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(dissApprCommonParamVO.getApprId());
		if (dissCommonApprMgmtService.checkListApplActYn(apprVO, dissApprCommonParamVO.getApprEmpId())
				&& ApplState.APPL_APPROVE.getCode().equals(dissApprCommonParamVO.getApplStat())
		) {
			// 현재 스텝 구하기
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setApprId(dissApprCommonParamVO.getApprId());
			dissStepVO = dissStepDao.getDissStepByApprId(dissStepVO);
			// 구한 스텝으로 스케쥴 완료일 업데이트
			DissScheduleVO dissScheduleVO = new DissScheduleVO();
			dissScheduleVO.setTaskId(dissStepVO.getTaskId());
			dissScheduleVO.setStepGroup("200"); // 개발제안스케쥴
			dissScheduleVO.setCompYmd(Util.getToday()); // 오늘날짜로완료
			dissScheduleVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());
			dissScheduleDao.updateDissScheduleCompYmd(dissScheduleVO);
		}

		// DISS 공통 품의서 결재 호출
		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);
	}


	/**
	 * 스펙인 컬러개발결과보고 저장처리
	 *
	 * @param dissSpecInVO
	 */
	@Override
	public void saveColorPrescription(DissSpecInVO dissSpecInVO) {
		if ("".equals(dissSpecInVO.getSaveMode())) {
			throw new ServiceException("", "컬러개발 결과보고 처리 구분이 지정되지 않았습니다.");
		}

		if ("TMP".equals(dissSpecInVO.getSaveMode())) { // 임시저장인경우
			// 기본저장
			saveColorPrescriptionTables(dissSpecInVO);
			// 공통 결재 저장액션
			dissSpecInVO.getApprVO().setApprId(dissSpecInVO.getApprId()); // 기본저장시 apprId 셋팅
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
			dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());
			dissCommonApprMgmtService.saveDissCommonAppr(dissSpecInVO.getApprVO(), ApprState.TEMP_SAVE.getCode(), false);
		} else if ("REQ".equals(dissSpecInVO.getSaveMode())) {  // 결재요청인경우
			// 기본저장
			saveColorPrescriptionTables(dissSpecInVO);
			// 공통 결재 저장액션
			dissSpecInVO.getApprVO().setApprId(dissSpecInVO.getApprId()); // 기본저장시 apprId 셋팅
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
			dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());
			
			String templeteFormContent = dissSpecInVO.getApprVO().getFormCont();
			dissSpecInVO.getApprVO().setTempleteFormContent(getApprFormContColorProposal(dissSpecInVO, templeteFormContent));			
			
			dissCommonApprMgmtService.saveDissCommonAppr(dissSpecInVO.getApprVO(), ApprState.APPR_PROCEEDING.getCode(), false);
		} else if ("DEL".equals(dissSpecInVO.getSaveMode())) { // 삭제인경우
			// 품의서 삭제
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
			dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());
			ApprVO checkApprVO = commonApprDao.getAppr(dissSpecInVO.getApprVO());
			if (!checkApprVO.getRegiIdxx().equals(dissSpecInVO.getUpdtIdxx())) {
				throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
			}
			dissCommonApprMgmtService.deleteDissAppr(dissSpecInVO.getApprVO());
			// 스텝삭제
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setStepId(dissSpecInVO.getStepId());
			dissStepVO.setStepCd(dissSpecInVO.getStepCd());
			dissStepVO.setTaskId(dissSpecInVO.getTaskId());
			dissStepDao.deleteDissStep(dissStepVO);
			// 이전스텝 최종 복구
			dissStepDao.updateStepLastYnYByStepCd(dissStepVO);
		} else if ("REW".equals(dissSpecInVO.getSaveMode())) { // 반려건 재작성 인경우
			dissSpecInVO.setStepId(""); // 스텝ID를 지우고 저장처리
			// 기본저장
			saveColorPrescriptionTables(dissSpecInVO);
			// 공통 결재 저장액션
			dissSpecInVO.getApprVO().setApprId(dissSpecInVO.getApprId()); // 기본저장시 apprId 셋팅
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
			dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());
			dissCommonApprMgmtService.saveDissCommonAppr(dissSpecInVO.getApprVO(), ApprState.TEMP_SAVE.getCode(), false);
		}
	}


	/**
	 * DISS 스펙인 컬러개발 보고서 저장 (결재의뢰 까지 사용)
	 *
	 * @param dissSpecInVO
	 */
	private void saveColorPrescriptionTables(DissSpecInVO dissSpecInVO) {
		if ("".equals(dissSpecInVO.getStepId())) { // stepId 가 없으면 insert
			String tmpStepId = Util.getUUID();   // 스텝ID
			String tmpApprId = Util.getUUID();   // 품의서ID 생성

			dissSpecInVO.setApprId(tmpApprId);
			dissSpecInVO.setStepId(tmpStepId);
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setStepId(tmpStepId);
			dissStepVO.setStepCd(dissSpecInVO.getStepCd());
			dissStepVO.setTaskId(dissSpecInVO.getTaskId());
			// 이전 스텝 LastYn N으로
			dissStepDao.updateDissStepLastYn(dissStepVO);

			dissStepVO.setTaskType("SPECIN"); // 스펙인으로 셋팅
			dissStepVO.setApprId(tmpApprId);
			dissStepVO.setDegreeNo(dissSpecInVO.getDegreeNo());
			dissStepVO.setRegiIdxx(dissSpecInVO.getRegiIdxx());
			dissStepVO.setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
			// 컬러개발 결과보고 스텝 생성
			dissStepDao.createDissStep(dissStepVO);

			// 품의서 등록,수정자 셋팅
			dissSpecInVO.getApprVO().setRegiIdxx(dissSpecInVO.getRegiIdxx());
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
		} else { // stepId가 있으면 update
			// 품의서 수정자 셋팅
			dissSpecInVO.getApprVO().setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
		}
	}

	/**
	 * DISS 스펙인 컬러개발보고서 품의 결재 처리
	 *
	 * @param dissApprCommonParamVO
	 */
	@Override
	public void applColorPrescription(DissApprCommonParamVO dissApprCommonParamVO) {
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(dissApprCommonParamVO.getApprId());                     // 품의서ID
		apprLineVO.setApprEmpId(dissApprCommonParamVO.getApprEmpId());              // 결재자사번
		apprLineVO.setApprLineComment(dissApprCommonParamVO.getApprLineComment());  // 결재자의견
		apprLineVO.setApplStat(dissApprCommonParamVO.getApplStat());                 // 결재자 결재결과
		apprLineVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());

		// 마지막 결재자 결재 완료 이면 후처리 작업
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(dissApprCommonParamVO.getApprId());
		if (dissCommonApprMgmtService.checkListApplActYn(apprVO, dissApprCommonParamVO.getApprEmpId())
				&& ApplState.APPL_APPROVE.getCode().equals(dissApprCommonParamVO.getApplStat())
		) {
			// 현재 스텝 구하기
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setApprId(dissApprCommonParamVO.getApprId());
			dissStepVO = dissStepDao.getDissStepByApprId(dissStepVO);
			// 구한 스텝으로 스케쥴 완료일 업데이트
			DissScheduleVO dissScheduleVO = new DissScheduleVO();
			dissScheduleVO.setTaskId(dissStepVO.getTaskId());
			dissScheduleVO.setStepGroup("300"); // 개발보고스케쥴
			dissScheduleVO.setCompYmd(Util.getToday()); // 오늘날짜로완료
			dissScheduleVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());
			dissScheduleDao.updateDissScheduleCompYmd(dissScheduleVO);
		}

		// DISS 공통 품의서 결재 호출
		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);
	}

	/** TODO
	 * 스펙인 스케쥴 수정
	 *
	 * @param dissSpecInVO
	 */
	@Override
	public void editSpecInSchedule(DissSpecInVO dissSpecInVO) {
		dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInVO);
		String tmpStepId = Util.getUUID();
		String tmpApprId = Util.getUUID();
		String taskType = "SPECIN";
		String taskId   = dissSpecInVO.getTaskId();

		// 권한 체크
		DissSpecInVO checkSpecInVO = dissSpecInDao.getDissSpecInInfo(dissSpecInVO);
		if(!(dissSpecInVO.getUpdtIdxx().equals(checkSpecInVO.getTsEmpId()) || dissSpecInVO.getUpdtIdxx().equals(checkSpecInVO.getSalesEmpId()))){
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.\n(SPEC-IN 일정수정은 과제 영업담당자,TS담당자 만 가능 합니다.)");
		}

		boolean chkSales = !dissSpecInVO.getSalesEmpId().equals(checkSpecInVO.getSalesEmpId());
		boolean chkTS = !dissSpecInVO.getTsEmpId().equals(checkSpecInVO.getTsEmpId());

		// 영업 담당자 또는 TS 담당자가 다를 경우 수정
		if(chkSales || chkTS) {
			dissSpecInDao.changeTsEmpGateReview(dissSpecInVO);

			String mailTitle = "D.I.S.S. 과제의 기존 담당자 요청으로 신규 담당자로 변경이 완료되었습니다. [" + checkSpecInVO.getTaskName() + "]";

			Map<String,String> mailParamMap = new HashMap<>();
			mailParamMap.put("taskName", checkSpecInVO.getTaskName());
			mailParamMap.put("leaderChange1", checkSpecInVO.getSalesEmpNm() + (chkSales ? " -> " + dissSpecInVO.getSalesEmpNm() : ""));
			mailParamMap.put("leaderChange2", checkSpecInVO.getTsEmpNm() + (chkTS ? " -> " + dissSpecInVO.getTsEmpNm() : ""));

			// 영업 담당자
			if(chkSales){
				Map<String, String> map = new HashMap<String, String>();
				map.put("sawnCode1", checkSpecInVO.getSalesEmpId());
				map.put("sawnCode2", dissSpecInVO.getSalesEmpId());
				for(EmployVO employVO : dissImpDevDao.getEmployByLeaderChange(map)) {
					SendMailVO sendMailVO = new SendMailVO();
					sendMailVO.setTitle(mailTitle);
					sendMailVO.setMailType(MailType.DISS_CHANGE_LEADER_SPECIN);
					sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
					sendMailVO.setReceiverEmail(employVO.getMailAddr());
					sendMailVO.setParams(mailParamMap);
					mailingService.sendMail(sendMailVO);
				}
			}

			// TS 담당자
			if(chkTS) {
				Map<String, String> map = new HashMap<String, String>();
				map.put("sawnCode1", checkSpecInVO.getTsEmpId());
				map.put("sawnCode2", dissSpecInVO.getTsEmpId());
				for(EmployVO employVO : dissImpDevDao.getEmployByLeaderChange(map)) {
					SendMailVO sendMailVO = new SendMailVO();
					sendMailVO.setTitle(mailTitle);
					sendMailVO.setMailType(MailType.DISS_CHANGE_LEADER_SPECIN);
					sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
					sendMailVO.setReceiverEmail(employVO.getMailAddr());
					sendMailVO.setParams(mailParamMap);
					mailingService.sendMail(sendMailVO);
				}
			}

			EmployVO employVO = new EmployVO();
			employVO.setTeamCode("H3002");	//전략기획팀(제품개발Part)
			employVO.setPageSize(10);
			for(EmployVO part : commonDao.getEmployList(employVO)) {
				SendMailVO sendMailVO = new SendMailVO();
				sendMailVO.setTitle(mailTitle);
				sendMailVO.setMailType(MailType.DISS_CHANGE_LEADER_SPECIN);
				sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
				sendMailVO.setReceiverEmail(part.getMailAddr());
				sendMailVO.setParams(mailParamMap);
				mailingService.sendMail(sendMailVO);
			}
		}

		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setTaskId(taskId);
		dissStepVO.setTaskType(taskType);
		dissStepVO.setApprId(tmpApprId);
		dissStepVO.setStepId(tmpStepId);
		dissStepVO.setStepCd("900000"); // 과제수정스텝으로
		dissStepVO.setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
		dissStepVO.setRegiIdxx(dissSpecInVO.getRegiIdxx());
		dissStepDao.createDissStep(dissStepVO);

		// 스케쥴 원본데이타 가져오기
		DissScheduleVO scheduleVOParam = new DissScheduleVO();
		scheduleVOParam.setTaskId(taskId);
		List<DissScheduleVO> dissScheduleVOList = dissScheduleDao.getDissScheduleList(scheduleVOParam);
		List<DissScheduleVO> editedScheduleVOList = dissSpecInVO.getDissScheduleList();

		// 원본데이타와 수정 데이타 머지하면서 히스토리 생성 및 원본 스케쥴 수정 저장
		for(DissScheduleVO dissScheduleVO : dissScheduleVOList){
			dissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(dissScheduleVO);
			for(DissScheduleVO editScheduleVO: editedScheduleVOList){
				editScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(editScheduleVO);
				if(dissScheduleVO.getStepGroup().equals(editScheduleVO.getStepGroup())){
					dissScheduleVO.setStepId(tmpStepId);
					dissScheduleVO.setCompGoalYmd(editScheduleVO.getCompGoalYmd());
					dissScheduleVO.setEmpId(editScheduleVO.getEmpId());
					dissScheduleVO.setDevEmpId(editScheduleVO.getDevEmpId());
					dissScheduleVO.setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
					dissScheduleVO.setRegiIdxx(dissSpecInVO.getRegiIdxx());
					// 히스토리 생성
					dissScheduleDao.createDissScheduleHis(dissScheduleVO);
					dissScheduleDao.updateDissSchedule(dissScheduleVO);
				}
			}
		}

		// 품의서 작성완료로 저장
		ApprVO apprVO = dissSpecInVO.getApprVO();
		apprVO.setApprId(tmpApprId);
		apprVO.setRegiIdxx(dissSpecInVO.getRegiIdxx());
		apprVO.setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
		dissCommonApprMgmtService.saveDissCommonAppr(apprVO,ApprState.APPR_WRITE_COMPLETE.getCode(), false);
	}

	@Override
	public void updateSpecInSchedule(DissSpecInVO dissSpecInVO) {
		boolean tempChk = !"".equals(dissSpecInVO.getStepId());

		String stepId = tempChk ? dissSpecInVO.getStepId() : Util.getUUID();
		String apprId = tempChk ? dissSpecInVO.getApprId() : Util.getUUID();
		String taskType = "SPECIN";
		String taskId   = dissSpecInVO.getTaskId();

		// 권한 체크
		DissSpecInVO checkSpecInVO = dissSpecInDao.getDissSpecInInfo(dissSpecInVO);
		if(!(dissSpecInVO.getUpdtIdxx().equals(checkSpecInVO.getTsEmpId()) || dissSpecInVO.getUpdtIdxx().equals(checkSpecInVO.getSalesEmpId()))) {
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.\n(SPEC-IN 일정수정은 과제 영업담당자,TS담당자 만 가능 합니다.)");
		}

		checkSpecInVO.setStepId(stepId);
		checkSpecInVO.setSalesEmpId(dissSpecInVO.getSalesEmpId());
		checkSpecInVO.setTsEmpId(dissSpecInVO.getTsEmpId());
		if(tempChk)	dissSpecInDao.deleteDissSpecInHis(checkSpecInVO);
		dissSpecInDao.createDissSpecInHis(checkSpecInVO);

		if(!tempChk) {
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setTaskId(taskId);
			dissStepVO.setTaskType(taskType);
			dissStepVO.setApprId(apprId);
			dissStepVO.setStepId(stepId);
			dissStepVO.setStepCd("900000"); // 과제수정스텝으로
			dissStepVO.setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
			dissStepVO.setRegiIdxx(dissSpecInVO.getRegiIdxx());
			dissStepDao.createDissStep(dissStepVO);
		}

		// 스케쥴 원본데이타 가져오기
		DissScheduleVO scheduleVOParam = new DissScheduleVO();
		scheduleVOParam.setTaskId(taskId);
		List<DissScheduleVO> dissScheduleVOList = dissScheduleDao.getDissScheduleList(scheduleVOParam);
		List<DissScheduleVO> editedScheduleVOList = dissSpecInVO.getDissScheduleList();
		
		// 원본데이타와 수정 데이타 머지하면서 히스토리 생성
		for(DissScheduleVO dissScheduleVO : dissScheduleVOList) {
			dissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(dissScheduleVO);
			for(DissScheduleVO editScheduleVO: editedScheduleVOList) {
				editScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(editScheduleVO);
				if(dissScheduleVO.getStepGroup().equals(editScheduleVO.getStepGroup())){
					dissScheduleVO.setStepId(stepId);
					dissScheduleVO.setCompGoalYmd(editScheduleVO.getCompGoalYmd());
					dissScheduleVO.setEmpId(editScheduleVO.getEmpId());
					dissScheduleVO.setDevEmpId(editScheduleVO.getDevEmpId());
					dissScheduleVO.setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
					dissScheduleVO.setRegiIdxx(dissSpecInVO.getRegiIdxx());
					dissScheduleDao.mergeDissScheduleHis(dissScheduleVO);
				}
			}
		}

		ApprVO apprVO = dissSpecInVO.getApprVO();
		apprVO.setApprId(apprId);
		apprVO.setRegiIdxx(dissSpecInVO.getRegiIdxx());
		apprVO.setUpdtIdxx(dissSpecInVO.getUpdtIdxx());

		dissCommonApprMgmtService.saveDissCommonAppr(apprVO, ApprState.APPR_PROCEEDING.getCode(), false);
	}

	@Override
	public void deleteSpecInScheduleEdit(DissSpecInVO dissSpecInVO) {
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(dissSpecInVO.getApprId());
		apprVO = commonApprDao.getAppr(apprVO);
		if(!apprVO.getRegiIdxx().equals(dissSpecInVO.getUpdtIdxx())){
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
		}

		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(dissSpecInVO.getStepId());
		DissScheduleVO dissScheduleVO = new DissScheduleVO();
		dissScheduleVO.setStepId(dissSpecInVO.getStepId());

		dissCommonApprMgmtService.deleteDissAppr(apprVO);
		dissSpecInDao.deleteDissSpecInHis(dissSpecInVO);
		dissStepDao.deleteDissStep(dissStepVO);
		dissScheduleDao.deleteDissScheduleHisAll(dissScheduleVO);
	}

	@Override
	public void applDissSpecInScheduleEdit(DissApprCommonParamVO dissApprCommonParamVO) {
		String apprId = dissApprCommonParamVO.getApprId();
		String taskId = dissApprCommonParamVO.getTaskId();
		String stepId = dissApprCommonParamVO.getStepId();

		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(apprId);                     // 품의서ID
		apprLineVO.setApprEmpId(dissApprCommonParamVO.getApprEmpId());              // 결재자사번
		apprLineVO.setApprLineComment(dissApprCommonParamVO.getApprLineComment());  // 결재자의견
		apprLineVO.setApplStat(dissApprCommonParamVO.getApplStat());                 // 결재자 결재결과
		apprLineVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());

		// DISS 공통 품의서 결재 호출
		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);

		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(apprId);
		if(dissCommonApprMgmtService.checkListApplActYn(apprVO, dissApprCommonParamVO.getApprEmpId())
		&& ApplState.APPL_APPROVE.getCode().equals(dissApprCommonParamVO.getApplStat())) {
			DissSpecInVO specInVO = new DissSpecInVO();
			specInVO.setTaskId(taskId);
			specInVO = dissSpecInDao.getDissSpecInInfo(specInVO);

			DissSpecInVO editedSpecInVO = new DissSpecInVO();
			editedSpecInVO.setStepId(stepId);
			editedSpecInVO = dissSpecInDao.getDissSpecInInfoHis(editedSpecInVO);

			boolean chkSales = !editedSpecInVO.getSalesEmpId().equals(specInVO.getSalesEmpId());
			boolean chkTS = !editedSpecInVO.getTsEmpId().equals(specInVO.getTsEmpId());

			if(chkSales || chkTS) {
				dissSpecInDao.changeTsEmpGateReview(editedSpecInVO);

				String mailTitle = "D.I.S.S. 과제의 기존 담당자 요청으로 신규 담당자로 변경이 완료되었습니다. [" + specInVO.getTaskName() + "]";

				Map<String,String> mailParamMap = new HashMap<>();
				mailParamMap.put("taskName", specInVO.getTaskName());
				mailParamMap.put("leaderChange1", specInVO.getSalesEmpNm() + (chkSales ? " -> " + editedSpecInVO.getSalesEmpNm() : ""));
				mailParamMap.put("leaderChange2", specInVO.getTsEmpNm() + (chkTS ? " -> " + editedSpecInVO.getTsEmpNm() : ""));

				// 영업 담당자
				if(chkSales) {
					Map<String, String> map = new HashMap<String, String>();
					map.put("sawnCode1", specInVO.getSalesEmpId());
					map.put("sawnCode2", editedSpecInVO.getSalesEmpId());
					for(EmployVO employVO : dissImpDevDao.getEmployByLeaderChange(map)) {
						SendMailVO sendMailVO = new SendMailVO();
						sendMailVO.setTitle(mailTitle);
						sendMailVO.setMailType(MailType.DISS_CHANGE_LEADER_SPECIN);
						sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
						sendMailVO.setReceiverEmail(employVO.getMailAddr());
						sendMailVO.setParams(mailParamMap);
						mailingService.sendMail(sendMailVO);
					}
				}

				// TS 담당자
				if(chkTS) {
					Map<String, String> map = new HashMap<String, String>();
					map.put("sawnCode1", specInVO.getTsEmpId());
					map.put("sawnCode2", editedSpecInVO.getTsEmpId());
					for(EmployVO employVO : dissImpDevDao.getEmployByLeaderChange(map)) {
						SendMailVO sendMailVO = new SendMailVO();
						sendMailVO.setTitle(mailTitle);
						sendMailVO.setMailType(MailType.DISS_CHANGE_LEADER_SPECIN);
						sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
						sendMailVO.setReceiverEmail(employVO.getMailAddr());
						sendMailVO.setParams(mailParamMap);
						mailingService.sendMail(sendMailVO);
					}
				}

				EmployVO employVO = new EmployVO();
				employVO.setTeamCode("H3002");	//전략기획팀(제품개발Part)
				employVO.setPageSize(10);
				for(EmployVO part : commonDao.getEmployList(employVO)) {
					SendMailVO sendMailVO = new SendMailVO();
					sendMailVO.setTitle(mailTitle);
					sendMailVO.setMailType(MailType.DISS_CHANGE_LEADER_SPECIN);
					sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
					sendMailVO.setReceiverEmail(part.getMailAddr());
					sendMailVO.setParams(mailParamMap);
					mailingService.sendMail(sendMailVO);
				}
			}

			DissScheduleVO scheduleVOParam = new DissScheduleVO();
			scheduleVOParam.setStepId(stepId);
			List<DissScheduleVO> editedScheduleVOList = dissScheduleDao.getDissScheduleHisList(scheduleVOParam);

			for(DissScheduleVO dissScheduleVO : editedScheduleVOList) {
				dissScheduleVO.setTaskId(taskId);
				dissScheduleDao.updateDissSchedule(dissScheduleVO);
			}
		}
	}

	@Override
	public void editSpecInCtq(DissSpecInVO dissSpecInVO) {
		dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInVO);
		String tmpStepId = Util.getUUID();
		String tmpApprId = Util.getUUID();
		String taskType = "SPECIN";
		String taskId   = dissSpecInVO.getTaskId();
		
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setTaskId(taskId);
		dissStepVO.setTaskType(taskType);
		dissStepVO.setApprId(tmpApprId);
		dissStepVO.setStepId(tmpStepId);
		dissStepVO.setStepCd("900000"); // 과제수정스텝으로
		dissStepVO.setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
		dissStepVO.setRegiIdxx(dissSpecInVO.getRegiIdxx());
		dissStepDao.createDissStep(dissStepVO);
		
		dissSpecInVO.setStepId(tmpStepId);
		dissSpecInDao.createDissSpecInHis(dissSpecInVO);
		dissSpecInDao.changeSpecInCtq(dissSpecInVO);
		
		// 품의서 작성완료로 저장
		ApprVO apprVO = dissSpecInVO.getApprVO();
		apprVO.setApprId(tmpApprId);
		apprVO.setRegiIdxx(dissSpecInVO.getRegiIdxx());
		apprVO.setUpdtIdxx(dissSpecInVO.getUpdtIdxx());
		dissCommonApprMgmtService.saveDissCommonAppr(apprVO,ApprState.APPR_WRITE_COMPLETE.getCode(), false);
	}

	@Override
	public List<DissExcelDownloadVO> getDissSpecInListExcelDownload(DissSpecInVO param) {
		return dissSpecInDao.getDissSpecInListExcelDownload(param);
	}

	@Override
	public List<DissSpecInVO> getFailSpecInList(DissSpecInVO param) {
		return dissSpecInDao.getFailSpecInList(param);
	}

	@Override
	public int getFailSpecInListCnt(DissSpecInVO param) {
		return dissSpecInDao.getFailSpecInListCnt(param);
	}
}
