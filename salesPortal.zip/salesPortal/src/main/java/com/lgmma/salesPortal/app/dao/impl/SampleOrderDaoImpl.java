package com.lgmma.salesPortal.app.dao.impl;

import com.lgmma.salesPortal.app.dao.SampleOrderDao;
import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.SampleOrderMasterVO;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public class SampleOrderDaoImpl implements SampleOrderDao {

    private static final String MAPPER_NAMESPACE = "SAMPLE_ORDER_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public void createSampleOrderMaster(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createSampleOrderMaster", param);
	}
	
	@Override
	public void createSampleOrderItem(DirectOrderItemVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createSampleOrderItem", param);
	}

	@Override
	public void updateErpOrderId(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateErpOrderId", param);
	}

	@Override
	public void updateErpMessage(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateErpMessage", param);
	}

	@Override
	public int getSampleOrderCount(SampleOrderMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getSampleOrderCount", param);
	}

	@Override
	public List<SampleOrderMasterVO> getSampleOrderList(SampleOrderMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSampleOrderList", param);
	}

	@Override
	public List<DirectOrderItemVO> getSampleOrderItemList(String orderId) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSampleOrderItemList", orderId);
	}

	@Override
	public SampleOrderMasterVO getSampleOrderDetail(SampleOrderMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getSampleOrderDetail", param);
	}

	@Override
	public void updateSampleOrderMaster(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateSampleOrderMaster", param);
	}

	@Override
	public void deleteSampleOrderItems(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "deleteSampleOrderItems", param);
	}

	@Override
	public void deleteSampleOrderMaster(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "deleteSampleOrderMaster", param);
	}

	@Override
	public int getSampleDocCount(SampleOrderMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getSampleDocCount", param);
	}

	@Override
	public List<SampleOrderMasterVO> getSampleDocList(SampleOrderMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSampleDocList", param);
	}

	@Override
	public SampleOrderMasterVO getVocInfo(SampleOrderMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getVocInfo", param);
	}

	@Override
	public List<DirectOrderItemVO> getVocItemList(String vactIdxx) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getVocItemList", vactIdxx);
	}

	@Override
	public void updateSampleOrderApprId(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateSampleOrderApprId", param);
	}

	@Override
	public void updateSampleOrderApprIdToNull(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateSampleOrderApprIdToNull", param);
	}

	@Override
	public void updateAfterSendErp(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateAfterSendErp", param);
	}

	@Override
	public void updateSampleOrderAfterVocActInfo(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateSampleOrderAfterVocActInfo", param);
	}

	@Override
	public void regSampleOrderFile(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "regSampleOrderFile", param);
	}

	@Override
	public void updateSampleOrderComment(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateSampleOrderComment", param);
	}


}
