package com.lgmma.salesPortal.app.dao.impl;

import com.lgmma.salesPortal.app.dao.DissSpecInDao;
import com.lgmma.salesPortal.app.model.DissExcelDownloadVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.EmployVO;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


@Repository
public class DissSpecInDaoImpl implements DissSpecInDao {

    private static final String MAPPER_NAMESPACE = "DISS_SPECIN_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public int getDissSpecInListCount(DissSpecInVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissSpecInListCount", param);
	}

	@Override
	public List<DissSpecInVO> getDissSpecInList(DissSpecInVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissSpecInList", param);
	}

	@Override
	public DissSpecInVO getDissSpecInInfo(DissSpecInVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissSpecInInfo", param);
	}

	@Override
	public DissSpecInVO getDissSpecInInfoHis(DissSpecInVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissSpecInInfoHis", param);
	}

	@Override
	public void createDissSpecIn(DissSpecInVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissSpecIn", param);
	}

	@Override
	public void createDissSpecInHis(DissSpecInVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissSpecInHis", param);
	}

	@Override
	public void updateDissSpecIn(DissSpecInVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissSpecIn", param);
	}

	@Override
	public void updateDissSpecInHis(DissSpecInVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissSpecInHis", param);
	}

	@Override
	public void deleteDissSpecIn(DissSpecInVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissSpecIn", param);
	}

	@Override
	public void deleteDissSpecInHis(DissSpecInVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissSpecInHis", param);
	}

	@Override
	public void changeTsEmpGateReview(DissSpecInVO param)  {
		sqlSession.update(MAPPER_NAMESPACE + "changeTsEmpGateReview", param);
	}

	@Override
	public void changeTsEmpGateReviewHis(DissSpecInVO param)  {
		sqlSession.update(MAPPER_NAMESPACE + "changeTsEmpGateReviewHis", param);
	}
	
	@Override
	public void changeSpecInDevLevel(DissSpecInVO param)  {
		sqlSession.update(MAPPER_NAMESPACE + "changeSpecInDevLevel", param);
	}
	
	@Override
	public void changeSpecInDevLevelHis(DissSpecInVO param)  {
		sqlSession.update(MAPPER_NAMESPACE + "changeSpecInDevLevelHis", param);
	}
	
	@Override
	public void changeSpecInCtq(DissSpecInVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "changeSpecInCtq", param);
	}
	
	@Override
	public void updateDissSpecInGateReviewHis(DissSpecInVO param){
		sqlSession.update(MAPPER_NAMESPACE + "updateDissSpecInGateReviewHis", param);
	}

	@Override
	public List<DissExcelDownloadVO> getDissSpecInListExcelDownload(DissSpecInVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissSpecInListExcelDownload", param);
	}

	@Override
	public List<DissSpecInVO> getFailSpecInList(DissSpecInVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getFailSpecInList", param);
	}

	@Override
	public int getFailSpecInListCnt(DissSpecInVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getFailSpecInListCnt", param);
	}
}
