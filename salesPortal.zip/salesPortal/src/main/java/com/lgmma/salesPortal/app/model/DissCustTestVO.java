package com.lgmma.salesPortal.app.model;

public class DissCustTestVO extends PagingParamVO {

	//TB_D_CUSTTEST
	private String stepId;        	  // 과제스텝ID
	private String afterPlan;     	  // 향후계획

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getAfterPlan() {
		return afterPlan;
	}

	public void setAfterPlan(String afterPlan) {
		this.afterPlan = afterPlan;
	}

}
