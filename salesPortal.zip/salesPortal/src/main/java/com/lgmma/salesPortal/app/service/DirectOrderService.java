package com.lgmma.salesPortal.app.service;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.ItemDeliveryVO;

public interface DirectOrderService {

	Map createDirectOrder(DirectOrderMasterVO param);

	void creSaveDirectOrder(DirectOrderMasterVO param);

	String makePurchNo(String docType);

	int getDirectOrderMasterItemListCount(DirectOrderMasterVO param);

	List<DirectOrderMasterVO> getDirectOrderMasterItemList(DirectOrderMasterVO param);

	List<ItemDeliveryVO> getOrderDeliveryInfo(String orderId);

	DirectOrderMasterVO getDirectOrderDetail(String orderId);

	void setOrderDetailCodeText(DirectOrderMasterVO orderMasterVO);

	//void updateDirectOrder(DirectOrderMasterVO param);

	void deleteDirectOrder(DirectOrderMasterVO param);

	List<DirectOrderMasterVO> getOrderMasterItemForClosingList(DirectOrderMasterVO param);

	void setSapOrderStatus(DirectOrderMasterVO param, List<DirectOrderMasterVO> masterList);

	Map updateDirectOrder(DirectOrderMasterVO orderMaster);

	Map updateDirectOrderSkipShipment(DirectOrderMasterVO orderMaster);

	Map updateCommentText(DirectOrderMasterVO orderMaster);

	void updatePmnttrms(DirectOrderMasterVO[] params);

	int getDirectOrderCount(DirectOrderMasterVO param);

	List<DirectOrderMasterVO> getDirectOrderList(DirectOrderMasterVO param);

	List<DirectOrderMasterVO> getOrderForPaymentChangeList(DirectOrderMasterVO param);

}
