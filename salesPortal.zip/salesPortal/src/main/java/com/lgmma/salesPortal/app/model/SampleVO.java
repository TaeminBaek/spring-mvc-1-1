package com.lgmma.salesPortal.app.model;

public class SampleVO extends PagingParamVO {

	private String codeIdxx;
	private String grupCode;
	private String codeName;
	private String deleIsxx;
	private String regiIdxx;
	private String regiDate;
	
	public String getCodeIdxx() {
		return codeIdxx;
	}
	public void setCodeIdxx(String codeIdxx) {
		this.codeIdxx = codeIdxx;
	}
	public String getGrupCode() {
		return grupCode;
	}
	public void setGrupCode(String grupCode) {
		this.grupCode = grupCode;
	}
	public String getCodeName() {
		return codeName;
	}
	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}
	public String getDeleIsxx() {
		return deleIsxx;
	}
	public void setDeleIsxx(String deleIsxx) {
		this.deleIsxx = deleIsxx;
	}
	public String getRegiIdxx() {
		return regiIdxx;
	}
	public void setRegiIdxx(String regiIdxx) {
		this.regiIdxx = regiIdxx;
	}
	public String getRegiDate() {
		return regiDate;
	}
	public void setRegiDate(String regiDate) {
		this.regiDate = regiDate;
	}
	
	

}
