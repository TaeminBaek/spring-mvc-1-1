 package com.lgmma.salesPortal.app.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissDashBoardDao;
import com.lgmma.salesPortal.app.model.DissDashBoardVO;

@Repository
public class DissDashBoardDaoImpl implements DissDashBoardDao{
	
	private static final String MAPPER_NAMESPACE = "DISS_DASHBOARD_MAPPER.";
	
	 @Autowired(required=true)
	    protected SqlSession sqlSession;

	@Override
	public DissDashBoardVO getDissDashBoardMyIngSpecInCnt(DissDashBoardVO param) {
		 return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissDashBoardMyIngSpecInCnt", param);
	}

	@Override
	public DissDashBoardVO getDissDashBoardMyIngImpDevCnt(DissDashBoardVO param) {
		 return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissDashBoardMyIngImpDevCnt", param);
	}

	@Override
	public DissDashBoardVO getDissDashBoardMyIngOneTeamCnt(DissDashBoardVO param) {
		 return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissDashBoardMyIngOneTeamCnt", param);
	}

	@Override
	public DissDashBoardVO getDissDashBoardStepSpecInCnt(DissDashBoardVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissDashBoardStepSpecInCnt", param);
	}

	@Override
	public DissDashBoardVO getDissDashBoardStepImpDevCnt(DissDashBoardVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissDashBoardStepImpDevCnt", param);
	}

}
