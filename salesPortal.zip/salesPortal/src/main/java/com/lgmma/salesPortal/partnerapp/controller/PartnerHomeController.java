package com.lgmma.salesPortal.partnerapp.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.controller.CommonController;
import com.lgmma.salesPortal.app.model.CustomerCreditListVO;
import com.lgmma.salesPortal.app.model.OrderListVO;
import com.lgmma.salesPortal.app.model.WorkStatVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.CreditMgmtService;
import com.lgmma.salesPortal.app.service.OrderService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;


@Controller
public class PartnerHomeController {

	@Autowired
	CommonService commonService;
	
	@Autowired
	SapSearchService sapSearchService;
	
	@Autowired
	CommonController commonController;
	
	@Autowired
	CreditMgmtService CreditMgmtService;
	
	@Autowired
	OrderService orderService;
	
	@RequestMapping(value = "/partner/home")
	public String partnerHomePage(ModelAndView mav) throws Exception {
		return "partner/home";
	}
	
	@RequestMapping(value = "/getPartHomeSalesExpList.json")
	public Map getPartHomeSalesExpList() throws Exception {
		String param = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getSawnCode();
		String defaultYm = DateUtil.getCurrentYear().concat(DateUtil.getToday().substring(4, 6));
		String kvgr3 = commonService.getKvgr3(param);
		
		List<List<Map>> returnList = new ArrayList<List<Map>>();
		String today = Util.getToday();
		String startMonth = DateUtil.addMonth(today, -12);	//조회 시작년월	(12개월 전)
		
		// 현재 일자가 10일 미만이면 조회년월 기간을 한달 앞당김(전월까지 조회)
		if(Integer.parseInt(today.substring(6)) < 10) {
			startMonth = DateUtil.addMonth(startMonth, -1);
		}
		for(int i=0; i<12; i++) {
			List<Map> partSalesExpList = sapSearchService.getPartSalesExpList(startMonth.substring(0,6), "3000", kvgr3);
			if(partSalesExpList.size() != 0) {
				for(Map sales : partSalesExpList) {
					sales.put("mm", startMonth.substring(4,6));
				}
			} else {
				Map emptySalesStatMap = new HashMap<>();
				emptySalesStatMap.put("mm", startMonth.substring(4,6));
				emptySalesStatMap.put("VALUE2", 0);
				partSalesExpList.add(emptySalesStatMap);
			}
			returnList.add(partSalesExpList);
			startMonth = DateUtil.addMonth(startMonth, 1);
		}
		
		return JsonResponse.asSuccess("storeData", returnList);
	}
	
	@RequestMapping(value = "/getPartHomeBondList.json")
	public Map getPartHomeBondList() throws Exception {
		String compName = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getCompName().trim();
		String currentYm = Util.getToday().substring(0, 6);
		String pastYm = DateUtil.addMonth(Util.getToday(), -1).substring(0, 6);
		
		Map<String, CustomerCreditListVO> returnMap = new HashMap<String, CustomerCreditListVO>();
		
		
		//전월채권
		CustomerCreditListVO pastBondVO = new CustomerCreditListVO();
		pastBondVO.setGjahr(pastYm);
		pastBondVO.setVtweg("");
		pastBondVO.setGsber("3000");
		pastBondVO.setName1(compName);
		
		List<CustomerCreditListVO> pastBondList = CreditMgmtService.getCustomerCreditList(pastBondVO);
		
		for(CustomerCreditListVO pastVO : pastBondList) {
			if(pastVO.getName1().equals(compName)) {
				returnMap.put("pastBond", pastVO);
			}
		}
		
		//당월채권
		CustomerCreditListVO currentBondVO = new CustomerCreditListVO();
		currentBondVO.setGjahr(currentYm);
		currentBondVO.setVtweg("");
		currentBondVO.setGsber("3000");
		currentBondVO.setName1(compName);
		
		List<CustomerCreditListVO> currentBondList = CreditMgmtService.getCustomerCreditList(currentBondVO);
		
		for(CustomerCreditListVO currentVO : currentBondList) {
			if(currentVO.getName1().equals(compName)) {
				returnMap.put("currentBond", currentVO);
			}
		}
		
		return JsonResponse.asSuccess("storeData", returnMap);
	}
	
	//주문 리스트
	@RequestMapping(value = "/getPartHomeOrderList.json")
	public Map getPartHomeOrderList(@RequestBody(required = false) OrderListVO param) throws Exception {
		String today = Util.getToday();
		String prevMonth = DateUtil.addMonth(Util.getToday(), -1);
		param.setSdate(prevMonth);
		param.setEdate(today);
		return JsonResponse.asSuccess("storeData", orderService.getOrderList(param));
	}
/*	
	@RequestMapping(value = "/html/{htmlPage}")
	public String homePage(@PathVariable String htmlPage) throws Exception {
		return htmlPage;
	}
*/	
}
