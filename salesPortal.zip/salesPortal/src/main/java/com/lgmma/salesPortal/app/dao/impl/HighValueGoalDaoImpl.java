 package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.HighValueGoalDao;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.HighValueGoalVO;

@Repository
public class HighValueGoalDaoImpl implements HighValueGoalDao{
	
	private static final String MAPPER_NAMESPACE = "HIGHVALUE_GOAL_MAPPER.";
	
	 @Autowired(required=true)
	    protected SqlSession sqlSession;

	@Override
	public int getHighValueGoalCount(HighValueGoalVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE+"getHighValueGoalCount", param);
	}

	@Override
	public List<HighValueGoalVO> getHighValueGoalList(HighValueGoalVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE+"getHighValueGoalList", param);
	}
	
	@Override
	public List<CommonCodeVO> getHighValueCodeList(HighValueGoalVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE+"getHighValueCodeList", param);
	}
	
	@Override
	public void createHighValueGoal(HighValueGoalVO param) {
		sqlSession.insert(MAPPER_NAMESPACE+"createHighValueGoal", param);
	}

	@Override
	public void updateHighValueGoal(HighValueGoalVO param) {
		sqlSession.update(MAPPER_NAMESPACE+"updateHighValueGoal", param);
	}

	@Override
	public void deleteHighValueGoal(HighValueGoalVO param) {
		sqlSession.delete(MAPPER_NAMESPACE+"deleteHighValueGoal", param);
	}

	@Override
	public List<CommonCodeVO> getYearHighValueCodeList(HighValueGoalVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE+"getYearHighValueCodeList", param);
	}

	@Override
	public List<HighValueGoalVO> getHighValueCGResultList(HighValueGoalVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE+"getHighValueCGResultList", param);
	}


}
