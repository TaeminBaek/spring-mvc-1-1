package com.lgmma.salesPortal.app.model;

public class DissCommentVO extends PagingParamVO {
	/* DISS Comment param */
	private String apprId;
	private String apprCommentId;
	private String apprComment;
	
	/* view columns */
	private String commentEmpNm;
	private String commentPosiNm;
	private String commentTeamNm;

	private String taskId;
	private String taskType;
	private String apprType;
	private String dailyActId;
	
	private boolean sendMail;

	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getApprCommentId() {
		return apprCommentId;
	}
	public void setApprCommentId(String apprCommentId) {
		this.apprCommentId = apprCommentId;
	}
	public String getApprComment() {
		return apprComment;
	}
	public void setApprComment(String apprComment) {
		this.apprComment = apprComment;
	}
	public String getCommentEmpNm() {
		return commentEmpNm;
	}
	public void setCommentEmpNm(String commentEmpNm) {
		this.commentEmpNm = commentEmpNm;
	}
	public String getCommentPosiNm() {
		return commentPosiNm;
	}
	public void setCommentPosiNm(String commentPosiNm) {
		this.commentPosiNm = commentPosiNm;
	}
	public String getCommentTeamNm() {
		return commentTeamNm;
	}
	public void setCommentTeamNm(String commentTeamNm) {
		this.commentTeamNm = commentTeamNm;
	}
	public boolean isSendMail() {
		return sendMail;
	}
	public void setSendMail(boolean sendMail) {
		this.sendMail = sendMail;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getApprType() {
		return apprType;
	}
	public void setApprType(String apprType) {
		this.apprType = apprType;
	}
	public String getDailyActId() {
		return dailyActId;
	}
	public void setDailyActId(String dailyActId) {
		this.dailyActId = dailyActId;
	}
}
