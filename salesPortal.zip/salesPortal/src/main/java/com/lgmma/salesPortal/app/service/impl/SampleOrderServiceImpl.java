package com.lgmma.salesPortal.app.service.impl;

import com.lgmma.salesPortal.app.dao.SampleOrderDao;
import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.OrderProdJindVO;
import com.lgmma.salesPortal.app.model.SampleOrderMasterVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.DirectOrderService;
import com.lgmma.salesPortal.app.service.SampleOrderService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.props.OrderStatus;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Transactional
@Service
public class SampleOrderServiceImpl implements SampleOrderService {

	private static Logger logger = LoggerFactory.getLogger(SampleOrderServiceImpl.class);

	private final String FNC_SAP_ORDER_LIST = "ZSDE02_DISPLAY_ORDER_STATUS";

	@Autowired
	SampleOrderDao sampleOrderDao;

	@Autowired
	DirectOrderService directOrderService;

	@Autowired
	SapSearchService sapSearchService;

	@Autowired
	private JcoConnector jcoConnector;

	@Autowired
	private CommonService commonService;
	/**
	 * 견본품의조회카운트
	 * @param param
	 * @return
	 */
	@Override
	public int getSampleDocCount(SampleOrderMasterVO param) {
		return sampleOrderDao.getSampleDocCount(param);
	}

	/**
	 * 견본품의조회
	 * @param param
	 * @return
	 */
	@Override
	public List<SampleOrderMasterVO> getSampleDocList(SampleOrderMasterVO param) {
		return sampleOrderDao.getSampleDocList(param);
	}

	/**
	 * 견본조회카운트
	 * @param param
	 * @return
	 */
	@Override
	public int getSampleOrderCount(SampleOrderMasterVO param) {
		return sampleOrderDao.getSampleOrderCount(param);
	}

	/**
	 * 견본조회
	 * @param param
	 * @return
	 */
	@Override
	public List<SampleOrderMasterVO> getSampleOrderList(SampleOrderMasterVO param) {
		List<SampleOrderMasterVO> masterList = sampleOrderDao.getSampleOrderList(param);
		for(SampleOrderMasterVO master : masterList) {
			master.setDistrChanText(sapSearchService.getMasterCodeName("24", StringUtil.isNullToString(master.getDistrChan())));
		}
		//화면에서 넘어온 조회조건이 아닌 조회된 데이터 셋의 확정일 from - to 로 rfc조회범위를 좁힌다.
		//해당 rfc의 일자는 필수
		setSapOrderStatus(masterList, setDateCondition(masterList));

		return masterList;
	}

	private String[] setDateCondition(List<SampleOrderMasterVO> masterList) {
		String fromDate = "";
		String toDate ="";
		for(SampleOrderMasterVO orderVO : masterList) {
			if(orderVO.getReqDateH() != null && !orderVO.getReqDateH().equals("")) {
				fromDate = StringUtils.remove(orderVO.getReqDateH(), '.');
				toDate = StringUtils.remove(orderVO.getReqDateH(), '.');
				break;
			}
		}
		for(SampleOrderMasterVO orderVO : masterList)
			if (!(orderVO.getReqDateH() == null || orderVO.getReqDateH().equals(""))) //noinspection SingleStatementInBlock
			{
				if (Integer.parseInt(fromDate) > Integer.parseInt(StringUtils.remove(orderVO.getReqDateH(), '.'))) {
					fromDate = StringUtils.remove(orderVO.getReqDateH(), '.');
				}
				if (Integer.parseInt(toDate) < Integer.parseInt(StringUtils.remove(orderVO.getReqDateH(), '.'))) {
					toDate = StringUtils.remove(orderVO.getReqDateH(), '.');
				}
			}
		return new String[] {fromDate, toDate};
	}

	private void setSapOrderStatus(List<SampleOrderMasterVO> orderList, String[] dateFromTo) {
		String tempOrderId = "";
		for(SampleOrderMasterVO orderVO : orderList) {
			if(orderVO.getVbeln() != null && !orderVO.getVbeln().equals("")) {
				if(!tempOrderId.equals(orderVO.getVbeln())) { //order id 당 한번씩만 rfc 호출하도록
					tempOrderId = orderVO.getVbeln();
					JcoTableParam tableParam = new JcoTableParam();
					Map<String, Object> inputParams = new HashMap<String, Object>();
					Map<String, Object> erpOrderIdMap = new HashMap<String, Object>();
					List<Map<String, String>> itemList = new ArrayList<>();

					if (!orderVO.getSalesOrg().equals("")) {
						inputParams.put("I_VKORG", orderVO.getSalesOrg());
					}
					inputParams.put("I_GUBUN", "W");

					erpOrderIdMap.put("SIGN", "I");
					erpOrderIdMap.put("OPTION", "EQ");
					erpOrderIdMap.put("LOW", tempOrderId);
					tableParam.put("VBELNRANGE", erpOrderIdMap);

					//조회된 목록의 주문일자로 FROM - TO 설정
					Map<String, Object> dateParamMap = new HashMap<String, Object>();
					dateParamMap.put("SIGN", "I");
					dateParamMap.put("OPTION", "BT");
					dateParamMap.put("LOW", dateFromTo[0]);
					dateParamMap.put("HIGH", dateFromTo[1]);
					tableParam.put("DATERANGE", dateParamMap);

					jcoConnector.executeFunction(FNC_SAP_ORDER_LIST, inputParams, tableParam);
					//sapOrderList
					List<Map<String, Object>> sapOrderList = (List) tableParam.get("T_LIST");
					//출불사유
					List<Map<String, Object>> sapOrderText = (List) tableParam.get("T_TEXT");

					for (Map<String, Object> sapOrder : sapOrderList) {
						for (SampleOrderMasterVO innerOrderVO : orderList) {
							if (sapOrder.get("VBELN").equals(innerOrderVO.getVbeln())) {
								innerOrderVO.setProcStat(sapOrder.get("WBSTK") + "");
								innerOrderVO.setProcStatText(OrderStatus.getStatus(sapOrder.get("WBSTK") + "").getName());
							}
						}
					}
				}
			}
		}
	}

	/**
	 * 견본주문 상세조회
	 *
	 * @param orderId
	 * @return
	 */
	@Override
	public SampleOrderMasterVO getSampleOrderDetail(String orderId) {
		SampleOrderMasterVO sampleOrderMasterVO = new SampleOrderMasterVO();
		sampleOrderMasterVO.setOrderId(orderId);
		sampleOrderMasterVO = (SampleOrderMasterVO) StringUtil.nullToEmptyString(sampleOrderDao.getSampleOrderDetail(sampleOrderMasterVO));
		sampleOrderMasterVO.setOrderItemList(sampleOrderDao.getSampleOrderItemList(orderId));

		directOrderService.setOrderDetailCodeText(sampleOrderMasterVO);
		String[] dateFromTo = {StringUtil.remove(sampleOrderMasterVO.getReqDateH(),'.'),StringUtil.remove(sampleOrderMasterVO.getReqDateH(),'.')};
		setSapOrderDetailStatus(sampleOrderMasterVO,dateFromTo);

		return sampleOrderMasterVO;
	}

	/**
	 * 견본주문 상세 SAP진행 상태 셋팅
	 * @param orderVO
	 * @param dateFromTo
	 */
	private void setSapOrderDetailStatus(SampleOrderMasterVO orderVO, String[] dateFromTo){
		String tempOrderId = "";
		if(orderVO.getVbeln() != null && !orderVO.getVbeln().equals("")) {
			if(!tempOrderId.equals(orderVO.getVbeln())) { //order id 당 한번씩만 rfc 호출하도록
				tempOrderId = orderVO.getVbeln();
				JcoTableParam tableParam = new JcoTableParam();
				Map<String, Object> inputParams = new HashMap<String, Object>();
				Map<String, Object> erpOrderIdMap = new HashMap<String, Object>();
				List<Map<String, String>> itemList = new ArrayList<>();

				if (!orderVO.getSalesOrg().equals("")) {
					inputParams.put("I_VKORG", orderVO.getSalesOrg());
				}
				inputParams.put("I_GUBUN", "W");

				erpOrderIdMap.put("SIGN", "I");
				erpOrderIdMap.put("OPTION", "EQ");
				erpOrderIdMap.put("LOW", tempOrderId);
				tableParam.put("VBELNRANGE", erpOrderIdMap);

				//조회된 목록의 주문일자로 FROM - TO 설정
				Map<String, Object> dateParamMap = new HashMap<String, Object>();
				dateParamMap.put("SIGN", "I");
				dateParamMap.put("OPTION", "BT");
				dateParamMap.put("LOW", dateFromTo[0]);
				dateParamMap.put("HIGH", dateFromTo[1]);
				tableParam.put("DATERANGE", dateParamMap);

				jcoConnector.executeFunction(FNC_SAP_ORDER_LIST, inputParams, tableParam);
				//sapOrderList
				List<Map<String, Object>> sapOrderList = (List) tableParam.get("T_LIST");
				//출불사유
				List<Map<String, Object>> sapOrderText = (List) tableParam.get("T_TEXT");

				for (Map<String, Object> sapOrder : sapOrderList) {
					if (sapOrder.get("VBELN").equals(orderVO.getVbeln())) {
						orderVO.setProcStat(sapOrder.get("WBSTK") + "");
						orderVO.setProcStatText(OrderStatus.getStatus(sapOrder.get("WBSTK") + "").getName());
					}
				}
			}
		}
	}

	/**
	 * 견본주문 테이블 저장
	 *
	 * @param param
	 */
	@Override
	public void createSampleOrder(SampleOrderMasterVO param) {
		param = (SampleOrderMasterVO) StringUtil.nullToEmptyString(param);
		if (param.getOrderItemList().size() > 0) {
			// orderId 생성
			param.setOrderId(Util.getUUID());

			setDateColRemoveFormat(param);

			if (param.getPurchNoC().equals("")) {
				param.setPurchNoC(directOrderService.makePurchNo(param.getDocType()));
			}

			logger.debug(param.toString());
			// 마스터 테이블 저장
			sampleOrderDao.createSampleOrderMaster(param);
			// 아이템 테이블 저장
			createSampleOrderItems(param);

			// voc 연결되어있다면 해당 voc에 orderId 셋팅
			if(param.getVactIdxx().length() > 0){
				sampleOrderDao.updateSampleOrderAfterVocActInfo(param);
			}
		}
	}

	/**
	 * 영업주문테이블에 입력 및 SAP 전송 처리
	 *
	 * @param param
	 */
	@Override
	public void createDirectOrderAndSendErp(SampleOrderMasterVO param) {
		param = (SampleOrderMasterVO) StringUtil.nullToEmptyString(param);
		// 영업주문테이블 생성 및 sap 전송처리
		Map rtMap = new HashMap();
		rtMap = (HashMap)directOrderService.createDirectOrder(param);

		boolean isSuccess = (boolean) rtMap.get("isSuccess");
		String message = (String) rtMap.get("message");

		if(isSuccess) {
			// 전송완료되면 vbeln 저장
			param.setVbeln((String) rtMap.get("vbeln"));
			updateSampleOrder(param);
		} else {
			ServiceException se = new ServiceException();
			se.setErrorMsg(message);
			throw se;
		}

	}

	/**
	 * 견본주문 자재리스트저장
	 *
	 * @param param
	 */
	private void createSampleOrderItems(SampleOrderMasterVO param) {
		int i = 0;
		for (DirectOrderItemVO item : param.getOrderItemList()) {
			item.setOrderId(param.getOrderId());
			i++;
			item.setSeq(i * 10);
			item.setCondPUnt(1);
			item.setRegiIdxx(param.getRegiIdxx());
			item.setUpdtIdxx(param.getUpdtIdxx());
			item.setCurrency(param.getCurrency());// 판매처 마스터의 통화를 맵핑
			item.setReqDate(param.getReqDateH()); // 주문마스터의 요청일을 아이템 요청일에 맵핑
			if (StringUtil.isNullToString(item.getHighValueYn()).equals("")) {
				item.setHighValueYn("N");
			}
			sampleOrderDao.createSampleOrderItem(item);
		}
	}

	/**
	 * 견본주문 수정 프로세스
	 *
	 * @param param
	 */
	@Override
	public void updateSampleOrder(SampleOrderMasterVO param) {
		param = (SampleOrderMasterVO) StringUtil.nullToEmptyString(param);
		if (param.getOrderItemList().size() > 0) {
			setDateColRemoveFormat(param);

			sampleOrderDao.updateSampleOrderMaster(param);
			sampleOrderDao.deleteSampleOrderItems(param);
			createSampleOrderItems(param);
		}
	}

	/**
	 * 데이타의 날짜컬럼의 포맷팅제거
	 * @param param
	 */
	@Override
	public void setDateColRemoveFormat(SampleOrderMasterVO param){
		param.setReqDateH(StringUtil.remove(param.getReqDateH(), '.'));
		param.setPriceDate(param.getReqDateH());
		param.setDocDate(param.getReqDateH());
	}

	/**
	 * 견본주문 수정 후 erp전송프로세스
	 * @param param
	 */
	@Override
	public void updateSampleOrderAndSendErp(SampleOrderMasterVO param) {
		param = (SampleOrderMasterVO) StringUtil.nullToEmptyString(param);
		// 주문반영 및 erp 전송
		try {
			directOrderService.updateDirectOrder(param);
			// 견본 업데이트
			updateSampleOrder(param);
		} catch (ServiceException se) {
			se.printStackTrace();
			throw se;
		}
	}

	/**
	 * 견본주문 삭제 프로세스
	 *
	 * @param param
	 */
	@Override
	public void deleteSampleOrder(SampleOrderMasterVO param) {
		param = (SampleOrderMasterVO) StringUtil.nullToEmptyString(param);
		// 견본 삭제
		sampleOrderDao.deleteSampleOrderMaster(param);
		sampleOrderDao.deleteSampleOrderItems(param);

		// voc 연결되어있다면 해당 voc에서 연결 끊기
		if(param.getVactIdxx().length() > 0){
			param.setApprId("");
			param.setOrderId("");
			sampleOrderDao.updateSampleOrderAfterVocActInfo(param);
		}

	}

	/**
	 * 견본주문 삭제 후 erp전송 process
	 * @param param
	 */
	@Override
	public void deleteSampleOrderAndSendErp(SampleOrderMasterVO param) {
		// 주문삭제반영 및 erp 전송
		try {
			directOrderService.deleteDirectOrder(param);
			deleteSampleOrder(param);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * VOC에서 연결된 견본주문 입력시 디폴트로 고객 요청된 내역을 넣어준다.
	 * @param vactIdxx
	 * @return
	 */
	@Override
	public SampleOrderMasterVO getVocInfo(String vactIdxx) {
			SampleOrderMasterVO sampleOrderMasterVO = new SampleOrderMasterVO();
			sampleOrderMasterVO.setVactIdxx(vactIdxx);
		try {
			sampleOrderMasterVO = (SampleOrderMasterVO) StringUtil.nullToEmptyString(sampleOrderDao.getVocInfo(sampleOrderMasterVO));
			sampleOrderMasterVO.setOrderItemList(sampleOrderDao.getVocItemList(vactIdxx));

			/*인도처 명 맵핑*/
			OrderProdJindVO param = new OrderProdJindVO();
			param.setCompCode(sampleOrderMasterVO.getPartnNumbWe());
			param.setTvkotVkorg(sampleOrderMasterVO.getSalesOrg());
			List<OrderProdJindVO> indoList = commonService.getOrderDeliverList(param);
			if(indoList != null){
				for(OrderProdJindVO indo : indoList){
					if(indo.getPartnNumb().equals(sampleOrderMasterVO.getPartnNumbWe())){
						sampleOrderMasterVO.setPartnNameWe(indo.getName());
					}
				}
			}
			directOrderService.setOrderDetailCodeText(sampleOrderMasterVO);
		}catch (Exception e){
			e.printStackTrace();
		}

		return sampleOrderMasterVO;
	}

	@Override
	public void regSampleOrderFile(SampleOrderMasterVO param) {
		sampleOrderDao.regSampleOrderFile(param);
	}

	@Override
	public void updateSampleOrderCommentAndSendErp(SampleOrderMasterVO param) {
		param = (SampleOrderMasterVO) StringUtil.nullToEmptyString(param);
		// 주문반영 및 erp 전송
		directOrderService.updateCommentText(param);
		// 견본 비고업데이트
		sampleOrderDao.updateSampleOrderComment(param);
	}

}

