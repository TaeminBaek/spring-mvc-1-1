package com.lgmma.salesPortal.app.service.impl;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.dao.CommonDao;
import com.lgmma.salesPortal.app.dao.DirectOrderDao;
import com.lgmma.salesPortal.app.dao.OrderDao;
import com.lgmma.salesPortal.app.dao.SalePriceMasterDao;
import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.ItemDeliveryVO;
import com.lgmma.salesPortal.app.model.OrderHeadVO;
import com.lgmma.salesPortal.app.model.OrderItemVO;
import com.lgmma.salesPortal.app.model.OrderListVO;
import com.lgmma.salesPortal.app.model.OrderProdJindVO;
import com.lgmma.salesPortal.app.model.OrderSaleNameListVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;
import com.lgmma.salesPortal.app.model.SapOrderListVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.DirectOrderService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.OrderService;
import com.lgmma.salesPortal.app.service.SalePriceMasterMgmtService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.props.Konwa;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.props.OrderStatus;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.props.SalePriceMasterPriceListType;
import com.lgmma.salesPortal.common.props.SalePriceMasterSpKind;
import com.lgmma.salesPortal.common.props.SalePriceMasterUnitType;
import com.lgmma.salesPortal.common.util.StringUtil;

@Transactional
@Service
public class OrderServiceImpl implements OrderService {
	
	private final String FNC_SAP_ORDER_LIST = "ZSDE02_DISPLAY_ORDER_STATUS";
	private final String FNC_SAP_ORDER_SHIP_LIST = "ZSDE02_SELECT_SHIPMENT";
	
	private static Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class); 
    @Autowired
    private OrderDao orderDao;
    
    @Autowired
    private SalePriceMasterDao salePriceMasterDao;
    
    @Autowired
    private SalePriceMasterMgmtService salePriceMasterMgmtService;
    
    @Autowired
    private CommonService commonService;
    
    @Autowired
    private CommonDao commonDao;
    
    @Autowired
    private SapSearchService sapSearchService;
    
    @Autowired
	private JcoConnector jcoConnector;
    
	@Autowired
	private DirectOrderService directOrderService;
	
	@Autowired
	private DirectOrderDao directOrderDao;
	
	@Autowired
	private MailingService mailingService;
	
    @Override
	public int getOrderCount(OrderListVO param) {
		return orderDao.getOrderCount(param);
	}

	@Override
	public List<OrderListVO> getOrderList(OrderListVO param) throws Exception {
		List<OrderListVO> orderList = orderDao.getOrderList(param);
		
		//주문 진행상태 rfc call
		//sap에 전송된 건이 있는지 확인
		if(existsSapOrderId(orderList)) {
			//화면에서 넘어온 조회조건이 아닌 조회된 데이터 셋의 확정일 from - to 로 rfc조회범위를 좁힌다.
			//해당 rfc의 일자는 필수
			setSapOrderStatus(param, orderList, setDateCondition(orderList));
		}
		return orderList;
	}
	
	private void setSapOrderStatus(OrderListVO param, List<OrderListVO> orderList, String[] dateFromTo) {
		String tempOrderId = "";
		for(OrderListVO orderVO : orderList) {
			if(orderVO.getErpxIdxx() != null && !orderVO.getErpxIdxx().equals("") && (orderVO.getProcStat().equals(OrderStatus.CONFIRM_ORDER.getCode()) || orderVO.getProcStat().equals(OrderStatus.CONFIRM_MODIFY.getCode()))) {
				if(!tempOrderId.equals(orderVO.getErpxIdxx())) { //order id 당 한번씩만 rfc 호출하도록
					tempOrderId = orderVO.getErpxIdxx();
					JcoTableParam tableParam = new JcoTableParam();
					Map<String, Object> inputParams = new HashMap<String, Object>();
					Map<String, Object> erpOrderIdMap = new HashMap<String, Object>();
					List<Map<String, String>> itemList =new ArrayList<>();

					if (!orderVO.getTvkotVkorg().equals("")) {
						inputParams.put("I_VKORG", orderVO.getTvkotVkorg());
					}
					inputParams.put("I_GUBUN", "W");
/*
 * rfc 에서 판매처를 넘기면 조회 안됨
					//검색조건 으로부터 판매처를 설정
					if(param.getCompCode() != null && !param.getCompCode().equals("")) {
						Map<String, String> saleComp = new HashMap<String, String>();
						saleComp.put("SIGN", "I");
						saleComp.put("OPTION", "EQ");
						saleComp.put("LOW", param.getCompCode());
						saleComp.put("HIGH", null);
						tableParam.put("CUSTOMERRANGE", saleComp);
					}
					
					//검색조건 으로부터 인도처를 설정
					if(param.getJindIdxx() != null && !param.getJindIdxx().equals("")) {
						Map<String, String> deliverComp = new HashMap<String, String>();
						deliverComp.put("SIGN", "I");
						deliverComp.put("OPTION", "EQ");
						deliverComp.put("LOW", param.getJindIdxx());
						deliverComp.put("HIGH", null);
						tableParam.put("KUNNRRANGE", deliverComp);
					}
					
					//검색된 데이터셑 에서 제품코드 설정
					if(param.getJindIdxx() != null && !param.getJindIdxx().equals("")) {	//검색을 하였으면
						for(OrderListVO itemVO : orderList) {
							Map<String, String> orderItem = new HashMap<String, String>();
							orderItem.put("SIGN", "I");
							orderItem.put("OPTION", "EQ");
							orderItem.put("LOW", itemVO.getJproIdxx());
							orderItem.put("HIGH", null);
							itemList.add(orderItem);
						}
						tableParam.put("MATNRRANGE", itemList);
					}
*/
					erpOrderIdMap.put("SIGN", "I");
					erpOrderIdMap.put("OPTION", "EQ");
					erpOrderIdMap.put("LOW", tempOrderId);
					tableParam.put("VBELNRANGE", erpOrderIdMap);

					//조회된 목록의 주문일자로 FROM - TO 설정
					Map<String, Object> dateParamMap = new HashMap<String, Object>();
					dateParamMap.put("SIGN","I");
					dateParamMap.put("OPTION", "BT");
					dateParamMap.put("LOW", dateFromTo[0]);
					dateParamMap.put("HIGH", dateFromTo[1]);
					tableParam.put("DATERANGE", dateParamMap);

					jcoConnector.executeFunction(FNC_SAP_ORDER_LIST, inputParams, tableParam);
					//sapOrderList
					List<Map<String, Object>> sapOrderList = (List) tableParam.get("T_LIST");
					//출불사유
					List<Map<String, Object>> sapOrderText = (List) tableParam.get("T_TEXT");
					
					for(Map<String, Object> sapOrder : sapOrderList) {
						for(OrderListVO innerOrderVO : orderList) {
							if(sapOrder.get("VBELN").equals(innerOrderVO.getErpxIdxx())) {
								innerOrderVO.setProcStat(sapOrder.get("WBSTK") + "");
								innerOrderVO.setProcStatNm(OrderStatus.getStatus(sapOrder.get("WBSTK") + "").getName());
								innerOrderVO.setLfimg(sapOrder.get("LFIMG") + "");
							}
						}
					}
					for(Map<String, Object> sapOrder : sapOrderText) {
						for(OrderListVO innerOrderVO : orderList) {
							if(sapOrder.get("VBELN").equals(innerOrderVO.getErpxIdxx()) && innerOrderVO.getErpxSubx().equals(sapOrder.get("ITM_NUMBER"))) {
								innerOrderVO.setRejectReason(sapOrder.get("TEXT_LINE") + "");
							}
						}
					}
				}
			}
		}
	}

	private String[] setDateCondition(List<OrderListVO> orderList) {
		String fromDate = "";
		String toDate ="";
		for(OrderListVO orderVO : orderList) {
			if(orderVO.getConfDate() != null && !orderVO.getConfDate().equals("")) {
				fromDate = orderVO.getConfDate();
				toDate = orderVO.getConfDate();
				break;
			}
		}
		for(OrderListVO orderVO : orderList) {
			if(orderVO.getConfDate() != null && !orderVO.getConfDate().equals("")) {
				if(Integer.parseInt(fromDate) > Integer.parseInt(orderVO.getConfDate())) {
					fromDate = orderVO.getConfDate();
				}
				if(Integer.parseInt(toDate) < Integer.parseInt(orderVO.getConfDate())) {
					toDate = orderVO.getConfDate();
				}
			}
		}
		return new String[] {fromDate, toDate};
	}

	private boolean existsSapOrderId(List<OrderListVO> orderList) {
		for(OrderListVO orderVO : orderList) {
			if(orderVO.getErpxIdxx() != null && !orderVO.getErpxIdxx().equals(""))
				return true;
		}
		return false;
	}

	@Override
	public int getSapOrderCount(OrderListVO param) throws Exception {
    	getSAPOrderList(param,true);
    	int orderCount = param.getSapOrderList().size();
		return orderCount;
	}

	@Override
	public List<OrderListVO> getSapOrderList(OrderListVO param) throws Exception {
		List<OrderListVO> orderList = new ArrayList();
		getSAPOrderList(param,true);
//		for(SapOrderListVO sapOrderListVO : param.getSapOrderList()) {
		int pageSize = param.getPageSize()+param.getStart();
		if(pageSize > param.getSapOrderList().size()) {
			pageSize = param.getSapOrderList().size();
		}
		for(int i=param.getStart(); i<pageSize; i++ ) {
			
			OrderListVO orderListVO = new OrderListVO();
			orderListVO.setVbeln(param.getSapOrderList().get(i).getVbeln());
			orderListVO.setAudat(param.getSapOrderList().get(i).getAudat());
			orderListVO.setMatnr(param.getSapOrderList().get(i).getMatnr());
			orderListVO.setVdatu(param.getSapOrderList().get(i).getVdatu());
			orderListVO.setName1(param.getSapOrderList().get(i).getName1());
			orderListVO.setKwmeng(param.getSapOrderList().get(i).getKwmeng());
			orderListVO.setLfimg(param.getSapOrderList().get(i).getLfimg());
			orderListVO.setName2(param.getSapOrderList().get(i).getName2());
			orderListVO.setPosnr(param.getSapOrderList().get(i).getPosnr());
			
			orderList.add(orderListVO);
		}
		return orderList;
	}
	
	@Override
	public int getTotOrderCount(OrderListVO param) throws Exception {
		int orderCount = orderDao.getOrderCount(param);
		param.setGubun("X"); 
    	getSAPOrderList(param,true);
    	int orderTotCount = orderCount + param.getSapOrderList().size();
		return orderTotCount;
	}
	
	@Override
	public List<OrderListVO> getTotOrderList(OrderListVO param) throws Exception {
		String keyStat = "";
		List<OrderListVO> orderList = new ArrayList();
		int orderCount = orderDao.getOrderCount(param);
			
		int pageSizeWeb = param.getPageSize()+param.getStart();
		if(pageSizeWeb > orderCount) {
			pageSizeWeb = orderCount;
		}
		if((param.getPageSize()+param.getStart()) < orderCount +10) {
			orderList = orderDao.getOrderList(param);
			
			param.setGubun("T"); //웹주문가져올때
			
			getSAPOrderList(param,false);
			if(orderList.size()>0 && param.getSapOrderList().size()>0) {
				for(OrderListVO orderListVO : orderList) {
					keyStat = orderListVO.getProcStat();
					if(orderListVO.getErpxIdxx() != "" && orderListVO.getErpxIdxx() != null) {
						for(SapOrderListVO sapOrderListVO : param.getSapOrderList()) {
							if(orderListVO.getErpxIdxx().equals(sapOrderListVO.getVbeln())
								&& orderListVO.getCproIdxx().equals(sapOrderListVO.getMatnr())){
								orderListVO.setProcStat(sapOrderListVO.getWbstk());
								orderListVO.setLfimg(sapOrderListVO.getLfimg());
								break;
							}
						}
					}else {
						orderListVO.setProcStat(keyStat);
						orderListVO.setLfimg("0");
					}
				}
			}
		}
		if(param.getStart() > orderCount-10){
			param.setGubun("X"); //ERP주문가져올때
			
			getSAPOrderList(param,true);
			if(!(keyStat.equals("NO")||keyStat.equals("DB")|keyStat.equals("CB"))){
//				for(SapOrderListVO sapOrderListVO : param.getSapOrderList()) {
				int startSap = 0;
				int pageSizeSap = 0;
				if(param.getStart()-pageSizeWeb < 0) {
					startSap= 0;
					pageSizeSap =  param.getPageSize()-(pageSizeWeb-param.getStart());
				}else{
					startSap = param.getStart()-pageSizeWeb;
					pageSizeSap =  param.getPageSize()+(param.getStart()-pageSizeWeb);
				}
				
				if(pageSizeSap > param.getSapOrderList().size()) {
					pageSizeSap = param.getSapOrderList().size();
				}
				for(int i=startSap; i<pageSizeSap; i++ ) {
					OrderListVO orderListVO = new OrderListVO();
					orderListVO.setEordHdid("E-" +param.getSapOrderList().get(i).getVbeln());
					orderListVO.setErpxIdxx(param.getSapOrderList().get(i).getVbeln());
					orderListVO.setEitmHdid("");
					orderListVO.setRegiDate(param.getSapOrderList().get(i).getAudat());
					orderListVO.setJproIdxx(param.getSapOrderList().get(i).getMatnr());
					orderListVO.setAreqDate(param.getSapOrderList().get(i).getVdatu());
					orderListVO.setName1(param.getSapOrderList().get(i).getName1());
					orderListVO.setName2(param.getSapOrderList().get(i).getName2());
					orderListVO.setJumnQtyx(param.getSapOrderList().get(i).getKwmeng());
					orderListVO.setLfimg(param.getSapOrderList().get(i).getLfimg());
					orderListVO.setProcStat(param.getSapOrderList().get(i).getWbstk());
					orderListVO.setErpxSubx(param.getSapOrderList().get(i).getPosnr());
					orderListVO.setJumnBigo("");
					orderList.add(orderListVO);
				}
			}
		}
		return orderList;
	}
	
	public OrderListVO getSAPOrderList(OrderListVO param, boolean isNorList) throws Exception {
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> outputParams = new HashMap<String, Object>();
		Map<String, Object> inputParams = new HashMap<String, Object>();
		String i_stats = "";
		if(isNorList||(!param.getProcStat().equals("OD")&&!param.getProcStat().equals("UD"))) {
			i_stats=param.getProcStat();
		}else {
			param.setProcStat("");
		}
		if (!param.getTvkotVkorg().equals("")) {
			inputParams.put("I_VKORG", param.getTvkotVkorg());
		}
		//		gubun
		if (!param.getGubun().equals("")) {
			inputParams.put("I_GUBUN", param.getGubun());
		}

		if (!i_stats.equals("")) {
			inputParams.put("I_STATS", i_stats);
		}
		Map<String, Object> struct_buyer = new HashMap<String, Object>();
		Map<String, Object> struct_deliver = new HashMap<String, Object>();
		Map<String, Object> struct_product = new HashMap<String, Object>();
		Map<String, Object> struct_sdate = new HashMap<String, Object>();
		List<Map<String, Object>> table =new ArrayList<>();
		List<OrderListVO> sapOrderCompCodeList = orderDao.getSapOrderCompCodeList(param);
		
		if (!param.getSaleComp().equals("")) {
			struct_buyer.put("SIGN", "I");
			struct_buyer.put("OPTION", "EQ");
			struct_buyer.put("LOW", param.getCompCode());
			struct_buyer.put("HIGH", null);
			tableParam.put("CUSTOMERRANGE", struct_buyer);
		} else if (!param.getUserType().equals("") && sapOrderCompCodeList != null && sapOrderCompCodeList.size() > 0) {
			int buyerCnt =0;
			for(OrderListVO orderListVO : sapOrderCompCodeList) {
				struct_buyer.put("SIGN", "I");
				struct_buyer.put("OPTION", "EQ");
				struct_buyer.put("LOW", orderListVO.getKunnr());
				struct_buyer.put("HIGH", null);
				buyerCnt++;
				table.add(struct_buyer);
			}
			if (buyerCnt > 0) {
				tableParam.put("CUSTOMERRANGE", table);
			}
//		}else if (!param.getUserType().equals("") ) {//지정업체가 없고 영업사원도 아니면 결과안보여줌
//			struct_buyer.put("SIGN", "I");
//			struct_buyer.put("OPTION", "EQ");
//			struct_buyer.put("LOW", "9999999999");
//			struct_buyer.put("HIGH", null);
//			tableParam.put("CUSTOMERRANGE", struct_buyer);
		}
		
		if (!param.getJindIdxx().equals("")) {
			struct_deliver.put("SIGN", "I");
			struct_deliver.put("OPTION", "EQ");
			struct_deliver.put("LOW", param.getJindIdxx());
			struct_deliver.put("HIGH", null);
			tableParam.put("KUNNRRANGE", struct_deliver);
		}
		if (!param.getJproIdxx().equals("")) {
			struct_product.put("SIGN", "I");
			struct_product.put("OPTION", "EQ");
			struct_product.put("LOW", param.getJproIdxx());
			struct_product.put("HIGH", null);
			tableParam.put("MATNRRANGE", struct_product);
		}
		if (!param.getSdate().equals("")) {
			struct_sdate.put("SIGN", "I");
			struct_sdate.put("OPTION", "BT");
			struct_sdate.put("LOW", param.getSdate());
			struct_sdate.put("HIGH", param.getEdate());
			tableParam.put("DATERANGE", struct_sdate);
		}
/*
		if (!param.getSdate().equals("")) {
			struct_sdate.put("SIGN", "I");
			struct_sdate.put("OPTION", "BT");
			struct_sdate.put("LOW", param.getSdate());
			struct_sdate.put("HIGH", param.getEdate());
			tableParam.put("VBELNRANGE", struct_sdate);
		}
*/			
			jcoConnector.executeFunction(FNC_SAP_ORDER_LIST ,inputParams ,outputParams ,tableParam);
			//sapOrderList
			List<SapOrderListVO> sapOrderList = (List<SapOrderListVO>) tableParam.get("T_LIST", SapOrderListVO.class);
			//출불사유
			List<SapOrderListVO> sapOrderText = (List<SapOrderListVO>) tableParam.get("T_TEXT", SapOrderListVO.class);
			
			if(sapOrderList.size() > 0)
				param.setSapOrderList(sapOrderList);
			if(sapOrderText.size() > 0)
				param.setSapOrderText(sapOrderText);
			
		return param;
	}
	
	@Override
	public OrderHeadVO getOrderDetail(OrderHeadVO param) {
		OrderItemVO itemVo = new OrderItemVO();
		itemVo.setEordHdid(param.getEordHdid());
		OrderHeadVO orderHeadVo = orderDao.getOrderDetail(param);
		orderHeadVo.setItemList(orderDao.getOrderItemList(itemVo));
		//배송정보
		orderHeadVo.setItemDeliveryList(getOrderItemDeliveryList(orderHeadVo.getItemList()));
		//주문 진행상태, 인도처 전화번호를 rfc 로 조회
		for(OrderItemVO item : orderHeadVo.getItemList()) {
			if(!item.getJindIdxx().equals("NEW")) {
				OrderProdJindVO jindVo = new OrderProdJindVO();
				jindVo.setJindIdxx(item.getJindIdxx());
				item.setJindTelNo(commonService.getOrderJindSearch(jindVo).get(0).getTELF1());
			}
			if(item.getErpxIdxx() != null && !item.getErpxIdxx().equals("")) {
				//출하수량
				setShippingAmount(item);
				//진행상태
				setOrderStatus(orderHeadVo, item);
			}
		}
		return orderHeadVo;
	}
	
	private void setOrderStatus(OrderHeadVO head, OrderItemVO item) {
		String tempOrderId = item.getErpxIdxx();
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> inputParams = new HashMap<String, Object>();
		Map<String, Object> erpOrderIdMap = new HashMap<String, Object>();
		List<Map<String, String>> itemList =new ArrayList<>();

		if (!head.getTvkotVkorg().equals("")) {
			inputParams.put("I_VKORG", head.getTvkotVkorg());
		}
		inputParams.put("I_GUBUN", "W");

		//판매처
		if(head.getCompCode() != null && !head.getCompCode().equals("")) {
			Map<String, String> saleComp = new HashMap<String, String>();
			saleComp.put("SIGN", "I");
			saleComp.put("OPTION", "EQ");
			saleComp.put("LOW", head.getCompCode());
			saleComp.put("HIGH", null);
			tableParam.put("CUSTOMERRANGE", saleComp);
		}
		
		//인도처
		if(item.getJindIdxx() != null && !item.getJindIdxx().equals("")) {
			Map<String, String> deliverComp = new HashMap<String, String>();
			deliverComp.put("SIGN", "I");
			deliverComp.put("OPTION", "EQ");
			deliverComp.put("LOW", item.getJindIdxx());
			deliverComp.put("HIGH", null);
			tableParam.put("KUNNRRANGE", deliverComp);
		}
		
		//확정제품
		if(item.getCproIdxx() != null && item.getCproIdxx().equals("")) {
			Map<String, String> orderItem = new HashMap<String, String>();
			orderItem.put("SIGN", "I");
			orderItem.put("OPTION", "EQ");
			orderItem.put("LOW", item.getCproIdxx());
			orderItem.put("HIGH", null);
			tableParam.put("MATNRRANGE", itemList);
		}

		erpOrderIdMap.put("SIGN", "I");
		erpOrderIdMap.put("OPTION", "EQ");
		erpOrderIdMap.put("LOW", tempOrderId);
		tableParam.put("VBELNRANGE", erpOrderIdMap);

		//주문일자
		Map<String, Object> dateParamMap = new HashMap<String, Object>();
		dateParamMap.put("SIGN","I");
		dateParamMap.put("OPTION", "EQ");
		dateParamMap.put("LOW", StringUtil.replace(item.getConfDate(),".","").substring(0, 8));
//		dateParamMap.put("HIGH", StringUtil.replace(item.getConfDate(),".","").substring(0, 8));
		tableParam.put("DATERANGE", dateParamMap);

		jcoConnector.executeFunction(FNC_SAP_ORDER_LIST, inputParams, tableParam);
		//sapOrderList
		List<Map<String, Object>> sapOrderList = (List) tableParam.get("T_LIST");
		//출불사유
		List<Map<String, Object>> sapOrderText = (List) tableParam.get("T_TEXT");
		
		for(Map<String, Object> sapOrder : sapOrderList) {
			if(sapOrder.get("VBELN").equals(item.getErpxIdxx())) {
				item.setProcStat(sapOrder.get("WBSTK") + "");
				item.setProcStatNm(OrderStatus.getStatus(sapOrder.get("WBSTK") + "").getName());
			}
		}
		for(Map<String, Object> sapOrder : sapOrderText) {
			if(sapOrder.get("VBELN").equals(item.getErpxIdxx()) && item.getErpxSubx().equals(sapOrder.get("ITM_NUMBER"))) {
				item.setRejectReason(sapOrder.get("TEXT_LINE") + "");
			}
		}
	}

	private void setShippingAmount(OrderItemVO orderItem) {
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> inputParams = new HashMap<String, Object>();
		Map<String, Object> outputParams = null;
		
		inputParams.put("I_VKORG", orderItem.getTvkotvkorg());
		
		List<Map<String, Object>> table =new ArrayList<>();
		
		Map<String, Object> row = new HashMap<String, Object>();
		
		row.put("VBELN", orderItem.getErpxIdxx());
		row.put("POSNR", orderItem.getErpxSubx());
		table.add(row);
		tableParam.put("T_INPUT",table);
		
		List<SapOrderListVO> orderDetailItemLfimg = null;
		jcoConnector.executeFunction(FNC_SAP_ORDER_SHIP_LIST ,inputParams ,outputParams ,tableParam);
		orderDetailItemLfimg = (List<SapOrderListVO>) tableParam.get("T_LIST", SapOrderListVO.class);

		float lfimg = 0;
		for(SapOrderListVO sapOrderListVO : orderDetailItemLfimg) {
			if(orderItem.getErpxSubx().equals(sapOrderListVO.getPosnv())) {
				lfimg += Float.parseFloat(StringUtil.isNullToString(sapOrderListVO.getLfimg()));
			}
		}
		orderItem.setLfimg(String.valueOf(lfimg));
	}

	@Override
	public List<OrderItemVO> getOrderItemList(OrderItemVO param) throws Exception {
		
		List<OrderItemVO> orderDetailItemList = orderDao.getOrderItemList(param);
/*		
		for(OrderItemVO orderItemVO : orderDetailItemList) {
			if(orderItemVO.getErpxIdxx() != "" && orderItemVO.getErpxIdxx() != null) {
				JcoTableParam tableParam = new JcoTableParam();
				Map<String, Object> inputParams = new HashMap<String, Object>();
				Map<String, Object> outputParams = null;
				
				inputParams.put("I_VKORG",orderItemVO.getTvkotvkorg());
				
				List<Map<String, Object>> table =new ArrayList<>();
				
				Map<String, Object> row = new HashMap<String, Object>();
				
				row.put("VBELN", orderItemVO.getErpxIdxx());
				row.put("POSNR", orderItemVO.getErpxSubx());
				table.add(row);
				tableParam.put("T_INPUT",table);
				
				List<SapOrderListVO> orderDetailItemLfimg = null;
				jcoConnector.executeFunction(FNC_SAP_ORDER_SHIP_LIST ,inputParams ,outputParams ,tableParam);
				orderDetailItemLfimg = (List<SapOrderListVO>) tableParam.get("T_LIST", SapOrderListVO.class);
		
				float lfimg = 0;
				for(SapOrderListVO sapOrderListVO : orderDetailItemLfimg) {
					if(orderItemVO.getErpxSubx().equals(sapOrderListVO.getPosnv())) {
						lfimg += Float.parseFloat(StringUtil.isNullToString(sapOrderListVO.getLfimg()));
					}
				}
				orderItemVO.setLfimg(String.valueOf(lfimg));
			}
		}
*/
		return orderDetailItemList;
		 
	}
	
	@Override
	public int getSaleNameCount(OrderSaleNameListVO param) {
		int saleNameCount = orderDao.getSaleNameCount(param);
		return saleNameCount;
	}
	
	@Override
	public List<OrderSaleNameListVO> getSaleNameList(OrderSaleNameListVO param) throws Exception {
		List<OrderSaleNameListVO> saleNameList = orderDao.getSaleNameList(param);
		return saleNameList;
	}
	
	@Override
	public void createOrder(OrderHeadVO param) throws Exception {
		orderDao.createOrderHead(param);
		for(OrderItemVO vo : param.getItemList()) {
			vo.setEordHdid(param.getEordHdid());
			vo.setUpdtIdxx(param.getUpdtIdxx());
			orderDao.createOrderItem(vo);
		}
	}
	
	@Override
	public void updateOrderItem(List<OrderItemVO> param) throws Exception {
		for(OrderItemVO vo : param) {
			orderDao.updateOrderItem(vo);
		}
	}
	
	@Override
	public void deleteOrderItem(List<OrderItemVO> param) throws Exception {
		for(OrderItemVO vo : param) {
			orderDao.deleteOrderItem(vo);
		}
	}
	
	@Override
	public int getOrderConfirmCount(OrderListVO param) {
		return  orderDao.getOrderConfirmCount(param);
	}

	@Override
	public List<OrderListVO> getOrderConfirmList(OrderListVO param) throws Exception {
		return orderDao.getOrderConfirmList(param);
	}
	
	@Override
	public OrderHeadVO getOrderConfirmDetail(OrderHeadVO param) {
		return orderDao.getOrderConfirmDetail(param);
	}
	
	@Override
	public List<OrderItemVO> getOrderConfirmItemList(OrderItemVO param) throws Exception {
		return orderDao.getOrderConfirmItemList(param);
		 
	}

	@Override
	public List<ItemDeliveryVO> getOrderDeliveryInfo(int eordHdid) {
		OrderItemVO param = new OrderItemVO();
		param.setEordHdid(eordHdid);
		List<OrderItemVO> orderItemList = orderDao.getOrderItemList(param);
		return getOrderItemDeliveryList(orderItemList);
	}

	private List<ItemDeliveryVO> getOrderItemDeliveryList(List<OrderItemVO> orderItemList) {
		List<ItemDeliveryVO> itemDeliveryVOList = new ArrayList<ItemDeliveryVO>();

		if(orderItemList.size() > 0) {
			Map<String, Object> inputParams = new HashMap<String, Object>();
			inputParams.put("I_VKORG", orderItemList.get(0).getTvkotvkorg());

			JcoTableParam tableParam = new JcoTableParam();
			List<Map<String, Object>> table =new ArrayList<>();
			
			for(OrderItemVO orderItemVO : orderItemList) {
				if(orderItemVO.getErpxIdxx() != null && !orderItemVO.getErpxIdxx().equals("")) {
					Map<String, Object> row = new HashMap<String, Object>();
					row.put("VBELN", orderItemVO.getErpxIdxx());
					row.put("POSNR", orderItemVO.getErpxSubx());
					table.add(row);
				}
			}
			tableParam.put("T_INPUT",table);
			
			jcoConnector.executeFunction(FNC_SAP_ORDER_SHIP_LIST, inputParams, tableParam);
			itemDeliveryVOList = (List<ItemDeliveryVO>) tableParam.get("T_LIST", ItemDeliveryVO.class);
		}

		for(OrderItemVO orderItemVO : orderItemList) {
		    float lfimg = 0;
		    for (ItemDeliveryVO itemDeliveryVO : itemDeliveryVOList) {
				if(orderItemVO.getErpxSubx().equals(itemDeliveryVO.getPosnv())){
					itemDeliveryVO.setVtwegName(sapSearchService.getMasterCodeName("24", orderItemVO.getTvtwtVtext()));
			    	itemDeliveryVO.setVsbedName(sapSearchService.getMasterCodeName("23", orderItemVO.getTbsbtVtext()));
			    	itemDeliveryVO.setAreqDate(orderItemVO.getAreqDate());
			    	itemDeliveryVO.setCdepBigo(orderItemVO.getCdepBigo());
			    	itemDeliveryVO.setDealBigo(orderItemVO.getDealBigo());
			    	itemDeliveryVO.setCustBigo(orderItemVO.getCustBigo());
				    lfimg +=  Float.parseFloat(StringUtil.nullConvert(itemDeliveryVO.getLfimg()));
				}
		    }
		    orderItemVO.setLfimg(String.valueOf(lfimg));
		}
	    for (ItemDeliveryVO itemDeliveryVO : itemDeliveryVOList) {
	    	itemDeliveryVO.setWerksName(sapSearchService.getMasterCodeName("04", itemDeliveryVO.getWerks()));
	    	itemDeliveryVO.setLgortName(sapSearchService.getMasterCodeName("15", itemDeliveryVO.getLgort()));
	    }
		return itemDeliveryVOList;
	}

	@Override
	public OrderHeadVO getOrderDetailForUpdate(OrderHeadVO param) {
		OrderItemVO itemVo = new OrderItemVO();
		itemVo.setEordHdid(param.getEordHdid());
		OrderHeadVO orderHeadVo = orderDao.getOrderDetail(param);
		orderHeadVo.setItemList(orderDao.getOrderItemList(itemVo));
		//erp id 가 존재하면 exception
		for(OrderItemVO item : orderHeadVo.getItemList()) {
			if(!StringUtil.nullConvert(item.getErpxIdxx()).equals(""))
				throw new ServiceException("fail.order.erpid.exists");
		}
		return orderHeadVo;
	}

	@Override
	public void updateOrder(OrderHeadVO param) {
		OrderItemVO itemVo = new OrderItemVO();
		itemVo.setEordHdid(param.getEordHdid());
		List<OrderItemVO> itemList = orderDao.getOrderItemList(itemVo);
		//erp id 가 존재하면 수정불가 exception
		for(OrderItemVO item : itemList) {
			if(!StringUtil.nullConvert(item.getErpxIdxx()).equals(""))
				throw new ServiceException("fail.order.erpid.exists");
		}
		orderDao.updateOrderHead(param);
		orderDao.deleteAllOrderItem(param);
		for(OrderItemVO vo : param.getItemList()) {
			vo.setEordHdid(param.getEordHdid());
			vo.setUpdtIdxx(param.getUpdtIdxx());
			orderDao.createOrderItem(vo);
		}
	}

	@Override
	public void deleteOrder(OrderHeadVO param) {
		OrderItemVO itemVo = new OrderItemVO();
		itemVo.setEordHdid(param.getEordHdid());
		List<OrderItemVO> itemList = orderDao.getOrderItemList(itemVo);
		//erp id 가 존재하면 삭제불가 exception
		for(OrderItemVO item : itemList) {
			if(!StringUtil.nullConvert(item.getErpxIdxx()).equals(""))
				throw new ServiceException("fail.order.erpid.exists");
		}
		orderDao.deleteAllOrderItem(param);
		orderDao.deleteOrderHead(param);
	}

	@Override
	public OrderHeadVO getOrderHead(OrderHeadVO param) {
		return orderDao.getOrderDetail(param);
	}

	@Override
	public void confirmOrder(OrderHeadVO head) {
		OrderHeadVO orderHead = (OrderHeadVO)StringUtil.nullToEmptyString(orderDao.getOrderDetail(head));

		//확정 제품의 판가가 존재하는지 확인하고 해당 판가로 변경
		checkSalesPriceExists(head);

		//화면에서 넘어온 값으로 치환 하고 전송후 update 수행
		orderHead.setCoaxIsxx(head.getCoaxIsxx());
		orderHead.setVeslCond(head.getVeslCond());
		orderHead.setSaleManCode(head.getSaleManCode());
		orderHead.setSaleManName(head.getSaleManName());
		orderHead.setBigoText(StringUtil.nullConvert(orderHead.getBigoText()));
		orderHead.setVkbur(head.getVkbur());
		orderHead.setDivision(head.getDivision());

		List<OrderItemVO> toConfirmItems = new ArrayList<OrderItemVO>();

		int itemIndex = 0;
		for(OrderItemVO item : head.getItemList()) {
			OrderItemVO oriItem = orderDao.getOrderItem(item);
			//이미 전송된 건인지 다시 확인
			if(!StringUtil.nullConvert(oriItem.getErpxIdxx()).equals(""))
				throw new ServiceException("fail.order.erpid.exists");
			//처리된주문 인지 다시 확인
			if(!StringUtil.nullConvert(oriItem.getProcStat()).equals(OrderStatus.NEW_ORDER.getCode()) && !StringUtil.nullConvert(oriItem.getProcStat()).equals(OrderStatus.CONFIRM_HOLD.getCode()))
				throw new ServiceException("fail.order.not.new");
			
			oriItem.setProcStat(OrderStatus.CONFIRM_ORDER.getCode());
			//수량이나 제품코드가 다르면 수정확정
			if(item.getConfQtyx() != oriItem.getJumnQtyx()) {
				oriItem.setProcStat(OrderStatus.CONFIRM_MODIFY.getCode());
			}
			if(item.getCproIdxx().equals(oriItem.getJproIdxx())) {
				oriItem.setProcStat(OrderStatus.CONFIRM_MODIFY.getCode());
			}
			//화면에서 넘어온 값으로 치환 하고 전송후 update 수행
			itemIndex++;
			oriItem.setErpxSubx(String.format("%06d", itemIndex * 10));
			oriItem.setCindIdxx(item.getJindIdxx());	//인도처
			oriItem.setCindAddr(item.getJindAddr());	//인도처 주소
			oriItem.setJindIdxx(item.getJindIdxx());	//인도처
			oriItem.setJindAddr(item.getJindAddr());	//인도처 주소
			oriItem.setJindName(item.getJindName());	//인도처 명
			oriItem.setCproIdxx(item.getCproIdxx());	//제품
			oriItem.setCproName(item.getCproIdxx());	//제품
			oriItem.setJumnQtyx(item.getJumnQtyx());	//주문수량(확정시 MMA는 드럼일때 KG 의 주문수량이 넘어온다. JSP 에서 MAAD 는 * 195 나머지는 *180)
			oriItem.setConfQtyx(item.getConfQtyx());	//수량
			oriItem.setConfDrum(item.getConfDrum());	//드럼
			oriItem.setConfPric(item.getConfPric());	//가격
			oriItem.setCurrency(item.getCurrency());	//단위
			oriItem.setArriDate(StringUtil.replace(item.getArriDate(), ".", ""));
			oriItem.setArriTime(item.getArriTime());
			oriItem.setTvtwtVtweg(item.getTvtwtVtweg());	//유통경로
			oriItem.setTvtwtVtext(sapSearchService.getMasterCodeName("24", item.getTvtwtVtweg()));	//유통경로명
			oriItem.setT001wWerks(item.getT001wWerks());	//플랜트
			oriItem.setT001wName1(sapSearchService.getMasterCodeName("04", item.getT001wWerks()));	//플랜트명
			oriItem.setDreqDate(StringUtil.replace(item.getDreqDate(), ".", ""));	//납품요청일 확정
			oriItem.setT001lTgort(item.getT001lTgort());	//저장위치ID 확정
			oriItem.setT001lLgobe(sapSearchService.getMasterCodeName("15", item.getT001lTgort()));	//저장위치명
			oriItem.setTbsbtVsbed(item.getTbsbtVsbed());	//출하조건ID 확정
			oriItem.setTbsbtVtext(sapSearchService.getMasterCodeName("23", item.getTbsbtVsbed()));	//출하조건명
			oriItem.setCdepBigo(item.getCdepBigo());	//
			oriItem.setDealBigo(item.getDealBigo());	//
			oriItem.setCustBigo(item.getCustBigo());	//
			
			toConfirmItems.add(oriItem);
		}

		//먼저 업데이트 한다고 겁먹지 마라... 전송 실패하면 exception 띄우고 자동 롤백한다. 전송 성공해도 db update 시 오류가 나면 더 큰일난다. 
		orderDao.updateOrderHead(orderHead);
		for(OrderItemVO item : toConfirmItems){
			//null 이 select 되면 업데이트시 오류가 발생하여 null String 으로 변환
			item = (OrderItemVO) StringUtil.nullToEmptyString(item);
			item.setUpdtIdxx  (head.getUpdtIdxx());	//세션에서 자동 바인딩 되므로 현재 사용자
			item.setCmanIdxx  (head.getUpdtIdxx());
			item.setConfDate  ("Y");

			orderDao.updateConfirmOrderItem(item);
		}

		//DirectOrderMasterVO 생성하여 신규 rfc로 전송한다.
		DirectOrderMasterVO directOrder = new DirectOrderMasterVO();
		directOrder.setDocType    (OrderType.ESALES.getCode());
		directOrder.setSalesOrg   (orderHead.getTvkotVkorg());
		directOrder.setDistrChan  (toConfirmItems.get(0).getTvtwtVtweg());
		directOrder.setPurchNoC   (head.getEordHdid() + "");
		//directOrder.setDivision   (head.getTvkotVkorg().equals("3000")?"30":"10");
		directOrder.setDivision   (head.getDivision());
		directOrder.setReqDateH   (toConfirmItems.get(0).getDreqDate());
		directOrder.setShipType   (head.getVeslCond().equals("S") ? "M4" : "M1");	//운임조건
		directOrder.setShipCond   (toConfirmItems.get(0).getTbsbtVsbed());	//인도조건
		directOrder.setIncoterms1 (head.getVeslCond().equals("S") ? "Z01" : "Z02"); //출하조건
		//PRICE_LIST 는 ITEM 으로 이동, 하지만 화면상에는 HEADER 에 유지 -> 이미 들어온 주문 아이템 이라서 개별 PRICE_LIST 적용이 힘들다.
		//directOrder.setPriceList  (head.getPartnNumbZ7().equals("") ? head.getPriceList() : SalePriceMasterPriceListType.PLTYP_REGULAR.getCode());
		directOrder.setPartnNumbAg(head.getCompCode());
		directOrder.setCompCode   (orderHead.getSaleComp());
		directOrder.setPartnNumbWe(toConfirmItems.get(0).getCindIdxx());	//확정인도처
		directOrder.setPartnNumbVe(orderHead.getSaleManCode());	//영업사원
		directOrder.setPartnNumbZ7(head.getPartnNumbZ7());	//실제인도처
		directOrder.setPartnNameWe(toConfirmItems.get(0).getJindName());
		directOrder.setPartnNameZ7(head.getPartnNameZ7());
		directOrder.setBigoZ001   (toConfirmItems.get(0).getDealBigo());
		directOrder.setBigoZ002   (toConfirmItems.get(0).getCdepBigo());
		directOrder.setBigoZ025   (toConfirmItems.get(0).getCustBigo());
		directOrder.setRegiIdxx   (head.getRegiIdxx());
		directOrder.setUpdtIdxx   (head.getUpdtIdxx());
		directOrder.setVkbur	  (head.getVkbur());
		
		directOrder = (DirectOrderMasterVO) StringUtil.nullToEmptyString(directOrder);

		if(toConfirmItems.size() > 0) {
			List<DirectOrderItemVO> itemList = new ArrayList<DirectOrderItemVO>();
			for(OrderItemVO item : toConfirmItems){
				DirectOrderItemVO directOrderItem = new DirectOrderItemVO();
				directOrderItem.setMaterial(item.getCproIdxx());
				directOrderItem.setPlant(item.getT001wWerks());
				directOrderItem.setStoreLoc(item.getT001lTgort());
				directOrderItem.setReqQty(item.getConfQtyx());
				directOrderItem.setCondUnit(SalePriceMasterUnitType.SP_UNIT_TYPE_KG.getCode());
				directOrderItem.setCondPUnt(1);
				directOrderItem.setPriceListI(head.getPartnNumbZ7().equals("") ? head.getPriceList() : SalePriceMasterPriceListType.PLTYP_REGULAR.getCode());
				directOrderItem.setReqDate(item.getDreqDate());
				directOrderItem.setCurrency(item.getCurrency());
				directOrderItem.setPr00Price(item.getConfPric());
				directOrderItem.setHighValueYn(item.getHighValueYn());
				directOrderItem.setHighValue(item.getHighValueYn().equals("Y") ? item.getHighValue() : "");
				directOrderItem.setRegiIdxx   (head.getRegiIdxx());
				directOrderItem.setUpdtIdxx   (head.getUpdtIdxx());
				itemList.add((DirectOrderItemVO) StringUtil.nullToEmptyString(directOrderItem));
			}
			directOrder.setOrderItemList(itemList);

			Map result = directOrderService.createDirectOrder(directOrder);
			String erpxIdxx = (String) result.get("vbeln");
			
			if(!erpxIdxx.equals("")) {
				for(OrderItemVO item : toConfirmItems){
					item.setErpxIdxx(erpxIdxx);
					orderDao.updateConfirmOrderItem(item);
				}
				if(!orderHead.getRegiIdxx().equals(head.getUpdtIdxx())) {	//if 가 굳이 필요한지 모르겠음
					Map<String, String> param = new HashMap<String, String>();
					param.put("gubnIdxx", "C");
					param.put("lognIdxx", orderHead.getRegiIdxx());
					Map receiver = commonDao.getMemberNameMail(param);
					
					param.put("gubnIdxx", "S");
					param.put("lognIdxx", head.getUpdtIdxx());
					Map sender = commonDao.getMemberNameMail(param);

					Map paramMap = new HashMap();
					paramMap.put("HEAD", orderHead);
					paramMap.put("ITEMS", toConfirmItems);

					SendMailVO sendMailVO = new SendMailVO();
					sendMailVO.setMailType(MailType.WEB_ORDER_CONFIRM_TO_CUSTOMER);
					sendMailVO.setSenderEmail(sender.get("LOGN_NAME") + "<" + sender.get("LOGN_MAIL") + ">");
					sendMailVO.setReceiverEmail(receiver.get("LOGN_MAIL") + "");
					sendMailVO.setReceiverName(receiver.get("LOGN_NAME") + "");
					sendMailVO.setParams(paramMap);

					mailingService.sendMail(sendMailVO);
				}

			}
		}
	}

	private void checkSalesPriceExists(OrderHeadVO head) {
		//확정 제품의 판가가 존재하는지 확인
		for(OrderItemVO item : head.getItemList()) {
			SalePriceMasterVO param = new SalePriceMasterVO();
			param.setVkorg(head.getTvkotVkorg());
			param.setVtweg(item.getTvtwtVtweg());
			param.setKunnr(head.getCompCode());
			if(head.getPartnerYn().equals("Y") && !head.getPartnNumbZ7().equals("")) {	//파트너사 이면서 실제인도처로 판가를 찾을때
				param.setSpTypeKind(SalePriceMasterSpKind.SP_TYPE_KIND_PATNR.getCode());
				param.setSpType(head.getPartnNumbZ7());
			} else {
				param.setSpTypeKind(SalePriceMasterSpKind.SP_TYPE_KIND_PLTYP.getCode());
				param.setSpType(head.getPriceList());
			}
			param.setIndoKunnr(item.getJindIdxx());
			param.setMatnr(item.getCproIdxx());
			param.setKonwa(Konwa.KRW.getCode());
			param.setFullMatchYn("Y");
			param.setSearchDate(StringUtil.remove(item.getDreqDate(), '.'));
			param.setStart(0);
			param.setPageSize(10);
			List<SalePriceMasterVO> priceList = salePriceMasterDao.getsalePriceMasterList(param);

			StringBuffer message = new StringBuffer();
			message.append("확정제품코드 " + item.getCproIdxx()+ " 의 단가가\n")
			.append("유통경로 " + item.getTvtwtVtweg()+ " 의\n")
			.append("인도처 " + item.getJindIdxx()+ " 의\n")
			.append(SalePriceMasterSpKind.getSalePriceMasterSpKind(param.getSpTypeKind()).getName() + " 의\n");
			if(SalePriceMasterSpKind.getSalePriceMasterSpKind(param.getSpTypeKind()) == SalePriceMasterSpKind.SP_TYPE_KIND_PATNR) {
				message.append("실제인도처 " + head.getPartnNumbZ7() + " 의\n");
			} else {
				message.append(SalePriceMasterPriceListType.getSalePriceMasterPriceListType(param.getSpType()).getName() + " 의\n");
			}
			message.append("단가 단위 킬로그램의\n")
			.append("납품요청일 " + item.getDreqDate()+ " 의 유효기간내에 존재하지 않습니다.\n");

			if(priceList.size() == 0) {
				ServiceException se = new ServiceException();
				se.setErrorMsg(message.toString());
				throw se;
			} else if(!priceList.get(0).getKmein().equals(SalePriceMasterUnitType.SP_UNIT_TYPE_KG.getCode())){
				ServiceException se = new ServiceException();
				se.setErrorMsg(message.toString());
				throw se;
			} else {
				//납품요청일의 단가로
				item.setConfPric(priceList.get(0).getPrice());
				item.setCurrency(priceList.get(0).getKonwa());
			}
		}
	}

	@Override
	public void rejectOrder(OrderHeadVO head) {
		OrderHeadVO orderHead = orderDao.getOrderDetail(head);
		List<OrderItemVO> toConfirmItems = new ArrayList<OrderItemVO>();

		for(OrderItemVO item : head.getItemList()) {
			OrderItemVO oriItem = orderDao.getOrderItem(item);
			//이미 전송된 건인지 다시 확인
			if(!StringUtil.nullConvert(oriItem.getErpxIdxx()).equals(""))
				throw new ServiceException("fail.order.erpid.exists");
			//처리된주문 인지 다시 확인
			if(!StringUtil.nullConvert(oriItem.getProcStat()).equals(OrderStatus.NEW_ORDER.getCode()))
				throw new ServiceException("fail.order.not.new");

			oriItem.setCustBigo(item.getCustBigo());	//고객 비고
			oriItem.setProcStat(item.getProcStat());	//상태
			toConfirmItems.add(oriItem);
		}
		for(OrderItemVO item : toConfirmItems){
			//null 이 select 되면 업데이트시 오류가 발생하여 null String 으로 변환
			item = (OrderItemVO) StringUtil.nullToEmptyString(item);
			item.setUpdtIdxx  (head.getUpdtIdxx());	//세션에서 자동 바인딩 되므로 현재 사용자
			item.setCmanIdxx  (head.getUpdtIdxx());
			item.setConfDate  ("Y");

			orderDao.updateConfirmOrderItem(item);
		}
		if(!orderHead.getRegiIdxx().equals(head.getUpdtIdxx())) {	//if 가 굳이 필요한지 모르겠음
			Map<String, String> param = new HashMap<String, String>();
			param.put("gubnIdxx", "C");
			param.put("lognIdxx", orderHead.getRegiIdxx());
			Map receiver = commonDao.getMemberNameMail(param);
			
			param.put("gubnIdxx", "S");
			param.put("lognIdxx", head.getUpdtIdxx());
			Map sender = commonDao.getMemberNameMail(param);

			Map paramMap = new HashMap();
			paramMap.put("HEAD", orderHead);
			paramMap.put("ITEMS", toConfirmItems);

			SendMailVO sendMailVO = new SendMailVO();
			if(toConfirmItems.get(0).getProcStat().equals(OrderStatus.CONFIRM_HOLD.getCode())) {
				sendMailVO.setMailType(MailType.WEB_ORDER_CONFIRM_HOLD_CUSTOMER);
			} else if(toConfirmItems.get(0).getProcStat().equals(OrderStatus.SHIPPING_REJECT.getCode())) {
				sendMailVO.setMailType(MailType.WEB_ORDER_SHIPPING_REJECT_TO_CUSTOMER);
			}
			sendMailVO.setSenderEmail(sender.get("LOGN_NAME") + "<" + sender.get("LOGN_MAIL") + ">");
			sendMailVO.setReceiverEmail(receiver.get("LOGN_MAIL") + "");
			sendMailVO.setReceiverName(receiver.get("LOGN_NAME") + "");
			sendMailVO.setParams(paramMap);

			mailingService.sendMail(sendMailVO);
		}
	}

	@Override
	public OrderHeadVO getOrderDetailForCopy(OrderHeadVO param) {
		OrderItemVO itemVo = new OrderItemVO();
		itemVo.setEordHdid(param.getEordHdid());
		OrderHeadVO orderHeadVo = orderDao.getOrderDetail(param);
		orderHeadVo.setItemList(orderDao.getOrderItemList(itemVo));
		return orderHeadVo;
	}

	@Override
	public OrderHeadVO getConfirmedEaslesOrderDetail(String orderId) {
		DirectOrderMasterVO directOrderMaster = new DirectOrderMasterVO();
		directOrderMaster.setPageSize(10);
		directOrderMaster.setStart(0);
		directOrderMaster.setOrderId(orderId);

		directOrderMaster = (DirectOrderMasterVO) StringUtil.nullToEmptyString(directOrderDao.getDirectOrderDetail(directOrderMaster));
		List<DirectOrderItemVO> directOrderItemList = directOrderDao.getDirectOrderItemList(directOrderMaster.getOrderId());
		//esales 원주문 head
		OrderHeadVO orderHeadVo = orderDao.getConfirmedEaslesOrderHead(orderId);
		if(orderHeadVo != null && !directOrderMaster.getVbeln().equals("") ) {
			OrderItemVO itemVo = new OrderItemVO();
			itemVo.setEordHdid(orderHeadVo.getEordHdid());
			itemVo.setErpxIdxx(directOrderMaster.getVbeln());
			//esales 원주문 items
			orderHeadVo.setItemList(orderDao.getOrderItemList(itemVo));
			for(OrderItemVO item : orderHeadVo.getItemList()) {
				//코드값 세팅
				setOrderDetailCodeText(item);
				//고부가 등 추가정보를 directOrderItemList 에서
				for(DirectOrderItemVO directOrderItem : directOrderItemList) {
					//판가유형은 orderHeadVo에 있는 값을 사용하고 모든 아이템에서 동일하다.  
					orderHeadVo.setPriceList(directOrderItem.getPriceListI());
					if(Integer.parseInt(item.getErpxSubx()) == directOrderItem.getSeq()) {
						item.setHighValueYn(directOrderItem.getHighValueYn());
						item.setHighValue(directOrderItem.getHighValue());
					}
				}
			}
			orderHeadVo.setPartnNumbZ7(directOrderMaster.getPartnNumbZ7());
			orderHeadVo.setPartnNameZ7(directOrderMaster.getPartnNameZ7());
		} else {
			throw new ServiceException("info.nodata.msg");
		}
		return orderHeadVo;
	}

	private void setOrderDetailCodeText(OrderItemVO orderItemVO){
		if(!orderItemVO.getTvtwtVtweg().equals(""))
			orderItemVO.setTvtwtVtext("["+orderItemVO.getTvtwtVtweg()+"]" + sapSearchService.getMasterCodeName("24", orderItemVO.getTvtwtVtweg()));
		if(!orderItemVO.getTbsbtVsbed().equals(""))
			orderItemVO.setTbsbtVtext("["+orderItemVO.getTbsbtVsbed()+"]" + sapSearchService.getMasterCodeName("23", orderItemVO.getTbsbtVsbed()));
		if(!orderItemVO.getT001wWerks().equals(""))
			orderItemVO.setT001wName1("["+orderItemVO.getT001wWerks()+"]" + sapSearchService.getMasterCodeName("04", orderItemVO.getT001wWerks()));
		if(!orderItemVO.getT001lTgort().equals(""))
			orderItemVO.setT001lLgobe("["+orderItemVO.getT001lTgort()+"]" + sapSearchService.getMasterCodeName("15", orderItemVO.getT001lTgort()));
	}

	@Override
	public void updateEaslesOrder(OrderHeadVO param) {
		//수정전 orderHead 가져오기
		OrderHeadVO orderHeadVo = orderDao.getOrderDetail(param);

		//확정 제품의 판가가 존재하는지 확인하고 해당 판가로 변경
		checkSalesPriceExists(param);

		//화면에서 변경가능한 값들 치환
		orderHeadVo.setCoaxIsxx(param.getCoaxIsxx());
		orderHeadVo.setVeslCond(param.getVeslCond());
		orderHeadVo.setUpdtIdxx(param.getUpdtIdxx());
		//orderHead update
		orderDao.updateOrderHead(orderHeadVo);

		OrderItemVO itemVo = new OrderItemVO();
		itemVo.setEordHdid(param.getEordHdid());
		itemVo.setErpxIdxx(param.getErpxIdxx());

		//sap에 전송된 esales 원주문 items
		List<OrderItemVO> oriOrderItemList = orderDao.getOrderItemList(itemVo);
		int itemIndex = 0;
		for(OrderItemVO vo : param.getItemList()) {
			itemIndex++;
			vo.setEordHdid(param.getEordHdid());
			vo.setErpxSubx(String.format("%06d", itemIndex * 10));	//ERP 전송건들을 새로 입력된 아이템에 대하여 ErpxSubx 으로 비교해서 update
		}
		// update 먼저 처리
		for(OrderItemVO vo : param.getItemList()) {
			for(OrderItemVO oriItem : oriOrderItemList) {
				if(vo.getErpxSubx().equals(oriItem.getErpxSubx())) {	//update
					oriItem.setProcStat(OrderStatus.CONFIRM_ORDER.getCode());	//확정
					//수량이나 제품코드가 다르면 수정확정
					if(vo.getConfQtyx() != oriItem.getJumnQtyx()) {
						oriItem.setProcStat(OrderStatus.CONFIRM_MODIFY.getCode());
					}
					if(vo.getCproIdxx().equals(oriItem.getJproIdxx())) {
						oriItem.setProcStat(OrderStatus.CONFIRM_MODIFY.getCode());
					}

					oriItem.setJindIdxx(vo.getJindIdxx());	//요청인도처
					oriItem.setJindAddr(vo.getJindAddr());	//요청인도처 주소
					oriItem.setJproIdxx(vo.getJproIdxx());	//요청자재
					oriItem.setJproName(vo.getJproName());	//요청자재
					oriItem.setJumnQtyx(vo.getJumnQtyx());	//요청량
					oriItem.setCindIdxx(vo.getJindIdxx());	//인도처
					oriItem.setCindAddr(vo.getJindAddr());	//인도처 주소
					oriItem.setCproIdxx(vo.getCproIdxx());	//제품
					oriItem.setCproName(vo.getCproName());	//제품
					oriItem.setConfQtyx(vo.getConfQtyx());	//수량
					oriItem.setConfPric(vo.getConfPric());	//가격
					oriItem.setCurrency(vo.getCurrency());	//단위
					oriItem.setAreqDate(StringUtil.replace(oriItem.getAreqDate(), ".", ""));
					oriItem.setArriDate(StringUtil.replace(vo.getArriDate(), ".", ""));
					oriItem.setDreqDate(StringUtil.replace(vo.getDreqDate(), ".", ""));	//납품요청일 확정
					oriItem.setTvtwtVtweg(vo.getTvtwtVtweg());	//유통경로
					oriItem.setT001wWerks(vo.getT001wWerks());	//플랜트
					oriItem.setT001lTgort(vo.getT001lTgort());	//저장위치ID 확정
					oriItem.setTbsbtVsbed(vo.getTbsbtVsbed());	//출하조건ID 확정
					oriItem.setTvtwtVtext(sapSearchService.getMasterCodeName("24", vo.getTvtwtVtweg()));	//유통경로명
					oriItem.setT001wName1(sapSearchService.getMasterCodeName("04", vo.getT001wWerks()));	//플랜트명
					oriItem.setT001lLgobe(sapSearchService.getMasterCodeName("15", vo.getT001lTgort()));	//저장위치명
					oriItem.setTbsbtVtext(sapSearchService.getMasterCodeName("23", vo.getTbsbtVsbed()));	//출하조건명
					oriItem.setCdepBigo(vo.getCdepBigo());	//
					oriItem.setDealBigo(vo.getDealBigo());	//
					oriItem.setCustBigo(vo.getCustBigo());	//
					oriItem.setUpdtIdxx(param.getUpdtIdxx());
					oriItem.setCmanIdxx(param.getUpdtIdxx());
					oriItem.setConfDate("Y");
					orderDao.updateConfirmOrderItem(oriItem);
				}
			}
		}
		if(oriOrderItemList.size() < param.getItemList().size()) {	//create
			for(OrderItemVO newItem : param.getItemList()) {
				if(Integer.parseInt(newItem.getErpxSubx()) > Integer.parseInt(oriOrderItemList.get(oriOrderItemList.size() - 1).getErpxSubx())) {
					newItem.setErpxIdxx(param.getErpxIdxx());
					newItem.setProcStat(OrderStatus.CONFIRM_ORDER.getCode());
					newItem.setAreqDate(StringUtil.replace(oriOrderItemList.get(0).getAreqDate(), ".", ""));
					newItem.setJindIdxx(newItem.getJindIdxx());	//인도처
					newItem.setJindAddr(newItem.getJindAddr());	//인도처 주소
					newItem.setCindIdxx(newItem.getJindIdxx());	//확정 인도처
					newItem.setCindAddr(newItem.getJindAddr());	//확정 인도처 주소
					newItem.setArriDate(StringUtil.replace(newItem.getArriDate(), ".", ""));
					newItem.setDreqDate(StringUtil.replace(newItem.getDreqDate(), ".", ""));	//납품요청일 확정
					newItem.setTvtwtVtext(sapSearchService.getMasterCodeName("24", newItem.getTvtwtVtweg()));	//유통경로명
					newItem.setT001wName1(sapSearchService.getMasterCodeName("04", newItem.getT001wWerks()));	//플랜트명
					newItem.setT001lLgobe(sapSearchService.getMasterCodeName("15", newItem.getT001lTgort()));	//저장위치명
					newItem.setTbsbtVtext(sapSearchService.getMasterCodeName("23", newItem.getTbsbtVsbed()));	//출하조건명
					newItem.setRegiIdxx(param.getRegiIdxx());
					newItem.setUpdtIdxx(param.getUpdtIdxx());
					newItem.setCmanIdxx(param.getUpdtIdxx());
					orderDao.createConfirmOrderItem(newItem);
				}
			}
		}
		if(oriOrderItemList.size() > param.getItemList().size()) {	//delete
			for(OrderItemVO oriItem : oriOrderItemList) {
				if(Integer.parseInt(oriItem.getErpxSubx()) > Integer.parseInt(param.getItemList().get(param.getItemList().size() - 1).getErpxSubx())) {
					orderDao.deleteOrderItem(oriItem);
				}
			}
		}

		String orderId = directOrderDao.getDirectOrderId(param.getErpxIdxx());
		//DirectOrderMasterVO 생성하여 수정 rfc로 전송한다.
		DirectOrderMasterVO directOrder = new DirectOrderMasterVO();
		directOrder.setOrderId    (orderId);
		directOrder.setVbeln      (param.getErpxIdxx());
		directOrder.setDocType    (OrderType.ESALES.getCode());
		directOrder.setSalesOrg   (orderHeadVo.getTvkotVkorg());
		directOrder.setDistrChan  (param.getItemList().get(0).getTvtwtVtweg());
		directOrder.setPurchNoC   (orderHeadVo.getEordHdid() + "");
		directOrder.setDivision   (param.getTvkotVkorg().equals("3000")?"30":"10");
		directOrder.setReqDateH   (StringUtil.remove(param.getItemList().get(0).getDreqDate(), '.'));
		directOrder.setShipType   (param.getVeslCond().equals("S") ? "M4" : "M1");	//운임조건
		directOrder.setShipCond   (param.getItemList().get(0).getTbsbtVsbed());	//인도조건
		directOrder.setIncoterms1 (param.getVeslCond().equals("S") ? "Z01" : "Z02"); //출하조건
		//PRICE_LIST 는 ITEM 으로 이동, 하지만 화면상에는 HEADER 에 유지 -> 이미 들어온 주문 아이템 이라서 개별 PRICE_LIST 적용이 힘들다.
		//directOrder.setPriceList  (param.getPartnNumbZ7().equals("") ? param.getPriceList() : SalePriceMasterPriceListType.PLTYP_REGULAR.getCode());
		directOrder.setPartnNumbAg(param.getCompCode());
		directOrder.setCompCode   (orderHeadVo.getSaleComp());
		directOrder.setPartnNumbWe(param.getItemList().get(0).getJindIdxx());	//인도처
		directOrder.setPartnNumbVe(orderHeadVo.getSaleManCode());	//영업사원
		directOrder.setPartnNumbZ7(param.getPartnNumbZ7());	//실제인도처
		directOrder.setPartnNameWe(param.getItemList().get(0).getJindName());
		directOrder.setPartnNameZ7(param.getPartnNameZ7());
		directOrder.setBigoZ001   (param.getItemList().get(0).getDealBigo());
		directOrder.setBigoZ002   (param.getItemList().get(0).getCdepBigo());
		directOrder.setBigoZ025   (param.getItemList().get(0).getCustBigo());
		directOrder.setRegiIdxx   (param.getRegiIdxx());
		directOrder.setUpdtIdxx   (param.getUpdtIdxx());
		
		directOrder = (DirectOrderMasterVO) StringUtil.nullToEmptyString(directOrder);

		if(param.getItemList().size() > 0) {
			List<DirectOrderItemVO> itemList = new ArrayList<DirectOrderItemVO>();
			for(OrderItemVO item : param.getItemList()){
				DirectOrderItemVO directOrderItem = new DirectOrderItemVO();
				directOrderItem.setMaterial(item.getCproIdxx());
				directOrderItem.setPlant(item.getT001wWerks());
				directOrderItem.setStoreLoc(item.getT001lTgort());
				directOrderItem.setReqQty(item.getConfQtyx());
				directOrderItem.setPriceListI(param.getPartnNumbZ7().equals("") ? param.getPriceList() : SalePriceMasterPriceListType.PLTYP_REGULAR.getCode());
				directOrderItem.setCondUnit(SalePriceMasterUnitType.SP_UNIT_TYPE_KG.getCode());
				directOrderItem.setCondPUnt(1);
				directOrderItem.setReqDate(StringUtil.remove(item.getDreqDate(), '.'));
				directOrderItem.setCurrency(item.getCurrency());
				directOrderItem.setPr00Price(item.getConfPric());
				directOrderItem.setHighValueYn(item.getHighValueYn());
				directOrderItem.setHighValue(item.getHighValueYn().equals("Y") ? item.getHighValue() : "");
				directOrderItem.setRegiIdxx   (param.getRegiIdxx());
				directOrderItem.setUpdtIdxx   (param.getUpdtIdxx());
				itemList.add((DirectOrderItemVO) StringUtil.nullToEmptyString(directOrderItem));
			}
			directOrder.setOrderItemList(itemList);
		}

		directOrderService.updateDirectOrder(directOrder);
	}

	@Override
	public void updateEaslesOrderComment(OrderHeadVO param) {
		//수정전 orderHead 가져오기
		OrderHeadVO orderHeadVo = orderDao.getOrderDetail(param);

		OrderItemVO itemVo = new OrderItemVO();
		itemVo.setEordHdid(param.getEordHdid());
		itemVo.setErpxIdxx(param.getErpxIdxx());

		//sap에 전송된 esales 원주문 items
		List<OrderItemVO> oriOrderItemList = orderDao.getOrderItemList(itemVo);
		int itemIndex = 0;
		for(OrderItemVO vo : param.getItemList()) {
			itemIndex++;
			vo.setEordHdid(param.getEordHdid());
			vo.setErpxSubx(String.format("%06d", itemIndex * 10));	//ERP 전송건들을 새로 입력된 아이템에 대하여 ErpxSubx 으로 비교해서 update
		}
		// 비고 update 만 수행
		for(OrderItemVO vo : param.getItemList()) {
			for(OrderItemVO oriItem : oriOrderItemList) {
				if(vo.getErpxSubx().equals(oriItem.getErpxSubx())) {	//update
					oriItem.setCdepBigo(vo.getCdepBigo());	//
					oriItem.setDealBigo(vo.getDealBigo());	//
					oriItem.setUpdtIdxx(param.getUpdtIdxx());
					orderDao.updateOrderItemComment(oriItem);
				}
			}
		}
		String orderId = directOrderDao.getDirectOrderId(param.getErpxIdxx());
		//기존 master 가져오기
		DirectOrderMasterVO directOrder = directOrderDao.getDirectOrderMaster(orderId);
		//비고 수정
		directOrder.setBigoZ001   (param.getItemList().get(0).getDealBigo());
		directOrder.setBigoZ002   (param.getItemList().get(0).getCdepBigo());
		directOrder.setUpdtIdxx   (param.getUpdtIdxx());
		
		directOrderService.updateCommentText((DirectOrderMasterVO) StringUtil.nullToEmptyString(directOrder));
	}

	@Override
	public void deleteEaslesOrder(OrderHeadVO param) {
		OrderItemVO itemVo = new OrderItemVO();
		itemVo.setEordHdid(param.getEordHdid());
		itemVo.setErpxIdxx(param.getErpxIdxx());

		//sap에 전송된 esales 원주문 items
		List<OrderItemVO> beforeDeleteOrderItemList = orderDao.getOrderItemList(itemVo);
		for(OrderItemVO oriItem : beforeDeleteOrderItemList) {	//item 삭제
			orderDao.deleteOrderItem(oriItem);
		}
		
		OrderItemVO headVo = new OrderItemVO();
		headVo.setEordHdid(param.getEordHdid());
		
		List<OrderItemVO> afterDeleteOrderItemList = orderDao.getOrderItemList(headVo);
		if(afterDeleteOrderItemList.size() == 0) {	//모든아이템이 삭제되었으면 head 삭제
			orderDao.deleteOrderHead(param);
		}
		String orderId = directOrderDao.getDirectOrderId(param.getErpxIdxx());
		//기존 master 가져오기
		DirectOrderMasterVO directOrder = directOrderDao.getDirectOrderMaster(orderId);
		directOrderService.deleteDirectOrder(directOrder);
	}

	@Override
	public void updateEaslesOrderPriceMaster(OrderHeadVO param) {
		//수정전 orderHead 가져오기
		OrderHeadVO orderHeadVo = (OrderHeadVO) StringUtil.nullToEmptyString(orderDao.getOrderDetail(param));
		orderHeadVo.setPriceList(param.getPriceList());

		OrderItemVO itemVo = new OrderItemVO();
		itemVo.setEordHdid(param.getEordHdid());
		itemVo.setErpxIdxx(param.getErpxIdxx());

		//sap에 전송된 esales 원주문 items
		orderHeadVo.setItemList(orderDao.getOrderItemList(itemVo));

		//확정 제품의 판가가 존재하는지 확인하고 해당 판가로 변경
		checkSalesPriceExists(orderHeadVo);

		String orderId = directOrderDao.getDirectOrderId(param.getErpxIdxx());
		//기존 master 가져오기
		DirectOrderMasterVO directOrder = directOrderDao.getDirectOrderMaster(orderId);
		directOrder.setOrderItemList(directOrderDao.getDirectOrderItemList(orderId));

		//DirectOrderMasterVO 생성하여 수정 rfc로 전송한다.
		directOrder.setReqDateH   (StringUtil.remove(directOrder.getReqDateH(), '.'));
		directOrder.setUpdtIdxx   (param.getUpdtIdxx());
		
		directOrder = (DirectOrderMasterVO) StringUtil.nullToEmptyString(directOrder);

		for(DirectOrderItemVO item : directOrder.getOrderItemList()){
			item.setPriceListI(directOrder.getPartnNumbZ7().equals("") ? param.getPriceList() : SalePriceMasterPriceListType.PLTYP_REGULAR.getCode());
			item.setReqDate(StringUtil.remove(item.getReqDate(), '.'));
			for(OrderItemVO oriItemVo : orderHeadVo.getItemList()) {
				if(oriItemVo.getErpxSubx().equals(String.format("%06d", item.getSeq()))) {
					item.setPr00Price(oriItemVo.getConfPric());
					continue;
				}
			}
			item.setUpdtIdxx   (param.getUpdtIdxx());
		}

		//진행상태 가져오기
		directOrderService.setSapOrderStatus(null, Arrays.asList(directOrder));
		if(directOrder.getProcStat().equals(OrderStatus.BILLING_COMPLETE.getCode())) {	//빌링단계까지 진행되었으면 취소후 수정하고 다시 빌링생성
			salePriceMasterMgmtService.cancelBilling(new DirectOrderMasterVO[] {directOrder});
			logger.debug("주문번호 : " + directOrder.getOrderId() + " 처리중");
			for(int i = 1 ; i < 20 ; i++) {	//빌링이 최종취소 될때까지 시간이 걸린다.. 얼마나 걸리는진 모른다...
				try {
					Thread.sleep(500);
					directOrderService.setSapOrderStatus(null, Arrays.asList(directOrder));
					if(!directOrder.getProcStat().equals(OrderStatus.BILLING_COMPLETE.getCode())) {
						directOrderService.updateDirectOrderSkipShipment(directOrder);
						salePriceMasterMgmtService.postBilling(new DirectOrderMasterVO[] {directOrder});
						logger.debug("주문번호 : " + directOrder.getOrderId() + " 처리완료 " + i + " seconds");
						continue;
					}
				} catch (InterruptedException e) {
				}
			}
		} else {
			directOrderService.updateDirectOrderSkipShipment(directOrder);
		}
	}
}
