package com.lgmma.salesPortal.app.model;

import java.util.List;

import org.hibernate.validator.constraints.NotBlank;

public class ApprVO extends PagingParamVO {
	/* columns */
	private String apprId;
	private String vkorg;
	private String compCode;
	@NotBlank(message="문서유형{errors.required}")
	private String apprType;
	@NotBlank(message="제목{errors.required}")
	private String apprTitle;
	@NotBlank(message="내용{errors.required}")
	private String formCont;
	private String secrCode;
	private String saveCode;
	private String apprStat;
	private String fileId;
	private String samFileId;
	private String gwxxIdxx;
	private String gwxxScrt;
	private String gwdcCode;
	private String confLoca;
	private String apprStartDate;
	private String lineAYn;
	private String lineCYn;
	private String lineIYn;
	private String lineRYn;
	private String dpRegisterInfo;
	private String reqApplChkType;
	private String teamCode;
	private String relApprId;
	private String gpSendType;

	/* work module key  */
	private String keyId;

	/* view columns  */
	private String regiDateFmt;
	private String sawnId;
	private String sawnName;
	private String sawnPosiName;
	private String sawnTeamName;
	private String apprTypeName;
	private String apprStatName;
	private String compName;
	private String sawnMailAddr;
	private String sawnHpxxNum1;
	private String samFileCnt;
	private String vocxIdxx;

	/* condition */
	private String cApprId;
	private String cApprEmpId;
	private String cFrYmd;
	private String cToYmd;
	private String cApprTitle;
	private String cApprType;
	private String cCompCode;
	private String cVkorg;
	private String cApprStat;
	private List<String> cApprTypeList;

	/* apprLineList */
	private List<ApprLineVO> apprLineList;
	private List<ApprLineVO> apprLineAList;
	private List<ApprLineVO> apprLineCList;
	private List<ApprLineVO> apprLineRList;
	private List<ApprLineVO> apprLineIList;

	/* file list */
	private List<FileVO> fileList;
	private List<FileVO> samFileList;

	/* 임시저장,결재요청구분 */
	private String saveType;
	/* 임시필드 */
	private String templeteFormContent;
	
	/* DISS 품의서 팝업 파라미터 */
	private String taskType;
	private String taskId;
	private String stepId;
	private String stepCd;
	private String processType;

	/* DISS 품의서 권한체크 */
	private String apprActGb; // 로그인사번의 결재권자구분

	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getApprType() {
		return apprType;
	}
	public void setApprType(String apprType) {
		this.apprType = apprType;
	}
	public String getApprTitle() {
		return apprTitle;
	}
	public void setApprTitle(String apprTitle) {
		this.apprTitle = apprTitle;
	}
	public String getFormCont() {
		return formCont;
	}
	public void setFormCont(String formCont) {
		this.formCont = formCont;
	}
	public String getSecrCode() {
		return secrCode;
	}
	public void setSecrCode(String secrCode) {
		this.secrCode = secrCode;
	}
	public String getSaveCode() {
		return saveCode;
	}
	public void setSaveCode(String saveCode) {
		this.saveCode = saveCode;
	}
	public String getApprStat() {
		return apprStat;
	}
	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getGwxxIdxx() {
		return gwxxIdxx;
	}
	public void setGwxxIdxx(String gwxxIdxx) {
		this.gwxxIdxx = gwxxIdxx;
	}
	public String getGwxxScrt() {
		return gwxxScrt;
	}
	public void setGwxxScrt(String gwxxScrt) {
		this.gwxxScrt = gwxxScrt;
	}
	public String getGwdcCode() {
		return gwdcCode;
	}
	public void setGwdcCode(String gwdcCode) {
		this.gwdcCode = gwdcCode;
	}
	public String getConfLoca() {
		return confLoca;
	}
	public void setConfLoca(String confLoca) {
		this.confLoca = confLoca;
	}
	public String getApprStartDate() {
		return apprStartDate;
	}
	public void setApprStartDate(String apprStartDate) {
		this.apprStartDate = apprStartDate;
	}
	public String getLineAYn() {
		return lineAYn;
	}
	public void setLineAYn(String lineAYn) {
		this.lineAYn = lineAYn;
	}
	public String getLineCYn() {
		return lineCYn;
	}
	public void setLineCYn(String lineCYn) {
		this.lineCYn = lineCYn;
	}
	public String getLineIYn() {
		return lineIYn;
	}
	public void setLineIYn(String lineIYn) {
		this.lineIYn = lineIYn;
	}
	public String getLineRYn() {
		return lineRYn;
	}
	public void setLineRYn(String lineRYn) {
		this.lineRYn = lineRYn;
	}
	public String getDpRegisterInfo() {
		return dpRegisterInfo;
	}
	public void setDpRegisterInfo(String dpRegisterInfo) {
		this.dpRegisterInfo = dpRegisterInfo;
	}
	public String getSawnId() {
		return sawnId;
	}
	public void setSawnId(String sawnId) {
		this.sawnId = sawnId;
	}
	public String getReqApplChkType() {
		return reqApplChkType;
	}
	public void setReqApplChkType(String reqApplChkType) {
		this.reqApplChkType = reqApplChkType;
	}
	public String getTeamCode() {
		return teamCode;
	}
	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}
	public String getKeyId() {
		return keyId;
	}
	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}
	public String getRegiDateFmt() {
		return regiDateFmt;
	}
	public void setRegiDateFmt(String regiDateFmt) {
		this.regiDateFmt = regiDateFmt;
	}
	public String getSawnName() {
		return sawnName;
	}
	public void setSawnName(String sawnName) {
		this.sawnName = sawnName;
	}
	public String getSawnPosiName() {
		return sawnPosiName;
	}
	public void setSawnPosiName(String sawnPosiName) {
		this.sawnPosiName = sawnPosiName;
	}
	public String getSawnTeamName() {
		return sawnTeamName;
	}
	public void setSawnTeamName(String sawnTeamName) {
		this.sawnTeamName = sawnTeamName;
	}
	public String getApprTypeName() {
		return apprTypeName;
	}
	public void setApprTypeName(String apprTypeName) {
		this.apprTypeName = apprTypeName;
	}
	public String getApprStatName() {
		return apprStatName;
	}
	public void setApprStatName(String apprStatName) {
		this.apprStatName = apprStatName;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getSawnMailAddr() {
		return sawnMailAddr;
	}
	public void setSawnMailAddr(String sawnMailAddr) {
		this.sawnMailAddr = sawnMailAddr;
	}
	public String getSawnHpxxNum1() {
		return sawnHpxxNum1;
	}
	public void setSawnHpxxNum1(String sawnHpxxNum1) {
		this.sawnHpxxNum1 = sawnHpxxNum1;
	}
	public String getcApprId() {
		return cApprId;
	}
	public void setcApprId(String cApprId) {
		this.cApprId = cApprId;
	}
	public String getcApprEmpId() {
		return cApprEmpId;
	}
	public void setcApprEmpId(String cApprEmpId) {
		this.cApprEmpId = cApprEmpId;
	}
	public String getcFrYmd() {
		return cFrYmd;
	}
	public void setcFrYmd(String cFrYmd) {
		this.cFrYmd = cFrYmd;
	}
	public String getcToYmd() {
		return cToYmd;
	}
	public void setcToYmd(String cToYmd) {
		this.cToYmd = cToYmd;
	}
	public String getcApprTitle() {
		return cApprTitle;
	}
	public void setcApprTitle(String cApprTitle) {
		this.cApprTitle = cApprTitle;
	}
	public String getcApprType() {
		return cApprType;
	}
	public void setcApprType(String cApprType) {
		this.cApprType = cApprType;
	}
	public String getcCompCode() {
		return cCompCode;
	}
	public void setcCompCode(String cCompCode) {
		this.cCompCode = cCompCode;
	}
	public String getcVkorg() {
		return cVkorg;
	}
	public void setcVkorg(String cVkorg) {
		this.cVkorg = cVkorg;
	}
	public String getcApprStat() {
		return cApprStat;
	}
	public void setcApprStat(String cApprStat) {
		this.cApprStat = cApprStat;
	}
	public List<ApprLineVO> getApprLineList() {
		return apprLineList;
	}
	public void setApprLineList(List<ApprLineVO> apprLineList) {
		this.apprLineList = apprLineList;
	}
	public List<ApprLineVO> getApprLineAList() {
		return apprLineAList;
	}
	public void setApprLineAList(List<ApprLineVO> apprLineAList) {
		this.apprLineAList = apprLineAList;
	}
	public List<ApprLineVO> getApprLineCList() {
		return apprLineCList;
	}
	public void setApprLineCList(List<ApprLineVO> apprLineCList) {
		this.apprLineCList = apprLineCList;
	}
	public List<ApprLineVO> getApprLineRList() {
		return apprLineRList;
	}
	public void setApprLineRList(List<ApprLineVO> apprLineRList) {
		this.apprLineRList = apprLineRList;
	}
	public List<ApprLineVO> getApprLineIList() {
		return apprLineIList;
	}
	public void setApprLineIList(List<ApprLineVO> apprLineIList) {
		this.apprLineIList = apprLineIList;
	}
	public List<FileVO> getFileList() {
		return fileList;
	}
	public void setFileList(List<FileVO> fileList) {
		this.fileList = fileList;
	}
	public String getSaveType() {
		return saveType;
	}
	public void setSaveType(String saveType) {
		this.saveType = saveType;
	}
	public String getTempleteFormContent() {
		return templeteFormContent;
	}
	public void setTempleteFormContent(String templeteFormContent) {
		this.templeteFormContent = templeteFormContent;
	}
	public String getSamFileId() {
		return samFileId;
	}
	public void setSamFileId(String samFileId) {
		this.samFileId = samFileId;
	}
	public String getSamFileCnt() {
		return samFileCnt;
	}
	public void setSamFileCnt(String samFileCnt) {
		this.samFileCnt = samFileCnt;
	}
	public String getVocxIdxx() {
		return vocxIdxx;
	}
	public void setVocxIdxx(String vocxIdxx) {
		this.vocxIdxx = vocxIdxx;
	}
	public List<String> getcApprTypeList() {
		return cApprTypeList;
	}
	public void setcApprTypeList(List<String> cApprTypeList) {
		this.cApprTypeList = cApprTypeList;
	}
	public List<FileVO> getSamFileList() {
		return samFileList;
	}
	public void setSamFileList(List<FileVO> samFileList) {
		this.samFileList = samFileList;
	}
	public String getRelApprId() {
		return relApprId;
	}
	public void setRelApprId(String relApprId) {
		this.relApprId = relApprId;
	}

	public String getGpSendType() {
		return gpSendType;
	}

	public void setGpSendType(String gpSendType) {
		this.gpSendType = gpSendType;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getStepCd() {
		return stepCd;
	}
	public void setStepCd(String stepCd) {
		this.stepCd = stepCd;
	}
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getApprActGb() {
		return apprActGb;
	}

	public void setApprActGb(String apprActGb) {
		this.apprActGb = apprActGb;
	}
}
