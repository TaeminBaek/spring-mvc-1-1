package com.lgmma.salesPortal.app.model;

public class VocSendMailToEmpVO extends PagingParamVO {
	//VOC 등록시 담당자 메일발송
	private String vocOrg;
	private String regComp;
	private String reqComp;
	private String regName;
	private String regHp;
	private String regEmail;
	private String regDate;
	private String svcName;
	private String scvDiv;
	private String reqTitl;
	private String empName;
	private String empEmail;
	private String reqText;
	//VOC ACT 등록시 발신 수신 정보
	private String toMail;
	private String toName;
	private String fromMail;
	private String fromName;
	//VOC ACT 등록시 내부 전송 정보
	private String vocxIdxx;
	private String srvcCode;
	private String divxCode;
	private String srvcName;
	private String divxName;
	private String titlText;
	private String acptDate;
	private String contText;
	private String regiCompname;
	private String actxName;	
	
	public String getVocOrg() {
		return vocOrg;
	}
	public void setVocOrg(String vocOrg) {
		this.vocOrg = vocOrg;
	}
	public String getRegComp() {
		return regComp;
	}
	public void setRegComp(String regComp) {
		this.regComp = regComp;
	}
	public String getReqComp() {
		return reqComp;
	}
	public void setReqComp(String reqComp) {
		this.reqComp = reqComp;
	}
	public String getRegName() {
		return regName;
	}
	public void setRegName(String regName) {
		this.regName = regName;
	}
	public String getRegHp() {
		return regHp;
	}
	public void setRegHp(String regHp) {
		this.regHp = regHp;
	}
	public String getRegEmail() {
		return regEmail;
	}
	public void setRegEmail(String regEmail) {
		this.regEmail = regEmail;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getSvcName() {
		return svcName;
	}
	public void setSvcName(String svcName) {
		this.svcName = svcName;
	}
	public String getScvDiv() {
		return scvDiv;
	}
	public void setScvDiv(String scvDiv) {
		this.scvDiv = scvDiv;
	}
	public String getReqTitl() {
		return reqTitl;
	}
	public void setReqTitl(String reqTitl) {
		this.reqTitl = reqTitl;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getReqText() {
		return reqText;
	}
	public void setReqText(String reqText) {
		this.reqText = reqText;
	}
	public String getToMail() {
		return toMail;
	}
	public void setToMail(String toMail) {
		this.toMail = toMail;
	}
	public String getToName() {
		return toName;
	}
	public void setToName(String toName) {
		this.toName = toName;
	}
	public String getFromMail() {
		return fromMail;
	}
	public void setFromMail(String fromMail) {
		this.fromMail = fromMail;
	}
	public String getFromName() {
		return fromName;
	}
	public void setFromName(String fromName) {
		this.fromName = fromName;
	}
	public String getVocxIdxx() {
		return vocxIdxx;
	}
	public void setVocxIdxx(String vocxIdxx) {
		this.vocxIdxx = vocxIdxx;
	}
	public String getSrvcCode() {
		return srvcCode;
	}
	public void setSrvcCode(String srvcCode) {
		this.srvcCode = srvcCode;
	}
	public String getDivxCode() {
		return divxCode;
	}
	public void setDivxCode(String divxCode) {
		this.divxCode = divxCode;
	}
	public String getSrvcName() {
		return srvcName;
	}
	public void setSrvcName(String srvcName) {
		this.srvcName = srvcName;
	}
	public String getDivxName() {
		return divxName;
	}
	public void setDivxName(String divxName) {
		this.divxName = divxName;
	}
	public String getTitlText() {
		return titlText;
	}
	public void setTitlText(String titlText) {
		this.titlText = titlText;
	}
	public String getAcptDate() {
		return acptDate;
	}
	public void setAcptDate(String acptDate) {
		this.acptDate = acptDate;
	}
	public String getContText() {
		return contText;
	}
	public void setContText(String contText) {
		this.contText = contText;
	}
	public String getRegiCompname() {
		return regiCompname;
	}
	public void setRegiCompname(String regiCompname) {
		this.regiCompname = regiCompname;
	}
	public String getActxName() {
		return actxName;
	}
	public void setActxName(String actxName) {
		this.actxName = actxName;
	}
	
}
