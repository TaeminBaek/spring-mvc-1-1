package com.lgmma.salesPortal.app.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.dao.CreditGradeReportDao;
import com.lgmma.salesPortal.app.model.CompDamboVO;
import com.lgmma.salesPortal.app.model.CreditDomesticVO;
import com.lgmma.salesPortal.app.model.CreditExportVO;
import com.lgmma.salesPortal.app.model.CreditGradeReportVO;
import com.lgmma.salesPortal.app.model.CustomerCreditListVO;
import com.lgmma.salesPortal.app.model.DomesticDelayCreditVO;
import com.lgmma.salesPortal.app.model.ExportDelayCreditVO;
import com.lgmma.salesPortal.app.model.PartnerCreditVO;
import com.lgmma.salesPortal.app.model.RiskCreditVO;
import com.lgmma.salesPortal.app.service.CreditMgmtService;
import com.lgmma.salesPortal.app.service.SapSearchServiceCache;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.props.Vkorg;

@Service
public class CreditMgmtServiceImpl implements CreditMgmtService {
	private static Logger logger = LoggerFactory.getLogger(CreditMgmtServiceImpl.class); 
	
	private final String FNC_SAP_CREDIT_DOMESTIC = "ZSD_CREDIT_DOMESTIC";			// 여신현황 (내수)
	private final String FNC_SAP_CREDIT_EXPORT = "ZSD_CREDIT_EXPORT";				// 여신현황 (수출)
	private final String FNC_SAP_RISK_CREDIT = "ZSD_RISK_CREDIT";					// 위험채권
	private final String FNC_SAP_DOMESTIC_DELAY = "ZSD_DOMESTIC_DELAY_CREDIT";		// 연체채권 (내수)
	private final String FNC_SAP_EXPORT_DELAY = "ZSD_EXPORT_DELAY_CREDIT";			// 연체채권 (수출)
	//private final String FNC_SAP_CREDIT_REPORT = "ZSDE02_EARLY_WARNING_REPORT";
	private final String FNC_SAP_CREDIT_REPORT = "ZSDE02_CREDIT_REPORT";			// ERP 신용등급 현황
	private final String FNC_SAP_PARTNER_CREDIT_INFO = "ZSDE02_SELECT_CREDIT";		// 파트너 채권현황
	
	@Autowired
	private CompanyDao companyDao;
	
	@Autowired
	private CreditGradeReportDao creditGradeReportDao;
	
	@Autowired
	private JcoConnector jcoConnector;
	
	@Autowired
	private SapSearchServiceCache sapSearchServiceCache;
	
	@Override
	public List<String> getKunnr(String param) {
		return companyDao.getKunnr(param);
	}
	
	@Override
	public List<CustomerCreditListVO> getCustomerCreditList(CustomerCreditListVO param) {
		
		List<CustomerCreditListVO> creditList = sapSearchServiceCache.getCustomerCreditListCache(param.getGjahr(), param.getGsber(), param.getVtweg(), param.getName1());
			
		for(int i=0; i<creditList.size(); i++) {
			/*if(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getUserType().equals("P"))
				System.out.println("######COMP_CODE ["+((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getCompCode()+"]");
				System.out.println("######KVGR3 ["+list.get(i).getKvgr3()+"]");*/
			creditList.get(i).setrIndex(i+1);
		}
		
		return creditList;
	
	}

	@Override
	public List<CreditDomesticVO> getCreditDomesticList(CreditDomesticVO param) {
		JcoTableParam tableParam = new JcoTableParam();
		
		//영업조직
		if (!(param.getVkorg() == null || param.getVkorg().equals(""))) {
			Map<String, Object> vkorgMap = new HashMap<String, Object>();
			vkorgMap.put("SIGN", "I");
			vkorgMap.put("OPTION", "EQ");
			vkorgMap.put("LOW", param.getVkorg());
			vkorgMap.put("HIGH", null);
			tableParam.put("R_VKORG", vkorgMap);
		} else {
			List<Map> vkorgMapList = new ArrayList<Map>();
			for (Vkorg org : Vkorg.values()) {
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("SIGN", "I");
				paramMap.put("OPTION", "EQ");
				paramMap.put("LOW", org.getCode());
				paramMap.put("HIGH", null);
				vkorgMapList.add(paramMap);
			}
			tableParam.put("R_VKORG", vkorgMapList);
		}
		
		//유통경로
		if (!(param.getVtweg() == null || param.getVtweg().equals("00"))) {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("SIGN", "I");
			paramMap.put("OPTION", "EQ");
			paramMap.put("LOW", param.getVtweg());
			paramMap.put("HIGH", null);
			tableParam.put("R_VTWEG", paramMap);
		}
		
		//고객명
		if (!(param.getName1() == null || param.getName1().equals(""))) {
			List<String> kunnrList = getKunnr(param.getName1());
			if(kunnrList.isEmpty()) {
				kunnrList.add("0000000000");
			}
			List<Map> kunnrListMap = new ArrayList<Map>();
			for (int i = 0; i < kunnrList.size(); i++) {
				Map kunnrMap = new HashMap<String, Object>();
				kunnrMap.put("SIGN", "I");
				kunnrMap.put("OPTION", "EQ");
				kunnrMap.put("LOW", kunnrList.get(i));
				kunnrMap.put("HIGH", null);
				kunnrListMap.add(kunnrMap);
			}
			tableParam.put("R_KUNNR", kunnrListMap);
		}
		
		jcoConnector.executeFunction(FNC_SAP_CREDIT_DOMESTIC, tableParam);
		
		List<CreditDomesticVO> list = (List<CreditDomesticVO>) tableParam.get("T_LIST", CreditDomesticVO.class);
		for(int i=0; i<list.size(); i++)
			list.get(i).setrIndex(i+1);
		
		return list;
	}

	@Override
	public List<CreditExportVO> getCreditExportList(CreditExportVO param) {
		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_KKBER",param.getKkber()); 
		
		//고객명
		if (!(param.getName1() == null || param.getName1().equals(""))) {
			List<String> kunnrList = getKunnr(param.getName1());
			if(kunnrList.isEmpty()) {
				kunnrList.add("0000000000");
			}
			List<Map> kunnrListMap = new ArrayList<Map>();
			
			for (int i = 0; i < kunnrList.size(); i++) {
				Map kunnrMap = new HashMap<String, Object>();
				kunnrMap.put("SIGN", "I");
				kunnrMap.put("OPTION", "EQ");
				kunnrMap.put("LOW", kunnrList.get(i));
				kunnrMap.put("HIGH", null);
				kunnrListMap.add(kunnrMap);
			}

			tableParam.put("R_KUNNR", kunnrListMap);
		}
		
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_CREDIT_EXPORT, inputParam, outputParam, tableParam);
		
		List<CreditExportVO> list = (List<CreditExportVO>) tableParam.get("T_LIST", CreditExportVO.class);
		for(int i=0; i<list.size(); i++) {
			list.get(i).setrIndex(i+1);
		}
			
		return list;
	}

	@Override
	public List<RiskCreditVO> getRiskyCreditList(RiskCreditVO param) {
		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_DATUM", param.getDatum().replace(".", "").trim()); 
		inputParam.put("I_SELECT","X");
		
		//영업조직
		if (!(param.getVkorg() == null || param.getVkorg().equals(""))) {
			Map<String, Object> vkorgMap = new HashMap<String, Object>();
			vkorgMap.put("SIGN", "I");
			vkorgMap.put("OPTION", "EQ");
			vkorgMap.put("LOW", param.getVkorg());
			vkorgMap.put("HIGH", null);
			tableParam.put("R_VKORG", vkorgMap);
		} else {
			List<Map> vkorgMapList = new ArrayList<Map>();
			for (Vkorg org : Vkorg.values()) {
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("SIGN", "I");
				paramMap.put("OPTION", "EQ");
				paramMap.put("LOW", org.getCode());
				paramMap.put("HIGH", null);
				vkorgMapList.add(paramMap);
			}
			tableParam.put("R_VKORG", vkorgMapList);
		}
		
		
		//유통경로
		if (!(param.getVtweg() == null || param.getVtweg().equals("00"))) {
			Map<String, Object> vtwegMap = new HashMap<String, Object>();
			vtwegMap.put("SIGN", "I");
			vtwegMap.put("OPTION", "EQ");
			vtwegMap.put("LOW", param.getVtweg());
			vtwegMap.put("HIGH", null);
			tableParam.put("R_VTWEG", vtwegMap);
		}
		
		//위험등급
		if (!(param.getRgrdcd() == null || param.getRgrdcd().equals("00"))) {
			Map<String, Object> rgrdcdMap = new HashMap<String, Object>();
			rgrdcdMap.put("SIGN", "I");
			rgrdcdMap.put("OPTION", "EQ");
			rgrdcdMap.put("LOW", param.getRgrdcd());
			rgrdcdMap.put("HIGH", null);
			tableParam.put("R_RGRDCD", rgrdcdMap);
		}
		
		//고객명
		if (!(param.getName1() == null || param.getName1().equals(""))) {
			List<String> kunnrList = getKunnr(param.getName1());
			if(kunnrList.isEmpty()) {
				kunnrList.add("0000000000");
			}
			List<Map> kunnrListMap = new ArrayList<Map>();
			for (int i = 0; i < kunnrList.size(); i++) {
				Map kunnrMap = new HashMap<String, Object>();
				kunnrMap.put("SIGN", "I");
				kunnrMap.put("OPTION", "EQ");
				kunnrMap.put("LOW", kunnrList.get(i));
				kunnrMap.put("HIGH", null);
				kunnrListMap.add(kunnrMap);
			}
			tableParam.put("R_KUNNR", kunnrListMap);
		}
				
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_RISK_CREDIT, inputParam, outputParam, tableParam);
		
		List<RiskCreditVO> list = (List<RiskCreditVO>) tableParam.get("T_LIST", RiskCreditVO.class);
		for(int i=0; i<list.size(); i++)
			list.get(i).setrIndex(i+1);
		
		return list;
	}

	@Override
	public List<DomesticDelayCreditVO> getDomesticDelayCreditList(DomesticDelayCreditVO param) {
		
		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_DATUM", param.getDatum().replace(".", "").trim());
		inputParam.put("I_SELECT","X");
		
		//영업조직
		if (!(param.getVkorg() == null || param.getVkorg().equals(""))) {
			Map<String, Object> vkorgMap = new HashMap<String, Object>();
			vkorgMap.put("SIGN", "I");
			vkorgMap.put("OPTION", "EQ");
			vkorgMap.put("LOW", param.getVkorg());
			vkorgMap.put("HIGH", null);
			tableParam.put("R_VKORG", vkorgMap);
		} else {
			List<Map> vkorgMapList = new ArrayList<Map>();
			for (Vkorg org : Vkorg.values()) {
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("SIGN", "I");
				paramMap.put("OPTION", "EQ");
				paramMap.put("LOW", org.getCode());
				paramMap.put("HIGH", null);
				vkorgMapList.add(paramMap);
			}
			tableParam.put("R_VKORG", vkorgMapList);
		}
		
		
		//유통경로
		if (!(param.getVtweg() == null || param.getVtweg().equals("00"))) {
			Map<String, Object> vtwegMap = new HashMap<String, Object>();
			vtwegMap.put("SIGN", "I");
			vtwegMap.put("OPTION", "EQ");
			vtwegMap.put("LOW", param.getVtweg());
			vtwegMap.put("HIGH", null);
			tableParam.put("R_VTWEG", vtwegMap);
		}
		
		//연체등급
		if (!(param.getBusil() == null || param.getBusil().equals(""))) {
			Map<String, Object> busilMap = new HashMap<String, Object>();
			busilMap.put("SIGN", "I");
			busilMap.put("OPTION", "EQ");
			busilMap.put("LOW", param.getBusil());
			busilMap.put("HIGH", null);
			tableParam.put("R_BUSIL", busilMap);
		}
		
		//고객명
		if (!(param.getName1() == null || param.getName1().equals(""))) {
			List<String> kunnrList = getKunnr(param.getName1());
			if(kunnrList.isEmpty()) {
				kunnrList.add("0000000000");
			}
			List<Map> kunnrListMap = new ArrayList<Map>();
			for (int i = 0; i < kunnrList.size(); i++) {
				Map kunnrMap = new HashMap<String, Object>();
				kunnrMap.put("SIGN", "I");
				kunnrMap.put("OPTION", "EQ");
				kunnrMap.put("LOW", kunnrList.get(i));
				kunnrMap.put("HIGH", null);
				kunnrListMap.add(kunnrMap);
			}
			tableParam.put("R_KUNNR", kunnrListMap);
		}
				
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_DOMESTIC_DELAY, inputParam, outputParam, tableParam);
		
		List<DomesticDelayCreditVO> list = (List<DomesticDelayCreditVO>) tableParam.get("T_LIST", DomesticDelayCreditVO.class);
		for(int i=0; i<list.size(); i++)
			list.get(i).setrIndex(i+1);
		
		return list;
	}

	@Override
	public List<ExportDelayCreditVO> getExportDelayCreditList(ExportDelayCreditVO param) {
		
		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_DATUM", param.getDatum().replace(".", "").trim());
		inputParam.put("I_SELECT","");
		
		//영업조직
		if (!(param.getVkorg() == null || param.getVkorg().equals(""))) {
			Map<String, Object> vkorgMap = new HashMap<String, Object>();
			vkorgMap.put("SIGN", "I");
			vkorgMap.put("OPTION", "EQ");
			vkorgMap.put("LOW", param.getVkorg());
			vkorgMap.put("HIGH", null);
			tableParam.put("R_VKORG", vkorgMap);
		} else {
			List<Map> vkorgMapList = new ArrayList<Map>();
			for (Vkorg org : Vkorg.values()) {
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("SIGN", "I");
				paramMap.put("OPTION", "EQ");
				paramMap.put("LOW", org.getCode());
				paramMap.put("HIGH", null);
				vkorgMapList.add(paramMap);
			}
			tableParam.put("R_VKORG", vkorgMapList);
		}
		
		
		//유통경로
		if (!(param.getVtweg() == null || param.getVtweg().equals("00"))) {
			Map<String, Object> vtwegMap = new HashMap<String, Object>();
			vtwegMap.put("SIGN", "I");
			vtwegMap.put("OPTION", "EQ");
			vtwegMap.put("LOW", param.getVtweg());
			vtwegMap.put("HIGH", null);
			tableParam.put("R_VTWEG", vtwegMap);
		}
		
		//연체등급
		if (!(param.getBusil() == null || param.getBusil().equals(""))) {
			Map<String, Object> busilMap = new HashMap<String, Object>();
			busilMap.put("SIGN", "I");
			busilMap.put("OPTION", "EQ");
			busilMap.put("LOW", param.getBusil());
			busilMap.put("HIGH", null);
			tableParam.put("R_BUSIL", busilMap);
		}
		
		//고객명
		if (!(param.getName1() == null || param.getName1().equals(""))) {
			List<String> kunnrList = getKunnr(param.getName1());
			if(kunnrList.isEmpty()) {
				kunnrList.add("0000000000");
			}
			List<Map> kunnrListMap = new ArrayList<Map>();
			for (int i = 0; i < kunnrList.size(); i++) {
				Map kunnrMap = new HashMap<String, Object>();
				kunnrMap.put("SIGN", "I");
				kunnrMap.put("OPTION", "EQ");
				kunnrMap.put("LOW", kunnrList.get(i));
				kunnrMap.put("HIGH", null);
				kunnrListMap.add(kunnrMap);
			}

			tableParam.put("R_KUNNR", kunnrListMap);
		}
				
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		
		//tableParam 디버깅
		logger.debug("######tableParams");
		List<Object> bList = (List<Object>) tableParam.get("R_VTWEG");
		if(bList != null) {
			for(int i=0 ;i<bList.size(); i++) {
				logger.debug("######R_VTWEG SIGN	["+((Map)bList.get(i)).get("SIGN")+"]");
				logger.debug("######R_VTWEG OPTION	["+((Map)bList.get(i)).get("OPTION")+"]");
				logger.debug("######R_VTWEG LOW	["+((Map)bList.get(i)).get("LOW")+"]");
				logger.debug("######R_VTWEG HIGH	["+((Map)bList.get(i)).get("HIGH")+"]");
				logger.debug("###########################");
			}
		}
		
				
		
		jcoConnector.executeFunction(FNC_SAP_EXPORT_DELAY, inputParam, outputParam, tableParam);
		
		//tableParam 디버깅
		logger.debug("######tableParams_after_executeFunction");
		List<Object> cList = (List<Object>) tableParam.get("R_VTWEG");
		if(bList != null) {
			for(int i=0 ;i<cList.size(); i++) {
				logger.debug("######R_VTWEG SIGN	["+((Map)cList.get(i)).get("SIGN")+"]");
				logger.debug("######R_VTWEG OPTION	["+((Map)cList.get(i)).get("OPTION")+"]");
				logger.debug("######R_VTWEG LOW	["+((Map)cList.get(i)).get("LOW")+"]");
				logger.debug("######R_VTWEG HIGH	["+((Map)cList.get(i)).get("HIGH")+"]");
				logger.debug("###########################");
			}
		}
		List<ExportDelayCreditVO> list = (List<ExportDelayCreditVO>) tableParam.get("T_LIST", ExportDelayCreditVO.class);
		for(int i=0; i<list.size(); i++)
			list.get(i).setrIndex(i+1);
		
		return list;
	}

	@Override
	public int getCreditGradeReportListCount(CreditGradeReportVO param) {
		int creditGradeReportListCount = creditGradeReportDao.getCreditGradeReportListCount(param);
		return creditGradeReportListCount;
	}
	@Override
	public List<CreditGradeReportVO> getCreditGradeReportList(CreditGradeReportVO param) {
		/*JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_DATUM", param.getDatum().replace(".", "").trim());
		
		//고객명
		if (!(param.getCompName() == null || param.getCompName().equals(""))) {
			List<String> kunnrList = getKunnr(param.getCompName());
			if(kunnrList.isEmpty()) {
				kunnrList.add("0000000000");
			}
			List<Map> kunnrListMap = new ArrayList<Map>();
			for (int i = 0; i < kunnrList.size(); i++) {
				Map kunnrMap = new HashMap<String, Object>();
				kunnrMap.put("SIGN", "I");
				kunnrMap.put("OPTION", "EQ");
				kunnrMap.put("LOW", kunnrList.get(i));
				kunnrMap.put("HIGH", null);
				kunnrListMap.add(kunnrMap);
			}

			tableParam.put("CUSTOMERRANGE", kunnrListMap);
		}
		
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_CREDIT_REPORT, inputParam, outputParam, tableParam);
		
		List<CreditGradeReportVO> list = (List<CreditGradeReportVO>) tableParam.get("T_LIST", CreditGradeReportVO.class);
		for(int i=0; i<list.size(); i++)
			list.get(i).setrIndex(i+1);
		*/
		List<CreditGradeReportVO> returnList = creditGradeReportDao.getCreditGradeReportList(param);
		for(int i=0; i<returnList.size(); i++) {
			//ERP 채권현황 
			returnList.get(i).setDatum(returnList.get(i).getKisdate()); //조회일자 세팅
			List<CreditGradeReportVO> erpCreditList = getErpCreditInfo(returnList.get(i)); //조회결과 
			
			if(erpCreditList.size() > 0) 
				returnList.get(i).setCreditYn("Y"); //버튼 표시여부
			
			returnList.get(i).setErpCreditList(erpCreditList);  //row별 채권현황 조회결과 저장
			
			//ERP 담보현황
			CompDamboVO erpDamboVo = new CompDamboVO();
			erpDamboVo.setCompCode(returnList.get(i).getCompCode()); //고객코드 세팅
			
			int erpDamboCount = getErpDamboInfoCount(erpDamboVo); //조회결과 count
			if(erpDamboCount > 0) {
				returnList.get(i).setDamboYn("Y"); //버튼 표시여부
			}
		}
		return returnList;
	}
	
	@Override
	public List<CreditGradeReportVO> getErpCreditInfo(CreditGradeReportVO param){
		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_DATUM",param.getDatum()); //일자
		
		//고객코드
		if (!(param.getKunnr() == null || param.getKunnr().equals(""))) {
			Map kunnrMap = new HashMap<String, Object>();
			kunnrMap.put("SIGN", "I");
			kunnrMap.put("OPTION", "EQ");
			kunnrMap.put("LOW", param.getKunnr());
			kunnrMap.put("HIGH", null);
			tableParam.put("CUSTOMERRANGE", kunnrMap);
		}
		
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_CREDIT_REPORT, inputParam, outputParam, tableParam);
		
		List<CreditGradeReportVO> list = (List<CreditGradeReportVO>) tableParam.get("T_LIST", CreditGradeReportVO.class);
		
		return list;
		
		
	}
	@Override
	public int getErpDamboInfoCount(CompDamboVO param) {
		return creditGradeReportDao.getDamboInfoListCount(param);
	}
	@Override
	public List<CompDamboVO> getErpDamboInfo(CompDamboVO param) {
		return creditGradeReportDao.getDamboInfoList(param);
	}

	@Override
	public List<PartnerCreditVO> getParterCreditInfo(PartnerCreditVO param) {
		List<PartnerCreditVO> returnList = new ArrayList<PartnerCreditVO>();
		
		JcoTableParam tableParam = new JcoTableParam();
		// 입력 파라미터 정의(입력값이 없다면 null로 선언)	
		Map<String, Object> inputParam = new HashMap<String, Object>();
		//=============================================================================
		// 입력 파라미터가 단순형이라면 inputParams.put("key",value);만 넣으면 되고, 
		// Structure형이라면 HashMap inputMembers = new HashMap()을 만들어서 
		// 각 필드갯수만큼 inputMember.put("key1",value1);를 넣은후
		// inputParams.put("key",inputMembers);로 넣어주면된다.
		//
		// 정리하면,
		// Simple Type => inputParams.put("필드명",값);
		// Structure Type => inputParams.put("필드명",해시맵);
		//=============================================================================
		  
		  //Simple field 임포트값 입력
		inputParam.put("I_VKORG", param.getVkorg());			// 영업조직
		inputParam.put("I_KUNNR", param.getKunnr());			// 거래선
		inputParam.put("I_SPMON", param.getSpmon());			// 기준일자
		inputParam.put("I_GUBUN", "A");							// 채권구분
		
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_PARTNER_CREDIT_INFO, inputParam, outputParam, tableParam);
		
		List<PartnerCreditVO> list = (List<PartnerCreditVO>) tableParam.get("T_CREDIT", PartnerCreditVO.class);
		
		return list;
	}

	@Override
	public List<PartnerCreditVO> getParterCreditHoldInfo(PartnerCreditVO param) {
		
		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_VKORG", param.getVkorg());			// 영업조직
		inputParam.put("I_KUNNR", param.getKunnr());			// 거래선
		inputParam.put("I_SPMON", param.getSpmon());			// 기준일자
		inputParam.put("I_GUBUN", "B");							// 채권구분
		
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_PARTNER_CREDIT_INFO, inputParam, outputParam, tableParam);
		
		List<PartnerCreditVO> list = (List<PartnerCreditVO>) tableParam.get("T_CREDIT2", PartnerCreditVO.class);
		
		return list;
	}

	@Override
	public List<PartnerCreditVO> getParterCreditExpiredInfo(PartnerCreditVO param) {

		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_VKORG", param.getVkorg());			// 영업조직
		inputParam.put("I_KUNNR", param.getKunnr());			// 거래선
		inputParam.put("I_SPMON", param.getSpmon());			// 기준일자
		inputParam.put("I_GUBUN", "C");							// 채권구분
		
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_PARTNER_CREDIT_INFO, inputParam, outputParam, tableParam);
		
		List<PartnerCreditVO> list = (List<PartnerCreditVO>) tableParam.get("T_CREDIT3", PartnerCreditVO.class);
		
		return list;
	}

	@Override
	public List<PartnerCreditVO> getParterCreditCashInfo(PartnerCreditVO param) {

		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_VKORG", param.getVkorg());			// 영업조직
		inputParam.put("I_KUNNR", param.getKunnr());			// 거래선
		inputParam.put("I_SPMON", param.getSpmon());			// 기준일자
		inputParam.put("I_GUBUN", "D");							// 채권구분
		
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_PARTNER_CREDIT_INFO, inputParam, outputParam, tableParam);
		
		List<PartnerCreditVO> list = (List<PartnerCreditVO>) tableParam.get("T_CREDIT1", PartnerCreditVO.class);
		
		return list;
	}

	@Override
	public List<PartnerCreditVO> getParterCreditBillInfo(PartnerCreditVO param) {
	JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_VKORG", param.getVkorg());			// 영업조직
		inputParam.put("I_KUNNR", param.getKunnr());			// 거래선
		inputParam.put("I_SPMON", param.getSpmon());			// 기준일자
		inputParam.put("I_GUBUN", "E");							// 채권구분
		
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_PARTNER_CREDIT_INFO, inputParam, outputParam, tableParam);
		
		List<PartnerCreditVO> list = (List<PartnerCreditVO>) tableParam.get("T_CREDIT2", PartnerCreditVO.class);
		
		return list;
	}
}
