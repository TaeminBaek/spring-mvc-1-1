package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.ContractItemVO;
import com.lgmma.salesPortal.app.model.ContractMasterVO;

public interface ContractDao {

	void createInitContractMaster(String orderId);

	ContractMasterVO getContractMaster(String orderId);

	void createInitContractItems(String orderId);

	List<ContractItemVO> getContractItem(String orderId);

	void updateContractMaster(ContractMasterVO param);

	void updateContractItem(ContractItemVO item);

}
