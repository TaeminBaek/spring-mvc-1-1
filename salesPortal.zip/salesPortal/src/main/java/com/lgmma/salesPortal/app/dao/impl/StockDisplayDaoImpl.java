package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.StockDisplayDao;
import com.lgmma.salesPortal.app.model.ProductStockVO;
import com.lgmma.salesPortal.app.model.ProductVO;

@Repository
public class StockDisplayDaoImpl implements StockDisplayDao{
	
	 private static final String MAPPER_NAMESPACE = "STOCKDISPLAY_MAPPER.";

	    @Autowired(required=true)
	    protected SqlSession sqlSession;

		@Override
		public int getStockDisplayCount(ProductVO param) {
			return sqlSession.selectOne(MAPPER_NAMESPACE + "getStockDisplayCount", param);
		}

		@Override
		public List<ProductVO> getStockDisplayList(ProductVO param) {
			return sqlSession.selectList(MAPPER_NAMESPACE + "getStockDisplay", param);
		}

		@Override
		public void updateStockDisplay(ProductVO param) {
			sqlSession.update(MAPPER_NAMESPACE + "updateStockDisplay", param);
			
		}

		@Override
		public void mergeProduct(List<ProductVO> productList) {
			for(ProductVO product : productList) {
				sqlSession.update(MAPPER_NAMESPACE + "mergeProduct", product);
			}
		}

		@Override
		public int getProductInStockCount(ProductStockVO param) {
			return sqlSession.selectOne(MAPPER_NAMESPACE + "getProductInStockCount", param);
		}

		@Override
		public List<ProductStockVO> getProductInStockList(ProductStockVO param) {
			return sqlSession.selectList(MAPPER_NAMESPACE + "getProductInStockList", param);
		}

}
