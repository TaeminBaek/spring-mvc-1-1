package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissCustTestVO;

public interface DissCustTestDao {	
	
	DissCustTestVO getDissCustTestInfo(DissCustTestVO param);
	
	void createDissCustTest(DissCustTestVO param);
	
	void updateDissCustTest(DissCustTestVO param);
	
	void deleteDissCustTestAll(DissCustTestVO param);
	

}
