package com.lgmma.salesPortal.app.model;

public class CompOrganByErpVO extends PagingParamVO{
	private String partnNumb;
	private String salesOrg;
	private String distrChan;
	private String division;
	private String salesDist;
	private String salesOff;
	private String salesGrp;
	private String custGroup;
	private String currency;
	private String incoterms1;
	private String incoterms2;
	private String pmnttrms;
	private String kkber;
	private String accntAsgn;
	private String custGrp1;
	private String custGrp2;
	private String custGrp3;
	private String custGrp4;
	private String custGrp5;
	private String ernam;
	private String erdat;
	private String name1;
	private String lifnr;
	private String vbund;
	private String konzs;
	private String stcd1;
	private String stcd2;
	private String stceg;
	private String j1kfrepre;
	private String j1kftbus;
	private String j1kftind;
	private String ktokd;
	private String brsch;
	private String bran1;
	private String bran2;
	private String bran3;
	private String bran4;
	private String bran5;
	private String ablad;
	private String knfak;
	private String defab;
	private String kalks;
	private String mrnkz;
	private String bezei;
	private String pernr;
	private String grade;
	private String zterm;
	private String loevm;
	private String ceofnm;
	private String ceoenm;

	public String getPartnNumb() {
		return partnNumb;
	}

	public void setPartnNumb(String partnNumb) {
		this.partnNumb = partnNumb;
	}

	public String getSalesOrg() {
		return salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public String getDistrChan() {
		return distrChan;
	}

	public void setDistrChan(String distrChan) {
		this.distrChan = distrChan;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getSalesDist() {
		return salesDist;
	}

	public void setSalesDist(String salesDist) {
		this.salesDist = salesDist;
	}

	public String getSalesOff() {
		return salesOff;
	}

	public void setSalesOff(String salesOff) {
		this.salesOff = salesOff;
	}

	public String getSalesGrp() {
		return salesGrp;
	}

	public void setSalesGrp(String salesGrp) {
		this.salesGrp = salesGrp;
	}

	public String getCustGroup() {
		return custGroup;
	}

	public void setCustGroup(String custGroup) {
		this.custGroup = custGroup;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getIncoterms1() {
		return incoterms1;
	}

	public void setIncoterms1(String incoterms1) {
		this.incoterms1 = incoterms1;
	}

	public String getIncoterms2() {
		return incoterms2;
	}

	public void setIncoterms2(String incoterms2) {
		this.incoterms2 = incoterms2;
	}

	public String getPmnttrms() {
		return pmnttrms;
	}

	public void setPmnttrms(String pmnttrms) {
		this.pmnttrms = pmnttrms;
	}

	public String getKkber() {
		return kkber;
	}

	public void setKkber(String kkber) {
		this.kkber = kkber;
	}

	public String getAccntAsgn() {
		return accntAsgn;
	}

	public void setAccntAsgn(String accntAsgn) {
		this.accntAsgn = accntAsgn;
	}

	public String getCustGrp1() {
		return custGrp1;
	}

	public void setCustGrp1(String custGrp1) {
		this.custGrp1 = custGrp1;
	}

	public String getCustGrp2() {
		return custGrp2;
	}

	public void setCustGrp2(String custGrp2) {
		this.custGrp2 = custGrp2;
	}

	public String getCustGrp3() {
		return custGrp3;
	}

	public void setCustGrp3(String custGrp3) {
		this.custGrp3 = custGrp3;
	}

	public String getCustGrp4() {
		return custGrp4;
	}

	public void setCustGrp4(String custGrp4) {
		this.custGrp4 = custGrp4;
	}

	public String getCustGrp5() {
		return custGrp5;
	}

	public void setCustGrp5(String custGrp5) {
		this.custGrp5 = custGrp5;
	}

	public String getErnam() {
		return ernam;
	}

	public void setErnam(String ernam) {
		this.ernam = ernam;
	}

	public String getErdat() {
		return erdat;
	}

	public void setErdat(String erdat) {
		this.erdat = erdat;
	}

	public String getName1() {
		return name1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}

	public String getLifnr() {
		return lifnr;
	}

	public void setLifnr(String lifnr) {
		this.lifnr = lifnr;
	}

	public String getVbund() {
		return vbund;
	}

	public void setVbund(String vbund) {
		this.vbund = vbund;
	}

	public String getKonzs() {
		return konzs;
	}

	public void setKonzs(String konzs) {
		this.konzs = konzs;
	}

	public String getStcd1() {
		return stcd1;
	}

	public void setStcd1(String stcd1) {
		this.stcd1 = stcd1;
	}

	public String getStcd2() {
		return stcd2;
	}

	public void setStcd2(String stcd2) {
		this.stcd2 = stcd2;
	}

	public String getStceg() {
		return stceg;
	}

	public void setStceg(String stceg) {
		this.stceg = stceg;
	}

	public String getJ1kfrepre() {
		return j1kfrepre;
	}

	public void setJ1kfrepre(String j1kfrepre) {
		this.j1kfrepre = j1kfrepre;
	}

	public String getJ1kftbus() {
		return j1kftbus;
	}

	public void setJ1kftbus(String j1kftbus) {
		this.j1kftbus = j1kftbus;
	}

	public String getJ1kftind() {
		return j1kftind;
	}

	public void setJ1kftind(String j1kftind) {
		this.j1kftind = j1kftind;
	}

	public String getKtokd() {
		return ktokd;
	}

	public void setKtokd(String ktokd) {
		this.ktokd = ktokd;
	}

	public String getBrsch() {
		return brsch;
	}

	public void setBrsch(String brsch) {
		this.brsch = brsch;
	}

	public String getBran1() {
		return bran1;
	}

	public void setBran1(String bran1) {
		this.bran1 = bran1;
	}

	public String getBran2() {
		return bran2;
	}

	public void setBran2(String bran2) {
		this.bran2 = bran2;
	}

	public String getBran3() {
		return bran3;
	}

	public void setBran3(String bran3) {
		this.bran3 = bran3;
	}

	public String getBran4() {
		return bran4;
	}

	public void setBran4(String bran4) {
		this.bran4 = bran4;
	}

	public String getBran5() {
		return bran5;
	}

	public void setBran5(String bran5) {
		this.bran5 = bran5;
	}

	public String getAblad() {
		return ablad;
	}

	public void setAblad(String ablad) {
		this.ablad = ablad;
	}

	public String getKnfak() {
		return knfak;
	}

	public void setKnfak(String knfak) {
		this.knfak = knfak;
	}

	public String getDefab() {
		return defab;
	}

	public void setDefab(String defab) {
		this.defab = defab;
	}

	public String getKalks() {
		return kalks;
	}

	public void setKalks(String kalks) {
		this.kalks = kalks;
	}

	public String getMrnkz() {
		return mrnkz;
	}

	public void setMrnkz(String mrnkz) {
		this.mrnkz = mrnkz;
	}

	public String getBezei() {
		return bezei;
	}

	public void setBezei(String bezei) {
		this.bezei = bezei;
	}

	public String getPernr() {
		return pernr;
	}

	public void setPernr(String pernr) {
		this.pernr = pernr;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getZterm() {
		return zterm;
	}

	public void setZterm(String zterm) {
		this.zterm = zterm;
	}

	public String getLoevm() {
		return loevm;
	}

	public void setLoevm(String loevm) {
		this.loevm = loevm;
	}

	public String getCeofnm() {
		return ceofnm;
	}

	public void setCeofnm(String ceofnm) {
		this.ceofnm = ceofnm;
	}

	public String getCeoenm() {
		return ceoenm;
	}

	public void setCeoenm(String ceoenm) {
		this.ceoenm = ceoenm;
	}
}
