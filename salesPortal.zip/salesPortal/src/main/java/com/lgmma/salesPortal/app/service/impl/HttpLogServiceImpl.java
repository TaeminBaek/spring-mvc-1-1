package com.lgmma.salesPortal.app.service.impl;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.dao.HttpLogDao;
import com.lgmma.salesPortal.app.service.HttpLogService;
import com.lgmma.salesPortal.common.model.LogVO;
import com.lgmma.salesPortal.common.util.StringUtil;

@Service
public class HttpLogServiceImpl implements HttpLogService {
    @Autowired
    private ThreadPoolTaskExecutor httpLogJobExecutor;

    @Autowired
    private HttpLogDao httpLogDao;
    
	@Override
	public void createLog(LogVO logVo) {
		logVo = (LogVO) StringUtil.nullToEmptyString((logVo == null) ? new LogVO() : logVo);

		// true  - 로그 기록
		// false - 로그 예외
		boolean flag = true;

		String userIP = logVo.getClientIp();

		// 로그 예외 IP 리스트
		String[] IPList = new String[] {
				"10.45.1.104",			// 백태민 (CNS) 무선
				"10.64.76.31",			// 백태민 (CNS) 클라우드
				"165.243.184.34",		// 백태민 (CNS) 유선
				"10.45.1.44",			// 전정규 (CNS) 무선
				"10.45.1.113",			// 전정규 (CNS) 무선
				// Local
				"127.0.0.1",
				"0:0:0:0:0:0:0:1"
		};
		
		// IP 체크
		flag = !Arrays.asList(IPList).contains(userIP);

		// 의미 없는 로그 예외 처리
		if(logVo.getPath().startsWith("/namoEditor"))
			flag = false;

		if(flag) {
			// adminLogin 파라미터 삭제
			if("/adminLogin".equals(logVo.getPath())) {
				logVo.setParameterMap("");
				logVo.setRequestBody("");
			}

			httpLogJobExecutor.execute(new HttpLogTask(logVo));
		}
	}

    private class HttpLogTask implements Runnable {
        private LogVO logVo;

        public HttpLogTask(final LogVO logVo) {
            this.logVo = logVo;
        }

        @Override
        public void run() {
        	httpLogDao.createLog(this.logVo);
        }
    }

}
