package com.lgmma.salesPortal.common.controller;

import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lgmma.salesPortal.common.factory.CustomSqlSessionFactoryBean;
import com.lgmma.salesPortal.common.model.JsonResponse;

@Controller
public class SqlMapperReloader 
{
	@Autowired ApplicationContext applicationContext;
	@Autowired SqlSessionFactory sqlSessionFactory;
	
	@RequestMapping(value = "/sqlMapperReload")
	@ResponseBody
	public Map sqlMapperReload() throws Exception
	{
		CustomSqlSessionFactoryBean.getInstance().refresh();
		return JsonResponse.asSuccess();
	}
}
