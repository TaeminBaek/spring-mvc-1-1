package com.lgmma.salesPortal.common.props;

import java.util.Arrays;
import java.util.List;

public enum ApprState {
/**
 * 품의서상태로서
*/
	 TEMP_SAVE(				"1000"	,"임시저장"		,"임시저장"		,false	,true	,false)
	,APPR_PROCEEDING(		"2000"	,"품의중"			,"품의중"			,false	,false	,false)
	,APPR_REJECT(			"4010"	,"결재반려"		,"결재반려"		,true	,false	,true)
	,CONF_REJECT(			"4020"	,"합의반려"		,"합의반려"		,true	,false	,true)
	,APPR_COMPLETE(			"9000"	,"완료"			,"보고완료"		,true	,false	,false)
	,APPR_WRITE_COMPLETE(	"9010"	,"작성완료"		,"작성완료"		,true	,false	,false)
	,APPR_FORCE_END(		"9999"	,"강제종료"		,"강제종료"		,true	,false	,false)
	,APPR_SAMPLE_DELETE(	"9020"	,"품의유지"		,"완료후삭제"		,true	,false	,false)
	;

	String code		= null;		// 품의서상태코드
	String name		= null;		// 품의서상태명
	String name2	= null;		// 보고서상태명
	boolean endYn	= false;	// 품의서종료여부
	boolean editYn	= false;	// 품의서수정가능여부
	boolean rejectYn= false;	// 품의반려여부

	private ApprState(String code, String name, String name2, boolean endYn, boolean editYn, boolean rejectYn) {
		this.code		= code;
		this.name		= name;
		this.name2		= name2;
		this.endYn		= endYn;
		this.editYn 	= editYn;
		this.rejectYn	= rejectYn;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName2() {
		return name2;
	}

	public void setName2(String name2) {
		this.name2 = name2;
	}

	public boolean getEndYn() {
		return endYn;
	}

	public void setEndYn(boolean endYn) {
		this.endYn = endYn;
	}

	public boolean getEditYn() {
		return editYn;
	}

	public void setEditYn(boolean editYn) {
		this.editYn = editYn;
	}

	public boolean isRejectYn() {
		return rejectYn;
	}

	public void setRejectYn(boolean rejectYn) {
		this.rejectYn = rejectYn;
	}

	public boolean checkEndYn(String code) {
		for(ApprState state : ApprState.values()) {
			if(state.getCode().equals(code)) {
				return state.getEndYn();
			}
		}
		return false;
	}

	public boolean checkEditYn(String code) {
		for(ApprState state : ApprState.values()) {
			if(state.getCode().equals(code)) {
				return state.getEditYn();
			}
		}
		return false;
	}

	public static ApprState getApprState(String code) {
		for(ApprState type : ApprState.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
	public static List<ApprState> getDissApprStatList() {
		return Arrays.asList(
				TEMP_SAVE
				,APPR_PROCEEDING
				,APPR_REJECT
				,CONF_REJECT
				,APPR_COMPLETE
				,APPR_WRITE_COMPLETE
		);
	}
}
