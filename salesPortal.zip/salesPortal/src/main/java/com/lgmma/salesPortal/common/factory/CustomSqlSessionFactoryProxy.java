package com.lgmma.salesPortal.common.factory;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class CustomSqlSessionFactoryProxy implements InvocationHandler 
{
	private CustomSqlSessionFactoryBean target;
	
	public CustomSqlSessionFactoryProxy(CustomSqlSessionFactoryBean target)
	{
		this.target = target;
	}
	
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		return method.invoke(target.getParentObject(), args);
	}
}
