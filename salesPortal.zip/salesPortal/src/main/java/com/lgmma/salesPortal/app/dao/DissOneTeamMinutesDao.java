package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissOneTeamMinutesVO;

public interface DissOneTeamMinutesDao {
	
	void createDissOneTeamMinutes(DissOneTeamMinutesVO param);
	
	int getDissOneTeamMinutesListCount(DissOneTeamMinutesVO param);
	
	List<DissOneTeamMinutesVO> getDissOneTeamMinutesList(DissOneTeamMinutesVO param);
	
	DissOneTeamMinutesVO getDissOneTeamMinutesDetail(DissOneTeamMinutesVO param);
	
	void updateDissOneTeamMinutes(DissOneTeamMinutesVO param);
	
	void deleteDissOneTeamMinutes(DissOneTeamMinutesVO param);
	
	List<ApprVO> getDissOneTeamMinutesIngList(DissOneTeamMinutesVO param);
}
