package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.CommonCommentDao;
import com.lgmma.salesPortal.app.model.DissCommentVO;

@Repository
public class CommonCommentDaoImpl implements CommonCommentDao {
    private static final String MAPPER_NAMESPACE = "COMMONCOMMENT_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public int getCommentListCount(DissCommentVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCommentListCount", param);
	}

	@Override
	public List<DissCommentVO> getCommentList(DissCommentVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCommentList", param);
	}
	
	@Override
	public DissCommentVO getComment(DissCommentVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getComment", param);
	}
	
	@Override
	public void createComment(DissCommentVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createComment", param);
	}
	
	@Override
	public void updateComment(DissCommentVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateComment", param);
	}
	
	@Override
	public void deleteComment(DissCommentVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteComment", param);
	}
}
