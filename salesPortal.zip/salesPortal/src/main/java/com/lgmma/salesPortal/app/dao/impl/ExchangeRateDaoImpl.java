package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.ExchangeRateDao;
import com.lgmma.salesPortal.app.model.ExchangeRateVO;

@Repository
public class ExchangeRateDaoImpl implements ExchangeRateDao {
    private static final String MAPPER_NAMESPACE = "EXCHANGERATE_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public List<ExchangeRateVO> getExchangeRateList(ExchangeRateVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getExchangeRateList", param);
	}

	@Override
	public void mergeExchangeRate(ExchangeRateVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeExchangeRate", param);
	}

	@Override
	public void updateExchangeRate(ExchangeRateVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateExchangeRate", param);
	}

	@Override
	public void createExchangeRate(ExchangeRateVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createExchangeRate", param);
	}

	@Override
	public int getExchangeRateCount(ExchangeRateVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getExchangeRateCount", param);
	}

	@Override
	public List<ExchangeRateVO> getExchangeRateMonAvgList(ExchangeRateVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getExchangeRateMonAvgList", param);
	}

	@Override
	public ExchangeRateVO getExchangeRateListAvg(ExchangeRateVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getExchangeRateListAvg", param);
	}

	@Override
	public ExchangeRateVO getExchangeRateMonAvgListAvg(ExchangeRateVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getExchangeRateMonAvgListAvg", param);
	}

	@Override
	public ExchangeRateVO getLastExchangeRateInfo() {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getLastExchangeRateInfo");
	}
}
