package com.lgmma.salesPortal.app.service;

import com.lgmma.salesPortal.app.model.ApprVO;

public interface GportalPostProcess {

	void saveApprId(ApprVO apprVO);
	void deleteApprId(ApprVO apprVO);
	void completeProcess(ApprVO apprVO);
	void rejectProcess(ApprVO apprVO);
	String getApprContent(String keyId);
}
