package com.lgmma.salesPortal.app.model;

import java.util.List;

public class CreditGradeReportVO extends PagingParamVO {
	
	//ERP I/F 공통
	private String datum; //일자
	private String vkorg; //영업조직
	private String kunnr; //고객코드
	private String vtweg; //유통경로
	private String rdate; //회전일
	private String zbala; //채권잔액
	private String zmisu; //미수금

	//ERP I/F 채권현황
	private String kkber; //여신영역
	private String compName; //고객명
	private String stcd2; //사업자번호
	private String confAmnt; //신용한도액
	private String guarAmnt; //담보한도액
	private String klimk; //여신한도액
	
	//ERP I/F 조기경보
	private String busil;
	
	
	//조기경보 조회조건
	private String stDate;
	private String edDate;
	private String chgFlag;
	
	//RDB 조기경보
	private String kisdate;
	private String watchGrade; //WATCH등급
	private String kisGrade;   //KIS등급
	private String cfGrade;	//현금흐름등급
	private String otStop;	 //당좌거래정지/부도
	private String stMg;	   //법정관리/화의
	private String compGlag;   //변동여부
	private String compCode;   //SFA업체코드
	private String compGrade;  //신용등급
	private String modiNote;   //변경내역
	private String name1;
	
	private List<CreditGradeReportVO> erpCreditList; //채권현황 리스트
	private String creditYn; //채권 보유 여부
	private String damboYn; //담보 보유 여부
	
	public String getDatum() {
		return datum;
	}
	public void setDatum(String datum) {
		this.datum = datum;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getVtweg() {
		return vtweg;
	}
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	public String getRdate() {
		return rdate;
	}
	public void setRdate(String rdate) {
		this.rdate = rdate;
	}
	public String getZbala() {
		return zbala;
	}
	public void setZbala(String zbala) {
		this.zbala = zbala;
	}
	public String getZmisu() {
		return zmisu;
	}
	public void setZmisu(String zmisu) {
		this.zmisu = zmisu;
	}
	public String getKkber() {
		return kkber;
	}
	public void setKkber(String kkber) {
		this.kkber = kkber;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getStcd2() {
		return stcd2;
	}
	public void setStcd2(String stcd2) {
		this.stcd2 = stcd2;
	}
	public String getConfAmnt() {
		return confAmnt;
	}
	public void setConfAmnt(String confAmnt) {
		this.confAmnt = confAmnt;
	}
	public String getGuarAmnt() {
		return guarAmnt;
	}
	public void setGuarAmnt(String guarAmnt) {
		this.guarAmnt = guarAmnt;
	}
	public String getKlimk() {
		return klimk;
	}
	public void setKlimk(String klimk) {
		this.klimk = klimk;
	}
	public String getBusil() {
		return busil;
	}
	public void setBusil(String busil) {
		this.busil = busil;
	}
	
	public String getStDate() {
		return stDate;
	}
	public void setStDate(String stDate) {
		this.stDate = stDate;
	}
	public String getEdDate() {
		return edDate;
	}
	public void setEdDate(String edDate) {
		this.edDate = edDate;
	}
	
	public String getChgFlag() {
		return chgFlag;
	}
	public void setChgFlag(String chgFlag) {
		this.chgFlag = chgFlag;
	}
	
	public String getKisdate() {
		return kisdate;
	}
	public void setKisdate(String kisdate) {
		this.kisdate = kisdate;
	}
	public String getWatchGrade() {
		return watchGrade;
	}
	public void setWatchGrade(String watchGrade) {
		this.watchGrade = watchGrade;
	}
	public String getKisGrade() {
		return kisGrade;
	}
	public void setKisGrade(String kisGrade) {
		this.kisGrade = kisGrade;
	}
	public String getCfGrade() {
		return cfGrade;
	}
	public void setCfGrade(String cfGrade) {
		this.cfGrade = cfGrade;
	}
	public String getOtStop() {
		return otStop;
	}
	public void setOtStop(String otStop) {
		this.otStop = otStop;
	}
	public String getStMg() {
		return stMg;
	}
	public void setStMg(String stMg) {
		this.stMg = stMg;
	}
	public String getCompGlag() {
		return compGlag;
	}
	public void setCompGlag(String compGlag) {
		this.compGlag = compGlag;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getCompGrade() {
		return compGrade;
	}
	public void setCompGrade(String compGrade) {
		this.compGrade = compGrade;
	}
	public String getModiNote() {
		return modiNote;
	}
	public void setModiNote(String modiNote) {
		this.modiNote = modiNote;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public List<CreditGradeReportVO> getErpCreditList() {
		return erpCreditList;
	}
	public void setErpCreditList(List<CreditGradeReportVO> erpCreditList) {
		this.erpCreditList = erpCreditList;
	}
	public String getCreditYn() {
		return creditYn;
	}
	public void setCreditYn(String creditYn) {
		this.creditYn = creditYn;
	}
	public String getDamboYn() {
		return damboYn;
	}
	public void setDamboYn(String damboYn) {
		this.damboYn = damboYn;
	}
	
}
