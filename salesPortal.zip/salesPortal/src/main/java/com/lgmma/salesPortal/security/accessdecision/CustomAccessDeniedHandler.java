package com.lgmma.salesPortal.security.accessdecision;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandlerImpl;

import com.lgmma.salesPortal.config.WebSecurityConfig;

public class CustomAccessDeniedHandler extends AccessDeniedHandlerImpl {
	
	public CustomAccessDeniedHandler(String errorPage) {
		this.setErrorPage(errorPage);
	}
	
	public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
		request.setAttribute(WebSecurityConfig.REQUSET_ATTRIBUTE_REQUEST_URI_BEFORE_SECURITY, request.getRequestURI());
		super.handle(request, response, accessDeniedException);
	}
}
