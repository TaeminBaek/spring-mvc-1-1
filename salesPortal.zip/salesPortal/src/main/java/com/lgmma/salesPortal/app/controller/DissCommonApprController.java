package com.lgmma.salesPortal.app.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.GPortalListTypeRestService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.ApplState;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

/**
 * DISS 품의처리 컨트롤러
 */
@Controller
@RequestMapping("/dissAppr")
public class DissCommonApprController {

	private static Logger logger = LoggerFactory.getLogger(DissCommonApprController.class);

	@Autowired
	CommonController commonController;

	@Autowired
	private DirectOrderController directOrderController;

	@Autowired
	DissCommonApprMgmtService dissCommonApprMgmtService; 
	
	@Autowired
	private GPortalListTypeRestService gPortalListTypeRestService;

	@RequestMapping(value = "/dissApprCommonPopLoad")
	public ModelAndView dissApprCommonPopLoad(ModelAndView mav) {
		logger.debug("###########################dissApprCommonPopLoad");
		mav.setViewName("dissAppr/dissApprCommonPopLoad");
		return mav;
	}

	@RequestMapping(value = "/dissApprCommonPop")
	public ModelAndView dissApprCommonPopEdit(ModelAndView mav, DissApprCommonParamVO dissApprCommonParamVO) throws Exception{
		dissApprCommonParamVO = (DissApprCommonParamVO) StringUtil.nullToEmptyString(dissApprCommonParamVO);

		// 공통 체크 메세지
		dissApprCommonParamVO.setCommonCheckMessage(dissCommonApprMgmtService.getDissStepIngCheckMessage(dissApprCommonParamVO));

		mav.addObject("dissApprCommonParamVO",dissApprCommonParamVO);
		mav.addObject("dissPageType","APPRPOP");
		mav.setViewName("dissAppr/dissApprCommonPop/" + ApprType.getApprType(dissApprCommonParamVO.getApprType()).getTargetView());
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		CommonCodeVO commonCodeVO = new CommonCodeVO();
		// DISS 제품개선개발 등급
		commonCodeVO.setGrupCode("DISS_IMPD_DEVGRADE");
		mav.addObject("DISS_IMPD_DEVGRADE", commonController.getCode(commonCodeVO).get("items"));
		// DISS 개선개발제안구분
		commonCodeVO.setGrupCode("DISS_DEV_PROP_TYPE");
		mav.addObject("DISS_DEV_PROP_TYPE", commonController.getCode(commonCodeVO).get("items"));		
		// DISS 최종결과
		commonCodeVO.setGrupCode("DISS_COMP_RESULT");
		mav.addObject("DISS_COMP_RESULT", commonController.getCode(commonCodeVO).get("items"));
		// DISS 실패사유구분
		commonCodeVO.setGrupCode("DISS_FAIL_REASON_D");
		mav.addObject("DISS_FAIL_REASON_D", commonController.getCode(commonCodeVO).get("items"));
		// DISS 4M 관리등급
		commonCodeVO.setGrupCode("DISS_4M_MGMT_GRADE");
		mav.addObject("DISS_4M_MGMT_GRADE", commonController.getCode(commonCodeVO).get("items"));
		// DISS 규격변경여부
		commonCodeVO.setGrupCode("DISS_STD_CHG_YN");
		mav.addObject("DISS_STD_CHG_YN", commonController.getCode(commonCodeVO).get("items"));
		// DISS 이관여부
		commonCodeVO.setGrupCode("DISS_TRANS_YN");
		mav.addObject("DISS_TRANS_YN", commonController.getCode(commonCodeVO).get("items"));
		/*
		// SAP 플랜트
		mav.addObject("plantList", commonController.getSapCommonCodeListWithSelectDDLB("04").get("items"));
		*/
		// 플랜트
		commonCodeVO.setGrupCode("DISS_REQ_PLANT");
		mav.addObject("plantList", commonController.getCode(commonCodeVO).get("items"));
		//사후의견
		mav.addObject("commentYn", ApprType.getApprType(dissApprCommonParamVO.getApprType()).isCommentYn());
		// SAP 공통 코드가져오기(견본을 위해서 필수 필요)
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = directOrderController.getOrderCode(OrderType.SAMPLE);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));

		return mav;
	}

	//결재함 화면
	@RequestMapping(value = "/dissMyApprInfo")
	public ModelAndView dissMyApprInfo(ModelAndView mav, ApprLineVO apprLineVO) throws Exception {
		mav.setViewName("dissAppr/dissMyApprInfo");
		String today = Util.getToday(Util.YmdFmt);
		String tempYmd = DateUtil.addMonth(Util.getToday(),-12);
		mav.addObject("defaultToDay", today);
		mav.addObject("defaultFrDay",Util.convertDateStrFormat(tempYmd, Util.Ymd, Util.YmdFmt));
		mav.addObject("apprTypeList", ApprType.getApprTypeByGpSendType("LIST"));
		mav.addObject("applStatList", new ArrayList< ApplState >(Arrays.asList(ApplState.values())));

		mav.addObject("apprLineVO",apprLineVO);
		return mav;
	}

	//결재함 리스트 조회
	@RequestMapping(value = "/getDissMyApprList.json")
	public Map getDissMyApprList(@RequestBody(required = true) ApprLineVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", dissCommonApprMgmtService.getDissMyApprListCount(param), "storeData",
				dissCommonApprMgmtService.getDissMyApprList(param));
	}
	
//	@RequestMapping(value = "/getDissMyApprDetail.json")
//	public Map getDissMyApprDetail(@RequestBody(required = true) ApprLineVO param) throws Exception {
//		return JsonResponse.asSuccess("storeData", dissCommonApprMgmtService.getDissMyApprList(param));
//	}
	
	//나의 요청 진행현황 화면
	@RequestMapping(value = "/dissMyApprReqInfo")
	public ModelAndView dissMyApprReqInfo(ModelAndView mav) throws Exception {
		mav.setViewName("dissAppr/dissMyApprReqInfo");
		String today = Util.getToday(Util.YmdFmt);
		String tempYmd = DateUtil.addMonth(Util.getToday(),-1);
		mav.addObject("defaultToDay", today);
		mav.addObject("defaultFrDay",Util.convertDateStrFormat(tempYmd, Util.Ymd, Util.YmdFmt));
		mav.addObject("apprTypeList", ApprType.getApprTypeByGpSendType("LIST"));
		mav.addObject("apprStatList", ApprState.getDissApprStatList());
		return mav;
	}

	//나의 요청 진행현황 리스트 조회
	@RequestMapping(value = "/getDissMyApprReqList.json")
	public Map getDissMyApprReqList(@RequestBody(required = true) ApprVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", dissCommonApprMgmtService.getDissMyApprReqListCount(param), "storeData",
				dissCommonApprMgmtService.getDissMyApprReqList(param));
	}
	
	/**
	 * GPortal 연계결재시 GPortal 에서 호출 실행
	 * */
	@RequestMapping(value = "/GPortalApproval")
	public @ResponseBody Map approvalFromGPortal(@RequestBody(required = true) Map<String, String> param) throws Exception {
		logger.debug("################GPortalApproval-TEST");
		logger.debug("################ param :"+param.toString());
		String apprId         = param.get("APPKEY_01");
		String apprEmpId      = param.get("EMP_NO");
		String apprStatus     = param.get("APPR_STATUS");
		String apprEmpComment = param.get("COMMENT");
		
		String result = gPortalListTypeRestService.approvalAtcionFromGPortal(apprId, apprEmpId, apprStatus, apprEmpComment);
		//response.getWriter().write("APPROVAL ATCION FROM GPORTAL END");
		logger.debug("################GPortalApproval-TEST result"+JsonResponse.asSuccess("RESULT",result,"ERR_MSG","").toString());
		if("S".equals(result)) {
			return JsonResponse.asSuccess("RESULT",result,"ERR_MSG","");
		}else {
			return JsonResponse.newInstance().setSuccess(false).addAttributes("RESULT","F","ERR_MSG",result).getResponseData();
		}
		
	}
}
