package com.lgmma.salesPortal.common.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.props.PeriodCodes;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.UserInfo;

public class JsonRequest extends HashMap
{
	//사용자 아이디
	private static final String userIdParamName = "SES_USER_ID";
	//사용자명
	private static final String userNameParamName = "SES_USER_NM";	
	//사용자 영업라인
	private static final String userCompanyParamName = "SES_COMPANY_CD";
	//사용자 접근 가능 채널
	private static final String userChannelsParamName = "SES_USER_CHANNELS";
	//사용자 권한
	private static final String userRoleParamName = "SES_USER_ROLE";
	//사이트 코드
	private static final String siteCodeName = "SES_SITE_CODE";
	private static final String siteCode = "S300";

	private HttpServletRequest httpServletRequest;
	
	public JsonRequest()
	{	
		injectUserInfo();
	}

	public JsonRequest(Map map)
	{	
		super(map);
		injectUserInfo();
	}
	
	private void injectUserInfo()
	{
		UserInfo userInfo = Util.getUserInfo();
		if(userInfo != null) {
			this.put(userIdParamName, userInfo.getUsername());
//			this.put(userNameParamName, userInfo.getUserNm());
//			this.put(userRoleParamName, userInfo.getUserRole());
			this.put(siteCodeName, siteCode);
		}
	}
	
	public void injectPagingParams()
	{
		int start = getInt("start");
		int limit = getInt("limit");
		int page = getInt("page");
		
		put("RNUM_FROM", start+1);
		put("RNUM_TO", limit*page);
	}
	
	public String getString(String key)
	{
		return getAs(key, String.class);
	}

	public List getList(String key)
	{
		return getList(key, false);
	}
	
	public List getList(String key, boolean getCopied)
	{
		List list = this.getAs(key, List.class);
		if(list == null) 
		{
			//throw new ServiceException("ERROR_LIST_TO_SAVE_IS_NULL");
			return null;
		}		
		int size = list.size();
		List ret = new ArrayList(); 
		for(int n=0; n<size; n++)
		{
			Object row = list.get(n);
			if(row instanceof Map)
			{
				ret.add(new JsonRequest((Map)row));
			}
			else
			{
				ret.add(row);
			}
		}
		if(!getCopied) put(key, ret);
		return ret;
	}
	
	public List getCopiedList(String key)
	{
		return getList(key, true);
	}
	
	public JsonRequest getMap(String key)
	{
		return getMap(key, false);
	}
	
	public JsonRequest getMap(String key, boolean getCopied)
	{
		JsonRequest map = new JsonRequest(this.getAs(key, Map.class));
		if(!getCopied) put(key, map);
		return map;
	}
	
	public JsonRequest getCopiedMap(String key)
	{
		return getMap(key, true);
	}
	
	public int getInt(String key)
	{
		return getAs(key, Integer.class);
	}
	
	public <T> T getAs(String key, Class<T> cls)
	{
		return (T)this.get(key);
	}
	
	public boolean isNull(String key)
	{
		return Util.isNull(get(key));
	}
	
	public String nvl(String key)
	{
		return nvl(key, "");
	}
	
	public <T> T nvl(String key, T value)
	{
		return (T) Util.nvl(getString(key), value);
	}
	
	public boolean isAllNull(String...key){
		for(int n=0; n<key.length; n++)
		{
			if(!isNull(key[n]))
			{
				return false;
			}
		}
		return true;
	}
	
	public boolean isAllNotNull(String...key)
	{
		for(int n=0; n<key.length; n++)
		{
			if(isNull(key[n]))
			{
				return false;
			}
		}
		return true;
	}
	
	public <T> T replaceGetIfNull(String key, T value)
	{
		if(isNull(key)) put(key, value);
		return (T)get(key);
	}
	
	public String remainOnlyNumber(String key)
	{
		String value = getString(key);
		if(value != null)
		{
			value = value.replaceAll("\\D", "");
			put(key, value);
		}
		return value;
	}
	
	public String remainOnlyNumber(String key, int length)
	{
		String value = remainOnlyNumber(key);
		if(value != null)
		{
			value = value.substring(0, Math.min(length, value.length()));
			put(key, value);
		}
		return value;
	}
	
	/**
	 * 문자열 비교. 둘 중 하나라도 널이면 false
	 */
	public boolean is(String key, Object thatValue)
	{
		Object thisValue = get(key);
		return Util.is(thisValue, thatValue);
	}

	public boolean isIn(String key, Object...thatValues)
	{
		Object thisValue = get(key);
		return Util.isIn(thisValue, thatValues);
	}
	
	public void setHttpServletRequest(HttpServletRequest httpServletRequest)
	{
		this.httpServletRequest = httpServletRequest;
	}
	
	public HttpServletRequest getHttpServletRequest()
	{
		return this.httpServletRequest;
	}
	
	public void put(Object...obj)
	{
		for(int n=0; n<obj.length; n++)
		{
			put(String.valueOf(obj[n]), obj[++n]);
		}
	}
	
	@Override
	public Object get(Object key)
	{
		Object ret = super.get(key);
		if(ret!= null && ret instanceof String) {
			ret = ((String)ret).trim();
		}
		return ret;		
	}
	
	@Override
	public Object put(Object key, Object value)
	{
		return super.put(key, value instanceof PeriodCodes ? ((PeriodCodes)value).getCode() : value);
	}
}
