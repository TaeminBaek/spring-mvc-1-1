package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.GenVocVO;


public interface GenVocMgmtService {

	List<GenVocVO> getGenVocItemList();
	
	int getGenVocCount(GenVocVO param);
	
	List<GenVocVO> getGenVocList(GenVocVO param);

	GenVocVO getGenVocDetail(GenVocVO param);
	
	void updateGenVocReply(GenVocVO param);

	void createGenVocReply(GenVocVO param);

	void deleteGenVocReply(GenVocVO param);
	
	void updateGenVocEmailSendYn(GenVocVO param);
}
