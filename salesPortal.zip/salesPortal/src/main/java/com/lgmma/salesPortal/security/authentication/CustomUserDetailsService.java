package com.lgmma.salesPortal.security.authentication;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.lgmma.salesPortal.app.dao.LoginDao;
import com.lgmma.salesPortal.common.util.StringUtil;

@Service
public class CustomUserDetailsService implements UserDetailsService {
	
	@Autowired LoginDao loginDao;

    @Autowired
    private MessageSourceAccessor messageSourceAccessor;

    @Autowired
    private MenuLoaderService menuLoaderService;
    
	public UserDetails loadUserByUsername(String empNo) throws UsernameNotFoundException {
        UserInfo user = loginDao.getUserInfo(empNo);
/*
        if(user == null || (!user.isAdmin() && !user.isEmp() && !user.isPartner())) {
   			throw new BadCredentialsException(messageSourceAccessor.getMessage("fail.common.login"));
        }
        List<GrantedAuthority> userAuthorities = new ArrayList<GrantedAuthority>();
    	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_USER"));	//기본 ROLE
        if(user.isAdmin()) {
        	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_ADMIN"));	//ADMIN
        }
        if(user.isEmp()) {
        	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_EMP"));	//임직원
        }
        if(user.isPartner()) {
        	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_PARTNER"));	//파트너
        }
        user.setAuthorities(userAuthorities);
*/        
        //사용자 메뉴
//        user.getAllowedMenuMap().put("01", menuLoaderService.getUserMenu(user, "UserMenu.xml"));
        return user;
	}

	public UserInfo loadPartnerUser(String userId) {
        UserInfo user = loginDao.getPartnerUserInfo(userId);
        if(user == null) {
   			throw new BadCredentialsException(messageSourceAccessor.getMessage("fail.common.login"));
        }
        List<GrantedAuthority> userAuthorities = new ArrayList<GrantedAuthority>();
    	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_USER"));	//로그인유저
    	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_PARTNER"));	//파트너
        user.setAuthorities(userAuthorities);
		return user;
	}

	public UserInfo loadEmpUser(String userId) {
        UserInfo user = loginDao.getEmpUserInfo(userId);
        if(user == null) {
   			throw new BadCredentialsException(messageSourceAccessor.getMessage("fail.common.login"));
        }
        List<GrantedAuthority> userAuthorities = new ArrayList<GrantedAuthority>();
    	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_USER"));	//로그인유저
    	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_EMP"));	//임직원
    	if(user.isAdmin()) {
        	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_ADMIN"));	//admin
    	}
    	if(loginDao.getCreditEmpUserInfo(userId).size() > 0) {
        	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_CREDIT"));	//여신 및 담보 관리자
    	}
        user.setAuthorities(userAuthorities);
        user.setUserType("E");
		return user;
	}

	public UserInfo loadPartnerUser(String partnerId, String partnerPwd) {
        UserInfo user = loginDao.getPartnerUserInfo(partnerId);
        if(user == null) {
   			throw new BadCredentialsException(messageSourceAccessor.getMessage("fail.common.login"));
        }
        String encriptPwd = loginDao.getEncryptPwd(StringUtil.encrypt(partnerPwd));
        if(!user.getPassword().equals(encriptPwd)) {
   			throw new BadCredentialsException(messageSourceAccessor.getMessage("fail.common.login"));
        }
        List<String> vkorgList = loginDao.getVkorg(user.getCompCode());
        if(vkorgList.size() > 1) {
            user.setVkorg("ALL");
        } else {
            user.setVkorg(vkorgList.get(0));
        }
        List<GrantedAuthority> userAuthorities = new ArrayList<GrantedAuthority>();
    	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_USER"));	//로그인유저
    	userAuthorities.add((GrantedAuthority)new SimpleGrantedAuthority("ROLE_PARTNER"));	//파트너
        user.setAuthorities(userAuthorities);
        user.setUserType("P");
		return user;
	}

}
