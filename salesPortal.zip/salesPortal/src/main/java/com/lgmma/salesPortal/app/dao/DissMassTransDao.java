package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissMassTransVO;

public interface DissMassTransDao {	
	
	DissMassTransVO getDissMassTransInfo(DissMassTransVO param);
	
	void createDissMassTrans(DissMassTransVO param);
	
	void updateDissMassTrans(DissMassTransVO param);
	
	void deleteDissMassTransAll(DissMassTransVO param);
	

}
