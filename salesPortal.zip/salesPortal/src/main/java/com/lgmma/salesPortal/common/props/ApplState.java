package com.lgmma.salesPortal.common.props;

public enum ApplState {
/**
 * 결재자결재결과로서
*/
	 APPL_APPROVE(	"A"	,"완료"	,true,false,"2")
	,APPL_REJECT(	"R"	,"반려"	,true,true,"3")
	,APPL_CONFIRM(	"C"	,"합의"	,true,false,"4")
	,APPL_WAITING(	"W"	,"미결"	,false,false,"0")
	;
	String code			= null;		// 결재상태코드
	String name			= null;		// 결재상태명
	boolean applYn		= false;	// 결재액션여부
	boolean rejectYn	= false;	// 반려여부
	String listTypeGpApplStat = null; // gportal 목록연동방식 상태값 맵핑

	private ApplState(String code, String name, boolean applYn, boolean rejectYn,String listTypeGpApplStat) {
		this.code	= code;
		this.name	= name;
		this.applYn = applYn;
		this.rejectYn= rejectYn;
		this.listTypeGpApplStat = listTypeGpApplStat;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isApplYn() {
		return applYn;
	}

	public void setApplYn(boolean applYn) {
		this.applYn = applYn;
	}

	public boolean isRejectYn() {
		return rejectYn;
	}

	public void setRejectYn(boolean rejectYn) {
		this.rejectYn = rejectYn;
	}

	public String getListTypeGpApplStat() {
		return listTypeGpApplStat;
	}

	public void setListTypeGpApplStat(String listTypeGpApplStat) {
		this.listTypeGpApplStat = listTypeGpApplStat;
	}

	public static ApplState getApplState(String code) {
		for(ApplState type : ApplState.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
}
