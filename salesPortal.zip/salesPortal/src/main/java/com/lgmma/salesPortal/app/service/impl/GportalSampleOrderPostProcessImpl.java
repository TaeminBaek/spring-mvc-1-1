package com.lgmma.salesPortal.app.service.impl;

import com.lgmma.salesPortal.app.dao.SampleOrderDao;
import com.lgmma.salesPortal.app.model.*;
import com.lgmma.salesPortal.app.service.GportalPostProcess;
import com.lgmma.salesPortal.app.service.VocMgmtService;
import com.lgmma.salesPortal.common.util.StringUtil;
import freemarker.template.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Transactional
@Service
public class GportalSampleOrderPostProcessImpl implements GportalPostProcess {

	private static Logger logger = LoggerFactory.getLogger(GportalSampleOrderPostProcessImpl.class);

	private final String REPORT_TEMPLATE_SAMPLE_ORDER = "REPORT_TEMPLATE_SAMPLE_ORDER";

	@Autowired
	private SampleOrderDao sampleOrderDao;

	@Autowired
	private VocMgmtService vocMgmtService;

	@Autowired
	@Qualifier(value="reportFreemarkerConfiguration")
	private Configuration reportTemplateConfiguration;

	/**
	 * 품의서 저장 후 원본테이블에 apprId 등록
	 * @param apprVO
	 */
	@Override
	public void saveApprId(ApprVO apprVO) {
		SampleOrderMasterVO param = new SampleOrderMasterVO();
		param.setOrderId(apprVO.getKeyId());
		param = sampleOrderDao.getSampleOrderDetail(param);
		param.setApprId(apprVO.getApprId());
		sampleOrderDao.updateSampleOrderApprId(param);
		// vactId로 VOC 요청내역 품의서 연결
		param = (SampleOrderMasterVO) StringUtil.nullToEmptyString(param);
		logger.debug(param.toString());
		if(param.getVactIdxx().length() > 0){
			sampleOrderDao.updateSampleOrderAfterVocActInfo(param);
		}
	}

	/**
	 * 품의서 삭제 후 원본테이블 apprId null 처리
	 * @param apprVO
	 */
	@Override
	public void deleteApprId(ApprVO apprVO) {
		SampleOrderMasterVO param = new SampleOrderMasterVO();
		param.setApprId(apprVO.getApprId());
		param = sampleOrderDao.getSampleOrderDetail(param);
		param.setApprId(apprVO.getApprId());
		sampleOrderDao.updateSampleOrderApprIdToNull(param);
		param = (SampleOrderMasterVO)StringUtil.nullToEmptyString(param);
		// vactId로 VOC 요청내역 품의서 연결 끊기
		if(param.getVactIdxx().length() > 0){
			param.setApprId("");
			sampleOrderDao.updateSampleOrderAfterVocActInfo(param);
		}
	}

	/**
	 * 결재 완료 후 후처리
	 * @param apprVO
	 */
	@Override
	public void completeProcess(ApprVO apprVO) {
		// 견본주문상세 조회
		SampleOrderMasterVO param = new SampleOrderMasterVO();
		param.setApprId(apprVO.getApprId());
		param = sampleOrderDao.getSampleOrderDetail(param);

		param = (SampleOrderMasterVO) StringUtil.nullToEmptyString(param);

		// 조회된 내역으로 voc쪽 품의 완료 후처리
		if(param.getVactIdxx().length() > 0) {
			VocActPopVO vocActPopVO = new VocActPopVO();
			vocActPopVO.setRegiIdxx(param.getUpdtIdxx());
			vocActPopVO.setVactIdxx(Integer.parseInt(param.getVactIdxx()));
			vocMgmtService.saveVocActAppr(vocActPopVO);
		}
	}

	/**
	 * 결재 반려 후 후처리
	 * @param apprVO
	 */
	@Override
	public void rejectProcess(ApprVO apprVO) {
		SampleOrderMasterVO param = new SampleOrderMasterVO();
		param.setApprId(apprVO.getApprId());
		param = sampleOrderDao.getSampleOrderDetail(param);
		param = (SampleOrderMasterVO) StringUtil.nullToEmptyString(param);
		logger.debug(param.toString());
		/*
		// VOC 에 연결 되었다면 끊는다.
		if(param.getVactIdxx().length() > 0){
			param.setOrderId("");
			param.setApprId("");
			sampleOrderDao.updateSampleOrderAfterVocActInfo(param);
		}
		*/
	}

	/**
	 * 품의서 최초 등록시 컨텐츠 내용이 미리 셋팅 되어야 할때
	 * @param orderId
	 * @return
	 */
	@Override
	public String getApprContent(String orderId) {
		//logger.debug("######################SAM-TEST");
		SampleOrderMasterVO param = new SampleOrderMasterVO();
		param.setOrderId(orderId);

		SampleOrderMasterVO sampleOrderMasterVO = (SampleOrderMasterVO) StringUtil.nullToEmptyString(sampleOrderDao.getSampleOrderDetail(param));
		List<DirectOrderItemVO> orderItemList = sampleOrderDao.getSampleOrderItemList(orderId);
		List<DirectOrderItemVO> copyOrderItemList = new ArrayList<DirectOrderItemVO>();
		for(DirectOrderItemVO itemVO : orderItemList){
			copyOrderItemList.add((DirectOrderItemVO) StringUtil.nullToEmptyString(itemVO));
		}
		int rowspan = orderItemList.size() + 1; // 헤더까지

		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("sampleOrderMasterVO", sampleOrderMasterVO);
		map.put("orderItemList", copyOrderItemList);
		map.put("rowspan", rowspan);
		try{
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(
					reportTemplateConfiguration.getTemplate(REPORT_TEMPLATE_SAMPLE_ORDER + ".txt"), map));
			return content.toString();
		}catch(Exception e){
			logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
		}
		return "";	}
}
