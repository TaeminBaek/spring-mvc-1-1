package com.lgmma.salesPortal.app.model;

public class DissApprCommonParamVO extends PagingParamVO {
	/* DISS Appr common param */
	private String apprId;
	private String apprType;
	private String taskId;
	private String taskType;
	private String stepId;
	private String stepCd;
	private String mode;               //EDIT,VIEW 구분
	private String apprApplCheck;     //결재승인권한체크
	private String apprLineType;      //결재라인유형(결재,합의)
	private String apprLineComment;   // 결재자 결재 코멘트
	private String applStat;          // 결재자 결재 코드
	private String apprEmpId;         // 결재자 사번
	private String commonCheckMessage;// 공통체크 메세지
	private String custCode;            // 고객코드
	private String relApprId;

	public String getApprId() {
		return apprId;
	}

	public void setApprId(String apprId) {
		this.apprId = apprId;
	}

	public String getApprType() {
		return apprType;
	}

	public void setApprType(String apprType) {
		this.apprType = apprType;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getStepCd() {
		return stepCd;
	}

	public void setStepCd(String stepCd) {
		this.stepCd = stepCd;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getApprApplCheck() {
		return apprApplCheck;
	}

	public void setApprApplCheck(String apprApplCheck) {
		this.apprApplCheck = apprApplCheck;
	}

	public String getApprLineType() {
		return apprLineType;
	}

	public void setApprLineType(String apprLineType) {
		this.apprLineType = apprLineType;
	}

	public String getApprLineComment() {
		return apprLineComment;
	}

	public void setApprLineComment(String apprLineComment) {
		this.apprLineComment = apprLineComment;
	}

	public String getApplStat() {
		return applStat;
	}

	public void setApplStat(String applStat) {
		this.applStat = applStat;
	}

	public String getApprEmpId() {
		return apprEmpId;
	}

	public void setApprEmpId(String apprEmpId) {
		this.apprEmpId = apprEmpId;
	}

	public String getCommonCheckMessage() {
		return commonCheckMessage;
	}

	public void setCommonCheckMessage(String commonCheckMessage) {
		this.commonCheckMessage = commonCheckMessage;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	
	public String getRelApprId() {
		return relApprId;
	}

	public void setRelApprId(String relApprId) {
		this.relApprId = relApprId;
	}
}
