package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissScheduleVO;
import com.lgmma.salesPortal.app.model.DissExcelDownloadVO;
import com.lgmma.salesPortal.app.model.DissSpecInSaleGoalVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.DissStepVO;

public interface DissSpecInService {

	List<DissSpecInVO> getDissSpecInList(DissSpecInVO param);

	int getDissSpecInListCount(DissSpecInVO param);

	DissSpecInVO getDissSpecInInfo(DissSpecInVO dissSpecInVO);

	DissSpecInVO getDissSpecInInfoHis(DissSpecInVO dissSpecInVOParam);

	DissSpecInVO getDissSpecInInfoAll(DissSpecInVO dissSpecInVOParam);

	DissSpecInVO getDissSpecInInfoHisAll(DissSpecInVO dissSpecInVOParam);

	List<DissScheduleVO> getDissScheduleList(String taskId);

	List<DissScheduleVO> getDissScheduleListHis(String stepId);

	List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalList(String taskId);

	List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalListFist(String taskId);

	List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalListHis(String stepId);

	void saveDissSpecIn(DissSpecInVO param);

	void deleteSpecInSaleGoalAndInsertAll(DissSpecInVO param, Integer seq);

	void deleteSpecInSaleGoalAndInsertAllHis(DissSpecInVO param);

	void deleteSpecInScheduleAndInsertAll(DissSpecInVO param);

	void deleteDissSpecIn(DissSpecInVO param);

	void saveDissSpecInHis(DissSpecInVO param);

	void tempSaveDissSpecIn(DissSpecInVO param);

	void reqGateReview(DissSpecInVO param);

	void deleteSpecInScheduleAndInsertAllHis(DissSpecInVO param);

	void saveSpecInGateReview(DissSpecInVO dissSpecInVO);

	void tempSaveSpecInGateReview(DissSpecInVO dissSpecInVO);

	void compSpecInGateReview(DissSpecInVO dissSpecInVO);

	void cancelSpecInGateReview(DissSpecInVO dissSpecInVO);

	void changeTsEmpGateReview(DissSpecInVO dissSpecInVO);
	
	void changeSpecInDevLevel(DissSpecInVO dissSpecInVO);

	void applActDissSpecInAfterGateReview(DissApprCommonParamVO dissApprCommonParamVO);

	void dissSpecInRewrite(DissSpecInVO dissSpecInVO);

	DissSpecInVO getDissSpecInTaskBasicInfoDetail(DissStepVO dissStepVO);

	void saveColorProposal(DissSpecInVO dissSpecInVO);

	void applColorProposal(DissApprCommonParamVO dissApprCommonParamVO);

	void saveColorPrescription(DissSpecInVO dissSpecInVO);

	void applColorPrescription(DissApprCommonParamVO dissApprCommonParamVO);

	void editSpecInSchedule(DissSpecInVO dissSpecInVO);

	void updateSpecInSchedule(DissSpecInVO dissSpecInVO);

	void deleteSpecInScheduleEdit(DissSpecInVO dissSpecInVO);

	void applDissSpecInScheduleEdit(DissApprCommonParamVO dissApprCommonParamVO);
	
	void editSpecInCtq(DissSpecInVO dissSpecInVO);

	List<DissExcelDownloadVO> getDissSpecInListExcelDownload(DissSpecInVO param);

	List<DissSpecInVO> getFailSpecInList(DissSpecInVO param);

	int getFailSpecInListCnt(DissSpecInVO param);
	
	String getApprFormCont(DissSpecInVO param); //kjy
	
	String getApprFormContColorProposal(DissSpecInVO param, String templeteFormContent);
}
