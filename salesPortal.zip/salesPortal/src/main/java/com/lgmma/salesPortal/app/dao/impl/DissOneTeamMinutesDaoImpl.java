package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissOneTeamMinutesDao;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissOneTeamMinutesVO;
import com.lgmma.salesPortal.app.model.DissOneTeamVO;

@Repository
public class DissOneTeamMinutesDaoImpl implements DissOneTeamMinutesDao{
	
	private static final String MAPPER_NAMESPACE = "DISSONETEAM_MINUTES_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public void createDissOneTeamMinutes(DissOneTeamMinutesVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissOneTeamMinutes", param);
	}

	@Override
	public int getDissOneTeamMinutesListCount(DissOneTeamMinutesVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissOneTeamMinutesListCount", param);
	}

	@Override
	public List<DissOneTeamMinutesVO> getDissOneTeamMinutesList(DissOneTeamMinutesVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissOneTeamMinutesList", param);
	}

	@Override
	public DissOneTeamMinutesVO getDissOneTeamMinutesDetail(DissOneTeamMinutesVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissOneTeamMinutesDetail", param);
	}

	@Override
	public void updateDissOneTeamMinutes(DissOneTeamMinutesVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissOneTeamMinutes", param);
	}

	@Override
	public void deleteDissOneTeamMinutes(DissOneTeamMinutesVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissOneTeamMinutes", param);
	}

	@Override
	public List<ApprVO> getDissOneTeamMinutesIngList(DissOneTeamMinutesVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissOneTeamMinutesIngList",param);
	}
}
