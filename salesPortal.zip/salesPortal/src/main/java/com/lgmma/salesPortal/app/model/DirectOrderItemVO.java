package com.lgmma.salesPortal.app.model;

import java.util.List;

public class DirectOrderItemVO extends PagingParamVO {
	
	private String orderId;
	private int seq;
	private String material;
	private String plant;
	private String plantText;
	private String storeLoc;
	private String storeLocText;
	private String reqDate;
	private int reqQty;
	private double pr00Price;
	private String currency;
	private String condUnit;
	private String condUnitText;
	private int condPUnt;
	private String reasonRej;
	private String highValueYn;
	private String highValue;
	private String pltypName;
	private String priceListI;
	private String spTypeKind;
	private String spTypeKindName;
	private String prodUsgx; // 견본조회용:용도
	private String vkbur; // 관리팀 

	private List<DirectOrderItemVO> itemList;
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getStoreLoc() {
		return storeLoc;
	}
	public void setStoreLoc(String storeLoc) {
		this.storeLoc = storeLoc;
	}
	public String getReqDate() {
		return reqDate;
	}
	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}
	public int getReqQty() {
		return reqQty;
	}
	public void setReqQty(int reqQty) {
		this.reqQty = reqQty;
	}
	public double getPr00Price() {
		return pr00Price;
	}
	public void setPr00Price(double pr00Price) {
		this.pr00Price = pr00Price;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCondUnit() {
		return condUnit;
	}
	public void setCondUnit(String condUnit) {
		this.condUnit = condUnit;
	}
	public int getCondPUnt() {
		return condPUnt;
	}
	public void setCondPUnt(int condPUnt) {
		this.condPUnt = condPUnt;
	}
	public String getReasonRej() {
		return reasonRej;
	}
	public void setReasonRej(String reasonRej) {
		this.reasonRej = reasonRej;
	}
	public String getHighValueYn() {
		return highValueYn;
	}
	public void setHighValueYn(String highValueYn) {
		this.highValueYn = highValueYn;
	}
	public String getHighValue() {
		return highValue;
	}
	public void setHighValue(String highValue) {
		this.highValue = highValue;
	}
	public String getCondUnitText() {
		return condUnitText;
	}
	public void setCondUnitText(String condUnitText) {
		this.condUnitText = condUnitText;
	}
	public String getPlantText() {
		return plantText;
	}
	public void setPlantText(String plantText) {
		this.plantText = plantText;
	}
	public String getStoreLocText() {
		return storeLocText;
	}
	public void setStoreLocText(String storeLocText) {
		this.storeLocText = storeLocText;
	}
	public String getPltypName() {
		return pltypName;
	}
	public void setPltypName(String pltypName) {
		this.pltypName = pltypName;
	}

	public String getProdUsgx() {
		return prodUsgx;
	}

	public void setProdUsgx(String prodUsgx) {
		this.prodUsgx = prodUsgx;
	}
	public List<DirectOrderItemVO> getItemList() {
		return itemList;
	}
	public void setItemList(List<DirectOrderItemVO> itemList) {
		this.itemList = itemList;
	}
	public String getPriceListI() {
		return priceListI;
	}
	public void setPriceListI(String priceListI) {
		this.priceListI = priceListI;
	}
	public String getSpTypeKind() {
		return spTypeKind;
	}
	public void setSpTypeKind(String spTypeKind) {
		this.spTypeKind = spTypeKind;
	}
	public String getSpTypeKindName() {
		return spTypeKindName;
	}
	public void setSpTypeKindName(String spTypeKindName) {
		this.spTypeKindName = spTypeKindName;
	}
	public String getVkbur() {
		return vkbur;
	}
	public void setVkbur(String vkbur) {
		this.vkbur = vkbur;
	}
	
}
