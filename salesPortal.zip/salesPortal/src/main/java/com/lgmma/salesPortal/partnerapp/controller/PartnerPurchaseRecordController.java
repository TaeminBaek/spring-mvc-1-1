package com.lgmma.salesPortal.partnerapp.controller;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.controller.CommonController;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;

@Controller
@RequestMapping("/partner")
public class PartnerPurchaseRecordController {
	
	@Autowired
	CommonController commonController;
	
	@Autowired
	SapSearchService sapSearchService;
	
	@RequestMapping(value = "/monthPurchaseRecordInfo")
	public ModelAndView partnerMonthPurchaseRecordInfo(ModelAndView mav) throws Exception {
		mav.setViewName("partner/purchaseRecord/monthPurchaseRecordInfo");
		mav.addObject("vkorgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("defaultYm", DateUtil.getCurrentYear().concat(".").concat(DateUtil.getToday().substring(4, 6)));
		return mav;
	}
	
	@RequestMapping(value = "/getMonthPurchaseRecordList.json")
	public Map getMonthPurchaseRecordList(@RequestParam(required=false) String vkorg, @RequestParam(required=false) String jproName, @RequestParam(required=false) String compCode, @RequestParam(required=false) String sdate, @RequestParam(required=false) String edate) throws Exception {
		List<Map> monthPurchaseRecordList = sapSearchService.getMonthPurchaseRecordList(vkorg, jproName, compCode, sdate, edate);
		
		for(Map sales : monthPurchaseRecordList) {
			sales.put("matnr", sales.get("MATNR"));			//제품
			sales.put("spmon", sales.get("SPMON"));			//출하일
			sales.put("ummenge", sales.get("UMMENGE"));		//수량
			sales.put("umnetwr", sales.get("UMNETWR"));		//금액
		}
		return JsonResponse.asSuccess("storeData", monthPurchaseRecordList);
	}
	
	@RequestMapping(value = "/dayPurchaseRecordInfo")
	public ModelAndView partnerDayPurchaseRecordInfo(ModelAndView mav) throws Exception {
		mav.setViewName("partner/purchaseRecord/dayPurchaseRecordInfo");
		mav.addObject("vkorgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		return mav;
	}
	
	@RequestMapping(value = "/getDayPurchaseRecordList.json")
	public Map getDayPurchaseRecordList(@RequestParam(required=false) String vkorg, @RequestParam(required=false) String jproName, @RequestParam(required=false) String compCode, @RequestParam(required=false) String sdate, @RequestParam(required=false) String edate) throws Exception {
		String userType = (((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getUserType());
		String sawnCode = (((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getSawnCode());
		List<Map> dayPurchaseRecordList = sapSearchService.getDayPurchaseRecordList(vkorg, jproName, compCode, sdate, edate, userType, sawnCode);
		
		for(Map sales : dayPurchaseRecordList) {
			sales.put("matnr", sales.get("MATNR"));			//제품
			sales.put("sptag", sales.get("SPTAG"));			//출하일
			sales.put("ummenge", sales.get("UMMENGE"));		//수량
			sales.put("name1", sales.get("NAME1"));			//인도처
			sales.put("vtext", sales.get("VTEXT"));			//출하지점
		}
		return JsonResponse.asSuccess("storeData", dayPurchaseRecordList);
	}
	
}
