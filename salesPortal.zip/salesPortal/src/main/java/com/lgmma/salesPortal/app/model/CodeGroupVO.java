package com.lgmma.salesPortal.app.model;

public class CodeGroupVO extends PagingParamVO {
	private String grupCode;
	private String grupName;
	private String deleIsxx;
	private String condHead1;
	private String condHead2;
	public String getGrupCode() {
		return grupCode;
	}
	public void setGrupCode(String grupCode) {
		this.grupCode = grupCode;
	}
	public String getGrupName() {
		return grupName;
	}
	public void setGrupName(String grupName) {
		this.grupName = grupName;
	}
	public String getDeleIsxx() {
		return deleIsxx;
	}
	public void setDeleIsxx(String deleIsxx) {
		this.deleIsxx = deleIsxx;
	}
	public String getCondHead1() {
		return condHead1;
	}
	public void setCondHead1(String condHead1) {
		this.condHead1 = condHead1;
	}
	public String getCondHead2() {
		return condHead2;
	}
	public void setCondHead2(String condHead2) {
		this.condHead2 = condHead2;
	}
}
