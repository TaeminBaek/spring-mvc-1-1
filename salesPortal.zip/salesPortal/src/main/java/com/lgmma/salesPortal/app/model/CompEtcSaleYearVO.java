package com.lgmma.salesPortal.app.model;

public class CompEtcSaleYearVO {
	
	private String compCode;
	private String saleYear;
	private String saleTotx;
	private String bigoText;
	
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getSaleYear() {
		return saleYear;
	}
	public void setSaleYear(String saleYear) {
		this.saleYear = saleYear;
	}
	public String getSaleTotx() {
		return saleTotx;
	}
	public void setSaleTotx(String saleTotx) {
		this.saleTotx = saleTotx;
	}
	public String getBigoText() {
		return bigoText;
	}
	public void setBigoText(String bigoText) {
		this.bigoText = bigoText;
	}
	
	

}
