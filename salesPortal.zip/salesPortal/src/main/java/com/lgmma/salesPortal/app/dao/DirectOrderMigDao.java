package com.lgmma.salesPortal.app.dao;

import com.lgmma.salesPortal.app.model.DirectOrderMigVO;


public interface DirectOrderMigDao {

	void createDirectOrderMig(DirectOrderMigVO param);
	
	DirectOrderMigVO createDirectOrderMigTrans(DirectOrderMigVO param);

}
