package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.DocTemplateVO;


public interface DocTemplateMgmtService {
	

	int getDocTemplateCount(DocTemplateVO param);
	
	List<DocTemplateVO> getDocTemplateList(DocTemplateVO param);

	void updateDocTemplate(DocTemplateVO param);

	void createDocTemplate(DocTemplateVO param);
	
	List<DocTemplateVO> getNotDeletedDocTemplateList(DocTemplateVO param);
	
}
