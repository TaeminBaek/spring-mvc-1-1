package com.lgmma.salesPortal.app.model;

public class DissExcelDownloadVO extends PagingParamVO {

	//Spec-In
	private String taskName;		// 과제명
	private String taskId;
	private String custName;		// Spec-In 고객
	private String kunnr;			// Spec-In 고객코드
	private String specinType;		// Spec-In 유형
	private String specinDevType;	// 개발유형
	private String specinDevlevel;	// Spec-In 등급
	private String prodDivision;	// 제품군
	private String prodDivisionD;	// 제품군상세
	private String specinUsgType;	// 용도분류
	private String prodUsgTypeDtl;	// 상세용도
	private String oem;				// OEM
	private String oemKind;			// 차종
	private String salesEmpNm;		// 담당영업사원
	private String salesEmpTeamNm;	// 영업부서
	private String tsEmpNm;			// TS담당자
	private String tsEmpTeamNm;		// TS담당팀
	private String expAnnualQty;	// 해당용도총사용량(톤/년)
	private String thisYearGoal;	// 당년매출목표(톤/년)
	private String tsGrade;			// TS＆D추천Grade
	private String taskStat;		// 진행상태
	private String compResult;		// 과제결과
	private String stepCd;			// 진행단계
	private String apprStat;		// 품의상태
	private String compYmdFmt;		// 완료예정일
	private String compGoalYmd200;	// 소재/컬러개발 제안
	private String compGoalYmd300;	// 소재/컬러개발
	private String compGoalYmd400;	// 견본송부
	private String compGoalYmd500;	// 고객Test/승인
	private String compGoalYmd600;	// 고객개발 완료
	private String compGoalYmd700;	// 양산이관
	private String compYmd100;
	private String compYmd200;
	private String compYmd300;
	private String compYmd400;
	private String compYmd500;
	private String compYmd600;
	private String compYmd700;
	private String goalTotal;
	private String goal01;
	private String goal02;
	private String goal03;
	private String goal04;
	private String goal05;
	private String goal06;
	private String goal07;
	private String goal08;
	private String goal09;
	private String goal10;
	private String goal11;
	private String goal12;
	private String material;		// 제품코드
	private String reqQty;			// 주문수량
	private String failReason;		// 성공/실패사유
	private String failReasonD;		// 실패사유구분
	private String compGrade;		// 확정Grade
	private String failTaskId;
	private String failTaskName;
	private String priorityTaskYn;

	// 견본관리
	private String reqDateH;
	private String partnNumbAg;
	private String partnNumbWe;
	private String partnNameAg;
	private String partnNameWe;
	private String partnNameVe;
	private String procStatText;
	private String vbeln;
	private String distrChan;
	private String distrChanText;
	private String currency;
	private String salesOrg;
	private String salesOrgText;
	private String dealName;
	private String docDate;

	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getSpecinType() {
		return specinType;
	}
	public void setSpecinType(String specinType) {
		this.specinType = specinType;
	}
	public String getSpecinDevType() {
		return specinDevType;
	}
	public void setSpecinDevType(String specinDevType) {
		this.specinDevType = specinDevType;
	}
	public String getSpecinDevlevel() {
		return specinDevlevel;
	}
	public void setSpecinDevlevel(String specinDevlevel) {
		this.specinDevlevel = specinDevlevel;
	}
	public String getProdDivision() {
		return prodDivision;
	}
	public void setProdDivision(String prodDivision) {
		this.prodDivision = prodDivision;
	}
	public String getProdDivisionD() {
		return prodDivisionD;
	}
	public void setProdDivisionD(String prodDivisionD) {
		this.prodDivisionD = prodDivisionD;
	}
	public String getSpecinUsgType() {
		return specinUsgType;
	}
	public void setSpecinUsgType(String specinUsgType) {
		this.specinUsgType = specinUsgType;
	}
	public String getProdUsgTypeDtl() {
		return prodUsgTypeDtl;
	}
	public void setProdUsgTypeDtl(String prodUsgTypeDtl) {
		this.prodUsgTypeDtl = prodUsgTypeDtl;
	}
	public String getOem() {
		return oem;
	}
	public void setOem(String oem) {
		this.oem = oem;
	}
	public String getOemKind() {
		return oemKind;
	}
	public void setOemKind(String oemKind) {
		this.oemKind = oemKind;
	}
	public String getSalesEmpNm() {
		return salesEmpNm;
	}
	public void setSalesEmpNm(String salesEmpNm) {
		this.salesEmpNm = salesEmpNm;
	}
	public String getSalesEmpTeamNm() {
		return salesEmpTeamNm;
	}
	public void setSalesEmpTeamNm(String salesEmpTeamNm) {
		this.salesEmpTeamNm = salesEmpTeamNm;
	}
	public String getTsEmpNm() {
		return tsEmpNm;
	}
	public void setTsEmpNm(String tsEmpNm) {
		this.tsEmpNm = tsEmpNm;
	}
	public String getTsEmpTeamNm() {
		return tsEmpTeamNm;
	}
	public void setTsEmpTeamNm(String tsEmpTeamNm) {
		this.tsEmpTeamNm = tsEmpTeamNm;
	}
	public String getExpAnnualQty() {
		return expAnnualQty;
	}
	public void setExpAnnualQty(String expAnnualQty) {
		this.expAnnualQty = expAnnualQty;
	}
	public String getThisYearGoal() {
		return thisYearGoal;
	}
	public void setThisYearGoal(String thisYearGoal) {
		this.thisYearGoal = thisYearGoal;
	}
	public String getTsGrade() {
		return tsGrade;
	}
	public void setTsGrade(String tsGrade) {
		this.tsGrade = tsGrade;
	}
	public String getTaskStat() {
		return taskStat;
	}
	public void setTaskStat(String taskStat) {
		this.taskStat = taskStat;
	}
	public String getCompResult() {
		return compResult;
	}
	public void setCompResult(String compResult) {
		this.compResult = compResult;
	}
	public String getStepCd() {
		return stepCd;
	}
	public void setStepCd(String stepCd) {
		this.stepCd = stepCd;
	}
	public String getApprStat() {
		return apprStat;
	}
	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}
	public String getCompYmdFmt() {
		return compYmdFmt;
	}
	public void setCompYmdFmt(String compYmdFmt) {
		this.compYmdFmt = compYmdFmt;
	}
	public String getCompGoalYmd200() {
		return compGoalYmd200;
	}
	public void setCompGoalYmd200(String compGoalYmd200) {
		this.compGoalYmd200 = compGoalYmd200;
	}
	public String getCompGoalYmd300() {
		return compGoalYmd300;
	}
	public void setCompGoalYmd300(String compGoalYmd300) {
		this.compGoalYmd300 = compGoalYmd300;
	}
	public String getCompGoalYmd400() {
		return compGoalYmd400;
	}
	public void setCompGoalYmd400(String compGoalYmd400) {
		this.compGoalYmd400 = compGoalYmd400;
	}
	public String getCompGoalYmd500() {
		return compGoalYmd500;
	}
	public void setCompGoalYmd500(String compGoalYmd500) {
		this.compGoalYmd500 = compGoalYmd500;
	}
	public String getCompGoalYmd600() {
		return compGoalYmd600;
	}
	public void setCompGoalYmd600(String compGoalYmd600) {
		this.compGoalYmd600 = compGoalYmd600;
	}
	public String getCompGoalYmd700() {
		return compGoalYmd700;
	}
	public void setCompGoalYmd700(String compGoalYmd700) {
		this.compGoalYmd700 = compGoalYmd700;
	}
	public String getCompYmd100() {
		return compYmd100;
	}
	public void setCompYmd100(String compYmd100) {
		this.compYmd100 = compYmd100;
	}
	public String getCompYmd200() {
		return compYmd200;
	}
	public void setCompYmd200(String compYmd200) {
		this.compYmd200 = compYmd200;
	}
	public String getCompYmd300() {
		return compYmd300;
	}
	public void setCompYmd300(String compYmd300) {
		this.compYmd300 = compYmd300;
	}
	public String getCompYmd400() {
		return compYmd400;
	}
	public void setCompYmd400(String compYmd400) {
		this.compYmd400 = compYmd400;
	}
	public String getCompYmd500() {
		return compYmd500;
	}
	public void setCompYmd500(String compYmd500) {
		this.compYmd500 = compYmd500;
	}
	public String getCompYmd600() {
		return compYmd600;
	}
	public void setCompYmd600(String compYmd600) {
		this.compYmd600 = compYmd600;
	}
	public String getCompYmd700() {
		return compYmd700;
	}
	public void setCompYmd700(String compYmd700) {
		this.compYmd700 = compYmd700;
	}
	public String getGoalTotal() {
		return goalTotal;
	}
	public void setGoalTotal(String goalTotal) {
		this.goalTotal = goalTotal;
	}
	public String getGoal01() {
		return goal01;
	}
	public void setGoal01(String goal01) {
		this.goal01 = goal01;
	}
	public String getGoal02() {
		return goal02;
	}
	public void setGoal02(String goal02) {
		this.goal02 = goal02;
	}
	public String getGoal03() {
		return goal03;
	}
	public void setGoal03(String goal03) {
		this.goal03 = goal03;
	}
	public String getGoal04() {
		return goal04;
	}
	public void setGoal04(String goal04) {
		this.goal04 = goal04;
	}
	public String getGoal05() {
		return goal05;
	}
	public void setGoal05(String goal05) {
		this.goal05 = goal05;
	}
	public String getGoal06() {
		return goal06;
	}
	public void setGoal06(String goal06) {
		this.goal06 = goal06;
	}
	public String getGoal07() {
		return goal07;
	}
	public void setGoal07(String goal07) {
		this.goal07 = goal07;
	}
	public String getGoal08() {
		return goal08;
	}
	public void setGoal08(String goal08) {
		this.goal08 = goal08;
	}
	public String getGoal09() {
		return goal09;
	}
	public void setGoal09(String goal09) {
		this.goal09 = goal09;
	}
	public String getGoal10() {
		return goal10;
	}
	public void setGoal10(String goal10) {
		this.goal10 = goal10;
	}
	public String getGoal11() {
		return goal11;
	}
	public void setGoal11(String goal11) {
		this.goal11 = goal11;
	}
	public String getGoal12() {
		return goal12;
	}
	public void setGoal12(String goal12) {
		this.goal12 = goal12;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getReqQty() {
		return reqQty;
	}
	public void setReqQty(String reqQty) {
		this.reqQty = reqQty;
	}
	public String getFailReason() {
		return failReason;
	}
	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}
	public String getFailReasonD() {
		return failReasonD;
	}
	public void setFailReasonD(String failReasonD) {
		this.failReasonD = failReasonD;
	}
	public String getCompGrade() {
		return compGrade;
	}
	public void setCompGrade(String compGrade) {
		this.compGrade = compGrade;
	}
	public String getFailTaskId() {
		return failTaskId;
	}
	public void setFailTaskId(String failTaskId) {
		this.failTaskId = failTaskId;
	}
	public String getFailTaskName() {
		return failTaskName;
	}
	public void setFailTaskName(String failTaskName) {
		this.failTaskName = failTaskName;
	}
	public String getPriorityTaskYn() {
		return priorityTaskYn;
	}
	public void setPriorityTaskYn(String priorityTaskYn) {
		this.priorityTaskYn = priorityTaskYn;
	}
	public String getReqDateH() {
		return reqDateH;
	}
	public void setReqDateH(String reqDateH) {
		this.reqDateH = reqDateH;
	}
	public String getPartnNumbWe() {
		return partnNumbWe;
	}
	public void setPartnNumbWe(String partnNumbWe) {
		this.partnNumbWe = partnNumbWe;
	}
	public String getPartnNumbAg() {
		return partnNumbAg;
	}
	public void setPartnNumbAg(String partnNumbAg) {
		this.partnNumbAg = partnNumbAg;
	}
	public String getPartnNameAg() {
		return partnNameAg;
	}
	public void setPartnNameAg(String partnNameAg) {
		this.partnNameAg = partnNameAg;
	}
	public String getPartnNameWe() {
		return partnNameWe;
	}
	public void setPartnNameWe(String partnNameWe) {
		this.partnNameWe = partnNameWe;
	}
	public String getPartnNameVe() {
		return partnNameVe;
	}
	public void setPartnNameVe(String partnNameVe) {
		this.partnNameVe = partnNameVe;
	}
	public String getProcStatText() {
		return procStatText;
	}
	public void setProcStatText(String procStatText) {
		this.procStatText = procStatText;
	}
	public String getVbeln() {
		return vbeln;
	}
	public void setVbeln(String vbeln) {
		this.vbeln = vbeln;
	}
	public String getDistrChan() {
		return distrChan;
	}
	public void setDistrChan(String distrChan) {
		this.distrChan = distrChan;
	}
	public String getDistrChanText() {
		return distrChanText;
	}
	public void setDistrChanText(String distrChanText) {
		this.distrChanText = distrChanText;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSalesOrg() {
		return salesOrg;
	}
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	public String getSalesOrgText() {
		return salesOrgText;
	}
	public void setSalesOrgText(String salesOrgText) {
		this.salesOrgText = salesOrgText;
	}
	public String getDealName() {
		return dealName;
	}
	public void setDealName(String dealName) {
		this.dealName = dealName;
	}
	public String getDocDate() {
		return docDate;
	}
	public void setDocDate(String docDate) {
		this.docDate = docDate;
	}
}