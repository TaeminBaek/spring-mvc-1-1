package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.CommonCodeVO;


public interface CommonCodeDao {
	

	public int getCommonCodeCount(CommonCodeVO param);
	
	List<CommonCodeVO> getCommonCodeList(CommonCodeVO param);

	public void updateCommonCode(CommonCodeVO param);

	public void createCommonCode(CommonCodeVO param);

	public List<CommonCodeVO> getCommonCodeDbAll();

}
