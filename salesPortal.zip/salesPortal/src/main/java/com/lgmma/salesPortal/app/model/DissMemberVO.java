package com.lgmma.salesPortal.app.model;

public class DissMemberVO extends PagingParamVO {

	//TB_D_MEMBER
	private String taskMemberId;    //멤버ID
	private String taskId;          //과제ID
	private String taskType;        //과제구분
	private String memberType;      //담당자유형코드
	private String mngEmpId;        //담당자
	private String mngEmpOrg;       //담당자부서
	private String mngMemberRole;   //담당자역할
	//멤버 LISTAGG
	private String mngEmpNmListagg;         //이름(소속)
	private String mngMemberRoleListagg; //역할
	//수정
	private String mngEmpNm;
	//HIS
	private String stepId;

	public String getTaskMemberId() {
		return taskMemberId;
	}

	public void setTaskMemberId(String taskMemberId) {
		this.taskMemberId = taskMemberId;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getMemberType() {
		return memberType;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	public String getMngEmpId() {
		return mngEmpId;
	}

	public void setMngEmpId(String mngEmpId) {
		this.mngEmpId = mngEmpId;
	}

	public String getMngEmpOrg() {
		return mngEmpOrg;
	}

	public void setMngEmpOrg(String mngEmpOrg) {
		this.mngEmpOrg = mngEmpOrg;
	}

	public String getMngMemberRole() {
		return mngMemberRole;
	}

	public void setMngMemberRole(String mngMemberRole) {
		this.mngMemberRole = mngMemberRole;
	}

	public String getMngEmpNmListagg() {
		return mngEmpNmListagg;
	}

	public void setMngEmpNmListagg(String mngEmpNmListagg) {
		this.mngEmpNmListagg = mngEmpNmListagg;
	}

	public String getMngMemberRoleListagg() {
		return mngMemberRoleListagg;
	}

	public void setMngMemberRoleListagg(String mngMemberRoleListagg) {
		this.mngMemberRoleListagg = mngMemberRoleListagg;
	}

	public String getMngEmpNm() {
		return mngEmpNm;
	}

	public void setMngEmpNm(String mngEmpNm) {
		this.mngEmpNm = mngEmpNm;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

}
