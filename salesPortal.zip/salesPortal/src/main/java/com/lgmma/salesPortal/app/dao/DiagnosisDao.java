package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.SalePriceCloseVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;

public interface DiagnosisDao {

	public List<SalePriceMasterVO> getSalePriceChangeRateList(SalePriceCloseVO param);
}