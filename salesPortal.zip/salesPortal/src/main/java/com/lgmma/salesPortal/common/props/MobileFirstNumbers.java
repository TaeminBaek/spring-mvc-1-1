package com.lgmma.salesPortal.common.props;

public enum MobileFirstNumbers {
/**
 * 핸드폰 앞자리로서
*/
	 MPN_010("010")
	,MPN_011("011")
	,MPN_016("016")
	,MPN_017("017")
	,MPN_018("018")
	,MPN_019("019")
	;
	String code = null;

	private MobileFirstNumbers(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
