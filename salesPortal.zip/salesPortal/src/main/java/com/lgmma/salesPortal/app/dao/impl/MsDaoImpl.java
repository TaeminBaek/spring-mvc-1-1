package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.MsDao;
import com.lgmma.salesPortal.app.dao.SmsDao;
import com.lgmma.salesPortal.app.model.IcisVO;
import com.lgmma.salesPortal.app.model.SmsVO;

@Repository
public class MsDaoImpl implements MsDao {

	private static final String MAPPER_NAMESPACE = "MS_MAPPER.";
	@Autowired
	@Resource(name="msSqlSession") 
	protected SqlSession sqlSession;

	@Override
	public List<IcisVO> getIcisList(IcisVO param) {
		return 		sqlSession.selectList(MAPPER_NAMESPACE + "getIcisList", param);
	}
}
