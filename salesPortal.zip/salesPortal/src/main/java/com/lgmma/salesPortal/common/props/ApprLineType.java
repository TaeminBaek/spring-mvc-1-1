package com.lgmma.salesPortal.common.props;

public enum ApprLineType {
/**
 * 결재자구분으로서
*/
	 APPR_APROBE(	"A",	"결재자"	,"0",true)
	,APPR_CONFIRM(	"C",	"합의자"	,"1",true)
	,APPR_REFERENCE("R",	"참조자"	,"",false)
	,APPR_INFORM(	"I",	"통보자"	,"",false)
	;
	String code = null;
	String name = null;
	String gpLineType = null;	// GPortal 결재 타입(0:결재, 1:합의(필수), 2:합의(선택))
	boolean apprActionLineYn = false; // 승인/결재/협의/반려 권자여부

	private ApprLineType(String code, String name, String gpLineType, boolean apprActionLineYn) {
		this.code = code;
		this.name = name;
		this.gpLineType = gpLineType;
		this.apprActionLineYn = apprActionLineYn;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getGpLineType() {
		return gpLineType;
	}

	public void setGpLineType(String gpLineType) {
		this.gpLineType = gpLineType;
	}

	public boolean isApprActionLineYn() {
		return apprActionLineYn;
	}

	public void setApprActionLineYn(boolean apprActionLineYn) {
		this.apprActionLineYn = apprActionLineYn;
	}

	public static ApprLineType getApprLineType(String code) {
		for(ApprLineType type : ApprLineType.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}

}
