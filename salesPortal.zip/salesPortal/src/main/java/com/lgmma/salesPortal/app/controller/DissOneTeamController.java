package com.lgmma.salesPortal.app.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissDashBoardVO;
import com.lgmma.salesPortal.app.model.DissOneTeamMinutesVO;
import com.lgmma.salesPortal.app.model.DissOneTeamVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.model.DissTaskSpecInVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.service.DissOneTeamService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;

/**
 * DISS 원팀과제 컨트롤러
 */
@Controller
@RequestMapping("/dissOneTeam") 
public class DissOneTeamController {

	private static Logger logger = LoggerFactory.getLogger(DissOneTeamController.class);

	@Autowired
	CommonController commonController;

	@Autowired
	DissOneTeamService dissOneTeamService;
	
	/**
	 * 원팀과제 리스트 화면
	 * @param mav
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/dissOneTeamList")
	public ModelAndView dissOneTeamList(ModelAndView mav, DissDashBoardVO dissDashBoardVO) throws Exception {
		mav.setViewName("dissOneTeam/dissOneTeamList");
		mav.addObject("frYmd", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-12)));
		mav.addObject("toYmd", DateUtil.defaultFormatDate(DateUtil.getToday()));
		
		//리더 팀코드
		mav.addObject("leaderTeamList", dissOneTeamService.getDissOneTeamLeaderTeamList());
		return mav;
	}
	
	/**
	 * 원팀과제 조회
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/getDissOneTeamList.json")
	public Map getDissOneTeamList(@RequestBody(required = true) DissOneTeamVO param) throws Exception {
		param = (DissOneTeamVO) StringUtil.nullToEmptyString(param);
		return JsonResponse.asSuccess("itemsCount", dissOneTeamService.getDissOneTeamListCount(param), "storeData", dissOneTeamService.getDissOneTeamList(param));
	}
	
/*	*//**
	 * 원팀과제 등록 화면
	 * @param mav
	 * @return
	 * @throws Exception
	 *//*
	@RequestMapping(value = "/dissOneTeamReg")
	public ModelAndView dissOneTeamReg(ModelAndView mav, String taskId) throws Exception {
		mav.setViewName("dissOneTeam/dissOneTeamReg");
		DissOneTeamVO dissOneTeamVO = new DissOneTeamVO();
		dissOneTeamVO.setTaskId(StringUtil.nullConvert(taskId));
		dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(dissOneTeamVO);
		mav.addObject("dissOneTeamParam", dissOneTeamVO);
		return mav;
	}
	*/
	
	/**
	 * 원팀과제 정보 조회
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getDissOneTeamInfo.json")
	public Map getDissOneTeamInfo(@RequestBody(required = true) DissOneTeamVO param) throws Exception {
		param = (DissOneTeamVO) StringUtil.nullToEmptyString(param);
		DissOneTeamVO dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(dissOneTeamService.getDissOneTeamInfo(param));
		return JsonResponse.asSuccess("storeData", dissOneTeamVO);
	}
	
	/**
	 * 원팀과제 저장
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveOneTeam.json")
	public Map saveOneTeam(@RequestBody(required = true) DissOneTeamVO param) throws Exception {
		param = (DissOneTeamVO) StringUtil.nullToEmptyString(param);
		dissOneTeamService.saveDissOneTeam(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * 원팀과제  결재처리
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveDissOneTeamApprovalAction.json")
	public Map saveDissOneTeamApprovalAction(@RequestBody(required = true) DissApprCommonParamVO param) throws Exception {
		param = (DissApprCommonParamVO) StringUtil.nullToEmptyString(param);
		param.setApprEmpId(param.getUpdtIdxx()); // 결재자는 반드시 로그인한 사원으로 체크 한다.
		dissOneTeamService.saveDissOneTeamApprovalAction(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * 원팀과제 스펙인 정보 검색
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/getSpecInListWithTotalSaleGoal.json")
	public Map getSpecInListWithTotalSaleGoal(@RequestBody(required = true) DissTaskSpecInVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissOneTeamService.getSpecInListWithTotalSaleGoal(param), "itemsCount", dissOneTeamService.getSpecInListWithTotalSaleGoalCnt(param));
	}
	
	/**
	 * 원팀과제 수정
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/updateOneTeamDtl.json")
	public Map updateOneTeamDtl(@RequestBody(required = true) DissOneTeamVO param) throws Exception {
		param = (DissOneTeamVO) StringUtil.nullToEmptyString(param);
		return JsonResponse.asSuccess("newStepId", dissOneTeamService.updateOneTeamDtl(param));
	}
	
	/**
	 * 원팀과제 회의록 목록 조회
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/getDissOneTeamMinutesList.json")
	public Map getDissOneTeamMinutesList(@RequestBody(required = true) DissOneTeamMinutesVO param) throws Exception {
		param = (DissOneTeamMinutesVO) StringUtil.nullToEmptyString(param);
		return JsonResponse.asSuccess("itemsCount", dissOneTeamService.getDissOneTeamMinutesListCount(param), "storeData", dissOneTeamService.getDissOneTeamMinutesList(param));
	}
	
	/**
	 * 원팀과제 회의록 저장
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveOneTeamMinutes.json")
	public Map saveOneTeamMinutes(@RequestBody(required = true) DissOneTeamMinutesVO param) throws Exception {
		param = (DissOneTeamMinutesVO) StringUtil.nullToEmptyString(param);
		dissOneTeamService.saveDissOneTeamMinutes(param);
		return JsonResponse.asSuccess();
	}
	
	/**
	 * 원팀과제 회의록 상세 조회
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/getDissOneTeamMinutesDetail.json")
	public Map getDissOneTeamMinutesDetail(@RequestBody(required = true) DissOneTeamMinutesVO param) throws Exception {
		param = (DissOneTeamMinutesVO) StringUtil.nullToEmptyString(param);
		return JsonResponse.asSuccess("storeData", dissOneTeamService.getDissOneTeamMinutesDetail(param));
	}
	

	/**
	 * 원팀과제 회의록 결재처리
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveDissOneTeamMinutesApprovalAction.json")
	public Map saveDissOneTeamMinutesApprovalAction(@RequestBody(required = true) DissApprCommonParamVO param) throws Exception {
		param = (DissApprCommonParamVO) StringUtil.nullToEmptyString(param);
		param.setApprEmpId(param.getUpdtIdxx()); // 결재자는 반드시 로그인한 사원으로 체크 한다.
		dissOneTeamService.saveDissOneTeamMinutesApprovalAction(param);
		return JsonResponse.asSuccess();
	}
	
	/**
	 * 원팀과제 완료보고 저장
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveDissOneTeamCompleteAppr.json")
	public Map saveDissOneTeamCompleteAppr(@RequestBody(required = true) DissOneTeamVO param) throws Exception {
		param = (DissOneTeamVO) StringUtil.nullToEmptyString(param);
		dissOneTeamService.saveDissOneTeamCompleteAppr(param);
		return JsonResponse.asSuccess();
	}
	
	/**
	 * 원팀과제 품의 삭제
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/deleteDissOneTeamAppr.json")
	public Map deleteDissOneTeamAppr(@RequestBody(required = true) DissApprCommonParamVO dissApprCommonParamVO ) throws Exception {
		dissApprCommonParamVO = (DissApprCommonParamVO) StringUtil.nullToEmptyString(dissApprCommonParamVO);
		dissOneTeamService.deleteDissOneTeamAppr(dissApprCommonParamVO);
		return JsonResponse.asSuccess();
	}
	
	/**
	 * 원팀회의록 삭제
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/deleteDissOneTeamMinutesAppr.json")
	public Map deleteDissOneTeamMinutesAppr(@RequestBody(required = true) DissApprCommonParamVO dissApprCommonParamVO ) throws Exception {
		dissApprCommonParamVO = (DissApprCommonParamVO) StringUtil.nullToEmptyString(dissApprCommonParamVO);
		dissOneTeamService.deleteDissOneTeamMinutesAppr(dissApprCommonParamVO);
		return JsonResponse.asSuccess();
	}
	
	/**
	 * 원팀과제 과제등록이력 조회
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/getDissOneTeamStepList.json")
	public Map getDissOneTeamStepList(@RequestBody(required = true) DissStepVO param) throws Exception {
		param = (DissStepVO) StringUtil.nullToEmptyString(param);
		return JsonResponse.asSuccess("storeData", dissOneTeamService.getDissOneTeamStepList(param));
	}
	
	@RequestMapping(value = "/loadEmployList.json")
	public Map getEmployList(@RequestBody(required=true) Map<String, String> param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissOneTeamService.loadEmployList(param));
	}
}
