package com.lgmma.salesPortal.app.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissDashBoardVO;
import com.lgmma.salesPortal.app.model.DissImpDevVO;
import com.lgmma.salesPortal.app.model.DissScheduleVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.DissImpDevService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;

@Controller
@RequestMapping("/dissImpDev") 
public class DissImpDevController {

	private static Logger logger = LoggerFactory.getLogger(DissImpDevController.class);

	@Autowired
	DissImpDevService dissImpDevService;
	
	@Autowired
	CommonController commonController;
	
	@Autowired
	private CommonService commonService;
	/**
	 * DISS 제품개선개발 조회 화면
	 */	
	@RequestMapping(value = "/dissImpDevList")
	public ModelAndView dissImpDevList(ModelAndView mav, DissDashBoardVO dissDashBoardVO) throws Exception {
		mav.setViewName("dissImpDev/dissImpDevList");	
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		CommonCodeVO commonCodeVO = new CommonCodeVO();
		//DISS 제품군
		commonCodeVO.setGrupCode("DISS_PROD_DIVISION");
		mav.addObject("DISS_PROD_DIVISION", commonController.getCode(commonCodeVO).get("items"));
		//DISS 제품군상세
		//개발등급
		commonCodeVO.setGrupCode("DISS_IMPD_DEVGRADE");
		mav.addObject("DISS_IMPD_DEVGRADE", commonController.getCode(commonCodeVO).get("items"));
		//개선개발 주관
		commonCodeVO.setGrupCode("DISS_IMPD_SUPERVISE");
		mav.addObject("DISS_IMPD_SUPERVISE", commonController.getCode(commonCodeVO).get("items"));
		//제품개선개발 과제 진행상태
		commonCodeVO.setGrupCode("DISS_TASK_STATUS");
		mav.addObject("DISS_TASK_STATUS", commonController.getCode(commonCodeVO).get("items"));
		//개선개발 공정 구분
		commonCodeVO.setGrupCode("DISS_IMPD_PROC_TYPE");
		mav.addObject("DISS_IMPD_PROC_TYPE", commonController.getCode(commonCodeVO).get("items"));
		//제품개선개발 과제 진행단계
		commonCodeVO.setGrupCode("DISS_STEP_CD");
		mav.addObject("DISS_STEP_CD", commonController.getCode(commonCodeVO).get("items"));
		//리더 팀코드
		mav.addObject("LEADER_TEAM_CD", dissImpDevService.getDissImpDevLeaderTeamList());
		//4M 관리등급
		commonCodeVO.setGrupCode("DISS_4M_MGMT_GRADE");
		mav.addObject("DISS_4M_MGMT_GRADE", commonController.getCode(commonCodeVO).get("items"));
		mav.addObject("apprStatList", ApprState.getDissApprStatList());
		mav.addObject("frYmd", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -12)));
		mav.addObject("toYmd", DateUtil.defaultFormatDate(DateUtil.getToday()));
		return mav;
		
	}

	/**
	 * DISS 제품개선개발 등록 화면
	 */
	@RequestMapping(value = "/dissImpDevReg")
	public ModelAndView dissImpDevReg(ModelAndView mav ) throws Exception {
		mav.setViewName("dissImpDev/dissImpDevReg");
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		CommonCodeVO commonCodeVO = new CommonCodeVO();
		//DISS 제품군
		commonCodeVO.setGrupCode("DISS_PROD_DIVISION");
		mav.addObject("DISS_PROD_DIVISION", commonController.getCode(commonCodeVO).get("items"));
		//개선개발 주관
		commonCodeVO.setGrupCode("DISS_IMPD_SUPERVISE");
		mav.addObject("DISS_IMPD_SUPERVISE", commonController.getCode(commonCodeVO).get("items"));
		//개발등급
		commonCodeVO.setGrupCode("DISS_IMPD_DEVGRADE");
		mav.addObject("DISS_IMPD_DEVGRADE", commonController.getCode(commonCodeVO).get("items"));
		//개선개발 공정 구분
		commonCodeVO.setGrupCode("DISS_IMPD_PROC_TYPE");
		mav.addObject("DISS_IMPD_PROC_TYPE", commonController.getCode(commonCodeVO).get("items"));
		//4M 관리등급
		commonCodeVO.setGrupCode("DISS_4M_MGMT_GRADE");
		mav.addObject("DISS_4M_MGMT_GRADE", commonController.getCode(commonCodeVO).get("items"));
		
		return mav;
	}
	
	/**
	 * DISS 제품개선개발 신규등록 
	 */	
	@RequestMapping(value = "/createDissImpDev.json")
	public Map createDissImpDev(@RequestBody DissImpDevVO param) throws Exception {
		dissImpDevService.createDissImpDev(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	/**
	 * DISS 제품개선개발 과제명 건수 확인
	 */		
	@RequestMapping(value = "/getDissTaskNameCount.json")
	public Map getDissTaskNameCnt(@RequestBody(required = true) DissImpDevVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", dissImpDevService.getDissTaskNameCount(param));
	}
	
	/**
	 * DISS 제품개선개발 조회
	 */			
	@RequestMapping(value = "/getDissImpDevList.json")
	public Map getDissImpDevList(@RequestBody(required = true) DissImpDevVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", dissImpDevService.getDissImpDevListCount(param), "storeData", dissImpDevService.getDissImpDevList(param));
	}
	
	/**
	 * DISS 제품개선개발 진행단계 조회
	 */		
	@RequestMapping(value = "/getDissStepGroupToStepCdList.json")
	public Map getDissStepGroupToStepCdList(@RequestBody(required = true) CommonCodeVO param) throws Exception {
		return JsonResponse.asSuccess("items", dissImpDevService.getDissStepGroupToStepCdList(param));
	}
	
	/**
	 * DISS 제품개선개발 상세 조회
	 */			
	@RequestMapping(value = "/getDissImpDevDetail.json")
	public Map getDissImpDevDetail(@RequestBody(required = true) DissImpDevVO param) throws Exception {
		List<DissScheduleVO> editedScheduleList = null;

		if(ApprType.APPR_TYPE_DISS_IMPDEV_SCHEDULE_EDIT.getCode().equals(param.getApprType()) && !"".equals(param.getStepId()))
			editedScheduleList = dissImpDevService.getDissScheduleHisList(param.getStepId());
		
		return JsonResponse.asSuccess("storeData", dissImpDevService.getDissImpDevDetail(param), "editedScheduleList", editedScheduleList);
	}
	
	/**
	 * DISS 제품개선개발 전체 수정 
	 */	
	@RequestMapping(value = "/updateDissImpDevAll.json")
	public Map updateDissImpDevAll(@RequestBody DissImpDevVO param) throws Exception {
		dissImpDevService.updateDissImpDevAll(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	/**
	 * DISS 제품개선개발 일정,멤버 수정 
	 */	
	@RequestMapping(value = "/updateDissImpDev.json")
	public Map updateDissImpDev(@RequestBody DissImpDevVO param) throws Exception {
		dissImpDevService.updateDissImpDev(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@Transactional
	@RequestMapping(value = "/updateImpDevSchedule.json")
	public Map updateImpDevSchedule(@RequestBody(required = true) DissImpDevVO param) throws Exception {
		param = (DissImpDevVO) StringUtil.nullToEmptyString(param);
		dissImpDevService.updateImpDevSchedule(param);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	@Transactional
	@RequestMapping(value = "/deleteImpDevScheduleEdit.json")
	public Map deleteImpDevScheduleEdit(@RequestBody(required = true) DissImpDevVO param) throws Exception {
		param = (DissImpDevVO) StringUtil.nullToEmptyString(param);
		dissImpDevService.deleteImpDevScheduleEdit(param);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	@RequestMapping(value = "/applDissImpDevScheduleEdit.json")
	public Map applDissImpDevScheduleEdit(@RequestBody(required = true) DissApprCommonParamVO param) throws Exception {
		param = (DissApprCommonParamVO) StringUtil.nullToEmptyString(param);
		param.setApprEmpId(param.getUpdtIdxx()); // 결재자는 반드시 로그인한 사원으로 체크 한다.
		dissImpDevService.applDissImpDevScheduleEdit(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * DISS 제품개선개발 삭제 
	 */	
	@RequestMapping(value = "/deleteDissImpDevAll.json")
	public Map deleteDissImpDevAll(@RequestBody DissStepVO param) throws Exception {
		dissImpDevService.deleteDissImpDevAll(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	/**
	 * DISS 제품개선개발 품의서 유형별 저장 (WinPop) 
	 */	
	@RequestMapping(value = "/saveDissImpDevApprType.json")
	public Map saveDissImpDevApprType(@RequestBody DissImpDevVO param) throws Exception {
		String saveMode = param.getSaveMode();
		if(saveMode.equals("TMP") || saveMode.equals("REQ")) {
			dissImpDevService.saveDissImpDevApprType(param); //임시저장, 결재의뢰
		}else if(saveMode.equals("REW")) {
			dissImpDevService.saveDissImpDevApprTypeRew(param); //반려재신청
		}else if(saveMode.equals("DEL")) {
			dissImpDevService.deleteDissImpDevApprType(param); //삭제
		}
		
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	/**
	 * DISS 제품개선개발 품의서 결재액션
	 */	
	@RequestMapping(value = "/saveDissImpDevApprovalAction.json")
	public Map saveDissImpDevApprovalAction(@RequestBody DissStepVO param) throws Exception {
		dissImpDevService.saveDissImpDevApprovalAction(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}	
	
	/**
	 * DISS 제품개선개발 제안 품의서 상세 조회
	 */			
	@RequestMapping(value = "/getDissImpDevApprTypeDetail.json")
	public Map getDissImpDevApprTypeDetail(@RequestBody(required = true) DissStepVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissImpDevService.getDissImpDevApprTypeDetail(param));
	}
	
	/**
	 * DISS 일정 공통 조회
	 */			
	@RequestMapping(value = "/getDissImpDevScheduleCommon.json")
	public Map getDissImpDevScheduleCommon(@RequestBody(required = true) DissImpDevVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissImpDevService.getDissImpDevScheduleCommon(param));
	}
	
	/**
	 * DISS 차수생성
	 */	
	@RequestMapping(value = "/createDissImpDevDegree.json")
	public Map createDissImpDevDegree(@RequestBody DissStepVO param) throws Exception {
		dissImpDevService.createDissImpDevDegree(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	/**
	 * DISS 차수현황 상세 조회
	 */			
	@RequestMapping(value = "/getDissImpDevStepRsltDetail.json")
	public Map getDissImpDevStepRsltDetail(@RequestBody(required = true) DissStepVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissImpDevService.getDissImpDevStepRsltDetail(param));
	}
	
	/**
	 * DISS 제품개선개발 리더 변경
	 */	
	@RequestMapping(value = "/updateLeader.json")
	public Map changeLeader(@RequestBody DissImpDevVO param) throws Exception {
		dissImpDevService.updateLeader(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
}