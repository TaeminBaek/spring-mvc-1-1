package com.lgmma.salesPortal.common.schedule.dao;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.CompOrganByErpVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.DissDelayGateReviewAlarmVO;
import com.lgmma.salesPortal.app.model.DissDelayTaskAlarmVO;
import com.lgmma.salesPortal.app.model.JobScheduleParamVO;
import com.lgmma.salesPortal.app.model.NiceCompGradeVO;
import com.lgmma.salesPortal.app.model.ProductStockVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.model.SampleOrderMasterVO;
import com.lgmma.salesPortal.security.authentication.UserInfo;

public interface JobScheduledDao {

	public void mergeProduct(List<ProductVO> productList);

	public void deleteProductStockAll();

	public void insertProductStocks(List<ProductStockVO> productStockList);

	void excUpdateOrderWadatIstFromSapByVbeln(SampleOrderMasterVO param);

	List<SampleOrderMasterVO> getUpdateOrderWadatIstList(JobScheduleParamVO jobScheduleParamVO);

	public void deleteCompOrganByErp();

	public void insertCompOrganByErp(CompOrganByErpVO compOrganByErpVO);

	public List<NiceCompGradeVO> getCompListForUpdateGrade(NiceCompGradeVO vo);

	public List<NiceCompGradeVO> getCompListForUploadKed();

	public NiceCompGradeVO getFinalCompGrade(NiceCompGradeVO compVo);

	public void createNiceCompanyGrade(NiceCompGradeVO niceVo);

	public void updateCompanyGrade(CompanyVO companyVo);

	public List<CompanyVO> getCompListForSendGradeToERP(CompanyVO companyVo);

	public List<NiceCompGradeVO> getNiceCompGradeListForSendToERP();

	public void updateExpiredDambo();

	public List<Map> getToBeExpiredDamboList();

	public List<Map> getCurrentDamboList();

	public List<DissDelayTaskAlarmVO> getDissDelayTaskList();
	
	public List<DissDelayGateReviewAlarmVO> getDissDelayGateReviewList();

	public List<CompanyVO> getErpExpCompanyList(CompanyVO companyVO);

	public void updateExpCompGrade(CompanyVO companyVO);

	public void deleteMonthlySales(String yyyyMm);

	public void insertMonthlySales(List<Map> monthlySalesList);

	public void mergeKedCompany(Map<String, String> paramMap);

	public void mergeKedFinancialInfo(Map<String, String> paramMap);

	public void mergeKedRepresentativeInfo(Map<String, String> paramMap);

	public void mergeKedPersonInfo(Map<String, String> paramMap);

	public void mergeKedExecutiveInfo(Map<String, String> paramMap);

	public void mergeKedEnterpriseInfo(Map<String, String> paramMap);

	public void mergeKedPurposeBusiness(Map<String, String> paramMap);

	public void mergeKedRelationCompany(Map<String, String> paramMap);

	public void mergeKedHolderStatus(Map<String, String> paramMap);

	public void mergeKedWorkspace(Map<String, String> paramMap);

	public void mergeKedIntellectualRight(Map<String, String> paramMap);

	public void mergeKedMajorCustomer(Map<String, String> paramMap);

	public void mergeKedOverallCreditRating(Map<String, String> paramMap);

	public void mergeKedCashFlowClass(Map<String, String> paramMap);

	public void mergeKedFinancialRatio(Map<String, String> paramMap);

	public void mergeKedEwAlert(Map<String, String> paramMap);

	public void mergeKedEwStatus(Map<String, String> paramMap);

	public Map<String, String> getKedToNiceGrade(String stcd2);

	public List<UserInfo> getSalesEmpInfoAll();

	public List<UserInfo> test();
}
