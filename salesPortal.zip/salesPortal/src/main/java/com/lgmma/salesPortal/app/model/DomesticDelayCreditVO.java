package com.lgmma.salesPortal.app.model;

public class DomesticDelayCreditVO extends PagingParamVO {
	private String vkorg;
	private String datum;
	private String vbeln;
	private String kunnr;
	private String vtweg;
	private String name1;
	private String augbl;
	private String budat;
	private String busil;
	private String zdays;
	private String zterm;
	private String ztag1;
	private String zfipadt;
	private String waers;
	private String wrbtr;
	private String dmbtr;
	private String aubel;
	private String pernr;
	private String prnam;
	private String text1;
	
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getDatum() {
		return datum;
	}
	public void setDatum(String datum) {
		this.datum = datum;
	}
	public String getVbeln() {
		return vbeln;
	}
	public void setVbeln(String vbeln) {
		this.vbeln = vbeln;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getVtweg() {
		return vtweg;
	}
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getAugbl() {
		return augbl;
	}
	public void setAugbl(String augbl) {
		this.augbl = augbl;
	}
	public String getBudat() {
		return budat;
	}
	public void setBudat(String budat) {
		this.budat = budat;
	}
	public String getBusil() {
		return busil;
	}
	public void setBusil(String busil) {
		this.busil = busil;
	}
	public String getZdays() {
		return zdays;
	}
	public void setZdays(String zdays) {
		this.zdays = zdays;
	}
	public String getZterm() {
		return zterm;
	}
	public void setZterm(String zterm) {
		this.zterm = zterm;
	}
	public String getZtag1() {
		return ztag1;
	}
	public void setZtag1(String ztag1) {
		this.ztag1 = ztag1;
	}
	public String getZfipadt() {
		return zfipadt;
	}
	public void setZfipadt(String zfipadt) {
		this.zfipadt = zfipadt;
	}
	public String getWaers() {
		return waers;
	}
	public void setWaers(String waers) {
		this.waers = waers;
	}
	public String getWrbtr() {
		return wrbtr;
	}
	public void setWrbtr(String wrbtr) {
		this.wrbtr = wrbtr;
	}
	public String getDmbtr() {
		return dmbtr;
	}
	public void setDmbtr(String dmbtr) {
		this.dmbtr = dmbtr;
	}
	public String getAubel() {
		return aubel;
	}
	public void setAubel(String aubel) {
		this.aubel = aubel;
	}
	public String getPernr() {
		return pernr;
	}
	public void setPernr(String pernr) {
		this.pernr = pernr;
	}
	public String getPrnam() {
		return prnam;
	}
	public void setPrnam(String prnam) {
		this.prnam = prnam;
	}
	public String getText1() {
		return text1;
	}
	public void setText1(String text1) {
		this.text1 = text1;
	}
	
}
