package com.lgmma.salesPortal.app.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public abstract class PagingParamVO implements Serializable{

	private String regiIdxx;
	private String regiDate;
	private String updtIdxx;
	private String updtDate;
	private boolean newObj;
	private int rIndex;
	private int start;
	private int pageSize;
	private String userType;

	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public String getUpdtDate() {
		return updtDate;
	}
	public void setUpdtDate(String updtDate) {
		this.updtDate = updtDate;
	}
	public boolean isNewObj() {
		return newObj;
	}
	public void setNewObj(boolean newObj) {
		this.newObj = newObj;
	}
	public int getrIndex() {
		return rIndex;
	}
	public void setrIndex(int rIndex) {
		this.rIndex = rIndex;
	}
	public String getRegiIdxx() {
		return regiIdxx;
	}
	public void setRegiIdxx(String regiIdxx) {
		this.regiIdxx = regiIdxx;
	}
	public String getUpdtIdxx() {
		return updtIdxx;
	}
	public void setUpdtIdxx(String updtIdxx) {
		this.updtIdxx = updtIdxx;
	}
	public String getRegiDate() {
		return regiDate;
	}
	public void setRegiDate(String regiDate) {
		this.regiDate = regiDate;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
	}
}
