package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.security.authentication.UserInfo;

public interface LoginDao {

	public UserInfo getUserInfo(String empNo);

	public UserInfo getPartnerUserInfo(String userId);

	public UserInfo getEmpUserInfo(String userId);

	public String getEncryptPwd(String partnerPwd);

	public List<String> getVkorg(String compCode);

	public List<UserInfo> getCreditEmpUserInfo(String userId);
}
