package com.lgmma.salesPortal.security.authentication;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Component;

/**
 * UsernamePasswordAuthenticationFilter
 */
@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    private UserDetailsService detailsService;

    @Autowired
    private MessageSourceAccessor messageSourceAccessor;

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String userIP = ((WebAuthenticationDetails) authentication.getDetails()).getRemoteAddress();

//		// Web 담당자
//		if (!("10.45.1.104".equals(userIP) // 백태민 (CNS) 무선
//		||	  "10.64.76.31".equals(userIP) // 백태민 (CNS) 클라우드
//		|| "165.243.184.34".equals(userIP) // 백태민 (CNS) 유선
//		||	   "10.45.1.38".equals(userIP) // 이규관  (CNS)
//		||	 "10.64.80.248".equals(userIP) // 이규관  (CNS)
//		|| "10.45.1.113".equals(userIP) // 노형정  (CNS)
//		|| "10.45.1.115".equals(userIP) // 성지홍  
//		|| "10.45.1.71".equals(userIP) // 이규관  (CNS)
		
//		// Local
//		||"0:0:0:0:0:0:0:1".equals(userIP))) {throw new BadCredentialsException("로그인에 실패했습니다.");}
//
//		System.out.println("########### login user IP : " + userIP);

		String empNo = authentication.getName();
		String password = (String) authentication.getCredentials();
		if(!password.equals("mmaadmin")) {
			throw new BadCredentialsException(messageSourceAccessor.getMessage("fail.common.login.notfound"));
		}
		
		UserInfo user = (UserInfo) detailsService.loadUserByUsername(empNo);
		//SSO 를 통한 로그인에서는 CustomAuthenticationToken 에 등록할  password 가 없다.
		return new CustomAuthenticationToken(user.getUsername(), "password", user.getAuthorities(), user);
	}

}
