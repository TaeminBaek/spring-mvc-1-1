package com.lgmma.salesPortal.app.dao;

import com.lgmma.salesPortal.app.model.DissSampleOrderItemVO;
import com.lgmma.salesPortal.app.model.DissSampleOrderMasterVO;

import java.util.List;

public interface DissSampleOrderDao {

	void createDissSampleOrderMaster(DissSampleOrderMasterVO dissSampleOrderMasterVO);

	void updateDissSampleOrderMaster(DissSampleOrderMasterVO dissSampleOrderMasterVO);

	void deleteDissSampleOrderMaster(String orderId);

	void createDissSampleOrderItem(DissSampleOrderItemVO dissSampleOrderItemVO);

	void deleteDissSampleOrderItemAll(String orderId);

	DissSampleOrderMasterVO getDissSampleOrderMaster(String orderId);

	List<DissSampleOrderItemVO> getDissSampleOrderItemList(String orderId);

	void updateAfterSendErp(DissSampleOrderMasterVO dissSampleOrderMasterVO);

	List<DissSampleOrderMasterVO> selectDissSampleOrderMasterItemList(DissSampleOrderMasterVO dissSampleOrderMasterVO);
	
	List<DissSampleOrderMasterVO> selectDissSampleOrderCustTestList(DissSampleOrderMasterVO dissSampleOrderMasterVO);
	
	List<DissSampleOrderMasterVO> selectDissSampleOrderCustTestOrderList(DissSampleOrderMasterVO dissSampleOrderMasterVO);
	
	void updateSampleOrderCustTestByStepId(DissSampleOrderMasterVO dissSampleOrderMasterVO);

	int getSampleOrderCount(DissSampleOrderMasterVO param);

	List<DissSampleOrderMasterVO> getSampleOrderList(DissSampleOrderMasterVO param);

	List<DissSampleOrderMasterVO> getDissSampleListExcelDownload(DissSampleOrderMasterVO param);
}
