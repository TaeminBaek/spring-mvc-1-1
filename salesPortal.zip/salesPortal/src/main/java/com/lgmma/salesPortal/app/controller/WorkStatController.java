package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.WorkStatVO;
import com.lgmma.salesPortal.app.service.WorkStatMgmtService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;
import com.lgmma.salesPortal.security.authentication.UserInfo;


//org.springframework.security.web.access.ExceptionTranslationFilter 
@Controller
@RequestMapping("/workstat")
public class WorkStatController {

	private static Logger logger = LoggerFactory.getLogger(WorkStatController.class);
	
	@Autowired
	private WorkStatMgmtService workStatMgmtService;
	
	@RequestMapping(value = "/workStatList")
	public ModelAndView workStatList(ModelAndView mav) throws Exception {
		mav.setViewName("workstat/workStatList");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6));
		return mav;
	}
	
	@RequestMapping(value = "/getWorkStatList.json")
	public Map getWorkStatList(@RequestBody(required=false) @Valid WorkStatVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", workStatMgmtService.getworkStatList(param));
	}
		
	@RequestMapping(value = "/workStatSalesMgmt")
	public ModelAndView workStatSalesMgmt(ModelAndView mav, @Valid WorkStatVO paramWorkStatVo) throws Exception {
		mav.setViewName("workstat/workStatSalesMgmt");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("defaultYyyy"	, DateUtil.getCurrentYear());
		
		UserInfo loginUserInfo = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo();
		//초기값
		if(paramWorkStatVo.getVkorg()==null && paramWorkStatVo.getYyyy()==null && paramWorkStatVo.getMm()==null) {
			paramWorkStatVo.setVkorg(loginUserInfo.getVkorg());
			paramWorkStatVo.setYyyyMm(DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6));
			paramWorkStatVo.setGubun("SA");
		}
		
		mav.addObject("paramWorkStatVo",paramWorkStatVo);
	
		List<WorkStatVO> salesStatList = workStatMgmtService.getworkStatView(paramWorkStatVo);
		mav.addObject("salesStatList", salesStatList);
		
		return mav;
	}
	
	@RequestMapping(value = "/workStatBondMgmt")
	public ModelAndView workStatBondMgmt(ModelAndView mav, @Valid WorkStatVO paramWorkStatVo) throws Exception {
		
		mav.setViewName("workstat/workStatBondMgmt");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("defaultYyyy"	, DateUtil.getCurrentYear());
		
		//초기값
		UserInfo loginUserInfo = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo();
		if(paramWorkStatVo.getVkorg()==null && paramWorkStatVo.getYyyy()==null && paramWorkStatVo.getMm()==null) {
			
			paramWorkStatVo.setVkorg(loginUserInfo.getVkorg());
			paramWorkStatVo.setYyyyMm(DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6));
			paramWorkStatVo.setGubun("BO");
		}
		
		mav.addObject("paramWorkStatVo",paramWorkStatVo);
	
		List<WorkStatVO> bondStatList = workStatMgmtService.getworkStatView(paramWorkStatVo);
		mav.addObject("bondStatList", bondStatList);
		
		return mav;
	}
	@RequestMapping(value = "/workStatStockProductMgmt")
	public ModelAndView workStatStockProductMgmt(ModelAndView mav, @Valid WorkStatVO paramWorkStatVo) {
		mav.setViewName("workstat/workStatStockProductMgmt");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("defaultYyyy"	, DateUtil.getCurrentYear());
		
		//초기값
		UserInfo loginUserInfo = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo();
		if(paramWorkStatVo.getVkorg()==null && paramWorkStatVo.getYyyy()==null && paramWorkStatVo.getMm()==null) {
			paramWorkStatVo.setVkorg(loginUserInfo.getVkorg());
			paramWorkStatVo.setYyyyMm(DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6));
			paramWorkStatVo.setGubun("ST");
		}
		mav.addObject("paramWorkStatVo",paramWorkStatVo);
	
		List<WorkStatVO> stockStatList = workStatMgmtService.getworkStatView(paramWorkStatVo);
		mav.addObject("stockStatList", stockStatList);
		return mav;
	}
	
	@RequestMapping(value = "/workStatProduceProductMgmt")
	public ModelAndView workStatProduceProductMgmt(ModelAndView mav, @Valid WorkStatVO paramWorkStatVo) {
		mav.setViewName("workstat/workStatProduceProductMgmt");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("defaultYyyy"	, DateUtil.getCurrentYear());

		//초기값
		UserInfo loginUserInfo = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo();
		if(paramWorkStatVo.getVkorg()==null && paramWorkStatVo.getYyyy()==null && paramWorkStatVo.getMm()==null) {
			paramWorkStatVo.setVkorg(loginUserInfo.getVkorg());
			paramWorkStatVo.setYyyyMm(DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6));
			paramWorkStatVo.setGubun("PD");
		}
		mav.addObject("paramWorkStatVo",paramWorkStatVo);
	
		List<WorkStatVO> produceStatList = workStatMgmtService.getworkStatView(paramWorkStatVo);
		mav.addObject("produceStatList", produceStatList);
		return mav;
	}
	
	
}
