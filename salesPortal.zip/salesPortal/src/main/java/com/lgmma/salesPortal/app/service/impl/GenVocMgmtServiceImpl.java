package com.lgmma.salesPortal.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.dao.GenVocDao;
import com.lgmma.salesPortal.app.model.GenVocVO;
import com.lgmma.salesPortal.app.service.GenVocMgmtService;

@Service
public class GenVocMgmtServiceImpl implements GenVocMgmtService{

	@Autowired
	private GenVocDao genVocDao;
	
	
	@Override
	public List<GenVocVO> getGenVocItemList() {
		return genVocDao.getGenVocItemList();
	}

	@Override
	public int getGenVocCount(GenVocVO param) {
		return genVocDao.getGenVocCount(param);
	}
	
	@Override
	public List<GenVocVO> getGenVocList(GenVocVO param) {
		return genVocDao.getGenVocList(param);
	}
	
	@Override
	public GenVocVO getGenVocDetail(GenVocVO param) {
		GenVocVO genVocVO = new GenVocVO();
		
		if(param.getSeqxNumx().equals(param.getRefxNumx())) {
			genVocVO.setSeqxNumx(param.getSeqxNumx());
		} else { //답변글이면
			genVocVO.setSeqxNumx(param.getRefxNumx());
		}
		genVocVO.setRefxNumx(param.getRefxNumx());
		
		genVocVO = genVocDao.getGenVocDetail(genVocVO);
		
		List<GenVocVO> replyList = genVocDao.getGenVocReply(genVocVO);
		genVocVO.setReplyList(replyList);
		
		return genVocVO;
	}
	
	@Override
	public void updateGenVocReply(GenVocVO param) {
		genVocDao.updateGenVocReply(param);
	}

	@Override
	public void createGenVocReply(GenVocVO param) {
		genVocDao.createGenVocReply(param);
	}

	@Override
	public void deleteGenVocReply(GenVocVO param) {
		genVocDao.deleteGenVocReply(param);
		
	}

	@Override
	public void updateGenVocEmailSendYn(GenVocVO param) {
		genVocDao.updateGenVocEmailSendYn(param);
	}

	


}
