package com.lgmma.salesPortal.app.model;

public class SalePriceCloseDtlVO extends PagingParamVO {
	private String vkorg;
	private String saleMan;
	private String saleManName;
	private String yyyymm;
	private String vtweg;
	private String vtwegName;
	private String kunnr;
	private String name1;
	private String land1;
	private String indoKunnr;
	private String indoName1;
	private String finalIndoName1;
	private String spType;
	private String spTypeName;
	private String matnr;
	private String konwa;
	private String spTypeKind;
	private String spTypeKindName;
	private String kmein;
	private String kmeinName;
	private double matnrCnt;
	private double price;
	private double netPrice;
	private double prePrice;
	private String wadatIst;
	private double prePrice03;
	private double prePrice02;
	private double prePrice01;
	private double priceGap;
	private double preMonth03;
	private double preMonth02;
	private double preMonth01;
	private double preMonth00;
	private String bigo;
	private int dupCnt;
	private int dupExists;
	private String packUnit;
	private String fobamt1;
	private String fobamt2;
	private String fobamt3;
	private String fobamt4;
	private String fobamtGap;

	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getSaleMan() {
		return saleMan;
	}
	public void setSaleMan(String saleMan) {
		this.saleMan = saleMan;
	}
	public String getSaleManName() {
		return saleManName;
	}
	public void setSaleManName(String saleManName) {
		this.saleManName = saleManName;
	}
	public String getYyyymm() {
		return yyyymm;
	}
	public void setYyyymm(String yyyymm) {
		this.yyyymm = yyyymm;
	}
	public String getVtweg() {
		return vtweg;
	}
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	public String getVtwegName() {
		return vtwegName;
	}
	public void setVtwegName(String vtwegName) {
		this.vtwegName = vtwegName;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getLand1() {
		return land1;
	}
	public void setLand1(String land1) {
		this.land1 = land1;
	}
	public String getIndoKunnr() {
		return indoKunnr;
	}
	public void setIndoKunnr(String indoKunnr) {
		this.indoKunnr = indoKunnr;
	}
	public String getIndoName1() {
		return indoName1;
	}
	public void setIndoName1(String indoName1) {
		this.indoName1 = indoName1;
	}
	public String getSpType() {
		return spType;
	}
	public void setSpType(String spType) {
		this.spType = spType;
	}
	public String getSpTypeName() {
		return spTypeName;
	}
	public void setSpTypeName(String spTypeName) {
		this.spTypeName = spTypeName;
	}
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getKonwa() {
		return konwa;
	}
	public void setKonwa(String konwa) {
		this.konwa = konwa;
	}
	public String getSpTypeKind() {
		return spTypeKind;
	}
	public void setSpTypeKind(String spTypeKind) {
		this.spTypeKind = spTypeKind;
	}
	public String getSpTypeKindName() {
		return spTypeKindName;
	}
	public void setSpTypeKindName(String spTypeKindName) {
		this.spTypeKindName = spTypeKindName;
	}
	public String getKmein() {
		return kmein;
	}
	public void setKmein(String kmein) {
		this.kmein = kmein;
	}
	public double getMatnrCnt() {
		return matnrCnt;
	}
	public void setMatnrCnt(double matnrCnt) {
		this.matnrCnt = matnrCnt;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getPrePrice() {
		return prePrice;
	}
	public void setPrePrice(double prePrice) {
		this.prePrice = prePrice;
	}
	public String getWadatIst() {
		return wadatIst;
	}
	public void setWadatIst(String wadatIst) {
		this.wadatIst = wadatIst;
	}
	public double getPrePrice03() {
		return prePrice03;
	}
	public void setPrePrice03(double prePrice03) {
		this.prePrice03 = prePrice03;
	}
	public double getPrePrice02() {
		return prePrice02;
	}
	public void setPrePrice02(double prePrice02) {
		this.prePrice02 = prePrice02;
	}
	public double getPrePrice01() {
		return prePrice01;
	}
	public void setPrePrice01(double prePrice01) {
		this.prePrice01 = prePrice01;
	}
	public double getPriceGap() {
		return priceGap;
	}
	public void setPriceGap(double priceGap) {
		this.priceGap = priceGap;
	}
	public String getBigo() {
		return bigo;
	}
	public void setBigo(String bigo) {
		this.bigo = bigo;
	}
	public String getKmeinName() {
		return kmeinName;
	}
	public void setKmeinName(String kmeinName) {
		this.kmeinName = kmeinName;
	}
	public String getFinalIndoName1() {
		return finalIndoName1;
	}
	public void setFinalIndoName1(String finalIndoName1) {
		this.finalIndoName1 = finalIndoName1;
	}
	public int getDupCnt() {
		return dupCnt;
	}
	public void setDupCnt(int dupCnt) {
		this.dupCnt = dupCnt;
	}
	public double getNetPrice() {
		return netPrice;
	}
	public void setNetPrice(double netPrice) {
		this.netPrice = netPrice;
	}
	public double getPreMonth03() {
		return preMonth03;
	}
	public void setPreMonth03(double preMonth03) {
		this.preMonth03 = preMonth03;
	}
	public double getPreMonth02() {
		return preMonth02;
	}
	public void setPreMonth02(double preMonth02) {
		this.preMonth02 = preMonth02;
	}
	public double getPreMonth01() {
		return preMonth01;
	}
	public void setPreMonth01(double preMonth01) {
		this.preMonth01 = preMonth01;
	}
	public double getPreMonth00() {
		return preMonth00;
	}
	public void setPreMonth00(double preMonth00) {
		this.preMonth00 = preMonth00;
	}
	public int getDupExists() {
		return dupExists;
	}
	public void setDupExists(int dupExists) {
		this.dupExists = dupExists;
	}
	public String getPackUnit() {
		return packUnit;
	}
	public void setPackUnit(String packUnit) {
		this.packUnit = packUnit;
	}
	public String getFobamt1() {
		return fobamt1;
	}
	public void setFobamt1(String fobamt1) {
		this.fobamt1 = fobamt1;
	}
	public String getFobamt2() {
		return fobamt2;
	}
	public void setFobamt2(String fobamt2) {
		this.fobamt2 = fobamt2;
	}
	public String getFobamt3() {
		return fobamt3;
	}
	public void setFobamt3(String fobamt3) {
		this.fobamt3 = fobamt3;
	}
	public String getFobamt4() {
		return fobamt4;
	}
	public void setFobamt4(String fobamt4) {
		this.fobamt4 = fobamt4;
	}
	public String getFobamtGap() {
		return fobamtGap;
	}
	public void setFobamtGap(String fobamtGap) {
		this.fobamtGap = fobamtGap;
	}
}
