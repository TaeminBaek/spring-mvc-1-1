package com.lgmma.salesPortal.app.model;

public class RiskCreditVO extends PagingParamVO {
	private String vkorg;
	private String datum;
	private String kunnr;
	private String vtweg;
	private String name1;
	private String pernr;
	private String zterm;
	private String text1;
	private String kgrdcd;
	private String cgrdcd;
	private String wgrdcd;
	private String wgrdtxt;
	private String kdate;
	private String rgrdcd;
	private String rgrdtxt;
	private String prnam;
	private String oblig;
	
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getDatum() {
		return datum;
	}
	public void setDatum(String datum) {
		this.datum = datum;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getVtweg() {
		return vtweg;
	}
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getPernr() {
		return pernr;
	}
	public void setPernr(String pernr) {
		this.pernr = pernr;
	}
	public String getZterm() {
		return zterm;
	}
	public void setZterm(String zterm) {
		this.zterm = zterm;
	}
	public String getText1() {
		return text1;
	}
	public void setText1(String text1) {
		this.text1 = text1;
	}
	public String getKgrdcd() {
		return kgrdcd;
	}
	public void setKgrdcd(String kgrdcd) {
		this.kgrdcd = kgrdcd;
	}
	public String getCgrdcd() {
		return cgrdcd;
	}
	public void setCgrdcd(String cgrdcd) {
		this.cgrdcd = cgrdcd;
	}
	public String getWgrdcd() {
		return wgrdcd;
	}
	public void setWgrdcd(String wgrdcd) {
		this.wgrdcd = wgrdcd;
	}
	public String getWgrdtxt() {
		return wgrdtxt;
	}
	public void setWgrdtxt(String wgrdtxt) {
		this.wgrdtxt = wgrdtxt;
	}
	public String getKdate() {
		return kdate;
	}
	public void setKdate(String kdate) {
		this.kdate = kdate;
	}
	public String getRgrdcd() {
		return rgrdcd;
	}
	public void setRgrdcd(String rgrdcd) {
		this.rgrdcd = rgrdcd;
	}
	public String getRgrdtxt() {
		return rgrdtxt;
	}
	public void setRgrdtxt(String rgrdtxt) {
		this.rgrdtxt = rgrdtxt;
	}
	public String getPrnam() {
		return prnam;
	}
	public void setPrnam(String prnam) {
		this.prnam = prnam;
	}
	public String getOblig() {
		return oblig;
	}
	public void setOblig(String oblig) {
		this.oblig = oblig;
	}

}
