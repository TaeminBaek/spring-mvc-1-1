package com.lgmma.salesPortal.app.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.dao.DissDashBoardDao;
import com.lgmma.salesPortal.app.model.DissDashBoardVO;
import com.lgmma.salesPortal.app.service.DissDashBoardService;

@Service
public class DissDashBoardServiceImpl implements DissDashBoardService{
	
	@Autowired
	private DissDashBoardDao dissDashBoardDao;
	
	@Override
	public Map<String,DissDashBoardVO> getDissDashBoardMyIngCnt(DissDashBoardVO param) {
		Map<String,DissDashBoardVO> dissDashBoardMap = new HashMap<String,DissDashBoardVO>();
		dissDashBoardMap.put("specInMyIngCnt", dissDashBoardDao.getDissDashBoardMyIngSpecInCnt(param));
		dissDashBoardMap.put("impDevMyIngCnt", dissDashBoardDao.getDissDashBoardMyIngImpDevCnt(param));
		dissDashBoardMap.put("oneTeamMyIngCnt", dissDashBoardDao.getDissDashBoardMyIngOneTeamCnt(param));
		
		DissDashBoardVO myIngCntVO = new DissDashBoardVO();
		int myIngCntVal = dissDashBoardMap.get("specInMyIngCnt").getIngCnt() 
				 		+ dissDashBoardMap.get("impDevMyIngCnt").getIngCnt()
				 		+ dissDashBoardMap.get("oneTeamMyIngCnt").getIngCnt();
		myIngCntVO.setIngCnt(myIngCntVal);
		
		dissDashBoardMap.put("myIngCnt", myIngCntVO);
		return dissDashBoardMap;
	}

	@Override
	public DissDashBoardVO getDissDashBoardMyIngSpecInCnt(DissDashBoardVO param) {
		return dissDashBoardDao.getDissDashBoardMyIngSpecInCnt(param);
	}

	@Override
	public DissDashBoardVO getDissDashBoardMyIngImpDevCnt(DissDashBoardVO param) {
		return dissDashBoardDao.getDissDashBoardMyIngImpDevCnt(param);
	}

	@Override
	public DissDashBoardVO getDissDashBoardMyIngOneTeamCnt(DissDashBoardVO param) {
		return dissDashBoardDao.getDissDashBoardMyIngOneTeamCnt(param);
	}
	
	//스펙인 My할일 
	@Override
	public Map<String,DissDashBoardVO> getDissDashBoardStepSpecInCnt(DissDashBoardVO param) {
		Map<String,DissDashBoardVO> dissDashBoardMap = new HashMap<String,DissDashBoardVO>();
		//등록
		param.setStepCd("100100");
		dissDashBoardMap.put("myRegStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		param.setStepCd("100200");
		dissDashBoardMap.put("myGateReviewStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		DissDashBoardVO myRegTotCntVO = new DissDashBoardVO();
		myRegTotCntVO.setTotCnt(dissDashBoardMap.get("myRegStepCnt").getTotCnt() + dissDashBoardMap.get("myGateReviewStepCnt").getTotCnt());
		/*myRegTotCntVO.setMyRegiCnt(dissDashBoardMap.get("myRegStepCnt").getMyRegiCnt() + dissDashBoardMap.get("myGateReviewStepCnt").getMyRegiCnt());*/
		dissDashBoardMap.put("myRegTotCnt", myRegTotCntVO);
		
		//개발제안
		param.setStepGroup("200");
		param.setStepCd("200100");
		dissDashBoardMap.put("myDevProposalStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		param.setStepCd("200500");
		dissDashBoardMap.put("myColorProposalStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		DissDashBoardVO myProposalTotCntVO = new DissDashBoardVO();
		myProposalTotCntVO.setTotCnt(dissDashBoardMap.get("myDevProposalStepCnt").getTotCnt() + dissDashBoardMap.get("myColorProposalStepCnt").getTotCnt());
		/*myProposalTotCntVO.setMyRegiCnt(dissDashBoardMap.get("myDevProposalStepCnt").getMyRegiCnt() + dissDashBoardMap.get("myColorProposalStepCnt").getMyRegiCnt());*/
		dissDashBoardMap.put("myProposalTotCnt", myProposalTotCntVO);
		
		//개발결과
		param.setStepGroup("300");
		param.setStepCd("300320");
		dissDashBoardMap.put("myDevPrescriptionStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		param.setStepCd("300500");
		dissDashBoardMap.put("myColorPrescriptionStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		param.setStepCd("300800");
		dissDashBoardMap.put("mySampleEvalStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		DissDashBoardVO myDevPrescriptionTotCntVO = new DissDashBoardVO();
		myDevPrescriptionTotCntVO.setTotCnt(dissDashBoardMap.get("myDevPrescriptionStepCnt").getTotCnt() 
												+ dissDashBoardMap.get("myColorPrescriptionStepCnt").getTotCnt()
												+ dissDashBoardMap.get("mySampleEvalStepCnt").getTotCnt()
											 );
		/*myDevPrescriptionTotCntVO.setMyRegiCnt(dissDashBoardMap.get("myDevPrescriptionStepCnt").getMyRegiCnt() 
												+ dissDashBoardMap.get("myColorPrescriptionStepCnt").getMyRegiCnt()
												+ dissDashBoardMap.get("mySampleEvalStepCnt").getMyRegiCnt()
											 );*/
		dissDashBoardMap.put("myPrescriptionTotCnt", myDevPrescriptionTotCntVO);
		
		//견본송부
		param.setStepGroup("400");
		param.setStepCd("400100");
		dissDashBoardMap.put("mySampleNoticeStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		param.setStepCd("400200");
		dissDashBoardMap.put("mySampleOrderStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		DissDashBoardVO mySampleOrderTotCntVO = new DissDashBoardVO();
		mySampleOrderTotCntVO.setTotCnt(dissDashBoardMap.get("mySampleNoticeStepCnt").getTotCnt() + dissDashBoardMap.get("mySampleOrderStepCnt").getTotCnt());
		/*myMassTransTotCntVO.setMyRegiCnt(dissDashBoardMap.get("myMassTransStepCnt").getMyRegiCnt() + dissDashBoardMap.get("myCompGradeStepCnt").getMyRegiCnt());*/
		dissDashBoardMap.put("mySampleOrderTotCnt", mySampleOrderTotCntVO);
		
		//고객TEST/승인
		param.setStepGroup("500");
		param.setStepCd("500100");
		dissDashBoardMap.put("myCustTestStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		
		//개발완료
		param.setStepGroup("600");
		param.setStepCd("600100");
		dissDashBoardMap.put("myDevCompleteStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		
		//양산이관
		param.setStepGroup("700");
		param.setStepCd("700100");
		dissDashBoardMap.put("myMassTransStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		param.setStepCd("700200");
		dissDashBoardMap.put("myCompGradeStepCnt", dissDashBoardDao.getDissDashBoardStepSpecInCnt(param));
		DissDashBoardVO myMassTransTotCntVO = new DissDashBoardVO();
		myMassTransTotCntVO.setTotCnt(dissDashBoardMap.get("myMassTransStepCnt").getTotCnt() + dissDashBoardMap.get("myCompGradeStepCnt").getTotCnt());
		/*myMassTransTotCntVO.setMyRegiCnt(dissDashBoardMap.get("myMassTransStepCnt").getMyRegiCnt() + dissDashBoardMap.get("myCompGradeStepCnt").getMyRegiCnt());*/
		dissDashBoardMap.put("myMassTransTotCnt", myMassTransTotCntVO);
		return dissDashBoardMap;
	}
	
	//제품개선개발 My할일 
	@Override
	public Map<String,DissDashBoardVO> getDissDashBoardStepImpDevCnt(DissDashBoardVO param) {
		Map<String,DissDashBoardVO> dissDashBoardMap = new HashMap<String,DissDashBoardVO>();
		//개발제안
		param.setStepGroup("200");
		param.setStepCd("200100");
		dissDashBoardMap.put("myDevProposalStepCnt", dissDashBoardDao.getDissDashBoardStepImpDevCnt(param));
		
		//개발결과
		param.setStepGroup("300");
		param.setStepCd("300320");
		dissDashBoardMap.put("myDevPrescriptionStepCnt", dissDashBoardDao.getDissDashBoardStepImpDevCnt(param));
		param.setStepCd("300800");
		dissDashBoardMap.put("mySampleEvalStepCnt", dissDashBoardDao.getDissDashBoardStepImpDevCnt(param));
		DissDashBoardVO myDevPrescriptionTotCntVO = new DissDashBoardVO();
		myDevPrescriptionTotCntVO.setTotCnt(dissDashBoardMap.get("myDevPrescriptionStepCnt").getTotCnt() + dissDashBoardMap.get("mySampleEvalStepCnt").getTotCnt());
		dissDashBoardMap.put("myPrescriptionTotCnt", myDevPrescriptionTotCntVO);
		
		//견본송부
		param.setStepGroup("400");
		param.setStepCd("400100");
		dissDashBoardMap.put("mySampleNoticeStepCnt", dissDashBoardDao.getDissDashBoardStepImpDevCnt(param));
		param.setStepCd("400200");
		dissDashBoardMap.put("mySampleOrderStepCnt", dissDashBoardDao.getDissDashBoardStepImpDevCnt(param));
		DissDashBoardVO mySampleOrderTotCntVO = new DissDashBoardVO();
		mySampleOrderTotCntVO.setTotCnt(dissDashBoardMap.get("mySampleNoticeStepCnt").getTotCnt() + dissDashBoardMap.get("mySampleOrderStepCnt").getTotCnt());
		/*myMassTransTotCntVO.setMyRegiCnt(dissDashBoardMap.get("myMassTransStepCnt").getMyRegiCnt() + dissDashBoardMap.get("myCompGradeStepCnt").getMyRegiCnt());*/
		dissDashBoardMap.put("mySampleOrderTotCnt", mySampleOrderTotCntVO);
		
		//고객TEST/승인
		param.setStepGroup("500");
		param.setStepCd("500100");
		dissDashBoardMap.put("myCustTestStepCnt", dissDashBoardDao.getDissDashBoardStepImpDevCnt(param));
		
		//개발완료
		param.setStepGroup("600");
		param.setStepCd("600100");
		dissDashBoardMap.put("myDevCompleteStepCnt", dissDashBoardDao.getDissDashBoardStepImpDevCnt(param));
		
		//양산이관
		param.setStepGroup("700");
		param.setStepCd("700100");
		dissDashBoardMap.put("myMassTransStepCnt", dissDashBoardDao.getDissDashBoardStepImpDevCnt(param));
		param.setStepCd("700200");
		dissDashBoardMap.put("myCompGradeStepCnt", dissDashBoardDao.getDissDashBoardStepImpDevCnt(param));
		DissDashBoardVO myMassTransTotCntVO = new DissDashBoardVO();
		myMassTransTotCntVO.setTotCnt(dissDashBoardMap.get("myMassTransStepCnt").getTotCnt() + dissDashBoardMap.get("myCompGradeStepCnt").getTotCnt());
		dissDashBoardMap.put("myMassTransTotCnt", myMassTransTotCntVO);
		return dissDashBoardMap;
	}
}
