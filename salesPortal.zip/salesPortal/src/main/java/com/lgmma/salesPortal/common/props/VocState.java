package com.lgmma.salesPortal.common.props;

public enum VocState {
/**
 * 고객서비스노출상태로서
*/
	 VOC_REGIST(	"R"	,"등록"			,false	,"1")
	,VOC_RECEIPTION("P"	,"접수"			,false	,"2")
	,VOC_STUDY(		"S"	,"내부검토중"	,false	,"3")
	,VOC_COMPLETE(	"C"	,"답변완료"		,true	,"4")
	,VOC_HAPPYCALL(	"H"	,"해피콜"		,true	,"6")
	;
	String code		= null;		// 고객서비스상태코드
	String name		= null;		// 고객서비스상태명
	boolean completeYn = false;	// 완료상태여부
	String iconCode	= null;		// 이미지아이콘코드

	private VocState(String code, String name, boolean completeYn, String iconCode) {
		this.code		= code;
		this.name		= name;
		this.completeYn	= completeYn;
		this.iconCode	= iconCode;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isCompleteYn() {
		return completeYn;
	}

	public void setCompleteYn(boolean completeYn) {
		this.completeYn = completeYn;
	}

	public String getIconCode() {
		return iconCode;
	}

	public void setIconCode(String iconCode) {
		this.iconCode = iconCode;
	}

	public static VocState getVocState(String code) {
		for(VocState type : VocState.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
}
