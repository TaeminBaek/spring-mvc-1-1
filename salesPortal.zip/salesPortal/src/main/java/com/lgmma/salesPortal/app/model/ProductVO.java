package com.lgmma.salesPortal.app.model;

public class ProductVO extends PagingParamVO {

	private String matnr;
	private String partnNumb;
	private String mtart;
	private String mbrsh;
	private String matkl;
	private String bismt;
	private String meins;
	private String bstme;
	private String groes;
	private String stoff;
	private String spart;
	private String kunnr;
	private String xchpf;
	private String magrv;
	private String ersda;
	private String laeda;
	private String aenam;
	private String vkorg;
	private String vtweg;
	private String kondm;
	private String ktgrm;
	private String mvgr1;
	private String mvgr2;
	private String mvgr3;
	private String mvgr4;
	private String mvgr5;
	private String vrkme;
	private String maktx;
	private String condType;
	private String condValue;
	private String currency;
	private String condUnit;
	private String condPUnt;
	private String stockDpYn;
	private String stockYn;
	private String lvorm;

	// 추가정보
	private String clabs;

	// 재고정보
	private String stockSumCnt;
	private String stockInfo;

	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getPartnNumb() {
		return partnNumb;
	}
	public void setPartnNumb(String partnNumb) {
		this.partnNumb = partnNumb;
	}
	public String getMtart() {
		return mtart;
	}
	public void setMtart(String mtart) {
		this.mtart = mtart;
	}
	public String getMbrsh() {
		return mbrsh;
	}
	public void setMbrsh(String mbrsh) {
		this.mbrsh = mbrsh;
	}
	public String getMatkl() {
		return matkl;
	}
	public void setMatkl(String matkl) {
		this.matkl = matkl;
	}
	public String getBismt() {
		return bismt;
	}
	public void setBismt(String bismt) {
		this.bismt = bismt;
	}
	public String getMeins() {
		return meins;
	}
	public void setMeins(String meins) {
		this.meins = meins;
	}
	public String getBstme() {
		return bstme;
	}
	public void setBstme(String bstme) {
		this.bstme = bstme;
	}
	public String getGroes() {
		return groes;
	}
	public void setGroes(String groes) {
		this.groes = groes;
	}
	public String getStoff() {
		return stoff;
	}
	public void setStoff(String stoff) {
		this.stoff = stoff;
	}
	public String getSpart() {
		return spart;
	}
	public void setSpart(String spart) {
		this.spart = spart;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getXchpf() {
		return xchpf;
	}
	public void setXchpf(String xchpf) {
		this.xchpf = xchpf;
	}
	public String getMagrv() {
		return magrv;
	}
	public void setMagrv(String magrv) {
		this.magrv = magrv;
	}
	public String getErsda() {
		return ersda;
	}
	public void setErsda(String ersda) {
		this.ersda = ersda;
	}
	public String getLaeda() {
		return laeda;
	}
	public void setLaeda(String laeda) {
		this.laeda = laeda;
	}
	public String getAenam() {
		return aenam;
	}
	public void setAenam(String aenam) {
		this.aenam = aenam;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getVtweg() {
		return vtweg;
	}
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	public String getKondm() {
		return kondm;
	}
	public void setKondm(String kondm) {
		this.kondm = kondm;
	}
	public String getKtgrm() {
		return ktgrm;
	}
	public void setKtgrm(String ktgrm) {
		this.ktgrm = ktgrm;
	}
	public String getMvgr1() {
		return mvgr1;
	}
	public void setMvgr1(String mvgr1) {
		this.mvgr1 = mvgr1;
	}
	public String getMvgr2() {
		return mvgr2;
	}
	public void setMvgr2(String mvgr2) {
		this.mvgr2 = mvgr2;
	}
	public String getMvgr3() {
		return mvgr3;
	}
	public void setMvgr3(String mvgr3) {
		this.mvgr3 = mvgr3;
	}
	public String getMvgr4() {
		return mvgr4;
	}
	public void setMvgr4(String mvgr4) {
		this.mvgr4 = mvgr4;
	}
	public String getMvgr5() {
		return mvgr5;
	}
	public void setMvgr5(String mvgr5) {
		this.mvgr5 = mvgr5;
	}
	public String getVrkme() {
		return vrkme;
	}
	public void setVrkme(String vrkme) {
		this.vrkme = vrkme;
	}
	public String getMaktx() {
		return maktx;
	}
	public void setMaktx(String maktx) {
		this.maktx = maktx;
	}
	public String getCondType() {
		return condType;
	}
	public void setCondType(String condType) {
		this.condType = condType;
	}
	public String getCondValue() {
		return condValue;
	}
	public void setCondValue(String condValue) {
		this.condValue = condValue;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCondUnit() {
		return condUnit;
	}
	public void setCondUnit(String condUnit) {
		this.condUnit = condUnit;
	}
	public String getCondPUnt() {
		return condPUnt;
	}
	public void setCondPUnt(String condPUnt) {
		this.condPUnt = condPUnt;
	}
	public String getStockDpYn() {
		return stockDpYn;
	}
	public void setStockDpYn(String stockDpYn) {
		this.stockDpYn = stockDpYn;
	}
	public String getClabs() {
		return clabs;
	}
	public void setClabs(String clabs) {
		this.clabs = clabs;
	}
	public String getStockSumCnt() {
		return stockSumCnt;
	}
	public void setStockSumCnt(String stockSumCnt) {
		this.stockSumCnt = stockSumCnt;
	}
	public String getStockInfo() {
		return stockInfo;
	}
	public void setStockInfo(String stockInfo) {
		this.stockInfo = stockInfo;
	}
	public String getStockYn() {
		return stockYn;
	}
	public void setStockYn(String stockYn) {
		this.stockYn = stockYn;
	}
	public String getLvorm() {
		return lvorm;
	}
	public void setLvorm(String lvorm) {
		this.lvorm = lvorm;
	}
	
	
}
