package com.lgmma.salesPortal.app.model;

public class CustomerCreditAssessInquiryDetailVO extends PagingParamVO {

	//기업개요
	private String kedCd;
	private String kedName;
	private String representativeName;
	private String businessNumber;
	private String businessCategoryName;
	private String corporationNumber;
	private String disclosureCodeName;
	private String telNo;
	private String workerNumber;
	private String transactionBankName;
	private String roadNameAddress;
	private String corporateStatusName;
	private String corporateStatusChangeDate;
	
	//기업등급	
	private String gradeFrst;  
	private String evDateFrst; 
	private String fnBaseDateFrst; 
	private String classificationFrst;
	private String gradeScnd;
	private String evDateScnd;
	private String fnBaseDateScnd;
	private String classificationScnd;
	private String gradeThrd;
	private String evDateThrd;
	private String fnBaseDateThrd;
	private String classificationThrd;
		
	//주요주주
	private String shareholderNameFrst;
	private String equityRatioFrst;
	private String shareholderNameScnd;
	private String equityRatioScnd;
	private String shareholderNameThrd;
	private String equityRatioThrd;
	
	//주요 재무상태표 
	private String totalAssetsFrst;
	private String totalAssetsScnd;
	private String totalAssetsThrd;
	private String totalDebtFrst;
	private String totalDebtScnd;
	private String totalDebtThrd;
	private String totalEquityFrst;
	private String totalEquityScnd;
	private String totalEquityThrd;
			 
	//주요 손익계산서
	private String totalSalesFrst;
	private String totalSalesScnd;
	private String totalSalesThrd;
	private String operatingProfitFrst;
	private String operatingProfitScnd;
	private String operatingProfitThrd;
	private String netIncomeFrst;
	private String netIncomeScnd;
	private String netIncomeThrd;
	
	//주요재무비율
	private String salesGrowsRateFrst;
	private String operatingMarginFrst;
	private String equityCapitalFrst;
	private String interestCompFrst;
	private String tradeTurnoverFrst;
	private String salesGrowsRateScnd;
	private String operatingMarginScnd;
	private String equityCapitalScnd;
	private String interestCompScnd;
	private String tradeTurnoverScnd;
	
	//관계회사
	private String associatedCompanyNameFrst;
	private String associatedEquityRatioFrst;
	private String associatedCompanyNameScnd;
	private String associatedEquityRatioScnd;
	private String associatedCompanyNameThrd;
	private String associatedEquityRatioThrd;
	
	//주요구매처
	private String bcCustNameFrst;
	private String bcTransactionRatioFrst;
	private String bcCustNameScnd;
	private String bcTransactionRatioScnd;
	private String bcCustNameThrd;
	private String bcTransactionRatioThrd;
		 
	//주묘판매처
	private String scCustNameFrst;
	private String scTransactionRatioFrst;
	private String scCustNameScnd;
	private String scTransactionRatioScnd;
	private String scCustNameThrd;
	private String scTransactionRatioThrd;
	   
		
	public String getKedCd() {
		return kedCd;
	}
	
	public void setKedCd(String kedCd) {
		this.kedCd = kedCd;
	}
	
	public String getKedName() {
		return kedName;
	}
	
	public void setKedName(String kedName) {
		this.kedName = kedName;
	}
	
	public String getRepresentativeName() {
		return representativeName;
	}
	
	public void setRepresentativeName(String representativeName) {
		this.representativeName = representativeName;
	}
	
	public String getBusinessNumber() {
		return businessNumber;
	}
	
	public void setBusinessNumber(String businessNumber) {
		this.businessNumber = businessNumber;
	}
	
	public String getBusinessCategoryName() {
		return businessCategoryName;
	}
	
	public void setBusinessCategoryName(String businessCategoryName) {
		this.businessCategoryName = businessCategoryName;
	}
	
	public String getCorporationNumber() {
		return corporationNumber;
	}
	
	public void setCorporationNumber(String corporationNumber) {
		this.corporationNumber = corporationNumber;
	}
	
	public String getDisclosureCodeName() {
		return disclosureCodeName;
	}
	
	public void setDisclosureCodeName(String disclosureCodeName) {
		this.disclosureCodeName = disclosureCodeName;
	}
	
	public String getTelNo() {
		return telNo;
	}

	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}
	
	public String getWorkerNumber() {
		return workerNumber;
	}
	
	public void setWorkerNumber(String workerNumber) {
		this.workerNumber = workerNumber;
	}
	
	public String getTransactionBankName() {
		return transactionBankName;
	}
	
	public void setTransactionBankName(String transactionBankName) {
		this.transactionBankName = transactionBankName;
	}
	
	public String getRoadNameAddress() {
		return roadNameAddress;
	}
	
	public void setRoadNameAddress(String roadNameAddress) {
		this.roadNameAddress = roadNameAddress;
	}
	
	public String getCorporateStatusName() {
		return corporateStatusName;
	}

	public void setCorporateStatusName(String corporateStatusName) {
		this.corporateStatusName = corporateStatusName;
	}

	public String getCorporateStatusChangeDate() {
		return corporateStatusChangeDate;
	}

	public void setCorporateStatusChangeDate(String corporateStatusChangeDate) {
		this.corporateStatusChangeDate = corporateStatusChangeDate;
	}

	public String getGradeFrst() {
		return gradeFrst;
	}

	public void setGradeFrst(String gradeFrst) {
		this.gradeFrst = gradeFrst;
	}

	public String getEvDateFrst() {
		return evDateFrst;
	}

	public void setEvDateFrst(String evDateFrst) {
		this.evDateFrst = evDateFrst;
	}

	public String getFnBaseDateFrst() {
		return fnBaseDateFrst;
	}

	public void setFnBaseDateFrst(String fnBaseDateFrst) {
		this.fnBaseDateFrst = fnBaseDateFrst;
	}

	public String getClassificationFrst() {
		return classificationFrst;
	}

	public void setClassificationFrst(String classificationFrst) {
		this.classificationFrst = classificationFrst;
	}

	public String getGradeScnd() {
		return gradeScnd;
	}

	public void setGradeScnd(String gradeScnd) {
		this.gradeScnd = gradeScnd;
	}

	public String getEvDateScnd() {
		return evDateScnd;
	}

	public void setEvDateScnd(String evDateScnd) {
		this.evDateScnd = evDateScnd;
	}

	public String getFnBaseDateScnd() {
		return fnBaseDateScnd;
	}

	public void setFnBaseDateScnd(String fnBaseDateScnd) {
		this.fnBaseDateScnd = fnBaseDateScnd;
	}

	public String getClassificationScnd() {
		return classificationScnd;
	}

	public void setClassificationScnd(String classificationScnd) {
		this.classificationScnd = classificationScnd;
	}

	public String getGradeThrd() {
		return gradeThrd;
	}

	public void setGradeThrd(String gradeThrd) {
		this.gradeThrd = gradeThrd;
	}

	public String getEvDateThrd() {
		return evDateThrd;
	}

	public void setEvDateThrd(String evDateThrd) {
		this.evDateThrd = evDateThrd;
	}

	public String getFnBaseDateThrd() {
		return fnBaseDateThrd;
	}

	public void setFnBaseDateThrd(String fnBaseDateThrd) {
		this.fnBaseDateThrd = fnBaseDateThrd;
	}

	public String getClassificationThrd() {
		return classificationThrd;
	}

	public void setClassificationThrd(String classificationThrd) {
		this.classificationThrd = classificationThrd;
	}

	public String getShareholderNameFrst() {
		return shareholderNameFrst;
	}

	public void setShareholderNameFrst(String shareholderNameFrst) {
		this.shareholderNameFrst = shareholderNameFrst;
	}

	public String getEquityRatioFrst() {
		return equityRatioFrst;
	}

	public void setEquityRatioFrst(String equityRatioFrst) {
		this.equityRatioFrst = equityRatioFrst;
	}

	public String getShareholderNameScnd() {
		return shareholderNameScnd;
	}

	public void setShareholderNameScnd(String shareholderNameScnd) {
		this.shareholderNameScnd = shareholderNameScnd;
	}

	public String getEquityRatioScnd() {
		return equityRatioScnd;
	}

	public void setEquityRatioScnd(String equityRatioScnd) {
		this.equityRatioScnd = equityRatioScnd;
	}

	public String getShareholderNameThrd() {
		return shareholderNameThrd;
	}

	public void setShareholderNameThrd(String shareholderNameThrd) {
		this.shareholderNameThrd = shareholderNameThrd;
	}

	public String getEquityRatioThrd() {
		return equityRatioThrd;
	}

	public void setEquityRatioThrd(String equityRatioThrd) {
		this.equityRatioThrd = equityRatioThrd;
	}

	public String getTotalAssetsFrst() {
		return totalAssetsFrst;
	}

	public void setTotalAssetsFrst(String totalAssetsFrst) {
		this.totalAssetsFrst = totalAssetsFrst;
	}

	public String getTotalAssetsScnd() {
		return totalAssetsScnd;
	}

	public void setTotalAssetsScnd(String totalAssetsScnd) {
		this.totalAssetsScnd = totalAssetsScnd;
	}

	public String getTotalAssetsThrd() {
		return totalAssetsThrd;
	}

	public void setTotalAssetsThrd(String totalAssetsThrd) {
		this.totalAssetsThrd = totalAssetsThrd;
	}

	public String getTotalDebtFrst() {
		return totalDebtFrst;
	}

	public void setTotalDebtFrst(String totalDebtFrst) {
		this.totalDebtFrst = totalDebtFrst;
	}

	public String getTotalDebtScnd() {
		return totalDebtScnd;
	}

	public void setTotalDebtScnd(String totalDebtScnd) {
		this.totalDebtScnd = totalDebtScnd;
	}

	public String getTotalDebtThrd() {
		return totalDebtThrd;
	}

	public void setTotalDebtThrd(String totalDebtThrd) {
		this.totalDebtThrd = totalDebtThrd;
	}

	public String getTotalEquityFrst() {
		return totalEquityFrst;
	}

	public void setTotalEquityFrst(String totalEquityFrst) {
		this.totalEquityFrst = totalEquityFrst;
	}

	public String getTotalEquityScnd() {
		return totalEquityScnd;
	}

	public void setTotalEquityScnd(String totalEquityScnd) {
		this.totalEquityScnd = totalEquityScnd;
	}

	public String getTotalEquityThrd() {
		return totalEquityThrd;
	}

	public void setTotalEquityThrd(String totalEquityThrd) {
		this.totalEquityThrd = totalEquityThrd;
	}

	public String getTotalSalesFrst() {
		return totalSalesFrst;
	}

	public void setTotalSalesFrst(String totalSalesFrst) {
		this.totalSalesFrst = totalSalesFrst;
	}

	public String getTotalSalesScnd() {
		return totalSalesScnd;
	}

	public void setTotalSalesScnd(String totalSalesScnd) {
		this.totalSalesScnd = totalSalesScnd;
	}

	public String getTotalSalesThrd() {
		return totalSalesThrd;
	}

	public void setTotalSalesThrd(String totalSalesThrd) {
		this.totalSalesThrd = totalSalesThrd;
	}

	public String getOperatingProfitFrst() {
		return operatingProfitFrst;
	}

	public void setOperatingProfitFrst(String operatingProfitFrst) {
		this.operatingProfitFrst = operatingProfitFrst;
	}

	public String getOperatingProfitScnd() {
		return operatingProfitScnd;
	}

	public void setOperatingProfitScnd(String operatingProfitScnd) {
		this.operatingProfitScnd = operatingProfitScnd;
	}

	public String getOperatingProfitThrd() {
		return operatingProfitThrd;
	}

	public void setOperatingProfitThrd(String operatingProfitThrd) {
		this.operatingProfitThrd = operatingProfitThrd;
	}

	public String getNetIncomeFrst() {
		return netIncomeFrst;
	}

	public void setNetIncomeFrst(String netIncomeFrst) {
		this.netIncomeFrst = netIncomeFrst;
	}

	public String getNetIncomeScnd() {
		return netIncomeScnd;
	}

	public void setNetIncomeScnd(String netIncomeScnd) {
		this.netIncomeScnd = netIncomeScnd;
	}

	public String getNetIncomeThrd() {
		return netIncomeThrd;
	}

	public void setNetIncomeThrd(String netIncomeThrd) {
		this.netIncomeThrd = netIncomeThrd;
	}

	public String getSalesGrowsRateFrst() {
		return salesGrowsRateFrst;
	}

	public void setSalesGrowsRateFrst(String salesGrowsRateFrst) {
		this.salesGrowsRateFrst = salesGrowsRateFrst;
	}

	public String getOperatingMarginFrst() {
		return operatingMarginFrst;
	}

	public void setOperatingMarginFrst(String operatingMarginFrst) {
		this.operatingMarginFrst = operatingMarginFrst;
	}

	public String getEquityCapitalFrst() {
		return equityCapitalFrst;
	}

	public void setEquityCapitalFrst(String equityCapitalFrst) {
		this.equityCapitalFrst = equityCapitalFrst;
	}

	public String getInterestCompFrst() {
		return interestCompFrst;
	}

	public void setInterestCompFrst(String interestCompFrst) {
		this.interestCompFrst = interestCompFrst;
	}

	public String getTradeTurnoverFrst() {
		return tradeTurnoverFrst;
	}

	public void setTradeTurnoverFrst(String tradeTurnoverFrst) {
		this.tradeTurnoverFrst = tradeTurnoverFrst;
	}

	public String getSalesGrowsRateScnd() {
		return salesGrowsRateScnd;
	}

	public void setSalesGrowsRateScnd(String salesGrowsRateScnd) {
		this.salesGrowsRateScnd = salesGrowsRateScnd;
	}

	public String getOperatingMarginScnd() {
		return operatingMarginScnd;
	}

	public void setOperatingMarginScnd(String operatingMarginScnd) {
		this.operatingMarginScnd = operatingMarginScnd;
	}

	public String getEquityCapitalScnd() {
		return equityCapitalScnd;
	}

	public void setEquityCapitalScnd(String equityCapitalScnd) {
		this.equityCapitalScnd = equityCapitalScnd;
	}

	public String getInterestCompScnd() {
		return interestCompScnd;
	}

	public void setInterestCompScnd(String interestCompScnd) {
		this.interestCompScnd = interestCompScnd;
	}

	public String getTradeTurnoverScnd() {
		return tradeTurnoverScnd;
	}

	public void setTradeTurnoverScnd(String tradeTurnoverScnd) {
		this.tradeTurnoverScnd = tradeTurnoverScnd;
	}

	public String getAssociatedCompanyNameFrst() {
		return associatedCompanyNameFrst;
	}

	public void setAssociatedCompanyNameFrst(String associatedCompanyNameFrst) {
		this.associatedCompanyNameFrst = associatedCompanyNameFrst;
	}

	public String getAssociatedEquityRatioFrst() {
		return associatedEquityRatioFrst;
	}

	public void setAssociatedEquityRatioFrst(String associatedEquityRatioFrst) {
		this.associatedEquityRatioFrst = associatedEquityRatioFrst;
	}

	public String getAssociatedCompanyNameScnd() {
		return associatedCompanyNameScnd;
	}

	public void setAssociatedCompanyNameScnd(String associatedCompanyNameScnd) {
		this.associatedCompanyNameScnd = associatedCompanyNameScnd;
	}

	public String getAssociatedEquityRatioScnd() {
		return associatedEquityRatioScnd;
	}

	public void setAssociatedEquityRatioScnd(String associatedEquityRatioScnd) {
		this.associatedEquityRatioScnd = associatedEquityRatioScnd;
	}

	public String getAssociatedCompanyNameThrd() {
		return associatedCompanyNameThrd;
	}

	public void setAssociatedCompanyNameThrd(String associatedCompanyNameThrd) {
		this.associatedCompanyNameThrd = associatedCompanyNameThrd;
	}

	public String getAssociatedEquityRatioThrd() {
		return associatedEquityRatioThrd;
	}

	public void setAssociatedEquityRatioThrd(String associatedEquityRatioThrd) {
		this.associatedEquityRatioThrd = associatedEquityRatioThrd;
	}

	public String getBcCustNameFrst() {
		return bcCustNameFrst;
	}

	public void setBcCustNameFrst(String bcCustNameFrst) {
		this.bcCustNameFrst = bcCustNameFrst;
	}

	public String getBcTransactionRatioFrst() {
		return bcTransactionRatioFrst;
	}

	public void setBcTransactionRatioFrst(String bcTransactionRatioFrst) {
		this.bcTransactionRatioFrst = bcTransactionRatioFrst;
	}

	public String getBcCustNameScnd() {
		return bcCustNameScnd;
	}

	public void setBcCustNameScnd(String bcCustNameScnd) {
		this.bcCustNameScnd = bcCustNameScnd;
	}

	public String getBcTransactionRatioScnd() {
		return bcTransactionRatioScnd;
	}

	public void setBcTransactionRatioScnd(String bcTransactionRatioScnd) {
		this.bcTransactionRatioScnd = bcTransactionRatioScnd;
	}

	public String getBcCustNameThrd() {
		return bcCustNameThrd;
	}

	public void setBcCustNameThrd(String bcCustNameThrd) {
		this.bcCustNameThrd = bcCustNameThrd;
	}

	public String getBcTransactionRatioThrd() {
		return bcTransactionRatioThrd;
	}

	public void setBcTransactionRatioThrd(String bcTransactionRatioThrd) {
		this.bcTransactionRatioThrd = bcTransactionRatioThrd;
	}

	public String getScCustNameFrst() {
		return scCustNameFrst;
	}

	public void setScCustNameFrst(String scCustNameFrst) {
		this.scCustNameFrst = scCustNameFrst;
	}

	public String getScTransactionRatioFrst() {
		return scTransactionRatioFrst;
	}

	public void setScTransactionRatioFrst(String scTransactionRatioFrst) {
		this.scTransactionRatioFrst = scTransactionRatioFrst;
	}

	public String getScCustNameScnd() {
		return scCustNameScnd;
	}

	public void setScCustNameScnd(String scCustNameScnd) {
		this.scCustNameScnd = scCustNameScnd;
	}

	public String getScTransactionRatioScnd() {
		return scTransactionRatioScnd;
	}

	public void setScTransactionRatioScnd(String scTransactionRatioScnd) {
		this.scTransactionRatioScnd = scTransactionRatioScnd;
	}

	public String getScCustNameThrd() {
		return scCustNameThrd;
	}

	public void setScCustNameThrd(String scCustNameThrd) {
		this.scCustNameThrd = scCustNameThrd;
	}

	public String getScTransactionRatioThrd() {
		return scTransactionRatioThrd;
	}

	public void setScTransactionRatioThrd(String scTransactionRatioThrd) {
		this.scTransactionRatioThrd = scTransactionRatioThrd;
	}
 
	
	
}
