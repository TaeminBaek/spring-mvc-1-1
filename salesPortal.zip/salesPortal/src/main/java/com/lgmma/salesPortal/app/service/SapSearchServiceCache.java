package com.lgmma.salesPortal.app.service;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.CustomerCreditListVO;
import com.lgmma.salesPortal.app.model.WorkStatVO;
import com.lgmma.salesPortal.common.model.DDLBItem;

public interface SapSearchServiceCache {

	List<DDLBItem> getSapCommonCodeListCache(String zgubun);
	
	Map<String, WorkStatVO> getNetProfitListCache(String year, String month);
	
	List<String> getKunnr(String param);
	
	List<CustomerCreditListVO> getCustomerCreditListCache(String gjahr
														 ,String gsber
														 ,String vtweg
														 ,String name1); 
	
}
