package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.ProductStockVO;
import com.lgmma.salesPortal.app.model.ProductVO;

public interface StockDisplayDao {

	int getStockDisplayCount(ProductVO param);

	List<ProductVO> getStockDisplayList(ProductVO param);

	void updateStockDisplay(ProductVO param);

	public void mergeProduct(List<ProductVO> productList);

	int getProductInStockCount(ProductStockVO param);

	List<ProductStockVO> getProductInStockList(ProductStockVO param);

}
