package com.lgmma.salesPortal.app.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgmma.salesPortal.app.model.SampleOrderMasterVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.DirectOrderService;
import com.lgmma.salesPortal.app.service.SampleOrderService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.Map;

@Controller
@RequestMapping("/sampleOrder")
public class SampleOrderController {

	private static Logger logger = LoggerFactory.getLogger(SampleOrderController.class);

	@Autowired
	private DirectOrderService directOrderService;

	@Autowired
	private SampleOrderService sampleOrderService;

	@Autowired
	private CommonService commonService;

	@Autowired
	private CommonController commonController;

	@Autowired
	private DirectOrderController directOrderController;

	/**
	 * 견본관리 품의목록 화면 랜딩
	 * @param mav
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sampleDocList")
	public ModelAndView sampleDocMgmt(ModelAndView mav ) throws Exception {
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		mav.addObject("userName",((CustomAuthenticationToken) SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getSawnName());
		mav.setViewName("sampleOrder/sampleDocList");
		return mav;
	}

	/**
	 * 견본관리 품의목록 조회
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/getSampleDocList.json")
	public Map getSampleDocList(@RequestBody(required = true) SampleOrderMasterVO param) {
		return JsonResponse.asSuccess("storeData", sampleOrderService.getSampleDocList(param),"itemsCount",sampleOrderService.getSampleDocCount(param));
	}


	/**
	 * 견본관리 견본목록 화면 랜딩
	 * @param mav
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sampleOrderMgmt")
	public ModelAndView sampleOrderMgmt(ModelAndView mav ) throws Exception {
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("orderTypeList", OrderType.values());
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		mav.addObject("apprStatList", commonController.getApprStateDDLB().get("items"));
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = directOrderController.getOrderCode(OrderType.SAMPLE);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));
		mav.setViewName("sampleOrder/sampleOrderMgmt");
		return mav;
	}

	/**
	 * 견본관리 견본목록 조회
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/getSampleOrderList.json")
	public Map getSampleOrderList(@RequestBody(required = true) SampleOrderMasterVO param) {
		return JsonResponse.asSuccess("storeData", sampleOrderService.getSampleOrderList(param),"itemsCount",sampleOrderService.getSampleOrderCount(param));
	}

	/**
	 * 견본관리 견본등록 화면 랜딩
	 * @param mav
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sampleOrderRegist")
	public ModelAndView sampleOrderRegist(ModelAndView mav
                                          ,String vactIdxx
	) throws Exception {
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("vactIdxx",StringUtil.nullConvert(vactIdxx));
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("orderType", OrderType.SAMPLE);
		mav.addObject("apprStatList", commonController.getApprStateDDLB().get("items"));
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = directOrderController.getOrderCode(OrderType.SAMPLE);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		mav.setViewName("sampleOrder/sampleOrderRegist");
		return mav;
	}

	/**
	 * 견본관리 수정,조회용 페이지 랜딩
	 * @param mav
	 * @param docType
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/detail/{docType}")
	public ModelAndView orderDetail(ModelAndView mav, @PathVariable("docType") String docType) throws Exception {
		mav.addObject("mode", "edit");
		sampleOrderRegist(mav,"");
		mav.setViewName("sampleOrder/detail/sampleOrderRegist");
		return mav;
	}


	/**
	 * 견본상세 조회
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getSampleOrderDetail.json")
	public Map getSampleOrderDetail(@RequestBody(required=true) SampleOrderMasterVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", sampleOrderService.getSampleOrderDetail(param.getOrderId()));
	}

	/**
	 * 견본등록
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/createOrder.json")
	public Map createOrder(@RequestBody(required=true) @Valid SampleOrderMasterVO param) throws Exception {
		sampleOrderService.createSampleOrder(param);
		return JsonResponse.asSuccess("success", "생성 되었습니다.");
	}

	/**
	 * 견본등록ERP전송
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/sendCreErp.json")
	public Map sendCreErp(@RequestBody(required=true) SampleOrderMasterVO param) {
		sampleOrderService.updateSampleOrder(param);
		sampleOrderService.createDirectOrderAndSendErp(param);
		return JsonResponse.asSuccess("success", "생성 되었습니다.");
	}

	/**
	 * 견본수정
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/updateOrder.json")
	public Map updateOrder(@RequestBody(required=true) @Valid SampleOrderMasterVO param) throws Exception {
		sampleOrderService.updateSampleOrder(param);
		return JsonResponse.asSuccess("success", "수정 되었습니다.");
	}

	/**
	 * 견본수정&ERP전송
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/updateOrderSendErp.json")
	public Map updateOrderSendErp(@RequestBody(required=true) @Valid SampleOrderMasterVO param) throws Exception {
		sampleOrderService.updateSampleOrderAndSendErp(param);
		return JsonResponse.asSuccess("success", "수정 되었습니다.");
	}

	/**
	 * 견본비고수정&ERP전송
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/updateOrderCommentSendErp.json")
	public Map updateOrderCommentSendErp(@RequestBody(required=true) @Valid SampleOrderMasterVO param) throws Exception {
		sampleOrderService.updateSampleOrderCommentAndSendErp(param);
		return JsonResponse.asSuccess("success", "수정 되었습니다.");
	}
	
	/**
	 * 견본삭제
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/deleteOrder.json")
	public Map deleteOrder(@RequestBody(required=true) @Valid SampleOrderMasterVO param) throws Exception {
		sampleOrderService.deleteSampleOrder(param);
		return JsonResponse.asSuccess("success", "삭제 되었습니다.");
	}

	/**
	 * VOC 요청내용 조회
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getVocInfo.json")
	public Map getVocInfo(@RequestBody(required=true) SampleOrderMasterVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", sampleOrderService.getVocInfo(param.getVactIdxx()));
	}

	/**
	 * 인수증등록
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/regSampleOrderFile.json")
	public Map regSampleOrderFile(@RequestBody(required=true) SampleOrderMasterVO param) throws Exception {
		sampleOrderService.regSampleOrderFile(param);
		return JsonResponse.asSuccess("success", "저장 되었습니다.");
	}


}
