package com.lgmma.salesPortal.app.service;
import java.util.List;

import com.lgmma.salesPortal.app.model.StatisticsCustSuppVO;
import com.lgmma.salesPortal.app.model.StatisticsOrderVO;



public interface StatisticsService {

	List<StatisticsOrderVO> getStatOrderList(StatisticsOrderVO param) throws Exception;
	
	List<StatisticsOrderVO> getStatOrderView(StatisticsOrderVO param) throws Exception;
	
	List<StatisticsCustSuppVO> getStatCustSuppList(StatisticsCustSuppVO param) throws Exception;
	
	List<StatisticsCustSuppVO> getStatCustSuppView(StatisticsCustSuppVO param) throws Exception;
	
	List<StatisticsCustSuppVO> getStatCustSuppDetail(StatisticsCustSuppVO param) throws Exception;
	
	
	
}
