package com.lgmma.salesPortal.app.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.HttpLogDao;
import com.lgmma.salesPortal.common.model.LogVO;

@Repository
public class HttpLogDaoImpl implements HttpLogDao {

	private static final String MAPPER_NAMESPACE = "HttpLogMapper.";
	
	@Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public void createLog(LogVO logVo) {
		sqlSession.insert(MAPPER_NAMESPACE + "createLog", logVo);
	}

}
