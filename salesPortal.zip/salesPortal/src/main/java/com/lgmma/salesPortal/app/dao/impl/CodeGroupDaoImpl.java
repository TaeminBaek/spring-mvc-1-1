 package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.CodeGroupDao;
import com.lgmma.salesPortal.app.model.CodeGroupVO;

@Repository
public class CodeGroupDaoImpl implements CodeGroupDao{
	
	private static final String MAPPER_NAMESPACE = "CODEGROUP_MAPPER.";
	
	 @Autowired(required=true)
	    protected SqlSession sqlSession;

	 @Override
		public int getCodeGroupCount(CodeGroupVO param) {
		 return sqlSession.selectOne(MAPPER_NAMESPACE + "getCodeGroupCount", param);
		}
	 
	@Override
	public List<CodeGroupVO> getCodeGroupList(CodeGroupVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCodeGroup", param);
	}

	@Override
	public void updateCodeGroup(CodeGroupVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateCodeGroup", param);
		
	}

	@Override
	public void createCodeGroup(CodeGroupVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createCodeGroup", param);
		
	}


	

	
	

}
