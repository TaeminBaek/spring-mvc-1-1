 package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.model.CompCreditVO;
import com.lgmma.salesPortal.app.model.CompDamboVO;
import com.lgmma.salesPortal.app.model.CompEtcSaleYearVO;
import com.lgmma.salesPortal.app.model.CompOrganEditVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.NewCompOrganEditVO;
import com.lgmma.salesPortal.app.model.OrganVO;
import com.lgmma.salesPortal.app.model.GenVocVO;

@Repository
public class CompanyDaoImpl implements CompanyDao {
	
	private static final String MAPPER_NAMESPACE = "COMPANY_MAPPER.";
		
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public List<String> getKunnr(String param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getKunnr", param);
	}

	@Override
	public int getCompanyCount(CompanyVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCompanyCount", param);
	}

	@Override
	public List<CompanyVO> getCompanyList(CompanyVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCompanyList", param);
	}

	@Override
	public CompanyVO getCompanyDetail(CompanyVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCompanyDetail", param);
	}

	@Override
	public void updateCompany(CompanyVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateCompany", param);
	}
	
	@Override
	public OrganVO getCompanyEtc(OrganVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCompanyEtc", param);
	}
	
	@Override
	public List<CompEtcSaleYearVO> getCompanyEtcSaleYearList(OrganVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCompanyEtcSaleYearList", param);
	}
	
	@Override
	public int getCompanyEtcKunnrCount(OrganVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCompanyEtcKunnrCount", param);
	}
	
	@Override
	public void updateEtc(OrganVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateEtc", param);
	}
	
	@Override
	public void createEtcAddOrg(OrganVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createEtcAddOrg", param);
	}
	
	@Override
	public void deleteEtcSaleYear(OrganVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteEtcSaleYear", param);
	}
	
	@Override
	public void createEtcSaleYear(CompEtcSaleYearVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createEtcSaleYear", param);
	}
	
	@Override
	public int getDamboCount(CompDamboVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDamboCount", param);
	}

	@Override
	public List<CompDamboVO> getDamboList(CompDamboVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDamboList", param);
	}
	
	@Override
	public void updateDambo(CompDamboVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDambo", param);
	}
	
	@Override
	public void createDambo(CompDamboVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDambo", param);
	}
	
	@Override
	public void createDamboHistory(CompDamboVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDamboHistory", param);
	}
	
	@Override
	public List<CompDamboVO> getConfirmDamboList(CompDamboVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getConfirmDamboList", param);
	}
	
	@Override
	public int getCreditCount(CompCreditVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCreditCount", param);
	}

	@Override
	public List<CompCreditVO> getCreditList(CompCreditVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCreditList", param);
	}
	
	@Override
	public int getSampleDocCount(GenVocVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getSampleDocCount", param);
	}

	@Override
	public List<GenVocVO> getSampleDocList(GenVocVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSampleDocList", param);
	}

	@Override
	public void createCredit(CompCreditVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createCredit", param);
	}

	@Override
	public void updateCreditApprId(CompCreditVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateCreditApprId", param);
	}

	@Override
	public void updateCreditApprIdToNull(CompCreditVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateCreditApprIdToNull", param);
	}

	@Override
	public CompCreditVO getCreditDetail(CompCreditVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCreditDetail", param);
	}

	@Override
	public void updateCreditErpStat(CompCreditVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateCreditErpStat", param);
	}

	@Override
	public Long getAddAmntSum(CompanyVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getAddAmntSum", param);
	}

	@Override
	public void updateCredit(CompCreditVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateCredit", param);
	}

	@Override
	public void createCompOrganEdit(CompOrganEditVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createCompOrganEdit", param);
	}

	@Override
	public void updateOrgan(OrganVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateOrgan", param);
	}

	@Override
	public void updateCompOrgEditApprId(CompOrganEditVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateCompOrgEditApprId", param);
	}

	@Override
	public void updateCompOrgEditIdToNull(CompOrganEditVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateCompOrgEditIdToNull", param);
	}

	@Override
	public NewCompOrganEditVO getCompOrganEditDetail(CompOrganEditVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCompOrganEditDetail", param);
	}

	@Override
	public List<NewCompOrganEditVO> getCompOrganEditList(CompOrganEditVO param) {
		//일단 회사코드와 영업조직만 넘겨서 getCompOrganEditDetail 을 사용해보자
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCompOrganEditDetail", param);
	}

	@Override
	public int countOtherOrganExists(Map<String, String> paramMap) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "countOtherOrganExists", paramMap);
	}

	@Override
	public void updateCompEditErpStat(CompOrganEditVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateCompEditErpStat", param);
	}

	@Override
	public void deleteCompOrganEdit(CompOrganEditVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "deleteCompOrganEdit", param);
	}

	@Override
	public void createNewCompOrganEdit(NewCompOrganEditVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createNewCompOrganEdit", param);
	}

	@Override
	public String getName1ByCompCode(String compCode) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getName1ByCompCode", compCode);
	}

	@Override
	public String getCompanyCreditGrade(String stcd2) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCompanyCreditGrade", stcd2);
	}
	
	@Override
	public int getDamboItemListCount(CompDamboVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDamboCount", param);
	}
}
