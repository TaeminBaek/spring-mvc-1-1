package com.lgmma.salesPortal.app.service.impl;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import com.lgmma.salesPortal.app.controller.CommonController;
import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.dao.DirectOrderDao;
import com.lgmma.salesPortal.app.dao.SalePriceMasterDao;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.ItemDeliveryVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;
import com.lgmma.salesPortal.app.service.DirectOrderService;
import com.lgmma.salesPortal.app.service.SalePriceMasterMgmtService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.app.service.SmsService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.model.DDLBItem;
import com.lgmma.salesPortal.common.props.CommissionType;
import com.lgmma.salesPortal.common.props.OrderStatus;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.props.SalePriceMasterPriceListType;
import com.lgmma.salesPortal.common.props.SalePriceMasterSpKind;
import com.lgmma.salesPortal.common.props.SalePriceMasterUnitType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

@Transactional
@Service
public class DirectOrderServiceImpl implements DirectOrderService {

	private final String FNC_SAP_ORDER_LIST = "ZSDE02_DISPLAY_ORDER_STATUS";
	private final String FNC_SAP_CREATE_ORDER = "ZSDE02_CREATE_SALES_ORDER2";
	private final String FNC_SAP_UPDATE_ORDER = "ZSDE02_CHANGE_SALES_ORDER2";
	//납품과 상관없이 주문을 수정하는 RFC (판가월마감, 비고수정 시 사용)
	private final String FNC_SAP_UPDATE_ORDER_SKIP_SHIPMENT = "ZSDE02_CHANGE_SALES_ORDER3";
	private final String FNC_SAP_ORDER_SHIP_LIST = "ZSDE02_SELECT_SHIPMENT";
	private final String FNC_SAP_SEARCH_ORDER       = "ZSDE02_DISPLAY_ORDER_LIST"; // 주문정보 조회

	private static Logger logger = LoggerFactory.getLogger(DirectOrderServiceImpl.class); 

	@Autowired
	private JcoConnector jcoConnector;
    
	@Autowired
	private DirectOrderDao directOrderDao;
	
	@Autowired
	private CompanyDao companyDao;

	@Autowired
    private SalePriceMasterDao salePriceMasterDao;
    
	@Autowired
	private SapSearchService sapSearchService;
	
	@Autowired
	private SalePriceMasterMgmtService salePriceMasterMgmtService;
	
	@Autowired
	private CommonController commonController;

	@Autowired
	private SmsService smsService;
	
	@Override
	public Map createDirectOrder(DirectOrderMasterVO param) {
		param = (DirectOrderMasterVO) StringUtil.nullToEmptyString(param);
		Map rtMap = new HashMap();
		OrderType orderType = OrderType.getOrderType(param.getDocType());
		if(param.getOrderItemList().size() > 0) {
			// orderId 생성(견본은 생성되어서 들어옴)
			if(OrderType.SAMPLE != orderType){
				param.setOrderId(Util.getUUID());
			}

			//판가 사용시 주문 제품의 판가가 유효기간에 존재하는지 확인 하고 납품요청일의 단가로 세팅 (전자상거래는 별도)
			if (orderType == OrderType.MARKETING || orderType == OrderType.OTHERS
					|| orderType == OrderType.QUANTITY_ADJUST_MINUS || orderType == OrderType.QUANTITY_ADJUST_PLUS
					|| orderType == OrderType.RETURNS_INBOUND || orderType == OrderType.SPECIAL_PRICE) {
				checkPriceExists(param);
			}
			
			// 먼저 저장처리
			creSaveDirectOrder(param);

			// 저장 완료후 erp 전송
			rtMap = (HashMap) createOrderSendToErp(param);
			boolean isSuccess = (boolean) rtMap.get("isSuccess");
			String message = (String) rtMap.get("message");

			if(isSuccess) {
				// 전송완료되면 vbeln 저장
				param.setVbeln((String) rtMap.get("vbeln"));
				directOrderDao.updateErpOrderId(param);
			} else {
				ServiceException se = new ServiceException();
				se.setErrorMsg("ERP : " + message);
				throw se;
			}
		}
		return rtMap;
	}

	private void checkPriceExists(DirectOrderMasterVO param) {
		for(DirectOrderItemVO item : param.getOrderItemList()) {
			SalePriceMasterVO priceVo = new SalePriceMasterVO();
			priceVo.setVkorg(param.getSalesOrg());
			priceVo.setVtweg(param.getDistrChan());
			priceVo.setKunnr(param.getPartnNumbAg());
			if(param.getPartnerYn().equals("Y") && !param.getPartnNumbZ7().equals("")) {	//파트너사 이면서 실제인도처로 판가를 찾을때
				priceVo.setSpTypeKind(SalePriceMasterSpKind.SP_TYPE_KIND_PATNR.getCode());
				priceVo.setSpType(param.getPartnNumbZ7());
			} else {
				priceVo.setSpTypeKind(SalePriceMasterSpKind.SP_TYPE_KIND_PLTYP.getCode());
				priceVo.setSpType(item.getPriceListI());
			}
			priceVo.setIndoKunnr(param.getPartnNumbWe());
			priceVo.setMatnr(item.getMaterial());
			priceVo.setKmein(item.getCondUnit());
			priceVo.setKonwa(item.getCurrency());
			priceVo.setFullMatchYn("Y");
			priceVo.setSearchDate(StringUtil.remove(param.getReqDateH(), '.'));
			priceVo.setStart(0);
			priceVo.setPageSize(10);
			List<SalePriceMasterVO> priceList = salePriceMasterDao.getsalePriceMasterList(priceVo);

			StringBuffer message = new StringBuffer();
			message.append("제품코드 " + item.getMaterial()+ " 의 단가가\n")
			.append("유통경로 " + param.getSalesOrg()+ " 의\n")
			.append("인도처 " + param.getPartnNumbWe()+ " 의\n")
			.append(SalePriceMasterSpKind.getSalePriceMasterSpKind(priceVo.getSpTypeKind()).getName() + " 의\n");
			if(SalePriceMasterSpKind.getSalePriceMasterSpKind(priceVo.getSpTypeKind()) == SalePriceMasterSpKind.SP_TYPE_KIND_PATNR) {
				message.append("실제인도처 " + param.getPartnNumbZ7() + " 의\n");
			} else {
				message.append(SalePriceMasterPriceListType.getSalePriceMasterPriceListType(priceVo.getSpType()).getName() + " 의\n");
			}
			message.append("단위 " + SalePriceMasterUnitType.getSalePriceMasterUnitType(priceVo.getKmein()).getName() + " 의\n")
			.append("통화 " + item.getCurrency() + " 의\n")
			.append("납품요청일 " + param.getReqDateH()+ " 의 유효기간내에 존재하지 않습니다.\n");

			if(priceList.size() == 0) {
				ServiceException se = new ServiceException();
				se.setErrorMsg(message.toString());
				throw se;
			} else {
				//납품요청일의 단가로
				item.setPr00Price(priceList.get(0).getPrice());
			}
		}
	}

	/**
	 * 주문테이블 저장
	 * @param param
	 */
	@Override
	public void creSaveDirectOrder(DirectOrderMasterVO param){
//			param.setOrdReason(param.getOrdReason().equals("") ? "100" : param.getOrdReason());
		param.setReqDateH(StringUtil.remove(param.getReqDateH(), '.'));
		param.setZdptbg(StringUtil.remove(param.getZdptbg(), '.'));
		param.setPriceDate(param.getReqDateH());
		param.setDocDate(Util.getToday());
		if(param.getLiablilityYn().equals("")) {
			param.setLiablilityYn("N");
		}
		if(param.getPurchNoC().equals("")) {
			param.setPurchNoC(makePurchNo(param.getDocType()));
		}
		//현재 영업담당으로 적용
		CompanyVO company = new CompanyVO();
		company.setCompCode(param.getCompCode());
		company.setVkorg(param.getSalesOrg());
		company = companyDao.getCompanyDetail(company);
		if(param.getPartnNumbVe() == null || param.getPartnNumbVe().equals("")) {
			param.setPartnNumbVe(company.getOrganVO().getSaleMan1());
		}
		/*param.setPartnNumbVe(company.getOrganVO().getSaleMan1());*/
		// 마스터 테이블 저장
		directOrderDao.createDirectOrderMaster(param);
		// 아이템 테이블 저장
		createDirectOrderItems(param);
	}

	/**
	 * 주문 item 저장처리
	 * @param param
	 */
	private void createDirectOrderItems(DirectOrderMasterVO param) {
		int i = 0;
		for(DirectOrderItemVO item : param.getOrderItemList()) {
			i++;
			item.setOrderId(param.getOrderId());
			item.setSeq(i * 10);
			item.setCondPUnt(1);
			item.setReqDate(param.getReqDateH());
			item.setRegiIdxx(param.getRegiIdxx());
			item.setUpdtIdxx(param.getUpdtIdxx());
			if(StringUtil.isNullToString(item.getHighValueYn()).equals("")) {
				item.setHighValueYn("N");
			}
			directOrderDao.createDirectOrderItem(item);
		}
	}

	/**
	 * 주문생성 erp 전송
	 * @param param
	 * @return
	 */
	public Map createOrderSendToErp(DirectOrderMasterVO param){

		Map<String, Object> inputParams = new HashMap<String, Object>();
		inputParams.put("I_PERSNO", param.getRegiIdxx());

		Map<String, Object> header = new HashMap<String, Object>(); //주문헤더
		header.put("DOC_TYPE", param.getDocType());
		header.put("ORD_REASON", param.getOrdReason());
		header.put("BILL_BLOCK", param.getBillBlock());
		header.put("SALES_ORG", param.getSalesOrg());
		header.put("DISTR_CHAN", param.getDistrChan());
		header.put("DIVISION", param.getDivision());
		header.put("REQ_DATE_H", param.getReqDateH());
		header.put("PRICE_DATE", param.getReqDateH());
		header.put("SHIP_COND", param.getShipCond());
		header.put("PURCH_NO_C", param.getPurchNoC());	//TB_ORDER_MASTER_SEQ
		header.put("DOC_DATE", Util.getToday());
		header.put("INCOTERMS1", param.getIncoterms1());
		header.put("INCOTERMS2", param.getIncoterms2());
		header.put("AUART_T", OrderType.getOrderType(param.getDocType()).getName());
		header.put("PMNTTRMS", param.getPmnttrms());
		header.put("ASS_NUMBER", param.getAssNumber());
		header.put("ACCNT_ASGN", param.getAccntAsgn());
		header.put("SALES_OFF", param.getVkbur());
//		header.put("PRICE_LIST", param.getPriceList());	item 으로 이동
		inputParams.put("ORDER_HEADER", header);

		Map<String, Object> booking = new HashMap<String, Object>(); //주문부킹
		booking.put("ZZROUTE", param.getZzroute());
		booking.put("ZBKQ_YN", param.getZbkqYn().equals("") ? "N" : param.getZbkqYn());
		booking.put("ZZLAND1", param.getZland1());
		booking.put("ZZTRNS_WAY1", param.getZztrnsWay1());
		booking.put("ZZTRNS_WAY2", param.getZztrnsWay2());
		booking.put("ZZTRNS_QTY1", param.getZztrnsQty1());
		booking.put("ZZTRNS_QTY2", param.getZztrnsQty2());
		booking.put("ZDPTBG", param.getZdptbg());
		inputParams.put("ORDER_BOOKING", booking);
		
		JcoTableParam tableParam = new JcoTableParam();

		// ORDER_PARTNER set
		List partners = new ArrayList();
		setErpPartnAg(param, partners);
		setErpPartnWe(param, partners);
		setErpPartnZ4(param, partners);
		setErpPartnZ6(param, partners);
		setErpPartnZ7(param, partners);
		setErpPartnVe(param, partners);

		tableParam.put("ORDER_PARTNER", partners);

		List itemList = new ArrayList();
		List itemPriceList = new ArrayList();
		Map itemMap = new HashMap();
		Map itemPriceMap = new HashMap();
		if(!param.getCondType().equals("")) {	//수출커미션
/*			itemMap.put("ITM_NUMBER", "00");//주문아이템 순차번호
			itemMap.put("UPDATEFLAG", "U");
			itemMap.put("REQ_QTY", 0);
			itemList.add(itemMap);
*/
			itemPriceMap.put("ITM_NUMBER", "00");//주문아이템 순차번호
			itemPriceMap.put("COND_TYPE", param.getCondType());
			itemPriceMap.put("COND_VALUE", param.getCondValue());
			itemPriceMap.put("UPDATEFLAG", "U");
			itemPriceList.add(itemPriceMap);
		}

		for(DirectOrderItemVO item : param.getOrderItemList()){
			itemMap = new HashMap();
			itemPriceMap = new HashMap();
			itemMap.put("ITM_NUMBER", item.getSeq()+"");//주문아이템 순차번호
			itemMap.put("MATERIAL", item.getMaterial());
			itemMap.put("PLANT", item.getPlant());
			itemMap.put("STORE_LOC", item.getStoreLoc());
			itemMap.put("REQ_DATE", param.getReqDateH());
			itemMap.put("REQ_QTY", item.getReqQty());
			itemMap.put("PURCH_NO_C", param.getPurchNoC());
			itemMap.put("REASON_REJ", param.getReasonRej());
			itemMap.put("PRICE_LIST_I", item.getPriceListI());

			itemList.add(itemMap);

			itemPriceMap = new HashMap();
			itemPriceMap.put("ITM_NUMBER", item.getSeq()+"");//주문아이템 순차번호
			itemPriceMap.put("MATERIAL", item.getMaterial());
			if (param.getDocType().equals(OrderType.MARKETING.getCode())
					|| param.getDocType().equals(OrderType.EXPORT.getCode())
					|| param.getDocType().equals(OrderType.ESALES.getCode())
					|| param.getDocType().equals(OrderType.RETURNS_INBOUND.getCode())
					|| param.getDocType().equals(OrderType.QUANTITY_ADJUST_MINUS.getCode())
					|| param.getDocType().equals(OrderType.QUANTITY_ADJUST_PLUS.getCode())
					|| param.getDocType().equals(OrderType.SALES_LOSS.getCode())
					|| param.getDocType().equals(OrderType.SALES_SURPLUS.getCode())
					|| param.getDocType().equals(OrderType.OTHERS.getCode())
					|| param.getDocType().equals(OrderType.SPECIAL_PRICE.getCode())) {
				itemPriceMap.put("COND_TYPE", "PR00");
				itemPriceMap.put("COND_VALUE", item.getPr00Price());
			}
			itemPriceMap.put("CURRENCY", item.getCurrency());
			itemPriceMap.put("COND_UNIT", item.getCondUnit());
			itemPriceMap.put("COND_P_UNT", item.getCondPUnt());
			itemPriceList.add(itemPriceMap);
		}
		tableParam.put("ORDER_ITEMS", itemList);
		tableParam.put("ORDER_ITEM_PRICE", itemPriceList);

		//출하담당 비고
		Iterable<String> ite = Splitter.fixedLength(65).split(StringUtil.replace(StringUtil.replace(param.getBigoZ002(), "\r", ""), "\n", " "));
		String[] cdepComments = Iterables.toArray(ite, String.class);

		List<Map> commentList = new ArrayList<Map>();
		setErpOrderTextCdep(cdepComments, commentList);

		//견본 비고
		ite = Splitter.fixedLength(65).split(StringUtil.replace(StringUtil.replace(param.getBigoZ025(), "\r", ""), "\n", " "));
		String[] sampleComments = Iterables.toArray(ite, String.class);
		setErpOrderTextSample(commentList, sampleComments);

		//고객 PO
		ite = Splitter.fixedLength(65).split(StringUtil.replace(StringUtil.replace(param.getBigoZ012(), "\r", ""), "\n", " "));
		String[] custpoComments = Iterables.toArray(ite, String.class);
		setErpOrderTextCustpo(commentList, custpoComments);

		//거래명세 (전자상거래 주문에서만 사용)
		ite = Splitter.fixedLength(65).split(StringUtil.replace(StringUtil.replace(param.getBigoZ001(), "\r", ""), "\n", " "));
		String[] esaleComments = Iterables.toArray(ite, String.class);
		setErpOrderTextEsale(commentList, esaleComments);
		
		if(commentList.size() > 0) {
			tableParam.put("ORDER_TEXT", commentList);
		}

		jcoConnector.executeFunction(FNC_SAP_CREATE_ORDER, inputParams, tableParam);

		List<Map> resultList = (List<Map>) tableParam.get("RETURN");
		Map rtMap = isSuccessSendErp(param, resultList);
		return rtMap;
	}

	/**
	 * erp 전송결과처리
	 * @param param
	 * @param resultList
	 * @param isSuccess
	 * @param message
	 * @return
	 */
	private Map isSuccessSendErp(DirectOrderMasterVO param, List<Map> resultList) {
		Map rtMap = new HashMap();
		rtMap.put("isSuccess", true);
		String vbeln = "";
		StringBuffer message = new StringBuffer();
		for(Map result : resultList) {
			String id = StringUtil.nullConvert(result.get("ID"));
			String number = StringUtil.nullConvert(result.get("NUMBER"));
			String type = StringUtil.nullConvert(result.get("TYPE"));

			if(type.equals("E")) {
				logger.error(result.get("MESSAGE").toString());
				message.append(result.get("MESSAGE").toString().trim() + "\n");
				rtMap.put("isSuccess", false);
				rtMap.put("message", message.toString());
				rtMap.put("vbeln", "");
			} else if(id.equals("V1") && number.equals("311")){//V1,311인 경우만 주문확정이 된 상태임 황영안과장.
				//erp id 가 10자리가 아닌경우 10자리를 만든다.
				vbeln = StringUtils.leftPad(result.get("MESSAGE_V2").toString().trim(), 10, "0");
//				param.setVbeln(vbeln);
				rtMap.put("message", "");
				rtMap.put("vbeln", vbeln);
			}
		}
		return rtMap;
	}

	private void setErpOrderTextEsale(List<Map> commentList, String[] custpoComments) {
		setErpOrderText(custpoComments,commentList,"Z001");
	}
	private void setErpOrderTextCustpo(List<Map> commentList, String[] custpoComments) {
		setErpOrderText(custpoComments,commentList,"Z012");
	}
	private void setErpOrderTextSample(List<Map> commentList, String[] sampleComments) {
		setErpOrderText(sampleComments,commentList,"Z025");
	}
	private void setErpOrderTextCdep(String[] cdepComments, List<Map> commentList) {
		setErpOrderText(cdepComments,commentList,"Z002");
	}
	private void setErpOrderText(String[] comments,List<Map> commentList,String key) {
		if(!comments.equals("")) {
			for(String comment : comments) {
				Map<String, String> commentMap = new HashMap<String, String>();
				commentMap.put("TEXT_ID", key);
				commentMap.put("TEXT_LINE", comment);
				commentList.add(commentMap);
			}
		}
	}

	private void setErpPartnVe(DirectOrderMasterVO param, List partners) {
		Map<String, Object> saleMan;
		if(!param.getPartnNumbVe().equals("") ) {
			saleMan = new HashMap<String, Object>();//실제인도처
			saleMan.put("SALES_ORG", param.getSalesOrg());
			saleMan.put("PARTN_ROLE", "VE");
			saleMan.put("PARTN_NUMB", param.getPartnNumbVe());
			partners.add(saleMan);
		}
	}

	private void setErpPartnZ7(DirectOrderMasterVO param, List partners) {
		Map<String, Object> realDelyComp;
		if(!param.getPartnNumbZ7().equals("") ) {
			realDelyComp = new HashMap<String, Object>();//실제인도처
			realDelyComp.put("SALES_ORG", param.getSalesOrg());
			realDelyComp.put("PARTN_ROLE", "Z7");
			realDelyComp.put("PARTN_NUMB", param.getPartnNumbZ7());
			partners.add(realDelyComp);
		}
	}
	
	private void setErpPartnZ6(DirectOrderMasterVO param, List partners) {
		Map<String, Object> exCoComp;
		if(!param.getPartnNumbZ6().equals("") ) {
			exCoComp = new HashMap<String, Object>();//수출커미션
			exCoComp.put("SALES_ORG", param.getSalesOrg());
			exCoComp.put("PARTN_ROLE", "Z6");
			exCoComp.put("PARTN_NUMB", param.getPartnNumbZ6());
			partners.add(exCoComp);
		}
	}

	private void setErpPartnZ4(DirectOrderMasterVO param, List partners) {
		Map<String, Object> forwComp;
		if(!param.getPartnNumbZ4().equals("") ) {
			forwComp = new HashMap<String, Object>();//포워더
			forwComp.put("SALES_ORG", param.getSalesOrg());
			forwComp.put("PARTN_ROLE","Z4");
			forwComp.put("PARTN_NUMB", param.getPartnNumbZ4());
			forwComp.put("NAME", param.getPartnNumbZ4Name());
			forwComp.put("STREET", param.getPartnNumbZ4Empnm());
			forwComp.put("TELEPHONE", param.getPartnNumbZ4Telephone());
			partners.add(forwComp);
		}
	}

	private void setErpPartnWe(DirectOrderMasterVO param, List partners) {
		Map<String, Object> delyComp;
		if(!param.getPartnNumbWe().equals("") ) {
			delyComp = new HashMap<String, Object>();//인도처
			delyComp.put("SALES_ORG", param.getSalesOrg());
			delyComp.put("PARTN_ROLE","WE");
			delyComp.put("PARTN_NUMB", param.getPartnNumbWe());
			delyComp.put("UNLOAD_PT", param.getUnloadPt());
			partners.add(delyComp);
		}
	}

	private void setErpPartnAg(DirectOrderMasterVO param, List partners) {
		Map<String, Object> saleComp;
		if(!param.getPartnNumbAg().equals("") ) {
			saleComp = new HashMap<String, Object>();//판매처
			saleComp.put("SALES_ORG", param.getSalesOrg());
			saleComp.put("PARTN_ROLE", "AG");
			saleComp.put("PARTN_NUMB", param.getPartnNumbAg());
			if(param.getDocType() == OrderType.CY_EXPORT_SHIP.getCode() || param.getDocType() == OrderType.SHIPPING.getCode()) {
				saleComp.put("UNLOAD_PT", param.getPartnNumbAg());
			}
			partners.add(saleComp);
		}
	}

	@Override
	public String makePurchNo(String docType) {
//		return Util.getToday() + "_" + docType + "_" + StringUtils.leftPad(directOrderDao.getPurchNoSeq() + "", 8, '0');
		return Util.getToday() + "_" + StringUtils.leftPad(directOrderDao.getPurchNoSeq() + "", 7, '0');
	}

	@Override
	public int getDirectOrderMasterItemListCount(DirectOrderMasterVO param) {
		return directOrderDao.getDirectOrderMasterItemListCount(param);
	}

	@Override
	public List<DirectOrderMasterVO> getDirectOrderMasterItemList(DirectOrderMasterVO param) {
		List<DirectOrderMasterVO> masterList = directOrderDao.getDirectOrderMasterItemList(param);
		for(DirectOrderMasterVO master : masterList) {
			master = (DirectOrderMasterVO) StringUtil.nullToEmptyString(master);
			setOrderDetailCodeText(master);
			master.setSalesOrgText(master.getSalesOrgText().split("]")[1]); //영업조직
			master.setDistrChanText(master.getDistrChanText().split("]")[1]); //유통경로
			
			CommonCodeVO commonCodeVO = new CommonCodeVO();
			
			if(master.getHighValue() != "") {
				if(master.getSalesOrg().equals("1000")){
					commonCodeVO.setGrupCode("HVALUEMMA");	
				} else if(master.getSalesOrg().equals("3000")) {
					commonCodeVO.setGrupCode("HVALUEPMMA");
				}
				
				try {
					for(DDLBItem codeItem : (List<DDLBItem>)commonController.getCode(commonCodeVO).get("items")) {
						if(codeItem.getCode().equals(master.getHighValue())) {
							master.setHighValueText("["+master.getHighValue()+"]"+codeItem.getText());
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
	
			
			if(!master.getPriceList().equals("")) //가격리스트구분
				master.setPriceListText("["+master.getPriceList()+"]"+SalePriceMasterPriceListType.getSalePriceMasterPriceListType(master.getPriceList()).getName());
			if(!StringUtil.isNullToString(master.getCondUnit()).equals("")) //단위
				master.setCondUnitText(SalePriceMasterUnitType.getSalePriceMasterUnitType(master.getCondUnit()).getName());
			if(!StringUtil.isNullToString(master.getPlant()).equals("")) //플랜트
				master.setPlantText("["+master.getPlant()+"]" + sapSearchService.getMasterCodeName("04", master.getPlant()));
			if(!StringUtil.isNullToString(master.getStoreLoc()).equals("")) //저장위치
				master.setStoreLocText("["+master.getStoreLoc()+"]" + sapSearchService.getMasterCodeName("15", master.getStoreLoc()));
		}
		//화면에서 넘어온 조회조건이 아닌 조회된 데이터 셋의 확정일 from - to 로 rfc조회범위를 좁힌다.
		//해당 rfc의 일자는 필수
//		setSapOrderStatus(param, masterList, setDateCondition(masterList));
//		setSapOrderStatus(param, masterList, new String[]{param.getSdate(), param.getEdate()});
		//검색조건 출하일자 +-1개월
//		setSapOrderStatus(param, masterList, new String[]{DateUtil.addYearMonthDay(param.getSdate(), 0, -1, 0), DateUtil.addYearMonthDay(param.getEdate(), 0, 1, 0)});
		if(masterList.size() > 0)
			setSapOrderStatus(param, masterList, setDateCondition(masterList));

		return masterList;
	}


	private void setSapOrderStatus(DirectOrderMasterVO param, List<DirectOrderMasterVO> orderList, String[] dateFromTo) {
		String tempOrderId = "";
		for(DirectOrderMasterVO orderVO : orderList) {
			if(orderVO.getVbeln() != null && !orderVO.getVbeln().equals("")) {
				if(!tempOrderId.equals(orderVO.getVbeln())) { //order id 당 한번씩만 rfc 호출하도록
					tempOrderId = orderVO.getVbeln();
					JcoTableParam tableParam = new JcoTableParam();
					Map<String, Object> inputParams = new HashMap<String, Object>();
					Map<String, Object> erpOrderIdMap = new HashMap<String, Object>();
					List<Map<String, String>> itemList =new ArrayList<>();

					if (!orderVO.getSalesOrg().equals("")) {
						inputParams.put("I_VKORG", orderVO.getSalesOrg());
					}
					inputParams.put("I_GUBUN", "W");
/*
 * rfc 에서 판매처를 넘기면 조회 안됨
					//검색조건 으로부터 판매처를 설정
					if(param.getCompCode() != null && !param.getCompCode().equals("")) {
						Map<String, String> saleComp = new HashMap<String, String>();
						saleComp.put("SIGN", "I");
						saleComp.put("OPTION", "EQ");
						saleComp.put("LOW", param.getCompCode());
						saleComp.put("HIGH", null);
						tableParam.put("CUSTOMERRANGE", saleComp);
					}
					
					//검색조건 으로부터 인도처를 설정
					if(param.getJindIdxx() != null && !param.getJindIdxx().equals("")) {
						Map<String, String> deliverComp = new HashMap<String, String>();
						deliverComp.put("SIGN", "I");
						deliverComp.put("OPTION", "EQ");
						deliverComp.put("LOW", param.getJindIdxx());
						deliverComp.put("HIGH", null);
						tableParam.put("KUNNRRANGE", deliverComp);
					}
					
					//검색된 데이터셑 에서 제품코드 설정
					if(param.getJindIdxx() != null && !param.getJindIdxx().equals("")) {	//검색을 하였으면
						for(OrderListVO itemVO : orderList) {
							Map<String, String> orderItem = new HashMap<String, String>();
							orderItem.put("SIGN", "I");
							orderItem.put("OPTION", "EQ");
							orderItem.put("LOW", itemVO.getJproIdxx());
							orderItem.put("HIGH", null);
							itemList.add(orderItem);
						}
						tableParam.put("MATNRRANGE", itemList);
					}
*/
					erpOrderIdMap.put("SIGN", "I");
					erpOrderIdMap.put("OPTION", "EQ");
					erpOrderIdMap.put("LOW", tempOrderId);
					tableParam.put("VBELNRANGE", erpOrderIdMap);

					//조회된 목록의 주문일자로 FROM - TO 설정
					Map<String, Object> dateParamMap = new HashMap<String, Object>();
					dateParamMap.put("SIGN","I");
					dateParamMap.put("OPTION", "BT");
					dateParamMap.put("LOW", dateFromTo[0]);
					dateParamMap.put("HIGH", dateFromTo[1]);
					tableParam.put("DATERANGE", dateParamMap);

					jcoConnector.executeFunction(FNC_SAP_ORDER_LIST, inputParams, tableParam);
					//sapOrderList
					List<Map<String, Object>> sapOrderList = (List) tableParam.get("T_LIST");
					//출불사유
					List<Map<String, Object>> sapOrderText = (List) tableParam.get("T_TEXT");
					
					for(Map<String, Object> sapOrder : sapOrderList) {
						for(DirectOrderMasterVO innerOrderVO : orderList) {
							if(sapOrder.get("VBELN").equals(innerOrderVO.getVbeln())) {
								innerOrderVO.setProcStat(sapOrder.get("WBSTK") + "");
								innerOrderVO.setProcStatText(OrderStatus.getStatus(sapOrder.get("WBSTK") + "").getName());
//								innerOrderVO.setLfimg(sapOrder.get("LFIMG") + "");
							}
						}
					}
/*					for(Map<String, Object> sapOrder : sapOrderText) {
						for(DirectOrderMasterVO innerOrderVO : orderList) {
							if(sapOrder.get("VBELN").equals(innerOrderVO.getVbeln()) && innerOrderVO.getErpxSubx().equals(sapOrder.get("ITM_NUMBER"))) {
								innerOrderVO.setRejectReason(sapOrder.get("TEXT_LINE") + "");
							}
						}
					}
*/				}
			}
		}
	}

	private String[] setDateCondition(List<DirectOrderMasterVO> orderList) {
		String fromDate = "";
		String toDate ="";
		for(DirectOrderMasterVO orderVO : orderList) {
			if(orderVO.getDocDate() != null && !orderVO.getDocDate().equals("")) {
				fromDate = StringUtils.remove(orderVO.getDocDate(), '.');
				toDate = StringUtils.remove(orderVO.getDocDate(), '.');
				break;
			}
		}
		for(DirectOrderMasterVO orderVO : orderList) {
			if(orderVO.getDocDate() != null && !orderVO.getDocDate().equals("")) {
				if(Integer.parseInt(fromDate) > Integer.parseInt(StringUtils.remove(orderVO.getDocDate(), '.'))) {
					fromDate = StringUtils.remove(orderVO.getDocDate(), '.');
				}
				if(Integer.parseInt(toDate) < Integer.parseInt(StringUtils.remove(orderVO.getDocDate(), '.'))) {
					toDate = StringUtils.remove(orderVO.getDocDate(), '.');
				}
			}
		}
		// +- 1월로 검색범위 확대
		return new String[] {DateUtil.addYearMonthDay(fromDate, 0, -1, 0), DateUtil.addYearMonthDay(toDate, 0, 1, 0)};
//		return new String[] {fromDate, toDate};
	}

	@Override
	public List<ItemDeliveryVO> getOrderDeliveryInfo(String orderId) {
		DirectOrderMasterVO orderMasterVO = getDirectOrderDetail(orderId);
		return getOrderItemDeliveryList(orderMasterVO);
	}
	@Override
	public DirectOrderMasterVO getDirectOrderDetail(String orderId) {
		DirectOrderMasterVO orderMasterVO = new DirectOrderMasterVO();
		orderMasterVO.setOrderId(orderId);
		orderMasterVO.setPageSize(1);
		orderMasterVO.setrIndex(10);
		orderMasterVO = (DirectOrderMasterVO) StringUtil.nullToEmptyString(directOrderDao.getDirectOrderDetail(orderMasterVO));
		orderMasterVO.setOrderItemList(directOrderDao.getDirectOrderItemList(orderId));

		setOrderDetailCodeText(orderMasterVO);

		return orderMasterVO;
	}

	@Override
	public void setOrderDetailCodeText(DirectOrderMasterVO orderMasterVO){
		if(!orderMasterVO.getSalesOrg().equals(""))
			orderMasterVO.setSalesOrgText("["+orderMasterVO.getSalesOrg()+"]" + Vkorg.getVkorg(orderMasterVO.getSalesOrg()).getName());
		if(!orderMasterVO.getDistrChan().equals(""))
			orderMasterVO.setDistrChanText("["+orderMasterVO.getDistrChan()+"]" + sapSearchService.getMasterCodeName("24", orderMasterVO.getDistrChan()));
		if(!orderMasterVO.getDivision().equals(""))
			orderMasterVO.setDivisionText("["+orderMasterVO.getDivision()+"]" + sapSearchService.getMasterCodeName("05", orderMasterVO.getDivision()));
		if(!orderMasterVO.getPmnttrms().equals(""))
			orderMasterVO.setPmnttrmsText("["+orderMasterVO.getPmnttrms()+"]" + sapSearchService.getMasterCodeName("28", orderMasterVO.getPmnttrms()));
		if(!orderMasterVO.getIncoterms1().equals(""))
			orderMasterVO.setIncoterms1Text("["+orderMasterVO.getIncoterms1()+"]" + sapSearchService.getMasterCodeName("30", orderMasterVO.getIncoterms1()));
		if(!orderMasterVO.getShipCond().equals(""))
			orderMasterVO.setShipCondText("["+orderMasterVO.getShipCond()+"]" + sapSearchService.getMasterCodeName("23", orderMasterVO.getShipCond()));
		if(!orderMasterVO.getOrdReason().equals(""))
			orderMasterVO.setOrdReasonText("["+orderMasterVO.getOrdReason()+"]" + sapSearchService.getMasterCodeName("22", orderMasterVO.getOrdReason()));
		if(!orderMasterVO.getPartnNumbZ6().equals(""))
			orderMasterVO.setPartnNameZ6("["+orderMasterVO.getPartnNumbZ6()+"]" + sapSearchService.getMasterCodeName("36", orderMasterVO.getPartnNumbZ6()));
		if(!orderMasterVO.getPartnNumbZ4().equals(""))
			orderMasterVO.setPartnNameZ4("["+orderMasterVO.getPartnNumbZ4()+"]" + sapSearchService.getMasterCodeName("35", orderMasterVO.getPartnNumbZ4()));
		if(!orderMasterVO.getAccntAsgn().equals(""))
			orderMasterVO.setAccntAsgnText("["+orderMasterVO.getAccntAsgn()+"]" + sapSearchService.getMasterCodeName("08", orderMasterVO.getAccntAsgn()));
		if(!orderMasterVO.getZzroute().equals(""))
			orderMasterVO.setZzrouteText("["+orderMasterVO.getZzroute()+"]" + sapSearchService.getMasterCodeName("31", orderMasterVO.getZzroute()));
		if(!orderMasterVO.getZland1().equals(""))
			orderMasterVO.setZland1Text("["+orderMasterVO.getZland1()+"]" + sapSearchService.getMasterCodeName("37", orderMasterVO.getZland1()));
		if(!orderMasterVO.getZztrnsWay1().equals(""))
			orderMasterVO.setZztrnsWay1Text("["+orderMasterVO.getZztrnsWay1()+"]" + sapSearchService.getMasterCodeName("33", orderMasterVO.getZztrnsWay1()));
		if(!orderMasterVO.getZztrnsWay2().equals(""))
			orderMasterVO.setZztrnsWay2Text("["+orderMasterVO.getZztrnsWay2()+"]" + sapSearchService.getMasterCodeName("33", orderMasterVO.getZztrnsWay2()));
		if(!orderMasterVO.getUnloadPt().equals(""))
			orderMasterVO.setUnloadPtText("["+orderMasterVO.getUnloadPt()+"]" + sapSearchService.getMasterCodeName("15", orderMasterVO.getUnloadPt()));
		if(!orderMasterVO.getCondType().equals(""))
			orderMasterVO.setCondTypeText("["+orderMasterVO.getCondType()+"]" + (CommissionType.getCommission(orderMasterVO.getCondType()) == null ? "" : CommissionType.getCommission(orderMasterVO.getCondType()).getText()));

		// 견본에서 orderItemList 없이 조회
		if(orderMasterVO.getOrderItemList() != null){
			for(DirectOrderItemVO orderItemVO : orderMasterVO.getOrderItemList()) {
				if(!orderMasterVO.getPriceList().equals(""))
					orderItemVO.setPltypName(SalePriceMasterPriceListType.getSalePriceMasterPriceListType(orderMasterVO.getPriceList()).getName());
				if(!StringUtil.isNullToString(orderItemVO.getCondUnit()).equals(""))
					orderItemVO.setCondUnitText(SalePriceMasterUnitType.getSalePriceMasterUnitType(orderItemVO.getCondUnit()).getName());
				if(!StringUtil.isNullToString(orderItemVO.getPlant()).equals(""))
					orderItemVO.setPlantText("["+orderItemVO.getPlant()+"]" + sapSearchService.getMasterCodeName("04", orderItemVO.getPlant()));
				if(!StringUtil.isNullToString(orderItemVO.getStoreLoc()).equals(""))
					orderItemVO.setStoreLocText("["+orderItemVO.getStoreLoc()+"]" + sapSearchService.getMasterCodeName("15", orderItemVO.getStoreLoc()));
			}
		}
	}

	private List<ItemDeliveryVO> getOrderItemDeliveryList(DirectOrderMasterVO orderMasterVO) {
		List<ItemDeliveryVO> itemDeliveryVOList = new ArrayList<ItemDeliveryVO>();

		if(orderMasterVO.getOrderItemList().size() > 0) {
			Map<String, Object> inputParams = new HashMap<String, Object>();
			inputParams.put("I_VKORG", orderMasterVO.getSalesOrg());

			JcoTableParam tableParam = new JcoTableParam();
			List<Map<String, Object>> table =new ArrayList<>();
			
			for(DirectOrderItemVO orderItemVO : orderMasterVO.getOrderItemList()) {
				if(orderMasterVO.getVbeln() != null && !orderMasterVO.getVbeln().equals("")) {
					Map<String, Object> row = new HashMap<String, Object>();
					row.put("VBELN", orderMasterVO.getVbeln());
					row.put("POSNR", orderItemVO.getSeq());
					table.add(row);
				}
			}
			tableParam.put("T_INPUT",table);
			
			jcoConnector.executeFunction(FNC_SAP_ORDER_SHIP_LIST, inputParams, tableParam);
			itemDeliveryVOList = (List<ItemDeliveryVO>) tableParam.get("T_LIST", ItemDeliveryVO.class);
		}

		for(DirectOrderItemVO orderItemVO : orderMasterVO.getOrderItemList()) {
		    float lfimg = 0;
		    for (ItemDeliveryVO itemDeliveryVO : itemDeliveryVOList) {
				if((orderItemVO.getSeq()+"").equals(itemDeliveryVO.getPosnv())){
					itemDeliveryVO.setVtwegName(sapSearchService.getMasterCodeName("24", orderMasterVO.getDistrChan()));
			    	itemDeliveryVO.setVsbedName(sapSearchService.getMasterCodeName("23", orderMasterVO.getShipCond()));
			    	itemDeliveryVO.setAreqDate(orderItemVO.getReqDate());
			    	itemDeliveryVO.setCdepBigo(orderMasterVO.getBigoZ002());
/*			    	itemDeliveryVO.setDealBigo(orderItemVO.getDealBigo());
			    	itemDeliveryVO.setCustBigo(orderItemVO.getCustBigo());
				    lfimg +=  Float.parseFloat(StringUtil.nullConvert(itemDeliveryVO.getLfimg()));
*/				}
		    }
//		    orderItemVO.setLfimg(String.valueOf(lfimg));
		}
	    for (ItemDeliveryVO itemDeliveryVO : itemDeliveryVOList) {
	    	itemDeliveryVO.setWerksName(sapSearchService.getMasterCodeName("04", itemDeliveryVO.getWerks()));
	    	itemDeliveryVO.setLgortName(sapSearchService.getMasterCodeName("15", itemDeliveryVO.getLgort()));
	    }
		return itemDeliveryVOList;
	}

	private Map updateDirectOrder(String rfcName, DirectOrderMasterVO param, boolean updatePrice) {
		param = (DirectOrderMasterVO) StringUtil.nullToEmptyString(param);
		OrderType orderType = OrderType.getOrderType(param.getDocType());
		Map rtMap = null;
		if(param.getOrderItemList().size() > 0) {
			//판가 사용시 주문 제품의 판가가 유효기간에 존재하는지 확인 (전자상거래는 별도)
			if(updatePrice) {
				if (orderType == OrderType.MARKETING || orderType == OrderType.OTHERS
						|| orderType == OrderType.QUANTITY_ADJUST_MINUS || orderType == OrderType.QUANTITY_ADJUST_PLUS
						|| orderType == OrderType.RETURNS_INBOUND || orderType == OrderType.SPECIAL_PRICE) {
					checkPriceExists(param);
				}
			}
//			param.setOrderId(Util.getUUID());
//			param.setOrdReason(param.getOrdReason().equals("") ? "100" : param.getOrdReason());
			param.setReqDateH(StringUtil.remove(param.getReqDateH(), '.'));
			param.setZdptbg(StringUtil.remove(param.getZdptbg(), '.'));
			param.setPriceDate(param.getReqDateH());
//			param.setDocDate(param.getReqDateH());
			if(param.getLiablilityYn().equals("")) {
				param.setLiablilityYn("N");
			}
/*
			if(param.getPurchNoC().equals("")) {
				param.setPurchNoC(makePurchNo(param.getDocType()));
			}
*/
			List<DirectOrderItemVO> oriItems = directOrderDao.getDirectOrderItemList(param.getOrderId());
			directOrderDao.updateDirectOrderMaster(param);
			directOrderDao.deleteDirectOrderItems(param);
			int i = 0;
			for(DirectOrderItemVO item : param.getOrderItemList()) {
				i++;
				item.setOrderId(param.getOrderId());
				item.setSeq(i * 10);
				item.setCondPUnt(1);
				item.setReqDate(param.getReqDateH());
				item.setRegiIdxx(param.getRegiIdxx());
				item.setUpdtIdxx(param.getUpdtIdxx());
				if(StringUtil.isNullToString(item.getHighValueYn()).equals("")) {
					item.setHighValueYn("N");
				}
				directOrderDao.createDirectOrderItem(item);
			}
			Map<String, Object> inputParams = new HashMap<String, Object>();
			inputParams.put("I_PERSNO", param.getUpdtIdxx());

			Map<String, Object> header = new HashMap<String, Object>(); //주문헤더
			header.put("UPDATEFLAG", "U");
			header.put("VBELN", param.getVbeln());
			header.put("DOC_TYPE", param.getDocType());
			header.put("ORD_REASON", param.getOrdReason());
			header.put("SALES_ORG", param.getSalesOrg());
			header.put("DISTR_CHAN", param.getDistrChan());
			header.put("DIVISION", param.getDivision());
			header.put("REQ_DATE_H", param.getReqDateH());
			header.put("PRICE_DATE", param.getReqDateH());
			header.put("SHIP_COND", param.getShipCond());
			header.put("PURCH_NO_C", param.getPurchNoC());	//TB_ORDER_MASTER_SEQ
//			header.put("DOC_DATE", Util.getToday());
			header.put("PMNTTRMS", param.getPmnttrms());
			header.put("INCOTERMS1", param.getIncoterms1());
			header.put("INCOTERMS2", param.getIncoterms2());
			header.put("BILL_BLOCK", param.getBillBlock());
			header.put("AUART_T", OrderType.getOrderType(param.getDocType()).getName());
			header.put("ACCNT_ASGN", param.getAccntAsgn());
//			header.put("PRICE_LIST", param.getPriceList());	item 으로 이동
			header.put("ASS_NUMBER", param.getAssNumber());
			header.put("SALES_OFF", param.getVkbur());
			inputParams.put("ORDER_HEADER", header);

			Map<String, Object> booking = new HashMap<String, Object>(); //주문부킹
			booking.put("ZZROUTE", param.getZzroute());
			booking.put("ZBKQ_YN", param.getZbkqYn().equals("") ? "N" : param.getZbkqYn());
			booking.put("ZZLAND1", param.getZland1());
			booking.put("ZZTRNS_WAY1", param.getZztrnsWay1());
			booking.put("ZZTRNS_WAY2", param.getZztrnsWay2());
			booking.put("ZZTRNS_QTY1", param.getZztrnsQty1());
			booking.put("ZZTRNS_QTY2", param.getZztrnsQty2());
			booking.put("ZDPTBG", param.getZdptbg());
			inputParams.put("ORDER_BOOKING", booking);

			JcoTableParam tableParam = new JcoTableParam();

			List partners = new ArrayList();
			setErpPartnAg(param, partners);//판매처
			setErpPartnWe(param, partners);//인도처
			setErpPartnZ4(param, partners);//포워더
			setErpPartnZ6(param, partners);//수출커미션
			setErpPartnZ7(param, partners);//실제인도처
			setErpPartnVe(param, partners);
			tableParam.put("ORDER_PARTNERS", partners);

			List itemList = new ArrayList();
			List itemPriceList = new ArrayList();
			Map itemMap = new HashMap();
			Map itemPriceMap = new HashMap();
			if(!param.getCondType().equals("")) {	//수출커미션
/*				itemMap.put("ITM_NUMBER", "00");//주문아이템 순차번호
				itemMap.put("UPDATEFLAG", "U");
				itemList.add(itemMap);
*/
				itemPriceMap.put("ITM_NUMBER", "00");//주문아이템 순차번호
				itemPriceMap.put("COND_TYPE", param.getCondType());
				itemPriceMap.put("COND_VALUE", param.getCondValue());
				itemPriceMap.put("UPDATEFLAG", "U");
				itemPriceList.add(itemPriceMap);
			}

			for(DirectOrderItemVO item : param.getOrderItemList()){
				itemMap = new HashMap();
				itemPriceMap = new HashMap();
				itemMap.put("ITM_NUMBER", item.getSeq()+"");//주문아이템 순차번호
				
				if(item.getSeq() <= oriItems.get(oriItems.size() - 1).getSeq()) {	// seq asc 로 검색했으니 마지막 seq 가 제일 크다
					//기존자재
					itemMap.put("UPDATEFLAG", "U");
					itemPriceMap.put("UPDATEFLAG", "U");
				} else {
					itemMap.put("UPDATEFLAG", "I");
					itemPriceMap.put("UPDATEFLAG", "U");
				}
				itemMap.put("MATERIAL", item.getMaterial());
				itemMap.put("PLANT", item.getPlant());
				itemMap.put("STORE_LOC", item.getStoreLoc());
				itemMap.put("REQ_DATE", param.getReqDateH());
				itemMap.put("REQ_QTY", item.getReqQty());
				itemMap.put("PURCH_NO_C", param.getPurchNoC());
				itemMap.put("REASON_REJ", param.getReasonRej());
				itemMap.put("PRICE_LIST_I", item.getPriceListI());
				
				//매출 적흑자 수정시 금액만 수정가능하게 하고 item 에는 넣지않는다.
				if (!param.getDocType().equals(OrderType.SALES_LOSS.getCode())
						&& !param.getDocType().equals(OrderType.SALES_SURPLUS.getCode())) {
					itemList.add(itemMap);
				}

				itemPriceMap.put("ITM_NUMBER", item.getSeq()+"");//주문아이템 순차번호
				itemPriceMap.put("MATERIAL", item.getMaterial());
				itemPriceMap.put("COND_UNIT", item.getCondUnit());
				itemPriceMap.put("COND_P_UNT", item.getCondPUnt());
				itemPriceMap.put("CURRENCY", item.getCurrency());
				if (param.getDocType().equals(OrderType.MARKETING.getCode())
						|| param.getDocType().equals(OrderType.EXPORT.getCode())
						|| param.getDocType().equals(OrderType.RETURNS_INBOUND.getCode())
						|| param.getDocType().equals(OrderType.QUANTITY_ADJUST_MINUS.getCode())
						|| param.getDocType().equals(OrderType.QUANTITY_ADJUST_PLUS.getCode())
						|| param.getDocType().equals(OrderType.OTHERS.getCode())
						|| param.getDocType().equals(OrderType.SALES_LOSS.getCode())
						|| param.getDocType().equals(OrderType.SALES_SURPLUS.getCode())
						|| param.getDocType().equals(OrderType.SPECIAL_PRICE.getCode())) {
					itemPriceMap.put("COND_TYPE", "PR00");
					itemPriceMap.put("COND_VALUE", item.getPr00Price());
				}

				itemPriceList.add(itemPriceMap);
			}

			Map deleteItemMap = new HashMap();
			Map deleteItemPriceMap = new HashMap();
			List deleteItemList = new ArrayList();
			List deleteItemPriceList = new ArrayList();

			for(DirectOrderItemVO oriItem : oriItems) {	//삭제된 것들 UPDATEFLAG D 로 별도생성 why ? 첫번째 전송때만 전송하고 두번째 전송에는 빼야 오류가 안난다. 
				if(oriItem.getSeq() > param.getOrderItemList().get(param.getOrderItemList().size() - 1).getSeq()) {
					deleteItemMap = new HashMap();
					deleteItemMap.put("ITM_NUMBER", oriItem.getSeq());//주문아이템 순차번호
					deleteItemMap.put("UPDATEFLAG", "D");

					deleteItemPriceMap.put("ITM_NUMBER", oriItem.getSeq());//주문아이템 순차번호
					deleteItemPriceMap.put("UPDATEFLAG", "D");
					deleteItemList.add(deleteItemMap);
					deleteItemPriceList.add(deleteItemPriceMap);
				}
			}

			List allItemList = new ArrayList();
			List allItemPriceList = new ArrayList();
			
			allItemList.addAll(itemList);
			allItemList.addAll(deleteItemList);
			allItemPriceList.addAll(itemPriceList);
			allItemPriceList.addAll(deleteItemPriceList);

			tableParam.put("ORDER_ITEMS", allItemList);
			tableParam.put("ORDER_ITEM_PRICE", allItemPriceList);

			//출하담당 비고
			Iterable<String> ite = Splitter.fixedLength(65).split(StringUtil.replace(StringUtil.replace(param.getBigoZ002(), "\r", ""), "\n", " "));
			String[] cdepComments = Iterables.toArray(ite, String.class);
			List<Map> commentList = new ArrayList<Map>();
			setErpOrderTextCdep(cdepComments, commentList);

			//견본 비고
			ite = Splitter.fixedLength(65).split(StringUtil.replace(StringUtil.replace(param.getBigoZ025(), "\r", ""), "\n", " "));
			String[] sampleComments = Iterables.toArray(ite, String.class);
			setErpOrderTextSample(commentList, sampleComments);

			//고객 PO
			ite = Splitter.fixedLength(65).split(StringUtil.replace(StringUtil.replace(param.getBigoZ012(), "\r", ""), "\n", " "));
			String[] custpoComments = Iterables.toArray(ite, String.class);
			setErpOrderTextCustpo(commentList, custpoComments);

			if(commentList.size() > 0) {
				tableParam.put("ORDER_TEXT", commentList);
			}

			jcoConnector.executeFunction(rfcName, inputParams, tableParam);

			List<Map> resultList = (List<Map>) tableParam.get("RETURN");
			rtMap = isSuccessSendErp(param, resultList);
			if((boolean) rtMap.get("isSuccess")) {
				//처음 수정시 제품이 수정되면 저장위치가 누락되는 경우가 발생 RFC를 수정해야 하나 임시변통으로 한번 더 전송
				tableParam = new JcoTableParam();
				tableParam.put("ORDER_PARTNERS", partners);
				tableParam.put("ORDER_ITEMS", itemList);
				tableParam.put("ORDER_ITEM_PRICE", itemPriceList);
				if(commentList.size() > 0) {
					tableParam.put("ORDER_TEXT", commentList);
				}
				jcoConnector.executeFunction(rfcName, inputParams, tableParam);

				resultList = (List<Map>) tableParam.get("RETURN");
				rtMap = isSuccessSendErp(param, resultList);
				if((boolean) rtMap.get("isSuccess")) {
					//NOTHING TO DO
//					directOrderDao.updateErpOrderId(param);
				} else {
					ServiceException se = new ServiceException();
					se.setErrorMsg("ERP : 오더번호 " + param.getVbeln() + " " + rtMap.get("message"));
					throw se;
				}
			} else {
				ServiceException se = new ServiceException();
				se.setErrorMsg("ERP : 오더번호 " + param.getVbeln() + " " + rtMap.get("message"));
				throw se;
			}
		}			
		return rtMap;
	}

	@Override
	public void deleteDirectOrder(DirectOrderMasterVO param) {
		directOrderDao.deleteDirectOrderMaster(param);
		directOrderDao.deleteDirectOrderItems(param);
		
		Map<String, Object> inputParams = new HashMap<String, Object>();

		Map<String, Object> header = new HashMap<String, Object>(); //주문헤더
		header.put("UPDATEFLAG", "D");
		header.put("VBELN", param.getVbeln());
		inputParams.put("ORDER_HEADER", header);
		
		JcoTableParam tableParam = new JcoTableParam();
		jcoConnector.executeFunction(FNC_SAP_UPDATE_ORDER, inputParams, tableParam);

		List<Map> resultList = (List<Map>) tableParam.get("RETURN");
		boolean isSuccess = true;
		String vbeln = "";
        StringBuffer message = new StringBuffer();
		for(Map result : resultList) {
			String id = StringUtil.nullConvert(result.get("ID"));
			String number = StringUtil.nullConvert(result.get("NUMBER"));
			String type = StringUtil.nullConvert(result.get("TYPE"));

			if(type.equals("E")) {
				logger.error(result.get("MESSAGE").toString());
				message.append(result.get("MESSAGE").toString().trim() + "\n");
				isSuccess = false;
			}
		}
		if(!isSuccess) {
			ServiceException se = new ServiceException();
			se.setErrorMsg(message.toString());
			throw se;
		}
	}

	@Override
	public List<DirectOrderMasterVO> getOrderMasterItemForClosingList(DirectOrderMasterVO param) {
		List<DirectOrderMasterVO> masterList = directOrderDao.getDirectOrderMasterItemList(param);
		for(DirectOrderMasterVO master : masterList) {
			
			master = (DirectOrderMasterVO) StringUtil.nullToEmptyString(master);
			setOrderDetailCodeText(master);
			master.setSalesOrgText(master.getSalesOrgText().split("]")[1]); //영업조직
			master.setDistrChanText(master.getDistrChanText().split("]")[1]); //유통경로
			
			if(!master.getPriceList().equals("")) //가격리스트구분
				master.setPriceListText("["+master.getPriceList()+"]"+SalePriceMasterPriceListType.getSalePriceMasterPriceListType(master.getPriceList()).getName());
			if(!StringUtil.isNullToString(master.getCondUnit()).equals("")) //단위
				master.setCondUnitText(SalePriceMasterUnitType.getSalePriceMasterUnitType(master.getCondUnit()).getName());
		}
		//화면에서 넘어온 조회조건이 아닌 조회된 데이터 셋의 확정일 from - to 로 rfc조회범위를 좁힌다.
		//해당 rfc의 일자는 필수
		if(masterList.size() > 0)
			setSapOrderStatus(param, masterList, setDateCondition(masterList));
//		setSapOrderStatus(param, masterList, new String[]{param.getSdate(), param.getEdate()});

		return masterList;
	}

	public Map updateCommentText(DirectOrderMasterVO param) {
		DirectOrderMasterVO masterVo = directOrderDao.getDirectOrderMaster(param.getOrderId());
		param = (DirectOrderMasterVO) StringUtil.nullToEmptyString(param);

		masterVo.setBigoZ002(param.getBigoZ002());
		masterVo.setBigoZ025(param.getBigoZ025());
		masterVo.setBigoZ012(param.getBigoZ012());
		masterVo.setUpdtIdxx(param.getUpdtIdxx());

		Map rtMap = null;
		directOrderDao.updateDirectOrderMaster(masterVo);
		Map<String, Object> inputParams = new HashMap<String, Object>();
		inputParams.put("I_PERSNO", masterVo.getUpdtIdxx());

		Map<String, Object> header = new HashMap<String, Object>(); //주문헤더
		header.put("UPDATEFLAG", "U");
		header.put("VBELN", masterVo.getVbeln());
/*
		header.put("DOC_TYPE", param.getDocType());
		header.put("ORD_REASON", param.getOrdReason());
		header.put("SALES_ORG", param.getSalesOrg());
		header.put("DISTR_CHAN", param.getDistrChan());
		header.put("DIVISION", param.getDivision());
		header.put("REQ_DATE_H", param.getReqDateH());
		header.put("PRICE_DATE", param.getReqDateH());
		header.put("SHIP_COND", param.getShipCond());
		header.put("PURCH_NO_C", param.getPurchNoC());	//TB_ORDER_MASTER_SEQ
//			header.put("DOC_DATE", Util.getToday());
		header.put("PMNTTRMS", param.getPmnttrms());
		header.put("INCOTERMS1", param.getIncoterms1());
		header.put("INCOTERMS2", param.getIncoterms2());
		header.put("BILL_BLOCK", param.getBillBlock());
		header.put("AUART_T", OrderType.getOrderType(param.getDocType()).getName());
		header.put("ACCNT_ASGN", param.getAccntAsgn());
//			header.put("PRICE_LIST", param.getPriceList());	item 으로 이동
		header.put("ASS_NUMBER", param.getAssNumber());
*/
		inputParams.put("ORDER_HEADER", header);
/*
		Map<String, Object> booking = new HashMap<String, Object>(); //주문부킹
		booking.put("ZZROUTE", param.getZzroute());
		booking.put("ZBKQ_YN", param.getZbkqYn().equals("") ? "N" : param.getZbkqYn());
		booking.put("ZZLAND1", param.getZland1());
		booking.put("ZZTRNS_WAY1", param.getZztrnsWay1());
		booking.put("ZZTRNS_WAY2", param.getZztrnsWay2());
		booking.put("ZZTRNS_QTY1", param.getZztrnsQty1());
		booking.put("ZZTRNS_QTY2", param.getZztrnsQty2());
		booking.put("ZDPTBG", param.getZdptbg());
		inputParams.put("ORDER_BOOKING", booking);
*/
		JcoTableParam tableParam = new JcoTableParam();
		//출하담당 비고
		Iterable<String> ite = Splitter.fixedLength(65).split(StringUtil.replace(StringUtil.replace(masterVo.getBigoZ002(), "\r", ""), "\n", " "));
		String[] cdepComments = Iterables.toArray(ite, String.class);
		List<Map> commentList = new ArrayList<Map>();
		setErpOrderTextCdep(cdepComments, commentList);

		//견본 비고
		ite = Splitter.fixedLength(65).split(StringUtil.replace(StringUtil.replace(masterVo.getBigoZ025(), "\r", ""), "\n", " "));
		String[] sampleComments = Iterables.toArray(ite, String.class);
		setErpOrderTextSample(commentList, sampleComments);

		//고객 PO
		ite = Splitter.fixedLength(65).split(StringUtil.replace(StringUtil.replace(masterVo.getBigoZ012(), "\r", ""), "\n", " "));
		String[] custpoComments = Iterables.toArray(ite, String.class);
		setErpOrderTextCustpo(commentList, custpoComments);

		if(commentList.size() > 0) {
			tableParam.put("ORDER_TEXT", commentList);
		}

		jcoConnector.executeFunction(FNC_SAP_UPDATE_ORDER_SKIP_SHIPMENT, inputParams, tableParam);

		List<Map> resultList = (List<Map>) tableParam.get("RETURN");
		rtMap = isSuccessSendErp(param, resultList);
		if((boolean) rtMap.get("isSuccess")) {
		} else {
			ServiceException se = new ServiceException();
			se.setErrorMsg("ERP : 오더번호 " + masterVo.getVbeln() + " " + rtMap.get("message"));
			throw se;
		}
		return rtMap;
	}


	@Override
	public void setSapOrderStatus(DirectOrderMasterVO param, List<DirectOrderMasterVO> masterList) {
		setSapOrderStatus(param, masterList, setDateCondition(masterList));
	}

	@Override
	public Map updateDirectOrderSkipShipment(DirectOrderMasterVO orderMaster) {
		return updateDirectOrder(FNC_SAP_UPDATE_ORDER_SKIP_SHIPMENT, orderMaster, false);
	}

	@Override
	public Map updateDirectOrder(DirectOrderMasterVO orderMaster) {
		return updateDirectOrder(FNC_SAP_UPDATE_ORDER, orderMaster, true);
	}

	@Override
	public void updatePmnttrms(DirectOrderMasterVO[] params) {
		for(DirectOrderMasterVO param : params) {
			DirectOrderMasterVO masterVo = directOrderDao.getDirectOrderMaster(param.getOrderId());
			masterVo.setOrderItemList(directOrderDao.getDirectOrderItemList(param.getOrderId()));
			//지급조건과 사유 변경
			masterVo.setPmnttrms(param.getNewPmnttrms());
			masterVo.setReasonRej(param.getReasonRej());
			//진행상태 가져오기
			setSapOrderStatus(null, Arrays.asList(masterVo));
			if(masterVo.getProcStat().equals(OrderStatus.BILLING_COMPLETE.getCode())) {	//빌링단계까지 진행되었으면 취소후 수정하고 다시 빌링생성
				salePriceMasterMgmtService.cancelBilling(new DirectOrderMasterVO[] {masterVo});
				logger.debug("주문번호 : " + masterVo.getOrderId() + " 처리중");
				for(int i = 1 ; i < 20 ; i++) {	//빌링이 최종취소 될때까지 시간이 걸린다.. 얼마나 걸리는진 모른다...
					try {
						Thread.sleep(500);
						setSapOrderStatus(null, Arrays.asList(masterVo));
						if(!masterVo.getProcStat().equals(OrderStatus.BILLING_COMPLETE.getCode())) {
							updateDirectOrderSkipShipment(masterVo);
							salePriceMasterMgmtService.postBilling(new DirectOrderMasterVO[] {masterVo});
							logger.debug("주문번호 : " + masterVo.getOrderId() + " 처리완료 " + i + " seconds");
							continue;
						}
					} catch (InterruptedException e) {
					}
				}
			} else {
				updateDirectOrderSkipShipment(masterVo);
			}
		}
	}

	@Override
	public int getDirectOrderCount(DirectOrderMasterVO param) {
		return directOrderDao.getDirectOrderCount(param);
	}

	@Override
	public List<DirectOrderMasterVO> getDirectOrderList(DirectOrderMasterVO param) {
		return directOrderDao.getDirectOrderList(param);
	}

	@Override
	public List<DirectOrderMasterVO> getOrderForPaymentChangeList(DirectOrderMasterVO param) {
		List<DirectOrderMasterVO> masterList = directOrderDao.getDirectOrderList(param);

		JcoTableParam<?> tableParam = null;
		Map<String, Object> inputParam = null;
		Map<String, Object> outputParam = null;
		Map<String, Object> paramMap = null;

		for(DirectOrderMasterVO master : masterList) {
			master.setPmnttrmsOrganText(sapSearchService.getMasterCodeName("28", StringUtil.nullConvert(master.getPmnttrmsOrgan())));
			//전자상거래는 지급조건이 TB_ORDER_MASTER 에 없고 주문시 SAP 에서 고객마스터의 지급조건으로 넣고있다. 
			//SAP 의 지급조건을 변경하는게 목표이므로 모든 주문을 SAP 지급조건으로 조회
			tableParam = new JcoTableParam<Object>();
			paramMap = new HashMap<String, Object>();
			tableParam.put("ET_DATA", paramMap);

			inputParam = new HashMap<String, Object>();
/*	조건이 많을때 더 느리다...
			inputParam.put("I_SALES_ORG", master.getSalesOrg());
			inputParam.put("I_DISTR_CHAN", master.getDistrChan());
			inputParam.put("I_DOC_DATE_F", StringUtil.remove(master.getDocDate(), '.'));
			inputParam.put("I_DOC_DATE_T", StringUtil.remove(master.getDocDate(), '.'));
*/			
			inputParam.put("I_VBELN", master.getVbeln());
			outputParam = new HashMap<String, Object>();

			jcoConnector.executeFunction(FNC_SAP_SEARCH_ORDER, inputParam, outputParam, tableParam, false);

			List<Object> orders = (List<Object>)tableParam.get("ET_DATA");
			String pmnttrms = "";
			if (orders.size() > 0) {
				pmnttrms = StringUtil.nullConvert(((Map)orders.get(0)).get("PMNTTRMS"));
				master.setPmnttrmsText(sapSearchService.getMasterCodeName("28", pmnttrms));
				master.setPmnttrms(pmnttrms);
				// 저장시 비교를 위해 기존 지급조건으로 세팅
				master.setNewPmnttrms(pmnttrms);
			}
		}
		return masterList;
	}
	
}
