package com.lgmma.salesPortal.app.dao;

import com.lgmma.salesPortal.app.model.SmsVO;

public interface SmsDao {
	
	public void createSms(SmsVO param);

}
