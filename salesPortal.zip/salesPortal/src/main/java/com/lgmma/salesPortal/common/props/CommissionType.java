package com.lgmma.salesPortal.common.props;

public enum CommissionType {
/**
 * 수출시 조건
*/
	 COMMISSION_PROD("PR00","판가 가격")
	,COMMISSION_RATE("ZE01","커미션 %")
	,COMMISSION_QTY("ZE02","커미션 수량")
	;
	String code = null;
	String text = null;

	private CommissionType(String code, String text) {
		this.code = code;
		this.text = text;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
		
	public static CommissionType getCommission(String code) {
		for(CommissionType type : CommissionType.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}

}
