package com.lgmma.salesPortal.app.model;

import java.util.List;

public class VocVO extends PagingParamVO {
	
	//TBS_VOC
	private int vocxIdxx;	//VOC ID
	private String inptChnl;	//접수채널
	private String tvkotVkorg;	//제품군
	private String srvcCode;	//서비스 코드
	private String divxCode;	//분류코드
	private String compCode;	//고객사코드
	private String reqxDate;	//처리요청일
	private String reqxHour;	//처리요청시간
	private String titlText;	//제목
	private String contText;	//요청사항
	private String gradIdxx;	//Grade Code
	private String fildQtyx1;	//수량
	private String qtyxUnit;	//단위
	private String fildDate1;	//일자1
	private String fildText1;	//Short 텍스트1
	private String fildText2;	//Short 텍스트2
	private String fildText3;	//Short 텍스트3
	private String fildText4;	//Short 텍스트4
	private String indoIdxx;	//인도처ID
	private String indoPost;	//인도처 우편번호
	private String indoAddr;	//인도처 주소
	private String indoTelx;	//인도처 연락처
	private String indoManx;	//인도처 담당자
	private String fildFlag1;	//플래그1
	private String vocxStat;	//고객_진행상태
	private String yymmDate;	//출하년월
	private String vsbed;		//출하지점	
	private String qpUse;
	private String qpUser;
	private String saveDate;
	private String saveRate;
	private String saveComment;
	private String saveContent;
	private String saveTel;
	private String saveMail;
	private String indoEmail;
	private String fileId;
	//샘플 품의관련 필드
	private String rivalCorp;
	private String rivalItems;
	private String setMaker;
	private String estimatedUsage;

	private String vkorgText;	//영업조직명
	private String srvcName;	//서비스코드명
	private String divxName;	//분류코드명
	private String vStatName;	//요청진행상태설명
	private String compName;	//등록자회사
	private String lognName;	//의뢰인
	private String faxxNumb;	//FAX
	private String hpxxNumb;	//휴대폰
	private String name1;		//업체명
	private String sawnName;	//담당영업사원명
	private String codeType;	//불만유형
	private String reqxDtFmt;	//처리요청일시
	private String fildFlag1Nm;	//플래그1명	
	private String indoName;	//인도처명

	private String loginUserType;	//사용자 타입 P : 파트너 E : 임직원
	private String userId;

	private List<VocGradeVO> vocGradeList;	
	private List<VocActVO> vocActList;
	private List<VocTypeVO> typeCodeList;
	//VOC 접수 이력
	private VocActVO vocCustActInputHis;
	//VOC 답변 이력
	private VocActVO vocCustActAnswerHis;
	
	public int getVocxIdxx() {
		return vocxIdxx;
	}
	public void setVocxIdxx(int vocxIdxx) {
		this.vocxIdxx = vocxIdxx;
	}
	public String getInptChnl() {
		return inptChnl;
	}
	public void setInptChnl(String inptChnl) {
		this.inptChnl = inptChnl;
	}
	public String getTvkotVkorg() {
		return tvkotVkorg;
	}
	public void setTvkotVkorg(String tvkotVkorg) {
		this.tvkotVkorg = tvkotVkorg;
	}
	public String getSrvcCode() {
		return srvcCode;
	}
	public void setSrvcCode(String srvcCode) {
		this.srvcCode = srvcCode;
	}
	public String getDivxCode() {
		return divxCode;
	}
	public void setDivxCode(String divxCode) {
		this.divxCode = divxCode;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getReqxDate() {
		return reqxDate;
	}
	public void setReqxDate(String reqxDate) {
		this.reqxDate = reqxDate;
	}
	public String getReqxHour() {
		return reqxHour;
	}
	public void setReqxHour(String reqxHour) {
		this.reqxHour = reqxHour;
	}
	public String getTitlText() {
		return titlText;
	}
	public void setTitlText(String titlText) {
		this.titlText = titlText;
	}
	public String getContText() {
		return contText;
	}
	public void setContText(String contText) {
		this.contText = contText;
	}
	public String getGradIdxx() {
		return gradIdxx;
	}
	public void setGradIdxx(String gradIdxx) {
		this.gradIdxx = gradIdxx;
	}
	public String getFildQtyx1() {
		return fildQtyx1;
	}
	public void setFildQtyx1(String fildQtyx1) {
		this.fildQtyx1 = fildQtyx1;
	}
	public String getQtyxUnit() {
		return qtyxUnit;
	}
	public void setQtyxUnit(String qtyxUnit) {
		this.qtyxUnit = qtyxUnit;
	}
	public String getFildDate1() {
		return fildDate1;
	}
	public void setFildDate1(String fildDate1) {
		this.fildDate1 = fildDate1;
	}
	public String getFildText1() {
		return fildText1;
	}
	public void setFildText1(String fildText1) {
		this.fildText1 = fildText1;
	}
	public String getFildText2() {
		return fildText2;
	}
	public void setFildText2(String fildText2) {
		this.fildText2 = fildText2;
	}
	public String getFildText3() {
		return fildText3;
	}
	public void setFildText3(String fildText3) {
		this.fildText3 = fildText3;
	}
	public String getFildText4() {
		return fildText4;
	}
	public void setFildText4(String fildText4) {
		this.fildText4 = fildText4;
	}
	public String getIndoIdxx() {
		return indoIdxx;
	}
	public void setIndoIdxx(String indoIdxx) {
		this.indoIdxx = indoIdxx;
	}
	public String getIndoPost() {
		return indoPost;
	}
	public void setIndoPost(String indoPost) {
		this.indoPost = indoPost;
	}
	public String getIndoAddr() {
		return indoAddr;
	}
	public void setIndoAddr(String indoAddr) {
		this.indoAddr = indoAddr;
	}
	public String getIndoTelx() {
		return indoTelx;
	}
	public void setIndoTelx(String indoTelx) {
		this.indoTelx = indoTelx;
	}
	public String getIndoManx() {
		return indoManx;
	}
	public void setIndoManx(String indoManx) {
		this.indoManx = indoManx;
	}
	public String getFildFlag1() {
		return fildFlag1;
	}
	public void setFildFlag1(String fildFlag1) {
		this.fildFlag1 = fildFlag1;
	}
	public String getVocxStat() {
		return vocxStat;
	}
	public void setVocxStat(String vocxStat) {
		this.vocxStat = vocxStat;
	}
	public String getYymmDate() {
		return yymmDate;
	}
	public void setYymmDate(String yymmDate) {
		this.yymmDate = yymmDate;
	}
	public String getVsbed() {
		return vsbed;
	}
	public void setVsbed(String vsbed) {
		this.vsbed = vsbed;
	}
	public String getQpUse() {
		return qpUse;
	}
	public void setQpUse(String qpUse) {
		this.qpUse = qpUse;
	}
	public String getQpUser() {
		return qpUser;
	}
	public void setQpUser(String qpUser) {
		this.qpUser = qpUser;
	}
	public String getSaveDate() {
		return saveDate;
	}
	public void setSaveDate(String saveDate) {
		this.saveDate = saveDate;
	}
	public String getSaveRate() {
		return saveRate;
	}
	public void setSaveRate(String saveRate) {
		this.saveRate = saveRate;
	}
	public String getSaveComment() {
		return saveComment;
	}
	public void setSaveComment(String saveComment) {
		this.saveComment = saveComment;
	}
	public String getSaveContent() {
		return saveContent;
	}
	public void setSaveContent(String saveContent) {
		this.saveContent = saveContent;
	}
	public String getSaveTel() {
		return saveTel;
	}
	public void setSaveTel(String saveTel) {
		this.saveTel = saveTel;
	}
	public String getSaveMail() {
		return saveMail;
	}
	public void setSaveMail(String saveMail) {
		this.saveMail = saveMail;
	}
	public String getIndoEmail() {
		return indoEmail;
	}
	public void setIndoEmail(String indoEmail) {
		this.indoEmail = indoEmail;
	}	
	public String getVkorgText() {
		return vkorgText;
	}
	public void setVkorgText(String vkorgText) {
		this.vkorgText = vkorgText;
	}
	public String getSrvcName() {
		return srvcName;
	}
	public void setSrvcName(String srvcName) {
		this.srvcName = srvcName;
	}
	public String getDivxName() {
		return divxName;
	}
	public void setDivxName(String divxName) {
		this.divxName = divxName;
	}
	public String getvStatName() {
		return vStatName;
	}
	public void setvStatName(String vStatName) {
		this.vStatName = vStatName;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getLognName() {
		return lognName;
	}
	public void setLognName(String lognName) {
		this.lognName = lognName;
	}
	public String getFaxxNumb() {
		return faxxNumb;
	}
	public void setFaxxNumb(String faxxNumb) {
		this.faxxNumb = faxxNumb;
	}
	public String getHpxxNumb() {
		return hpxxNumb;
	}
	public void setHpxxNumb(String hpxxNumb) {
		this.hpxxNumb = hpxxNumb;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getSawnName() {
		return sawnName;
	}
	public void setSawnName(String sawnName) {
		this.sawnName = sawnName;
	}
	public String getCodeType() {
		return codeType;
	}
	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}
	public String getReqxDtFmt() {
		return reqxDtFmt;
	}
	public void setReqxDtFmt(String reqxDtFmt) {
		this.reqxDtFmt = reqxDtFmt;
	}
	public String getFildFlag1Nm() {
		return fildFlag1Nm;
	}
	public void setFildFlag1Nm(String fildFlag1Nm) {
		this.fildFlag1Nm = fildFlag1Nm;
	}
	public List<VocGradeVO> getVocGradeList() {
		return vocGradeList;
	}	
	public void setVocGradeList(List<VocGradeVO> vocGradeList) {
		this.vocGradeList = vocGradeList;
	}
	
	public String getIndoName() {
		return indoName;
	}
	public void setIndoName(String indoName) {
		this.indoName = indoName;
	}	
	
	public String getLoginUserType() {
		return loginUserType;
	}
	public void setLoginUserType(String loginUserType) {
		this.loginUserType = loginUserType;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public List<VocActVO> getVocActList() {
		return vocActList;
	}
	public void setVocActList(List<VocActVO> vocActList) {
		this.vocActList = vocActList;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<VocTypeVO> getTypeCodeList() {
		return typeCodeList;
	}
	public void setTypeCodeList(List<VocTypeVO> typeCodeList) {
		this.typeCodeList = typeCodeList;
	}
	public VocActVO getVocCustActInputHis() {
		return vocCustActInputHis;
	}
	public void setVocCustActInputHis(VocActVO vocCustActInputHis) {
		this.vocCustActInputHis = vocCustActInputHis;
	}
	public VocActVO getVocCustActAnswerHis() {
		return vocCustActAnswerHis;
	}
	public void setVocCustActAnswerHis(VocActVO vocCustActAnswerHis) {
		this.vocCustActAnswerHis = vocCustActAnswerHis;
	}
	public String getRivalCorp() {
		return rivalCorp;
	}
	public void setRivalCorp(String rivalCorp) {
		this.rivalCorp = rivalCorp;
	}
	public String getRivalItems() {
		return rivalItems;
	}
	public void setRivalItems(String rivalItems) {
		this.rivalItems = rivalItems;
	}
	public String getSetMaker() {
		return setMaker;
	}
	public void setSetMaker(String setMaker) {
		this.setMaker = setMaker;
	}
	public String getEstimatedUsage() {
		return estimatedUsage;
	}
	public void setEstimatedUsage(String estimatedUsage) {
		this.estimatedUsage = estimatedUsage;
	}	
	
}
