package com.lgmma.salesPortal.common.props;

public enum ApprGPortalApprovalReturnType {
/**
 * GPortal 결재자결재 리턴코드 로서
*/
	 GP_APPL_APPROVE(	"APPROVE"	,"승인"				,	"2000",	"A")
	,GP_APPL_REJECT(	"REJECT"	,"반려"				,	"4010",	"R")
	,GP_APPL_AGREE(		"AGREE"		,"합의(합의완료)"	,	"2000",	"C")
	,GP_APPL_DISAGREE(	"DISAGREE"	,"합의(합의반대)"	,	"4020",	"R")
	,GP_APPL_COMPLETE(	"COMPLETE"	,"최종완료"			,	"9000",	"A")
	;
	String code		= null;		// GPortal 결재결과 코드
	String name		= null;		// GPortal 결재결과 코드명
	String apprState= null;		// salesportal 문서상태
	String applState= null;		// salesportal 결재자 결재 상태

	private ApprGPortalApprovalReturnType(String code, String name, String apprState, String applState) {
		this.code		= code;
		this.name		= name;
		this.apprState	= apprState;
		this.applState	= applState;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getApprState() {
		return apprState;
	}

	public void setApprState(String apprState) {
		this.apprState = apprState;
	}

	public String getApplState() {
		return applState;
	}

	public void setApplState(String applState) {
		this.applState = applState;
	}

	public static ApprGPortalApprovalReturnType getApprGPortalApprovalReturnType(String code) {
		for(ApprGPortalApprovalReturnType type : ApprGPortalApprovalReturnType.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
}
