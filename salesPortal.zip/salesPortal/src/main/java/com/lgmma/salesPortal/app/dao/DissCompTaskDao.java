package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissCompTaskVO;

public interface DissCompTaskDao {	
	
	DissCompTaskVO getDissCompTaskInfo(DissCompTaskVO param);
	
	void createDissCompTask(DissCompTaskVO param);
	
	void updateDissCompTask(DissCompTaskVO param);
	
	void deleteDissCompTaskAll(DissCompTaskVO param);
	

}
