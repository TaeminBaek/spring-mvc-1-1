package com.lgmma.salesPortal.common.schedule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.lgmma.salesPortal.app.model.JobScheduleParamVO;
import com.lgmma.salesPortal.common.schedule.service.JobScheduledService;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.Util;

@Component
public class ScheduleTask {

	@Autowired
	JobScheduledService jobScheduledService;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;

	private static Logger logger = LoggerFactory.getLogger(ScheduleTask.class);
	/**
	 * 자재마스터 가져오기 정시 마다
	 */
	@Scheduled(cron="0 0 * * * ?")
	public void excProductsFromSap() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================자재마스터 가져오기 시작================================");
			jobScheduledService.excProductsFromSap();
			logger.debug("================================자재마스터 가져오기 종료================================");
		}
	}

	/**
	 * 재고마스터 가져오기 30분 마다
	 */
	@Scheduled(cron="0 0/30 * * * ?")
	public void excProductStocksFromSap() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================재고마스터 가져오기 시작================================");
			jobScheduledService.excProductStocksFromSap();
			logger.debug("================================재고마스터 가져오기 종료================================");
		}
	}

	/**
	 * 환율정보 가져오기 정시 마다
	 */
	@Scheduled(cron="0 0 * * * ?")
	public void excExchangeRateFromSap() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================환율정보 가져오기 시작================================");
			jobScheduledService.excExchangeRateFromSap();
			logger.debug("================================환율정보 가져오기 종료================================");
		}
	}

	/**
	 * 출하일자 가져오기 배치 12시간 마다
	 */
	@Scheduled(cron="0 0 0/12 * * ?")
	public void excUpdateOrderWadatIstFromSap() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================출하일자 가져오기 시작================================");
			// 금일 부터 30일치를 찾아서실행
			String toDay = Util.getToday();
			String frDay = DateUtil.addDay(toDay,-30);
			JobScheduleParamVO jobScheduleParamVO = new JobScheduleParamVO();
			jobScheduleParamVO.setToYmd(toDay);
			jobScheduleParamVO.setFrYmd(frDay);
			jobScheduledService.excUpdateOrderWadatIstFromSap(jobScheduleParamVO);
			logger.debug("================================출하일자 가져오기 종료================================");
		}
	}

	/**
	 * 판매처정보가져오기 매일 새벽 2시 15분에 한번씩
	 */
	@Scheduled(cron="0 15 2 * * ?")
	public void excSyncCompOrganByErp() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================판매처정보 가져오기 시작================================");
			jobScheduledService.excSyncCompOrganByErp();
			logger.debug("================================판매처정보 가져오기 종료================================");
		}
	}

	/**
	 * 매일 새벽 5:20에 담보 만료시 담당자에 메일전송, ERP에 담보금액 전송. 
	 */
	@Scheduled(cron="0 20 5 * * ?")
	public void exeSendDamboExpiredMailERP() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================담보 만료 처리 시작================================");
			jobScheduledService.exeSendDamboExpiredMailERP();
			logger.debug("================================담보 만료 처리 종료================================");
		}
	}

	/**
	 * 평일 새벽 5:45에 Diss 과제 지연 건 과제리더,담당자에게 지연 알람 메일
	 */
	@Scheduled(cron="0 45 5 * * 2-6")
	public void exeSendMailDISSDelayTaskAlarm() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================DISS 지연 과제 알람 메일 발송 시작================================");
			jobScheduledService.exeSendMailDISSDelayTaskAlarm();
			logger.debug("================================DISS 지연 과제 알람 메일 발송 종료================================");
		}
	}

	/**
	 * 매일 새벽 5:50에 Diss GateReview 지연 건 담당자에게 지연 알람 메일
	 */
	@Scheduled(cron="0 50 5 * * ?")
	public void exeSendMailDISSDelayGateReviewAlarm() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================DISS GateReview 지연 알람 메일 발송 시작================================");
			jobScheduledService.exeSendMailDISSDelayGateReviewAlarm();
			logger.debug("================================DISS GateReview 지연 알람 메일 발송 종료================================");
		}
	}

	/**
	 * 매일 새벽 6:00에 수출 거래선 신용등급 Update
	 */
	@Scheduled(cron="0 0 6 * * ?")
	public void exeUpdateExpCompanyGradeFromSap() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================수출 거래선 신용등급 Update 시작================================");
			jobScheduledService.exeUpdateExpCompanyGradeFromSap("");
			logger.debug("================================수출 거래선 신용등급 Update 종료================================");
		}
	}

	/**
	 * 매일 새벽 2:30에 매출정보 3개월치 수신
	 */
	@Scheduled(cron="0 30 2 * * ?")
	public void exeGetMonthlySalesFromSap() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================매출정보 3개월치 수신 시작================================");
			String yyyyMmDd = DateUtil.getCurrentDate("yyyyMMdd").substring(0, 6) + "01";
			for(int i = -2 ; i < 1 ; i++) {
				jobScheduledService.exeGetMonthlySalesFromSap(DateUtil.addMonth(yyyyMmDd, i).substring(0, 6));
			}
			logger.debug("================================매출정보 3개월치 수신 종료================================");
		}
	}

	/**
	 * 매일 새벽 7:00에 KED 기업정보 Update
	 */
	@Scheduled(cron="0 0 7 * * ?")
	public void exeUpdateKedInfo() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================KED 기업정보 Update 시작================================");
			jobScheduledService.exeUpdateKedInfo();
			logger.debug("================================KED 기업정보 Update 종료================================");
		}
	}

	/**
	 * NICE 평가정보를 매일 새벽 5시에 조회하여 TBC_COMPANY_GRADE에 인서트 하고 TB_COMPANY를 업데이트 한다. 
	 */
	/*
	@Scheduled(cron="0 0 5 * * ?")
	public void exeUpdateCompGradeFromNICE() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================Nice 평가정보 가져오기 시작================================");
			jobScheduledService.exeUpdateCompGradeFromNICE("");
			logger.debug("================================Nice 평가정보 가져오기 종료================================");
		}
	}
	*/

	/**
	 * KED 평가정보를 매일 아침 7:30에 조회하여 TBC_COMPANY_GRADE에 인서트하고 TB_COMPANY를 업데이트 한다. 
	 */
	@Scheduled(cron="0 30 7 * * ?")
	public void exeUpdateCompGradeFromCretop() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================KED 평가정보 Update 시작================================");
			jobScheduledService.exeUpdateCompGradeFromCretop();
			logger.debug("================================KED 평가정보 Update 종료================================");
		}
	}

	/**
	 * 평가정보를 매일 아침 8시에 ERP에 전송. 
	 */
	@Scheduled(cron="0 0 8 * * ?")
	public void exeSendCompGradeToERP() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================평가정보 ERP 전송 시작================================");
			jobScheduledService.exeSendCompGradeToERP("");
			logger.debug("================================평가정보 ERP 전송 종료================================");
		}
	}

	/**
	 * 수출수금예정 7일 이내 정보 메일 전송
	 */
	@Scheduled(cron="0 15 8 * * ?")
	public void exeSendCollectExpectedDateMail() {
		if(!messageSourceAccessor.getMessage("system.mode").equals("local")) {
			logger.debug("================================수출수금예정 7일 이내 정보 메일 전송 시작================================");
			jobScheduledService.exeSendCollectExpectedDateMail();
			logger.debug("================================수출수금예정 7일 이내 정보 메일 전송 종료================================");
		}
	}

	/**
	 * 매일 오후 5:00에 KED I/F 받을 기업정보 Upload
	 */
	@Scheduled(cron="0 0 17 * * ?")
	public void exeUploadKedCompanyInfo() {
		if(messageSourceAccessor.getMessage("system.mode").equals("real")) {
			logger.debug("================================KED I/F 받을 기업정보 Upload 시작================================");
			jobScheduledService.exeUploadKedCompanyInfo();
			logger.debug("================================KED I/F 받을 기업정보 Upload 종료================================");
		}
	}
}
