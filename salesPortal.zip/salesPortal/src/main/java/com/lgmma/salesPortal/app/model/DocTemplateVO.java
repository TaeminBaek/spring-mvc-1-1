package com.lgmma.salesPortal.app.model;

public class DocTemplateVO extends PagingParamVO {
	private String docTmplId;
	private String docTmplName;
	private String docTmplCont;
	private String deleteYn;
	private String regiName;
	
	public String getDocTmplId() {
		return docTmplId;
	}
	public void setDocTmplId(String docTmplId) {
		this.docTmplId = docTmplId;
	}
	public String getDocTmplName() {
		return docTmplName;
	}
	public void setDocTmplName(String docTmplName) {
		this.docTmplName = docTmplName;
	}
	public String getDocTmplCont() {
		return docTmplCont;
	}
	public void setDocTmplCont(String docTmplCont) {
		this.docTmplCont = docTmplCont;
	}
	public String getDeleteYn() {
		return deleteYn;
	}
	public void setDeleteYn(String deleteYn) {
		this.deleteYn = deleteYn;
	}
	public String getRegiName() {
		return regiName;
	}
	public void setRegiName(String regiName) {
		this.regiName = regiName;
	}
	
}
