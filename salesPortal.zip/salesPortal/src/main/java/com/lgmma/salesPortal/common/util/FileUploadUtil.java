package com.lgmma.salesPortal.common.util;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Component;

@Component
public class FileUploadUtil {

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	public void makeDir(String saveDir) throws Exception{
		java.io.File dir = new java.io.File(messageSourceAccessor.getMessage("file.upload.path") + saveDir);
		
		if(!dir.exists()){
			dir.mkdirs();
		}
	}

	public void makeDirFullPath(String saveDir) throws Exception{
		java.io.File dir = new java.io.File(saveDir);
		
		if(!dir.exists()){
			dir.mkdirs();
		}
	}

	public void deleteDir(String saveDir) throws Exception {
		java.io.File dir = new java.io.File(messageSourceAccessor.getMessage("file.upload.path") + saveDir);
		
		if(dir.exists()){
			File[] innerFileList = dir.listFiles(); 
			if(innerFileList != null){
				for (File innerdir : innerFileList) { 
					if(innerdir.isDirectory()) {
						deleteDir(innerdir.getAbsolutePath());//
					} else { 
						innerdir.delete();
					}
				}
				dir.delete(); 
			}
		}
	}
	
	public void deleteFile(String delDir, String fileNm) throws Exception {
		java.io.File dFile = new java.io.File(delDir + File.separatorChar + fileNm);
		if(dFile != null){
			dFile.delete();
		}
	}
	
}
