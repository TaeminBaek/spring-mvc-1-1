package com.lgmma.salesPortal.app.model;

public class VocActVO extends PagingParamVO {
	
	private String vactIdxx;
	private int vocxIdxx;
	private String levlNumx;
	private String actxName;
	private String regiLognName;
	private String regiLognMail;
	private String acptLognName;
	private String acptLognMail;
	private String regiDate;
	private String acptDate;
	private String endxFlag;
	private String prgmName;
	private String brozSize;
	private String tvkotVkorg;
	private String actxCode;
	private String kunnr;
	private String erpxNoxx;
	private String typeCode; //VOC 세부유형
	private String apprId;
	private String samOrderId;
	//VOC HIS
	private String dueDate;
	private String content1;
	private String content2;
	private String regId;
	private String regName;
	private String regDate;
	
	public String getVactIdxx() {
		return vactIdxx;
	}
	public void setVactIdxx(String vactIdxx) {
		this.vactIdxx = vactIdxx;
	}
	public int getVocxIdxx() {
		return vocxIdxx;
	}
	public void setVocxIdxx(int vocxIdxx) {
		this.vocxIdxx = vocxIdxx;
	}
	public String getLevlNumx() {
		return levlNumx;
	}
	public void setLevlNumx(String levlNumx) {
		this.levlNumx = levlNumx;
	}
	public String getActxName() {
		return actxName;
	}
	public void setActxName(String actxName) {
		this.actxName = actxName;
	}
	public String getRegiLognName() {
		return regiLognName;
	}
	public void setRegiLognName(String regiLognName) {
		this.regiLognName = regiLognName;
	}
	public String getRegiLognMail() {
		return regiLognMail;
	}
	public void setRegiLognMail(String regiLognMail) {
		this.regiLognMail = regiLognMail;
	}
	public String getAcptLognName() {
		return acptLognName;
	}
	public void setAcptLognName(String acptLognName) {
		this.acptLognName = acptLognName;
	}
	public String getAcptLognMail() {
		return acptLognMail;
	}
	public void setAcptLognMail(String acptLognMail) {
		this.acptLognMail = acptLognMail;
	}
	public String getRegiDate() {
		return regiDate;
	}
	public void setRegiDate(String regiDate) {
		this.regiDate = regiDate;
	}
	public String getAcptDate() {
		return acptDate;
	}
	public void setAcptDate(String acptDate) {
		this.acptDate = acptDate;
	}
	public String getEndxFlag() {
		return endxFlag;
	}
	public void setEndxFlag(String endxFlag) {
		this.endxFlag = endxFlag;
	}
	public String getPrgmName() {
		return prgmName;
	}
	public void setPrgmName(String prgmName) {
		this.prgmName = prgmName;
	}
	public String getBrozSize() {
		return brozSize;
	}
	public void setBrozSize(String brozSize) {
		this.brozSize = brozSize;
	}
	public String getTvkotVkorg() {
		return tvkotVkorg;
	}
	public void setTvkotVkorg(String tvkotVkorg) {
		this.tvkotVkorg = tvkotVkorg;
	}
	public String getActxCode() {
		return actxCode;
	}
	public void setActxCode(String actxCode) {
		this.actxCode = actxCode;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getErpxNoxx() {
		return erpxNoxx;
	}
	public void setErpxNoxx(String erpxNoxx) {
		this.erpxNoxx = erpxNoxx;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public String getContent1() {
		return content1;
	}
	public void setContent1(String content1) {
		this.content1 = content1;
	}
	public String getContent2() {
		return content2;
	}
	public void setContent2(String content2) {
		this.content2 = content2;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegName() {
		return regName;
	}
	public void setRegName(String regName) {
		this.regName = regName;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getSamOrderId() {
		return samOrderId;
	}
	public void setSamOrderId(String samOrderId) {
		this.samOrderId = samOrderId;
	}
	
}
