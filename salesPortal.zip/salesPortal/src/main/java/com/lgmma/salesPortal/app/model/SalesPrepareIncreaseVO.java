package com.lgmma.salesPortal.app.model;

public class SalesPrepareIncreaseVO extends PagingParamVO {
	
	private String salesOrg;
	private String distrChan;
	private String gjahr;
	private String gubun;	
	private String cApprEmpId;	
	private String cApprEmpNm;
		
	private String spart;
	private String vtweg;
	private String waerk;
	private String kunnr;
	private String name1;
	private String ename;
	private String zzfield1;
	private String zzfield1bm;
	private String zzfield1av;
	private String zzfield1by;
	private String zzfield1bmu;
	private String zzfield2bmu;
	private String zzfield1avu;
	private String zzfield2avu;
	private String zzfield1byu;
	private String zzfield2byu;
	
	public String getSalesOrg() {
		return salesOrg;
	}
	
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	
	public String getDistrChan() {
		return distrChan;
	}
	
	public void setDistrChan(String distrChan) {
		this.distrChan = distrChan;
	}
	
	public String getGjahr() {
		return gjahr;
	}
	
	public void setGjahr(String gjahr) {
		this.gjahr = gjahr;
	}
	
	public String getGubun() {
		return gubun;
	}
	
	public void setGubun(String gubun) {
		this.gubun = gubun;
	}
	
	public String getcApprEmpId() {
		return cApprEmpId;
	}
	
	public void setcApprEmpId(String cApprEmpId) {
		this.cApprEmpId = cApprEmpId;
	}
	
	public String getcApprEmpNm() {
		return cApprEmpNm;
	}
	
	public void setcApprEmpNm(String cApprEmpNm) {
		this.cApprEmpNm = cApprEmpNm;
	}
	
	public String getSpart() {
		return spart;
	}
	
	public void setSpart(String spart) {
		this.spart = spart;
	}
	
	public String getVtweg() {
		return vtweg;
	}
	
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	
	public String getWaerk() {
		return waerk;
	}

	public void setWaerk(String waerk) {
		this.waerk = waerk;
	}

	public String getKunnr() {
		return kunnr;
	}
	
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	
	public String getName1() {
		return name1;
	}
	
	public void setName1(String name1) {
		this.name1 = name1;
	}
		
	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getZzfield1() {
		return zzfield1;
	}
	
	public void setZzfield1(String zzfield1) {
		this.zzfield1 = zzfield1;
	}

	public String getZzfield1bm() {
		return zzfield1bm;
	}

	public void setZzfield1bm(String zzfield1bm) {
		this.zzfield1bm = zzfield1bm;
	}

	public String getZzfield1av() {
		return zzfield1av;
	}

	public void setZzfield1av(String zzfield1av) {
		this.zzfield1av = zzfield1av;
	}

	public String getZzfield1by() {
		return zzfield1by;
	}

	public void setZzfield1by(String zzfield1by) {
		this.zzfield1by = zzfield1by;
	}

	public String getZzfield1bmu() {
		return zzfield1bmu;
	}

	public void setZzfield1bmu(String zzfield1bmu) {
		this.zzfield1bmu = zzfield1bmu;
	}

	public String getZzfield2bmu() {
		return zzfield2bmu;
	}

	public void setZzfield2bmu(String zzfield2bmu) {
		this.zzfield2bmu = zzfield2bmu;
	}

	public String getZzfield1avu() {
		return zzfield1avu;
	}

	public void setZzfield1avu(String zzfield1avu) {
		this.zzfield1avu = zzfield1avu;
	}

	public String getZzfield2avu() {
		return zzfield2avu;
	}

	public void setZzfield2avu(String zzfield2avu) {
		this.zzfield2avu = zzfield2avu;
	}

	public String getZzfield1byu() {
		return zzfield1byu;
	}

	public void setZzfield1byu(String zzfield1byu) {
		this.zzfield1byu = zzfield1byu;
	}

	public String getZzfield2byu() {
		return zzfield2byu;
	}

	public void setZzfield2byu(String zzfield2byu) {
		this.zzfield2byu = zzfield2byu;
	}
	
	
}
