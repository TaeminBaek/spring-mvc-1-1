package com.lgmma.salesPortal.app.model;

import java.util.List;

import com.lgmma.salesPortal.common.props.OrderType;

public class SalePriceCloseVO extends PagingParamVO {
	private String vkorg;
	private String vkorgName;
	private String saleMan;
	private String saleManName;
	private String yyyymm;
	private String startMonth;
	private String endMonth;
	private String spMonFYmd;
	private String spMonTYmd;
	private String formCont;
	private String workStat;
	private String workStatName;
	private String apprId;
	private String apprStat;
	private String apprStatName;
	private String partnNumbAg;
	private String material;
	private List<OrderType> orderTypeList;
	private List<SalePriceCloseDtlVO> salePriceCloseDtlList;

	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getVkorgName() {
		return vkorgName;
	}
	public void setVkorgName(String vkorgName) {
		this.vkorgName = vkorgName;
	}
	public String getSaleMan() {
		return saleMan;
	}
	public void setSaleMan(String saleMan) {
		this.saleMan = saleMan;
	}
	public String getSaleManName() {
		return saleManName;
	}
	public void setSaleManName(String saleManName) {
		this.saleManName = saleManName;
	}
	public String getYyyymm() {
		return yyyymm;
	}
	public void setYyyymm(String yyyymm) {
		this.yyyymm = yyyymm;
	}
	public String getSpMonFYmd() {
		return spMonFYmd;
	}
	public void setSpMonFYmd(String spMonFYmd) {
		this.spMonFYmd = spMonFYmd;
	}
	public String getSpMonTYmd() {
		return spMonTYmd;
	}
	public void setSpMonTYmd(String spMonTYmd) {
		this.spMonTYmd = spMonTYmd;
	}
	public String getFormCont() {
		return formCont;
	}
	public void setFormCont(String formCont) {
		this.formCont = formCont;
	}
	public String getWorkStat() {
		return workStat;
	}
	public void setWorkStat(String workStat) {
		this.workStat = workStat;
	}
	public String getWorkStatName() {
		return workStatName;
	}
	public void setWorkStatName(String workStatName) {
		this.workStatName = workStatName;
	}
	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getApprStat() {
		return apprStat;
	}
	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}
	public String getApprStatName() {
		return apprStatName;
	}
	public void setApprStatName(String apprStatName) {
		this.apprStatName = apprStatName;
	}
	public String getStartMonth() {
		return startMonth;
	}
	public void setStartMonth(String startMonth) {
		this.startMonth = startMonth;
	}
	public String getEndMonth() {
		return endMonth;
	}
	public void setEndMonth(String endMonth) {
		this.endMonth = endMonth;
	}
	public List<OrderType> getOrderTypeList() {
		return orderTypeList;
	}
	public void setOrderTypeList(List<OrderType> orderTypeList) {
		this.orderTypeList = orderTypeList;
	}
	public String getPartnNumbAg() {
		return partnNumbAg;
	}
	public void setPartnNumbAg(String partnNumbAg) {
		this.partnNumbAg = partnNumbAg;
	}
	public List<SalePriceCloseDtlVO> getSalePriceCloseDtlList() {
		return salePriceCloseDtlList;
	}
	public void setSalePriceCloseDtlList(List<SalePriceCloseDtlVO> salePriceCloseDtlList) {
		this.salePriceCloseDtlList = salePriceCloseDtlList;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
}
