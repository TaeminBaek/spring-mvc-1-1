package com.lgmma.salesPortal.app.dao.impl;

import com.lgmma.salesPortal.app.dao.DissSampleOrderDao;
import com.lgmma.salesPortal.app.model.DissSampleOrderItemVO;
import com.lgmma.salesPortal.app.model.DissSampleOrderMasterVO;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class DissSampleOrderDaoImpl implements DissSampleOrderDao {

	private static final String MAPPER_NAMESPACE = "DISS_SAMPLEORDER_MAPPER.";

	@Autowired(required = true)
	protected SqlSession sqlSession;

	@Override
	public void createDissSampleOrderMaster(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissSampleOrderMaster", dissSampleOrderMasterVO);
	}

	@Override
	public void updateDissSampleOrderMaster(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissSampleOrderMaster", dissSampleOrderMasterVO);
	}

	@Override
	public void deleteDissSampleOrderMaster(String orderId) {
		sqlSession.update(MAPPER_NAMESPACE + "deleteDissSampleOrderMaster", orderId);
	}

	@Override
	public void createDissSampleOrderItem(DissSampleOrderItemVO dissSampleOrderItemVO) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissSampleOrderItem", dissSampleOrderItemVO);
	}

	@Override
	public void deleteDissSampleOrderItemAll(String orderId) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissSampleOrderItemAll", orderId);
	}

	@Override
	public DissSampleOrderMasterVO getDissSampleOrderMaster(String orderId) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissSampleOrderMaster", orderId);
	}

	@Override
	public List<DissSampleOrderItemVO> getDissSampleOrderItemList(String orderId) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissSampleOrderItemList", orderId);
	}

	@Override
	public void updateAfterSendErp(DissSampleOrderMasterVO dissSampleOrderMasterVO){
		sqlSession.update(MAPPER_NAMESPACE + "updateAfterSendErp",dissSampleOrderMasterVO);
	}

	@Override
	public List<DissSampleOrderMasterVO> selectDissSampleOrderMasterItemList(DissSampleOrderMasterVO dissSampleOrderMasterVO){
		return sqlSession.selectList(MAPPER_NAMESPACE + "selectDissSampleOrderMasterItemList",dissSampleOrderMasterVO);
	}
	
	@Override
	public List<DissSampleOrderMasterVO> selectDissSampleOrderCustTestList(DissSampleOrderMasterVO dissSampleOrderMasterVO){
		return sqlSession.selectList(MAPPER_NAMESPACE + "selectDissSampleOrderCustTestList",dissSampleOrderMasterVO);
	}
	
	@Override
	public List<DissSampleOrderMasterVO> selectDissSampleOrderCustTestOrderList(DissSampleOrderMasterVO dissSampleOrderMasterVO){
		return sqlSession.selectList(MAPPER_NAMESPACE + "selectDissSampleOrderCustTestOrderList",dissSampleOrderMasterVO);
	}
	
	@Override
	public void updateSampleOrderCustTestByStepId(DissSampleOrderMasterVO dissSampleOrderMasterVO){
		sqlSession.update(MAPPER_NAMESPACE + "updateSampleOrderCustTestByStepId",dissSampleOrderMasterVO);
	}

	@Override
	public int getSampleOrderCount(DissSampleOrderMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getSampleOrderCount", param);
	}

	@Override
	public List<DissSampleOrderMasterVO> getSampleOrderList(DissSampleOrderMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSampleOrderList", param);
	}

	@Override
	public List<DissSampleOrderMasterVO> getDissSampleListExcelDownload(DissSampleOrderMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissSampleListExcelDownload", param);
	}
}
