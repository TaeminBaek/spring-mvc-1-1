package com.lgmma.salesPortal.app.model;

public class ApprLineVO extends PagingParamVO {
	/* columns */
	private String apprId;
	private String apprLineType;
	private int    apprLineNo;
	private String apprEmpId;
	private String applTeamNm;
	private String applPosiNm;
	private String apprLineComment;
	private String applStat;
	private String apprLineDate;

	/* view columns */
	private String apprEmpName;
	private String applStatName;
	private String apprEmpEmail;
	private String apprEmpSawnId;
	private String apprEmpHpno;
	private String applTeamCd;
	private String applPosiCd;
	private String regiDateFmt;
	private String sawnName;
	private String apprTypeName;
	private String apprStatName;
	private String apprLineTypeName;

	/* 저장액션구분 */
	private String saveStatus;
	
	/* My 결재 조회용 column 추가*/
	private String apprType;
	private String apprStat;
	private String apprTitle;
	private String stepId;
	private String stepCd;
	private String taskId;
	private String taskType;
	private String processType;
	private String apprApplCheck;
	
	/* condition columns */
	private String loginEmpId;
	private String cRegiIdxx;
	private String cFrYmd;
	private String cToYmd;
	private String cApprTitle;
	private String cApplStat;
	private String cApprType;
	private String cApprStat;

	private String relApprId;

	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getApprLineType() {
		return apprLineType;
	}
	public void setApprLineType(String apprLineType) {
		this.apprLineType = apprLineType;
	}
	public int getApprLineNo() {
		return apprLineNo;
	}
	public void setApprLineNo(int apprLineNo) {
		this.apprLineNo = apprLineNo;
	}
	public String getApprEmpId() {
		return apprEmpId;
	}
	public void setApprEmpId(String apprEmpId) {
		this.apprEmpId = apprEmpId;
	}
	public String getApplTeamNm() {
		return applTeamNm;
	}
	public void setApplTeamNm(String applTeamNm) {
		this.applTeamNm = applTeamNm;
	}
	public String getApplPosiNm() {
		return applPosiNm;
	}
	public void setApplPosiNm(String applPosiNm) {
		this.applPosiNm = applPosiNm;
	}
	public String getApprLineComment() {
		return apprLineComment;
	}
	public void setApprLineComment(String apprLineComment) {
		this.apprLineComment = apprLineComment;
	}
	public String getApplStat() {
		return applStat;
	}
	public void setApplStat(String applStat) {
		this.applStat = applStat;
	}
	public String getApprLineDate() {
		return apprLineDate;
	}
	public void setApprLineDate(String apprLineDate) {
		this.apprLineDate = apprLineDate;
	}
	public String getApprEmpName() {
		return apprEmpName;
	}
	public void setApprEmpName(String apprEmpName) {
		this.apprEmpName = apprEmpName;
	}
	public String getApplStatName() {
		return applStatName;
	}
	public void setApplStatName(String applStatName) {
		this.applStatName = applStatName;
	}
	public String getApprEmpEmail() {
		return apprEmpEmail;
	}
	public void setApprEmpEmail(String apprEmpEmail) {
		this.apprEmpEmail = apprEmpEmail;
	}
	public String getApprEmpSawnId() {
		return apprEmpSawnId;
	}
	public void setApprEmpSawnId(String apprEmpSawnId) {
		this.apprEmpSawnId = apprEmpSawnId;
	}
	public String getApprEmpHpno() {
		return apprEmpHpno;
	}
	public void setApprEmpHpno(String apprEmpHpNo) {
		this.apprEmpHpno = apprEmpHpNo;
	}
	public String getApplTeamCd() {
		return applTeamCd;
	}
	public void setApplTeamCd(String applTeamCd) {
		this.applTeamCd = applTeamCd;
	}
	public String getApplPosiCd() {
		return applPosiCd;
	}
	public void setApplPosiCd(String applPosiCd) {
		this.applPosiCd = applPosiCd;
	}
	public String getSaveStatus() {
		return saveStatus;
	}
	public void setSaveStatus(String saveStatus) {
		this.saveStatus = saveStatus;
	}
	public String getApprType() {
		return apprType;
	}
	public void setApprType(String apprType) {
		this.apprType = apprType;
	}
	public String getApprStat() {
		return apprStat;
	}
	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}
	public String getApprTitle() {
		return apprTitle;
	}
	public void setApprTitle(String apprTitle) {
		this.apprTitle = apprTitle;
	}
	public String getRegiDateFmt() {
		return regiDateFmt;
	}
	public void setRegiDateFmt(String regiDateFmt) {
		this.regiDateFmt = regiDateFmt;
	}
	public String getSawnName() {
		return sawnName;
	}
	public void setSawnName(String sawnName) {
		this.sawnName = sawnName;
	}
	public String getApprTypeName() {
		return apprTypeName;
	}
	public void setApprTypeName(String apprTypeName) {
		this.apprTypeName = apprTypeName;
	}
	public String getApprStatName() {
		return apprStatName;
	}
	public void setApprStatName(String apprStatName) {
		this.apprStatName = apprStatName;
	}
	public String getApprLineTypeName() {
		return apprLineTypeName;
	}
	public void setApprLineTypeName(String apprLineTypeName) {
		this.apprLineTypeName = apprLineTypeName;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getStepCd() {
		return stepCd;
	}
	public void setStepCd(String stepCd) {
		this.stepCd = stepCd;
	}
	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}	
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public String getApprApplCheck() {
		return apprApplCheck;
	}
	public void setApprApplCheck(String apprApplCheck) {
		this.apprApplCheck = apprApplCheck;
	}
	public String getLoginEmpId() {
		return loginEmpId;
	}
	public void setLoginEmpId(String loginEmpId) {
		this.loginEmpId = loginEmpId;
	}
	public String getcRegiIdxx() {
		return cRegiIdxx;
	}
	public void setcRegiIdxx(String cRegiIdxx) {
		this.cRegiIdxx = cRegiIdxx;
	}
	public String getcFrYmd() {
		return cFrYmd;
	}
	public void setcFrYmd(String cFrYmd) {
		this.cFrYmd = cFrYmd;
	}
	public String getcToYmd() {
		return cToYmd;
	}
	public void setcToYmd(String cToYmd) {
		this.cToYmd = cToYmd;
	}
	public String getcApprTitle() {
		return cApprTitle;
	}
	public void setcApprTitle(String cApprTitle) {
		this.cApprTitle = cApprTitle;
	}
	public String getcApplStat() {
		return cApplStat;
	}
	public void setcApplStat(String cApplStat) {
		this.cApplStat = cApplStat;
	}
	public String getcApprType() {
		return cApprType;
	}
	public void setcApprType(String cApprType) {
		this.cApprType = cApprType;
	}
	public String getcApprStat() {
		return cApprStat;
	}
	public void setcApprStat(String cApprStat) {
		this.cApprStat = cApprStat;
	}
	public String getRelApprId() {
		return relApprId;
	}
	public void setRelApprId(String relApprId) {
		this.relApprId = relApprId;
	}
}
