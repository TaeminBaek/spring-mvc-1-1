package com.lgmma.salesPortal.partnerapp.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.ProductStockVO;
import com.lgmma.salesPortal.app.service.StockDisplayMgmtService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.Vkorg;


@Controller
@RequestMapping("/partner")
public class PartnerStockController {

	@Autowired
	StockDisplayMgmtService stockDisplayMgmtService;
	
	@RequestMapping(value = "/stockInfo")
	public ModelAndView stockInfo(ModelAndView mav) throws Exception {
		mav.setViewName("partner/stock/stockInfo");
		//PMMA 만 사용
		mav.addObject("vkorg", "3000");
		mav.addObject("vkorgText", Vkorg.getVkorg("3000").getName());
		return mav;
	}

	@RequestMapping(value = "/getProductInStock")
	public Map getProductInStock(@RequestBody ProductStockVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", stockDisplayMgmtService.getProductInStockCount(param), "storeData", stockDisplayMgmtService.getProductInStockList(param));
	}
}
