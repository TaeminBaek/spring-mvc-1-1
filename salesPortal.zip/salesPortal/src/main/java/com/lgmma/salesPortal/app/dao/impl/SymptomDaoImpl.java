package com.lgmma.salesPortal.app.dao.impl;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.SymptomDao;
import com.lgmma.salesPortal.app.model.CustomerCreditAssessInquiryVO;
import com.lgmma.salesPortal.app.model.SalesPriceChageRateVO;
import com.lgmma.salesPortal.app.model.SalesTrendByProdAccontVO;

@Repository
public class SymptomDaoImpl implements SymptomDao {

	private static final String MAPPER_NAMESPACE = "SYMPTOM_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;
    
    public int getSalesPriceChageRateListCount(SalesPriceChageRateVO param) {
    	return sqlSession.selectOne(MAPPER_NAMESPACE + "getSalesPriceChageRateListCount", param);
    
    }

	@Override
	public List<SalesPriceChageRateVO> getSalesPriceChageRateList(SalesPriceChageRateVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSalesPriceChageRateList", param);
	}

	@Override
	public int getSalesTrendByProdAccontCount(SalesTrendByProdAccontVO param) {		
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getSalesTrendByProdAccontListCount", param);
	}

	@Override
	public List<SalesTrendByProdAccontVO> getSalesTrendByProdAccontList(SalesTrendByProdAccontVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSalesTrendByProdAccontList", param);
	}

	@Override
	public int getCustomerCreditAssessInquiryCount(CustomerCreditAssessInquiryVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCustomerCreditAssessInquiryCount", param);
	}
	
	@Override
	public List<CustomerCreditAssessInquiryVO> getCustomerCreditAssessInquiryList(CustomerCreditAssessInquiryVO param) {		
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCustomerCreditAssessInquiryList", param);
	}

	@Override
	public Map<String, Object> getCustomerBaseInfo(CustomerCreditAssessInquiryVO param) {		
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCustomerBaseInfo", param);
	}

	@Override
	public List<Map<String, Object>> getCustomerCreditRating(CustomerCreditAssessInquiryVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCustomerCreditRating", param);
	}

	@Override
	public List<Map<String, Object>> getCustomerStockHolder(CustomerCreditAssessInquiryVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCustomerStockHolder", param);
	}

	@Override
	public List<Map<String, Object>> getCustomerFinancialInfo(CustomerCreditAssessInquiryVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCustomerFinancialInfo", param);
	}

	@Override
	public List<Map<String, Object>> getCustomerFinancialRatio(CustomerCreditAssessInquiryVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCustomerFinancialRatio", param);
	}

	@Override
	public List<Map<String, Object>> getCustomerMajorCustomer(CustomerCreditAssessInquiryVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCustomerMajorCustomer", param);
	}

	@Override
	public List<Map<String, Object>> getRelatedCompany(CustomerCreditAssessInquiryVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getRelatedCompany", param);
	}

}
