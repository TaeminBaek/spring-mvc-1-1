package com.lgmma.salesPortal.app.model;

public class SalesContinuityDecreaseVO extends PagingParamVO {
	
	private String salesOrg;
	private String distrChan;
	private String gjahr;		
	private String cApprEmpId;	
	private String cApprEmpNm;
	
	private String spart;
	private String vtweg;
	private String kunnr;
	private String name1;
	private String ename;
	private String waerk;
	private String ummenge;
	private String ummengeUpdown;
	private String zzfield1;
	private String zzfield1Updown;
	private String ummengeBm;
	private String ummengeBmUpdown;
	private String zzfield1Bm;
	private String zzfield1BmUpdown;
	private String ummengeBbm;
	private String ummengeBbmUpdown;
	private String zzfield1Bbm;
	private String zzfield1BbmUpdown;
	
	
	public String getSalesOrg() {
		return salesOrg;
	}
	
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	
	public String getDistrChan() {
		return distrChan;
	}
	
	public void setDistrChan(String distrChan) {
		this.distrChan = distrChan;
	}
	
	public String getGjahr() {
		return gjahr;
	}
	
	public void setGjahr(String gjahr) {
		this.gjahr = gjahr;
	}
	
	public String getcApprEmpId() {
		return cApprEmpId;
	}
	
	public void setcApprEmpId(String cApprEmpId) {
		this.cApprEmpId = cApprEmpId;
	}
	
	public String getcApprEmpNm() {
		return cApprEmpNm;
	}
	
	public void setcApprEmpNm(String cApprEmpNm) {
		this.cApprEmpNm = cApprEmpNm;
	}
	
	public String getSpart() {
		return spart;
	}
	
	public void setSpart(String spart) {
		this.spart = spart;
	}
	
	public String getVtweg() {
		return vtweg;
	}
	
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	
	public String getKunnr() {
		return kunnr;
	}
	
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	
	public String getName1() {
		return name1;
	}
	
	public void setName1(String name1) {
		this.name1 = name1;
	}
	
	public String getEname() {
		return ename;
	}
	
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	public String getUmmenge() {
		return ummenge;
	}
	
	public void setUmmenge(String ummenge) {
		this.ummenge = ummenge;
	}
	
	public String getUmmengeUpdown() {
		return ummengeUpdown;
	}
	
	public void setUmmengeUpdown(String ummengeUpdown) {
		this.ummengeUpdown = ummengeUpdown;
	}
	
	public String getZzfield1() {
		return zzfield1;
	}
	
	public void setZzfield1(String zzfield1) {
		this.zzfield1 = zzfield1;
	}
	
	public String getZzfield1Updown() {
		return zzfield1Updown;
	}
	
	public void setZzfield1Updown(String zzfield1Updown) {
		this.zzfield1Updown = zzfield1Updown;
	}
	
	public String getUmmengeBm() {
		return ummengeBm;
	}
	
	public void setUmmengeBm(String ummengeBm) {
		this.ummengeBm = ummengeBm;
	}
	
	public String getUmmengeBmUpdown() {
		return ummengeBmUpdown;
	}
	
	public void setUmmengeBmUpdown(String ummengeBmUpdown) {
		this.ummengeBmUpdown = ummengeBmUpdown;
	}
	
	public String getZzfield1Bm() {
		return zzfield1Bm;
	}
	
	public void setZzfield1Bm(String zzfield1Bm) {
		this.zzfield1Bm = zzfield1Bm;
	}
	
	public String getZzfield1BmUpdown() {
		return zzfield1BmUpdown;
	}
	
	public void setZzfield1BmUpdown(String zzfield1BmUpdown) {
		this.zzfield1BmUpdown = zzfield1BmUpdown;
	}
	
	public String getUmmengeBbm() {
		return ummengeBbm;
	}
	
	public void setUmmengeBbm(String ummengeBbm) {
		this.ummengeBbm = ummengeBbm;
	}
	
	public String getUmmengeBbmUpdown() {
		return ummengeBbmUpdown;
	}
	
	public void setUmmengeBbmUpdown(String ummengeBbmUpdown) {
		this.ummengeBbmUpdown = ummengeBbmUpdown;
	}
	
	public String getZzfield1Bbm() {
		return zzfield1Bbm;
	}
	
	public void setZzfield1Bbm(String zzfield1Bbm) {
		this.zzfield1Bbm = zzfield1Bbm;
	}
	
	public String getZzfield1BbmUpdown() {
		return zzfield1BbmUpdown;
	}
	
	public void setZzfield1BbmUpdown(String zzfield1BbmUpdown) {
		this.zzfield1BbmUpdown = zzfield1BbmUpdown;
	}

	public String getWaerk() {
		return waerk;
	}

	public void setWaerk(String waerk) {
		this.waerk = waerk;
	}
	
}
