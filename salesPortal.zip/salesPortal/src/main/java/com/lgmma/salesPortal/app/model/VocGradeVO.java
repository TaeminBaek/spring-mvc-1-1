package com.lgmma.salesPortal.app.model;

public class VocGradeVO extends PagingParamVO {
	
	//TBS_VOCMGRADE
	private String seqxNumx;	//일련번호
	private int vocxIdxx;    //VOC ID
	private String prodIdxx;    //제품코드
	private String oldxPric;    //기존가격
	private String reqxPric;    //요청가격
	private String usgxQtyx;    //월사용수량
	private String qtyxUnit;    //월사용량단위
	private String qtyxUnit2;   //요청단위
	private String prodUsgx;    //용도
	
	public String getSeqxNumx() {
		return seqxNumx;
	}
	public void setSeqxNumx(String seqxNumx) {
		this.seqxNumx = seqxNumx;
	}
	public int getVocxIdxx() {
		return vocxIdxx;
	}
	public void setVocxIdxx(int vocxIdxx) {
		this.vocxIdxx = vocxIdxx;
	}
	public String getProdIdxx() {
		return prodIdxx;
	}
	public void setProdIdxx(String prodIdxx) {
		this.prodIdxx = prodIdxx;
	}
	public String getOldxPric() {
		return oldxPric;
	}
	public void setOldxPric(String oldxPric) {
		this.oldxPric = oldxPric;
	}
	public String getReqxPric() {
		return reqxPric;
	}
	public void setReqxPric(String reqxPric) {
		this.reqxPric = reqxPric;
	}
	public String getUsgxQtyx() {
		return usgxQtyx;
	}
	public void setUsgxQtyx(String usgxQtyx) {
		this.usgxQtyx = usgxQtyx;
	}
	public String getQtyxUnit() {
		return qtyxUnit;
	}
	public void setQtyxUnit(String qtyxUnit) {
		this.qtyxUnit = qtyxUnit;
	}
	public String getQtyxUnit2() {
		return qtyxUnit2;
	}
	public void setQtyxUnit2(String qtyxUnit2) {
		this.qtyxUnit2 = qtyxUnit2;
	}
	public String getProdUsgx() {
		return prodUsgx;
	}
	public void setProdUsgx(String prodUsgx) {
		this.prodUsgx = prodUsgx;
	}
	
}
