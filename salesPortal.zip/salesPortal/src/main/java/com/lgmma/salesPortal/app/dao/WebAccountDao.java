package com.lgmma.salesPortal.app.dao;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.LoginMastVO;
import com.lgmma.salesPortal.app.model.LoginReqVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;

public interface WebAccountDao {

	int getNewWebAccountRequestsCount(LoginReqVO param);

	List<LoginReqVO> getNewWebAccountRequests(LoginReqVO param);

	LoginReqVO getWebAccountRequestDetail(LoginReqVO param);

	void updateWebAccountStatus(LoginReqVO param);

	int getExistsBizNumCount(String bizxNumx);

	int getExistsLoginIdCount(String string);

	void updateLoginCompByLoginReq(LoginReqVO param);

	int createLoginCompByLoginReq(LoginReqVO param);

	void createLoginUser(LoginReqVO param);

	int getWebAccountListCount(LoginUserVO param);

	List<LoginUserVO> getWebAccountList(LoginUserVO param);

	LoginUserVO getWebAccountDetail(LoginUserVO param);

	int getWebAccountCompListCount(LoginMastVO param);

	List<LoginMastVO> getWebAccountCompList(LoginMastVO param);

	void initWebAccountPassword(LoginUserVO param);

	void updateLoginUser(LoginUserVO param);

	void updateLoginComp(LoginUserVO param);

	void deleteLoginMast(LoginMastVO param);

	void createLoginMast(LoginMastVO param);

	void moveCustOfWebAccount(Map<String, String> loginMast);


}
