package com.lgmma.salesPortal.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.dao.CodeGroupDao;
import com.lgmma.salesPortal.app.dao.CommonCodeDao;
import com.lgmma.salesPortal.app.model.CodeGroupVO;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.service.CommonCodeMgmtService;

@Service
public class CommonCodeMgmtServiceImpl implements CommonCodeMgmtService{
	
	@Autowired
	private CodeGroupDao codeGroupDao;
	@Autowired
	private CommonCodeDao commonCodeDao;

	@Override
	public int getCodeGroupCount(CodeGroupVO param) {
		return codeGroupDao.getCodeGroupCount(param);
	}
	
	@Override
	public List<CodeGroupVO> getCodeGroupList(CodeGroupVO param) {
		return codeGroupDao.getCodeGroupList(param);
	}
	
	@Override
	public void updateCodeGroup(CodeGroupVO param) {
		codeGroupDao.updateCodeGroup(param);
	}

	@Override
	public void createCodeGroup(CodeGroupVO param) {
		codeGroupDao.createCodeGroup(param);
	}

	@Override
	public int getCommonCodeCount(CommonCodeVO param) {
		return commonCodeDao.getCommonCodeCount(param);
	}

	@Override
	public List<CommonCodeVO> getCommonCodeList(CommonCodeVO param) {
		return commonCodeDao.getCommonCodeList(param);
	}
	
	@Override
	public void updateCommonCode(CommonCodeVO param) {
		commonCodeDao.updateCommonCode(param);
	}

	@Override
	public void createCommonCode(CommonCodeVO param) {
		commonCodeDao.createCommonCode(param);
	}



}
