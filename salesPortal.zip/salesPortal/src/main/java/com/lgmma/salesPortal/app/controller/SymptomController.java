package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.CollectAccountDetailVO;
import com.lgmma.salesPortal.app.model.CollectExpectedDateVO;
import com.lgmma.salesPortal.app.model.CreditLimitRateVO;
import com.lgmma.salesPortal.app.model.CustBondOverdueInformationVO;
import com.lgmma.salesPortal.app.model.CustomerCreditAssessInquiryVO;
import com.lgmma.salesPortal.app.model.OperatingProfitContinuityDecreaseVO;
import com.lgmma.salesPortal.app.model.SalesContinuityDecreaseVO;
import com.lgmma.salesPortal.app.model.SalesPrepareIncreaseVO;
import com.lgmma.salesPortal.app.model.SalesPriceChageRateVO;
import com.lgmma.salesPortal.app.model.SalesTrendByProdAccontVO;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.app.service.SymptomService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

import freemarker.template.Configuration;

@Controller
@RequestMapping("/symptom")
public class SymptomController {

	@Autowired
	private SymptomService symptomService;

	@Autowired
	private CommonController commonController;

	@Autowired
	private SapSearchService sapSearchService;

	@Autowired
	@Qualifier(value = "excelFreemarkerConfiguration")
	private Configuration excelFreemarkerConfiguration;

	private final String SALES_PRICE_CHANGE_RATE_EXCEL_TEMPLATE = "SALES_PRICE_CHANGE_RATE_EXCEL_TEMPLATE";
	private final String SALES_TREND_BY_PROD_ACCONT_EXCEL_TEMPLATE = "SALES_TREND_BY_PROD_ACCONT_EXCEL_TEMPLATE";
	private final String COLLECT_ACCONT_DETAIL_EXCEL_TEMPLATE = "COLLECT_ACCONT_DETAIL_EXCEL_DOWNLOAD";
	private final String COLLECT_EXPECTED_DATE_EXCEL_TEMPLATE = "COLLECT_EXPECTED_DATE_EXCEL_DOWNLOAD";
	private final String SALES_PREPARE_INCREASE_EXCEL_TEMPLATE = "SALES_PREPARE_INCREASE_EXCEL_DOWNLOAD";
	private final String SALES_CONTINUITY_DECREASE_EXCEL_TEMPLATE = "SALES_CONTINUITY_DECREASE_EXCEL_DOWNLOAD";
	private final String OPER_PROFIT_DECREASE_EXCEL_TEMPLATE = "OPER_PROFIT_DECREASE_EXCEL_DOWNLOAD";
	private final String CREDIT_LIMIT_RATE_EXCEL_TEMPLATE = "CREDIT_LIMIT_RATE_EXCEL_DOWNLOAD";
	private final String CUST_BOND_OVERDUE_INFO_EXCEL_DOWNLOAD = "CUST_BOND_OVERDUE_INFO_EXCEL_DOWNLOAD";
	private final String CORPORATE_INFORMATION_REPORT_EXCEL_TEMPLATE = "CORPORATE_INFORMATION_REPORT_EXCEL_DOWNLOAD";

	private static Logger logger = LoggerFactory.getLogger(SymptomController.class);

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;

	// 판가변동율
	@RequestMapping(value = "/salesPriceChageRate")
	public ModelAndView salesPriceChageRateList(ModelAndView mav, SalesPriceChageRateVO param) throws Exception {
		mav.setViewName("symptom/salesPriceChageRate");
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
//		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear() + "." + DateUtil.getToday().substring(4, 6));
		mav.addObject("defaultYyyyMm", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1).substring(0, 6)));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -2).substring(0, 6)));
		mav.addObject("apprStatList", ApprState.getDissApprStatList());

		return mav;
	}

	@RequestMapping(value = "/getSalesPriceChageRateList.json")
	public Map getSalesPriceChageRateList(@RequestBody(required = true) SalesPriceChageRateVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", symptomService.getSalesPriceChageRateListCount(param), "storeData", symptomService.getSalesPriceChageRateList(param), "defaultYyyyMm", DateUtil.defaultFormatDate(param.getSpmon().replace(".", "")), "prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(param.getSpmon().replace(".", "") + "01", -1).substring(0, 6)));
	}

	@RequestMapping(value = "/salesPriceChageRateExcelDownload", method = RequestMethod.POST)
	public void salesPriceChageRateExcelDownload(SalesPriceChageRateVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		req.setCharacterEncoding("euc-kr");

		List<SalesPriceChageRateVO> salesPriceChageRateList = symptomService.getSalesPriceChageRateList(param);
		List<SalesPriceChageRateVO> copySalesPriceChageRateList = new ArrayList<SalesPriceChageRateVO>();

		for (SalesPriceChageRateVO salePriceChangeRate : salesPriceChageRateList)
			copySalesPriceChageRateList.add((SalesPriceChageRateVO) StringUtil.nullToEmptyString(salePriceChangeRate));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("salesPriceChageRateList", copySalesPriceChageRateList);
		paramMap.put("defaultYyyyMm", DateUtil.defaultFormatDate(param.getSpmon().replace(".", "")));
		paramMap.put("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(param.getSpmon().replace(".", "") + "01", -1).substring(0, 6)));

		try {
			StringBuffer content = new StringBuffer();
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate(SALES_PRICE_CHANGE_RATE_EXCEL_TEMPLATE + ".txt"), paramMap));

			String fileName = java.net.URLEncoder.encode("판가변동율_Download_" + Util.getToday("yyyyMMdd"), "UTF-8");
			String ext = ".xls";

			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie", "fileDownload=true; path=/");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ext + "\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();
		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:" + e.getMessage());
		}
	}

	// 제품별, 거래처별 판가 Trend
	@RequestMapping(value = "/salesTrendByProdAccont")
	public ModelAndView salesTrendByProdAccont(ModelAndView mav, SalesTrendByProdAccontVO param) throws Exception {
		mav.setViewName("symptom/salesTrendByProdAccont");
		//고객그룹 3
		mav.addObject("kvgr3List", commonController.getSapCommonCodeListWithAllDDLB("12").get("items"));
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
//		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear() + "." + DateUtil.getToday().substring(4, 6));
		mav.addObject("defaultYyyyMm", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1).substring(0, 6)));
		mav.addObject("yyyyMmHeaderList", getYyyyMmHeaderList(DateUtil.addMonth(DateUtil.getToday(),-1).substring(0, 6), 6));

		return mav;
	}

	private List getYyyyMmHeaderList(String startYyyyMm, int size) {
		startYyyyMm = startYyyyMm + "01";
		List<String> yyyyMmList = new ArrayList<String>();
		for(int i = 0 ; i < size ; i++) {
			yyyyMmList.add(DateUtil.defaultFormatDate(DateUtil.addMonth(startYyyyMm, -i).substring(0, 6)));
		}
		return yyyyMmList;
	}

	@RequestMapping(value = "/getSalesTrendByProdAccontList.json")
	public Map getSalesTrendByProdAccontList(@RequestBody(required = true) SalesTrendByProdAccontVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", symptomService.getSalesTrendByProdAccontCount(param), "storeData", symptomService.getSalesTrendByProdAccontList(param), "yyyyMmHeaderList", getYyyyMmHeaderList(param.getSpmon(), 6));
	}

	@RequestMapping(value = "/salesTrendByProdAccontExcelDownload", method = RequestMethod.POST)
	public void salesTrendByProdAccontExcelDownload(SalesTrendByProdAccontVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		req.setCharacterEncoding("euc-kr");

		List<SalesTrendByProdAccontVO> salesTrendByProdAccontList = symptomService.getSalesTrendByProdAccontList(param);
		List<SalesTrendByProdAccontVO> copySalesTrendByProdAccontList = new ArrayList<SalesTrendByProdAccontVO>();

		for (SalesTrendByProdAccontVO salesTrendByProdAccont : salesTrendByProdAccontList)
			copySalesTrendByProdAccontList.add((SalesTrendByProdAccontVO) StringUtil.nullToEmptyString(salesTrendByProdAccont));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("salesTrendByProdAccontList", copySalesTrendByProdAccontList);
		paramMap.put("yyyyMmHeaderList", getYyyyMmHeaderList(param.getSpmon(), 6));
		try {
			StringBuffer content = new StringBuffer();
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate(SALES_TREND_BY_PROD_ACCONT_EXCEL_TEMPLATE + ".txt"), paramMap));

			String fileName = java.net.URLEncoder.encode("제품별,거래처별_판가_Trend_Download_" + Util.getToday("yyyyMMdd"), "UTF-8");
			String ext = ".xls";

			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie", "fileDownload=true; path=/");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ext + "\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();
		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:" + e.getMessage());
		}
	}

	// 수금 계좌 입금 명세 조회
	@RequestMapping(value = "/collectAccountDetail")
	public ModelAndView collectAccountDetail(ModelAndView mav, CollectAccountDetailVO param) throws Exception {
		mav.setViewName("symptom/collectAccountDetail");
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear() + "." + DateUtil.getToday().substring(4, 6));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));

		return mav;
	}

	@RequestMapping(value = "/getCollectAccountDetailList.json")
	public Map getCollectAccountDetailList(@RequestBody(required = false) CollectAccountDetailVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", sapSearchService.getCollectAccountDetailList(param));
	}

	@RequestMapping(value = "/collectAccountDetailExcelDownload", method = RequestMethod.POST)
	public void collectAccountDetailExcelDownload(CollectAccountDetailVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		param.setPrmsdate(param.getPrmsdate().replace(".", ""));
		param.setPrmedate(param.getPrmedate().replace(".", ""));

		req.setCharacterEncoding("euc-kr");

		List<CollectAccountDetailVO> collectAccountDetailList = sapSearchService.getCollectAccountDetailList(param);
		List<CollectAccountDetailVO> copycollectAccountDetailList = new ArrayList<CollectAccountDetailVO>();

		for (CollectAccountDetailVO accountVO : collectAccountDetailList)
			copycollectAccountDetailList.add((CollectAccountDetailVO) StringUtil.nullToEmptyString(accountVO));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("collectAccountDetailList", copycollectAccountDetailList);

		try {
			StringBuffer content = new StringBuffer();
			// contents 생성 (html)
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate(COLLECT_ACCONT_DETAIL_EXCEL_TEMPLATE + ".txt"), paramMap));

			// contents 내보내기 (xls)
			String fileName = "수금계좌입금명세조회_Download_" + Util.getToday("yyyyMMdd");
			String ext = ".xls";
			fileName = java.net.URLEncoder.encode(fileName, "UTF-8");

			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie", "fileDownload=true; path=/");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ext + "\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();

		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:" + e.getMessage());
		}

	}

	// 수츨 수금 예정일 현황
	@RequestMapping(value = "/collectExpectedDate")
	public ModelAndView collectExpectedDate(ModelAndView mav, CollectAccountDetailVO param) throws Exception {
		mav.setViewName("symptom/collectExpectedDate");
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear() + "." + DateUtil.getToday().substring(4, 6));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));

		return mav;
	}

	@RequestMapping(value = "/getCollectExpectedDateList.json")
	public Map getCollectExpectedDateList(@RequestBody(required = false) CollectExpectedDateVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", sapSearchService.getCollectExpectedDateList(param));
	}

	@RequestMapping(value = "/collectExpectedDateExcelDownload", method = RequestMethod.POST)
	public void collectExpectedDateExcelDownload(CollectExpectedDateVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		param.setGjahr(param.getGjahr().replace(".", ""));
		req.setCharacterEncoding("euc-kr");

		List<CollectExpectedDateVO> collectExpectedDateList = sapSearchService.getCollectExpectedDateList(param);
		List<CollectExpectedDateVO> copycollectExpectedDateList = new ArrayList<CollectExpectedDateVO>();

		for (CollectExpectedDateVO ExpectedVO : collectExpectedDateList)
			copycollectExpectedDateList.add((CollectExpectedDateVO) StringUtil.nullToEmptyString(ExpectedVO));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("collectExpectedDateList", copycollectExpectedDateList);

		try {
			StringBuffer content = new StringBuffer();
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate(COLLECT_EXPECTED_DATE_EXCEL_TEMPLATE + ".txt"), paramMap));

			String fileName = "수출수금예정일현황_Download_" + Util.getToday("yyyyMMdd");
			String ext = ".xls";
			fileName = java.net.URLEncoder.encode(fileName, "UTF-8");

			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie", "fileDownload=true; path=/");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ext + "\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();
		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:" + e.getMessage());
		}
	}

	// 기존 매출 대비 증가/감소
	@RequestMapping(value = "/salesPrepareIncrease")
	public ModelAndView salesPrepareIncrease(ModelAndView mav, CollectAccountDetailVO param) throws Exception {
		mav.setViewName("symptom/salesPrepareIncrease");
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
//		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear() + "." + DateUtil.getToday().substring(4, 6));
		mav.addObject("defaultYyyyMm", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1).substring(0, 6)));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -2).substring(0, 6)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), 1)));
		mav.addObject("yyyyMmHeaderList", getYyyyMmHeaderList(DateUtil.addMonth(DateUtil.getToday(),-1).substring(0, 6), 2));
		mav.addObject("prevYyyyMm", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -13).substring(0, 6)));

		return mav;
	}

	@RequestMapping(value = "/getSalesPrepareIncreaseList.json")
	public Map getSalesPrepareIncreaseList(@RequestBody(required = false) SalesPrepareIncreaseVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", sapSearchService.getSalesPrepareIncreaseList(param), "yyyyMmHeaderList", getYyyyMmHeaderList(param.getGjahr().replace(".", ""), 2), "prevYyyyMm", DateUtil.defaultFormatDate(DateUtil.addMonth(param.getGjahr().replace(".", "") + "01", -12).substring(0, 6)), "prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(param.getGjahr().replace(".", "") + "01", -1).substring(0, 6)));
	}

	@RequestMapping(value = "/salesPrepareIncreaseExcelDownload", method = RequestMethod.POST)
	public void salesPrepareIncreaseExcelDownload(SalesPrepareIncreaseVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		param.setGjahr(param.getGjahr().replace(".", ""));
		req.setCharacterEncoding("euc-kr");

		List<SalesPrepareIncreaseVO> salesPrepareIncreaseList = sapSearchService.getSalesPrepareIncreaseList(param);
		List<SalesPrepareIncreaseVO> copySalesPrepareIncreaseList = new ArrayList<SalesPrepareIncreaseVO>();

		for (SalesPrepareIncreaseVO SalesVO : salesPrepareIncreaseList)
			copySalesPrepareIncreaseList.add((SalesPrepareIncreaseVO) StringUtil.nullToEmptyString(SalesVO));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("searchCondition", param);
		paramMap.put("salesPrepareIncreaseList", copySalesPrepareIncreaseList);
		paramMap.put("yyyyMmHeaderList", getYyyyMmHeaderList(param.getGjahr().replace(".", ""), 2));
		paramMap.put("prevYyyyMm", DateUtil.defaultFormatDate(DateUtil.addMonth(param.getGjahr().replace(".", "") + "01", -12).substring(0, 6)));
		paramMap.put("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(param.getGjahr().replace(".", "") + "01", -1).substring(0, 6)));

		try {
			StringBuffer content = new StringBuffer();
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate(SALES_PREPARE_INCREASE_EXCEL_TEMPLATE + ".txt"), paramMap));

			String fileName = "기존매출대비증가감소_Download_" + Util.getToday("yyyyMMdd");
			String ext = ".xls";
			fileName = java.net.URLEncoder.encode(fileName, "UTF-8");

			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie", "fileDownload=true; path=/");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ext + "\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();
		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:" + e.getMessage());
		}
	}

	// 매출 연속 감소
	@RequestMapping(value = "/salesContinuityDecrease")
	public ModelAndView salesContinuityDecrease(ModelAndView mav, SalesContinuityDecreaseVO param) throws Exception {
		mav.setViewName("symptom/salesContinuityDecrease");
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("defaultYyyyMm", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1).substring(0, 6)));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), 1)));
		mav.addObject("yyyyMmHeaderList", getYyyyMmHeaderList(DateUtil.addMonth(DateUtil.getToday(),-1).substring(0, 6), 3));
		return mav;
	}

	@RequestMapping(value = "/getSalesContinuityDecreaseList.json")
	public Map getSalesContinuityDecreaseList(@RequestBody(required = false) SalesContinuityDecreaseVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", sapSearchService.getSalesContinuityDecreaseList(param), "yyyyMmHeaderList", getYyyyMmHeaderList(param.getGjahr().replace(".", ""), 3));
	}

	@RequestMapping(value = "/salesContinuityDecreaseExcelDownload", method = RequestMethod.POST)
	public void salesContinuityDecreaseExcelDownload(SalesContinuityDecreaseVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		param.setGjahr(param.getGjahr().replace(".", ""));
		req.setCharacterEncoding("euc-kr");

		List<SalesContinuityDecreaseVO> salesContinuityDecreaseList = sapSearchService.getSalesContinuityDecreaseList(param);
		List<SalesContinuityDecreaseVO> copysalesContinuityDecreaseList = new ArrayList<SalesContinuityDecreaseVO>();

		for (SalesContinuityDecreaseVO SalesDcsVO : salesContinuityDecreaseList)
			copysalesContinuityDecreaseList.add((SalesContinuityDecreaseVO) StringUtil.nullToEmptyString(SalesDcsVO));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("salesContinuityDecreaseList", copysalesContinuityDecreaseList);
		paramMap.put("yyyyMmHeaderList", getYyyyMmHeaderList(param.getGjahr(), 3));

		try {
			StringBuffer content = new StringBuffer();
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate(SALES_CONTINUITY_DECREASE_EXCEL_TEMPLATE + ".txt"), paramMap));

			String fileName = "매출연속감소_Download_" + Util.getToday("yyyyMMdd");
			String ext = ".xls";
			fileName = java.net.URLEncoder.encode(fileName, "UTF-8");

			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie", "fileDownload=true; path=/");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ext + "\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();
		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:" + e.getMessage());
		}
	}

	// 영업이익/이익률 연속 감소
	@RequestMapping(value = "/operatingProfitContinuityDecrease")
	public ModelAndView operatingProfitContinuityDecrease(ModelAndView mav, OperatingProfitContinuityDecreaseVO param) throws Exception {
		mav.setViewName("symptom/operatingProfitContinuityDecrease");
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
//		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear() + "." + DateUtil.getToday().substring(4, 6));
		mav.addObject("defaultYyyyMm", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1).substring(0, 6)));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), 1)));
		mav.addObject("yyyyMmHeaderList", getYyyyMmHeaderList(DateUtil.addMonth(DateUtil.getToday(),-1).substring(0, 6), 3));

		return mav;
	}

	@RequestMapping(value = "/getOperatingProfitContinuityDecreaseList.json")
	public Map getOperatingProfitContinuityDecreaseList(@RequestBody(required = false) OperatingProfitContinuityDecreaseVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", sapSearchService.getOperatingProfitContinuityDecreaseList(param), "yyyyMmHeaderList", getYyyyMmHeaderList(param.getGjahr().replace(".", ""), 3));
	}

	@RequestMapping(value = "/operatingProfitContinuityDecreaseExcelDownload", method = RequestMethod.POST)
	public void operatingProfitContinuityDecreaseExcelDownload(OperatingProfitContinuityDecreaseVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		param.setGjahr(param.getGjahr().replace(".", ""));
		req.setCharacterEncoding("euc-kr");

		List<OperatingProfitContinuityDecreaseVO> operatingProfitContinuityDecreaseList = sapSearchService.getOperatingProfitContinuityDecreaseList(param);
		List<OperatingProfitContinuityDecreaseVO> copyOperatingProfitContinuityDecreaseList = new ArrayList<OperatingProfitContinuityDecreaseVO>();

		for (OperatingProfitContinuityDecreaseVO OpeProfitVO : operatingProfitContinuityDecreaseList)
			copyOperatingProfitContinuityDecreaseList.add((OperatingProfitContinuityDecreaseVO) StringUtil.nullToEmptyString(OpeProfitVO));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("operatingProfitContinuityDecreaseList", copyOperatingProfitContinuityDecreaseList);
		paramMap.put("yyyyMmHeaderList", getYyyyMmHeaderList(param.getGjahr(), 3));

		try {
			StringBuffer content = new StringBuffer();
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate(OPER_PROFIT_DECREASE_EXCEL_TEMPLATE + ".txt"), paramMap));

			String fileName = "영업이익_연속감소_Download_" + Util.getToday("yyyyMMdd");
			String ext = ".xls";
			fileName = java.net.URLEncoder.encode(fileName, "UTF-8");

			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie", "fileDownload=true; path=/");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ext + "\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();
		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:" + e.getMessage());
		}
	}

	// 여신한도 변동율
	@RequestMapping(value = "/creditLimitRate")
	public ModelAndView creditLimitRate(ModelAndView mav, CreditLimitRateVO param) throws Exception {
		mav.setViewName("symptom/creditLimitRate");
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
//		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear() + "." + DateUtil.getToday().substring(4, 6));
		mav.addObject("defaultYyyyMm", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1).substring(0, 6)));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -2).substring(0, 6)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), 1)));
		mav.addObject("yyyyMmHeaderList", getYyyyMmHeaderList(DateUtil.addMonth(DateUtil.getToday(),-2).substring(0, 6), 5));

		return mav;
	}

	@RequestMapping(value = "/getCreditLimitRateList.json")
	public Map getCreditLimitRateList(@RequestBody(required = false) CreditLimitRateVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", sapSearchService.getCreditLimitRateList(param), "defaultYyyyMm", DateUtil.defaultFormatDate(param.getGjahr().replace(".", "")), "yyyyMmHeaderList", getYyyyMmHeaderList(DateUtil.addMonth(param.getGjahr().replace(".", "") + "01", -1).substring(0, 6), 5), "prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(param.getGjahr().replace(".", "") + "01", -1).substring(0, 6)));
	}

	@RequestMapping(value = "/creditLimitRateExcelDownload", method = RequestMethod.POST)
	public void creditLimitRateExcelDownload(CreditLimitRateVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		param.setGjahr(param.getGjahr().replace(".", ""));
		req.setCharacterEncoding("euc-kr");

		List<CreditLimitRateVO> creditLimitRateList = sapSearchService.getCreditLimitRateList(param);
		List<CreditLimitRateVO> copycreditLimitRateList = new ArrayList<CreditLimitRateVO>();

		for (CreditLimitRateVO limitRateVO : creditLimitRateList)
			copycreditLimitRateList.add((CreditLimitRateVO) StringUtil.nullToEmptyString(limitRateVO));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("creditLimitRateList", copycreditLimitRateList);
		paramMap.put("yyyyMmHeaderList", getYyyyMmHeaderList(DateUtil.addMonth(param.getGjahr().replace(".", "") + "01", -1).substring(0, 6), 5));
		paramMap.put("defaultYyyyMm", DateUtil.defaultFormatDate(param.getGjahr().replace(".", "")));
		paramMap.put("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(param.getGjahr().replace(".", "") + "01", -1).substring(0, 6)));

		try {
			StringBuffer content = new StringBuffer();
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate(CREDIT_LIMIT_RATE_EXCEL_TEMPLATE + ".txt"), paramMap));

			String fileName = "여신한도변동율_Download_" + Util.getToday("yyyyMMdd");
			String ext = ".xls";
			fileName = java.net.URLEncoder.encode(fileName, "UTF-8");

			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie", "fileDownload=true; path=/");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ext + "\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();
		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:" + e.getMessage());
		}
	}

	// 거래선 채권 연체 정보
	@RequestMapping(value = "/custBondOverdueInformation")
	public ModelAndView custBondOverdueInformation(ModelAndView mav, SalesContinuityDecreaseVO param) throws Exception {
		mav.setViewName("symptom/custBondOverdueInformation");
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
//		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear() + "." + DateUtil.getToday().substring(4, 6));
		mav.addObject("defaultYyyyMm", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1).substring(0, 6)));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), 1)));
		mav.addObject("yyyyMmHeaderList", getYyyyMmHeaderList(DateUtil.addMonth(DateUtil.getToday(),-1).substring(0, 6), 6));

		return mav;
	}

	@RequestMapping(value = "/getCustBondOverdueInformationList.json")
	public Map getCustBondOverdueInformationList(@RequestBody(required = false) CustBondOverdueInformationVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", sapSearchService.getCustBondOverdueInformationList(param), "yyyyMmHeaderList", getYyyyMmHeaderList(param.getGjahr().replace(".", ""), 6));
	}

	@RequestMapping(value = "/custBondOverdueInforExcelDownload", method = RequestMethod.POST)
	public void custBondOverdueInforExcelDownload(CustBondOverdueInformationVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		param.setGjahr(param.getGjahr().replace(".", ""));
		req.setCharacterEncoding("euc-kr");

		List<CustBondOverdueInformationVO> custBondOverdueInforList = sapSearchService.getCustBondOverdueInformationList(param);
		List<CustBondOverdueInformationVO> copyCustBondOverdueInforList = new ArrayList<CustBondOverdueInformationVO>();

		for (CustBondOverdueInformationVO CustBondVO : custBondOverdueInforList)
			copyCustBondOverdueInforList.add((CustBondOverdueInformationVO) StringUtil.nullToEmptyString(CustBondVO));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("custBondOverdueInforList", copyCustBondOverdueInforList);
		paramMap.put("yyyyMmHeaderList", getYyyyMmHeaderList(param.getGjahr().replace(".", ""), 6));

		try {
			StringBuffer content = new StringBuffer();
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate(CUST_BOND_OVERDUE_INFO_EXCEL_DOWNLOAD + ".txt"), paramMap));

			String fileName = "거래선별채권연체정보_Download_" + Util.getToday("yyyyMMdd");
			String ext = ".xls";
			fileName = java.net.URLEncoder.encode(fileName, "UTF-8");

			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie", "fileDownload=true; path=/");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ext + "\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();
		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:" + e.getMessage());
		}
	}

	// 고객 신용 등급 조회
	@RequestMapping(value = "/custCreditRateAppr")
	public String custCreditRateAppr(ModelAndView mav, SalesTrendByProdAccontVO param) throws Exception {
		return "symptom/custCreditRateAppr";
	}

	@RequestMapping(value = "/getCustomerCreditAssessInquiryList.json")
	public Map getCustomerCreditAssessInquiryList(@RequestBody(required = false) CustomerCreditAssessInquiryVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", symptomService.getCustomerCreditAssessInquiryCount(param), "storeData", symptomService.getCustomerCreditAssessInquiryList(param));
	}

	@RequestMapping(value = "/customerCreditAssessInquiryExcelDownload", method = RequestMethod.POST)
	public void customerCreditAssessInquiryExcelDownload(CustomerCreditAssessInquiryVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		req.setCharacterEncoding("euc-kr");

		Map<String, Object> paramMap = symptomService.getCustomerCreditAssessReport(param);

		try {
			StringBuffer content = new StringBuffer();

			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate(CORPORATE_INFORMATION_REPORT_EXCEL_TEMPLATE + ".txt"), paramMap));

			String fileName = "기업정보레포트_브리핑_" + ((Map)paramMap.get("BASE_INFO")).get("KED_NAME") + "_" + Util.getToday("yyyyMMdd");
			String ext = ".xls";
			fileName = java.net.URLEncoder.encode(fileName, "UTF-8");

			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie", "fileDownload=true; path=/");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ext + "\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();
		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:" + e.getMessage());
		}
	}
}
