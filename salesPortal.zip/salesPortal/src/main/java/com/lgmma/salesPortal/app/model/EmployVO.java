package com.lgmma.salesPortal.app.model;

public class EmployVO extends PagingParamVO {
	private String sawnCode;
	private String sawnName;
	private String sawnIdxx;
	private String mailAddr;
	private String teamCode;
	private String teamName;
	private String posiCode;
	private String posiName;
	private String upprCode;
	public String getSawnCode() {
		return sawnCode;
	}
	public void setSawnCode(String sawnCode) {
		this.sawnCode = sawnCode;
	}
	public String getSawnName() {
		return sawnName;
	}
	public void setSawnName(String sawnName) {
		this.sawnName = sawnName;
	}
	public String getSawnIdxx() {
		return sawnIdxx;
	}
	public void setSawnIdxx(String sawnIdxx) {
		this.sawnIdxx = sawnIdxx;
	}
	public String getMailAddr() {
		return mailAddr;
	}
	public void setMailAddr(String mailAddr) {
		this.mailAddr = mailAddr;
	}
	public String getTeamCode() {
		return teamCode;
	}
	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getPosiCode() {
		return posiCode;
	}
	public void setPosiCode(String posiCode) {
		this.posiCode = posiCode;
	}
	public String getPosiName() {
		return posiName;
	}
	public void setPosiName(String posiName) {
		this.posiName = posiName;
	}
	public String getUpprCode() {
		return upprCode;
	}
	public void setUpprCode(String upprCode) {
		this.upprCode = upprCode;
	}
}
