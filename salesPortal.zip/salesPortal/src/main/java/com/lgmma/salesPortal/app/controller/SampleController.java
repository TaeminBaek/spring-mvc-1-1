package com.lgmma.salesPortal.app.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lgmma.salesPortal.app.model.SampleVO;
import com.lgmma.salesPortal.app.service.SampleService;
import com.lgmma.salesPortal.common.model.JsonResponse;


//org.springframework.security.web.access.ExceptionTranslationFilter
@Controller
@RequestMapping("/sample") 
public class SampleController {

	@Autowired
	SampleService sampleService;

	@RequestMapping(value = "/sampleInfo")
	public String sampleInfo() throws Exception {
		return "sample/sampleInfo";
	}

	@RequestMapping(value = "/getSample.json")
	public Map getSample(@RequestBody(required=true) SampleVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", sampleService.getSampleCount(param), "storeData", sampleService.getSample(param));
	}
	
	@RequestMapping(value = "/updateSample.json")
	public Map updateSample(@RequestBody SampleVO param) throws Exception {
		sampleService.updateSample(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/createSample.json")
	public Map createSample(@RequestBody SampleVO param) throws Exception {
		sampleService.createSample(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/deleteSample.json")
	public Map deleteSample(@RequestBody SampleVO param) throws Exception {
		sampleService.deleteSample(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
}
