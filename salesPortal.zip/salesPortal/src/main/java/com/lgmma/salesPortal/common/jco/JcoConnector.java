package com.lgmma.salesPortal.common.jco;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.sap.conn.jco.JCoContext;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFieldIterator;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoMetaData;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

@Component
public class JcoConnector {

	private static Logger logger = LoggerFactory.getLogger(JcoConnector.class); 
	
	@Resource
	private Properties sapConnectionConfig;
	private LGMMADestinationDataProvider destinationDataProvider;
	private JCoRepository repos;
	private JCoDestination dest;
	final static String DEST_NAME = "MMA_SAP";

	public static final String Ymd = "yyyy.MM.dd";
	public static final String YmdHms = "yyyy.MM.dd HH:mm:ss";

	SimpleDateFormat ymdfmt = new SimpleDateFormat(Ymd);
	SimpleDateFormat ymdhmsfmt = new SimpleDateFormat(YmdHms);

	@PostConstruct
	public void initConnection() {
		logger.info(sapConnectionConfig.toString());
		destinationDataProvider = new LGMMADestinationDataProvider();
		destinationDataProvider.changePropertiesForABAP_AS(sapConnectionConfig);
		com.sap.conn.jco.ext.Environment.registerDestinationDataProvider(destinationDataProvider);

		try {
			dest = JCoDestinationManager.getDestination(DEST_NAME);
			repos = dest.getRepository();
		} catch (JCoException e) {
			throw new RuntimeException(e);
		}
	}

	@PreDestroy
	public void releaseConnection() {
		com.sap.conn.jco.ext.Environment.unregisterDestinationDataProvider(destinationDataProvider);
	}

	public void executeFunction(String funcName, Map<String, Object> inputParams, JcoTableParam tableParam) {
		this.executeFunction(funcName, inputParams, null, tableParam);
	}
	public void executeFunction(String funcName, Map<String, Object> inputParam, Map<String, Object> outputParam) {
		this.executeFunction(funcName, inputParam, outputParam, new JcoTableParam());
	}

	public void executeFunction(String funcName, JcoTableParam tableParam) {
		this.executeFunction(funcName, null, null, tableParam);
	}

	public void executeFunction(String funcName, Map<String, Object> inputParam, Map<String, Object> outputParam, JcoTableParam tableParam) {
		JCoFunction function = getFunction(funcName);
		if(function.getImportParameterList() != null)
			function.getImportParameterList().clear();
		if(function.getExportParameterList() != null)
			function.getExportParameterList().clear();
		if(function.getTableParameterList() != null)
			function.getTableParameterList().clear();

		try {
			bindImportParameters(function, inputParam, tableParam);
			execute(function);
			makeExportParameters(function, outputParam, tableParam, true);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}

	@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	public void executeFunction(String funcName, Map<String, Object> inputParam, Map<String, Object> outputParam, JcoTableParam tableParam , boolean formattable) {
		JCoFunction function = getFunction(funcName);
		if(function.getImportParameterList() != null)
			function.getImportParameterList().clear();
		if(function.getExportParameterList() != null)
			function.getExportParameterList().clear();
		if(function.getTableParameterList() != null)
			function.getTableParameterList().clear();

		try {
			bindImportParameters(function, inputParam, tableParam);
			execute(function);
			makeExportParameters(function, outputParam, tableParam, formattable);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}

	private void bindImportParameters(JCoFunction function, Map<String, Object> param, JcoTableParam tableParam) throws Exception {
        logger.info("$$$ binding import parameter for function : " + function.getName());
        
        JCoParameterList importParams = function.getImportParameterList();
        JCoParameterList tableParams = function.getTableParameterList();

        try {
            if (param != null && importParams != null) {
                JCoFieldIterator fields = importParams.getFieldIterator();
                while (fields.hasNextField()) {
                    JCoField field = fields.nextField();
                    if (param.containsKey(field.getName())) {
                        if (field.isStructure()) {
                            setStructureValue((Map<String, Object>)param, field);
                        } else {
                            setFieldValue(param, field);
                        }
                    }
                }
            }
            if (!tableParam.getParamMap().isEmpty() && tableParams != null) {
                JCoFieldIterator fields = tableParams.getFieldIterator();
                while (fields.hasNextField()) {
                    JCoField field = fields.nextField();
                    if (tableParam.getParamMap().containsKey(field.getName())) {
                        List<Map<String, Object>> rows = (List<Map<String, Object>>) tableParam.getParamMap().get(field.getName());
                        JCoTable table = field.getTable();
                        for (Map<String, Object> row: rows) {
                            table.appendRow();
                            JCoFieldIterator fi = table.getFieldIterator();
                            while (fi.hasNextField()) {
                                JCoField f = fi.nextField();
                                if (row.containsKey(f.getName())) {
                                    setFieldValue(row, f);
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            throw e;
        }
    }

	private void setStructureValue(Map<String, Object> param, JCoField field) {
		JCoStructure struct = field.getStructure();
		JCoFieldIterator fi = struct.getFieldIterator();
		while (fi.hasNextField()) {
		    JCoField f = fi.nextField();
			try {
			    if (((Map<String, Object>) param.get(field.getName())).containsKey(f.getName())) {
			        setFieldValue((Map<String, Object>) param.get(field.getName()), f);
			    }
			} catch (NullPointerException e) {
	            logger.error("Parameter Binding Error : Parameter Map Doesn't Have Key " + field.getName());
	            throw e;
			}
		}
	}

	private void setFieldValue(Map<String, Object> param, JCoField field) {
		try {
			field.setValue(param.get(field.getName()));
		} catch (NullPointerException e) {
            logger.error("Parameter Binding Error : Parameter Map Doesn't Have Key " + field.getName());
            throw e;
		} catch (Exception e) {
			logger.error("Parameter Binding Error : " + field.getName() + " Field Couldn't Bind With " + param.get(field.getName()));
			throw e;
		}
	}

    private void makeExportParameters(JCoFunction function, Map<String, Object> outputParam, JcoTableParam tableParam, boolean formattable) throws Exception {
        logger.info("$$$ making export parameter for function : " + function.getName());
        JCoParameterList exportParams = function.getExportParameterList();
        JCoParameterList tableParams = function.getTableParameterList();

        if (outputParam != null && exportParams != null) {
            JCoFieldIterator fields = exportParams.getFieldIterator();
            while (fields.hasNextField()) {
                JCoField field = fields.nextField();
                if (field.isStructure()) {
                    HashMap row = new HashMap();

                    JCoStructure struct = field.getStructure();
                    JCoFieldIterator fi = struct.getFieldIterator();
                    while (fi.hasNextField()) {
                        JCoField f = fi.nextField();
                        if(f.getType() == JCoMetaData.TYPE_DATE) {
                        	if(f.getLength() == 8) {
                            	if(!f.getString().replaceAll("[.-]", "").trim().matches("[1-9][0-9]{7}$")) {
                                	row.put(f.getName(), f.getString());
                            	}else {
                                    row.put(f.getName(), f.getValue() == null ? "" : formattable ? getDateStringYmd(f.getDate()):f.getString());
                            	}
                        	} else if (f.getLength() == 14) {
                            	if(!f.getString().replaceAll("[.-]", "").trim().matches("[1-9][0-9]{13}$")) {
                                	row.put(f.getName(),  f.getString());
                            	}else {
                                    row.put(f.getName(), f.getValue() == null ? "" : formattable ? getDateStringYmdhms(f.getDate()) : f.getString());
                            	}
                        	}
                        } else if(f.getType() == JCoMetaData.TYPE_BCD) {
                        	row.put(f.getName(),  f.getString());
                        } else {
                        	row.put(f.getName(), f.getValue());
                        }
                    }
                    outputParam.put(field.getName(), row);
                } else {
                    if(field.getType() == JCoMetaData.TYPE_DATE) {
                    	if(field.getLength() == 8) {
                        	if(!field.getString().replaceAll("[.-]", "").trim().matches("[1-9][0-9]{7}$")) {
                        		outputParam.put(field.getName(), field.getString());
                        	}else {
                        		outputParam.put(field.getName(), field.getDate() == null ? "" : formattable ? getDateStringYmd(field.getDate()) : field.getString());
                        	}
                    	} else if (field.getLength() == 14) {
                        	if(!field.getString().replaceAll("[.-]", "").trim().matches("[1-9][0-9]{13}$")) {
                        		outputParam.put(field.getName(), field.getString());
                        	}else {
                        		outputParam.put(field.getName(), field.getDate() == null ? "" : formattable ? getDateStringYmdhms(field.getDate()) : field.getString());
                        	}
                    	}
                    } else if(field.getType() == JCoMetaData.TYPE_BCD) {
                		outputParam.put(field.getName(), field.getString());
                    } else {
                        outputParam.put(field.getName(), field.getValue());
                    }
                }
            }
        }

        if (tableParam != null && tableParams != null) {
            JCoFieldIterator fields = tableParams.getFieldIterator();
            while (fields.hasNextField()) {
                JCoField field = fields.nextField();

                List rows = new ArrayList();
                JCoTable table = field.getTable();
                for (int i = 0; i < table.getNumRows(); i++) {
                    JCoFieldIterator fi = table.getFieldIterator();
                    Map row = new HashMap();
                    while (fi.hasNextField()) {
                        JCoField f = fi.nextField();
                        if(f.getType() == JCoMetaData.TYPE_DATE) {
                        	if(f.getLength() == 8) {
                            	if(!f.getString().replaceAll("[.-]", "").trim().matches("[1-9][0-9]{7}$")) {
                                	row.put(f.getName(), f.getString());
                            	}else {
                                    row.put(f.getName(), f.getValue() == null ? "" : formattable ? getDateStringYmd(f.getDate()) : f.getString());
                            	}
                        	} else if (f.getLength() == 14) {
                            	if(!f.getString().replaceAll("[.-]", "").trim().matches("[1-9][0-9]{13}$")) {
                                	row.put(f.getName(),  f.getString());
                            	}else {
                                    row.put(f.getName(), f.getValue() == null ? "" : formattable ? getDateStringYmdhms(f.getDate()) : f.getString());
                            	}
                        	}
                        } else if(f.getType() == JCoMetaData.TYPE_BCD) {
                        	row.put(f.getName(),  f.getString());
                        } else {
                        	row.put(f.getName(), f.getValue());
                        }
                    }
                    rows.add(row);
                    table.nextRow();
                }
                tableParam.getParamMap().put(field.getName(), rows);
            }
        }
    }

    public JCoFunction getFunction(String functionStr) {
		JCoFunction function = null;
		try {
			function = repos.getFunction(functionStr);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Problem retrievingJCO.Function object.");
		}

		if (function == null) {
			throw new RuntimeException("Not possible toreceive function.");
		}
		return function;
	}

	public void execute(JCoFunction function) {
		try {
			JCoContext.begin(dest);
			function.execute(dest);
			JCoContext.end(dest);
		} catch (JCoException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}

	public Properties getSapConnectionConfig() {
		return sapConnectionConfig;
	}

	public void setSapConnectionConfig(Properties sapConnectionConfig) {
		this.sapConnectionConfig = sapConnectionConfig;
	}

	public String getDateStringYmd(Date date) {
		return ymdfmt.format(date);
	}

	public String getDateStringYmdhms(Date date) {
		return ymdhmsfmt.format(date);
	}

}
