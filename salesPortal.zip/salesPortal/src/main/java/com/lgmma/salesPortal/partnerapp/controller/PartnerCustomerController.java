package com.lgmma.salesPortal.partnerapp.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.controller.CommonController;
import com.lgmma.salesPortal.app.model.CompFileListVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.CustReqVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.LoginMastVO;
import com.lgmma.salesPortal.app.model.LoginReqVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.CustomerService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.WebAccountService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.props.Months;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;


@Controller
@RequestMapping("/partner")
public class PartnerCustomerController {

	@Autowired
	WebAccountService webAccountService;

	@Autowired
	CommonController commonController;
	
	@Autowired
	CommonService commonService;
	
    @Autowired
    private MailingService mailingService;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	@Autowired
	CustomerService customerService;
	
	@RequestMapping(value = "/webAccountInfo")
	public ModelAndView webAccountInfo(ModelAndView mav) throws Exception {
		LoginUserVO param = new LoginUserVO();
		param.setUserNumx(Integer.parseInt(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getSawnCode()));
		mav.setViewName("partner/account/webAccountInfo");
		mav.addObject(webAccountService.getWebAccountDetail(param));
		mav.addObject("mobileProvider", commonController.getMobileProviderWithSelectDDLB().get("items"));
		return mav;
	}

	@RequestMapping(value = "/updateWebAccountDetail.json")
	public Map updateWebAccountDetail(@RequestBody(required=true) @Valid LoginUserVO param) throws Exception {
		webAccountService.updatePartnerWebAccountDetail(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
}
