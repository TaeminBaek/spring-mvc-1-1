package com.lgmma.salesPortal.app.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.ContractItemVO;
import com.lgmma.salesPortal.app.model.ContractMasterVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.service.ContractService;
import com.lgmma.salesPortal.common.util.Util;


@Controller
@RequestMapping("/contract") 
public class ContractController {

	@Autowired
	private ContractService contractService;
	private final String CONTRACT_TYPE_SLAES_CONTRACT = "_SLAES_CONTRACT";
	private final String CONTRACT_TYPE_PROFORMA_INVOICE = "_PROFORMA_INVOICE";
	private final String CONTRACT_TYPE_OFFER_SHEET = "_OFFER_SHEET";
	
	private static Logger logger = LoggerFactory.getLogger(ContractController.class);
	
	@RequestMapping(value = "/salesContract", method = RequestMethod.POST)
	public ModelAndView saleContract(HttpServletRequest request, DirectOrderMasterVO param) {
		ContractMasterVO contractMaster = contractService.getContractMaster(param.getOrderId());
		contractMaster.setContractType(CONTRACT_TYPE_SLAES_CONTRACT);

		// 영업조직이 1000이고, Item의 Plant가 하나라도 3000이면 특수비드. 계약서 양식이 3000으로 나와야 함.
		boolean chk3000Plant = false;
		for(ContractItemVO item : contractMaster.getItems())
			if("3000".equals(item.getPlant())) {
				chk3000Plant = true;
				break;
			}

		// 영업조직이 1000이고, Item의 Plant가 하나라도 3000이면 특수비드. 계약서 양식이 3000으로 나와야 함.
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("contract/tmpl/salesContract_" + ("1000".equals(param.getSalesOrg()) && chk3000Plant ? "3000" : param.getSalesOrg()));
		modelAndView.addObject("imageUrl", Util.getServerUrl(request) + "/web-resource/images");
		modelAndView.addObject("contractMaster", contractMaster);
		return modelAndView;
	}

	@RequestMapping(value = "/proformaInvoice", method = RequestMethod.POST)
	public ModelAndView saleProformaInvoice(HttpServletRequest request, DirectOrderMasterVO param) {
		ContractMasterVO contractMaster = contractService.getContractMaster(param.getOrderId());
		contractMaster.setContractType(CONTRACT_TYPE_PROFORMA_INVOICE);

		// 영업조직이 1000이고, Item의 Plant가 하나라도 3000이면 특수비드. 계약서 양식이 3000으로 나와야 함.
		boolean chk3000Plant = false;
		for(ContractItemVO item : contractMaster.getItems())
			if("3000".equals(item.getPlant())) {
				chk3000Plant = true;
				break;
			}

		// 영업조직이 1000이고, Item의 Plant가 하나라도 3000이면 특수비드. 계약서 양식이 3000으로 나와야 함.
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("contract/tmpl/proformaInvoice_" + ("1000".equals(param.getSalesOrg()) && chk3000Plant ? "3000" : param.getSalesOrg()));
		modelAndView.addObject("imageUrl", Util.getServerUrl(request) + "/web-resource/images");
		modelAndView.addObject("contractMaster", contractMaster);
		return modelAndView;
	}
	
	@RequestMapping(value = "/offerSheet", method = RequestMethod.POST)
	public ModelAndView offerSheet(HttpServletRequest request, DirectOrderMasterVO param) {
		ContractMasterVO contractMaster = contractService.getContractMaster(param.getOrderId());
		contractMaster.setContractType(CONTRACT_TYPE_OFFER_SHEET);

		// 영업조직이 1000이고, Item의 Plant가 하나라도 3000이면 특수비드. 계약서 양식이 3000으로 나와야 함.
		boolean chk3000Plant = false;
		for(ContractItemVO item : contractMaster.getItems())
			if("3000".equals(item.getPlant())) {
				chk3000Plant = true;
				break;
			}

		// 영업조직이 1000이고, Item의 Plant가 하나라도 3000이면 특수비드. 계약서 양식이 3000으로 나와야 함.
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("contract/tmpl/offerSheet_" + ("1000".equals(param.getSalesOrg()) && chk3000Plant ? "3000" : param.getSalesOrg()));
		modelAndView.addObject("imageUrl", Util.getServerUrl(request) + "/web-resource/images");
		modelAndView.addObject("contractMaster", contractMaster);
		return modelAndView;
	}
	
	@RequestMapping(value = "/downloadPDF", method = RequestMethod.POST)
	public ModelAndView downloadPDF(@ModelAttribute("contactForm") ContractMasterVO param) {
//		contractService.updateContractMaster(param);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("pdfView");
		modelAndView.addObject("fileName", param.getPurchNoC() + param.getContractType() + ".pdf");
		modelAndView.addObject("src", param.getHtmlSrc());
		return modelAndView;
	}
}
