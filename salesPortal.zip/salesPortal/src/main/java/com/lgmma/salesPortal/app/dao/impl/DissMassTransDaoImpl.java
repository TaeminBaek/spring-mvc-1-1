package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissMassTransDao;
import com.lgmma.salesPortal.app.model.DissMassTransVO;

@Repository
public class DissMassTransDaoImpl implements DissMassTransDao{
	
	private static final String MAPPER_NAMESPACE = "DISSMASSTRANS_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public DissMassTransVO getDissMassTransInfo(DissMassTransVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissMassTransInfo", param);
	}
	
	@Override
	public void createDissMassTrans(DissMassTransVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissMassTrans", param);
	}
	
	@Override
	public void updateDissMassTrans(DissMassTransVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissMassTrans", param);
	}
	
	@Override
	public void deleteDissMassTransAll(DissMassTransVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissMassTransAll", param);
	}	

}
