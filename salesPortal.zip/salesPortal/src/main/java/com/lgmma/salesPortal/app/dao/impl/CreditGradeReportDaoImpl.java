package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.CreditGradeReportDao;
import com.lgmma.salesPortal.app.model.CompDamboVO;
import com.lgmma.salesPortal.app.model.CreditGradeReportVO;

@Repository
public class CreditGradeReportDaoImpl implements CreditGradeReportDao {

	private static final String MAPPER_NAMESPACE = "CREDITGRADEREPORT_MAPPER.";

	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public int getCreditGradeReportListCount(CreditGradeReportVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCreditGradeReportListCount", param);
	}
	
	@Override
	public List<CreditGradeReportVO> getCreditGradeReportList(CreditGradeReportVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCreditGradeReportList", param);
	}

	@Override
	public int getDamboInfoListCount(CompDamboVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDamboInfoListCount", param);
	}
	
	@Override
	public List<CompDamboVO> getDamboInfoList(CompDamboVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDamboInfoList", param);
	}




}
