
package com.lgmma.salesPortal.app.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.lgmma.salesPortal.app.dao.CommonApprDao;
import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.dao.DissDailyActDao;
import com.lgmma.salesPortal.app.dao.DissImpDevDao;
import com.lgmma.salesPortal.app.dao.DissSpecInDao;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissDailyVO;
import com.lgmma.salesPortal.app.model.DissImpDevVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.DissDailyActService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

import freemarker.template.Configuration;

@Service
public class DissDailyActServiceImpl implements DissDailyActService{
	
	private static Logger logger = LoggerFactory.getLogger(DissDailyActServiceImpl.class);
	
	private final String REPORT_TEMPLATE_DISS_PUBLIC_DAILY_ACT = "REPORT_TEMPLATE_DISS_PUBLIC_DAILY_ACT"; //kjy

	@Autowired
	DissCommonApprMgmtService dissCommonApprMgmtService;
	@Autowired
	DissDailyActDao dissDailyActDao;
	@Autowired
	CompanyDao companyDao;
	@Autowired
	DissSpecInDao dissSpecInDao;
	@Autowired
	DissImpDevDao dissImpDevDao;
	@Autowired
	CommonApprDao commonApprDao;
	@Autowired
	private CommonFileService commonFileService;
	@Autowired
    @Qualifier(value="reportFreemarkerConfiguration")
    private Configuration reportTemplateConfiguration;
	@Override
	public void saveDissDailyAct(DissDailyVO param) {
		//과제유형 셋팅
		/*if(!("".equals(param.getTaskId()))) {
			param.setTaskType("SPECIN");
		}*/
		//제목 셋팅
		param.setTitle(param.getApprVO().getApprTitle());
		
		//최초등록시
		if("".equals(param.getDailyActId())) {
			//createDissDailyAct(param); //dailyActId 구하기 위해 대체함. 
			
			//품의서 ID 생성
			String apprId = Util.getUUID();
			param.setApprId(apprId);
			param.getApprVO().setApprId(apprId);
			//Daily 생성
			param.setDailyActId(apprId);
			dissDailyActDao.createDissDailyAct(param);
		} else {
			if(param.getApprVO().getApprStat().equals("4010") || param.getApprVO().getApprStat().equals("4020") ) {
				//createDissDailyAct(param); //dailyActId 구하기 위해 대체함.
				
				//품의서 ID 생성
				String apprId = Util.getUUID();
				param.setApprId(apprId);
				param.getApprVO().setApprId(apprId);
				//Daily 생성
				param.setDailyActId(apprId);
				dissDailyActDao.createDissDailyAct(param);	
			}
			updateDissDailyAct(param);
		}

		//공통품의
		String saveType = param.getApprVO().getSaveType();
		String apprStat = "";
		switch(saveType) {
			case "TEMP" : apprStat = ApprState.TEMP_SAVE.getCode();
				break;
			case "SAVE" : apprStat = ApprState.APPR_PROCEEDING.getCode();
				break;
			case "REAPPR" : apprStat = ApprState.TEMP_SAVE.getCode();
				break;
		}
		String apprType = ApprType.APPR_TYPE_DISS_DAILY_ACT.getCode();
		ApprVO apprVO = param.getApprVO();
		apprVO.setApprType(apprType);
		apprVO.setApprStat(apprStat);
		apprVO.setRegiIdxx(param.getRegiIdxx());
		apprVO.setUpdtIdxx(param.getUpdtIdxx());
		// 업무테이블 품의서 기초내용 작성 호출  kjy
		String templeteFormContent = param.getApprVO().getFormCont();
		param.getApprVO().setTempleteFormContent(getApprFormContDailyAct(param, templeteFormContent));
		
		dissCommonApprMgmtService.saveDissCommonAppr(apprVO,apprStat,false);
	}
	
	
	@Override
	public void createDissDailyAct(DissDailyVO param) {
		//품의서 ID 생성
		String apprId = Util.getUUID();
		param.setApprId(apprId);
		param.getApprVO().setApprId(apprId);
		//Daily 생성
		param.setDailyActId(apprId);
		dissDailyActDao.createDissDailyAct(param);
	}

	@Override
	public int getDissDailyActListCount(DissDailyVO param) {
		return dissDailyActDao.getDissDailyActListCount(param);
	}

	@Override
	public List<DissDailyVO> getDissDailyActList(DissDailyVO param) {
		return dissDailyActDao.getDissDailyActList(param);
	}
	
	@Override
	public DissDailyVO getDissDailyActInfo(DissDailyVO param) {
		
		DissDailyVO dissDailyVO = new DissDailyVO();
		
		// 스펙인 탭
		if(!"".equals(param.getTaskId())){
			if("SPECIN".equals(param.getTaskType())) {
				DissSpecInVO dissSpecInVOParam = new DissSpecInVO();
				dissSpecInVOParam.setTaskId(param.getTaskId());
				DissSpecInVO dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInDao.getDissSpecInInfo(dissSpecInVOParam));
				dissDailyVO.setTaskId(dissSpecInVO.getTaskId());
				dissDailyVO.setTaskName(dissSpecInVO.getTaskName());
				dissDailyVO.setCustCode(dissSpecInVO.getCustCode());
				dissDailyVO.setCustName(dissSpecInVO.getCustName());;
				dissDailyVO.setKunnr(dissSpecInVO.getCustErpCode());
			} else if ("IMPDEV".equals(param.getTaskType())) {
				DissImpDevVO dissImpDevVO = new DissImpDevVO();
				dissImpDevVO.setTaskId(param.getTaskId());
				dissImpDevVO = (DissImpDevVO) StringUtil.nullToEmptyString(dissImpDevDao.getDissImpDevDetail(dissImpDevVO));
				dissDailyVO.setTaskId(dissImpDevVO.getTaskId());
				dissDailyVO.setTaskName(dissImpDevVO.getTaskName());
			}
		// 고객 탭
		} else if(!"".equals(param.getCustCode())) {
			dissDailyVO.setCustCode(param.getCustCode());
			dissDailyVO.setCustName(companyDao.getName1ByCompCode(param.getCustCode()));
		}
		
		return dissDailyVO;
	}
	
	@Override
	public DissDailyVO getDissDailyActDetail(DissDailyVO param) {
		return dissDailyActDao.getDissDailyActDetail(param);
	}

	@Override
	public DissDailyVO getDissDailyActDetailLast(DissDailyVO param) {
		return dissDailyActDao.getDissDailyActDetailLast(param);
	}

	@Override
	public void updateDissDailyAct(DissDailyVO param) {
		dissDailyActDao.updateDissDailyAct(param);
	}

	@Override
	public void deleteDissDailyAct(DissDailyVO param) {
		//품의서 삭제
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(param.getApprId());

		ApprVO checkApprVO = commonApprDao.getAppr(apprVO);
		if(!checkApprVO.getRegiIdxx().equals(param.getUpdtIdxx())){
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
		}
		dissCommonApprMgmtService.deleteDissAppr(apprVO);
		
		//Daily 삭제
		dissDailyActDao.deleteDissDailyAct(param);
	}

	@Override
	public void saveDissDailyActApprovalAction(DissApprCommonParamVO dissApprCommonParamVO) {
		// 결재 액션 파라미터 셋팅
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(dissApprCommonParamVO.getApprId());                      // 품의서ID
		apprLineVO.setApprEmpId(dissApprCommonParamVO.getApprEmpId());                // 결재자사번
		apprLineVO.setApprLineComment(dissApprCommonParamVO.getApprLineComment());    // 결재자의견
		apprLineVO.setApplStat(dissApprCommonParamVO.getApplStat());                  // 결재자 결재결과
		apprLineVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());

		// DISS 공통 품의서 결재 호출
		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);
	}


	@Override
	public List<DissDailyVO> getDissDailyActStatList(DissDailyVO param) {
		return dissDailyActDao.getDissDailyActStatList(param);
	}

	@Override
	public List<DissDailyVO> getDissDailyActListExcelDownload(DissDailyVO param) {
		return dissDailyActDao.getDissDailyActListExcelDownload(param);
	}

	@Override
	public List<DissDailyVO> getDissDailyActStatInfoExcelDownload(DissDailyVO param) {
		return dissDailyActDao.getDissDailyActStatInfoExcelDownload(param);
	}

	@Override
	public List<DissDailyVO> getDissDailyActStatInfoExcelDownload2(DissDailyVO param) {
		return dissDailyActDao.getDissDailyActStatInfoExcelDownload2(param);
	}
	
	@Override
	public String getApprFormContDailyAct(DissDailyVO param, String templeteFormContent) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();		
		String template = null;		
		
		template = REPORT_TEMPLATE_DISS_PUBLIC_DAILY_ACT;  
		
		// Daily정보
		DissDailyVO dissDailyVO = (DissDailyVO) StringUtil.nullToEmptyString(getDissDailyActDetail(param));		
				
		map.put("dissDailyVO", dissDailyVO);		
		map.put("templeteFormContent", templeteFormContent);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getApprVO().getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);		
		
		map.put("fileVoList", fileVoList);
				
		try{
   		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
   				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
   		return content.toString();
   	}catch(Exception e){
   		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
   	}
		
   	return "";
	}
}
 