package com.lgmma.salesPortal.app.model;

public class GPortalApprovalVO extends PagingParamVO {
	/* columns */
	private String apprId;
	private String apprEmpId;
	private String apprEmpComment;
	private String apprStatus;

	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getApprEmpId() {
		return apprEmpId;
	}
	public void setApprEmpId(String apprEmpId) {
		this.apprEmpId = apprEmpId;
	}
	public String getApprEmpComment() {
		return apprEmpComment;
	}
	public void setApprEmpComment(String apprEmpComment) {
		this.apprEmpComment = apprEmpComment;
	}
	public String getApprStatus() {
		return apprStatus;
	}
	public void setApprStatus(String apprStatus) {
		this.apprStatus = apprStatus;
	}

}
