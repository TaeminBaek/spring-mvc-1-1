package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;

public interface CommonApprMgmtService {

	public int getApprListCount(ApprVO param);

	public List<ApprVO> getApprList(ApprVO param);

	public ApprVO getAppr(ApprVO param);

	public void saveAppr(ApprVO param);

	public void createAppr(ApprVO param);

	public void updateAppr(ApprVO param);

	public void deleteAppr(ApprVO param);

	public List<ApprLineVO> getApprLineList(ApprVO param);

	public ApprVO getApprContainLineList(ApprVO param);
	
	public void apprApplyResultFromGPortal(ApprVO apprVO, ApprLineVO apprLineVO, String forceExcute);
	
	public boolean apprAccessAuthCheck(ApprVO apprVO);

	public ApprVO getApprLineListContainType(ApprVO apprVO);
	
	public ApprVO getApprInfoAll(ApprVO apprVO);
	
	public List<ApprLineVO> getOrderedApprLineList(ApprVO apprVO);
	
	public void sendApprSms(ApprVO param);
}
