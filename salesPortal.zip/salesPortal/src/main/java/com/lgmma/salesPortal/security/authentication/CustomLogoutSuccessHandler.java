package com.lgmma.salesPortal.security.authentication;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CustomLogoutSuccessHandler extends SimpleUrlLogoutSuccessHandler {
	
	public CustomLogoutSuccessHandler(String logoutSuccessUrl) {
		setDefaultTargetUrl(logoutSuccessUrl);
	}
	
	public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
		if(authentication != null) {
			String userType = ((CustomAuthenticationToken) authentication).getUserInfo().getUserType();
			if (userType.equals("E")) {    //임직원은 SSO 이므로 window close
				response.setStatus(HttpServletResponse.SC_OK);
				response.setContentType("text/html; charset=UTF-8");
				response.getWriter().write("<script language='javascript' type='text/javascript'>self.opener=self;window.close();</script>");
				response.getWriter().flush();
				response.getWriter().close();
			} else {
				response.setStatus(HttpServletResponse.SC_OK);
				response.sendRedirect("/loginPage");
			}
			new SecurityContextLogoutHandler().logout(request, response, authentication);
			if (authentication != null && authentication.getDetails() != null) {
				try {
					request.getSession().invalidate();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}else{
			response.setStatus(HttpServletResponse.SC_OK);
			response.setContentType("text/html; charset=UTF-8");
			response.getWriter().write("<script language='javascript' type='text/javascript'>alert('로그아웃되었습니다.');</script>");
			response.getWriter().flush();
			response.getWriter().close();
		}

	}
}
