package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissMemberDao;
import com.lgmma.salesPortal.app.model.DissMemberVO;



@Repository
public class DissMemberDaoImpl implements DissMemberDao{
	
	private static final String MAPPER_NAMESPACE = "DISSMEMBER_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;
	
	@Override
	public void createDissMember(DissMemberVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissMember", param);
	}
	
	@Override
	public List<DissMemberVO> getDissMemberListaggList(DissMemberVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissMemberListaggList", param);
	}
	@Override
	public List<DissMemberVO> getDissMemberListaggHisList(DissMemberVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissMemberListaggHisList", param);
	}
	@Override
	public List<DissMemberVO> getDissMemberList(DissMemberVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissMemberList", param);
	}
	
	@Override
	public List<DissMemberVO> getDissMemberHisList(DissMemberVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissMemberHisList", param);
	}
	
	@Override
	public void deleteDissMemberAll(DissMemberVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissMemberAll", param);
	}
	
	@Override
	public void createDissMemberHis(DissMemberVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissMemberHis", param);
	}
	
	@Override
	public void deleteDissMemberHisAll(DissMemberVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissMemberHisAll", param);
	}

	@Override
	public List<DissMemberVO> getImpDevMemberAll(DissMemberVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getImpDevMemberAll", param);
	}
}
