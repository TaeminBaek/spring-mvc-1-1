package com.lgmma.salesPortal.app.model;

import javax.validation.constraints.Pattern;

public class SalePriceMasterHisVO extends PagingParamVO implements Cloneable{
	@Pattern(regexp="(\\d{8}|)$", message="{errors.date}")
	private String spCreYmd;
	private Integer seq;
	private String vkorg;
	private String vtweg;
	private String kunnr;
	private String indoKunnr;
	private String matnr;
	private String spType;
	@Pattern(regexp="(\\d{8}|)$", message="{errors.date}")
	private String spStaYmd;
	@Pattern(regexp="(\\d{8}|)$", message="{errors.date}")
	private String spEndYmd;
	private String spTypeKind;
	private String konwa;
	private String kmein;
	private float price;
	private String bigoText;
	
	private String regiName; //등록자명
	
	//마스터저장처리 프로시저 리턴변수
	private String R_ERRCODE;
	private String R_ERRMESG;
	
	private String workGroupId;
	
	public String getSpCreYmd() {
		return spCreYmd;
	}
	public void setSpCreYmd(String spCreYmd) {
		this.spCreYmd = spCreYmd;
	}
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getVtweg() {
		return vtweg;
	}
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getIndoKunnr() {
		return indoKunnr;
	}
	public void setIndoKunnr(String indoKunnr) {
		this.indoKunnr = indoKunnr;
	}
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getSpType() {
		return spType;
	}
	public void setSpType(String spType) {
		this.spType = spType;
	}
	public String getSpStaYmd() {
		return spStaYmd;
	}
	public void setSpStaYmd(String spStaYmd) {
		this.spStaYmd = spStaYmd;
	}
	public String getSpEndYmd() {
		return spEndYmd;
	}
	public void setSpEndYmd(String spEndYmd) {
		this.spEndYmd = spEndYmd;
	}
	public String getSpTypeKind() {
		return spTypeKind;
	}
	public void setSpTypeKind(String spTypeKind) {
		this.spTypeKind = spTypeKind;
	}
	public String getKonwa() {
		return konwa;
	}
	public void setKonwa(String konwa) {
		this.konwa = konwa;
	}
	public String getKmein() {
		return kmein;
	}
	public void setKmein(String kmein) {
		this.kmein = kmein;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getBigoText() {
		return bigoText;
	}
	public void setBigoText(String bigoText) {
		this.bigoText = bigoText;
	}
	public String getRegiName() {
		return regiName;
	}
	public void setRegiName(String regiName) {
		this.regiName = regiName;
	}
	public String getR_ERRCODE() {
		return R_ERRCODE;
	}
	public void setR_ERRCODE(String r_ERRCODE) {
		R_ERRCODE = r_ERRCODE;
	}
	public String getR_ERRMESG() {
		return R_ERRMESG;
	}
	public void setR_ERRMESG(String r_ERRMESG) {
		R_ERRMESG = r_ERRMESG;
	}
	@Override
	public Object clone()
	{
		try{
			SalePriceMasterHisVO salePriceMasterHisVO = (SalePriceMasterHisVO)super.clone();
			return salePriceMasterHisVO;
		}catch(CloneNotSupportedException e){
			e.printStackTrace();
		}
		return null;
	}
	public String getWorkGroupId() {
		return workGroupId;
	}
	public void setWorkGroupId(String workGroupId) {
		this.workGroupId = workGroupId;
	}
	
}
