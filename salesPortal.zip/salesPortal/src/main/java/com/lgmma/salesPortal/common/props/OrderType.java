package com.lgmma.salesPortal.common.props;

import java.util.Arrays;
import java.util.List;

public enum OrderType {
/**
 * 주문 유형으로서
ZBOR	전자상거래주문
ZBQT	전자상거래견적
ZCCR	매출적자
ZCDR	매출흑자
ZCFD	견본
ZCKE	내수-Local전환출하
ZCKR	전환반품
ZCOR	시판주문
ZCQT	기타견적
ZCRE	반품입고
ZCRK	송장수정요청
ZDOR	특가주문
ZEFD	CY용 수출적송
ZEIN	수출문의
ZEOR	수출주문
ZEQT	수출L/C관리
ZFOR	수출전자상거래
ZGOR	수출보상주문
ZMFD	적송출하오더
ZORQ	수량 차이 조정 (+)
ZREQ	수량 차이 조정 (-)
ZRFD	무상주문-Claim
ZERD	무상수출주문-Claim
ZRRE	반품 후 보상
ZSOR	기타
*/
	 ESALES("ZBOR","전자상거래")
	,EXPORT("ZEOR","수출")
	,SPECIAL_PRICE("ZDOR","특가")
	,SAMPLE("ZCFD","견본")
	,CY_EXPORT_SHIP("ZEFD","CY용 수출적송")
	,SALES_LOSS("ZCCR","매출적자")
	,SALES_SURPLUS("ZCDR","매출흑자")
	,QUANTITY_ADJUST_PLUS("ZORQ","수량 차이 조정 (+)")
	,QUANTITY_ADJUST_MINUS("ZREQ","수량 차이 조정 (-)")
	,MARKETING("ZCOR","시판")
	,SHIPPING("ZMFD","적송출하")
	,RETURNS_INBOUND("ZCRE","반품입고")
	,CLAIM("ZRFD","무상주문-CLAIM")
	,CLAIM_EXPORT("ZERD","무상수출주문-CLAIM")
	,OTHERS("ZSOR","기타")
	;
	String code = null;
	String name = null;

	private OrderType(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static OrderType getOrderType(String code) {
		for(OrderType type : OrderType.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
		
	public static List<OrderType> getDirectOrderTypeList() {
		return Arrays.asList(EXPORT
				,SPECIAL_PRICE
				,CY_EXPORT_SHIP
				,SALES_LOSS
				,SALES_SURPLUS
				,QUANTITY_ADJUST_PLUS
				,QUANTITY_ADJUST_MINUS
				,MARKETING
				,SHIPPING
				,RETURNS_INBOUND
				,CLAIM
				,OTHERS
				,ESALES
				,CLAIM
				,CLAIM_EXPORT
		);
	}
	
	public static List<OrderType> getHighValueDirectOrderTypeList() {
		return Arrays.asList(ESALES
				,EXPORT
				,SPECIAL_PRICE
				,MARKETING
		);
	}

	public static List<OrderType> getPriceListOrderTypeList() {
		return Arrays.asList(MARKETING
				,EXPORT
				,ESALES
				,RETURNS_INBOUND
				,QUANTITY_ADJUST_PLUS
				,QUANTITY_ADJUST_MINUS
				,OTHERS
				);
	}

	public static List<OrderType> getCloseOrderTypeList() {
		return Arrays.asList(ESALES
				,EXPORT
				,MARKETING
				,SPECIAL_PRICE
				,OTHERS
		);
	}

	public static List<OrderType> getBillingOrderTypeList() {
		return Arrays.asList(ESALES
			,EXPORT
			,SPECIAL_PRICE
			,SALES_LOSS
			,SALES_SURPLUS
			,QUANTITY_ADJUST_PLUS
			,QUANTITY_ADJUST_MINUS
			,MARKETING
			,RETURNS_INBOUND
			,CLAIM
			,OTHERS
		);
	}
}
