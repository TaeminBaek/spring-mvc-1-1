package com.lgmma.salesPortal.common.model.validation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.lgmma.salesPortal.common.model.validation.Max2Byte;

public class Max2ByteValidator implements ConstraintValidator<Max2Byte, String> {

	private long allowedMaxLength;

    @Override
	public void initialize(Max2Byte constraintAnnotation) {
		allowedMaxLength = constraintAnnotation.eng();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if(getByteLength(value) > allowedMaxLength) {
			return false;
		}
		return true;
	}

	private int getByteLength(String s) {
		return s == null ? 0 : s.getBytes().length;
	}
}
