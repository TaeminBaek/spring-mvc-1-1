package com.lgmma.salesPortal.app.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.itextpdf.text.log.SysoCounter;
import com.lgmma.salesPortal.app.dao.SalePriceMasterDao;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.SalePriceCloseDtlVO;
import com.lgmma.salesPortal.app.model.SalePriceCloseVO;
import com.lgmma.salesPortal.app.service.GportalPostProcess;
import com.lgmma.salesPortal.app.service.SalePriceMasterMgmtService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.app.service.SmsService;
import com.lgmma.salesPortal.common.util.StringUtil;

import freemarker.template.Configuration;

@Transactional
@Service
public class GportalSalePirceMonthlyCloseProcessImpl implements GportalPostProcess {

	private static Logger logger = LoggerFactory.getLogger(GportalSalePirceMonthlyCloseProcessImpl.class); 

	private final String REPORT_TEMPLATE_SP_MONTH_CLOSE = "REPORT_TEMPLATE_SP_MONTH_CLOSE";

	@Autowired
	private SmsService smsService;
	
	@Autowired
	private SapSearchService sapSearchService;
	
	@Autowired
	private SalePriceMasterDao salePriceMasterDao;
	
	@Autowired
	private SalePriceMasterMgmtService salePriceMasterMgmtService;
	
	@Autowired
	private CommonFileServiceImpl commonFileService;
	
    @Autowired
    @Qualifier(value="reportFreemarkerConfiguration")
    private Configuration reportTemplateConfiguration;
    
	@Autowired
    private PlatformTransactionManager transactionManager;

    @Override
	public void saveApprId(ApprVO apprVO) {
		SalePriceCloseVO param = new SalePriceCloseVO();
		param.setApprId(apprVO.getKeyId());
		List<SalePriceCloseVO> returnList = salePriceMasterDao.getPriceMasterMonthlyListByApprId(param);
		
		for(SalePriceCloseVO item : returnList) {
			item.setApprId(apprVO.getApprId());
			item.setYyyymm(StringUtil.remove(item.getYyyymm(), '.'));
			salePriceMasterDao.updateMonthlyCloseApprId(item);
		}
	}

	@Override
	public void deleteApprId(ApprVO apprVO) {
		SalePriceCloseVO param = new SalePriceCloseVO();
		param.setApprId(apprVO.getApprId());
		//할게 있나?
//		companyDao.updateCompOrgEditIdToNull(param);
	}

	@Override
	public void completeProcess(ApprVO apprVO) {
	}

	@Override
	public void rejectProcess(ApprVO apprVO) {
	}

	@Override
	public String getApprContent(String apprId) {
		SalePriceCloseVO param = new SalePriceCloseVO();
		param.setApprId(apprId);
		List<SalePriceCloseVO> returnList = salePriceMasterDao.getPriceMasterMonthlyListByApprId(param);

		StringBuffer content = new StringBuffer();
		Map<String, Object> map = null;

		List<SalePriceCloseDtlVO> detailList = new ArrayList<SalePriceCloseDtlVO>();

		for(SalePriceCloseVO item : returnList) {
			item.setYyyymm(StringUtil.remove(item.getYyyymm(), '.'));
			List<SalePriceCloseDtlVO> detailListTemp = salePriceMasterMgmtService.getMonthlyCloseDetailList(item);
			for(SalePriceCloseDtlVO detail : detailListTemp) {
				detail = (SalePriceCloseDtlVO) StringUtil.nullToEmptyString(detail);
				String matnr = detail.getMatnr();
				String packUnit = detail.getPackUnit();

				// 천정수 사원 요구사항. BA/BN구분 & 포장단위 구분 
				if(matnr.contains("BN") || matnr.contains("BA")) {
					detail.setMatnr(matnr.substring(0,matnr.indexOf('-')));
					if(matnr.substring(matnr.indexOf('-'), matnr.length() - 1) !=null) {
						detail.setPackUnit(matnr.substring(matnr.indexOf('-')+1, matnr.length()));
					}
				}
				
				
				
				// 제품코드 규칙 예외
				if("MAABW".equals(matnr))		matnr = "MAAB";
				else if("SMMAB".equals(matnr))	matnr = "MAAB";
				else if("SMMAD".equals(matnr))	matnr = "MAAD";

				// 1000 제품군은 제품코드 기준으로 묶음
				// 제품코드 끝자리와 포장단위를 비교해서 제품코드 재설정
				if("1000".equals(detail.getVkorg())) {
					if(("BULK".equals(detail.getPackUnit()) && "B".equals(matnr.substring(matnr.length() - 1)))
					|| ("DRUM".equals(detail.getPackUnit()) && "D".equals(matnr.substring(matnr.length() - 1)))) {
						detail.setMatnr(matnr.substring(0, matnr.length() - 1));
					}
				}
			}
			detailList.addAll(detailListTemp);
		}
		Collections.sort(detailList, new Comparator<SalePriceCloseDtlVO>() {
			@Override
			public int compare(SalePriceCloseDtlVO o1, SalePriceCloseDtlVO o2) {
				int[] orderBy = {
					o1.getMatnr().compareTo(o2.getMatnr()),						// 품목
					o1.getVtweg().compareTo(o2.getVtweg()),						// 유통경로
					o1.getKunnr().compareTo(o2.getKunnr()),						// 판매처
					o1.getPackUnit().compareTo(o2.getPackUnit()),				// 포장단위
					o1.getSaleMan().compareTo(o2.getSaleMan()),					// 담당자
					o1.getSpType().compareTo(o2.getSpType()),					// 판가유형
					o1.getIndoKunnr().compareTo(o2.getIndoKunnr()),				// 인도처
					o1.getFinalIndoName1().compareTo(o2.getFinalIndoName1())	// 실제인도처
				};

				for(int o : orderBy)
					if(o != 0)	return o;

				return 0;
			}
		});

		String matnr = detailList.get(0).getMatnr();
		List<List<SalePriceCloseDtlVO>> detailListAll = new ArrayList<List<SalePriceCloseDtlVO>>();
		detailListAll.add(new ArrayList<SalePriceCloseDtlVO>());
		
		
		for(SalePriceCloseDtlVO data : detailList) {
		System.out.println(matnr);
		System.out.println(data.getMatnr());
			if(!matnr.equals(data.getMatnr())) {
				if(matnr.contains("BA") == false || data.getMatnr().contains("BA") == false) {
					matnr = data.getMatnr();
					if(data.getMatnr().contains("BN") == false) {
						detailListAll.add(new ArrayList<SalePriceCloseDtlVO>());
					}
				}
			}
			detailListAll.get(detailListAll.size() - 1).add(data);
		}

		map = new HashMap<String, Object>();
		map.put("detailListAll", detailListAll);
		map.put("returnList", returnList);
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString(reportTemplateConfiguration.getTemplate(REPORT_TEMPLATE_SP_MONTH_CLOSE + ".txt"), map));
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}

		return content.toString();
	}
}
