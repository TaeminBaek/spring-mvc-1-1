 package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DocTemplateDao;
import com.lgmma.salesPortal.app.model.DocTemplateVO;

@Repository
public class DocTemplateDaoImpl implements DocTemplateDao{
	
	private static final String MAPPER_NAMESPACE = "DOCTEMPLATE_MAPPER.";
	
	 @Autowired(required=true)
	    protected SqlSession sqlSession;

	 @Override
		public int getDocTemplateCount(DocTemplateVO param) {
		 return sqlSession.selectOne(MAPPER_NAMESPACE + "getDocTemplateCount", param);
		}
	 
	@Override
	public List<DocTemplateVO> getDocTemplateList(DocTemplateVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDocTemplateList", param);
	}

	@Override
	public void updateDocTemplate(DocTemplateVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDocTemplate", param);
		
	}

	@Override
	public void createDocTemplate(DocTemplateVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createDocTemplate", param);
		
	}

	@Override
	public List<DocTemplateVO> getNotDeletedDocTemplateList(DocTemplateVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getNotDeletedDocTemplateList", param);
	}


}
