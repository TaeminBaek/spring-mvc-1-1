package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.CodeGroupVO;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.ExchangeRateVO;
import com.lgmma.salesPortal.app.model.SampleVO;
import com.lgmma.salesPortal.app.model.GenVocVO;


public interface ExchangeMgmtService {
	
	public int getExchangeRateCount(ExchangeRateVO param);

	public List<ExchangeRateVO> getExchangeRateList(ExchangeRateVO param);

	public List<ExchangeRateVO> getExchangeRateMonAvgList(ExchangeRateVO param);

	public List<ExchangeRateVO> getExchangeRateListAddAvg(ExchangeRateVO param);

	public List<ExchangeRateVO> getExchangeRateMonAvgListAddAvg(ExchangeRateVO param);

	public void updateExchangeRate(ExchangeRateVO param);

	public void createExchangeRate(ExchangeRateVO param);

	public ExchangeRateVO getLastExchangeRateInfo();
}
