package com.lgmma.salesPortal.app.model;

public class ExportDelayCreditVO extends PagingParamVO {
	private String vkorg;
	private String datum;
	private String belnr;
	private String zfbeno;
	private String kunnr;
	private String name1;
	private String vtweg;
	private String vbeln;
	private String busil;
	private String budat;
	private String zterm;
	private String zfbdt;
	private String zdays;
	private String zfuspt;
	private String zfuspr;
	private String zfxisk;
	private String zfbisdt;
	private String zfipadt;
	private String waers;
	private String dmbtr;
	private String wrbtr;
	private String prnam;
	
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getDatum() {
		return datum;
	}
	public void setDatum(String datum) {
		this.datum = datum;
	}
	public String getBelnr() {
		return belnr;
	}
	public void setBelnr(String belnr) {
		this.belnr = belnr;
	}
	public String getZfbeno() {
		return zfbeno;
	}
	public void setZfbeno(String zfbeno) {
		this.zfbeno = zfbeno;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getVtweg() {
		return vtweg;
	}
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	public String getVbeln() {
		return vbeln;
	}
	public void setVbeln(String vbeln) {
		this.vbeln = vbeln;
	}
	public String getBusil() {
		return busil;
	}
	public void setBusil(String busil) {
		this.busil = busil;
	}
	public String getBudat() {
		return budat;
	}
	public void setBudat(String budat) {
		this.budat = budat;
	}
	public String getZterm() {
		return zterm;
	}
	public void setZterm(String zterm) {
		this.zterm = zterm;
	}
	public String getZfbdt() {
		return zfbdt;
	}
	public void setZfbdt(String zfbdt) {
		this.zfbdt = zfbdt;
	}
	public String getZdays() {
		return zdays;
	}
	public void setZdays(String zdays) {
		this.zdays = zdays;
	}
	public String getZfuspt() {
		return zfuspt;
	}
	public void setZfuspt(String zfuspt) {
		this.zfuspt = zfuspt;
	}
	public String getZfuspr() {
		return zfuspr;
	}
	public void setZfuspr(String zfuspr) {
		this.zfuspr = zfuspr;
	}
	public String getZfxisk() {
		return zfxisk;
	}
	public void setZfxisk(String zfxisk) {
		this.zfxisk = zfxisk;
	}
	public String getZfbisdt() {
		return zfbisdt;
	}
	public void setZfbisdt(String zfbisdt) {
		this.zfbisdt = zfbisdt;
	}
	public String getZfipadt() {
		return zfipadt;
	}
	public void setZfipadt(String zfipadt) {
		this.zfipadt = zfipadt;
	}
	public String getWaers() {
		return waers;
	}
	public void setWaers(String waers) {
		this.waers = waers;
	}
	public String getDmbtr() {
		return dmbtr;
	}
	public void setDmbtr(String dmbtr) {
		this.dmbtr = dmbtr;
	}
	public String getWrbtr() {
		return wrbtr;
	}
	public void setWrbtr(String wrbtr) {
		this.wrbtr = wrbtr;
	}
	public String getPrnam() {
		return prnam;
	}
	public void setPrnam(String prnam) {
		this.prnam = prnam;
	}

}
