package com.lgmma.salesPortal.app.service;

import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;
import com.lgmma.salesPortal.app.model.OrderProdJindVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;
import com.lgmma.salesPortal.app.model.SapOrderShipListVO;
import com.lgmma.salesPortal.app.model.VocVO;

import java.util.List;
import java.util.Map;

public interface CommonServiceCache {
	List<CommonCodeVO> getCommonCodeDbAll();
}
