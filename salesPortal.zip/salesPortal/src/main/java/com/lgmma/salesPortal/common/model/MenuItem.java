package com.lgmma.salesPortal.common.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlType(propOrder = { "id", "depth", "name", "url", "role", "parentId", "script",  "selected",  "visible", "menuItems"})	//xml write 순서를 정한다.
public class MenuItem {
	private String id;
	private String name;
	private String url;
	private List<String> role;
	private int depth;
	private String parentId;
	private String script;
	private boolean selected;
	private boolean visible;
	private List<MenuItem> menuItems;

	public String getId() {
		return id;
	}
	@XmlElement
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	@XmlElement
	public void setName(String name) {
		this.name = name;
	}
	public String getUrl() {
		return url;
	}
	@XmlElement
	public void setUrl(String url) {
		this.url = url;
	}
	public List<String> getRole() {
		return role;
	}
	@XmlElement
	public void setRole(List<String> role) {
		this.role = role;
	}
	public int getDepth() {
		return depth;
	}
	@XmlElement
	public void setDepth(int depth) {
		this.depth = depth;
	}
	public String getParentId() {
		return parentId;
	}
	@XmlElement
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public List<MenuItem> getMenuItems() {
		return menuItems;
	}
	@XmlElement(name = "menuItem")
	public void setMenuItems(List<MenuItem> menuItems) {
		this.menuItems = menuItems;
	}
	public String getScript() {
		return script;
	}
	@XmlElement
	public void setScript(String script) {
		this.script = script;
	}
	public boolean isSelected() {
		return selected;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	public boolean isVisible() {
		return visible;
	}
	public void setVisible(boolean visible) {
		this.visible = visible;
	}
	@Override
	public String toString() {
		return "MenuItem [id=" + id + ", name=" + name + ", url=" + url + ", role=" + role + ", depth=" + depth
				+ ", parentId=" + parentId + ", script=" + script + ", selected=" + selected + ", visible=" + visible
				+ ", menuItems=" + menuItems + "]";
	}
}
