package com.lgmma.salesPortal.app.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.lgmma.salesPortal.app.dao.CommonApprDao;
import com.lgmma.salesPortal.app.dao.CommonCommentDao;
import com.lgmma.salesPortal.app.dao.CommonDao;
import com.lgmma.salesPortal.app.dao.CommonReviewDao;
import com.lgmma.salesPortal.app.dao.DissCompGradeDao;
import com.lgmma.salesPortal.app.dao.DissCompTaskDao;
import com.lgmma.salesPortal.app.dao.DissCustTestDao;
import com.lgmma.salesPortal.app.dao.DissCustTestOrderDao;
import com.lgmma.salesPortal.app.dao.DissDailyActDao;
import com.lgmma.salesPortal.app.dao.DissFieldTestDao;
import com.lgmma.salesPortal.app.dao.DissImpDevDao;
import com.lgmma.salesPortal.app.dao.DissKpiDao;
import com.lgmma.salesPortal.app.dao.DissMassTransDao;
import com.lgmma.salesPortal.app.dao.DissMemberDao;
import com.lgmma.salesPortal.app.dao.DissOneTeamDao;
import com.lgmma.salesPortal.app.dao.DissRecipeDao;
import com.lgmma.salesPortal.app.dao.DissSampleOrderDao;
import com.lgmma.salesPortal.app.dao.DissScheduleDao;
import com.lgmma.salesPortal.app.dao.DissSpecInDao;
import com.lgmma.salesPortal.app.dao.DissStepDao;
import com.lgmma.salesPortal.app.dao.DissTaskResultDao;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissCommentVO;
import com.lgmma.salesPortal.app.model.DissCompGradeVO;
import com.lgmma.salesPortal.app.model.DissCompTaskVO;
import com.lgmma.salesPortal.app.model.DissCustTestOrderVO;
import com.lgmma.salesPortal.app.model.DissCustTestVO;
import com.lgmma.salesPortal.app.model.DissImpDevVO;
import com.lgmma.salesPortal.app.model.DissKpiVO;
import com.lgmma.salesPortal.app.model.DissMassTransVO;
import com.lgmma.salesPortal.app.model.DissMemberVO;
import com.lgmma.salesPortal.app.model.DissOneTeamVO;
import com.lgmma.salesPortal.app.model.DissPublicVO;
import com.lgmma.salesPortal.app.model.DissReviewVO;
import com.lgmma.salesPortal.app.model.DissSampleOrderMasterVO;
import com.lgmma.salesPortal.app.model.DissScheduleVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.DissImpDevService;
import com.lgmma.salesPortal.app.service.DissPublicService;
import com.lgmma.salesPortal.app.service.DissSpecInService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.props.ApplState;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

import freemarker.template.Configuration;

@Service
public class DissPublicServiceImpl implements DissPublicService {

	private static Logger logger = LoggerFactory.getLogger(DissPublicServiceImpl.class);
	
	private final String REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER_NOTICE = "REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER_NOTICE"; //kjy
	private final String REPORT_TEMPLATE_DISS_PUBLIC_CUST_TEST = "REPORT_TEMPLATE_DISS_PUBLIC_CUST_TEST";
	private final String REPORT_TEMPLATE_DISS_PUBLIC_CUST_COMPLETE = "REPORT_TEMPLATE_DISS_PUBLIC_CUST_COMPLETE";
	private final String REPORT_TEMPLATE_DISS_PUBLIC_COMP_GRADE = "REPORT_TEMPLATE_DISS_PUBLIC_COMP_GRADE";
	private final String REPORT_TEMPLATE_DISS_PUBLIC_MASS_TRANS = "REPORT_TEMPLATE_DISS_PUBLIC_MASS_TRANS";
	
	@Autowired
	private DissCommonApprMgmtService dissCommonApprMgmtService;	

	@Autowired
	DissSpecInDao dissSpecInDao;

	@Autowired
	DissMassTransDao dissMassTransDao;

	@Autowired
	DissCompGradeDao dissCompGradeDao;

	@Autowired
	DissCompTaskDao dissCompTaskDao;

	@Autowired
	DissCustTestDao dissCustTestDao;

	@Autowired
	DissCustTestOrderDao dissCustTestOrderDao;

	@Autowired
	DissSampleOrderDao dissSampleOrderDao;

	@Autowired
	DissImpDevDao dissImpDevDao;

	@Autowired
	DissOneTeamDao dissOneTeamDao;

	@Autowired
	DissDailyActDao dissDailyActDao;

	@Autowired
	DissKpiDao dissKpiDao;

	@Autowired
	DissScheduleDao dissScheduleDao;

	@Autowired
	DissMemberDao dissMemberDao;

	@Autowired
	DissStepDao dissStepDao;

	@Autowired
	DissFieldTestDao dissFieldTestDao;

	@Autowired
	DissTaskResultDao dissTaskResultDao;

	@Autowired
	DissRecipeDao dissRecipeDao;

	@Autowired
	CommonDao commonDao;
	
	@Autowired
	CommonApprDao commonApprDao;
	
	@Autowired
	CommonCommentDao commonCommentDao;

	@Autowired
	CommonReviewDao commonReviewDao;
	
	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	@Autowired
	private MailingService mailingService;

	@Autowired
	private SapSearchService sapSearchService;
	
	@Autowired
	private DissSpecInService dissSpecInService;
	
	@Autowired
	private DissImpDevService dissImpDevService;
	
	@Autowired
	private CommonFileService commonFileService;
	
	@Autowired
    @Qualifier(value="reportFreemarkerConfiguration")
    private Configuration reportTemplateConfiguration;

	@Transactional
	@Override
	public void deleteDissPublicApprType(DissPublicVO param) {
		String stepId = param.getStepId();
		String apprType = param.getApprVO().getApprType();

		//과제완료결과 삭제
		if (apprType.equals(ApprType.APPR_TYPE_DISS_COMPLETE.getCode())) {
			//과제완료결과 삭제
			DissCompTaskVO paramCompTask = new DissCompTaskVO();
			paramCompTask.setStepId(stepId);
			dissCompTaskDao.deleteDissCompTaskAll(paramCompTask);
		}
		//고객TEST결과등록 삭제
		if (apprType.equals(ApprType.APPR_TYPE_DISS_CUSTTEST.getCode())) {
			//과제고객TEST결과
			DissCustTestVO paramCustTest = new DissCustTestVO();
			paramCustTest.setStepId(stepId);
			dissCustTestDao.deleteDissCustTestAll(paramCustTest);
			//고객TEST결과 견본ITEM별
			DissCustTestOrderVO paramCustTestOrder = new DissCustTestOrderVO();
			paramCustTestOrder.setStepId(stepId);
			dissCustTestOrderDao.deleteDissCustTestOrderAll(paramCustTestOrder);
		}
		//양산이관보고 삭제
		if (apprType.equals(ApprType.APPR_TYPE_DISS_MASSTRANS.getCode())) {
			DissMassTransVO paramMassTrans = new DissMassTransVO();
			paramMassTrans.setStepId(stepId);
			dissMassTransDao.deleteDissMassTransAll(paramMassTrans);
		}
		//규격제정/개정 삭제
		if (apprType.equals(ApprType.APPR_TYPE_DISS_COMPGRADE.getCode())) {
			DissCompGradeVO paramCompGrade = new DissCompGradeVO();
			paramCompGrade.setStepId(stepId);
			dissCompGradeDao.deleteDissCompGradeAll(paramCompGrade);
		}
		//DISS 스텝 삭제
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(stepId);
		dissStepDao.deleteDissStep(dissStepVO);
		//DISS 스텝 최종여부 N으로 변경
		dissStepDao.updateDissStepLastYn(dissStepVO);
		//공통품의 삭제
		ApprVO apprVO = param.getApprVO();
		ApprVO checkApprVO = commonApprDao.getAppr(apprVO);
		if(!checkApprVO.getRegiIdxx().equals(param.getUpdtIdxx())){
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
		}
		dissCommonApprMgmtService.deleteDissAppr(apprVO);
	}

	@Transactional
	@Override
	public void saveDissPublicApprTypeRew(DissPublicVO param) {
		String regiIdxx = param.getRegiIdxx();
		String rewStepId = Util.getUUID();
		String rewApprId = Util.getUUID();
		String stepId = param.getStepId();
		String apprType = param.getApprVO().getApprType();
		Integer degreeNo = 1;
		DissStepVO dissStepVO = new DissStepVO();
		//스텝의 최대 차수 조회
		dissStepVO.setTaskId(param.getTaskId());
		degreeNo = dissStepDao.getDissStepMaxDegreeNo(dissStepVO);
		//과제완료결과
		if (apprType.equals(ApprType.APPR_TYPE_DISS_COMPLETE.getCode())) {
			//과제완료결과 등록
			DissCompTaskVO paramCompTask = new DissCompTaskVO();
			paramCompTask.setStepId(stepId);
			DissCompTaskVO dissCompTaskVO = dissCompTaskDao.getDissCompTaskInfo(paramCompTask);
			dissCompTaskVO.setStepId(rewStepId);
			dissCompTaskVO.setRegiIdxx(regiIdxx);
			dissCompTaskDao.createDissCompTask(dissCompTaskVO);
		}
		//고객TEST결과등록
		if (apprType.equals(ApprType.APPR_TYPE_DISS_CUSTTEST.getCode())) {
			//과제고객TEST결과
			DissCustTestVO paramCustTest = new DissCustTestVO();
			paramCustTest.setStepId(stepId);
			DissCustTestVO dissCustTestVO = dissCustTestDao.getDissCustTestInfo(paramCustTest);
			dissCustTestVO.setStepId(rewStepId);
			dissCustTestVO.setRegiIdxx(regiIdxx);
			dissCustTestDao.createDissCustTest(dissCustTestVO);
			//고객TEST결과 견본ITEM별 조회
			DissCustTestOrderVO paramCustTestOrder = new DissCustTestOrderVO();
			paramCustTestOrder.setStepId(stepId);
			List<DissCustTestOrderVO> dissCustTestOrderList = dissCustTestOrderDao.getDissCustTestOrderList(paramCustTestOrder);
			int cntDissCustTestOrder = dissCustTestOrderList.size();
			//고객TEST결과 견본ITEM별 등록
			if(cntDissCustTestOrder > 0) {
				for(DissCustTestOrderVO vo : dissCustTestOrderList) {
					vo.setStepId(rewStepId);
					vo.setRegiIdxx(regiIdxx);
					dissCustTestOrderDao.createDissCustTestOrder(vo);
				}
			}
		}
		//양산이관보고
		if (apprType.equals(ApprType.APPR_TYPE_DISS_MASSTRANS.getCode())) {
			DissMassTransVO paramMassTrans = new DissMassTransVO();
			paramMassTrans.setStepId(stepId);
			DissMassTransVO dissMassTransVO = dissMassTransDao.getDissMassTransInfo(paramMassTrans);
			dissMassTransVO.setStepId(rewStepId);
			dissMassTransVO.setRegiIdxx(regiIdxx);
			dissMassTransDao.createDissMassTrans(dissMassTransVO);
		}
		//규격제정/개정
		if (apprType.equals(ApprType.APPR_TYPE_DISS_COMPGRADE.getCode())) {
			DissCompGradeVO paramCompGrade = new DissCompGradeVO();
			paramCompGrade.setStepId(stepId);
			DissCompGradeVO dissCompGradeVO = dissCompGradeDao.getDissCompGradeInfo(paramCompGrade);
			dissCompGradeVO.setStepId(rewStepId);
			dissCompGradeVO.setRegiIdxx(regiIdxx);
			dissCompGradeDao.createDissCompGrade(dissCompGradeVO);
		}
		//DISS 스텝
		dissStepVO.setApprId(rewApprId);
		dissStepVO.setStepId(stepId);
		dissStepVO.setTaskId(param.getTaskId());
		dissStepVO.setTaskType(param.getTaskType());
		dissStepVO.setStepCd(param.getStepCd());
		dissStepVO.setDegreeNo(degreeNo);
		dissStepVO.setStepLastYn("Y");
		dissStepVO.setRegiIdxx(regiIdxx);
		//스텝최종여부 N으로 변경
		dissStepDao.updateDissStepLastYn(dissStepVO);
		//DISS 스텝 등록
		dissStepVO.setStepId(rewStepId);
		dissStepDao.createDissStep(dissStepVO);
		//공통품의
		String apprStat = ApprState.TEMP_SAVE.getCode();
		ApprVO apprVO = param.getApprVO();
		apprVO.setApprId(rewApprId);
		apprVO.setApprStat(apprStat);
		apprVO.setRegiIdxx(param.getRegiIdxx());
		apprVO.setUpdtIdxx(param.getUpdtIdxx());

		dissCommonApprMgmtService.saveDissCommonAppr(apprVO,apprStat, false);
	}
	
	@Transactional
	@Override
	public void saveDissPublicApprType(DissPublicVO param) {
		String apprType = param.getApprVO().getApprType();
		String apprId = "";
		Integer degreeNo = 1;
		DissStepVO dissStepVO = new DissStepVO();
		String stepId = "";

		if (param.getApprVO().getApprId().equals("")) {
			apprId = Util.getUUID();
			//스텝의 최대 차수 조회
			dissStepVO.setTaskId(param.getTaskId());
			degreeNo = dissStepDao.getDissStepMaxDegreeNo(dissStepVO);
		}
		//스텝ID 신규, 수정 분기
		if (param.getStepId().equals("")) {
			stepId = Util.getUUID();
		} else {
			stepId = param.getStepId();
		}
		//과제완료결과
		if (apprType.equals(ApprType.APPR_TYPE_DISS_COMPLETE.getCode())) {
			//품의서ID가 없으면 신규등록
			if (param.getApprVO().getApprId().equals("")) {
				//과제완료결과 등록
				DissCompTaskVO dissCompTaskVO = param.getDissCompTaskVO();
				dissCompTaskVO.setStepId(stepId);
				dissCompTaskVO.setRegiIdxx(param.getRegiIdxx());
				dissCompTaskDao.createDissCompTask(dissCompTaskVO);
				//스텝 등록
				dissStepVO.setApprId(apprId);
				dissStepVO.setStepId(stepId);
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType()); //개선개발 DISS_TASK_TYPE
				dissStepVO.setStepCd(param.getStepCd());
				dissStepVO.setDegreeNo(degreeNo);
				dissStepVO.setStepLastYn("Y");
				dissStepVO.setRegiIdxx(param.getRegiIdxx());
				//스텝최종여부 N으로 변경
				dissStepDao.updateDissStepLastYn(dissStepVO);
				dissStepDao.createDissStep(dissStepVO);
				//공통품의 apprId 설정
				param.getApprVO().setApprId(apprId);
				//품의서ID가 있으면 수정
			} else {
				DissCompTaskVO dissCompTaskVO = param.getDissCompTaskVO();
				dissCompTaskVO.setStepId(stepId);
				dissCompTaskVO.setRegiIdxx(param.getRegiIdxx());
				dissCompTaskDao.updateDissCompTask(dissCompTaskVO);
				
				dissStepVO.setStepId(param.getStepId()); //KJY
				dissStepVO.setTaskId(param.getTaskId()); //KJY
				dissStepVO.setTaskType(param.getTaskType());		
			}
			
			//kjy
			dissStepVO.setApprType(param.getApprVO().getApprType());
			param.setDissStepVO(dissStepVO);			

			// 개발완료 성공일때 고객테스트 결과가 실패인지 체크 한다.
			DissCompTaskVO dissCompTaskVO = (DissCompTaskVO) StringUtil.nullToEmptyString(param.getDissCompTaskVO());
			if("PASS".equals(dissCompTaskVO.getCompResult())){
				DissApprCommonParamVO dissApprCommonParamVO = new DissApprCommonParamVO();
				dissApprCommonParamVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskId(param.getTaskId());
				degreeNo = dissStepDao.getDissStepMaxDegreeNo(dissStepVO);

				// 고객 테스트 결과 리스트를 구한다.
				List<DissStepVO> stepVOList = dissCommonApprMgmtService.getCompStepList(dissApprCommonParamVO,"500100",degreeNo);
				// 고객 테스트 결과 리스트가 있으면 테스트 결과를 체크한다.
				if(stepVOList.size() > 0){
					int passCnt = 0;
					for(DissStepVO chkDissStepVO:stepVOList){
						chkDissStepVO = (DissStepVO) StringUtil.nullToEmptyString(chkDissStepVO);
						if("PASS".equals(chkDissStepVO.getCustTestResult())){
							passCnt++;
						}
					}
					if(passCnt==0){
						throw new ServiceException("","고객테스트 결과 성공건이 있어야 개발완료결과를 성공처리 할 수 있습니다.");
					}
				}
			}
			// 업무테이블 품의서 기초내용 작성 호출  kjy
			String templeteFormContent = param.getApprVO().getFormCont();
			param.getApprVO().setTempleteFormContent(getApprFormContCustComplete(param, templeteFormContent));
		}
		//고객TEST결과등록
		if (apprType.equals(ApprType.APPR_TYPE_DISS_CUSTTEST.getCode())) {
			//품의서ID가 없으면 신규등록
			if (param.getApprVO().getApprId().equals("")) {
				//과제고객TEST결과
				DissCustTestVO dissCustTestVO = param.getDissCustTestVO();
				dissCustTestVO.setStepId(stepId);
				dissCustTestVO.setRegiIdxx(param.getRegiIdxx());
				dissCustTestDao.createDissCustTest(dissCustTestVO);
				//고객TEST결과 견본ITEM별
				int cntDissCustTestOrderList = param.getDissCustTestOrderList().size();
				if (cntDissCustTestOrderList > 0) {
					for (DissCustTestOrderVO vo : param.getDissCustTestOrderList()) {
						if("NONE".equals(vo.getCustTestResult()))	continue;
						vo.setStepId(stepId);
						vo.setRegiIdxx(param.getRegiIdxx());
						dissCustTestOrderDao.createDissCustTestOrder(vo);
					}
				}
				//스텝 등록
				dissStepVO.setApprId(apprId);
				dissStepVO.setStepId(stepId);
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType()); //개선개발 DISS_TASK_TYPE
				dissStepVO.setStepCd(param.getStepCd());
				dissStepVO.setDegreeNo(degreeNo);
				dissStepVO.setStepLastYn("Y");
				dissStepVO.setRegiIdxx(param.getRegiIdxx());
				//스텝최종여부 N으로 변경
				dissStepDao.updateDissStepLastYn(dissStepVO);
				dissStepDao.createDissStep(dissStepVO);
				//공통품의 apprId 설정
				param.getApprVO().setApprId(apprId);
				//품의서ID가 있으면 수정
				
				param.setStepId(stepId); // kjy 최초저장시 평가결과 조회에 필요한 변수 셋팅.
				
			} else {
				//과제고객TEST결과
				DissCustTestVO dissCustTestVO = param.getDissCustTestVO();
				dissCustTestVO.setStepId(stepId);
				dissCustTestVO.setRegiIdxx(param.getRegiIdxx());
				dissCustTestDao.updateDissCustTest(dissCustTestVO);
				//고객TEST결과 견본ITEM별
				int cntDissCustTestOrderList = param.getDissCustTestOrderList().size();
				if (cntDissCustTestOrderList > 0) {
					for (DissCustTestOrderVO vo : param.getDissCustTestOrderList()) {
						vo.setStepId(stepId);
						vo.setRegiIdxx(param.getRegiIdxx());
						dissCustTestOrderDao.updateDissCustTestOrder(vo);
					}
				}
				dissStepVO.setStepId(param.getStepId()); //KJY
				dissStepVO.setTaskId(param.getTaskId()); //KJY
				dissStepVO.setTaskType(param.getTaskType());				
			}
			//kjy
			dissStepVO.setApprType(param.getApprVO().getApprType());
			param.setDissStepVO(dissStepVO);
										
			// 업무테이블 품의서 기초내용 작성 호출  kjy
			String templeteFormContent = param.getApprVO().getFormCont();
			param.getApprVO().setTempleteFormContent(getApprFormContCustTest(param, templeteFormContent));			
		}
		//양산이관보고
		if (apprType.equals(ApprType.APPR_TYPE_DISS_MASSTRANS.getCode())) {
			//품의서ID가 없으면 신규등록
			if (param.getApprVO().getApprId().equals("")) {
				//양산이관보고 등록
				DissMassTransVO dissMassTransVO = param.getDissMassTransVO();
				dissMassTransVO.setStepId(stepId);
				dissMassTransVO.setRegiIdxx(param.getRegiIdxx());
				dissMassTransDao.createDissMassTrans(dissMassTransVO);
				//스텝 등록
				dissStepVO.setApprId(apprId);
				dissStepVO.setStepId(stepId);
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType()); //개선개발 DISS_TASK_TYPE
				dissStepVO.setStepCd(param.getStepCd());
				dissStepVO.setDegreeNo(degreeNo);
				dissStepVO.setStepLastYn("Y");
				dissStepVO.setRegiIdxx(param.getRegiIdxx());
				//스텝최종여부 N으로 변경
				dissStepDao.updateDissStepLastYn(dissStepVO);
				dissStepDao.createDissStep(dissStepVO);
				//공통품의 apprId 설정
				param.getApprVO().setApprId(apprId);
				//품의서ID가 있으면 수정
				
				param.setStepId(stepId); // kjy 최초저장시 평가결과 조회에 필요한 변수 셋팅.
			} else {
				DissMassTransVO dissMassTransVO = param.getDissMassTransVO();
				dissMassTransVO.setStepId(stepId);
				dissMassTransVO.setRegiIdxx(param.getRegiIdxx());
				dissMassTransDao.updateDissMassTrans(dissMassTransVO);
				
				dissStepVO.setStepId(param.getStepId()); //KJY
				dissStepVO.setTaskId(param.getTaskId()); //KJY
				dissStepVO.setTaskType(param.getTaskType());
			}
			
			//kjy
			dissStepVO.setApprType(param.getApprVO().getApprType());
			param.setDissStepVO(dissStepVO);			
													
			// 업무테이블 품의서 기초내용 작성 호출  kjy
			String templeteFormContent = param.getApprVO().getFormCont();
			param.getApprVO().setTempleteFormContent(getApprFormContMassTrans(param, templeteFormContent));
			
		}
		//규격제정/개정
		if (apprType.equals(ApprType.APPR_TYPE_DISS_COMPGRADE.getCode())) {
			//품의서ID가 없으면 신규등록
			if (param.getApprVO().getApprId().equals("")) {
				//규격제정/개정 등록
				DissCompGradeVO dissCompGradeVO = param.getDissCompGradeVO();
				dissCompGradeVO.setStepId(stepId);
				dissCompGradeVO.setRegiIdxx(param.getRegiIdxx());
				dissCompGradeDao.createDissCompGrade(dissCompGradeVO);
				//스텝 등록
				dissStepVO.setApprId(apprId);
				dissStepVO.setStepId(stepId);
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType()); //개선개발 DISS_TASK_TYPE
				dissStepVO.setStepCd(param.getStepCd());
				dissStepVO.setDegreeNo(degreeNo);
				dissStepVO.setStepLastYn("Y");
				dissStepVO.setRegiIdxx(param.getRegiIdxx());
				//스텝최종여부 N으로 변경
				dissStepDao.updateDissStepLastYn(dissStepVO);
				dissStepDao.createDissStep(dissStepVO);
				//공통품의 apprId 설정
				param.getApprVO().setApprId(apprId);
				//품의서ID가 있으면 수정
				
				param.setStepId(stepId); // kjy 최초저장시 평가결과 조회에 필요한 변수 셋팅.
				
			} else {
				DissCompGradeVO dissCompGradeVO = param.getDissCompGradeVO();
				dissCompGradeVO.setStepId(stepId);
				dissCompGradeVO.setRegiIdxx(param.getRegiIdxx());
				dissCompGradeDao.updateDissCompGrade(dissCompGradeVO);
				
				dissStepVO.setStepId(param.getStepId()); //KJY
				dissStepVO.setTaskId(param.getTaskId()); //KJY
				dissStepVO.setTaskType(param.getTaskType());
			}
			
			//kjy
			dissStepVO.setApprType(param.getApprVO().getApprType());
			param.setDissStepVO(dissStepVO);			
													
			// 업무테이블 품의서 기초내용 작성 호출  kjy
			String templeteFormContent = param.getApprVO().getFormCont();
			param.getApprVO().setTempleteFormContent(getApprFormContCompGrade(param, templeteFormContent));
			
		}
		//공통품의
		String saveType = param.getApprVO().getSaveType();
		String apprStat = ("SAVE".equals(saveType)) ? ApprState.APPR_PROCEEDING.getCode() : ApprState.TEMP_SAVE.getCode();
		ApprVO apprVO = param.getApprVO();
		apprVO.setApprStat(apprStat);
		apprVO.setRegiIdxx(param.getRegiIdxx());
		apprVO.setUpdtIdxx(param.getUpdtIdxx());

		dissCommonApprMgmtService.saveDissCommonAppr(apprVO, apprStat, false);
	}
	
	/**
	 * DISS SPEC-IN/제품 과제완료결과  내용 
	 *
	 * @param DissStepVO	 
	 * @return
	 */
	@Override
	public String getApprFormContCustComplete(DissPublicVO param, String templeteFormContent) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();		
		DissSpecInVO dissSpecInVO = new DissSpecInVO();		
		DissImpDevVO dissImpDevVO2 = new DissImpDevVO();
		String template = null;		
		//String apprType = param.getApprType();
		 
		// 헤더 조회. 
		if ("SPECIN".equals(param.getTaskType())) {			
			
			dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInTaskBasicInfoDetail(param.getDissStepVO()));			
			dissSpecInVO.setTaskType(param.getTaskType());						
			map.put("dissSpecInVO"  , dissSpecInVO);
			
		} else if ("IMPDEV".equals(param.getTaskType())) {					
			
			dissImpDevVO2 = (DissImpDevVO) StringUtil.nullToEmptyString(dissImpDevService.getDissImpDevTaskBasicInfoDetail(param.getDissStepVO()));					
			dissImpDevVO2.setTaskType(param.getTaskType());			
			map.put("dissSpecInVO"  , dissImpDevVO2);
		} else {
			throw new ServiceException("", "과제구분 정보가 잘못되었습니다.");
		}
		
		template = REPORT_TEMPLATE_DISS_PUBLIC_CUST_COMPLETE;  // spec-in, 제품개선 공통 템플릿.
		
		// 고객TEST등록
		DissPublicVO dissPublicVO = (DissPublicVO) StringUtil.nullToEmptyString(getDissPublicApprTypeDetail(param.getDissStepVO()));		
		
		//일정조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getTaskId());		
		
		List<DissScheduleVO> getDissScheduleList = dissScheduleDao.getDissScheduleList(paramSchedule);						
				
		List<DissScheduleVO> dissScheduleList = new ArrayList<DissScheduleVO>();
		for(DissScheduleVO schedule : getDissScheduleList) {
			dissScheduleList.add((DissScheduleVO)StringUtil.nullToEmptyString(schedule));
		}
		
		map.put("dissPublicVO", dissPublicVO);
		map.put("dissCompTaskVO", StringUtil.nullToEmptyString(dissPublicVO.getDissCompTaskVO()));
		map.put("dissScheduleList", dissScheduleList);
		map.put("templeteFormContent", templeteFormContent);
		
		//kpi
		List<DissKpiVO> dissKpiList = new ArrayList<DissKpiVO>();
		for(DissKpiVO impDev : dissPublicVO.getDissKpiList()) {			
			dissKpiList.add((DissKpiVO)StringUtil.nullToEmptyString(impDev));
		}
		map.put("dissKpiList", dissKpiList);		
		
		//견본 리스트 조회(고객Test결과 등록내역)
		DissSampleOrderMasterVO dissSampleOrderMasterVO = new DissSampleOrderMasterVO();
		dissSampleOrderMasterVO.setStepId(param.getStepId());		
		
		List<DissSampleOrderMasterVO> selectDissSampleOrderCustTestOrderList = dissSampleOrderDao.selectDissSampleOrderCustTestOrderList(dissSampleOrderMasterVO);
		
		List<DissSampleOrderMasterVO> dissCustTestOrderList = new ArrayList<DissSampleOrderMasterVO>();
		for(DissSampleOrderMasterVO schedule : selectDissSampleOrderCustTestOrderList) {
			dissCustTestOrderList.add((DissSampleOrderMasterVO)StringUtil.nullToEmptyString(schedule));
		}
		
		map.put("dissCustTestOrderList", dissCustTestOrderList);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getApprVO().getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);
		
		map.put("fileVoList", fileVoList);
				
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}
	
	/**
	 * DISS SPEC-IN/제품 고객TEST결과등록  내용 
	 *
	 * @param DissStepVO	 
	 * @return
	 */
	@Override
	public String getApprFormContCustTest(DissPublicVO param, String templeteFormContent) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();
		DissSpecInVO dissSpecInVO = new DissSpecInVO();		
		DissImpDevVO dissImpDevVO2 = new DissImpDevVO();
		String template = null;		
		//String apprType = param.getApprType();
		 
		// 헤더 조회. 
		if ("SPECIN".equals(param.getTaskType())) {			
			dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInTaskBasicInfoDetail(param.getDissStepVO()));			
			dissSpecInVO.setTaskType(param.getTaskType());						
			map.put("dissSpecInVO"  , dissSpecInVO);
			
		} else if ("IMPDEV".equals(param.getTaskType())) {					
			
			dissImpDevVO2 = (DissImpDevVO) StringUtil.nullToEmptyString(dissImpDevService.getDissImpDevTaskBasicInfoDetail(param.getDissStepVO()));					
			dissImpDevVO2.setTaskType(param.getTaskType());			
			map.put("dissSpecInVO"  , dissImpDevVO2);
		} else {
			throw new ServiceException("", "과제구분 정보가 잘못되었습니다.");
		}
		
		template = REPORT_TEMPLATE_DISS_PUBLIC_CUST_TEST;  // spec-in, 제품개선 공통 템플릿.
		
		// 고객TEST등록
		DissPublicVO dissPublicVO = (DissPublicVO) StringUtil.nullToEmptyString(getDissPublicApprTypeDetail(param.getDissStepVO()));		
		
		//일정조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getTaskId());		
		
		List<DissScheduleVO> getDissScheduleList = dissScheduleDao.getDissScheduleList(paramSchedule);		

		List<DissScheduleVO> dissScheduleList = new ArrayList<DissScheduleVO>();
		for(DissScheduleVO schedule : getDissScheduleList) {
			dissScheduleList.add((DissScheduleVO)StringUtil.nullToEmptyString(schedule));
		}
		
		map.put("dissPublicVO", dissPublicVO);
		map.put("dissCustTestVO", StringUtil.nullToEmptyString(dissPublicVO.getDissCustTestVO()));
		map.put("dissScheduleList", dissScheduleList);
		map.put("templeteFormContent", templeteFormContent);
		
		//kpi
		List<DissKpiVO> dissKpiList = new ArrayList<DissKpiVO>();
		for(DissKpiVO impDev : dissPublicVO.getDissKpiList()) {			
			dissKpiList.add((DissKpiVO)StringUtil.nullToEmptyString(impDev));
		}
		map.put("dissKpiList", dissKpiList);		
		
		//견본 리스트 조회(고객Test결과 등록내역)
		DissSampleOrderMasterVO dissSampleOrderMasterVO = new DissSampleOrderMasterVO();
		dissSampleOrderMasterVO.setStepId(param.getStepId());		
		
		List<DissSampleOrderMasterVO> selectDissSampleOrderCustTestOrderList = dissSampleOrderDao.selectDissSampleOrderCustTestOrderList(dissSampleOrderMasterVO);
		
		List<DissSampleOrderMasterVO> dissCustTestOrderList = new ArrayList<DissSampleOrderMasterVO>();
		for(DissSampleOrderMasterVO schedule : selectDissSampleOrderCustTestOrderList) {
			dissCustTestOrderList.add((DissSampleOrderMasterVO)StringUtil.nullToEmptyString(schedule));
		}
		
		map.put("dissCustTestOrderList", dissCustTestOrderList);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getApprVO().getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);
		
		map.put("fileVoList", fileVoList);
				
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}
	
	/**
	 * DISS SPEC-IN/제품 규격제정 /개정
	 *
	 * @param DissStepVO	 
	 * @return
	 */
	@Override
	public String getApprFormContCompGrade(DissPublicVO param, String templeteFormContent) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();		
		DissSpecInVO dissSpecInVO = new DissSpecInVO();		
		DissImpDevVO dissImpDevVO2 = new DissImpDevVO();
		String template = null;		
		//String apprType = param.getApprType();
		 
		// 헤더 조회. 
		if ("SPECIN".equals(param.getTaskType())) {			
			
			dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInTaskBasicInfoDetail(param.getDissStepVO()));			
			dissSpecInVO.setTaskType(param.getTaskType());						
			map.put("dissSpecInVO"  , dissSpecInVO);
			
		} else if ("IMPDEV".equals(param.getTaskType())) {						
			
			dissImpDevVO2 = (DissImpDevVO) StringUtil.nullToEmptyString(dissImpDevService.getDissImpDevTaskBasicInfoDetail(param.getDissStepVO()));					
			dissImpDevVO2.setTaskType(param.getTaskType());			
			map.put("dissSpecInVO"  , dissImpDevVO2);
			
		} else {
			throw new ServiceException("", "과제구분 정보가 잘못되었습니다.");
		}
		
		template = REPORT_TEMPLATE_DISS_PUBLIC_COMP_GRADE;  // spec-in, 제품개선 공통 템플릿.
		
		// 고객TEST등록
		DissPublicVO dissPublicVO = (DissPublicVO) StringUtil.nullToEmptyString(getDissPublicApprTypeDetail(param.getDissStepVO()));		
		
		//일정조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getTaskId());		
		
		List<DissScheduleVO> getDissScheduleList = dissScheduleDao.getDissScheduleList(paramSchedule);		
		
		List<DissScheduleVO> dissScheduleList = new ArrayList<DissScheduleVO>();
		for(DissScheduleVO schedule : getDissScheduleList) {
			dissScheduleList.add((DissScheduleVO)StringUtil.nullToEmptyString(schedule));
		}
		
		map.put("dissPublicVO", dissPublicVO);
		map.put("dissCompGradeVO", StringUtil.nullToEmptyString(dissPublicVO.getDissCompGradeVO()));
		map.put("dissScheduleList", dissScheduleList);
		map.put("templeteFormContent", templeteFormContent);
		
		//kpi
		List<DissKpiVO> dissKpiList = new ArrayList<DissKpiVO>();
		for(DissKpiVO impDev : dissPublicVO.getDissKpiList()) {			
			dissKpiList.add((DissKpiVO)StringUtil.nullToEmptyString(impDev));
		}
		map.put("dissKpiList", dissKpiList);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getApprVO().getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);
		
		map.put("fileVoList", fileVoList);
				
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}
	
	/**
	 * DISS SPEC-IN/제품 양산이관 보고
	 *
	 * @param DissStepVO	 
	 * @return
	 */
	@Override
	public String getApprFormContMassTrans(DissPublicVO param, String templeteFormContent) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();		
		DissSpecInVO dissSpecInVO = new DissSpecInVO();		
		DissImpDevVO dissImpDevVO2 = new DissImpDevVO();
		String template = null;		
		//String apprType = param.getApprType();
		 
		// 헤더 조회. 
		if ("SPECIN".equals(param.getTaskType())) {		
			
			dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInTaskBasicInfoDetail(param.getDissStepVO()));				
			dissSpecInVO.setTaskType(param.getTaskType());						
			map.put("dissSpecInVO"  , dissSpecInVO);
			
		} else if ("IMPDEV".equals(param.getTaskType())) {				
			
			dissImpDevVO2 = (DissImpDevVO) StringUtil.nullToEmptyString(dissImpDevService.getDissImpDevTaskBasicInfoDetail(param.getDissStepVO()));					
			dissImpDevVO2.setTaskType(param.getTaskType());		
			map.put("dissSpecInVO"  , dissImpDevVO2);
			
		} else {
			throw new ServiceException("", "과제구분 정보가 잘못되었습니다.");
		}
		
		template = REPORT_TEMPLATE_DISS_PUBLIC_MASS_TRANS;  // spec-in, 제품개선 공통 템플릿.
		
		// 고객TEST등록
		DissPublicVO dissPublicVO = (DissPublicVO) StringUtil.nullToEmptyString(getDissPublicApprTypeDetail(param.getDissStepVO()));		
		
		//일정조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getTaskId());		
		
		List<DissScheduleVO> getDissScheduleList = dissScheduleDao.getDissScheduleList(paramSchedule);		
		
		List<DissScheduleVO> dissScheduleList = new ArrayList<DissScheduleVO>();
		for(DissScheduleVO schedule : getDissScheduleList) {
			dissScheduleList.add((DissScheduleVO)StringUtil.nullToEmptyString(schedule));
		}
		
		map.put("dissPublicVO", dissPublicVO);
		map.put("getDissMassTransVO", StringUtil.nullToEmptyString(dissPublicVO.getDissMassTransVO()));
		map.put("dissScheduleList", dissScheduleList);
		map.put("templeteFormContent", templeteFormContent);
		
		//kpi
		List<DissKpiVO> dissKpiList = new ArrayList<DissKpiVO>();
		for(DissKpiVO impDev : dissPublicVO.getDissKpiList()) {			
			dissKpiList.add((DissKpiVO)StringUtil.nullToEmptyString(impDev));
		}
		map.put("dissKpiList", dissKpiList);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getApprVO().getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);
		
		map.put("fileVoList", fileVoList);
				
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}

	@Transactional
	@Override
	public void saveDissPublicApprovalAction(DissStepVO param) {
		//결재미완료건 조회
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(param.getApprId());
		int applIncompleteCount = commonApprDao.getApplIncompleteCount(apprVO);
		//최종결재 완료예정 결재시 후처리 시작
		String apprType = param.getApprType();
		String applStat = param.getApplStat();
		if (applIncompleteCount == 1 && applStat.equals(ApplState.APPL_APPROVE.getCode())) {
			//과제완료결과
			if (apprType.equals(ApprType.APPR_TYPE_DISS_COMPLETE.getCode())) {
				//DISS 일정 완료일 수정
				String compYmd = DateUtil.getToday();
				DissScheduleVO paramSchedule = new DissScheduleVO();
				paramSchedule.setTaskId(param.getTaskId());
				paramSchedule.setRegiIdxx(param.getRegiIdxx());
				paramSchedule.setCompYmd(compYmd);
				paramSchedule.setStepGroup("600");
				dissScheduleDao.updateDissScheduleCompYmd(paramSchedule);
				//DISS 일정 HIS 완료일 수정
				paramSchedule.setStepId(param.getStepId());
				dissScheduleDao.createDissScheduleHisBySelect(paramSchedule);
			}
			//고객TEST결과등록
			if (apprType.equals(ApprType.APPR_TYPE_DISS_CUSTTEST.getCode())) {
				//견본품의 Master 수정
				DissSampleOrderMasterVO dissSampleOrderMasterVO = new DissSampleOrderMasterVO();
				dissSampleOrderMasterVO.setStepId(param.getStepId());
				dissSampleOrderMasterVO.setUpdtIdxx(param.getUpdtIdxx());
				dissSampleOrderDao.updateSampleOrderCustTestByStepId(dissSampleOrderMasterVO);
				//DISS 일정 완료일 수정
				String compYmd = DateUtil.getToday();
				DissScheduleVO paramSchedule = new DissScheduleVO();
				paramSchedule.setTaskId(param.getTaskId());
				paramSchedule.setRegiIdxx(param.getRegiIdxx());
				paramSchedule.setCompYmd(compYmd);
				paramSchedule.setStepGroup("500");
				dissScheduleDao.updateDissScheduleCompYmd(paramSchedule);
				//DISS 일정 HIS 완료일 수정
				paramSchedule.setStepId(param.getStepId());
				dissScheduleDao.createDissScheduleHisBySelect(paramSchedule);
			}
			//양산이관보고
			if (apprType.equals(ApprType.APPR_TYPE_DISS_MASSTRANS.getCode())) {
				//DISS 일정 완료일 수정
				String compYmd = DateUtil.getToday();
				DissScheduleVO paramSchedule = new DissScheduleVO();
				paramSchedule.setTaskId(param.getTaskId());
				paramSchedule.setRegiIdxx(param.getRegiIdxx());
				paramSchedule.setCompYmd(compYmd);
				paramSchedule.setStepGroup("700");
				dissScheduleDao.updateDissScheduleCompYmd(paramSchedule);
				//DISS 일정 HIS 완료일 수정
				paramSchedule.setStepId(param.getStepId());
				dissScheduleDao.createDissScheduleHisBySelect(paramSchedule);
			}
		}
		//DISS 공통 품의서 결재액션(결재자,협의자 승인,협의,반려 처리)
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(param.getApprId());
		apprLineVO.setApprLineComment(param.getApprLineComment());
		apprLineVO.setApprEmpId(param.getUpdtIdxx());
		apprLineVO.setApplStat(param.getApplStat());
		apprLineVO.setApprLineType(param.getApprLineType());
		apprLineVO.setUpdtIdxx(param.getUpdtIdxx());

		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);
	}

	@Transactional
	@Override
	public void createComment(DissCommentVO param) {
		param.setApprCommentId(Util.getUUID());
		commonCommentDao.createComment(param);
		sendCommentMail(param);
	}

	@Override
	public void sendCommentMail(DissCommentVO param) {
		boolean sendMail = param.isSendMail();
		param = commonCommentDao.getComment(param);
		EmployVO employVO = commonDao.getEmployBySawnCode(param.getRegiIdxx());
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(param.getApprId());
		apprVO = commonApprDao.getAppr(apprVO);

		if(sendMail || (employVO.getPosiCode().equals("AC0") && apprVO.getApprType().equals("900"))) {
			String url = messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=";
			String taskListUrl = "";

			try {
				if(param.getTaskId() != null) {
					if("SPECIN".equals(param.getTaskType()))
						taskListUrl   = url + URLEncoder.encode("/dissSpecIn/dissSpecInList","UTF-8") + "?taskId=" + param.getTaskId();
					else if("IMPDEV".equals(param.getTaskType()))
						taskListUrl = url + URLEncoder.encode("/dissImpDev/dissImpDevList","UTF-8") + "?taskId=" + param.getTaskId();
					else
						taskListUrl = url + URLEncoder.encode("/dissOneTeam/dissOneTeamList","UTF-8") + "?taskId=" + param.getTaskId();
				} else {
					taskListUrl = url + URLEncoder.encode("/dissPublic/dissPublicDailyActMgmt","UTF-8") + "?dailyActId=" + param.getDailyActId();
				}
			} catch (UnsupportedEncodingException e) {
				logger.error(e.getMessage());
			}

			Map<String, String> mailParamMap = new HashMap<>();
	
			mailParamMap.put("apprTitle", apprVO.getApprTitle());
			mailParamMap.put("regiEmp", param.getCommentEmpNm() + " " + param.getCommentPosiNm() + " " + param.getCommentTeamNm());
			mailParamMap.put("apprComment", param.getApprComment());
			mailParamMap.put("regiDate", param.getRegiDate());
			mailParamMap.put("taskListUrl", taskListUrl);

			if(sendMail) {
				ApprLineVO apprLineVO = new ApprLineVO();
				apprLineVO.setApprId(param.getApprId());

				List<ApprLineVO> apprLineVOList = commonApprDao.getApprLineList(apprLineVO);

				// 품의서 작성자 이메일 가져오기
				EmployVO employVO2 = commonDao.getEmployBySawnCode(apprVO.getRegiIdxx());
				apprLineVO.setApprEmpEmail(employVO2.getMailAddr());
				apprLineVO.setApprEmpId(employVO2.getSawnCode());
				apprLineVOList.add(apprLineVO);

				for (ApprLineVO apprLine : apprLineVOList) {
					SendMailVO sendMailVO = new SendMailVO();
					sendMailVO.setTitle("D.I.S.S. 결재문서 사후의견 등록 알림");
					sendMailVO.setMailType(MailType.DISS_APPR_COMMENT_ALARM);
					sendMailVO.setSenderEmail(employVO.getSawnName() + "/" + employVO.getPosiName() + " <" + employVO.getMailAddr() + ">");
					sendMailVO.setParams(mailParamMap);
					if(param.getRegiIdxx().equals(apprLine.getApprEmpId()))
						continue;
					sendMailVO.setReceiverEmail(apprLine.getApprEmpEmail());
					mailingService.sendMail(sendMailVO);
				}
			}

			// Daily 활동 사장님 사후의견 작성 시 전략기획팀(제품개발Part) 전원에게 메일 발송
			if(employVO.getPosiCode().equals("AC0") && apprVO.getApprType().equals("900")) {
				EmployVO employVO2 = new EmployVO();
				employVO2.setTeamCode("H3002");	//전략기획팀(제품개발Part)
				employVO2.setPageSize(10);
				List<EmployVO> part = commonDao.getEmployList(employVO2);

				for(EmployVO employ: part) {
					SendMailVO sendMailVO = new SendMailVO();
					sendMailVO.setTitle("D.I.S.S. 결재문서 사후의견 등록 알림");
					sendMailVO.setMailType(MailType.DISS_APPR_COMMENT_ALARM);
					sendMailVO.setSenderEmail(employVO.getSawnName() + "/" + employVO.getPosiName() + " <" + employVO.getMailAddr() + ">");
					sendMailVO.setParams(mailParamMap);
					sendMailVO.setReceiverEmail(employ.getMailAddr());
					mailingService.sendMail(sendMailVO);
				}
			}
		}
	}

	/* DISS 품의서 댓글 작성 권한 체크
	 * @param
	 *  - regiIdxx	: 품의서 작성자
	 *  - apprId	: 품의서 ID
	 *  - taskId	: 과제 ID 
	 *  - apprType	: 품의서 구분
	 */
	@Override
	public boolean createCommentYn(DissCommentVO param) {
		String userId = param.getRegiIdxx();

		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(param.getApprId());
		apprVO = commonApprDao.getAppr(apprVO);

		// 작성자
		if(apprVO.getRegiIdxx().equals(userId))
			return true;

		// 공통_결재라인
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(param.getApprId());
		List<ApprLineVO> apprLineList = commonApprDao.getApprLineList(apprLineVO);
		for(ApprLineVO apprLine : apprLineList)
			if(apprLine.getApprEmpId().equals(userId))	// 결재라인
				return true;

		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setApprId(param.getApprId());
		dissStepVO = dissStepDao.getDissStepByApprId(dissStepVO);

		if(dissStepVO != null && "SPECIN".equals(dissStepVO.getTaskType())) {		// SPEC-IN
			DissSpecInVO dissSpecInVO = new DissSpecInVO();
			dissSpecInVO.setTaskId(param.getTaskId());
			dissSpecInVO = dissSpecInDao.getDissSpecInInfo(dissSpecInVO);
			if(dissSpecInVO.getSalesEmpId().equals(userId)	// 영업담당자
			|| dissSpecInVO.getTsEmpId().equals(userId))	// TS담당자
				return true;

			DissScheduleVO dissScheduleVO = new DissScheduleVO();
			dissScheduleVO.setTaskId(param.getTaskId());
			List<DissScheduleVO> dissScheduleList = dissScheduleDao.getDissScheduleList(dissScheduleVO);
			for(DissScheduleVO dissSchedule : dissScheduleList) {
				if((dissSchedule.getEmpId() != null && dissSchedule.getEmpId().equals(userId))	// 일정담당자
				|| (dissSchedule.getDevEmpId() != null && dissSchedule.getDevEmpId().equals(userId)))	//개발담당자
					return true;
			}
		} else if(dissStepVO != null && "IMPDEV".equals(dissStepVO.getTaskType())) {	// 제품개선개발
			DissImpDevVO dissImpDevVO = new DissImpDevVO();
			dissImpDevVO.setTaskId(param.getTaskId());
			dissImpDevVO = dissImpDevDao.getDissImpDevDetail(dissImpDevVO);
			if(dissImpDevVO.getLeaderEmpId().equals(userId))	// 리더
				return true;

			DissScheduleVO dissScheduleVO = new DissScheduleVO();
			dissScheduleVO.setTaskId(param.getTaskId());
			List<DissScheduleVO> dissScheduleList = dissScheduleDao.getDissScheduleList(dissScheduleVO);
			for(DissScheduleVO dissSchedule : dissScheduleList) {
				if((dissSchedule.getEmpId() != null && dissSchedule.getEmpId().equals(userId))	// 일정담당자
				|| (dissSchedule.getDevEmpId() != null && dissSchedule.getDevEmpId().equals(userId)))	//개발담당자
					return true;
			}
			
			DissMemberVO paramMember = new DissMemberVO();;
			paramMember.setTaskId(param.getTaskId());
			List<DissMemberVO> dissMemberList = dissMemberDao.getDissMemberList(paramMember);
			for(DissMemberVO dissmember : dissMemberList) {
				if(dissmember != null && dissmember.getMngEmpId().equals(userId))	// 멤버
					return true;
			}
		} else if(dissStepVO == null || "ONETEAM".equals(dissStepVO.getTaskType())) { // 원팀과제
			DissOneTeamVO dissOneTeamVO = new DissOneTeamVO();
			dissOneTeamVO.setTaskId(param.getTaskId());
			dissOneTeamVO = dissOneTeamDao.getDissOneTeamInfo(dissOneTeamVO);
			if(dissOneTeamVO != null && dissOneTeamVO.getLeaderEmpId().equals(userId))
				return true;

			DissMemberVO paramMember = new DissMemberVO();;
			paramMember.setTaskId(param.getTaskId());
			List<DissMemberVO> dissMemberList = dissMemberDao.getDissMemberList(paramMember);
			for(DissMemberVO dissmember : dissMemberList) {
				if(dissmember != null && dissmember.getMngEmpId().equals(userId))	// 멤버
					return true;
			}
		}

		return false;
	}
	
	@Override
	public List<DissCommentVO> getCommentList(DissCommentVO param) {
		return commonCommentDao.getCommentList(param);
	}
	
	@Override
	public int getCommentListCount(DissCommentVO param) {
		return commonCommentDao.getCommentListCount(param);
	}

	@Transactional
	@Override
	public void createReviewReq(DissReviewVO param) {
		param.setApprReviewId(Util.getUUID());
		commonReviewDao.createReview(param);

		ApprVO apprVO = new ApprVO();
		String url = messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=";
		String taskListUrl    = "";

		param = commonReviewDao.getReview(param);
		apprVO.setApprId(param.getApprId());
		apprVO = commonApprDao.getAppr(apprVO);

		EmployVO employVO = commonDao.getEmployBySawnCode(param.getRegiIdxx());
		EmployVO employVO2 = commonDao.getEmployBySawnCode(param.getAnswIdxx());

		try {
			if(param.getTaskId() != null) {
				if("SPECIN".equals(param.getTaskType()))
					taskListUrl   = url + URLEncoder.encode("/dissSpecIn/dissSpecInList","UTF-8") + "?taskId=" + param.getTaskId();
				else if("IMPDEV".equals(param.getTaskType()))
					taskListUrl = url + URLEncoder.encode("/dissImpDev/dissImpDevList","UTF-8") + "?taskId=" + param.getTaskId();
				else
					taskListUrl = url + URLEncoder.encode("/dissOneTeam/dissOneTeamList","UTF-8") + "?taskId=" + param.getTaskId();
			} else {
				taskListUrl = url + URLEncoder.encode("/dissPublic/dissPublicDailyActMgmt","UTF-8") + "?dailyActId=" + param.getDailyActId();
			}
		} catch (UnsupportedEncodingException e) {
			logger.error(e.getMessage());
		}

		Map<String, String> mailParamMap = new HashMap<>();
		mailParamMap.put("apprTitle", apprVO.getApprTitle());
		mailParamMap.put("regiEmp", param.getReviewReqEmpNm() + " " + param.getReviewReqPosiNm() + " " + param.getReviewReqTeamNm());
		mailParamMap.put("apprReviewReq", param.getApprReviewReq());
		mailParamMap.put("regiDate", param.getRegiDate());
		mailParamMap.put("taskListUrl", taskListUrl);

		SendMailVO sendMailVO = new SendMailVO();
		sendMailVO.setTitle("D.I.S.S. 검토요청 등록 알림");
		sendMailVO.setMailType(MailType.DISS_APPR_REVIEW_REQ_ALARM);
		sendMailVO.setSenderEmail(employVO.getSawnName() + "/" + employVO.getPosiName() + " <" + employVO.getMailAddr() + ">");
		sendMailVO.setReceiverEmail(employVO2.getMailAddr());
		sendMailVO.setParams(mailParamMap);
		mailingService.sendMail(sendMailVO);
	}

	@Transactional
	@Override
	public void createReviewAns(DissReviewVO param) {
		commonReviewDao.createReviewAns(param);

		ApprVO apprVO = new ApprVO();
		String url = messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=";
		String taskListUrl    = "";

		param = commonReviewDao.getReview(param);
		apprVO.setApprId(param.getApprId());
		apprVO = commonApprDao.getAppr(apprVO);

		EmployVO employVO = commonDao.getEmployBySawnCode(param.getRegiIdxx());
		EmployVO employVO2 = commonDao.getEmployBySawnCode(param.getAnswIdxx());

		try {
			if(param.getTaskId() != null) {
				if("SPECIN".equals(param.getTaskType()))
					taskListUrl   = url + URLEncoder.encode("/dissSpecIn/dissSpecInList","UTF-8") + "?taskId=" + param.getTaskId();
				else if("IMPDEV".equals(param.getTaskType()))
					taskListUrl = url + URLEncoder.encode("/dissImpDev/dissImpDevList","UTF-8") + "?taskId=" + param.getTaskId();
				else
					taskListUrl = url + URLEncoder.encode("/dissOneTeam/dissOneTeamList","UTF-8") + "?taskId=" + param.getTaskId();
			} else {
				taskListUrl = url + URLEncoder.encode("/dissPublic/dissPublicDailyActMgmt","UTF-8") + "?dailyActId=" + param.getDailyActId();
			}
		} catch (UnsupportedEncodingException e) {
			logger.error(e.getMessage());
		}

		Map<String, String> mailParamMap = new HashMap<>();
		mailParamMap.put("apprTitle", apprVO.getApprTitle());
		mailParamMap.put("regiEmp", param.getReviewAnsEmpNm() + " " + param.getReviewAnsPosiNm() + " " + param.getReviewAnsTeamNm());
		mailParamMap.put("apprReviewAns", param.getApprReviewAns());
		mailParamMap.put("regiDate", param.getRegiDate());
		mailParamMap.put("taskListUrl", taskListUrl);

		SendMailVO sendMailVO = new SendMailVO();
		sendMailVO.setTitle("D.I.S.S. 검토의견 등록 알림");
		sendMailVO.setMailType(MailType.DISS_APPR_REVIEW_ANS_ALARM);
		sendMailVO.setSenderEmail(employVO2.getSawnName() + "/" + employVO2.getPosiName() + " <" + employVO2.getMailAddr() + ">");
		sendMailVO.setReceiverEmail(employVO.getMailAddr());
		sendMailVO.setParams(mailParamMap);
		mailingService.sendMail(sendMailVO);
	}
	
	@Override
	public List<DissReviewVO> getReviewList(DissReviewVO param) {
		return commonReviewDao.getReviewList(param);
	}
	
	@Override
	public int getReviewListCount(DissReviewVO param) {
		return commonReviewDao.getReviewListCount(param);
	}
	
	@Override
	public DissPublicVO getDissPublicApprTypeDetail(DissStepVO param) {
		String stepId = param.getStepId();
		String apprType = param.getApprType();
		DissPublicVO returnItem = new DissPublicVO();
		int maxStepDgreeNo = 1;
		DissStepVO paramStep = new DissStepVO();
		//스텝 최대 차수 조회
		paramStep.setTaskId(param.getTaskId());
		maxStepDgreeNo = dissStepDao.getDissStepMaxDegreeNo(paramStep);
		//KPI HIS 조회
		DissKpiVO paramKpi = new DissKpiVO();
		paramKpi.setTaskId(param.getTaskId());
		paramKpi.setDegreeNo(maxStepDgreeNo);
		List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisStepRsltList(paramKpi);
		returnItem.setDissKpiList(dissKpiList);
		//스텝ID가 없으면 등록 초기 정보 조회
		if (stepId == "") {

		} else {
			//과제완료결과등록 과제개발완료 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_COMPLETE.getCode())) {
				DissCompTaskVO paramCompTask = new DissCompTaskVO();
				paramCompTask.setStepId(stepId);
				DissCompTaskVO dissCompTaskInfo = dissCompTaskDao.getDissCompTaskInfo(paramCompTask);
				returnItem.setDissCompTaskVO(dissCompTaskInfo);
			}
			//고객TEST결과등록 과제고객TEST결과 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_CUSTTEST.getCode())) {
				DissCustTestVO paramCustTest = new DissCustTestVO();
				paramCustTest.setStepId(stepId);
				DissCustTestVO dissCustTestInfo = dissCustTestDao.getDissCustTestInfo(paramCustTest);
				returnItem.setDissCustTestVO(dissCustTestInfo);
			}
			//양산이관보고 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_MASSTRANS.getCode())) {
				DissMassTransVO paramMassTrans = new DissMassTransVO();
				paramMassTrans.setStepId(stepId);
				DissMassTransVO dissMassTransInfo = dissMassTransDao.getDissMassTransInfo(paramMassTrans);
				//양산라인명 : 공통코드로 변경되어서 주석처리함. kjy
				/*if (!StringUtil.isNullToString(dissMassTransInfo.getMassLine()).equals("")) {
					dissMassTransInfo.setMassLineName(sapSearchService.getMasterCodeName("04", dissMassTransInfo.getMassLine()));
				}*/
				returnItem.setDissMassTransVO(dissMassTransInfo);
			}
			//규격제정/개정 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_COMPGRADE.getCode())) {
				DissCompGradeVO paramCompGrade = new DissCompGradeVO();
				paramCompGrade.setStepId(stepId);
				DissCompGradeVO dissCompGradeInfo = dissCompGradeDao.getDissCompGradeInfo(paramCompGrade);
				returnItem.setDissCompGradeVO(dissCompGradeInfo);
			}
			//반려재신청품의유무
			String reWriteRejectApprYn = dissStepDao.getDissStepReWriteRejectApprYn(param);
			returnItem.setReWriteRejectApprYn(reWriteRejectApprYn);
		}

		return returnItem;
	}

	/**
	 * 견본일정공지 기본정보 조회
	 *
	 * @param dissPublicVO
	 * @return
	 */
	@Override
	public DissPublicVO searchSampleOrderNoticeInfo(DissPublicVO dissPublicVO) {
		DissStepVO dissStepVOparam = new DissStepVO();
		dissStepVOparam.setStepId(dissPublicVO.getStepId());
		dissStepVOparam.setTaskId(dissPublicVO.getTaskId());
		dissPublicVO.setDissStepVO(dissStepDao.getDissStep(dissStepVOparam));
		return dissPublicVO;
	}


	/**
	 * 견본일정공지 저장처리
	 *
	 * @param dissPublicVO
	 */
	@Override
	public void saveSampleOrderNotice(DissPublicVO dissPublicVO) {
		if ("".equals(dissPublicVO.getSaveMode())) {
			throw new ServiceException("", "견본일정공지 처리 구분이 지정되지 않았습니다.");
		}

		DissStepVO dissStepVO = dissPublicVO.getDissStepVO();
		dissStepVO.setRegiIdxx(dissPublicVO.getRegiIdxx());
		dissStepVO.setUpdtIdxx(dissPublicVO.getUpdtIdxx());

		if ("TMP".equals(dissPublicVO.getSaveMode())) { // 임시저장인경우
			// 기본저장
			saveSampleOrderNoticeTables(dissStepVO);
			// 공통 결재 저장액션
			dissPublicVO.getApprVO().setApprId(dissStepVO.getApprId()); // 기본저장시 apprId 셋팅
			dissPublicVO.getApprVO().setRegiIdxx(dissPublicVO.getRegiIdxx());
			dissPublicVO.getApprVO().setUpdtIdxx(dissPublicVO.getUpdtIdxx());
			dissCommonApprMgmtService.saveDissCommonAppr(dissPublicVO.getApprVO(), ApprState.TEMP_SAVE.getCode(), false);
		} else if ("REQ".equals(dissPublicVO.getSaveMode())) {  // 결재요청인경우
			// 기본저장
			saveSampleOrderNoticeTables(dissStepVO);
			// 공통 결재 저장액션
			dissPublicVO.getApprVO().setApprId(dissStepVO.getApprId()); // 기본저장시 apprId 셋팅
			dissPublicVO.getApprVO().setRegiIdxx(dissPublicVO.getRegiIdxx());
			dissPublicVO.getApprVO().setUpdtIdxx(dissPublicVO.getUpdtIdxx());
			
			//kjy
			dissPublicVO.getDissStepVO().setApprType(dissPublicVO.getApprVO().getApprType());			
			dissPublicVO.setStepId(dissPublicVO.getDissStepVO().getStepId());
			dissPublicVO.setTaskId(dissPublicVO.getDissStepVO().getTaskId());			
			
			// 업무테이블 품의서 기초내용 작성 호출  kjy
			String templeteFormContent = dissPublicVO.getApprVO().getFormCont();
			dissPublicVO.getApprVO().setTempleteFormContent(getApprFormContSampleOrderNotice(dissPublicVO, templeteFormContent));
			
			dissCommonApprMgmtService.saveDissCommonAppr(dissPublicVO.getApprVO(), ApprState.APPR_PROCEEDING.getCode(), false);
		} else if ("DEL".equals(dissPublicVO.getSaveMode())) { // 삭제인경우
			// 품의서 삭제
			ApprVO checkApprVO = commonApprDao.getAppr(dissPublicVO.getApprVO());
			if(!checkApprVO.getRegiIdxx().equals(dissPublicVO.getUpdtIdxx())){
				throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
			}
			dissCommonApprMgmtService.deleteDissAppr(dissPublicVO.getApprVO());
			// 스텝삭제
			dissStepDao.deleteDissStep(dissStepVO);
			// 이전스텝 최종 복구
			dissStepDao.updateStepLastYnYByStepCd(dissStepVO);
		} else if ("REW".equals(dissPublicVO.getSaveMode())) { // 반려건 재작성 인경우
			dissStepVO.setStepId(""); // 스텝ID를 지우고 저장처리
			// 기본저장
			saveSampleOrderNoticeTables(dissStepVO);
			// 공통 결재 저장액션
			dissPublicVO.getApprVO().setApprId(dissStepVO.getApprId()); // 기본저장시 apprId 셋팅
			dissPublicVO.getApprVO().setRegiIdxx(dissPublicVO.getRegiIdxx());
			dissPublicVO.getApprVO().setUpdtIdxx(dissPublicVO.getUpdtIdxx());
			dissCommonApprMgmtService.saveDissCommonAppr(dissPublicVO.getApprVO(), ApprState.TEMP_SAVE.getCode(), false);
		}
	}
	
	@Override
	public String getApprFormContSampleOrderNotice(DissPublicVO param, String templeteFormContent) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();		
		DissSpecInVO dissSpecInVO = new DissSpecInVO();		
		DissImpDevVO dissImpDevVO2 = new DissImpDevVO();
		String template = null;		
		//String apprType = param.getApprType();			
		
		// 헤더 조회. 
		if ("SPECIN".equals(param.getDissStepVO().getTaskType())) {		
			
			dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInTaskBasicInfoDetail(param.getDissStepVO()));
			dissSpecInVO.setTaskType(param.getDissStepVO().getTaskType());			
			map.put("dissSpecInVO"  , dissSpecInVO);
			
		} else if ("IMPDEV".equals(param.getDissStepVO().getTaskType())) {		
			
			dissImpDevVO2 = (DissImpDevVO) StringUtil.nullToEmptyString(dissImpDevService.getDissImpDevTaskBasicInfoDetail(param.getDissStepVO()));	
			dissImpDevVO2.setTaskType(param.getDissStepVO().getTaskType());			
			map.put("dissSpecInVO"  , dissImpDevVO2);
			
		} else {
			throw new ServiceException("", "과제구분 정보가 잘못되었습니다.");
		}
		
		template = REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER_NOTICE;  // spec-in, 제품개선 공통 템플릿.		
						
		// 개선개발제안서	getTaskType = "SPECIN"	임. 
		DissPublicVO dissPublicVO = (DissPublicVO) StringUtil.nullToEmptyString(searchSampleOrderNoticeInfo(param));		
		
		//일정조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getDissStepVO().getTaskId());		
		
		List<DissScheduleVO> getDissScheduleList = dissScheduleDao.getDissScheduleList(paramSchedule);		
		
		List<DissScheduleVO> dissScheduleList = new ArrayList<DissScheduleVO>();
		for(DissScheduleVO schedule : getDissScheduleList) {
			dissScheduleList.add((DissScheduleVO)StringUtil.nullToEmptyString(schedule));
		}
		
		map.put("dissPublicVO"		 , dissPublicVO);		
		map.put("dissScheduleList"	 , dissScheduleList);
		map.put("templeteFormContent", templeteFormContent);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getApprVO().getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);		
		
		map.put("fileVoList", fileVoList);		
				
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}

	/**
	 * 견본일정공지 저장 (결재의뢰 까지 사용)
	 *
	 * @param dissStepVO
	 */
	private void saveSampleOrderNoticeTables(DissStepVO dissStepVO) {
		if ("".equals(dissStepVO.getStepId())) { // stepId 가 없으면 insert
			String tmpStepId = Util.getUUID();   // 스텝ID
			String tmpApprId = Util.getUUID();   // 품의서ID 생성
			dissStepVO.setApprId(tmpApprId);
			dissStepVO.setStepId(tmpStepId);
			// 이전 스텝 LastYn N으로
			dissStepDao.updateDissStepLastYn(dissStepVO);
			// 견본일정공지 스텝 생성
			dissStepDao.createDissStep(dissStepVO);
		}
	}

	/**
	 * 견본일정공지 결재 처리
	 *
	 * @param dissApprCommonParamVO
	 */
	@Override
	public void applSampleOrderNotice(DissApprCommonParamVO dissApprCommonParamVO) {
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(dissApprCommonParamVO.getApprId());                     // 품의서ID
		apprLineVO.setApprEmpId(dissApprCommonParamVO.getApprEmpId());              // 결재자사번
		apprLineVO.setApprLineComment(dissApprCommonParamVO.getApprLineComment());  // 결재자의견
		apprLineVO.setApplStat(dissApprCommonParamVO.getApplStat());                 // 결재자 결재결과
		apprLineVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());

		// DISS 공통 품의서 결재 호출
		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);
	}

	/**
	 * 견본 송부 일정 담당자가 영업팀 소속인지 체크한다.
	 *
	 * @param empId
	 */
	@Override
	public void chkSalesTeam(String empId){
		DissScheduleVO dissScheduleVO = new DissScheduleVO();
		dissScheduleVO.setEmpId(empId);
		String check = dissScheduleDao.chkSalesTeam(dissScheduleVO);
		if("N".equals(check) && !"07150".equals(empId)){	// 정해찬 예외처리
			throw new ServiceException("","견본일정 담당자는 영업팀 소속이어야 합니다.");
		}
	}

	/**
	 * 담당자가 TS팀 소속인지 체크한다.
	 *
	 * @param empId
	 */
	@Override
	public void chkTSTeam(String empId){
		DissScheduleVO dissScheduleVO = new DissScheduleVO();
		dissScheduleVO.setEmpId(empId);
		String check = dissScheduleDao.chkTSTeam(dissScheduleVO);
		if("N".equals(check)){
			throw new ServiceException("","TS 담당자는 TS팀 소속이어야 합니다.");
		}
	}
	
	/**
	 * @param apprType
	 * 		410 : OneTeam
	 * 		900 : Daily
	 * @param id
	 * 		OneTeam : taskId
	 * 		Daily : regiIdxx
	 */
	@Override
	public List<EmployVO> loadEmployList(Map<String, String> param) {
		List<EmployVO> employList = new ArrayList<>();
		if("410".equals(param.get("apprType")))
			employList = dissOneTeamDao.loadEmployList(param);
		else if("900".equals(param.get("apprType")))
			employList = dissDailyActDao.loadEmployList(param);
		return employList;
	}

	@Override
	public List<DissStepVO> getDissStepIngList(DissStepVO param) {
		return dissStepDao.getDissStepIngList(param);
	}

	@Override
	public List<DissMemberVO> getDefaultApprILine(DissMemberVO param) {
		List<DissMemberVO> dissMemberList = null;
		if("IMPDEV".equals(param.getTaskType())) {
			dissMemberList = dissMemberDao.getImpDevMemberAll(param);
		}
		return dissMemberList;
	}
}
