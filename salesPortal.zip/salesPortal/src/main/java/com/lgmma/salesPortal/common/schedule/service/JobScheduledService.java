package com.lgmma.salesPortal.common.schedule.service;

import com.lgmma.salesPortal.app.model.DisplayOrderLotVO;
import com.lgmma.salesPortal.app.model.JobScheduleParamVO;

public interface JobScheduledService {

	void excProductsFromSap();

	void excProductStocksFromSap();
	
	void excExchangeRateFromSap();

	void excUpdateOrderWadatIstFromSap(JobScheduleParamVO param);

	void excSyncCompOrganByErp();
	
	void excOrderLotFromSap(DisplayOrderLotVO param); //주문 LOT NO 조회

	void exeUpdateCompGradeFromNICE(String stcd2);

	void exeSendCompGradeToERP(String string);

	void exeSendDamboExpiredMailERP();

	void exeSendMailDISSDelayTaskAlarm();
	
	void exeSendMailDISSDelayGateReviewAlarm();

	void exeUpdateExpCompanyGradeFromSap(String kunnr);

	void exeGetMonthlySalesFromSap(String yyyyMm);

	void exeUpdateKedInfo();

	void exeUploadKedCompanyInfo();

	void exeUpdateCompGradeFromCretop();

	void exeSendCollectExpectedDateMail();

	void test();
}
