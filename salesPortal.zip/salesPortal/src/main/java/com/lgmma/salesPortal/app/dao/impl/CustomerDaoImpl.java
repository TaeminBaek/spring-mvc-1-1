package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.CustomerDao;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.CustReqVO;
import com.lgmma.salesPortal.app.model.OrganVO;

@Repository
public class CustomerDaoImpl implements CustomerDao {

    private static final String MAPPER_NAMESPACE = "CUSTOMER_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public void createCustomer(CompanyVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createCustomer", param);
	}

	@Override
	public void createOrgan(OrganVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createOrgan", param);
	}

	@Override
	public int getCustomerRequestsCount(CustReqVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCustomerRequestsCount", param);
	}

	@Override
	public List<CustReqVO> getCustomerRequestsList(CustReqVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCustomerRequestsList", param);
	}

	@Override
	public CustReqVO getCustomerRequestDetail(CustReqVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCustomerRequestDetail", param);
	}

}
