package com.lgmma.salesPortal.app.model;

import java.util.List;

public class DissOneTeamVO extends PagingParamVO {
	// Table Column
	private String taskId;
	private String taskType;
	private String taskName;
	private String taskCd;
	private String leaderEmpId	;
	private String prodType;
	private String prodTypeD;
	private String specinOutline;
	private String taskIssue;
	private String taskPlan;
	private String afterPlan;
	private String taskOpinion;
	private String expQlt;
	private Double expQty00Cnt;
	private Double expQty01Cnt;
	private Double expQty02Cnt;
	private Double expQty03Cnt;
	private Double expQty00Samount;
	private Double expQty01Samount;
	private Double expQty02Samount;
	private Double expQty03Samount;
	private Double expQty00Bizprofit;
	private Double expQty01Bizprofit;
	private Double expQty02Bizprofit;
	private Double expQty03Bizprofit;
	private String staYmd;
	private String expectCompYmd;
	private String compYmd;
	
	// Search Condition Column
	private String scTaskName;
	private String scLeaderEmpNm;
	private String scLeaderTeamCd;
	private String scFrCompYmd;
	private String scToCompYmd;
	private String scMngEmpNm;
	private String scProdType;
	private String scProdTypeD;
	private String scTaskStat;
	
	// Display Column
	private String stepNm;
	private String apprStat;
	private String leaderEmpNm;
	private String leaderTeamNm;
	private String leaderTeamCd;
	private String staYmdFmt;
	private String expectCompYmdFmt;
	private String compYmdFmt;
	private String prodTypeTxt;
	private String prodTypeDTxt;
	private String regiInfo;
	private String taskStatusCd;

	// Sub table list
	private List<DissKpiVO> dissKpiList;
	private List<DissMemberVO>   dissMemberList;
	private List<DissMemberVO>   dissMemberListaggList;
	private List<DissTaskSpecInVO>   dissTaskSpecInList;
	
	// History Column
	private String stepId;
	private String stepCd;
	
	//품의
	private ApprVO apprVO;
	private String apprActGb;;
	private String apprLineType;
	//appr param
	private String apprType;
	private String apprId;
	private String taskLastStepId;  // 과제마지막스텝id
	private String taskLastStepYn;  // 과제마지막스텝여부
	
	private String myIngYn;
	
	private String regApprFormCont;

	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getLeaderEmpId() {
		return leaderEmpId;
	}
	public void setLeaderEmpId(String leaderEmpId) {
		this.leaderEmpId = leaderEmpId;
	}
	public String getProdType() {
		return prodType;
	}
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}
	public String getProdTypeD() {
		return prodTypeD;
	}
	public void setProdTypeD(String prodTypeD) {
		this.prodTypeD = prodTypeD;
	}
	public String getSpecinOutline() {
		return specinOutline;
	}
	public void setSpecinOutline(String specinOutline) {
		this.specinOutline = specinOutline;
	}
	public String getTaskIssue() {
		return taskIssue;
	}
	public void setTaskIssue(String taskIssue) {
		this.taskIssue = taskIssue;
	}
	public String getTaskPlan() {
		return taskPlan;
	}
	public void setTaskPlan(String taskPlan) {
		this.taskPlan = taskPlan;
	}
	public String getAfterPlan() {
		return afterPlan;
	}
	public void setAfterPlan(String afterPlan) {
		this.afterPlan = afterPlan;
	}
	public String getTaskOpinion() {
		return taskOpinion;
	}
	public void setTaskOpinion(String taskOpinion) {
		this.taskOpinion = taskOpinion;
	}
	public String getExpQlt() {
		return expQlt;
	}
	public void setExpQlt(String expQlt) {
		this.expQlt = expQlt;
	}
	public Double getExpQty00Cnt() {
		return expQty00Cnt;
	}
	public void setExpQty00Cnt(Double expQty00Cnt) {
		this.expQty00Cnt = expQty00Cnt;
	}
	public Double getExpQty01Cnt() {
		return expQty01Cnt;
	}
	public void setExpQty01Cnt(Double expQty01Cnt) {
		this.expQty01Cnt = expQty01Cnt;
	}
	public Double getExpQty02Cnt() {
		return expQty02Cnt;
	}
	public void setExpQty02Cnt(Double expQty02Cnt) {
		this.expQty02Cnt = expQty02Cnt;
	}
	public Double getExpQty03Cnt() {
		return expQty03Cnt;
	}
	public void setExpQty03Cnt(Double expQty03Cnt) {
		this.expQty03Cnt = expQty03Cnt;
	}
	public Double getExpQty00Samount() {
		return expQty00Samount;
	}
	public void setExpQty00Samount(Double expQty00Samount) {
		this.expQty00Samount = expQty00Samount;
	}
	public Double getExpQty01Samount() {
		return expQty01Samount;
	}
	public void setExpQty01Samount(Double expQty01Samount) {
		this.expQty01Samount = expQty01Samount;
	}
	public Double getExpQty02Samount() {
		return expQty02Samount;
	}
	public void setExpQty02Samount(Double expQty02Samount) {
		this.expQty02Samount = expQty02Samount;
	}
	public Double getExpQty03Samount() {
		return expQty03Samount;
	}
	public void setExpQty03Samount(Double expQty03Samount) {
		this.expQty03Samount = expQty03Samount;
	}
	public Double getExpQty00Bizprofit() {
		return expQty00Bizprofit;
	}
	public void setExpQty00Bizprofit(Double expQty00Bizprofit) {
		this.expQty00Bizprofit = expQty00Bizprofit;
	}
	public Double getExpQty01Bizprofit() {
		return expQty01Bizprofit;
	}
	public void setExpQty01Bizprofit(Double expQty01Bizprofit) {
		this.expQty01Bizprofit = expQty01Bizprofit;
	}
	public Double getExpQty02Bizprofit() {
		return expQty02Bizprofit;
	}
	public void setExpQty02Bizprofit(Double expQty02Bizprofit) {
		this.expQty02Bizprofit = expQty02Bizprofit;
	}
	public Double getExpQty03Bizprofit() {
		return expQty03Bizprofit;
	}
	public void setExpQty03Bizprofit(Double expQty03Bizprofit) {
		this.expQty03Bizprofit = expQty03Bizprofit;
	}
	public String getStaYmd() {
		return staYmd;
	}
	public void setStaYmd(String staYmd) {
		this.staYmd = staYmd;
	}
	public String getExpectCompYmd() {
		return expectCompYmd;
	}
	public void setExpectCompYmd(String expectCompYmd) {
		this.expectCompYmd = expectCompYmd;
	}
	public String getCompYmd() {
		return compYmd;
	}
	public void setCompYmd(String compYmd) {
		this.compYmd = compYmd;
	}
	public String getScTaskName() {
		return scTaskName;
	}
	public void setScTaskName(String scTaskName) {
		this.scTaskName = scTaskName;
	}
	public String getScLeaderEmpNm() {
		return scLeaderEmpNm;
	}
	public void setScLeaderEmpNm(String scLeaderEmpNm) {
		this.scLeaderEmpNm = scLeaderEmpNm;
	}
	public String getScLeaderTeamCd() {
		return scLeaderTeamCd;
	}
	public void setScLeaderTeamCd(String scLeaderTeamCd) {
		this.scLeaderTeamCd = scLeaderTeamCd;
	}
	public String getScFrCompYmd() {
		return scFrCompYmd;
	}
	public void setScFrCompYmd(String scFrCompYmd) {
		this.scFrCompYmd = scFrCompYmd;
	}
	public String getScToCompYmd() {
		return scToCompYmd;
	}
	public void setScToCompYmd(String scToCompYmd) {
		this.scToCompYmd = scToCompYmd;
	}
	public String getScMngEmpNm() {
		return scMngEmpNm;
	}
	public void setScMngEmpNm(String scMngEmpNm) {
		this.scMngEmpNm = scMngEmpNm;
	}
	public String getScProdType() {
		return scProdType;
	}
	public void setScProdType(String scProdType) {
		this.scProdType = scProdType;
	}
	public String getScProdTypeD() {
		return scProdTypeD;
	}
	public void setScProdTypeD(String scProdTypeD) {
		this.scProdTypeD = scProdTypeD;
	}
	public String getScTaskStat() {
		return scTaskStat;
	}
	public void setScTaskStat(String scTaskStat) {
		this.scTaskStat = scTaskStat;
	}
	public String getStepNm() {
		return stepNm;
	}
	public void setStepNm(String stepNm) {
		this.stepNm = stepNm;
	}
	public String getApprStat() {
		return apprStat;
	}
	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}
	public String getApprType() {
		return apprType;
	}
	public void setApprType(String apprType) {
		this.apprType = apprType;
	}
	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getLeaderEmpNm() {
		return leaderEmpNm;
	}
	public void setLeaderEmpNm(String leaderEmpNm) {
		this.leaderEmpNm = leaderEmpNm;
	}
	public String getLeaderTeamNm() {
		return leaderTeamNm;
	}
	public void setLeaderTeamNm(String leaderTeamNm) {
		this.leaderTeamNm = leaderTeamNm;
	}
	public String getLeaderTeamCd() {
		return leaderTeamCd;
	}
	public void setLeaderTeamCd(String leaderTeamCd) {
		this.leaderTeamCd = leaderTeamCd;
	}
	public String getStaYmdFmt() {
		return staYmdFmt;
	}
	public void setStaYmdFmt(String staYmdFmt) {
		this.staYmdFmt = staYmdFmt;
	}
	public String getExpectCompYmdFmt() {
		return expectCompYmdFmt;
	}
	public void setExpectCompYmdFmt(String expectCompYmdFmt) {
		this.expectCompYmdFmt = expectCompYmdFmt;
	}
	public String getCompYmdFmt() {
		return compYmdFmt;
	}
	public void setCompYmdFmt(String compYmdFmt) {
		this.compYmdFmt = compYmdFmt;
	}
	public String getProdTypeTxt() {
		return prodTypeTxt;
	}
	public void setProdTypeTxt(String prodTypeTxt) {
		this.prodTypeTxt = prodTypeTxt;
	}
	public String getProdTypeDTxt() {
		return prodTypeDTxt;
	}
	public void setProdTypeDTxt(String prodTypeDTxt) {
		this.prodTypeDTxt = prodTypeDTxt;
	}
	public String getRegiInfo() {
		return regiInfo;
	}
	public void setRegiInfo(String regiInfo) {
		this.regiInfo = regiInfo;
	}
	public String getTaskStatusCd() {
		return taskStatusCd;
	}
	public void setTaskStatusCd(String taskStatusCd) {
		this.taskStatusCd = taskStatusCd;
	}
	public List<DissKpiVO> getDissKpiList() {
		return dissKpiList;
	}
	public void setDissKpiList(List<DissKpiVO> dissKpiList) {
		this.dissKpiList = dissKpiList;
	}
	public List<DissMemberVO> getDissMemberList() {
		return dissMemberList;
	}
	public void setDissMemberList(List<DissMemberVO> dissMemberList) {
		this.dissMemberList = dissMemberList;
	}
	public List<DissMemberVO> getDissMemberListaggList() {
		return dissMemberListaggList;
	}
	public void setDissMemberListaggList(List<DissMemberVO> dissMemberListaggList) {
		this.dissMemberListaggList = dissMemberListaggList;
	}
	public List<DissTaskSpecInVO> getDissTaskSpecInList() {
		return dissTaskSpecInList;
	}
	public void setDissTaskSpecInList(List<DissTaskSpecInVO> dissTaskSpecInList) {
		this.dissTaskSpecInList = dissTaskSpecInList;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getStepCd() {
		return stepCd;
	}
	public void setStepCd(String stepCd) {
		this.stepCd = stepCd;
	}
	public ApprVO getApprVO() {
		return apprVO;
	}
	public void setApprVO(ApprVO apprVO) {
		this.apprVO = apprVO;
	}
	public String getApprActGb() {
		return apprActGb;
	}
	public void setApprActGb(String apprActGb) {
		this.apprActGb = apprActGb;
	}
	public String getApprLineType() {
		return apprLineType;
	}
	public void setApprLineType(String apprLineType) {
		this.apprLineType = apprLineType;
	}
	public String getTaskLastStepId() {
		return taskLastStepId;
	}
	public void setTaskLastStepId(String taskLastStepId) {
		this.taskLastStepId = taskLastStepId;
	}
	public String getTaskLastStepYn() {
		return taskLastStepYn;
	}
	public void setTaskLastStepYn(String taskLastStepYn) {
		this.taskLastStepYn = taskLastStepYn;
	}
	public String getMyIngYn() {
		return myIngYn;
	}
	public void setMyIngYn(String myIngYn) {
		this.myIngYn = myIngYn;
	}
	public String getRegApprFormCont() {
		return regApprFormCont;
	}
	public void setRegApprFormCont(String regApprFormCont) {
		this.regApprFormCont = regApprFormCont;
	}

}
