package com.lgmma.salesPortal.app.model;

public class CustReqVO extends PagingParamVO {
	private int reqxIdxx;
	private int compCode;
	private int webxCode;
	private String compName;
	private String workAddr;
	private String workPost;
	private String bizxAddr;
	private String bizxPost;
	private String telxNum1;
	private String telxNum2;
	private String telxNum3;
	private String faxxNum1;
	private String faxxNum2;
	private String faxxNum3;
	private String bizxNumx;
	private String compCeox;
	private String workSort;
	private String workType;
	private String bizxDate;
	private String webxSite;
	private String bigoText;
	private String indiDivi;
	private String tradDate;
	private String custInfo;
	private String usgeGrad;
	private String usgeQtyx;
	private int salePric;
	private String partProd;
	private String custDivx;
	private String saleDivx;
	private String procStat;
	private int dealIdxx;
	private String dealName;
	private String fileName;
	private String deptIdxx;

	public int getReqxIdxx() {
		return reqxIdxx;
	}
	public void setReqxIdxx(int reqxIdxx) {
		this.reqxIdxx = reqxIdxx;
	}
	public int getCompCode() {
		return compCode;
	}
	public void setCompCode(int compCode) {
		this.compCode = compCode;
	}
	public int getWebxCode() {
		return webxCode;
	}
	public void setWebxCode(int webxCode) {
		this.webxCode = webxCode;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getWorkAddr() {
		return workAddr;
	}
	public void setWorkAddr(String workAddr) {
		this.workAddr = workAddr;
	}
	public String getWorkPost() {
		return workPost;
	}
	public void setWorkPost(String workPost) {
		this.workPost = workPost;
	}
	public String getBizxAddr() {
		return bizxAddr;
	}
	public void setBizxAddr(String bizxAddr) {
		this.bizxAddr = bizxAddr;
	}
	public String getBizxPost() {
		return bizxPost;
	}
	public void setBizxPost(String bizxPost) {
		this.bizxPost = bizxPost;
	}
	public String getTelxNum1() {
		return telxNum1;
	}
	public void setTelxNum1(String telxNum1) {
		this.telxNum1 = telxNum1;
	}
	public String getFaxxNum1() {
		return faxxNum1;
	}
	public void setFaxxNum1(String faxxNum1) {
		this.faxxNum1 = faxxNum1;
	}
	public String getBizxNumx() {
		return bizxNumx;
	}
	public void setBizxNumx(String bizxNumx) {
		this.bizxNumx = bizxNumx;
	}
	public String getCompCeox() {
		return compCeox;
	}
	public void setCompCeox(String compCeox) {
		this.compCeox = compCeox;
	}
	public String getWorkSort() {
		return workSort;
	}
	public void setWorkSort(String workSort) {
		this.workSort = workSort;
	}
	public String getWorkType() {
		return workType;
	}
	public void setWorkType(String workType) {
		this.workType = workType;
	}
	public String getBizxDate() {
		return bizxDate;
	}
	public void setBizxDate(String bizxDate) {
		this.bizxDate = bizxDate;
	}
	public String getWebxSite() {
		return webxSite;
	}
	public void setWebxSite(String webxSite) {
		this.webxSite = webxSite;
	}
	public String getBigoText() {
		return bigoText;
	}
	public void setBigoText(String bigoText) {
		this.bigoText = bigoText;
	}
	public String getIndiDivi() {
		return indiDivi;
	}
	public void setIndiDivi(String indiDivi) {
		this.indiDivi = indiDivi;
	}
	public String getTradDate() {
		return tradDate;
	}
	public void setTradDate(String tradDate) {
		this.tradDate = tradDate;
	}
	public String getCustInfo() {
		return custInfo;
	}
	public void setCustInfo(String custInfo) {
		this.custInfo = custInfo;
	}
	public String getUsgeGrad() {
		return usgeGrad;
	}
	public void setUsgeGrad(String usgeGrad) {
		this.usgeGrad = usgeGrad;
	}
	public String getUsgeQtyx() {
		return usgeQtyx;
	}
	public void setUsgeQtyx(String usgeQtyx) {
		this.usgeQtyx = usgeQtyx;
	}
	public int getSalePric() {
		return salePric;
	}
	public void setSalePric(int salePric) {
		this.salePric = salePric;
	}
	public String getPartProd() {
		return partProd;
	}
	public void setPartProd(String partProd) {
		this.partProd = partProd;
	}
	public String getCustDivx() {
		return custDivx;
	}
	public void setCustDivx(String custDivx) {
		this.custDivx = custDivx;
	}
	public String getSaleDivx() {
		return saleDivx;
	}
	public void setSaleDivx(String saleDivx) {
		this.saleDivx = saleDivx;
	}
	public String getProcStat() {
		return procStat;
	}
	public void setProcStat(String procStat) {
		this.procStat = procStat;
	}
	public int getDealIdxx() {
		return dealIdxx;
	}
	public void setDealIdxx(int dealIdxx) {
		this.dealIdxx = dealIdxx;
	}
	public String getDealName() {
		return dealName;
	}
	public void setDealName(String dealName) {
		this.dealName = dealName;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getDeptIdxx() {
		return deptIdxx;
	}
	public void setDeptIdxx(String deptIdxx) {
		this.deptIdxx = deptIdxx;
	}
	public String getTelxNum2() {
		return telxNum2;
	}
	public void setTelxNum2(String telxNum2) {
		this.telxNum2 = telxNum2;
	}
	public String getTelxNum3() {
		return telxNum3;
	}
	public void setTelxNum3(String telxNum3) {
		this.telxNum3 = telxNum3;
	}
	public String getFaxxNum2() {
		return faxxNum2;
	}
	public void setFaxxNum2(String faxxNum2) {
		this.faxxNum2 = faxxNum2;
	}
	public String getFaxxNum3() {
		return faxxNum3;
	}
	public void setFaxxNum3(String faxxNum3) {
		this.faxxNum3 = faxxNum3;
	}
}
