package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.DirectOrderSimpleVO;
import com.lgmma.salesPortal.app.model.SalePriceCloseDtlVO;
import com.lgmma.salesPortal.app.model.SalePriceCloseVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterHisVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;

public interface SalePriceMasterDao {

	int getsalePriceMasterListCount(SalePriceMasterVO param);
	
	List<SalePriceMasterVO> getsalePriceMasterList(SalePriceMasterVO param);
	
	SalePriceMasterVO getsalePriceMasterDetail(SalePriceMasterVO param);

	List<SalePriceMasterHisVO> getsalePriceMasterHisList(SalePriceMasterVO param);
	
	int duplicateChkSalePriceMaster(SalePriceMasterHisVO param);
	
	void createSalePriceMasterHis(SalePriceMasterHisVO param);
	
	SalePriceMasterHisVO mergeSalePriceMaster(SalePriceMasterHisVO param);
	
	List<SalePriceMasterVO> getSalePriceMasterMergeTargetList(SalePriceMasterVO param);
	
	int checkSalePriceMasterMergeTargetCnt(SalePriceMasterVO param);
	
	void createSalePriceMasterMergeTarget(SalePriceMasterVO param);
	
	void updateSalePriceMasterMergeTarget(SalePriceMasterVO param);
	
	void deleteSalePriceMasterMergeTarget(SalePriceMasterVO param);

	void deleteMonthlyCloseDetail(SalePriceCloseVO param);

	void createMonthlyClose(SalePriceCloseVO param);

	int getMonthlyCloseListCount(SalePriceCloseVO param);

	List<SalePriceCloseVO> getMonthlyCloseList(SalePriceCloseVO param);

	int getPriceMasterExistsOrderListCount(SalePriceCloseVO param);

	List<SalePriceMasterVO> getPriceMasterExistsOrderList(SalePriceCloseVO param);

	int getOrderByPriceListCount(SalePriceMasterVO param);

	List<DirectOrderMasterVO> getOrderByPriceList(SalePriceMasterVO param);

	SalePriceCloseVO getSingleMonthlyClose(SalePriceCloseVO param);

	List<SalePriceCloseDtlVO> getMonthlyCloseDetailListBeforeFinish(SalePriceCloseVO param);

	void updateMonthlyClose(SalePriceCloseVO param);

	void insertMonthlyCloseDetail(SalePriceCloseDtlVO detail);

	List<SalePriceCloseDtlVO> getMonthlyCloseDetailListAfterFinish(SalePriceCloseVO param);

	void updateMonthlyCloseApprId(SalePriceCloseVO param);

	List<SalePriceCloseVO> getPriceMasterMonthlyListByApprId(SalePriceCloseVO param);

	int getDifferentOrderPriceAndMasterCount(DirectOrderSimpleVO param);

	List<DirectOrderSimpleVO> getDifferentOrderPriceAndMasterList(DirectOrderSimpleVO param);

	void changeSalePriceCloseStatus(SalePriceCloseVO param);
	
}