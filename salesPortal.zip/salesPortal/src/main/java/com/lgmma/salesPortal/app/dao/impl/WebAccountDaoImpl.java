package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.WebAccountDao;
import com.lgmma.salesPortal.app.model.LoginMastVO;
import com.lgmma.salesPortal.app.model.LoginReqVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;
import com.lgmma.salesPortal.common.mybatis.typehandler.VkorgTypeHandler;

@Repository
public class WebAccountDaoImpl implements WebAccountDao {

    private static final String MAPPER_NAMESPACE = "WEB_ACCOUNT_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public int getNewWebAccountRequestsCount(LoginReqVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getNewWebAccountRequestsCount", param);
	}

	@Override
	public List<LoginReqVO> getNewWebAccountRequests(LoginReqVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getNewWebAccountRequests", param);
	}

	@Override
	public LoginReqVO getWebAccountRequestDetail(LoginReqVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getWebAccountRequestDetail", param);
	}

	@Override
	public void updateWebAccountStatus(LoginReqVO param) {
		sqlSession.selectOne(MAPPER_NAMESPACE + "updateWebAccountStatus", param);
	}

	@Override
	public int getExistsBizNumCount(String bizxNumx) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getExistsBizNumCount", bizxNumx);
	}

	@Override
	public int getExistsLoginIdCount(String lognIdxx) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getExistsLoginIdCount", lognIdxx);
	}

	@Override
	public void updateLoginCompByLoginReq(LoginReqVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateLoginCompByLoginReq", param);
	}

	@Override
	public int createLoginCompByLoginReq(LoginReqVO param) {
		return sqlSession.insert(MAPPER_NAMESPACE + "createLoginCompByLoginReq", param);
	}

	@Override
	public void createLoginUser(LoginReqVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createLoginUser", param);
	}

	@Override
	public int getWebAccountListCount(LoginUserVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getWebAccountListCount", param);
	}

	@Override
	public List<LoginUserVO> getWebAccountList(LoginUserVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getWebAccountList", param);
	}

	@Override
	public LoginUserVO getWebAccountDetail(LoginUserVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getWebAccountDetail", param);
	}

	@Override
	public int getWebAccountCompListCount(LoginMastVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getWebAccountCompListCount", param);
	}

	@Override
	public List<LoginMastVO> getWebAccountCompList(LoginMastVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getWebAccountCompList", param);
	}

	@Override
	public void initWebAccountPassword(LoginUserVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "initWebAccountPassword", param);
	}

	@Override
	public void updateLoginUser(LoginUserVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateLoginUser", param);
	}

	@Override
	public void updateLoginComp(LoginUserVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateLoginComp", param);
	}

	@Override
	public void deleteLoginMast(LoginMastVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteLoginMast", param);
	}

	@Override
	public void createLoginMast(LoginMastVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createLoginMast", param);
	}

	@Override
	public void moveCustOfWebAccount(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "moveCustOfWebAccount", paramMap);
	}
	
}
