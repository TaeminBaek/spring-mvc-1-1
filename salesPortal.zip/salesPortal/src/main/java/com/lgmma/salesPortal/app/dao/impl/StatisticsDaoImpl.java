package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.StatisticsDao;
import com.lgmma.salesPortal.app.model.StatisticsCustSuppVO;
import com.lgmma.salesPortal.app.model.StatisticsOrderVO;


@Repository
public class StatisticsDaoImpl implements StatisticsDao {

    private static final String MAPPER_NAMESPACE = "STATISTICS_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public List<StatisticsOrderVO> getStatOrderList(StatisticsOrderVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getStatOrderList", param);
	}
	
	@Override
	public List<StatisticsOrderVO> getStatOrderView(StatisticsOrderVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getStatOrderView", param);
	}
	
	@Override
	public List<StatisticsCustSuppVO> getStatCustSuppList(StatisticsCustSuppVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getStatCustSuppList", param);
	}
	
	@Override
	public List<StatisticsCustSuppVO> getStatCustSuppView(StatisticsCustSuppVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getStatCustSuppView", param);
	}
	
	@Override
	public List<StatisticsCustSuppVO> getStatCustSuppDetail(StatisticsCustSuppVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getStatCustSuppDetail", param);
	}
}
