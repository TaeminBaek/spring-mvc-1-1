package com.lgmma.salesPortal.app.model;

public class CustCreditRateApprVO extends PagingParamVO {
	
	private String custCode;			/* 고객코드 */
	private String custName;			/* 고객명 */		
	private String repreName; 		/* 데표자명 */
	private String regDt;  			/* 등록일자 */
	private String uptDt; 			/* 변동일자 */
	private String bsnssCode;   		/* 사업자번호 */
	private String corporationCode;	/* 법인번호 */
	private String socialSecuCode; 	/* 주민등록번호 */
	private String delYn; 			/* 삭제여부 */
	
	private String partnNameAg;
	private String partnNumbAg;
	private String salesOrg;
	private String userType;
	
	public String getCustCode() {
		return custCode;
	}
	
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	
	public String getCustName() {
		return custName;
	}
	
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	public String getRepreName() {
		return repreName;
	}
	
	public void setRepreName(String repreName) {
		this.repreName = repreName;
	}
	
	public String getRegDt() {
		return regDt;
	}
	
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	
	public String getUptDt() {
		return uptDt;
	}
	
	public void setUptDt(String uptDt) {
		this.uptDt = uptDt;
	}
	
	public String getBsnssCode() {
		return bsnssCode;
	}
	
	public void setBsnssCode(String bsnssCode) {
		this.bsnssCode = bsnssCode;
	}
	
	public String getCorporationCode() {
		return corporationCode;
	}
	
	public void setCorporationCode(String corporationCode) {
		this.corporationCode = corporationCode;
	}
	
	public String getSocialSecuCode() {
		return socialSecuCode;
	}
	
	public void setSocialSecuCode(String socialSecuCode) {
		this.socialSecuCode = socialSecuCode;
	}
	
	public String getDelYn() {
		return delYn;
	}
	
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	
	public String getPartnNameAg() {
		return partnNameAg;
	}
	
	public void setPartnNameAg(String partnNameAg) {
		this.partnNameAg = partnNameAg;
	}
	
	public String getPartnNumbAg() {
		return partnNumbAg;
	}
	
	public void setPartnNumbAg(String partnNumbAg) {
		this.partnNumbAg = partnNumbAg;
	}
	
	public String getSalesOrg() {
		return salesOrg;
	}
	
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	
	public String getUserType() {
		return userType;
	}
	
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	
	
}
