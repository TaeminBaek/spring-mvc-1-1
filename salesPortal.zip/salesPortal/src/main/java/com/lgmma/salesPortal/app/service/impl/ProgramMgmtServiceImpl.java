package com.lgmma.salesPortal.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.InitBinder;

import com.lgmma.salesPortal.app.dao.ProgramDao;
import com.lgmma.salesPortal.app.model.ProgramVO;
import com.lgmma.salesPortal.app.service.ProgramMgmtService;
import com.lgmma.salesPortal.common.util.Util;

@Service
public class ProgramMgmtServiceImpl implements ProgramMgmtService {

	@Autowired
	private ProgramDao programDao;


	@Override
	public int getProgramCount(ProgramVO param) {
		return programDao.getProgramCount(param);
	}

	@Override
	public List<ProgramVO> getProgramList(ProgramVO param) {
		return programDao.getProgramList(param);
	}
	@Override
	public void createProgram(ProgramVO param) {
		param.setPrgId(Util.getUUID());
		programDao.createProgram(param);
	}
	@Override
	public void updateProgram(ProgramVO param) {
		programDao.updateProgram(param);
	}

}
