package com.lgmma.salesPortal.app.model;

public class LoginMastVO extends PagingParamVO {

	private String userNumx;
	private String vkorg;
	private String vkorgText;
	private String compCode;
	private String kunnr;
	private String name1;
	private String primIsxx;

	public String getUserNumx() {
		return userNumx;
	}
	public void setUserNumx(String userNumx) {
		this.userNumx = userNumx;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getPrimIsxx() {
		return primIsxx;
	}
	public void setPrimIsxx(String primIsxx) {
		this.primIsxx = primIsxx;
	}
	public String getVkorgText() {
		return vkorgText;
	}
	public void setVkorgText(String vkorgText) {
		this.vkorgText = vkorgText;
	}
}
