package com.lgmma.salesPortal.app.dao;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.DissImpDevVO;
import com.lgmma.salesPortal.app.model.EmployVO;

public interface DissImpDevDao {
	
	void createDissImpDev(DissImpDevVO param);
	
	int getDissTaskNameCount(DissImpDevVO param);

	int getDissImpDevListCount(DissImpDevVO param);
	
	List<DissImpDevVO> getDissImpDevList(DissImpDevVO param);
	
	List<DissImpDevVO> getDissImpDevLeaderTeamList();
	
	List<CommonCodeVO> getDissStepGroupToStepCdList(CommonCodeVO param);
	
	DissImpDevVO getDissImpDevDetail(DissImpDevVO param);
	
	void updateDissImpDev(DissImpDevVO param);
	
	void deleteDissImpDevAll(DissImpDevVO param);
	
	void updateDissImpDevProposalAppr(DissImpDevVO param);
	
	void createDissImpDevHis(DissImpDevVO param);
	
	void updateDissImpDevHisProposalAppr(DissImpDevVO param);
	
	void createDissImpDevHisProposalAppr(DissImpDevVO param);
	
	void createDissImpDevHisProposalApprRew(DissImpDevVO param);
	
	void createDissImpDevHisLevelChgAppr(DissImpDevVO param);
	
	void updateDissImpDevHis(DissImpDevVO param);
	
	void deleteDissImpDevHisAll(DissImpDevVO param);
	
	DissImpDevVO getDissImpDevHis(DissImpDevVO param);
	
	DissImpDevVO getDissImpDevHisDetail(DissImpDevVO param);

	List<DissImpDevVO> getDissImpDevListExcelDownload(DissImpDevVO param);

	void updateLeader(DissImpDevVO param);

	List<EmployVO> getEmployByLeaderChange(Map<String, String> map);
}
