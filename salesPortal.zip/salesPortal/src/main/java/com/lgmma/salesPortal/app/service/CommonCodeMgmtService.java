package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.CodeGroupVO;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.SampleVO;


public interface CommonCodeMgmtService {
	

	public int getCodeGroupCount(CodeGroupVO param);
	
	List<CodeGroupVO> getCodeGroupList(CodeGroupVO param);

	public void updateCodeGroup(CodeGroupVO param);

	public void createCodeGroup(CodeGroupVO param);

	public int getCommonCodeCount(CommonCodeVO param);

	public List<CommonCodeVO> getCommonCodeList(CommonCodeVO param);

	public void updateCommonCode(CommonCodeVO param);

	public void createCommonCode(CommonCodeVO param);

	
}
