package com.lgmma.salesPortal.common.props;

public enum Vkorg {
/**
 * 영업조직, 제품군 영역으로서
*/
	 MMA("1000","MMA")
	,PMMA("3000","PMMA")
	;
	String code = null;
	String name = null;

	private Vkorg(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static Vkorg getVkorg(String code) {
		for(Vkorg type : Vkorg.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
		
}
