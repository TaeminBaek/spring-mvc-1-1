package com.lgmma.salesPortal.common.props;

public enum FilePath {
/**
 * 파일패스구분으로서
*/
	 FILE_PATH_RNA("RNA","RNA","UPLOAD.RNA.Path")		// 품의서기본 첨부(기존)
	,FILE_PATH_APPR("APPR","APPR","UPLOAD.RNA.Path")	// TO-BE 품의서 기본 첨부
	,FILE_PATH_CUST("CUST","CUST","file.cust.path")		// 고객정보 첨부파일(사업자등록증)
	,FILE_PATH_TMP("TEMP","TEMP","file.temp.path")		// 기본업로드시임시파일위치
	,FILE_PATH_VOC("VOC","VOC","UPLOAD.CUSTSUPP.Path")	// VOC 기본 파일첨부
	,FILE_PATH_SAM("SAM","SAM","UPLOAD.RNA.Path")		// 견본 인수증 파일첨부
	,FILE_PATH_PUB("PUB","PUB","file.pub.path")		// 공통파일업로드 팝업에서 사용
	,FILE_PATH_TEMPLATE("TEMPLATE","TEMPLATE","file.template.path")		// 파일명으로템플릿파일
	;

	String	code					= null;	// 파일패스구분코드 
	String	name					= null;	// 파일패스구분명 
	String	filePathProp			= null;	// 파일패스프로퍼티key

	private FilePath(String code, String name, String filePathProp) {
		this.code			= code;
		this.name			= name;
		this.filePathProp	= filePathProp;
	}

	public static FilePath getFilePath(String code) {
		for(FilePath type : FilePath.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getFilePathProp() {
		return filePathProp;
	}

	public void setFilePathProp(String filePathProp) {
		this.filePathProp = filePathProp;
	}

}
