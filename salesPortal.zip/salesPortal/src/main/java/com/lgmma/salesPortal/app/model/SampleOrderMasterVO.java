package com.lgmma.salesPortal.app.model;

import java.util.List;

public class SampleOrderMasterVO extends DirectOrderMasterVO {
	private String sawnName;
	private String apprType;
	private String apprTypeName;
	private String apprStat;
	private String apprStatName;
	private String apprTitle;
	private String name1;
	private String samFileId;
	private Integer samFileCnt;
	private String regiDateYmd;
	private String currency;
	private String vactIdxx;
	private String vocxIdxx;
	private String sapRtnMessage;
	private List<VocGradeVO> vocItemList;
	private String migIdxx;
	private String vocContText;
	private String vocRivalCorp;
	private String vocRivalItems;
	private String vocSetMaker;
	private String vocEstimatedUsage;
	private String vocLognName;

	public String getRegiDateYmd() {
		return regiDateYmd;
	}

	public void setRegiDateYmd(String regiDateYmd) {
		this.regiDateYmd = regiDateYmd;
	}

	public String getSamFileId() {
		return samFileId;
	}

	public void setSamFileId(String samFileId) {
		this.samFileId = samFileId;
	}

	public Integer getSamFileCnt() {
		return samFileCnt;
	}

	public void setSamFileCnt(Integer samFileCnt) {
		this.samFileCnt = samFileCnt;
	}

	public String getName1() {
		return name1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}

	public String getApprTitle() {
		return apprTitle;
	}

	public void setApprTitle(String apprTitle) {
		this.apprTitle = apprTitle;
	}

	public String getSawnName() {
		return sawnName;
	}

	public void setSawnName(String sawnName) {
		this.sawnName = sawnName;
	}

	public String getApprTypeName() {
		return apprTypeName;
	}

	public void setApprTypeName(String apprTypeName) {
		this.apprTypeName = apprTypeName;
	}

	public String getApprStatName() {
		return apprStatName;
	}

	public void setApprStatName(String apprStatName) {
		this.apprStatName = apprStatName;
	}

	public String getApprType() {
		return apprType;
	}

	public void setApprType(String apprType) {
		this.apprType = apprType;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getVactIdxx() {
		return vactIdxx;
	}

	public void setVactIdxx(String vactIdxx) {
		this.vactIdxx = vactIdxx;
	}

	public String getVocxIdxx() {
		return vocxIdxx;
	}

	public void setVocxIdxx(String vocxIdxx) {
		this.vocxIdxx = vocxIdxx;
	}

	public String getSapRtnMessage() {
		return sapRtnMessage;
	}

	public void setSapRtnMessage(String sapRtnMessage) {
		this.sapRtnMessage = sapRtnMessage;
	}

	public List<VocGradeVO> getVocItemList() {
		return vocItemList;
	}

	public void setVocItemList(List<VocGradeVO> vocItemList) {
		this.vocItemList = vocItemList;
	}

	public String getMigIdxx() {
		return migIdxx;
	}

	public void setMigIdxx(String migIdxx) {
		this.migIdxx = migIdxx;
	}

	public String getApprStat() {
		return apprStat;
	}

	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}

	public String getVocContText() {
		return vocContText;
	}

	public void setVocContText(String vocContText) {
		this.vocContText = vocContText;
	}

	public String getVocRivalCorp() {
		return vocRivalCorp;
	}

	public void setVocRivalCorp(String vocRivalCorp) {
		this.vocRivalCorp = vocRivalCorp;
	}

	public String getVocRivalItems() {
		return vocRivalItems;
	}

	public void setVocRivalItems(String vocRivalItems) {
		this.vocRivalItems = vocRivalItems;
	}

	public String getVocSetMaker() {
		return vocSetMaker;
	}

	public void setVocSetMaker(String vocSetMaker) {
		this.vocSetMaker = vocSetMaker;
	}

	public String getVocEstimatedUsage() {
		return vocEstimatedUsage;
	}

	public void setVocEstimatedUsage(String vocEstimatedUsage) {
		this.vocEstimatedUsage = vocEstimatedUsage;
	}

	public String getVocLognName() {
		return vocLognName;
	}

	public void setVocLognName(String vocLognName) {
		this.vocLognName = vocLognName;
	}
}
