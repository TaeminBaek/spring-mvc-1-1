package com.lgmma.salesPortal.app.model;

import org.hibernate.validator.constraints.NotBlank;

import com.lgmma.salesPortal.common.model.validation.Max2Byte;

/**
 * @author jklee
 * 신규 등록시 사용하는 항목들만 모아서 만든 vo
 */
public class NewCompOrganEditVO extends CompOrganEditVO {
	@NotBlank(message="업태명{errors.required}")
	@Max2Byte(value=15, eng=30, message="업태명{errors.maxlength.kor}")
	private String j1kftbus;
	@NotBlank(message="업종명{errors.required}")
	@Max2Byte(value=15, eng=30, message="업종명{errors.maxlength.kor}")
	private String j1kftind;
	@Max2Byte(value=15, eng=30, message="제품{errors.maxlength.kor}")
	private String usgeGrad;
	@Max2Byte(value=14, eng=28, message="예상수량{errors.maxlength.kor}")
	private String usgeQtyx;
	private int salePric;
	@Max2Byte(value=15, eng=30, message="용도{errors.maxlength.kor}")
	private String partProd;
	private String usgeQtyxUnit;
	private String bzirk;
	@NotBlank(message="관리팀{errors.required}")
	private String vkbur;
	@NotBlank(message="영업그룹{errors.required}")
	private String vkgrp;
	@NotBlank(message="통화{errors.required}")
	private String waers;
	@NotBlank(message="계정지정그룹{errors.required}")
	private String ktgrd;
	@NotBlank(message="영업사원{errors.required}")
	private String saleMan1;
	private String sawnName;
	private String creditRating;
	private String limitAmount;
	private String limitCurrency;
	private String limitExpYmd;
	private String expCompCode;
	private String expCntCode;
	@Max2Byte(value=50, eng=100, message="거래선정보{errors.maxlength.kor}")
	private String custInfo;
	@NotBlank(message="거래예정일{errors.required}")
	private String guarExptYmd;
	private String dealIdxx;
	private String dealCompNm;

	public String getJ1kftbus() {
		return j1kftbus;
	}
	public void setJ1kftbus(String j1kftbus) {
		this.j1kftbus = j1kftbus;
	}
	public String getJ1kftind() {
		return j1kftind;
	}
	public void setJ1kftind(String j1kftind) {
		this.j1kftind = j1kftind;
	}
	public String getUsgeGrad() {
		return usgeGrad;
	}
	public void setUsgeGrad(String usgeGrad) {
		this.usgeGrad = usgeGrad;
	}
	public String getUsgeQtyx() {
		return usgeQtyx;
	}
	public void setUsgeQtyx(String usgeQtyx) {
		this.usgeQtyx = usgeQtyx;
	}
	public int getSalePric() {
		return salePric;
	}
	public void setSalePric(int salePric) {
		this.salePric = salePric;
	}
	public String getPartProd() {
		return partProd;
	}
	public void setPartProd(String partProd) {
		this.partProd = partProd;
	}
	public String getUsgeQtyxUnit() {
		return usgeQtyxUnit;
	}
	public void setUsgeQtyxUnit(String usgeQtyxUnit) {
		this.usgeQtyxUnit = usgeQtyxUnit;
	}
	public String getBzirk() {
		return bzirk;
	}
	public void setBzirk(String bzirk) {
		this.bzirk = bzirk;
	}
	public String getVkbur() {
		return vkbur;
	}
	public void setVkbur(String vkbur) {
		this.vkbur = vkbur;
	}
	public String getVkgrp() {
		return vkgrp;
	}
	public void setVkgrp(String vkgrp) {
		this.vkgrp = vkgrp;
	}
	public String getWaers() {
		return waers;
	}
	public void setWaers(String waers) {
		this.waers = waers;
	}
	public String getKtgrd() {
		return ktgrd;
	}
	public void setKtgrd(String ktgrd) {
		this.ktgrd = ktgrd;
	}
	public String getSaleMan1() {
		return saleMan1;
	}
	public void setSaleMan1(String saleMan1) {
		this.saleMan1 = saleMan1;
	}
	public String getSawnName() {
		return sawnName;
	}
	public void setSawnName(String sawnName) {
		this.sawnName = sawnName;
	}
	public String getCreditRating() {
		return creditRating;
	}
	public void setCreditRating(String creditRating) {
		this.creditRating = creditRating;
	}
	public String getLimitAmount() {
		return limitAmount;
	}
	public void setLimitAmount(String limitAmount) {
		this.limitAmount = limitAmount;
	}
	public String getLimitCurrency() {
		return limitCurrency;
	}
	public void setLimitCurrency(String limitCurrency) {
		this.limitCurrency = limitCurrency;
	}
	public String getLimitExpYmd() {
		return limitExpYmd;
	}
	public void setLimitExpYmd(String limitExpYmd) {
		this.limitExpYmd = limitExpYmd;
	}
	public String getExpCompCode() {
		return expCompCode;
	}
	public void setExpCompCode(String expCompCode) {
		this.expCompCode = expCompCode;
	}
	public String getExpCntCode() {
		return expCntCode;
	}
	public void setExpCntCode(String expCntCode) {
		this.expCntCode = expCntCode;
	}
	public String getCustInfo() {
		return custInfo;
	}
	public void setCustInfo(String custInfo) {
		this.custInfo = custInfo;
	}
	public String getGuarExptYmd() {
		return guarExptYmd;
	}
	public void setGuarExptYmd(String guarExptYmd) {
		this.guarExptYmd = guarExptYmd;
	}
	public String getDealIdxx() {
		return dealIdxx;
	}
	public void setDealIdxx(String dealIdxx) {
		this.dealIdxx = dealIdxx;
	}
	public String getDealCompNm() {
		return dealCompNm;
	}
	public void setDealCompNm(String dealCompNm) {
		this.dealCompNm = dealCompNm;
	}
}
