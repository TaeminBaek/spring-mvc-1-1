package com.lgmma.salesPortal.common.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lgmma.salesPortal.common.model.DDLBItem;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.schedule.service.JobScheduledService;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.Util;

@Controller
public class StandardController {
	@Autowired MessageSourceAccessor messageSourceAccessor;
	@Autowired JobScheduledService jobScheduledService;
	
	@RequestMapping(value = "/getUUID")
	@ResponseBody
	public Object getUUID() {
		String UUID = Util.getUUID();
		return JsonResponse.asSuccess("UUID", UUID);
	}

	@RequestMapping(value = "/getYearsDDLB")
	@ResponseBody
	public Map getYearsDDLB() {
		int startYear = new Integer(messageSourceAccessor.getMessage("appr.start.year", "2016"));
		int currYear = new Integer(DateUtil.getCurrentYear());
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		while(startYear <= currYear) {
			DDLBItem item = new DDLBItem();
			item.setCode(currYear+"");
			item.setText(currYear+"");
			currYear--;
			items.add(item);
		}
			
		return JsonResponse.asSuccess("items", items);
	}
	@RequestMapping("favicon.ico")
	String favicon() {
		return "forward:/web-resource/images/favicon.ico";
	}

}
