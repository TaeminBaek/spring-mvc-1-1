package com.lgmma.salesPortal.app.model;

public class SapOrderListVO extends PagingParamVO {

	private String gubun;		//로그인자
	
	//SAP 주문목록
	private String vbeln;		//주문번호
	private String audat;		//주문날자
	private String matnr;		//제품ID
	private String vdatu;		//요청날자
	private String name1;		//주문자1
	private String kwmeng;		//주문수량 ,드럼수량 공통
	private String lfimg;		//출고수량
	private String wbstk;		//주문상태
	private String ztext;		//주문상태명
	private String posnv;		//모르겠으나 필요함
	private String textLine;	//모르겠으나 필요함
	
	
	private String posnr;		//배송정보 조회용
	
	//배송조회용
	private String lfdat;       //납품일
	private String vbelv;     //선행 영업/유통문서
	private String street;    //주소
	private String telNumber; //인도처전화번호
	private String vstel;     //출하지점/입고지점
	private String name2;      //운송사명
	private String name3;      //기사명
	private String street1;;  //차량번호
	private String telNumber1;//기사 연락처
	
	
	
	public String getPosnr() {
		return posnr;
	}
	public void setPosnr(String posnr) {
		this.posnr = posnr;
	}
	public String getLfdat() {
		return lfdat;
	}
	public void setLfdat(String lfdat) {
		this.lfdat = lfdat;
	}
	public String getVbelv() {
		return vbelv;
	}
	public void setVbelv(String vbelv) {
		this.vbelv = vbelv;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getTelNumber() {
		return telNumber;
	}
	public void setTelNumber(String telNumber) {
		this.telNumber = telNumber;
	}
	public String getVstel() {
		return vstel;
	}
	public void setVstel(String vstel) {
		this.vstel = vstel;
	}
	public String getName3() {
		return name3;
	}
	public void setName3(String name3) {
		this.name3 = name3;
	}
	public String getStreet1() {
		return street1;
	}
	public void setStreet1(String street1) {
		this.street1 = street1;
	}
	public String getTelNumber1() {
		return telNumber1;
	}
	public void setTelNumber1(String telNumber1) {
		this.telNumber1 = telNumber1;
	}
	public String getGubun() {
		return gubun;
	}
	public void setGubun(String gubun) {
		this.gubun = gubun;
	}
	public String getVbeln() {
		return vbeln;
	}
	public void setVbeln(String vbeln) {
		this.vbeln = vbeln;
	}
	public String getAudat() {
		return audat;
	}
	public void setAudat(String audat) {
		this.audat = audat;
	}
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getVdatu() {
		return vdatu;
	}
	public void setVdatu(String vdatu) {
		this.vdatu = vdatu;
	}
	public String getName2() {
		return name2;
	}
	public void setName2(String name2) {
		this.name2 = name2;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getKwmeng() {
		return kwmeng;
	}
	public void setKwmeng(String kwmeng) {
		this.kwmeng = kwmeng;
	}
	public String getLfimg() {
		return lfimg;
	}
	public void setLfimg(String lfimg) {
		this.lfimg = lfimg;
	}
	public String getWbstk() {
		return wbstk;
	}
	public void setWbstk(String wbstk) {
		this.wbstk = wbstk;
	}
	public String getZtext() {
		return ztext;
	}
	public void setZtext(String ztext) {
		this.ztext = ztext;
	}
	public String getPosnv() {
		return posnv;
	}
	public void setPosnv(String posnv) {
		this.posnv = posnv;
	}
	public String getTextLine() {
		return textLine;
	}
	public void setTextLine(String textLine) {
		this.textLine = textLine;
	}
	
	
	
	
}
