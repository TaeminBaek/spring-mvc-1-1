package com.lgmma.salesPortal.common.schedule.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.model.CompOrganByErpVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.DissDelayGateReviewAlarmVO;
import com.lgmma.salesPortal.app.model.DissDelayTaskAlarmVO;
import com.lgmma.salesPortal.app.model.JobScheduleParamVO;
import com.lgmma.salesPortal.app.model.NiceCompGradeVO;
import com.lgmma.salesPortal.app.model.ProductStockVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.model.SampleOrderMasterVO;
import com.lgmma.salesPortal.common.schedule.dao.JobScheduledDao;
import com.lgmma.salesPortal.security.authentication.UserInfo;

@Repository
public class JobScheduledDaoImpl implements JobScheduledDao {

	private static final String MAPPER_NAMESPACE = "JOBSCHEDULED_MAPPER.";

	@Autowired(required = true)
	protected SqlSession sqlSession;

	@Override
	public void mergeProduct(List<ProductVO> productList) {
		for (ProductVO product : productList) {
			sqlSession.update(MAPPER_NAMESPACE + "mergeProduct", product);
		}
	}

	@Override
	public void deleteProductStockAll() {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteProductStockAll");
	}

	@Override
	public void insertProductStocks(List<ProductStockVO> productStockList) {
		for (ProductStockVO productStock : productStockList) {
			sqlSession.insert(MAPPER_NAMESPACE + "insertProductStock", productStock);
		}
	}

	@Override
	@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	public void excUpdateOrderWadatIstFromSapByVbeln(SampleOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "excUpdateOrderWadatIstFromSapByVbeln", param);
	}

	@Override
	public List<SampleOrderMasterVO> getUpdateOrderWadatIstList(JobScheduleParamVO jobScheduleParamVO) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getUpdateOrderWadatIstFromSapList", jobScheduleParamVO);
	}

	@Override
	public void deleteCompOrganByErp() {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteCompOrganByErp");
	}

	@Override
	public void insertCompOrganByErp(CompOrganByErpVO compOrganByErpVO) {
		sqlSession.insert(MAPPER_NAMESPACE + "insertCompOrganByErp", compOrganByErpVO);
	}

	@Override
	public List<NiceCompGradeVO> getCompListForUpdateGrade(NiceCompGradeVO vo) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCompListForUpdateGrade", vo);
	}
	@Override
	public List<NiceCompGradeVO> getCompListForUploadKed() {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCompListForUploadKed");
	}

	@Override
	public NiceCompGradeVO getFinalCompGrade(NiceCompGradeVO vo) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getFinalCompGrade", vo);
	}

	@Override
	public void createNiceCompanyGrade(NiceCompGradeVO vo) {
		sqlSession.update(MAPPER_NAMESPACE + "createNiceCompanyGrade", vo);
	}

	@Override
	public void updateCompanyGrade(CompanyVO companyVo) {
		sqlSession.update(MAPPER_NAMESPACE + "updateCompanyGrade", companyVo);
	}

	@Override
	public List<CompanyVO> getCompListForSendGradeToERP(CompanyVO companyVo) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCompListForSendGradeToERP", companyVo);
	}

	@Override
	public List<NiceCompGradeVO> getNiceCompGradeListForSendToERP() {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getNiceCompGradeListForSendToERP");
	}

	@Override
	public void updateExpiredDambo() {
		sqlSession.update(MAPPER_NAMESPACE + "updateExpiredDambo");
	}

	@Override
	public List<Map> getToBeExpiredDamboList() {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getToBeExpiredDamboList");
	}

	@Override
	public List<Map> getCurrentDamboList() {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCurrentDamboList");
	}

	@Override
	public List<DissDelayTaskAlarmVO> getDissDelayTaskList(){
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissDelayTaskList");
	}
	
	@Override
	public List<DissDelayGateReviewAlarmVO> getDissDelayGateReviewList(){
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissDelayGateReviewList");
	}

	@Override
	public List<CompanyVO> getErpExpCompanyList(CompanyVO companyVO){
		return sqlSession.selectList(MAPPER_NAMESPACE + "getErpExpCompanyList", companyVO);
	}

	@Override
	public void updateExpCompGrade(CompanyVO companyVO) {
		sqlSession.update(MAPPER_NAMESPACE + "updateExpCompGrade", companyVO);
	}

	@Override
	public void deleteMonthlySales(String yyyyMm) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteMonthlySales", yyyyMm);
	}

	@Override
	public void insertMonthlySales(List<Map> monthlySalesList) {
		for (Map sales : monthlySalesList) {
			sqlSession.insert(MAPPER_NAMESPACE + "insertMonthlySales", sales);
		}
	}

	@Override
	public void mergeKedCompany(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedCompany", paramMap);
	}

	@Override
	public void mergeKedFinancialInfo(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedFinancialInfo", paramMap);
	}

	@Override
	public void mergeKedRepresentativeInfo(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedRepresentativeInfo", paramMap);
	}

	@Override
	public void mergeKedPersonInfo(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedPersonInfo", paramMap);
	}

	@Override
	public void mergeKedExecutiveInfo(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedExecutiveInfo", paramMap);
	}

	@Override
	public void mergeKedEnterpriseInfo(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedEnterpriseInfo", paramMap);
	}

	@Override
	public void mergeKedRelationCompany(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedRelationCompany", paramMap);
	}

	@Override
	public void mergeKedPurposeBusiness(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedPurposeBusiness", paramMap);
	}

	@Override
	public void mergeKedHolderStatus(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedHolderStatus", paramMap);
	}

	@Override
	public void mergeKedWorkspace(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedWorkspace", paramMap);
	}

	@Override
	public void mergeKedIntellectualRight(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedIntellectualRight", paramMap);
	}

	@Override
	public void mergeKedMajorCustomer(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedMajorCustomer", paramMap);
	}

	@Override
	public void mergeKedOverallCreditRating(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedOverallCreditRating", paramMap);
	}

	@Override
	public void mergeKedCashFlowClass(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedCashFlowClass", paramMap);
	}

	@Override
	public void mergeKedFinancialRatio(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedFinancialRatio", paramMap);
	}

	@Override
	public void mergeKedEwAlert(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedEwAlert", paramMap);
	}

	@Override
	public void mergeKedEwStatus(Map<String, String> paramMap) {
		sqlSession.update(MAPPER_NAMESPACE + "mergeKedEwStatus", paramMap);
	}

	@Override
	public Map<String, String> getKedToNiceGrade(String stcd2) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getKedToNiceGrade", stcd2);
	}

	@Override
	public List<UserInfo> getSalesEmpInfoAll() {
		return sqlSession.selectList(MAPPER_NAMESPACE + "test");
	}

	@Override
	public List<UserInfo> test() {
		return sqlSession.selectList(MAPPER_NAMESPACE + "test");
	}
}
