package com.lgmma.salesPortal.app.dao;

import com.lgmma.salesPortal.app.model.DissSpecInSaleGoalVO;

import java.util.List;

public interface DissSpecInSaleGoalDao {

	void createDissSpecInSaleGoal(DissSpecInSaleGoalVO param);

	void createDissSpecInSaleGoalHis(DissSpecInSaleGoalVO param);

	void deleteDissSpecInSaleGoalAll(DissSpecInSaleGoalVO param);

	void deleteDissSpecInSaleGoalAllHis(DissSpecInSaleGoalVO param);

	void updateDissSpecInSaleGoal(DissSpecInSaleGoalVO param);

	List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalList(String taskId);

	List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalListHis(String stepId);

	List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalListFirst(String taskId);
}
