package com.lgmma.salesPortal.app.dao;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.model.VocVO;

public interface CommonFileDao {

	public List<FileVO> getFileList(FileVO fileVO);
	
	public int getFileListCnt(FileVO fileVO);
	
	public FileVO getFileDetail(FileVO fileVO);
	
	public void createFile(FileVO fileVO);
	
	public void deleteFile(FileVO fileVO);

}
