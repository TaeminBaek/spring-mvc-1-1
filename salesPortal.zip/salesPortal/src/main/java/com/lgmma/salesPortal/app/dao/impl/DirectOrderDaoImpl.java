package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DirectOrderDao;
import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;


@Repository
public class DirectOrderDaoImpl implements DirectOrderDao {

    private static final String MAPPER_NAMESPACE = "DIRECT_ORDER_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public int getPurchNoSeq() {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getPurchNoSeq");
	}
	
	@Override
	public void createDirectOrderMaster(DirectOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createDirectOrderMaster", param);
	}
	
	@Override
	public void createDirectOrderItem(DirectOrderItemVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createDirectOrderItem", param);
	}

	@Override
	public void updateErpOrderId(DirectOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateErpOrderId", param);
	}

	@Override
	public List<DirectOrderMasterVO> getHomeOrderList(DirectOrderMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getHomeOrderList", param);
	}

	@Override
	public int getDirectOrderCount(DirectOrderMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDirectOrderCount", param);
	}

	@Override
	public List<DirectOrderMasterVO> getDirectOrderList(DirectOrderMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDirectOrderList", param);
	}

	@Override
	public List<DirectOrderItemVO> getDirectOrderItemList(String orderId) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDirectOrderItemList", orderId);
	}

	@Override
	public DirectOrderMasterVO getDirectOrderDetail(DirectOrderMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDirectOrderList", param);
	}

	@Override
	public void updateDirectOrderMaster(DirectOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDirectOrderMaster", param);
	}

	@Override
	public void deleteDirectOrderItems(DirectOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "deleteDirectOrderItems", param);
	}

	@Override
	public void deleteDirectOrderMaster(DirectOrderMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "deleteDirectOrderMaster", param);
	}

	@Override
	public int getDirectOrderMasterItemListCount(DirectOrderMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDirectOrderMasterItemListCount", param);
	}
	
	@Override
	public List<DirectOrderMasterVO> getDirectOrderMasterItemList(DirectOrderMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDirectOrderMasterItemList", param);
	}

	@Override
	public void updateHighValue(DirectOrderItemVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateHighValue", param);
	}

	@Override
	public String getDirectOrderId(String vbeln) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDirectOrderId", vbeln);
	}

	@Override
	public void updateDirectOrderItem(DirectOrderItemVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDirectOrderItem", param);
	}

	@Override
	public DirectOrderMasterVO getDirectOrderMaster(String orderId) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDirectOrderMaster", orderId);
	}
	
}
