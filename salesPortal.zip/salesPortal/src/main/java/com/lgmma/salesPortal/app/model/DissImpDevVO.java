package com.lgmma.salesPortal.app.model;

import java.util.List;

public class DissImpDevVO extends PagingParamVO {
	//TB_D_IMPDEV
	private String taskId;				//과제ID
	private String taskName;            //과제명
	private String taskType;            //과제구분
	private String taskCd;              //개선개발코드
	private String devPropType;         //개선개발제안구분
	private String leaderEmpId;         //리더
	private String devSupervising;      //개발주관
	private String devLevel;            //개발등급
	private String processType;         //공정
	private String prodTypeD;           //제품
	private String prodType;            //제품군
	private String prodUsgType;         //용도분류
	private String prodUsgTypeDtl;      //상세용도
	private String specinOutline;       //개요(개발배경)
	private String fmChgCode;           //4M변경사항
	private String fmLevel;             //4M등급
	private String fmMngEmpId;          //4M실무위원
	private String curGrade;            //기존GRADE
	private String newGrade;            //신규GRADE
	private String reqCertStdCd;        //필요인증규격
	private String impDevRslt;          //개선개발결과
	private String expQty;              //기대매출량
	private String expAmt;              //기대매출액
	//등록시 사용
	private List<DissKpiVO>      dissKpiList;	
	private List<DissMemberVO>   dissMemberListaggList;
	private List<DissScheduleVO> dissScheduleList;	
	//조회 리스트 
	private String processTypeDevLevelNm;
	private String stepCd;
	private String stepNm;
	private String taskStatusCd;
	private String taskStatusNm;
	private String devSupervisinglNm;
	private String leaderEmpNm;
	private String leaderTeamCode;
	private String leaderTeamName;
	private String preLeaderEmpNm;
	private String stScheduleDate;
	private String edScheduleDate;
	private String apprStat;
	//조회조건 
	private String apprId;
	private String memberNm;
	private String frStScheduleDate;
	private String toStScheduleDate;
	private String frEdScheduleDate;
	private String toEdScheduleDate;
	//상세조회
	private String leaderFullName;
	private String devLevelNm;
	private String processTypeNm;
	private String prodTypeDNm;
	private String prodTypeNm;
	private String prodFullName;
	private String expQtyFullName;
	private String gradeFullName;
	private List<DissStepVO> dissStepList;
	//수정시 사용
	private List<DissMemberVO> dissMemberList;
	private String fmMngEmpNm;          //4M실무위원명
	//품의
	private ApprVO apprVO;
	private String apprType;
	//HIS
	private String stepId;
	//품의서 View
	private String fmLevelNm;
	private String fmMngFullName;
	//F/Test 계획, 결과 사용
	private DissFieldTestVO fieldTestVO;
	//스텝 최대 차수
	private int maxStepDgreeNo;
	//개발결과
	private DissTaskResultVO dissTaskResultVO;
	private DissScheduleVO dissScheduleVO;
	private List<DissTaskResultVO> dissTaskResultList;
	//처방
	private List<DissRecipeVO> dissRecipeList;
	//차수현황
	private DissStepVO dissStepVO;
	//반려재신청품의유무
	private String reWriteRejectApprYn;
	//저장방식(품의서)
	private String saveMode;
	//반려재신청 스텝ID
	private String rewStepId; 
	//개선개발제안구분명
	private String devPropTypeName;
	// 과제결과
	private String compResult;
	private String compResultNm;
	
	private String myIngYn;

	private String apprReqYn;
	
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getDevPropType() {
		return devPropType;
	}
	public void setDevPropType(String devPropType) {
		this.devPropType = devPropType;
	}
	public String getLeaderEmpId() {
		return leaderEmpId;
	}
	public void setLeaderEmpId(String leaderEmpId) {
		this.leaderEmpId = leaderEmpId;
	}
	public String getDevSupervising() {
		return devSupervising;
	}
	public void setDevSupervising(String devSupervising) {
		this.devSupervising = devSupervising;
	}
	public String getDevLevel() {
		return devLevel;
	}
	public void setDevLevel(String devLevel) {
		this.devLevel = devLevel;
	}
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public String getProdTypeD() {
		return prodTypeD;
	}
	public void setProdTypeD(String prodTypeD) {
		this.prodTypeD = prodTypeD;
	}
	public String getProdType() {
		return prodType;
	}
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}
	public String getProdUsgType() {
		return prodUsgType;
	}
	public void setProdUsgType(String prodUsgType) {
		this.prodUsgType = prodUsgType;
	}
	public String getProdUsgTypeDtl() {
		return prodUsgTypeDtl;
	}
	public void setProdUsgTypeDtl(String prodUsgTypeDtl) {
		this.prodUsgTypeDtl = prodUsgTypeDtl;
	}
	public String getSpecinOutline() {
		return specinOutline;
	}
	public void setSpecinOutline(String specinOutline) {
		this.specinOutline = specinOutline;
	}
	public String getFmChgCode() {
		return fmChgCode;
	}
	public void setFmChgCode(String fmChgCode) {
		this.fmChgCode = fmChgCode;
	}
	public String getFmLevel() {
		return fmLevel;
	}
	public void setFmLevel(String fmLevel) {
		this.fmLevel = fmLevel;
	}
	public String getFmMngEmpId() {
		return fmMngEmpId;
	}
	public void setFmMngEmpId(String fmMngEmpId) {
		this.fmMngEmpId = fmMngEmpId;
	}
	public String getCurGrade() {
		return curGrade;
	}
	public void setCurGrade(String curGrade) {
		this.curGrade = curGrade;
	}
	public String getNewGrade() {
		return newGrade;
	}
	public void setNewGrade(String newGrade) {
		this.newGrade = newGrade;
	}
	public String getReqCertStdCd() {
		return reqCertStdCd;
	}
	public void setReqCertStdCd(String reqCertStdCd) {
		this.reqCertStdCd = reqCertStdCd;
	}
	public String getImpDevRslt() {
		return impDevRslt;
	}
	public void setImpDevRslt(String impDevRslt) {
		this.impDevRslt = impDevRslt;
	}
	public String getExpQty() {
		return expQty;
	}
	public void setExpQty(String expQty) {
		this.expQty = expQty;
	}
	public String getExpAmt() {
		return expAmt;
	}
	public void setExpAmt(String expAmt) {
		this.expAmt = expAmt;
	}
	public List<DissKpiVO> getDissKpiList() {
		return dissKpiList;
	}
	public void setDissKpiList(List<DissKpiVO> dissKpiList) {
		this.dissKpiList = dissKpiList;
	}
	public List<DissMemberVO> getDissMemberList() {
		return dissMemberList;
	}
	public void setDissMemberList(List<DissMemberVO> dissMemberList) {
		this.dissMemberList = dissMemberList;
	}
	public List<DissScheduleVO> getDissScheduleList() {
		return dissScheduleList;
	}
	public void setDissScheduleList(List<DissScheduleVO> dissScheduleList) {
		this.dissScheduleList = dissScheduleList;
	}
	public String getProcessTypeDevLevelNm() {
		return processTypeDevLevelNm;
	}
	public void setProcessTypeDevLevelNm(String processTypeDevLevelNm) {
		this.processTypeDevLevelNm = processTypeDevLevelNm;
	}
	public String getStepCd() {
		return stepCd;
	}
	public void setStepCd(String stepCd) {
		this.stepCd = stepCd;
	}
	public String getStepNm() {
		return stepNm;
	}
	public void setStepNm(String stepNm) {
		this.stepNm = stepNm;
	}
	public String getTaskStatusCd() {
		return taskStatusCd;
	}
	public void setTaskStatusCd(String taskStatusCd) {
		this.taskStatusCd = taskStatusCd;
	}
	public String getTaskStatusNm() {
		return taskStatusNm;
	}
	public void setTaskStatusNm(String taskStatusNm) {
		this.taskStatusNm = taskStatusNm;
	}
	public String getDevSupervisinglNm() {
		return devSupervisinglNm;
	}
	public void setDevSupervisinglNm(String devSupervisinglNm) {
		this.devSupervisinglNm = devSupervisinglNm;
	}
	public String getLeaderEmpNm() {
		return leaderEmpNm;
	}
	public void setLeaderEmpNm(String leaderEmpNm) {
		this.leaderEmpNm = leaderEmpNm;
	}
	public String getLeaderTeamCode() {
		return leaderTeamCode;
	}
	public void setLeaderTeamCode(String leaderTeamCode) {
		this.leaderTeamCode = leaderTeamCode;
	}
	public String getStScheduleDate() {
		return stScheduleDate;
	}
	public void setStScheduleDate(String stScheduleDate) {
		this.stScheduleDate = stScheduleDate;
	}
	public String getEdScheduleDate() {
		return edScheduleDate;
	}
	public void setEdScheduleDate(String edScheduleDate) {
		this.edScheduleDate = edScheduleDate;
	}
	public String getApprStat() {
		return apprStat;
	}
	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}
	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getMemberNm() {
		return memberNm;
	}
	public void setMemberNm(String memberNm) {
		this.memberNm = memberNm;
	}
	public String getFrStScheduleDate() {
		return frStScheduleDate;
	}
	public void setFrStScheduleDate(String frStScheduleDate) {
		this.frStScheduleDate = frStScheduleDate;
	}
	public String getToStScheduleDate() {
		return toStScheduleDate;
	}
	public void setToStScheduleDate(String toStScheduleDate) {
		this.toStScheduleDate = toStScheduleDate;
	}
	public String getFrEdScheduleDate() {
		return frEdScheduleDate;
	}
	public void setFrEdScheduleDate(String frEdScheduleDate) {
		this.frEdScheduleDate = frEdScheduleDate;
	}
	public String getToEdScheduleDate() {
		return toEdScheduleDate;
	}
	public void setToEdScheduleDate(String toEdScheduleDate) {
		this.toEdScheduleDate = toEdScheduleDate;
	}
	public String getLeaderTeamName() {
		return leaderTeamName;
	}
	public void setLeaderTeamName(String leaderTeamName) {
		this.leaderTeamName = leaderTeamName;
	}
	public String getLeaderFullName() {
		return leaderFullName;
	}
	public void setLeaderFullName(String leaderFullName) {
		this.leaderFullName = leaderFullName;
	}
	public String getPreLeaderEmpNm() {
		return preLeaderEmpNm;
	}
	public void setPreLeaderEmpNm(String preLeaderEmpNm) {
		this.preLeaderEmpNm = preLeaderEmpNm;
	}
	public String getDevLevelNm() {
		return devLevelNm;
	}
	public void setDevLevelNm(String devLevelNm) {
		this.devLevelNm = devLevelNm;
	}
	public String getProcessTypeNm() {
		return processTypeNm;
	}
	public void setProcessTypeNm(String processTypeNm) {
		this.processTypeNm = processTypeNm;
	}
	public String getProdTypeDNm() {
		return prodTypeDNm;
	}
	public void setProdTypeDNm(String prodTypeDNm) {
		this.prodTypeDNm = prodTypeDNm;
	}
	public String getProdTypeNm() {
		return prodTypeNm;
	}
	public void setProdTypeNm(String prodTypeNm) {
		this.prodTypeNm = prodTypeNm;
	}
	public String getProdFullName() {
		return prodFullName;
	}
	public void setProdFullName(String prodFullName) {
		this.prodFullName = prodFullName;
	}
	public String getExpQtyFullName() {
		return expQtyFullName;
	}
	public void setExpQtyFullName(String expQtyFullName) {
		this.expQtyFullName = expQtyFullName;
	}
	public String getGradeFullName() {
		return gradeFullName;
	}
	public void setGradeFullName(String gradeFullName) {
		this.gradeFullName = gradeFullName;
	}
	public List<DissStepVO> getDissStepList() {
		return dissStepList;
	}
	public void setDissStepList(List<DissStepVO> dissStepList) {
		this.dissStepList = dissStepList;
	}
	public List<DissMemberVO> getDissMemberListaggList() {
		return dissMemberListaggList;
	}
	public void setDissMemberListaggList(List<DissMemberVO> dissMemberListaggList) {
		this.dissMemberListaggList = dissMemberListaggList;
	}
	public String getFmMngEmpNm() {
		return fmMngEmpNm;
	}
	public void setFmMngEmpNm(String fmMngEmpNm) {
		this.fmMngEmpNm = fmMngEmpNm;
	}
	public ApprVO getApprVO() {
		return apprVO;
	}
	public void setApprVO(ApprVO apprVO) {
		this.apprVO = apprVO;
	}
	public String getApprType() {
		return apprType;
	}
	public void setApprType(String apprType) {
		this.apprType = apprType;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getFmLevelNm() {
		return fmLevelNm;
	}
	public void setFmLevelNm(String fmLevelNm) {
		this.fmLevelNm = fmLevelNm;
	}
	public String getFmMngFullName() {
		return fmMngFullName;
	}
	public void setFmMngFullName(String fmMngFullName) {
		this.fmMngFullName = fmMngFullName;
	}
	public DissFieldTestVO getFieldTestVO() {
		return fieldTestVO;
	}
	public void setFieldTestVO(DissFieldTestVO fieldTestVO) {
		this.fieldTestVO = fieldTestVO;
	}
	public int getMaxStepDgreeNo() {
		return maxStepDgreeNo;
	}
	public void setMaxStepDgreeNo(int maxStepDgreeNo) {
		this.maxStepDgreeNo = maxStepDgreeNo;
	}
	public DissTaskResultVO getDissTaskResultVO() {
		return dissTaskResultVO;
	}
	public void setDissTaskResultVO(DissTaskResultVO dissTaskResultVO) {
		this.dissTaskResultVO = dissTaskResultVO;
	}
	public DissScheduleVO getDissScheduleVO() {
		return dissScheduleVO;
	}
	public void setDissScheduleVO(DissScheduleVO dissScheduleVO) {
		this.dissScheduleVO = dissScheduleVO;
	}
	public List<DissTaskResultVO> getDissTaskResultList() {
		return dissTaskResultList;
	}
	public void setDissTaskResultList(List<DissTaskResultVO> dissTaskResultList) {
		this.dissTaskResultList = dissTaskResultList;
	}
	public List<DissRecipeVO> getDissRecipeList() {
		return dissRecipeList;
	}
	public void setDissRecipeList(List<DissRecipeVO> dissRecipeList) {
		this.dissRecipeList = dissRecipeList;
	}
	public DissStepVO getDissStepVO() {
		return dissStepVO;
	}
	public void setDissStepVO(DissStepVO dissStepVO) {
		this.dissStepVO = dissStepVO;
	}
	public String getReWriteRejectApprYn() {
		return reWriteRejectApprYn;
	}
	public void setReWriteRejectApprYn(String reWriteRejectApprYn) {
		this.reWriteRejectApprYn = reWriteRejectApprYn;
	}
	public String getSaveMode() {
		return saveMode;
	}
	public void setSaveMode(String saveMode) {
		this.saveMode = saveMode;
	}
	public String getRewStepId() {
		return rewStepId;
	}
	public void setRewStepId(String rewStepId) {
		this.rewStepId = rewStepId;
	}
	public String getDevPropTypeName() {
		return devPropTypeName;
	}

	public String getCompResult() {
		return compResult;
	}

	public void setCompResult(String compResult) {
		this.compResult = compResult;
	}

	public String getCompResultNm() {
		return compResultNm;
	}

	public void setCompResultNm(String compResultNm) {
		this.compResultNm = compResultNm;
	}

	public void setDevPropTypeName(String devPropTypeName) {
		this.devPropTypeName = devPropTypeName;
	}

	public String getMyIngYn() {
		return myIngYn;
	}
	public void setMyIngYn(String myIngYn) {
		this.myIngYn = myIngYn;
	}

	public String getApprReqYn() {
		return apprReqYn;
	}
	public void setApprReqYn(String apprReqYn) {
		this.apprReqYn = apprReqYn;
	}
}
