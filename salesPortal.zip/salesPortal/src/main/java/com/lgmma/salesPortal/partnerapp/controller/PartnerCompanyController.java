package com.lgmma.salesPortal.partnerapp.controller;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.OrganVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.CompanyService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.app.service.WebAccountService;
import com.lgmma.salesPortal.common.model.DDLBItem;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;


@Controller
@RequestMapping("/partner")
public class PartnerCompanyController {

	@Autowired
	WebAccountService webAccountService;

	@Autowired
	CommonService commonService;
	
    @Autowired
    private MailingService mailingService;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	@Autowired
	CompanyService companyService;
	
	@Autowired
	SapSearchService sapSearchService;
	
	//고객정보 목록
	@RequestMapping(value = "/partnerCompanyInfo")
	public String customerInfo() throws Exception {
		return "partner/company/partnerCompanyInfo";
	}

	@RequestMapping(value = "/getCompanyList.json")
	public Map getCustomerList(@RequestBody CompanyVO param) throws Exception {
		param.setUserType(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getUserType());
		return JsonResponse.asSuccess("itemsCount", companyService.getCompanyCount(param), "storeData", companyService.getCompanyList(param));
	}
	
	@RequestMapping(value = "/getCompanyDetail.json")
	public Map getCompanyDetail(@RequestBody(required=false) CompanyVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", companyService.getCompanyDetail(param));
	}
	
	@RequestMapping(value = "/getCompanySalesYearList.json")
	public Map getCompanySalesYearList(@RequestParam(required=false) String kunnr, @RequestParam(required=false) String vkorg, @RequestParam(required=false) String fromYear, @RequestParam(required=false) String toYear) throws Exception {
		List<Map> salesYearList = sapSearchService.getCompanySalesYearList(kunnr, vkorg, fromYear, toYear);
		
		List<Map> sortList = new ArrayList<>();
		
		int intFromYear = Integer.valueOf(fromYear).intValue();
		int intToYear = Integer.valueOf(toYear).intValue();
		int yearRow = intToYear - intFromYear;
		
		for(int i=0; i <= yearRow; i++) {
			for(int j=0; j<salesYearList.size(); j++) {
				if(String.valueOf(intFromYear + i).equals(salesYearList.get(j).get("ZYYYY"))) {
					
					Map<String, Object> sales = new HashMap<String, Object>();
					
					sales.put("saleYear", salesYearList.get(j).get("ZYYYY"));		//년도 = 매출년도
					sales.put("product", salesYearList.get(j).get("MATNR"));		//자재번호 = 제품명
					sales.put("amount", salesYearList.get(j).get("UMMENGE"));		//송장수량 = 수량 
					sales.put("price", StringUtil.remove((salesYearList.get(j).get("UMNETWR")+""), '.'));	//송장처리된 판매 정가 = 금액
					sales.put("profit", StringUtil.remove((salesYearList.get(j).get("ZZFIELD1")+""), '.'));	//매출총이익 = 이익
					sales.put("profitRate", salesYearList.get(j).get("ZZFIELD2"));	//이익율%
					sortList.add(sales);
				}
			}
		}
		return JsonResponse.asSuccess("storeData", sortList);
	}
	
	@RequestMapping(value = "/getCompanySalesMonthList.json")
	public Map getCompanySalesMonthList(@RequestParam(required=false) String kunnr, @RequestParam(required=false) String vkorg, @RequestParam(required=false) String fromYearMonth, @RequestParam(required=false) String toYearMonth) throws Exception {
		List<Map> salesMonthList = sapSearchService.getCompanySalesMonthList(kunnr, vkorg, fromYearMonth, toYearMonth);
		
		List<Map> sortList = new ArrayList<>();
		
		int intFromYearMonth = Integer.valueOf(fromYearMonth).intValue();
		int intToYearMonth = Integer.valueOf(toYearMonth).intValue();
		int yearRow = intToYearMonth - intFromYearMonth;
		
		for(int i=0; i <= yearRow; i++) {
			for(int j=0; j<salesMonthList.size(); j++) {
				if(String.valueOf(intFromYearMonth + i).equals(salesMonthList.get(j).get("SPMON"))) {
					
					Map<String, Object> sales = new HashMap<String, Object>();
					
					sales.put("saleMonth", salesMonthList.get(j).get("SPMON"));		//년도 = 매출년도
					sales.put("product", salesMonthList.get(j).get("MATNR"));		//자재번호 = 제품명
					sales.put("amount", salesMonthList.get(j).get("UMMENGE"));		//송장수량 = 수량 
					sales.put("price", StringUtil.remove((salesMonthList.get(j).get("UMNETWR")+""), '.'));	//송장처리된 판매 정가 = 금액
					sales.put("profit", StringUtil.remove((salesMonthList.get(j).get("ZZFIELD1")+""), '.'));	//매출총이익 = 이익
					sales.put("profitRate", salesMonthList.get(j).get("ZZFIELD2"));	//이익율%
					sortList.add(sales);
				}
			}
		}
		return JsonResponse.asSuccess("storeData", sortList);
	}
	
	@RequestMapping(value = "/getCompanyEtc.json")
	public Map getCompanyEtc(@RequestBody(required=false) OrganVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", companyService.getCompanyEtc(param), "countKunnr", companyService.getCompanyEtcKunnrCount(param));
	}
	
	@RequestMapping(value = "/saveCompanyEtc.json")
	public Map saveCompanyEtc(@RequestBody OrganVO param) throws Exception {
		companyService.saveCompanyEtc(param);
		return JsonResponse.asSuccess();
	}

	@RequestMapping(value = "/getCompanyBondList.json")
	public Map getCompanyBondList(@RequestParam(required=false) String kunnr, @RequestParam(required=false) String vkorg) throws Exception {
		List<DDLBItem> wegList = sapSearchService.getSapCommonCodeList("24");
		List<Map> bondList = sapSearchService.getCompanyBondList(kunnr, vkorg, Util.getToday("yyyyMM"));
		for(Map bond : bondList) {
			for(DDLBItem weg : wegList) {
				if(weg.getCode().equals(bond.get("VTWEG"))) {
					bond.put("VTWEGTXT", weg.getText());
					break;
				}
			}
 			bond.put("MREBI", StringUtil.setComma(StringUtil.remove((bond.get("MREBI")+""), '.')));
 			bond.put("MRSUM", StringUtil.setComma(StringUtil.remove((bond.get("MRSUM")+""), '.')));
 			bond.put("LMCAS", StringUtil.setComma(StringUtil.remove((bond.get("LMCAS")+""), '.')));
 			bond.put("CBICA", StringUtil.setComma(StringUtil.remove((bond.get("CBICA")+""), '.')));
 			bond.put("NOTBI", StringUtil.setComma(StringUtil.remove((bond.get("NOTBI")+""), '.')));
 			bond.put("LMBIL", StringUtil.setComma(StringUtil.remove((bond.get("LMBIL")+""), '.')));
 			bond.put("MSALE", StringUtil.setComma(StringUtil.remove((bond.get("MSALE")+""), '.')));
 			bond.put("LMSUM", StringUtil.setComma(StringUtil.remove((bond.get("LMSUM")+""), '.')));
 			bond.put("MRECA", StringUtil.setComma(StringUtil.remove((bond.get("MRECA")+""), '.')));
 			bond.put("NOTTO", StringUtil.setComma(StringUtil.remove((bond.get("NOTTO")+""), '.')));
		}
		
		return JsonResponse.asSuccess("storeData", bondList);
	}
}
