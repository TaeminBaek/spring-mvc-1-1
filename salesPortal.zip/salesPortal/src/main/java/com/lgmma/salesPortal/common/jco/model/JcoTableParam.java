package com.lgmma.salesPortal.common.jco.model;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.lgmma.salesPortal.app.model.ProductVO;

public class JcoTableParam<T> {

	private Map<String, List<Map<String, Object>>> paramMap = new HashMap<String, List<Map<String,Object>>>();

	public Object get(String key) {
		return this.paramMap.get(key);
	}

	public Map<String, List<Map<String, Object>>> getParamMap() {
		return paramMap;
	}

	public void setParamMap(Map<String, List<Map<String, Object>>> paramMap) {
		this.paramMap = paramMap;
	}

	public void put(String key, List<Map<String, Object>> mappedlist) {
		this.paramMap.put(key, mappedlist);
	}

	public void put(String key, Map<String, Object> param) {
		this.put(key, Arrays.asList(param));
	}

	public List<?> get(String key, final Class<?> t) {
		List<Map<String, Object>> rows = this.paramMap.get(key);
		List<T> voList = new ArrayList<T>();
		try {
			for(Map<String, Object> row : rows) {
				voList.add(voGenerator(row, t));
			}
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return voList;
	}

	private T voGenerator(Map<String, Object> row, final Class<?> t) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		Class<?> cls = Class.forName(t.getName());
		T vo = (T) cls.newInstance();
		Field[] fields = cls.getDeclaredFields();
		for(int i = 0 ; i < fields.length ; i++) {
			Field field = fields[i];
			for(String key : row.keySet()) {
				if(key.replaceAll("_", "").equals(field.getName().toUpperCase())) {	//sap는 대문자로만 비교
					field.setAccessible(true);
					if(field.getType() == String.class) {
						field.set(vo, String.valueOf(row.get(key)));
					} else {
						field.set(vo, (field.getType().cast(row.get(key))));
					}
					continue;
				}
			}
		}
		return vo;
	}
}
