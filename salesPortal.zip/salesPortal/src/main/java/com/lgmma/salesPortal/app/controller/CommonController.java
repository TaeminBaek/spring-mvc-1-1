package com.lgmma.salesPortal.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.itextpdf.text.log.SysoCounter;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;
import com.lgmma.salesPortal.app.model.OrderProdJindVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;
import com.lgmma.salesPortal.app.model.SapOrderShipListVO;
import com.lgmma.salesPortal.app.model.VocVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.ExchangeMgmtService;
import com.lgmma.salesPortal.app.service.OrderService;
import com.lgmma.salesPortal.app.service.SalePriceMasterMgmtService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.model.DDLBItem;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.ApprConfType;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.CommissionType;
import com.lgmma.salesPortal.common.props.MobileFirstNumbers;
import com.lgmma.salesPortal.common.props.OrderStatus;
import com.lgmma.salesPortal.common.props.SalePriceMasterPriceListType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;

 
@Controller
@RequestMapping("/common")
public class CommonController {

	@Autowired
	private CommonService commonService;

	@Autowired
	private OrderService orderService;
	
	@Autowired
	private SapSearchService sapSearchService;
	
	@Autowired
	private ExchangeMgmtService exchangeMgmtService;
	
	@Autowired
	private SalePriceMasterMgmtService salePriceMasterMgmtService;
	
	@RequestMapping(value = "/getEmployList.json")
	public Map getEmployList(@RequestBody(required=true) EmployVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", commonService.getEmployList(param), "itemsCount", commonService.getEmployListCount(param));
	}
	
	@RequestMapping(value = "/fileDownloader")
	public void fileDownloader(@RequestParam String commFileLoc, @RequestParam String commFileName, HttpServletRequest req, HttpServletResponse res) throws Exception {
		String path = req.getServletContext().getRealPath(File.separator);

		File dfile = new File(path + File.separatorChar + commFileLoc + File.separatorChar + commFileName);
		if (dfile.isFile()) {
			res.setHeader("Content-Type", "application/octet-stream;");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + URLEncoder.encode(commFileName, "UTF-8") + "\";");
			
			OutputStream os = res.getOutputStream();
	        FileInputStream fis = new FileInputStream(dfile);
	        int n = 0;
			byte b[] = new byte[1024 * 4];
	        while((n = fis.read(b)) != -1 ) {
	            os.write(b, 0, n);
	        }
	        fis.close();
	        os.close();
		} else {
			throw new FileNotFoundException("해당화일을 찾을 수 없습니다.");
		}
	}
	
	@RequestMapping(value = "/getOrderSearchOptionList.json")
	public Map getOrderSearchOptionList(@RequestBody(required=false) OrderProdJindVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", commonService.getOrderProductList(param), "storeData2", commonService.getOrderDeliverList(param));
	}

	@RequestMapping(value = "/getCode.json")
	public Map getCode(@RequestBody CommonCodeVO param) throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = new DDLBItem();

		items.addAll(getCommonCodeList(param));
		return JsonResponse.asSuccess("items", items);
	}
	
	@RequestMapping(value = "/getCodeAll.json")
	public Map getCodeAll(@RequestBody CommonCodeVO param) throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = new DDLBItem();
		item.setCode("");
		item.setText("전체");
		items.add(item);

		items.addAll(getCommonCodeList(param));
		return JsonResponse.asSuccess("items", items);
	}

	@RequestMapping(value = "/getCodeSelect.json")
	public Map getCodeSelect(@RequestBody CommonCodeVO param) throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = new DDLBItem();
		item.setCode("");
		item.setText("선택");
		items.add(item);

		items.addAll(getCommonCodeList(param));
		return JsonResponse.asSuccess("items", items);
	}

	
	private List<DDLBItem> getCommonCodeList(CommonCodeVO param) throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		List<CommonCodeVO> codeList = commonService.getCommonCodeComboList(param);
		for(CommonCodeVO code : codeList) {
			DDLBItem item = new DDLBItem();
			item.setCode(code.getCodeIdxx());
			item.setText(code.getCodeName());
			items.add(item);
		}
		return items;
	}
	
	@RequestMapping(value = "/getYnDDLB.json")
	public Map getYnDDLB() throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = null;
		
		item = new DDLBItem();
		item.setCode("Y");
		item.setText("Y");
		items.add(item);
		
		item = new DDLBItem();
		item.setCode("N");
		item.setText("N");
		items.add(item);
		
		return JsonResponse.asSuccess("items", items);
	}

	@RequestMapping(value = "/getYnDDLBWithAll.json")
	public Map getYnDDLBWithAll() throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = new DDLBItem();
		item.setCode("");
		item.setText("전체");
		items.add(item);
		
		item = new DDLBItem();
		item.setCode("Y");
		item.setText("Y");
		items.add(item);
		
		item = new DDLBItem();
		item.setCode("N");
		item.setText("N");
		items.add(item);
		
		return JsonResponse.asSuccess("items", items);
	}
	
	@RequestMapping(value = "/getMobileProviderDDLB.json")
	public Map getMobileProviderDDLB() throws Exception {
		List<DDLBItem> items = getMobileProviders();
		return JsonResponse.asSuccess("items", items);
	}

	@RequestMapping(value = "/getMobileProviderWithSelectDDLB.json")
	public Map getMobileProviderWithSelectDDLB() throws Exception {
		List<DDLBItem> items = getMobileProviders();
		items.add(0, new DDLBItem("","선택"));
		return JsonResponse.asSuccess("items", items);
	}
	
	private List<DDLBItem> getMobileProviders() {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = null;
		for(MobileFirstNumbers provider : MobileFirstNumbers.values()) {
			item = new DDLBItem();
			item.setCode(provider.getCode());
			item.setText(provider.getCode());
			items.add(item);
		}
		return items;
	}

	@RequestMapping(value = "/getSapCommonCodeListDDLB.json")
	public Map getSapCommonCodeListDDLB(@RequestParam String zgubun) throws Exception {
		return JsonResponse.asSuccess("items", getSapCommonCodeList(zgubun));
	}
	
	@RequestMapping(value = "/getSapCommonCodeListWithSelectDDLB.json")
	public Map getSapCommonCodeListWithSelectDDLB(@RequestParam String zgubun) throws Exception {
		List<DDLBItem> items;
		if(zgubun.equals("28")) {
			items = getSapCommonCodeListZterm(zgubun);
		}else {
			items = getSapCommonCodeList(zgubun);
		}
		items.add(0, new DDLBItem("","선택"));
		return JsonResponse.asSuccess("items", items);
	}
	
	@RequestMapping(value = "/getSapCommonCodeListWithAllDDLB.json")
	public Map getSapCommonCodeListWithAllDDLB(@RequestParam String zgubun) throws Exception {
		List<DDLBItem> items = getSapCommonCodeList(zgubun);
		items.add(0, new DDLBItem("","전체"));
		return JsonResponse.asSuccess("items", items);
	}
	
	private List<DDLBItem> getSapCommonCodeList(String zgubun) {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		for(DDLBItem item : sapSearchService.getSapCommonCodeList(zgubun)) {
			DDLBItem newItem = new DDLBItem();
			newItem.setCode(item.getCode());
			newItem.setText(item.getText());
			if (!item.getText().contains("(사용X)")) {
				items.add(newItem);
			}
		}
		return items;
	}
	
	private List<DDLBItem> getSapCommonCodeListZterm(String zgubun) {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		for(DDLBItem item : sapSearchService.getSapCommonCodeList(zgubun)) {
			if(!item.getCode().equals("WD05")) {
				DDLBItem newItem = new DDLBItem();
				newItem.setCode(item.getCode());
				newItem.setText(item.getText());
				items.add(newItem);
			}
		}
		return items;
	}

	@RequestMapping(value = "/getProductPopupList.json")
	public Map getProductPopupList(@RequestBody(required=false) ProductVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", commonService.getProductPopupCount(param), "storeData", commonService.getProductPopupList(param));
	}

	@RequestMapping(value = "/getCustomerPopupList.json")
	public Map getCustomerPopupList(@RequestBody(required=true) CompanyVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", commonService.getCustomerPopupCount(param), "storeData", commonService.getCustomerPopupList(param));
	}
	
	@RequestMapping(value = "/getAgencyPopupList.json")
	public Map getAgencyPopupList(@RequestBody(required=true) CompanyVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", commonService.getAgencyPopupCount(param), "storeData", commonService.getAgencyPopupList(param));
	}
	
	@RequestMapping(value = "/getVkorgDDLB.json")
	public Map getVkorgDDLB() throws Exception {
		List<DDLBItem> items = getVkorg();
		return JsonResponse.asSuccess("items", items);
	}

	@RequestMapping(value = "/getVkorgWithSelectDDLB.json")
	public Map getVkorgWithSelectDDLB() throws Exception {
		List<DDLBItem> items = getVkorg();
		items.add(0, new DDLBItem("","선택", false));
		return JsonResponse.asSuccess("items", items);
	}
	
	@RequestMapping(value = "/getVkorgWithAllDDLB.json")
	public Map getVkorgWithAllDDLB() throws Exception {
		List<DDLBItem> items = getVkorg();
		items.add(0, new DDLBItem("","전체", false));
		return JsonResponse.asSuccess("items", items);
	}
	
	private List<DDLBItem> getVkorg() {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = null;
		for(Vkorg vkorg : Vkorg.values()) {
			item = new DDLBItem();
			item.setCode(vkorg.getCode());
			item.setText(vkorg.getName());
			item.setSelected(item.getCode().equals(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getVkorg()));
			items.add(item);
		}
		return items;
	}

	@RequestMapping(value = "/getApprTypeDDLB.json")
	public Map getApprTypeDDLB() throws Exception {
		List<DDLBItem> items = getApprTypeCodeList();
		return JsonResponse.asSuccess("items", items);
	}

	private List<DDLBItem> getApprTypeCodeList() throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = null;
		for(ApprType tmpItem : ApprType.values()) {
			item = new DDLBItem();
			item.setCode(tmpItem.getCode());
			item.setText(tmpItem.getName());
			items.add(item);
		}
		return items;
	}

	@RequestMapping(value = "/getApprStateDDLB.json")
	public Map getApprStateDDLB() throws Exception {
		List<DDLBItem> items = getApprStateCodeList();
		return JsonResponse.asSuccess("items", items);
	}

	private List<DDLBItem> getApprStateCodeList() throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = null;
		for(ApprState tmpItem : ApprState.values()) {
			item = new DDLBItem();
			item.setCode(tmpItem.getCode());
			item.setText(tmpItem.getName());
			items.add(item);
		}
		return items;
	}

	@RequestMapping(value = "/getApprConfTypeDDLB.json")
	public Map getApprConfTypeDDLB() throws Exception {
		List<DDLBItem> items = getApprConfTypeCodeList();
		return JsonResponse.asSuccess("items", items);
	}

	private List<DDLBItem> getApprConfTypeCodeList() throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = null;
		for(ApprConfType tmpItem : ApprConfType.values()) {
			item = new DDLBItem();
			item.setCode(tmpItem.getCode());
			item.setText(tmpItem.getName());
			items.add(item);
		}
		return items;
	}

	@RequestMapping(value = "/getWebAccountPopupList.json")
	public Map getWebAccountPopupList(@RequestBody(required=true) LoginUserVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", commonService.getWebAccountPopupCount(param), "storeData", commonService.getWebAccountPopupList(param));
	}
	
	//인도처 정보
	@RequestMapping(value = "/getOrderJindSearch.json")
	public Map getOrderJindSearch(@RequestBody(required=false) OrderProdJindVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", commonService.getOrderJindSearch(param));
	}
	
	//배송 정보	
	@RequestMapping(value = "/getOrderDeliverSearch.json")
	public Map getOrderDeliverSearch(@RequestBody(required=false) SapOrderShipListVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", commonService.getOrderDeliverSearch(param));
	}

	//직수출 등급/한도 조회
	@RequestMapping(value = "/getImportCorpCredit.json")
	public Map getImportCorpCredit(@RequestParam(required=true) String impNationCode, @RequestParam(required=true) String impCorpCode) throws Exception {
		Map result = sapSearchService.getImportCorpCredit(impNationCode, impCorpCode);
		if(!result.get("E_SUBRC").toString().equals("0")) {
			return JsonResponse.asFailure(result.get("E_RETURN").toString());
		}
		return JsonResponse.asSuccess("items", result);
	}

	//tbc_company 사업자번호 중복 체크
	@RequestMapping(value = "/checkCompanyBusinoDub.json")
	public Map checkCompanyBusinoDub(@RequestParam(required=true) String vkorg, @RequestParam(required=true) String busino) throws Exception {
		String message = "";
		Map<String, String> param = new HashMap<String, String>();
		param.put("vkorg", vkorg);
		param.put("busino", busino);
		CompanyVO companyVO = commonService.checkCompanyBusinoDub(param);
		if(companyVO != null) {
			message = "기존 고객사입니다. (대표자:"+companyVO.getJ1kfrepre()+" )";
			message +="\n영업조직 "+Vkorg.getVkorg(vkorg).getName()+"는 이미 존재합니다.";
			return JsonResponse.asFailure(message);
		} else {
			message = "신규 고객사입니다.";
			message +="\n영업조직 "+Vkorg.getVkorg(vkorg).getName()+"는 신규입니다.";
			return JsonResponse.asSuccessMsg("success", message);
		}
	}

	//ERP 인도처정보 가져오기
	@RequestMapping(value = "/getCompanyDeliveryList.json")
	public Map getCompanyJind(@RequestParam(required=true) String kunnr, @RequestParam(required=true) String vkorg) throws Exception {
		OrderProdJindVO param = new OrderProdJindVO();
		param.setCompCode(kunnr);
		param.setTvkotVkorg(vkorg);
		return JsonResponse.asSuccess("storeData", commonService.getOrderDeliverList(param));
	}
	
	public Map getYearsDDLB() {
		int currYear = new Integer(DateUtil.getCurrentYear());
		int startYear = currYear-5;
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		while(startYear <= currYear) {
			DDLBItem item = new DDLBItem();
			item.setCode(currYear+"");
			item.setText(currYear+"");
			currYear--;
			items.add(item);
		}
		return JsonResponse.asSuccess("items", items);
	}
	
	@RequestMapping(value = "/getToYearsDDLB.json")
	public Map getToYearsDDLB() {
		int currYear = new Integer(DateUtil.getCurrentYear());
		int startYear = currYear-10;
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		while(startYear <= currYear) {
			DDLBItem item = new DDLBItem();
			item.setCode(currYear+"");
			item.setText(currYear+"");
			currYear--;
			items.add(item);
		}
		return JsonResponse.asSuccess("items", items);
	}
	
	@RequestMapping(value = "/getFromYearsDDLB.json")
	public Map getFromYearsDDLB() {
		int currYear = new Integer(DateUtil.getCurrentYear())-2;
		int startYear = currYear-8;
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		while(startYear <= currYear) {
			DDLBItem item = new DDLBItem();
			item.setCode(currYear+"");
			item.setText(currYear+"");
			currYear--;
			items.add(item);
		}
		return JsonResponse.asSuccess("items", items);
	}
	
	@RequestMapping(value = "/getFromToMonthDDLB.json")
	public Map getFromToMonthDDLB() {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		for(int i=1; i<=12; i++){
			DDLBItem item = new DDLBItem();
			if(i<10){
				item.setCode("0"+i+"");
				item.setText("0"+i+"월");
				items.add(item);
			}else{
				item.setCode(i+"");
				item.setText(i+"월");
				items.add(item);
			}
		}
		return JsonResponse.asSuccess("items", items);
	}
	
	@RequestMapping(value = "/getOrderProdPricesSearch.json")
	public Map getOrderProdPricesSearch(@RequestBody(required=false) OrderProdJindVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", commonService.getOrderProdPricesSearch(param));
	}
	@RequestMapping(value = "/getDeliveryInfoPopupList.json")
	public Map getDeliveryInfoPopupList(@RequestParam(required=true) int eordHdid) throws Exception {
		return JsonResponse.asSuccess("storeData", orderService.getOrderDeliveryInfo(eordHdid));
	}
	
	@RequestMapping(value = "/getVocSrvcWithSelectDDLB.json")
	public Map getVocSrvcWithSelectDDLB() throws Exception {
		List<DDLBItem> items = getVocSrvc();
		items.add(0, new DDLBItem("","선택", false));
		return JsonResponse.asSuccess("items", items);
	}
	
	@RequestMapping(value = "/getVocSrvcWithAllDDLB.json")
	public Map getVocSrvcWithAllDDLB() throws Exception {
		List<DDLBItem> items = getVocSrvc();
		items.add(0, new DDLBItem("","전체", false));
		return JsonResponse.asSuccess("items", items);
	}

	private List<DDLBItem> getVocSrvc() {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = null;
		for(VocVO tmpItem : commonService.getVocSrvcList()) {
			item = new DDLBItem();
			item.setCode(tmpItem.getSrvcCode());
			item.setText(tmpItem.getSrvcName());
			items.add(item);
		}
		return items;
	}
	
	@RequestMapping(value = "/getVocSrvcdivxCodeTypeDDLB.json") 
	public Map getVocSrvcdivxCodeTypeDDLB(@RequestBody VocVO param) throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = new DDLBItem();

		items.addAll(getVocSrvcdivxCodeList(param));
		return JsonResponse.asSuccess("items", items);
	}
	
	private List<DDLBItem> getVocSrvcdivxCodeList(VocVO param) throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		List<VocVO> codeList = commonService.getVocSrvcDivxList(param);
		for(VocVO code : codeList) {
			DDLBItem item = new DDLBItem();
			item.setCode(code.getDivxCode());
			item.setText(code.getDivxName());
			items.add(item);
		}
		return items;
	}
	
	@RequestMapping(value = "/blank")
	public String blank() throws Exception {
		return "common/blank";
	}
	
	@RequestMapping(value = "/getLastExchangeRateInfo.json")
	public Map getLastExchangeRateInfo() throws Exception {
		return JsonResponse.asSuccess("storeData", exchangeMgmtService.getLastExchangeRateInfo());
	}

	@RequestMapping(value = "/getCommissionDDLB.json")
	public Map getCommissionDDLB() throws Exception {
		List<DDLBItem> items = getCommission();
		return JsonResponse.asSuccess("items", items);
	}
	
	private List<DDLBItem> getCommission() {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = null;
		for(CommissionType commissionType : CommissionType.values()) {
			item = new DDLBItem();
			item.setCode(commissionType.getCode());
			item.setText(commissionType.getText());
			items.add(item);
		}
		return items;
	}

	@RequestMapping(value = "/getSalePricePopupList.json")
	public Map getSalePricePopupList(@RequestBody(required=true) SalePriceMasterVO param) throws Exception {
		
		if(param.getSearchDate().equals("sysdate")) {
			param.setSearchDate(Util.getToday());
		}
		if(StringUtil.isNullToString(param.getSpType()).equals("") ) {	//화면에서 실제 인도처가 넘어오지 않으면 파트너사가 아닌 경우
			if(param.getVtweg().equals("30") || param.getVtweg().equals("40")) {
				param.setPriceList(SalePriceMasterPriceListType.getExportSalePriceList());                                                               
			} else {
				param.setPriceList(SalePriceMasterPriceListType.getDomesticSalePriceList());                                                               
			}
		}
		return JsonResponse.asSuccess("itemsCount", salePriceMasterMgmtService.getsalePriceMasterListCount(param), "storeData", salePriceMasterMgmtService.getsalePriceMasterList(param));
	}

	@RequestMapping(value = "/getSalePricePopupListNoPage.json")
	public Map getSalePricePopupListNoPage(@RequestBody(required=true) SalePriceMasterVO param) throws Exception {
		if(param.getSearchDate().equals("sysdate")) {
			param.setSearchDate(Util.getToday());
		}
		if(StringUtil.isNullToString(param.getSpType()).equals("") ) {	//화면에서 실제 인도처가 넘어오지 않으면 파트너사가 아닌 경우
			if(param.getVtweg().equals("30") || param.getVtweg().equals("40")) {
				param.setPriceList(SalePriceMasterPriceListType.getExportSalePriceList());                                                               
			} else {
				param.setPriceList(SalePriceMasterPriceListType.getDomesticSalePriceList());                                                               
			}
		}
		int itemsCount = salePriceMasterMgmtService.getsalePriceMasterListCount(param);
		param.setrIndex(1);
		param.setPageSize(itemsCount);
		return JsonResponse.asSuccess("storeData", salePriceMasterMgmtService.getsalePriceMasterList(param));
	}
	
	public Map getSapCommonCodeListDDLBWithCode(String zgubun) {
		return JsonResponse.asSuccess("items", getSapCommonCodeListWithCode(zgubun));
	}

	private List<DDLBItem> getSapCommonCodeListWithCode(String zgubun) {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		for(DDLBItem item : sapSearchService.getSapCommonCodeList(zgubun)) {
			DDLBItem newItem = new DDLBItem();
			newItem.setCode(item.getCode());
			newItem.setText("[" + item.getCode() + "]" + item.getText());
			items.add(newItem);
		}
		return items;
	}

	private List<DDLBItem> getDirectOrderStatus() {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		for(OrderStatus item : OrderStatus.getDirectOrderStatus()) {
			DDLBItem newItem = new DDLBItem();
			newItem.setCode(item.getCode());
			newItem.setText(item.getName());
			items.add(newItem);
		}
		return items;
	}


	public Map getDirectOrderStatusDDLBWithAll() {
		List<DDLBItem> items = getDirectOrderStatus();
		items.add(0, new DDLBItem("","전체", false));
		return JsonResponse.asSuccess("items", items);
	}
	
	@RequestMapping(value = "/dissPopSample")
	public String dissSamplePop() throws Exception {
		return "common/dissPopSample";
	}


	@RequestMapping(value = "/getCommonCodeDbAll.json")
	public Map getCommonCodeDbAll() throws Exception {
		List<CommonCodeVO> commonCodeVOList = commonService.getCommonCodeDbAll();
		Map codeMap = new HashMap();
		CommonCodeVO preCode = null;
		List<CommonCodeVO> tempCodeList = null;
		for(CommonCodeVO commonCode:commonCodeVOList){
			if(preCode==null){
				tempCodeList = new ArrayList<CommonCodeVO>();
				tempCodeList.add(commonCode);
			}else{
				if(!(commonCode.getGrupCode().equals(preCode.getGrupCode()))){
					codeMap.put(preCode.getGrupCode(),tempCodeList);
					tempCodeList = new ArrayList<CommonCodeVO>();
					tempCodeList.add(commonCode);
				}else{
					tempCodeList.add(commonCode);
				}
			}
			preCode = commonCode;
		}
		codeMap.put(preCode.getGrupCode(),tempCodeList);
		return JsonResponse.asSuccess("storeData", codeMap);
	}
	
	@RequestMapping(value = "/getDissProdDivisionDTypeDDLB.json") 
	public Map getDissProdDivisionDTypeDDLB(@RequestBody CommonCodeVO param) throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = new DDLBItem();

		items.addAll(getDissProdDivisionDCodeList(param));
		return JsonResponse.asSuccess("items", items);
	}
	
	private List<DDLBItem> getDissProdDivisionDCodeList(CommonCodeVO param) throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		List<CommonCodeVO> codeList = commonService.getDissProdDivisionDList(param);
		for(CommonCodeVO code : codeList) {
			DDLBItem item = new DDLBItem();
			item.setCode(code.getCodeIdxx());
			item.setText(code.getCodeName());
			items.add(item);
		}
		return items;
	}
	
	@RequestMapping(value = "/getDissFailReasonDtlTypeDDLB.json") 
	public Map getDissFailReasonDtlTypeDDLB(@RequestBody CommonCodeVO param) throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		DDLBItem item = new DDLBItem();

		items.addAll(getDissFailReasonDtlCodeList(param));
		return JsonResponse.asSuccess("items", items);
	}
	
	private List<DDLBItem> getDissFailReasonDtlCodeList(CommonCodeVO param) throws Exception {
		List<DDLBItem> items = new ArrayList<DDLBItem>();
		List<CommonCodeVO> codeList = commonService.getDissFailReasonDtlList(param);
		for(CommonCodeVO code : codeList) {
			DDLBItem item = new DDLBItem();
			item.setCode(code.getCodeIdxx());
			item.setText(code.getCodeName());
			items.add(item);
		}
		return items;
	}
}
