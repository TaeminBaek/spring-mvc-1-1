package com.lgmma.salesPortal.app.service;
import java.util.HashMap;
import java.util.List;

import com.lgmma.salesPortal.app.model.SampleVO;



public interface SampleService {

	public List<SampleVO> getSample(SampleVO param) throws Exception;
	
	public void updateSample(SampleVO param) throws Exception;
	
	public void createSample(SampleVO param) throws Exception;
	
	public void deleteSample(SampleVO param) throws Exception;

	public int getSampleCount(SampleVO param);

}
