package com.lgmma.salesPortal.partnerapp.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.controller.CommonController;
import com.lgmma.salesPortal.app.model.OrderHeadVO;
import com.lgmma.salesPortal.app.model.OrderItemVO;
import com.lgmma.salesPortal.app.model.OrderListVO;
import com.lgmma.salesPortal.app.model.OrderSaleNameListVO;
import com.lgmma.salesPortal.app.service.OrderService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.util.DateUtil;

@Controller
@RequestMapping("/partner")
public class PartnerOrderController {
	
	@Autowired
	OrderService orderService;

	@Autowired
	CommonController commonController;
	
	@RequestMapping(value = "/orderInfo")
	public ModelAndView orderInfo(ModelAndView mav) throws Exception {
		mav.setViewName("partner/order/partnerOrderInfo");
		mav.addObject("vkorgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		return mav;
	}
	
	@RequestMapping(value = "/getOrderList.json")
	public Map getOrderList(@RequestBody(required = false) OrderListVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", orderService.getOrderCount(param), "storeData", orderService.getOrderList(param));
	}
	
	@RequestMapping(value = "/getOrderDetail.json")
	public Map getOrderDetail(@RequestBody(required=false) OrderHeadVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", orderService.getOrderDetail(param));
	}
	
	@RequestMapping(value = "/getOrderDetailForUpdate.json")
	public Map getOrderDetailForUpdate(@RequestBody(required=false) OrderHeadVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", orderService.getOrderDetailForUpdate(param));
	}
	
	@RequestMapping(value = "/getOrderDetailForCopy.json")
	public Map getOrderDetailForCopy(@RequestBody(required=false) OrderHeadVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", orderService.getOrderDetailForCopy(param));
	}
	
	@RequestMapping(value = "/getOrderItemList.json")
	public Map getOrderItemList(@RequestBody(required = false) OrderItemVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", orderService.getOrderItemList(param));
	}
	
	@RequestMapping(value = "/getSaleNameList.json")
	public Map getSaleNameList(@RequestBody(required = false) OrderSaleNameListVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", orderService.getSaleNameCount(param),"storeData", orderService.getSaleNameList(param));
	}
	
	@RequestMapping(value = "/createOrder.json")
	public Map createOrder(@RequestBody @Valid OrderHeadVO param) throws Exception {
		param.setRegiGubn("P");
		orderService.createOrder(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	@RequestMapping(value = "/updateOrder.json")
	public Map updateOrder(@RequestBody @Valid OrderHeadVO param) throws Exception {
		param.setRegiGubn("P");
		orderService.updateOrder(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	@RequestMapping(value = "/deleteOrder.json")
	public Map deleteOrder(@RequestBody @Valid OrderHeadVO param) throws Exception {
		orderService.deleteOrder(param);
		return JsonResponse.asSuccess("success", "삭제되었습니다");
	}
	
	@RequestMapping(value = "/deleteOrderItem.json")
	public Map deleteOrderItem(@RequestBody List<OrderItemVO> param ) throws Exception {
		orderService.deleteOrderItem(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/getOrderDeliveryInfo.json")
	public Map getOrderDeliveryInfo(@RequestBody(required=true) int eordHdid) throws Exception {
		return JsonResponse.asSuccess("storeData", orderService.getOrderDeliveryInfo(eordHdid));
	}
	
}
