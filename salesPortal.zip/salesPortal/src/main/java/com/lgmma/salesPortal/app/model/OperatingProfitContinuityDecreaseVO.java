package com.lgmma.salesPortal.app.model;

public class OperatingProfitContinuityDecreaseVO extends PagingParamVO {
	
	private String salesOrg;
	private String distrChan;
	private String gjahr;		
	private String cApprEmpId;	
	private String cApprEmpNm;
	
	private String spart;
	private String vtweg;
	private String kunnr;
	private String name1;
	private String maktx;
	private String ename;
	private String zzfield1;
	private String zzfield1Yeong;
	private String zzfeild1Updown;
	private String zzfield2;
	private String zzfield1Bm;
	private String zzfield1YeongBm;
	private String zzfield1UpdownBm;
	private String zzfield2Bm;
	private String zzfield1Bbm;
	private String zzfield1YeongBbm;
	private String zzfield1UpdownBbm;
	private String zzfield2Bbm;
	private String zzfield2Updown;
	private String zzfield2BmUpdown;
	private String zzfield2BbmUpdown;
	
	public String getSalesOrg() {
		return salesOrg;
	}
	
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	
	public String getDistrChan() {
		return distrChan;
	}
	
	public void setDistrChan(String distrChan) {
		this.distrChan = distrChan;
	}
	
	public String getGjahr() {
		return gjahr;
	}
	
	public void setGjahr(String gjahr) {
		this.gjahr = gjahr;
	}
	
	public String getcApprEmpId() {
		return cApprEmpId;
	}
	
	public void setcApprEmpId(String cApprEmpId) {
		this.cApprEmpId = cApprEmpId;
	}
	
	public String getcApprEmpNm() {
		return cApprEmpNm;
	}
	
	public void setcApprEmpNm(String cApprEmpNm) {
		this.cApprEmpNm = cApprEmpNm;
	}
	
	public String getSpart() {
		return spart;
	}
	
	public void setSpart(String spart) {
		this.spart = spart;
	}
	
	public String getVtweg() {
		return vtweg;
	}
	
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	
	public String getKunnr() {
		return kunnr;
	}
	
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	
	public String getName1() {
		return name1;
	}
	
	public void setName1(String name1) {
		this.name1 = name1;
	}
	
	public String getMaktx() {
		return maktx;
	}
	
	public void setMaktx(String maktx) {
		this.maktx = maktx;
	}
	
	public String getEname() {
		return ename;
	}
	
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	public String getZzfield1() {
		return zzfield1;
	}
	
	public void setZzfield1(String zzfield1) {
		this.zzfield1 = zzfield1;
	}

	public String getZzfield1Yeong() {
		return zzfield1Yeong;
	}

	public void setZzfield1Yeong(String zzfield1Yeong) {
		this.zzfield1Yeong = zzfield1Yeong;
	}

	public String getZzfeild1Updown() {
		return zzfeild1Updown;
	}

	public void setZzfeild1Updown(String zzfeild1Updown) {
		this.zzfeild1Updown = zzfeild1Updown;
	}

	public String getZzfield2() {
		return zzfield2;
	}

	public void setZzfield2(String zzfield2) {
		this.zzfield2 = zzfield2;
	}

	public String getZzfield1Bm() {
		return zzfield1Bm;
	}

	public void setZzfield1Bm(String zzfield1Bm) {
		this.zzfield1Bm = zzfield1Bm;
	}

	public String getZzfield1YeongBm() {
		return zzfield1YeongBm;
	}

	public void setZzfield1YeongBm(String zzfield1YeongBm) {
		this.zzfield1YeongBm = zzfield1YeongBm;
	}

	public String getZzfield1UpdownBm() {
		return zzfield1UpdownBm;
	}

	public void setZzfield1UpdownBm(String zzfield1UpdownBm) {
		this.zzfield1UpdownBm = zzfield1UpdownBm;
	}

	public String getZzfield2Bm() {
		return zzfield2Bm;
	}

	public void setZzfield2Bm(String zzfield2Bm) {
		this.zzfield2Bm = zzfield2Bm;
	}

	public String getZzfield1Bbm() {
		return zzfield1Bbm;
	}

	public void setZzfield1Bbm(String zzfield1Bbm) {
		this.zzfield1Bbm = zzfield1Bbm;
	}

	public String getZzfield1YeongBbm() {
		return zzfield1YeongBbm;
	}

	public void setZzfield1YeongBbm(String zzfield1YeongBbm) {
		this.zzfield1YeongBbm = zzfield1YeongBbm;
	}

	public String getZzfield1UpdownBbm() {
		return zzfield1UpdownBbm;
	}

	public void setZzfield1UpdownBbm(String zzfield1UpdownBbm) {
		this.zzfield1UpdownBbm = zzfield1UpdownBbm;
	}

	public String getZzfield2Bbm() {
		return zzfield2Bbm;
	}

	public void setZzfield2Bbm(String zzfield2Bbm) {
		this.zzfield2Bbm = zzfield2Bbm;
	}

	public String getZzfield2Updown() {
		return zzfield2Updown;
	}

	public void setZzfield2Updown(String zzfield2Updown) {
		this.zzfield2Updown = zzfield2Updown;
	}

	public String getZzfield2BmUpdown() {
		return zzfield2BmUpdown;
	}

	public void setZzfield2BmUpdown(String zzfield2BmUpdown) {
		this.zzfield2BmUpdown = zzfield2BmUpdown;
	}

	public String getZzfield2BbmUpdown() {
		return zzfield2BbmUpdown;
	}

	public void setZzfield2BbmUpdown(String zzfield2BbmUpdown) {
		this.zzfield2BbmUpdown = zzfield2BbmUpdown;
	}
	
	
		
}
