package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissCommentVO;

public interface CommonCommentDao {

	int getCommentListCount(DissCommentVO param);
	
	List<DissCommentVO> getCommentList(DissCommentVO param);

	DissCommentVO getComment(DissCommentVO param);

	void createComment(DissCommentVO param);

	void updateComment(DissCommentVO param);

	void deleteComment(DissCommentVO param);

}
