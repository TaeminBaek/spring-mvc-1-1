package com.lgmma.salesPortal.app.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.dao.ExchangeRateDao;
import com.lgmma.salesPortal.app.model.ExchangeRateVO;
import com.lgmma.salesPortal.app.service.ExchangeMgmtService;

@Service
public class ExchangeRateMgmtServiceImpl implements ExchangeMgmtService {

	@Autowired
	private ExchangeRateDao exchangeRateDao;

	@Override
	public int getExchangeRateCount(ExchangeRateVO param) {
		return exchangeRateDao.getExchangeRateCount(param);
	}

	@Override
	public List<ExchangeRateVO> getExchangeRateList(ExchangeRateVO param) {
		return exchangeRateDao.getExchangeRateList(param);
	}

	@Override
	public void updateExchangeRate(ExchangeRateVO param) {
		exchangeRateDao.updateExchangeRate(param);
	}

	@Override
	public void createExchangeRate(ExchangeRateVO param) {
		exchangeRateDao.createExchangeRate(param);
	}

	@Override
	public List<ExchangeRateVO> getExchangeRateMonAvgList(ExchangeRateVO param) {
		return exchangeRateDao.getExchangeRateMonAvgList(param);
	}

	@Override
	public List<ExchangeRateVO> getExchangeRateListAddAvg(ExchangeRateVO param) {
		List<ExchangeRateVO> exchangeRateVOList = new ArrayList<ExchangeRateVO>();
		exchangeRateVOList = exchangeRateDao.getExchangeRateList(param);
		if(exchangeRateVOList.size() > 0) {
			exchangeRateVOList.add(exchangeRateDao.getExchangeRateListAvg(param));
		}
		return exchangeRateVOList;
	}

	@Override
	public List<ExchangeRateVO> getExchangeRateMonAvgListAddAvg(ExchangeRateVO param) {
		List<ExchangeRateVO> exchangeRateVOList = new ArrayList<ExchangeRateVO>();
		exchangeRateVOList = exchangeRateDao.getExchangeRateMonAvgList(param);
		if(exchangeRateVOList.size() > 0) {
			exchangeRateVOList.add(exchangeRateDao.getExchangeRateMonAvgListAvg(param));
		}
		return exchangeRateVOList;
	}

	@Override
	public ExchangeRateVO getLastExchangeRateInfo() {
		return exchangeRateDao.getLastExchangeRateInfo();
	}

}
