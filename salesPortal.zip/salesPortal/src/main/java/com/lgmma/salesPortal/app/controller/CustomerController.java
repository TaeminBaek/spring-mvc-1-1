package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.CompFileListVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.CustReqVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.LoginMastVO;
import com.lgmma.salesPortal.app.model.LoginReqVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.CustomerService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.WebAccountService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

@Controller
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private WebAccountService webAccountService;

	@Autowired
	private CommonService commonService;
	
    @Autowired
    private MailingService mailingService;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	
	@Autowired
	CustomerService customerService;
	
	@RequestMapping(value = "/newWebAccountRequests")
	public String newWebAccountRequests() throws Exception {
		return "customer/newWebAccountRequests";
	}

	@RequestMapping(value = "/getNewWebAccountRequests.json")
	public Map getNewWebAccountRequests(@RequestBody(required=false) LoginReqVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", webAccountService.getNewWebAccountRequestsCount(param), "storeData", webAccountService.getNewWebAccountRequests(param));
	}
	@RequestMapping(value = "/getWebAccountRequestDetail.json")
	public Map getWebAccountRequestDetail(@RequestBody(required=false) LoginReqVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", webAccountService.getWebAccountRequestDetail(param));
	}
	
	@RequestMapping(value = "/updateWebAccountStatus.json")
	public Map updateWebAccountStatus(@RequestBody(required=false) LoginReqVO param) throws Exception {
		//param.setLognPwdx(StringUtil.encrypt("1111"));
		webAccountService.updateWebAccountStatus(param);
		param = (LoginReqVO)StringUtil.nullToEmptyString(param);
		
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("COMP_NAME", param.getCompName());
		paramMap.put("LOGN_NAME", param.getLognName());
		paramMap.put("LOGN_IDXX", param.getLognIdxx());
		paramMap.put("REJECT_REASON", param.getRejectReason());

		SendMailVO sendMailVO = new SendMailVO();
		sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
		sendMailVO.setReceiverEmail(param.getMailAddr());
		sendMailVO.setReceiverName(param.getLognName());
		sendMailVO.setParams(paramMap);
		//고객에 메일 보내기
		if(param.getServGrad().equals("A")) {	//승인
			sendMailVO.setMailType(MailType.NEW_ACCOUNT_APPROVE_TO_CUSTOMER);
		} else if (param.getServGrad().equals("X")) {	//반려
			sendMailVO.setMailType(MailType.NEW_ACCOUNT_REJECT_TO_CUSTOMER);
		} else { //검토
			sendMailVO.setMailType(MailType.NEW_ACCOUNT_REVIEW_TO_CUSTOMER);
		}
		mailingService.sendMail(sendMailVO);

		//승인시 담당 영업사원에게 메일 보내기
		if(param.getServGrad().equals("A")) {	//승인
			if(!param.getDeptIdxx().equals("")){	//mma
				EmployVO mmaSalesEmp = commonService.getEmployBySawnCode(param.getDeptIdxx());
				SendMailVO sendMailVoToSales = new SendMailVO();
				sendMailVoToSales.setMailType(MailType.NEW_ACCOUNT_APPROVE_TO_SALES);
				sendMailVoToSales.setTitle("[LX MMA] '"+param.getLognName()+"("+param.getCompName()+")'의 담당 영업사원으로 지정되었습니다.");
				sendMailVoToSales.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
				sendMailVoToSales.setReceiverEmail(mmaSalesEmp.getMailAddr());
				sendMailVoToSales.setReceiverName(mmaSalesEmp.getSawnName());
				paramMap.put("PROD_ORG", "MMA");
				sendMailVoToSales.setParams(paramMap);
				mailingService.sendMail(sendMailVoToSales);
			}
			if(!param.getDeptPmma().equals("")){	//pmma
				EmployVO mmaSalesEmp = commonService.getEmployBySawnCode(param.getDeptPmma());
				SendMailVO sendMailVoToSales = new SendMailVO();
				sendMailVoToSales.setMailType(MailType.NEW_ACCOUNT_APPROVE_TO_SALES);
				sendMailVoToSales.setTitle("[LX MMA] '"+param.getLognName()+"("+param.getCompName()+")'의 담당 영업사원으로 지정되었습니다.");
				sendMailVoToSales.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
				sendMailVoToSales.setReceiverEmail(mmaSalesEmp.getMailAddr());
				sendMailVoToSales.setReceiverName(mmaSalesEmp.getSawnName());
				paramMap.put("PROD_ORG", "PMMA");
				sendMailVoToSales.setParams(paramMap);
				mailingService.sendMail(sendMailVoToSales);
			}
		}
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/webAccountInfo")
	public String webAccountInfo() throws Exception {
		return "customer/webAccountInfo";
	}

	@RequestMapping(value = "/getWebAccountList.json")
	public Map getWebAccountList(@RequestBody(required=false) LoginUserVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", webAccountService.getWebAccountListCount(param), "storeData", webAccountService.getWebAccountList(param));
	}
	
	@RequestMapping(value = "/getWebAccountDetail.json")
	public Map getWebAccountDetail(@RequestBody(required=false) LoginUserVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", webAccountService.getWebAccountDetail(param));
	}
	
	@RequestMapping(value = "/updateWebAccountDetail.json")
	public Map updateWebAccountDetail(@RequestBody(required=true) @Valid LoginUserVO param) throws Exception {
		LoginUserVO beforeVO = webAccountService.getWebAccountDetail(param);
		webAccountService.updateWebAccountDetail(param);
		param = (LoginUserVO)StringUtil.nullToEmptyString(param);

		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("COMP_NAME", param.getCompName());
		paramMap.put("LOGN_NAME", param.getLognName());
		paramMap.put("LOGN_IDXX", param.getLognIdxx());
		paramMap.put("LOGN_PWDX", param.getLognPwdx());

		if (beforeVO.getLognIdyn().equals("X")& param.getLognIdyn().equals("A")){
			//사용금지에서 승인으로
			SendMailVO sendMailVO = new SendMailVO();
			sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
			sendMailVO.setReceiverEmail(param.getMailAddr());
			sendMailVO.setReceiverName(param.getLognName());
			sendMailVO.setParams(paramMap);
			sendMailVO.setMailType(MailType.WEB_ACCOUNT_ENABLE_TO_CUSTOMER);
			mailingService.sendMail(sendMailVO);
		} else if (beforeVO.getLognIdyn().equals("A")& param.getLognIdyn().equals("X")) {
			//승인에서 사용금지로
			SendMailVO sendMailVO = new SendMailVO();
			sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
			sendMailVO.setReceiverEmail(param.getMailAddr());
			sendMailVO.setReceiverName(param.getLognName());
			sendMailVO.setParams(paramMap);
			sendMailVO.setMailType(MailType.WEB_ACCOUNT_DISABLE_TO_CUSTOMER);
			mailingService.sendMail(sendMailVO);
		}
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	
	@RequestMapping(value = "/getWebAccountCompList.json")
	public Map getWebAccountCompList(@RequestBody(required=false) LoginMastVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", webAccountService.getWebAccountCompListCount(param), "storeData", webAccountService.getWebAccountCompList(param));
	}
	@RequestMapping(value = "/initWebAccountPassword.json")
	public Map initWebAccountPassword(@RequestBody(required=true) LoginUserVO param) throws Exception {
		param.setLognPwdx(StringUtil.encrypt("1111"));
		webAccountService.initWebAccountPassword(param);
		param = (LoginUserVO)StringUtil.nullToEmptyString(param);

		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("COMP_NAME", param.getCompName());
		paramMap.put("LOGN_NAME", param.getLognName());
		paramMap.put("LOGN_IDXX", param.getLognIdxx());
		paramMap.put("LOGN_PWDX", "1111");

		SendMailVO sendMailVO = new SendMailVO();
		sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
		sendMailVO.setReceiverEmail(param.getMailAddr());
		sendMailVO.setReceiverName(param.getLognName());
		sendMailVO.setParams(paramMap);
		sendMailVO.setMailType(MailType.WEB_ACCOUNT_PASSOWORD_INIT_TO_CUSTOMER);
		mailingService.sendMail(sendMailVO);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/deleteCustFromWebAccount.json")
	public Map deleteCustFromWebAccount(@RequestBody(required=true) LoginMastVO param) throws Exception {
		webAccountService.deleteLoginMast(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/createCustOfWebAccount.json")
	public Map createCustOfWebAccount(@RequestBody(required=true) LoginMastVO param) throws Exception {
		webAccountService.createLoginMast(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/moveCustOfWebAccount.json")
	public Map moveCustOfWebAccount(@RequestBody(required=true) Map<String, Object> param) throws Exception {
		String toWebAccount = (String) ((Map) param.get("toWebAccount")).get("userNumx");
		List<Map<String, String>> fromLoginMastList = (List<Map<String, String>>) param.get("fromLoginMastList");
		for(Map<String, String> loginMastfrom : fromLoginMastList) {
			loginMastfrom.put("toUserNumx", toWebAccount);
		}
		webAccountService.moveCustOfWebAccount(fromLoginMastList);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	//잠재고객 등록
	@RequestMapping(value = "/potenCustRegist")
	public String potenCustRegist() throws Exception {
		return "customer/potenCustRegist";
	}
	
	//잠재고객 등록
	@RequestMapping(value = "/createPotenCust.json")
	public Map createPotenCust(@RequestBody(required=true) @Valid CompanyVO param) throws Exception {
		String message = "";
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("vkorg", param.getOrganVO().getVkorg());
		paramMap.put("busino", param.getStcd2());
		CompanyVO companyVO = commonService.checkCompanyBusinoDub(paramMap);
		if(companyVO != null) {
			message = "기존 고객사입니다. (대표자:"+companyVO.getJ1kfrepre()+" )";
			message +="\n영업조직 "+Vkorg.getVkorg(param.getOrganVO().getVkorg()).getName()+"는 이미 존재합니다.";
			return JsonResponse.asFailure(message);
		}
		param.setCompCode(Util.getUUID());
		param.getOrganVO().setCompCode(param.getCompCode());
		param.getOrganVO().setCompLevl1("00050");	//잠재고객
		param.getOrganVO().setRegiIdxx(SecurityContextHolder.getContext().getAuthentication().getName());
		param.getOrganVO().setUpdtIdxx(SecurityContextHolder.getContext().getAuthentication().getName());
		
		customerService.createCustomer(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/compFileList")
	public ModelAndView compFileList(ModelAndView mav) throws Exception {
		mav.setViewName("customer/compFileList");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("defaultYyyy"	, DateUtil.getCurrentYear());
		mav.addObject("defaultYyyyMm",DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6));
		return mav;
	}
	
	@RequestMapping(value = "/getCompFileList.json")
	public Map getcompFileList(@RequestBody(required=false) @Valid CompFileListVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", customerService.getCompFileList(param));
	}

	//거래선 요청목록
	@RequestMapping(value = "/customerRequests")
	public String customerRequests() throws Exception {
		return "customer/customerRequests";
	}
	
	@RequestMapping(value = "/getCustomerRequestsList.json")
	public Map getCustomerRequestsList(@RequestBody CustReqVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", customerService.getCustomerRequestsCount(param), "storeData", customerService.getCustomerRequestsList(param));
	}
	
	@RequestMapping(value = "/getCustomerRequestDetail.json")
	public Map getCustomerRequestDetail(@RequestBody(required=false) CustReqVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", customerService.getCustomerRequestDetail(param));
	}
	
}
