package com.lgmma.salesPortal.app.dao.impl;

import com.lgmma.salesPortal.app.dao.DissSpecInSaleGoalDao;
import com.lgmma.salesPortal.app.model.DissSpecInSaleGoalVO;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class DissSpecInSaleGoalDaoImpl implements DissSpecInSaleGoalDao {

    private static final String MAPPER_NAMESPACE = "DISS_SPECIN_SALEGOAL_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public void createDissSpecInSaleGoal(DissSpecInSaleGoalVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissSpecInSaleGoal", param);
	}

	@Override
	public void createDissSpecInSaleGoalHis(DissSpecInSaleGoalVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissSpecInSaleGoalHis", param);
	}

	@Override
	public void deleteDissSpecInSaleGoalAll(DissSpecInSaleGoalVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissSpecInSaleGoalAll", param);
	}

	@Override
	public void deleteDissSpecInSaleGoalAllHis(DissSpecInSaleGoalVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissSpecInSaleGoalAllHis", param);
	}

	@Override
	public void updateDissSpecInSaleGoal(DissSpecInSaleGoalVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissSpecInSaleGoal", param);
	}

	@Override
	public List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalList(String taskId) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissSpecInSaleGoalList",taskId);
	}

	@Override
	public List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalListHis(String stepId) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissSpecInSaleGoalListHis",stepId);
	}

	@Override
	public List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalListFirst(String taskId) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissSpecInSaleGoalListFirst",taskId);
	}

}
