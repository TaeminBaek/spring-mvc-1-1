package com.lgmma.salesPortal.common.props;

import java.util.ArrayList;
import java.util.List;

public enum ApprType {
/**
 * 품의서구분으로서
*/
	 APPR_TYPE_NEW_CUST                 		("001", "신규고객등록"     ,true, true	,"gportalCompanyCreatePostProcessImpl", null,"AUTO", false)
	,APPR_TYPE_NEW_CUST_AND_CREDIT      		("002", "신규고객등록(여신)",true, true	,"gportalPostProcessImpl", null,"AUTO", false)
	,APPR_TYPE_MODIFY_CUST	            		("003", "고객정보수정"     ,true, true	,"gportalCompanyUpdatePostProcessImpl", null,"AUTO", false)
	,APPR_TYPE_CREDIT                   		("004", "여신증액"        ,true, true	,"gportalCreditPostProcessImpl", null,"AUTO", false)
	,APPR_TYPE_SAMPLE                   		("005", "견본품의(샘플)"   ,true, true	,"gportalSampleOrderPostProcessImpl", null,"AUTO", false)
	,APPR_TYPE_SAMPLE2                  		("015", "견본품의(시판)"   ,true, true	,"gportalPostProcessImpl", null,"AUTO", false)
	,APPR_TYPE_SALE_PRICE               		("006", "판가품의"        ,true, false,"gportalSalePirceMonthlyCloseProcessImpl", null,"AUTO", false)
	,APPR_TYPE_SALE_NOTE                		("007", "영업일지"        ,false, true,"gportalPostProcessImpl", null,"AUTO", false)
	,APPR_TYPE_GENERAL                  		("008", "일반품의"        ,false, false,"gportalPostProcessImpl", null,"AUTO", false)
	,APPR_TYPE_MIG                      		("MIG", "이관"           ,false, false,"gportalPostProcessImpl", null,"AUTO", false)
	,APPR_TYPE_DISS_SAMPLE_NOTICE       		("100", "DISS견본일정공지"   ,false, false	,null, "dissPublic/dissSampleOrderNoticeAppr","LIST", true)
	,APPR_TYPE_DISS_SAMPLE              		("105", "DISS견본품의"   ,true, true	,null, "dissPublic/dissSampleOrderAppr","LIST", true)
	,APPR_TYPE_DISS_SPECIN_REG          		("201", "SPEC-IN등록"       ,true, false,null, "dissSpecIn/dissSpecInRegAppr","LIST", true)
	,APPR_TYPE_DISS_SPECIN_SCHEDULE_EDIT        ("202", "SPEC-IN일정수정"   ,true, false,null, "dissSpecIn/dissSpecInScheduleEditAppr","LIST", true)
	,APPR_TYPE_DISS_SPECIN_CTQ_EDIT 	        ("203", "SPEC-INCTQ수정"   ,false, false,null, "dissSpecIn/dissSpecInCtqEditAppr","LIST", false)
	,APPR_TYPE_DISS_IMPDEV_SCHEDULE_EDIT        ("204", "제품개선개발제안일정수정"   ,true, false,null, "dissImpDev/dissImpDevScheduleEditAppr","LIST", true)
	,APPR_TYPE_DISS_IMPDEV_PROPOSAL     		("301", "개선개발제안서"  ,true, false,null, "dissAppr/dissImpDevProposalAppr","LIST", true)
	,APPR_TYPE_DISS_SPECIN_COLOR_PROPOSAL 		("311", "컬러개발제안서"  ,true, false,null, "dissSpecIn/dissSpecInColorProposalAppr","LIST", true)
	,APPR_TYPE_DISS_IMPDEV_LEVEL_CHG    		("302", "개발등급변경"   ,true, false,null, "dissAppr/dissImpDevProposalAppr","LIST", true)
	,APPR_TYPE_DISS_IMPDEV_PRESCRIPTION 		("303", "소재개발결과등록",true, false,null, "dissAppr/dissImpDevPrescriptionAppr","LIST", true)
	,APPR_TYPE_DISS_SPECIN_COLOR_PRESCRIPTION	("313", "컬러개발결과등록",true, false,null, "dissSpecIn/dissSpecInColorPrescriptionAppr","LIST", true)
	,APPR_TYPE_DISS_IMPDEV_SAMPLEEVAL 		    ("304", "TS견본검증결과보고",false, false,null, "dissAppr/dissImpDevSampleEvalAppr","LIST", true)
	,APPR_TYPE_DISS_IMPDEV_FT_PLAN      		("391", "F/Test계획"    ,true, false,null, "dissImpDev/dissImpDevFtPlanAppr","LIST", false)
	,APPR_TYPE_DISS_IMPDEV_FT_RESULT    		("392", "F/Test결과"    ,true, false,null, "dissImpDev/dissImpDevFtResultAppr","LIST", false)
	,APPR_TYPE_DISS_IMPDEV_COMPOUND     		("393", "Comp'd처방"    ,true, false,null, "dissImpDev/dissImpDevCompoundAppr","LIST", false)
	,APPR_TYPE_DISS_CUSTTEST 		            ("501", "고객TEST결과등록",true, false,null, "dissAppr/dissPublicCustTestAppr","LIST", true)
	,APPR_TYPE_DISS_COMPLETE 		            ("502", "과제완료결과등록",true, false,null, "dissAppr/dissPublicCompleteAppr","LIST", true)
	,APPR_TYPE_DISS_MASSTRANS 		            ("503", "양산이관보고",true, false,null, "dissAppr/dissPublicMassTransAppr","LIST", true)
	,APPR_TYPE_DISS_COMPGRADE                   ("504", "규격제정/개정",true, false,null, "dissAppr/dissPublicCompGradeAppr","LIST", true)
	,APPR_TYPE_DISS_ONETEAM_REG         		("401", "원팀과제등록"      ,true, false,null, "dissOneTeam/dissOneTeamRegAppr","LIST", true)
	,APPR_TYPE_DISS_ONETEAM_UPDATE_COMMON       ("402", "원팀과제기본정보/개요/멤버수정"    ,false, false,null, "dissOneTeam/dissOneTeamUpdateCommonDtl","LIST", false)	// 스텝 생성용(품의 X)
	,APPR_TYPE_DISS_ONETEAM_UPDATE_PERFORMANCE  ("403", "원팀과제KPI/예상성과/SPEC-IN정보수정" ,false, false,null, "dissOneTeam/dissOneTeamUpdatePerformDtl","LIST", false)	// 스텝 생성용(품의 X)
	,APPR_TYPE_DISS_ONETEAM_REPORT      		("410", "원팀과제활동내역"    ,false, false,null, "dissOneTeam/dissOneTeamMinutesAppr","LIST", true)
	,APPR_TYPE_DISS_ONETEAM_COMPLETE    		("420", "원팀과제완료"   ,true, false,null, "dissOneTeam/dissOneTeamCompleteAppr","LIST", true)
	,APPR_TYPE_DISS_DAILY_ACT            		("900", "DAILY활동",false, false,null, "dissPublic/dissPublicDailyActAppr","LIST", true)
	;

	String	code					= null;	// 품의서구분코드(AUTO,LIST)
	String	name					= null;	// 품의서구분명   (AUTO,LIST)
	boolean	reqApprLineYn			= true;	// 결재라인필수여부(AUTO,LIST)
	boolean	reqCustYn				= true;	// 고객정보필수여부(AUTO)
	String	gpPostServiceBeanName   = null;	// 품의서구분별 후속 프로세스처리 bean name(AUTO)
	String	targetView	            = null;	// 품의서원본페이지뷰(LIST)
	String gpSendType               = null; // 품의서 GPortal 연계방식(AUTO,LIST 둘중 하나 반드시 지정)
	boolean commentYn				= false; // 댓글 사용 여부

	private ApprType(String code, String name, boolean reqApprLineYn, boolean reqCustYn, String gpPostServiceBeanName,String targetView,String gpSendType, boolean commentYn) {
		this.code					= code;
		this.name					= name;
		this.reqApprLineYn			= reqApprLineYn;
		this.reqCustYn				= reqCustYn;
		this.gpPostServiceBeanName	= gpPostServiceBeanName;
		this.targetView             = targetView;
		this.gpSendType             = gpSendType;
		this.commentYn				= commentYn;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public boolean isReqApprLineYn() {
		return reqApprLineYn;
	}

	public void setReqApprLineYn(boolean reqApprLineYn) {
		this.reqApprLineYn = reqApprLineYn;
	}

	public boolean isReqCustYn() {
		return reqCustYn;
	}

	public void setReqCustYn(boolean reqCustYn) {
		this.reqCustYn = reqCustYn;
	}

	public String getGpPostServiceBeanName() {
		return gpPostServiceBeanName;
	}

	public void setGpPostServiceBeanName(String gpPostServiceBeanName) {
		this.gpPostServiceBeanName = gpPostServiceBeanName;
	}

	public String getTargetView() {
		return targetView;
	}

	public void setTargetView(String targetView) {
		this.targetView = targetView;
	}

	public String getGpSendType() {
		return gpSendType;
	}

	public void setGpSendType(String gpSendType) {
		this.gpSendType = gpSendType;
	}
	
	public boolean isCommentYn() {
		return commentYn;
	}
	
	public void setCommentYn(boolean commentYn) {
		this.commentYn= commentYn;
	}

	public static ApprType getApprType(String code) {
		for(ApprType type : ApprType.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
	
	public static List<ApprType> getApprTypeByGpSendType(String gpSendType) {
		List<ApprType> returnList = new ArrayList<ApprType>();
		for(ApprType type : ApprType.values()) {
			if(type.getGpSendType().equals(gpSendType)) {
				returnList.add(type);
			}
		}
		return returnList;
	}
}
