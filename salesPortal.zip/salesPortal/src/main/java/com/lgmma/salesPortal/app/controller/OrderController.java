package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.OrderHeadVO;
import com.lgmma.salesPortal.app.model.OrderItemVO;
import com.lgmma.salesPortal.app.model.OrderListVO;
import com.lgmma.salesPortal.app.model.OrderSaleNameListVO;
import com.lgmma.salesPortal.app.service.OrderService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.props.SalePriceMasterPriceListType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;


@Controller
@RequestMapping("/order") 
public class OrderController {

	@Autowired
	private OrderService orderService;

	@Autowired
	private CommonController commonController;
	
	@Autowired
	private DirectOrderController directOrderController;
	
	@RequestMapping(value = "/orderInfo")
	public ModelAndView orderInfo(ModelAndView mav) throws Exception {
		mav.setViewName("order/orderInfo");
		mav.addObject("vkorgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		return mav;
	}
	
	@RequestMapping(value = "/getOrderList.json")
	public Map getOrderList(@RequestBody(required = false) OrderListVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", orderService.getOrderCount(param), "storeData", orderService.getOrderList(param));
	}
/*	
	@RequestMapping(value = "/getOrderList.json")
	public Map getOrderList(@RequestBody(required = false) OrderListVO param) throws Exception {
		List<OrderListVO> orderList = null;
		int orderCount = 0;
		if(param.getGubun().equals("W")) {
			orderCount = orderService.getOrderCount(param);
			orderList = orderService.getOrderList(param);
		}else if(param.getGubun().equals("X")) {
			orderCount = orderService.getSapOrderCount(param);
			orderList = orderService.getSapOrderList(param);
		}else if(param.getGubun().equals("")) {
			orderCount = orderService.getTotOrderCount(param);
			orderList = orderService.getTotOrderList(param);
		}
		return JsonResponse.asSuccess("itemsCount", orderCount, "storeData", orderList);
	}
*/	
	@RequestMapping(value = "/getOrderDetail.json")
	public Map getOrderDetail(@RequestBody(required=false) OrderHeadVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", orderService.getOrderDetail(param));
	}
	
	@RequestMapping(value = "/getOrderHead.json")
	public Map getOrderHead(@RequestBody(required=false) OrderHeadVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", orderService.getOrderHead(param));
	}
	
	@RequestMapping(value = "/getOrderItemList.json")
	public Map getOrderItemList(@RequestBody(required = false) OrderItemVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", orderService.getOrderItemList(param));
	}
	
	@RequestMapping(value = "/getSaleNameList.json")
	public Map getSaleNameList(@RequestBody(required = false) OrderSaleNameListVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", orderService.getSaleNameCount(param),"storeData", orderService.getSaleNameList(param));
	}
	
	@RequestMapping(value = "/createOrder.json")
	public Map createOrder(@RequestBody OrderHeadVO param ) throws Exception {
		//orderService.createOrder(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	//확정된 전자상거래 주문의 수정
	@RequestMapping(value = "/updateEaslesOrder.json")
	public Map updateEaslesOrder(@RequestBody OrderHeadVO param ) throws Exception {
		orderService.updateEaslesOrder(param);
		return JsonResponse.asSuccess("success", "수정되었습니다");
	}
	
	//확정된 전자상거래 주문의 비고수정
	@RequestMapping(value = "/updateEaslesOrderComment.json")
	public Map updateEaslesOrderComment(@RequestBody OrderHeadVO param ) throws Exception {
		orderService.updateEaslesOrderComment(param);
		return JsonResponse.asSuccess("success", "수정되었습니다");
	}
	
	//확정된 전자상거래 주문의 판가유형 변경
	@RequestMapping(value = "/updateEaslesOrderPriceMaster.json")
	public Map updateEaslesOrderPriceMaster(@RequestBody OrderHeadVO param ) throws Exception {
		orderService.updateEaslesOrderPriceMaster(param);
		return JsonResponse.asSuccess("success", "변경되었습니다");
	}
	
	//확정된 전자상거래 주문의 삭제
	@RequestMapping(value = "/deleteEaslesOrder.json")
	public Map deleteEaslesOrder(@RequestBody OrderHeadVO param ) throws Exception {
		orderService.deleteEaslesOrder(param);
		return JsonResponse.asSuccess("success", "삭제되었습니다");
	}
	
	@RequestMapping(value = "/updateOrderItem.json")
	public Map updateOrderItem(@RequestBody List<OrderItemVO> param ) throws Exception {
		orderService.updateOrderItem(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/deleteOrderItem.json")
	public Map deleteOrderItem(@RequestBody List<OrderItemVO> param ) throws Exception {
		orderService.deleteOrderItem(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/orderConfirmInfo")
	public ModelAndView orderConfirmInfo(ModelAndView mav) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		mav.setViewName("order/orderConfirmInfo");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("vkorgSelect", ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getVkorg());
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));

		CommonCodeVO commonCodeVO = new CommonCodeVO();
		commonCodeVO.setGrupCode("HVALUEMMA");
		mav.addObject("HVALUEMMA", mapper.writeValueAsString(commonController.getCode(commonCodeVO).get("items")));
		commonCodeVO.setGrupCode("HVALUEPMMA");
		mav.addObject("HVALUEPMMA", mapper.writeValueAsString(commonController.getCode(commonCodeVO).get("items")));

		Map<String, Object> codeMap = directOrderController.getOrderCode(OrderType.ESALES);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("domesticSalePriceList", mapper.writeValueAsString(SalePriceMasterPriceListType.getSalePriceListItemList(SalePriceMasterPriceListType.getDomesticSalePriceList())));                                                               
		mav.addObject("exportSalePriceList", mapper.writeValueAsString(SalePriceMasterPriceListType.getSalePriceListItemList(SalePriceMasterPriceListType.getExportSalePriceList())));                                                               
		return mav;
	}
	
	@RequestMapping(value = "/getOrderConfirmList.json")
	public Map getOrderConfirmList(@RequestBody(required = false) OrderListVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", orderService.getOrderConfirmCount(param), "storeData", orderService.getOrderConfirmList(param));
	}
	
	@RequestMapping(value = "/getOrderConfirmDetail.json")
	public Map getOrderConfirmDetail(@RequestBody(required=false) OrderHeadVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", orderService.getOrderConfirmDetail(param));
	}
	
	@RequestMapping(value = "/getOrderConfirmItemList.json")
	public Map getOrderConfirmItemList(@RequestBody(required = false) OrderItemVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", orderService.getOrderConfirmItemList(param));
	}
	
	@RequestMapping(value = "/confirmOrder.json")
	public Map confirmOrder(@RequestBody(required=true) @Valid OrderHeadVO param) throws Exception {
		orderService.confirmOrder(param);
		return JsonResponse.asSuccess("success", "확정되었습니다.");
	}
	
	@RequestMapping(value = "/rejectOrder.json")
	public Map rejectOrder(@RequestBody(required=true) @Valid OrderHeadVO param) throws Exception {
		orderService.rejectOrder(param);
		return JsonResponse.asSuccess("success", "출하불가 또는 보류 되었습니다.");
	}
	
	@RequestMapping(value = "/getEaslesOrderDetail.json")
	public Map getEaslesOrderDetail(@RequestBody(required=true) DirectOrderMasterVO param) throws Exception {
		//확정건의 orderId 로 tbs_orderhead, tbs_orderitem 의 erpx_idxx 를 찾는다. 
		return JsonResponse.asSuccess("storeData", orderService.getConfirmedEaslesOrderDetail(param.getOrderId()));
	}
	
}
