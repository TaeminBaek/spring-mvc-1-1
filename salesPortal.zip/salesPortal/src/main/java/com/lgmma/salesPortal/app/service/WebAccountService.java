package com.lgmma.salesPortal.app.service;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.LoginMastVO;
import com.lgmma.salesPortal.app.model.LoginReqVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;

public interface WebAccountService {

	int getNewWebAccountRequestsCount(LoginReqVO param);

	List<LoginReqVO> getNewWebAccountRequests(LoginReqVO param);

	LoginReqVO getWebAccountRequestDetail(LoginReqVO param);

	void updateWebAccountStatus(LoginReqVO param);

	int getWebAccountListCount(LoginUserVO param);

	List<LoginUserVO> getWebAccountList(LoginUserVO param);

	LoginUserVO getWebAccountDetail(LoginUserVO param);

	int getWebAccountCompListCount(LoginMastVO param);

	List<LoginMastVO> getWebAccountCompList(LoginMastVO param);

	void initWebAccountPassword(LoginUserVO param);

	void updateWebAccountDetail(LoginUserVO param);

	void deleteLoginMast(LoginMastVO param);

	void createLoginMast(LoginMastVO param);

	void moveCustOfWebAccount(List<Map<String, String>> fromLoginMastList);

	void updatePartnerWebAccountDetail(LoginUserVO param);


}
