package com.lgmma.salesPortal.app.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DirectOrderMigDao;
import com.lgmma.salesPortal.app.model.DirectOrderMigVO;


@Repository
public class DirectOrderMigDaoImpl implements DirectOrderMigDao {

    private static final String MAPPER_NAMESPACE = "DIRECT_ORDER_MIG_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public void createDirectOrderMig(DirectOrderMigVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDirectOrderMig", param);
	}

	@Override
	public DirectOrderMigVO createDirectOrderMigTrans(DirectOrderMigVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "createDirectOrderMigTrans", param);
	}
}
