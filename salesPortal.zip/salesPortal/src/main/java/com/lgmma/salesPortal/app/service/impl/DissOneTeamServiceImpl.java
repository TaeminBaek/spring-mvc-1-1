
package com.lgmma.salesPortal.app.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.lgmma.salesPortal.app.dao.CommonApprDao;
import com.lgmma.salesPortal.app.dao.DissKpiDao;
import com.lgmma.salesPortal.app.dao.DissMemberDao;
import com.lgmma.salesPortal.app.dao.DissOneTeamDao;
import com.lgmma.salesPortal.app.dao.DissOneTeamMinutesDao;
import com.lgmma.salesPortal.app.dao.DissStepDao;
import com.lgmma.salesPortal.app.dao.DissTaskSpecInDao;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissKpiVO;
import com.lgmma.salesPortal.app.model.DissMemberVO;
import com.lgmma.salesPortal.app.model.DissOneTeamMinutesVO;
import com.lgmma.salesPortal.app.model.DissOneTeamVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.model.DissTaskSpecInVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.DissOneTeamService;
import com.lgmma.salesPortal.app.service.DissSpecInService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.props.ApplState;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

import freemarker.template.Configuration;

@Service
public class DissOneTeamServiceImpl implements DissOneTeamService{
	
	private static Logger logger = LoggerFactory.getLogger(DissOneTeamServiceImpl.class);
	
	@Autowired
	private DissCommonApprMgmtService dissCommonApprMgmtService;
	
	@Autowired
    private PlatformTransactionManager transactionManager;
	
	@Autowired
	DissOneTeamDao dissOneTeamDao;

	@Autowired
	DissKpiDao dissKpiDao;
	
	@Autowired
	DissMemberDao dissMemberDao;
	
	@Autowired
	DissTaskSpecInDao dissTaskSpecInDao;
	
	@Autowired
	DissStepDao dissStepDao;
	
	@Autowired
	DissSpecInService dissSpecInService;
	
	@Autowired
	CommonApprDao commonApprDao;
	
	@Autowired
	DissOneTeamMinutesDao dissOneTeamMinutesDao;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	@Autowired
	private CommonFileService commonFileService;
	
	@Autowired
    @Qualifier(value="reportFreemarkerConfiguration")
    private Configuration reportTemplateConfiguration;
	
	private final String REPORT_TEMPLATE_DISS_PUBLIC_ONE_TEAM = "REPORT_TEMPLATE_DISS_PUBLIC_ONE_TEAM"; 
	
	private final String REPORT_TEMPLATE_DISS_PUBLIC_ONE_TEAM_MIN = "REPORT_TEMPLATE_DISS_PUBLIC_ONE_TEAM_MIN"; //kjy
	
	@Override
	public void saveDissOneTeam(DissOneTeamVO param) {
		
		// 최초등록인지 판단
		if("".equals(param.getTaskId())){ 
			//createDissOneTeam(param);			//insert
			
			//원팀코드 생성
			param.setTaskCd(dissOneTeamDao.createDissOneTeamCode());
			//원팀과제 HIS 생성
			String stepId = Util.getUUID();
			param.setStepId(stepId);
			dissOneTeamDao.createDissOneTeamHis(param);
			//원팀과제 마스터 생성
			String taskId = Util.getUUID();
			param.setTaskId(taskId);
			dissOneTeamDao.createDissOneTeam(param);
			//품의서 ID 생성
			String apprId = Util.getUUID();
			param.getApprVO().setApprId(apprId);
			//원팀과제등록 STEP 생성
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setStepId(stepId);
			dissStepVO.setTaskId(taskId);
			dissStepVO.setTaskType(param.getTaskType());
			dissStepVO.setStepCd(param.getStepCd()); // 원팀과제등록 DISS_STEP_CD
			dissStepVO.setApprId(apprId);
			dissStepVO.setStepLastYn("Y");
			dissStepVO.setRegiIdxx(param.getRegiIdxx());
			dissStepVO.setUpdtIdxx(param.getUpdtIdxx());
			dissStepDao.createDissStep(dissStepVO);
			
			//KPI, 멤버, SPEC-IN 정보  생성
			if(param.getDissKpiList().size() > 0) {
				for(DissKpiVO vo : param.getDissKpiList()){
					vo.setKpiId(Util.getUUID());
					vo.setTaskType(param.getTaskType());
					vo.setTaskId(param.getTaskId());
					vo.setRegiIdxx(param.getRegiIdxx());
					vo.setUpdtIdxx(param.getUpdtIdxx());
					dissKpiDao.createDissKpi(vo);
				}
			}
			
			if(param.getDissMemberList().size() > 0) {
				for(DissMemberVO vo : param.getDissMemberList()){
					vo.setTaskMemberId(Util.getUUID());
					vo.setTaskType(param.getTaskType());
					vo.setTaskId(param.getTaskId());
					vo.setRegiIdxx(param.getRegiIdxx());
					vo.setUpdtIdxx(param.getUpdtIdxx());
					dissMemberDao.createDissMember(vo);
				}
			}
			
			if(param.getDissTaskSpecInList().size() > 0) {
				for(DissTaskSpecInVO vo : param.getDissTaskSpecInList()){
					vo.setTaskId(param.getTaskId());
					vo.setRegiIdxx(param.getRegiIdxx());
					vo.setUpdtIdxx(param.getUpdtIdxx());
					dissTaskSpecInDao.createDissTaskSpecIn(vo);
				}
			}
			
			//KPI, 멤버, SPEC-IN 정보 HIS 생성
			createAfterDeleteAllKpiHis(param);
			createAfterDeleteAllMemberHis(param);
			createAfterDeleteAllTaskSpecinHis(param);
		} else {
			//반려건
			if(param.getApprVO().getApprStat().equals("4010") || param.getApprVO().getApprStat().equals("4020")) {
				//createStepAndHistory(param);
				//품의서 ID 생성
				String apprId = Util.getUUID();
				param.getApprVO().setApprId(apprId);
				
				// LAST_STEP_YN : Y->N
				DissStepVO lastStepVO = new DissStepVO();
				lastStepVO.setTaskId(param.getTaskId());
				lastStepVO.setStepCd(param.getStepCd());
				dissStepDao.updateDissStepLastYn(lastStepVO);
				
				//원팀과제 HIS 생성
				String stepId = Util.getUUID();
				param.setStepId(stepId);
				dissOneTeamDao.createDissOneTeamHis(param);
				
				//원팀과제등록 STEP 생성
				DissStepVO dissStepVO = new DissStepVO();
				dissStepVO.setStepId(stepId);
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType());
				dissStepVO.setStepCd(param.getStepCd()); 
				dissStepVO.setApprId(apprId);
				dissStepVO.setStepLastYn("Y");
				dissStepVO.setRegiIdxx(param.getRegiIdxx());
				dissStepVO.setUpdtIdxx(param.getUpdtIdxx());
				dissStepDao.createDissStep(dissStepVO);
				
				//KPI, 멤버 HIS 삭제 후 생성
				createAfterDeleteAllKpiHis(param);
				createAfterDeleteAllMemberHis(param);
				createAfterDeleteAllTaskSpecinHis(param);
			} else {
				updateDissOneTeam(param);			//update
			}
		}
		
		//공통품의
		String saveType = param.getApprVO().getSaveType();
		String apprStat = "";
		switch(saveType) {
			case "TEMP" : apprStat = ApprState.TEMP_SAVE.getCode();
				break;
			case "SAVE" : apprStat = ApprState.APPR_PROCEEDING.getCode();
				break;
			case "REAPPR" : apprStat = ApprState.TEMP_SAVE.getCode();
				break;
		}
		String apprType = ApprType.APPR_TYPE_DISS_ONETEAM_REG.getCode();
		ApprVO apprVO = param.getApprVO();
		apprVO.setApprType(apprType);
		apprVO.setApprStat(apprStat);
		apprVO.setRegiIdxx(param.getRegiIdxx());
		apprVO.setUpdtIdxx(param.getUpdtIdxx());
		//내용만들고 같이 보내기.
		String templeteFormContent = param.getApprVO().getFormCont();
		param.getApprVO().setTempleteFormContent(getApprFormContOneTeam(param, templeteFormContent));
		dissCommonApprMgmtService.saveDissCommonAppr(apprVO,apprStat, false);
	}

	
	private void createStepAndHistory(DissOneTeamVO param) {
		
		//품의서 ID 생성
		String apprId = Util.getUUID();
		param.getApprVO().setApprId(apprId);
		
		// LAST_STEP_YN : Y->N
		DissStepVO lastStepVO = new DissStepVO();
		lastStepVO.setTaskId(param.getTaskId());
		lastStepVO.setStepCd(param.getStepCd());
		dissStepDao.updateDissStepLastYn(lastStepVO);
		
		//원팀과제 HIS 생성
		String stepId = Util.getUUID();
		param.setStepId(stepId);
		dissOneTeamDao.createDissOneTeamHis(param);
		
		//원팀과제등록 STEP 생성
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(stepId);
		dissStepVO.setTaskId(param.getTaskId());
		dissStepVO.setTaskType(param.getTaskType());
		dissStepVO.setStepCd(param.getStepCd()); 
		dissStepVO.setApprId(apprId);
		dissStepVO.setStepLastYn("Y");
		dissStepVO.setRegiIdxx(param.getRegiIdxx());
		dissStepVO.setUpdtIdxx(param.getUpdtIdxx());
		dissStepDao.createDissStep(dissStepVO);
		
		//KPI, 멤버 HIS 삭제 후 생성
		createAfterDeleteAllKpiHis(param);
		createAfterDeleteAllMemberHis(param);
		createAfterDeleteAllTaskSpecinHis(param);
		
	}
	
	@Override
	public void createDissOneTeam(DissOneTeamVO param) {
		//원팀코드 생성
		param.setTaskCd(dissOneTeamDao.createDissOneTeamCode());
		//원팀과제 HIS 생성
		String stepId = Util.getUUID();
		param.setStepId(stepId);
		dissOneTeamDao.createDissOneTeamHis(param);
		//원팀과제 마스터 생성
		String taskId = Util.getUUID();
		param.setTaskId(taskId);
		dissOneTeamDao.createDissOneTeam(param);
		//품의서 ID 생성
		String apprId = Util.getUUID();
		param.getApprVO().setApprId(apprId);
		//원팀과제등록 STEP 생성
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(stepId);
		dissStepVO.setTaskId(taskId);
		dissStepVO.setTaskType(param.getTaskType());
		dissStepVO.setStepCd(param.getStepCd()); // 원팀과제등록 DISS_STEP_CD
		dissStepVO.setApprId(apprId);
		dissStepVO.setStepLastYn("Y");
		dissStepVO.setRegiIdxx(param.getRegiIdxx());
		dissStepVO.setUpdtIdxx(param.getUpdtIdxx());
		dissStepDao.createDissStep(dissStepVO);
		
		//KPI, 멤버, SPEC-IN 정보  생성
		if(param.getDissKpiList().size() > 0) {
			for(DissKpiVO vo : param.getDissKpiList()){
				vo.setKpiId(Util.getUUID());
				vo.setTaskType(param.getTaskType());
				vo.setTaskId(param.getTaskId());
				vo.setRegiIdxx(param.getRegiIdxx());
				vo.setUpdtIdxx(param.getUpdtIdxx());
				dissKpiDao.createDissKpi(vo);
			}
		}
		
		if(param.getDissMemberList().size() > 0) {
			for(DissMemberVO vo : param.getDissMemberList()){
				vo.setTaskMemberId(Util.getUUID());
				vo.setTaskType(param.getTaskType());
				vo.setTaskId(param.getTaskId());
				vo.setRegiIdxx(param.getRegiIdxx());
				vo.setUpdtIdxx(param.getUpdtIdxx());
				dissMemberDao.createDissMember(vo);
			}
		}
		
		if(param.getDissTaskSpecInList().size() > 0) {
			for(DissTaskSpecInVO vo : param.getDissTaskSpecInList()){
				vo.setTaskId(param.getTaskId());
				vo.setRegiIdxx(param.getRegiIdxx());
				vo.setUpdtIdxx(param.getUpdtIdxx());
				dissTaskSpecInDao.createDissTaskSpecIn(vo);
			}
		}
		
		//KPI, 멤버, SPEC-IN 정보 HIS 생성
		createAfterDeleteAllKpiHis(param);
		createAfterDeleteAllMemberHis(param);
		createAfterDeleteAllTaskSpecinHis(param);
		
	}

	@Override
	public int getDissOneTeamListCount(DissOneTeamVO param) {
		return dissOneTeamDao.getDissOneTeamListCount(param);
	}

	@Override
	public List<DissOneTeamVO> getDissOneTeamList(DissOneTeamVO param) {
		return dissOneTeamDao.getDissOneTeamList(param);
	}

	@Override
	public List<DissOneTeamVO> getDissOneTeamLeaderTeamList() {
		return dissOneTeamDao.getDissOneTeamLeaderTeamList();
	}

	@Override
	public void updateDissOneTeam(DissOneTeamVO param) {
		//DISS 원팀과제 HIS 수정
		dissOneTeamDao.updateDissOneTeamHis(param);
		//KPI, 멤버 HIS 삭제 후 생성
		createAfterDeleteAllKpiHis(param);
		createAfterDeleteAllMemberHis(param);
		createAfterDeleteAllTaskSpecinHis(param);
	}

	@Override
	public void deleteDissOneTeamAll(DissStepVO param) {
		
	}

	@Override
	public DissOneTeamVO getDissOneTeamInfo(DissOneTeamVO param) {
		DissOneTeamVO dissOneTeamVO = new DissOneTeamVO();
		
		
		if(param.getApprType().equals("401")) { // 등록팝업
			dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(getDissOneTeamHisInfo(param));
		} else if(param.getApprType().equals("402")) { // 수정팝업(개요&멤버)
			if(!"".equals(param.getStepId())) {
				dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(getDissOneTeamHisInfo(param));
			} else {
				dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(getDissOneTeamMasterInfo(param));
			}
		} else if(param.getApprType().equals("403")) { // 수정팝업(KPI&예상성과)
			if(!"".equals(param.getStepId())) {
				dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(getDissOneTeamHisInfo(param));
			} else {
				dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(getDissOneTeamMasterInfo(param));
			}
		} else if(param.getApprType().equals("420")) { // 완료팝업
			
			if(!"".equals(param.getStepId())) {
				dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(getDissOneTeamHisInfo(param));
			} else {
				dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(getDissOneTeamMasterInfo(param));
			}
		} else { // 상세탭
			dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(getDissOneTeamMasterInfo(param));
		}
		
		return dissOneTeamVO;
	}
	
	@Override
	public DissOneTeamVO getDissOneTeamMasterInfo(DissOneTeamVO param) {
		DissOneTeamVO dissOneTeamVO = dissOneTeamDao.getDissOneTeamInfo(param);
		// KPI
		DissKpiVO dissKpiVO = new DissKpiVO();
		dissKpiVO.setTaskId(param.getTaskId());
		dissOneTeamVO.setDissKpiList(dissKpiDao.getDissKpiList(dissKpiVO));
		// 멤버
		DissMemberVO dissMemberVO = new DissMemberVO();
		dissMemberVO.setTaskId(param.getTaskId());
		List<DissMemberVO> dissMemberListaggList = dissMemberDao.getDissMemberListaggList(dissMemberVO); 
		dissOneTeamVO.setDissMemberListaggList(dissMemberListaggList);
		//멤버 조회(수정시 사용)
		List<DissMemberVO> dissMemberList = dissMemberDao.getDissMemberList(dissMemberVO);
		dissOneTeamVO.setDissMemberList(dissMemberList);
		// SPEC-IN 정보
		DissTaskSpecInVO dissTaskSpecInVO = new DissTaskSpecInVO();
		dissTaskSpecInVO.setTaskId(param.getTaskId());
		dissOneTeamVO.setDissTaskSpecInList(dissTaskSpecInDao.getDissTaskSpecInList(dissTaskSpecInVO));
		return dissOneTeamVO;
	}
	
	@Override
	public DissOneTeamVO getDissOneTeamHisInfo(DissOneTeamVO param) {


		
		DissOneTeamVO dissOneTeamVO = new DissOneTeamVO(); 
		dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(dissOneTeamDao.getDissOneTeamHisInfo(param));
		
		// KPI
		DissKpiVO dissKpiVO = new DissKpiVO();
		dissKpiVO.setStepId(param.getStepId());
		dissOneTeamVO.setDissKpiList(dissKpiDao.getDissKpiHisList(dissKpiVO));
		// 멤버
		DissMemberVO dissMemberVO = new DissMemberVO();
		dissMemberVO.setTaskId(param.getTaskId());
		dissMemberVO.setStepId(param.getStepId());
		
		List<DissMemberVO> dissMemberListaggList = dissMemberDao.getDissMemberListaggHisList(dissMemberVO); 
		dissOneTeamVO.setDissMemberListaggList(dissMemberListaggList);
		//멤버 조회(수정시 사용)
		List<DissMemberVO> dissMemberHisList = dissMemberDao.getDissMemberHisList(dissMemberVO);
		dissOneTeamVO.setDissMemberList(dissMemberHisList);
		// SPEC-IN 정보
		DissTaskSpecInVO dissTaskSpecInVO = new DissTaskSpecInVO();
		dissTaskSpecInVO.setStepId(param.getStepId());
		dissOneTeamVO.setDissTaskSpecInList(dissTaskSpecInDao.getDissTaskSpecInHisList(dissTaskSpecInVO));
		
		return dissOneTeamVO;
	}

	@Override
	public void createAfterDeleteAllKpiHis(DissOneTeamVO param) {
		//DISS KPI관리 HIS 삭제
		DissKpiVO dissKpiVO = new DissKpiVO();
		dissKpiVO.setStepId(param.getStepId());
		dissKpiDao.deleteDissKpiHisAll(dissKpiVO);
		//DISS KPI관리 HIS 등록
		if(param.getDissKpiList().size() > 0) {
			for(DissKpiVO vo : param.getDissKpiList()) {
				vo.setKpiId(Util.getUUID());
				vo.setStepId(param.getStepId());
				vo.setTaskType(param.getTaskType());
				vo.setRegiIdxx(param.getRegiIdxx());
				vo.setUpdtIdxx(param.getUpdtIdxx());
				dissKpiDao.createDissKpiHis(vo);
			}
		}
		
	}

	@Override
	public void createAfterDeleteAllMemberHis(DissOneTeamVO param) {
		//DISS 과제멤버관리 HIS 삭제
		DissMemberVO dissMemberVO = new DissMemberVO();
		dissMemberVO.setStepId(param.getStepId());
		dissMemberDao.deleteDissMemberHisAll(dissMemberVO);
		//DISS 과제멤버관리 HIS 등록
		if(param.getDissMemberList().size() > 0) {
			for(DissMemberVO vo : param.getDissMemberList()) {
				if(!vo.getMngEmpId().equals("")) {
					vo.setTaskMemberId(Util.getUUID());
					vo.setStepId(param.getStepId());
					vo.setTaskType(param.getTaskType());
					vo.setRegiIdxx(param.getRegiIdxx());
					vo.setUpdtIdxx(param.getUpdtIdxx());
					dissMemberDao.createDissMemberHis(vo);
				}
			}
		}
		
	}

	@Override
	public void createAfterDeleteAllTaskSpecinHis(DissOneTeamVO param) {
		//DISS 원팀 SPEC-IN 정보 HIS 삭제
		DissTaskSpecInVO dissTaskSpecInVO = new DissTaskSpecInVO();
		dissTaskSpecInVO.setStepId(param.getStepId());
		dissTaskSpecInDao.deleteDissTaskSpecInHisAll(dissTaskSpecInVO);
		//DISS 원팀 SPEC-IN 정보 HIS 등록
		if(param.getDissTaskSpecInList().size() > 0) {
			for(DissTaskSpecInVO vo : param.getDissTaskSpecInList()) {
				if(!vo.getSpecinId().equals("")) {
					vo.setStepId(param.getStepId());
					vo.setRegiIdxx(param.getRegiIdxx());
					vo.setUpdtIdxx(param.getUpdtIdxx());
					dissTaskSpecInDao.createDissTaskSpecInHis(vo);
				}
			}
		}
	}
	
	@Override
	public void saveDissOneTeamApprovalAction(DissApprCommonParamVO dissApprCommonParamVO) {
		// 결재 액션 파라미터 셋팅
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(dissApprCommonParamVO.getApprId());                     // 품의서ID
		apprLineVO.setApprEmpId(dissApprCommonParamVO.getApprEmpId());              // 결재자사번
		apprLineVO.setApprLineComment(dissApprCommonParamVO.getApprLineComment());  // 결재자의견
		apprLineVO.setApplStat(dissApprCommonParamVO.getApplStat());                 // 결재자 결재결과
		apprLineVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());

		// 마지막 결재자 결재 완료 이면 후처리 작업
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(dissApprCommonParamVO.getApprId());
		if(dissCommonApprMgmtService.checkListApplActYn(apprVO,dissApprCommonParamVO.getApprEmpId())
				&& ApplState.APPL_APPROVE.getCode().equals(dissApprCommonParamVO.getApplStat())
		){
			logger.debug("결재완료 후처리");
			logger.debug(dissApprCommonParamVO.toString());

			if(dissApprCommonParamVO.getApprType().equals("401")) {			//등록
				DissOneTeamVO dissOneTeamVOParam = new DissOneTeamVO();
				dissOneTeamVOParam.setStepId(dissApprCommonParamVO.getStepId());
				dissOneTeamVOParam.setTaskId(dissApprCommonParamVO.getTaskId());

				DissOneTeamVO dissOneTeamVOHis = getDissOneTeamHisInfo(dissOneTeamVOParam);

				// OneTeam 히스토리 내역으로 원본테이블 업데이트
				dissOneTeamVOHis.setTaskId(dissOneTeamVOParam.getTaskId());
				dissOneTeamVOHis.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());
				dissOneTeamDao.updateDissOneTeam(dissOneTeamVOHis);
				// Kpi 히스토리 내역으로 원본테이블 업데이트
				DissKpiVO dissKpiVO = new DissKpiVO();
				dissKpiVO.setTaskId(dissOneTeamVOParam.getTaskId());
				dissKpiDao.deleteDissKpiAll(dissKpiVO);
				for(DissKpiVO tmpDissKpiVO : dissOneTeamVOHis.getDissKpiList()){
					tmpDissKpiVO.setKpiId(Util.getUUID());
					tmpDissKpiVO.setTaskId(dissOneTeamVOHis.getTaskId());
					dissKpiDao.createDissKpi(tmpDissKpiVO);
				}
				
				// Member 히스토리 내역으로 원본테이블 업데이트
				DissMemberVO dissMemberVO = new DissMemberVO();
				dissMemberVO.setTaskId(dissOneTeamVOParam.getTaskId());
				dissMemberDao.deleteDissMemberAll(dissMemberVO);
				for(DissMemberVO tmpDissMemberVO : dissOneTeamVOHis.getDissMemberList()){
					tmpDissMemberVO.setTaskMemberId(Util.getUUID());
					tmpDissMemberVO.setTaskId(dissOneTeamVOHis.getTaskId());
					tmpDissMemberVO.setTaskType(dissOneTeamVOHis.getTaskType());
					dissMemberDao.createDissMember(tmpDissMemberVO);
				}
				// TaskSpecIn 히스토리 내역으로 원본테이블 업데이트
				DissTaskSpecInVO dissTaskSpecInVO = new DissTaskSpecInVO();
				dissTaskSpecInVO.setTaskId(dissOneTeamVOParam.getTaskId());
				dissTaskSpecInDao.deleteDissTaskSpecInAll(dissTaskSpecInVO);
				for(DissTaskSpecInVO tmpDissTaskSpecInVO : dissOneTeamVOHis.getDissTaskSpecInList()){
					tmpDissTaskSpecInVO.setTaskId(dissOneTeamVOHis.getTaskId());
					dissTaskSpecInDao.createDissTaskSpecIn(tmpDissTaskSpecInVO);
				}
			} else if(dissApprCommonParamVO.getApprType().equals("420")) {			//완료
				
				DissOneTeamVO dissOneTeamVOParam = new DissOneTeamVO();
				dissOneTeamVOParam.setStepId(dissApprCommonParamVO.getStepId());
				dissOneTeamVOParam.setTaskId(dissApprCommonParamVO.getTaskId());

				DissOneTeamVO dissOneTeamVOHis = getDissOneTeamHisInfo(dissOneTeamVOParam);
				// OneTeam 히스토리 내역으로 원본테이블 업데이트
				dissOneTeamVOHis.setTaskId(dissOneTeamVOParam.getTaskId());
				dissOneTeamVOHis.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());
				dissOneTeamVOHis.setCompYmd(Util.getToday()); //과제완료일
				dissOneTeamDao.updateDissOneTeam(dissOneTeamVOHis);
			}

		}
		//logger.debug("apprLineVO : "+apprLineVO.toString());
		// DISS 공통 품의서 결재 호출
		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);
		
	}

	@Override
	public List<DissTaskSpecInVO> getSpecInListWithTotalSaleGoal(DissTaskSpecInVO param) {
		return dissTaskSpecInDao.getSpecInListWithTotalSaleGoal(param);
	}

	@Override
	public int getSpecInListWithTotalSaleGoalCnt(DissTaskSpecInVO param) {
		return dissTaskSpecInDao.getSpecInListWithTotalSaleGoalCnt(param);
	}
	
	@Override
	public String updateOneTeamDtl(DissOneTeamVO param) {
		
		//품의서 ID 생성
		String apprId = Util.getUUID();
		param.getApprVO().setApprId(apprId);
		
		//원팀과제 HIS 생성
		String stepId = Util.getUUID();
		param.setStepId(stepId);
		dissOneTeamDao.createDissOneTeamHis(param);
		
		// LAST_STEP_YN : Y->N
		DissStepVO lastStepVO = new DissStepVO();
		lastStepVO.setTaskId(param.getTaskId());
		lastStepVO.setStepCd(param.getStepCd());
		dissStepDao.updateDissStepLastYn(lastStepVO);
		
		//원팀과제 수정 STEP 생성
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(stepId);
		dissStepVO.setTaskId(param.getTaskId());
		dissStepVO.setTaskType(param.getTaskType());
		dissStepVO.setStepCd(param.getStepCd()); // 원팀과제 수정 DISS_STEP_CD
		dissStepVO.setApprId(apprId);
		dissStepVO.setStepLastYn("Y");
		dissStepVO.setRegiIdxx(param.getRegiIdxx());
		dissStepVO.setUpdtIdxx(param.getUpdtIdxx());
		dissStepDao.createDissStep(dissStepVO);
		
		//KPI, 멤버, 스펙인정보 HIS 삭제 후 생성
		createAfterDeleteAllMemberHis(param);
		createAfterDeleteAllKpiHis(param);
		createAfterDeleteAllTaskSpecinHis(param);

		//원팀과제 마스터 업데이트/////////////////////////////////////////////////////////////
		
		DissOneTeamVO dissOneTeamVOParam = new DissOneTeamVO();
		dissOneTeamVOParam.setStepId(param.getStepId());
		dissOneTeamVOParam.setTaskId(param.getTaskId());

		DissOneTeamVO dissOneTeamVOHis = getDissOneTeamHisInfo(dissOneTeamVOParam);

		// OneTeam 히스토리 내역으로 원본테이블 업데이트
		dissOneTeamVOHis.setTaskId(param.getTaskId());
		dissOneTeamVOHis.setUpdtIdxx(param.getUpdtIdxx());
		dissOneTeamDao.updateDissOneTeam(dissOneTeamVOHis);

		// Member 히스토리 내역으로 원본테이블 업데이트
		DissMemberVO dissMemberVO = new DissMemberVO();
		dissMemberVO.setTaskId(dissOneTeamVOParam.getTaskId());
		dissMemberDao.deleteDissMemberAll(dissMemberVO);
		for(DissMemberVO tmpDissMemberVO : dissOneTeamVOHis.getDissMemberList()){
			tmpDissMemberVO.setTaskMemberId(Util.getUUID());
			tmpDissMemberVO.setTaskId(dissOneTeamVOHis.getTaskId());
			tmpDissMemberVO.setTaskType(dissOneTeamVOHis.getTaskType());
			dissMemberDao.createDissMember(tmpDissMemberVO);
		}
		// Kpi 히스토리 내역으로 원본테이블 업데이트
		DissKpiVO dissKpiVO = new DissKpiVO();
		dissKpiVO.setTaskId(dissOneTeamVOParam.getTaskId());
		dissKpiDao.deleteDissKpiAll(dissKpiVO);
		for(DissKpiVO tmpDissKpiVO : dissOneTeamVOHis.getDissKpiList()){
			tmpDissKpiVO.setKpiId(Util.getUUID());
			tmpDissKpiVO.setTaskId(dissOneTeamVOHis.getTaskId());
			dissKpiDao.createDissKpi(tmpDissKpiVO);
		}
		// TaskSpecIn 히스토리 내역으로 원본테이블 업데이트
		DissTaskSpecInVO dissTaskSpecInVO = new DissTaskSpecInVO();
		dissTaskSpecInVO.setTaskId(dissOneTeamVOParam.getTaskId());
		dissTaskSpecInDao.deleteDissTaskSpecInAll(dissTaskSpecInVO);
		for(DissTaskSpecInVO tmpDissTaskSpecInVO : dissOneTeamVOHis.getDissTaskSpecInList()){
			tmpDissTaskSpecInVO.setTaskId(dissOneTeamVOHis.getTaskId());
			dissTaskSpecInDao.createDissTaskSpecIn(tmpDissTaskSpecInVO);
		}
	
		//원팀과제 마스터 업데이트 end/////////////////////////////////////////////////////////////
		
		//공통품의
		String apprStat = ApprState.APPR_PROCEEDING.getCode();
		ApprVO apprVO = param.getApprVO();
		apprVO.setApprStat(apprStat);
		apprVO.setRegiIdxx(param.getRegiIdxx());
		apprVO.setUpdtIdxx(param.getUpdtIdxx());
		dissCommonApprMgmtService.saveDissCommonAppr(apprVO,apprStat, false);

		return param.getStepId();
	}
	
	@Override
	public int getDissOneTeamMinutesListCount(DissOneTeamMinutesVO param) {
		return dissOneTeamMinutesDao.getDissOneTeamMinutesListCount(param);
	}

	@Override
	public List<DissOneTeamMinutesVO> getDissOneTeamMinutesList(DissOneTeamMinutesVO param) {
		return dissOneTeamMinutesDao.getDissOneTeamMinutesList(param);
	}

	@Override
	public void saveDissOneTeamMinutes(DissOneTeamMinutesVO param) {
		
		// 신규등록 or 반려건 재작성
		if("".equals(param.getApprVO().getApprId())
				|| param.getApprVO().getApprStat().equals("4010") || param.getApprVO().getApprStat().equals("4020")
		){
			String apprId = Util.getUUID();
			param.setApprId(apprId);
			param.getApprVO().setApprId(apprId);
			dissOneTeamMinutesDao.createDissOneTeamMinutes(param);
		} else {
			param.setApprId(param.getApprVO().getApprId());
			dissOneTeamMinutesDao.updateDissOneTeamMinutes(param);
		}

		//공통품의
		String saveType = param.getApprVO().getSaveType();
		String apprStat = "";
		switch(saveType) {
			case "TEMP" : apprStat = ApprState.TEMP_SAVE.getCode();
				break;
			case "SAVE" : apprStat = ApprState.APPR_PROCEEDING.getCode();
				break;
			case "REAPPR" : apprStat = ApprState.TEMP_SAVE.getCode();
				break;
		}
		String apprType = ApprType.APPR_TYPE_DISS_ONETEAM_REPORT.getCode();
		ApprVO apprVO = param.getApprVO();
		apprVO.setApprStat(apprStat);
		apprVO.setApprType(apprType);
		apprVO.setUpdtIdxx(param.getUpdtIdxx());
		apprVO.setRegiIdxx(param.getRegiIdxx());
		// 업무테이블 품의서 기초내용 작성 호출  kjy
		String templeteFormContent = param.getApprVO().getFormCont();
		param.getApprVO().setTempleteFormContent(getApprFormContOneTeamMinutes(param, templeteFormContent));
		dissCommonApprMgmtService.saveDissCommonAppr(apprVO,apprStat, false);
	}

	@Override
	public DissOneTeamMinutesVO getDissOneTeamMinutesDetail(DissOneTeamMinutesVO param) {
		return dissOneTeamMinutesDao.getDissOneTeamMinutesDetail(param);
	}
	
	@Override
	public void saveDissOneTeamMinutesApprovalAction(DissApprCommonParamVO dissApprCommonParamVO) {
		// 결재 액션 파라미터 셋팅
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(dissApprCommonParamVO.getApprId());                     // 품의서ID
		apprLineVO.setApprEmpId(dissApprCommonParamVO.getApprEmpId());              // 결재자사번
		apprLineVO.setApprLineComment(dissApprCommonParamVO.getApprLineComment());  // 결재자의견
		apprLineVO.setApplStat(dissApprCommonParamVO.getApplStat());                 // 결재자 결재결과
		apprLineVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());

		// DISS 공통 품의서 결재 호출
		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);
		
	}

	@Override
	public void saveDissOneTeamCompleteAppr(DissOneTeamVO param) {
		// 최초등록 or 반려건 재작성
		if("".equals(param.getStepId())
		  || param.getApprVO().getApprStat().equals("4010") || param.getApprVO().getApprStat().equals("4020")
		){ 

			//품의서 ID 생성
			String apprId = Util.getUUID();
			param.getApprVO().setApprId(apprId);
			param.getApprVO().setRegiIdxx(param.getRegiIdxx());
			
			// LAST_STEP_YN : Y->N
			DissStepVO lastStepVO = new DissStepVO();
			lastStepVO.setTaskId(param.getTaskId());
			lastStepVO.setStepCd(param.getStepCd());
			dissStepDao.updateDissStepLastYn(lastStepVO);
			
			//원팀과제 HIS 생성
			String stepId = Util.getUUID();
			param.setStepId(stepId);
			dissOneTeamDao.createDissOneTeamHis(param);
			
			//원팀과제완료 STEP 생성
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setStepId(stepId);
			dissStepVO.setTaskId(param.getTaskId());
			dissStepVO.setTaskType(param.getTaskType());
			dissStepVO.setStepCd(param.getStepCd()); // 원팀과제완료 DISS_STEP_CD
			dissStepVO.setApprId(apprId);
			dissStepVO.setStepLastYn("Y");
			dissStepVO.setRegiIdxx(param.getRegiIdxx());
			dissStepVO.setUpdtIdxx(param.getUpdtIdxx());
			dissStepDao.createDissStep(dissStepVO);
			
			//KPI, 멤버, 스펙인정보 HIS 삭제 후 생성
			createAfterDeleteAllMemberHis(param);
			createAfterDeleteAllKpiHis(param);
			createAfterDeleteAllTaskSpecinHis(param);
		} else {
			//원팀과제 HIS 수정
			dissOneTeamDao.updateDissOneTeamHis(param);
		}
		
		//공통품의
		String saveType = param.getApprVO().getSaveType();
		String apprStat = "";
		switch(saveType) {
			case "TEMP" : apprStat = ApprState.TEMP_SAVE.getCode();
				break;
			case "SAVE" : apprStat = ApprState.APPR_PROCEEDING.getCode();
				break;
			case "REAPPR" : apprStat = ApprState.TEMP_SAVE.getCode();
				break;
		}
		String apprType = ApprType.APPR_TYPE_DISS_ONETEAM_COMPLETE.getCode();
		ApprVO apprVO = param.getApprVO();
		apprVO.setApprType(apprType);
		apprVO.setApprStat(apprStat);
		apprVO.setRegiIdxx(param.getRegiIdxx());
		apprVO.setUpdtIdxx(param.getUpdtIdxx());
		//내용만들고 같이 보내기.
		String templeteFormContent = param.getApprVO().getFormCont();
		param.getApprVO().setTempleteFormContent(getApprFormContOneTeam(param, templeteFormContent));
		dissCommonApprMgmtService.saveDissCommonAppr(apprVO,apprStat, false);
	}

	@Override
	public void deleteDissOneTeamAppr(DissApprCommonParamVO param) {
		//품의서 삭제
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(param.getApprId());
		ApprVO checkApprVO = commonApprDao.getAppr(apprVO);
		if(!checkApprVO.getRegiIdxx().equals(param.getUpdtIdxx())){
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
		}
		dissCommonApprMgmtService.deleteDissAppr(apprVO);
		
		DissOneTeamVO dissOneTeamParamVO = new DissOneTeamVO();
		dissOneTeamParamVO.setTaskId(param.getTaskId());
		dissOneTeamParamVO.setStepId(param.getStepId());
		
		//원팀 History
		DissOneTeamVO dissOneTeamHisVO = getDissOneTeamHisInfo(dissOneTeamParamVO);
		
		//KPI History 삭제
  		if(dissOneTeamHisVO.getDissKpiList().size() > 0) {
			DissKpiVO dissKpiVO = new DissKpiVO();
			dissKpiVO.setStepId(dissOneTeamParamVO.getStepId());
			dissKpiDao.deleteDissKpiHisAll(dissKpiVO);
		}
		
		//Member History 삭제
		if(dissOneTeamHisVO.getDissMemberList().size() > 0) {
			DissMemberVO dissMemberVO = new DissMemberVO();
			dissMemberVO.setStepId(dissOneTeamParamVO.getStepId());
			dissMemberDao.deleteDissMemberHisAll(dissMemberVO);
		}
		
		//SPEC-IN 정보 History 삭제
		if(dissOneTeamHisVO.getDissTaskSpecInList().size() > 0) {
			DissTaskSpecInVO dissTaskSpecInVO = new DissTaskSpecInVO();
			dissTaskSpecInVO.setStepId(dissOneTeamParamVO.getStepId());
			dissTaskSpecInDao.deleteDissTaskSpecInHisAll(dissTaskSpecInVO);
		}
		//원팀 History 삭제
		dissOneTeamDao.deleteDissOneTeamHisAll(dissOneTeamParamVO);
		
		//Step 삭제
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setTaskId(param.getTaskId());
		dissStepVO.setStepId(param.getStepId());
		dissStepVO.setStepCd(param.getStepCd());
		dissStepDao.deleteDissStep(dissStepVO);
		//마지막 스텝의 LAST_STEP_YN을 N->Y 변경
		dissStepDao.updateStepLastYnYByStepCd(dissStepVO);
		
		//등록품의일 경우 
		if(param.getApprType().equals("401")) {
			// 해당 과제ID로 등록된 스텝이 1개 미만이면(반려건 재작성이 아닌 최초등록이면)
			DissStepVO regiStepVO = new DissStepVO();
			regiStepVO.setTaskId(param.getTaskId());
			regiStepVO.setUpdtIdxx(param.getUpdtIdxx());
			List<DissStepVO> regiStepList = dissStepDao.getDissStepRegiList(regiStepVO);
			if(regiStepList.size() < 1) {
				
				//원팀 마스터
				
				DissOneTeamVO dissOneTeamMasterVO = getDissOneTeamMasterInfo(dissOneTeamParamVO);
				
				//KPI 삭제
				if(dissOneTeamMasterVO.getDissKpiList().size() > 0) {
					DissKpiVO dissKpiVO = new DissKpiVO();
					dissKpiVO.setTaskId(dissOneTeamParamVO.getTaskId());
					dissKpiDao.deleteDissKpiAll(dissKpiVO);
				}
				
				//Member 삭제
				if(dissOneTeamMasterVO.getDissMemberList().size() > 0) {
					DissMemberVO dissMemberVO = new DissMemberVO();
					dissMemberVO.setTaskId(dissOneTeamParamVO.getTaskId());
					dissMemberDao.deleteDissMemberAll(dissMemberVO);
				}
				
				//SPEC-IN 정보 삭제
				if(dissOneTeamMasterVO.getDissTaskSpecInList().size() > 0) {
					DissTaskSpecInVO dissTaskSpecInVO = new DissTaskSpecInVO();
					dissTaskSpecInVO.setTaskId(dissOneTeamParamVO.getTaskId());
					dissTaskSpecInDao.deleteDissTaskSpecInAll(dissTaskSpecInVO);
				}
				//원팀 삭제
				dissOneTeamDao.deleteDissOneTeamAll(dissOneTeamParamVO);
			}
		}
		
	}

	@Override
	public void deleteDissOneTeamMinutesAppr(DissApprCommonParamVO param) {
		//품의정보 삭제
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(param.getApprId());
		ApprVO checkApprVO = commonApprDao.getAppr(apprVO);
		if(!checkApprVO.getRegiIdxx().equals(param.getUpdtIdxx())){
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
		}
		dissCommonApprMgmtService.deleteDissAppr(apprVO);
		
		//회의록 삭제
		DissOneTeamMinutesVO dissOneTeamMinutesVO = new DissOneTeamMinutesVO();
		dissOneTeamMinutesVO.setTaskId(param.getTaskId());
		dissOneTeamMinutesVO.setApprId(param.getApprId());
		dissOneTeamMinutesDao.deleteDissOneTeamMinutes(dissOneTeamMinutesVO);
	}
	
	/*sorting*/
	public static Comparator<DissStepVO> sortStep = new Comparator<DissStepVO>() {
		
		@Override
		public int compare(DissStepVO o1, DissStepVO o2) {
			int data1 =  o1.getOrderNo();
			int data2 = o2.getOrderNo();
			return Double.compare(data2, data1);
		}
	};

	@Override
	public List<DissStepVO> getDissOneTeamStepList(DissStepVO param) {
		List<DissStepVO> stepRegiList = dissStepDao.getDissStepRegiList(param);
		Collections.sort(stepRegiList, sortStep);
		return stepRegiList;
	}
	
	@Override
	public List<EmployVO> loadEmployList(Map<String, String> param) {
		return dissOneTeamDao.loadEmployList(param);
	}
	
	/**
	 * DISS 원팀과제등록 / 원팀과제완료
	 *
	 * @param DissOneTeamVO	 
	 * @return
	 */
	@Override
	public String getApprFormContOneTeam(DissOneTeamVO param, String templeteFormContent) {
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();		
		
		String template = REPORT_TEMPLATE_DISS_PUBLIC_ONE_TEAM;  
		param.setApprType(ApprType.APPR_TYPE_DISS_ONETEAM_REG.getCode());
		DissOneTeamVO dissOneTeamVO = (DissOneTeamVO) StringUtil.nullToEmptyString(getDissOneTeamInfo(param));
		//제품군, 제품상세 따로 가지고 옴.
		DissOneTeamVO dissOneTeamTxt = (DissOneTeamVO) StringUtil.nullToEmptyString(dissOneTeamDao.getProdTypeTxt(param));
		dissOneTeamVO.setProdTypeTxt(dissOneTeamTxt.getProdTypeTxt());
		dissOneTeamVO.setProdTypeDTxt(dissOneTeamTxt.getProdTypeDTxt());
		
		map.put("dissOneTeamVO", dissOneTeamVO);		
		map.put("templeteFormContent", templeteFormContent);		
		
		//sub list 처리
		List<DissKpiVO>        dissKpiList           = new ArrayList<DissKpiVO>();
		List<DissMemberVO>     dissMemberListaggList = new ArrayList<DissMemberVO>();
		List<DissTaskSpecInVO> dissTaskSpecInList    = new ArrayList<DissTaskSpecInVO>();
		
		for(DissKpiVO impDev : dissOneTeamVO.getDissKpiList()) {			
			dissKpiList.add((DissKpiVO)StringUtil.nullToEmptyString(impDev));
		}
		map.put("dissKpiList", dissKpiList);
		
		for(DissMemberVO impDev : dissOneTeamVO.getDissMemberListaggList()) {			
			dissMemberListaggList.add((DissMemberVO)StringUtil.nullToEmptyString(impDev));
		}

		//원팀멤버
		for(int i=0; i<dissMemberListaggList.size(); i++) {
			if(dissMemberListaggList.get(i).getMemberType().equals("SP")) {
				map.put("spName", dissMemberListaggList.get(i).getMngEmpNmListagg());
				map.put("spRole", dissMemberListaggList.get(i).getMngMemberRoleListagg());
			} else if(dissMemberListaggList.get(i).getMemberType().equals("QA")) {
				map.put("qaName", dissMemberListaggList.get(i).getMngEmpNmListagg());
				map.put("qaRole", dissMemberListaggList.get(i).getMngMemberRoleListagg());
			} else if(dissMemberListaggList.get(i).getMemberType().equals("TT")) {
				map.put("ttName", dissMemberListaggList.get(i).getMngEmpNmListagg());
				map.put("ttRole", dissMemberListaggList.get(i).getMngMemberRoleListagg());
			} else if(dissMemberListaggList.get(i).getMemberType().equals("TC")) {
				map.put("tcName", dissMemberListaggList.get(i).getMngEmpNmListagg());
				map.put("tcRole", dissMemberListaggList.get(i).getMngMemberRoleListagg());
			} else if(dissMemberListaggList.get(i).getMemberType().equals("TP")) {
				map.put("tpName", dissMemberListaggList.get(i).getMngEmpNmListagg());
				map.put("tpRole", dissMemberListaggList.get(i).getMngMemberRoleListagg());
			} else if(dissMemberListaggList.get(i).getMemberType().equals("RND")) {
				map.put("rndName", dissMemberListaggList.get(i).getMngEmpNmListagg());
				map.put("rndRole", dissMemberListaggList.get(i).getMngMemberRoleListagg());
			} else if(dissMemberListaggList.get(i).getMemberType().equals("ETC")) {
				map.put("etcName", dissMemberListaggList.get(i).getMngEmpNmListagg());
				map.put("etcRole", dissMemberListaggList.get(i).getMngMemberRoleListagg());
			} else if(dissMemberListaggList.get(i).getMemberType().equals("PRO")) {
				map.put("proName", dissMemberListaggList.get(i).getMngEmpNmListagg());
				map.put("proRole", dissMemberListaggList.get(i).getMngMemberRoleListagg());
			} else if(dissMemberListaggList.get(i).getMemberType().equals("CP")) {
				map.put("cpName", dissMemberListaggList.get(i).getMngEmpNmListagg());
				map.put("cpRole", dissMemberListaggList.get(i).getMngMemberRoleListagg());
			}
		}
		
		for(DissTaskSpecInVO impDev : dissOneTeamVO.getDissTaskSpecInList()) {			
			dissTaskSpecInList.add((DissTaskSpecInVO)StringUtil.nullToEmptyString(impDev));
		}
		map.put("dissTaskSpecInList", dissTaskSpecInList);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getApprVO().getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);		
		
		map.put("fileVoList", fileVoList);
				
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}
	
	@Override
	public String getApprFormContOneTeamMinutes(DissOneTeamMinutesVO param, String templeteFormContent) {
		
		StringBuffer content = new StringBuffer();
		Map< String, Object> map = new HashMap< String, Object>();		
		String template = null;			
		
		template = REPORT_TEMPLATE_DISS_PUBLIC_ONE_TEAM_MIN;  
		
		// OneTeamMinutes 정보		
		DissOneTeamMinutesVO dissOneTeamMinutesVO = (DissOneTeamMinutesVO) StringUtil.nullToEmptyString(getDissOneTeamMinutesDetail(param));		
				
		map.put("dissOneTeamMinutesVO", dissOneTeamMinutesVO);		
		map.put("templeteFormContent", templeteFormContent);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getApprVO().getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);		
		
		map.put("fileVoList", fileVoList);
				
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}


}
 