package com.lgmma.salesPortal.config.viewresolver;
import java.io.ByteArrayOutputStream;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.AbstractView;

import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
 
public abstract class AbstractITextPdfView extends AbstractView {
 
	public AbstractITextPdfView() {
	    setContentType("application/pdf");
	}
 
	@Override
	protected boolean generatesDownloadContent() {
	    return true;
	}
	 
	@Override
	protected final void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception  {
	 
		ByteArrayOutputStream out = createTemporaryOutputStream();
		PdfWriter writer = new PdfWriter(out);
//		PdfDocument pdfDoc = new PdfDocument(writer);
        //Set the result to be tagged
//        pdfDoc.setTagged();
//        pdfDoc.setDefaultPageSize(PageSize.A4);
	    buildPdfDocument(model, writer, request, response);
//	    pdfDoc.close();
	}
/*	 
	protected void prepareWriter(Map<String, Object> model, PdfWriter writer, HttpServletRequest request) throws DocumentException {
	    writer.setViewerPreferences(getViewerPreferences());
	}
	 
	protected int getViewerPreferences() {
	    return PdfWriter.ALLOW_PRINTING | PdfWriter.PageLayoutSinglePage;
	}
	 
	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
	}
*/	 
	 
	 
	protected abstract void buildPdfDocument(Map<String, Object> model, PdfWriter writer,
	                                         HttpServletRequest request, HttpServletResponse response) throws Exception;
}

