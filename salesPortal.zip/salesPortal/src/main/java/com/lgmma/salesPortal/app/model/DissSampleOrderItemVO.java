package com.lgmma.salesPortal.app.model;

public class DissSampleOrderItemVO extends DirectOrderItemVO {
}
