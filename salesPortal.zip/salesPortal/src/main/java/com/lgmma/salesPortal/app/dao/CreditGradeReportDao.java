package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.CompDamboVO;
import com.lgmma.salesPortal.app.model.CreditGradeReportVO;

public interface CreditGradeReportDao {

	int getCreditGradeReportListCount(CreditGradeReportVO param);
	
	List<CreditGradeReportVO> getCreditGradeReportList(CreditGradeReportVO param);
	
	int getDamboInfoListCount(CompDamboVO param);
	
	List<CompDamboVO> getDamboInfoList(CompDamboVO param);

}
