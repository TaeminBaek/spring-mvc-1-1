package com.lgmma.salesPortal.app.controller;

import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.FilePath;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;
import com.lgmma.salesPortal.security.authentication.UserInfo;
import com.namo.crossuploader.CrossUploaderException;
import com.namo.crossuploader.FileDownload;
import com.namo.crossuploader.FileItem;
import com.namo.crossuploader.FileUpload;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;


@Controller
public class CommonFileController {

	private static Logger logger = LoggerFactory.getLogger(CommonFileController.class);
	private static String[] fileWhiteList = {
			"hwp"
			, "mdi"
			, "pptx"
			, "docx"
			, "eml"
			, "zip"
			, "xps"
			, "alz"
			, "tiff"
			, "xls"
			, "xlsx"
			, "bmp"
			, "xls"
			, "png"
			, "tif"
			, "jpg"
			, "txt"
			, "mht"
			, "gif"
			, "jpeg"
			, "doc"
			, "ppt"
			, "pdf"
			, "ppsx"
	};
	@Autowired
	private MessageSourceAccessor messageSourceAccessor;

	@Autowired
	private CommonFileService commonFileService;

	/**
	 * 공통 namo 다운로더로 파일다운로드 처리
	 *
	 * @param req
	 * @param res
	 * @throws Exception
	 */
	@RequestMapping(value = "/common/crFileDownloadProcess")
	public void fileDownloadProcess(HttpServletRequest req
			, HttpServletResponse res
	) throws Exception {
		FileDownload fileDownload = new FileDownload(req, res);

		try {
			String downloadFormData = req.getParameter("CD_DOWNLOAD_FILE_INFO");

			if (downloadFormData == null) throw new Exception("다운로드 중 예외가 발생했습니다.");

			// 로그인 확인
			try{
				UserInfo userInfo = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo();
				if(userInfo == null || "".equals(StringUtil.nullConvert(userInfo.getSawnIdxx()))){
					throw new Exception("로그인이 필요합니다.");
				}
			}catch (Exception e) {
				throw new Exception("로그인이 필요합니다.");
			}

			//참고소스 : 파일정보 받기
			//JSONObject jsonObject = (JSONObject)downloadFileInfoArray.get(i); 
			//(String)jsonObject.get("fileId");
			//(String)jsonObject.get("fileName"); // 필요할 경우 사용합니다.
			//(String)jsonObject.get("fileSize"); // 필요할 경우 사용합니다.  
			//(String)jsonObject.get("fileUrl");  // 각 파일의 URL이 다르거나 SingleFileDownload일 때 사용됩니다

			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObject = (JSONObject) jsonParser.parse(downloadFormData);
			FileVO paramFileVO = new FileVO();
			paramFileVO.setFileItemId((String) jsonObject.get("fileId"));
			FileVO fileVO = commonFileService.getFileDetail(paramFileVO);

			String oriFilePath = messageSourceAccessor.getMessage(FilePath.getFilePath(fileVO.getFilePathCd()).getFilePathProp(), "");
			String fileNameAlias = fileVO.getFileNmAlias();

			fileNameAlias = fileVO.getFileNmAlias();
			oriFilePath += (File.separator + fileVO.getFileNm());

			// fileNameAlias는 웹서버 환경에 따라 적절히 인코딩 되어야 합니다.
			fileNameAlias = URLEncoder.encode(fileNameAlias, "UTF-8");
			logger.debug("##################################filePath[" + oriFilePath + "]");
			logger.debug("##################################fileNameAlias[" + fileNameAlias + "]");
			// attachment 옵션에 따라 파일 종류에 관계 없이 항상 파일 저장 대화상자를 출력할 수 있습니다. 
			boolean attachment = true;

			// resumable 옵션에 따라 파일 이어받기가 가능합니다.
			// 클라이언트에서 이어받기 요청이 있어야 하며, 이어받기 요청이 없을 경우 일반 다운로드와 동일하게 동작합니다.
			boolean resumable = false;
			// filePath에 지정된 파일을 fileNameAlias 이름으로 다운로드 합니다. 
			fileDownload.startDownload(oriFilePath, fileNameAlias, attachment, resumable);

			// 참고소스 : 다른 유형의 다운로드 함수들
			//fileDownload.startDownload(String filePath); 
			//fileDownload.startDownload(String filePath, boolean attachment); 
			//fileDownload.startDownload(String filePath, boolean attachment, boolean resumable); 
			//fileDownload.startDownload(String filePath, String fileNameAlias); 
			//fileDownload.startDownload(String filePath, String fileNameAlias, boolean attachment);
			//fileDownload.startStreamDownload(InputStream inputStream,  fileNameAlias, long fileSize,  attachment);
		} catch (CrossUploaderException ex) {
			res.setCharacterEncoding("EUC-KR");
			res.setContentType("text/html; charset=EUC-KR");
			res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			res.getWriter().print("다운로드 중 예외 발생 : " + ex.getMessage());
			logger.error("다운로드 중 예외 발생 : " + ex.getMessage());
		} catch (FileNotFoundException ex) {
			res.setCharacterEncoding("EUC-KR");
			res.setContentType("text/html; charset=EUC-KR");
			res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			res.getWriter().print("다운로드 중 예외 발생 : " + ex.getMessage());
			logger.error("다운로드 중 예외 발생 : " + ex.getMessage());
		} catch (IOException ex) {
			res.setCharacterEncoding("EUC-KR");
			res.setContentType("text/html; charset=EUC-KR");
			res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			res.getWriter().print("다운로드 중 예외 발생 : " + ex.getMessage());
			logger.error("다운로드 중 예외 발생 : " + ex.getMessage());
		} catch (Exception ex) {
			res.setCharacterEncoding("EUC-KR");
			res.setContentType("text/html; charset=EUC-KR");
			res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			res.getWriter().print("다운로드 중 예외 발생 : " + ex.getMessage());
			logger.error("다운로드 중 예외 발생 : " + ex.getMessage());
		}
	}

	/**
	 * 개별 파일 다운로드 처리 namo 다운로더로 파일다운로드 처리
	 *
	 * @param req
	 * @param res
	 * @throws Exception
	 */
	@RequestMapping(value = "/common/crFileDownload")
	public void crFileDownload(HttpServletRequest req
			, HttpServletResponse res
	) throws Exception {
		FileDownload fileDownload = new FileDownload(req, res);
		FileVO paramFileVO = new FileVO();
		paramFileVO.setFileItemId(req.getParameter("fileItemId"));
		FileVO fileVO = commonFileService.getFileDetail(paramFileVO);

		String oriFilePath = messageSourceAccessor.getMessage(FilePath.getFilePath(fileVO.getFilePathCd()).getFilePathProp(), "");
		String fileNameAlias = fileVO.getFileNmAlias();

		fileNameAlias = fileVO.getFileNmAlias();
		oriFilePath += (File.separator + fileVO.getFileNm());

		// fileNameAlias는 웹서버 환경에 따라 적절히 인코딩 되어야 합니다.
		fileNameAlias = URLEncoder.encode(fileNameAlias, "UTF-8");
		logger.debug("##################################filePath[" + oriFilePath + "]");
		logger.debug("##################################fileNameAlias[" + fileNameAlias + "]");
		// attachment 옵션에 따라 파일 종류에 관계 없이 항상 파일 저장 대화상자를 출력할 수 있습니다. 
		boolean attachment = true;

		// resumable 옵션에 따라 파일 이어받기가 가능합니다.
		// 클라이언트에서 이어받기 요청이 있어야 하며, 이어받기 요청이 없을 경우 일반 다운로드와 동일하게 동작합니다.
		boolean resumable = false;
		// filePath에 지정된 파일을 fileNameAlias 이름으로 다운로드 합니다. 
		fileDownload.startDownload(oriFilePath, fileNameAlias, attachment, resumable);
	}


	/**
	 * 품의서 보고서 TEMPLATE 다운 컨트롤
	 *
	 * @param req
	 * @param res
	 * @throws Exception
	 */
	@RequestMapping(value = "/common/crFileDownloadFileName")
	public void crFileDownloadName(HttpServletRequest req
			, HttpServletResponse res
	) throws Exception {
		FileDownload fileDownload = new FileDownload(req, res);
		String fileName = req.getParameter("fileName");
		String oriFilePath = messageSourceAccessor.getMessage(FilePath.FILE_PATH_TEMPLATE.getFilePathProp(), "");

		String fileNameAlias = "";
		if ("TEMPLATE_301".equals(fileName)) {
			fileNameAlias = "보고서양식_소재개발제안서.pptx";
		}
		if ("TEMPLATE_303".equals(fileName)) {
			fileNameAlias = "보고서양식_소재개발결과보고서.pptx";
		}
		if ("TEMPLATE_304".equals(fileName)) {
			fileNameAlias = "보고서양식_TS견본검증결과보고서.pptx";
		}
		if ("TEMPLATE_503".equals(fileName)) {
			fileNameAlias = "보고서양식_양산이관보고서.pptx";
		}
		if ("TEMPLATE_504".equals(fileName)) {
			fileNameAlias = "보고서양식_초도양산결과보고서.pptx";
		}

		oriFilePath += (File.separator + fileName + ".pptx");

		// fileNameAlias는 웹서버 환경에 따라 적절히 인코딩 되어야 합니다.
		fileNameAlias = URLEncoder.encode(fileNameAlias, "UTF-8");
		logger.debug("##################################filePath[" + oriFilePath + "]");
		logger.debug("##################################fileNameAlias[" + fileNameAlias + "]");
		// attachment 옵션에 따라 파일 종류에 관계 없이 항상 파일 저장 대화상자를 출력할 수 있습니다.
		boolean attachment = true;

		// resumable 옵션에 따라 파일 이어받기가 가능합니다.
		// 클라이언트에서 이어받기 요청이 있어야 하며, 이어받기 요청이 없을 경우 일반 다운로드와 동일하게 동작합니다.
		boolean resumable = false;
		// filePath에 지정된 파일을 fileNameAlias 이름으로 다운로드 합니다.
		fileDownload.startDownload(oriFilePath, fileNameAlias, attachment, resumable);
	}


	/**
	 * 파일리스트 조회
	 * fileVO.fileId 필수
	 *
	 * @param fileVO
	 * @return
	 */
	@RequestMapping(value = "/common/crGetCommonFileList.json")
	public Map crGetCommonFileList(@RequestBody(required = false) FileVO fileVO) {
		logger.debug("#######################################FILEVO[" + fileVO.toString() + "]");
		fileVO = (FileVO) StringUtil.nullToEmptyString(fileVO);
		List<FileVO> fileList = commonFileService.getFileList(fileVO);
		return JsonResponse.asSuccess("storeData", fileList);
	}

	/**
	 * 공통 namo 다운로더로 선택 파일 삭제
	 * fileVO.fileList fileItemId 리스트
	 *
	 * @param fileVO
	 * @throws Exception
	 */
	@RequestMapping(value = "/common/crDeleteSelectedFiles.json")
	public Map crDeleteSelectedFiles(@RequestBody(required = false) FileVO fileVO) throws Exception {
		logger.debug("######################################################################################");
		fileVO = (FileVO) StringUtil.nullToEmptyString(fileVO);
		commonFileService.deleteFiles(fileVO);
		return JsonResponse.asSuccess();
	}

	/**
	 * 공통 namo 파일업로더로 파일 업로드처리
	 *
	 * @param req
	 * @param res
	 * @throws Exception
	 */
	@RequestMapping(value = "/common/crFileUploadProcess")
	public void fileUploadProcess(HttpServletRequest req
			, HttpServletResponse res
	) throws Exception {
		PrintWriter writer = res.getWriter();
		FileUpload fileUpload = new FileUpload(req, res, "UTF-8");                                                                            // 업로더 생성
		String tmpFilePath = messageSourceAccessor.getMessage(FilePath.getFilePath("TEMP").getFilePathProp(), "");                            // 임시저장위치
		String regiIdxx = ((CustomAuthenticationToken) SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getSawnCode();    // 등록자
		String fileNm = "";                // 실제 저장될 파일명
		String fileNmAlias = "";                // 사용자가 올린 원본파일명
		String fileExtension = "";                // 확장자
		String fileSize = "";                // 파일크기
		String filePathCd = "";                // 저장위치코드
		String fileId = "";                // 파일그룹ID
		String fileItemId = Util.getUUID();    // 파일ID
		String saveFilePath = "";                // 최종으로 실제 저장될 파일 위치

		try {
			// 기본셋팅
			fileUpload.setAutoMakeDirs(true);            // 상위 디렉토리까지 자동생성
			fileUpload.setMaxFileSize(1024 * 1024 * 10);    // 파일개당 제한크기 10MB
			//fileUpload.setFileFilters(fileWhiteList, false);	// 1. 파일필터리스트, 2. [false : 필터화이트리스트적용(default) / true : 필터블랙리스트적용] 
			fileUpload.setFileFilters(fileWhiteList);    // 허용파일 화이트리스트셋팅

			// saveDirPath에 지정한 경로로 파일 업로드를 시작합니다. 
			// 업로드 경로를 지정하지 않을 경우, 시스템의 임시 디렉토리로 파일 업로드를 시작합니다.
			fileUpload.startUpload(tmpFilePath);

			// getFormItem 은 startUpload 이후 호출 해야 한다.
			filePathCd = fileUpload.getFormItem("filePathCd");
			fileId = fileUpload.getFormItem("fileId");    // 화면에서 파일등록시에 없으면 미리 생성.
			logger.debug("############################################filePathCd[" + filePathCd + "]");
			logger.debug("############################################fileId[" + fileId + "]");

			// 실저장 위치 구하기
			saveFilePath = messageSourceAccessor.getMessage(FilePath.getFilePath(filePathCd).getFilePathProp(), "");

			/*
			 * 입력한 file 태그의 name을 키로 갖는 FileItem[] 객체를 리턴합니다.
			 * NamoCrossUploader Client Flex Edition의 name은 "CU_FILE" 입니다.
			 */
			FileItem fileItem = fileUpload.getFileItem("CU_FILE");

			if (fileItem != null) {
				logger.debug("##########################################################upload start");
				// FileItem 객체로 아래와 같은 정보를 가져올 수 있습니다. 추가적으로 필요한 정보가 있을 경우 JSONObject 객체에 추가해 주십시오.
				// 교환할 데이터는 JSON 타입이 아니어도 되며, Javascript에서 파싱할 적절한 형태로 조합하시면 됩니다.
				// LastSavedDirectoryPath, LastSavedFileName에는 Windwos 경로에 대한 예외처리가 되어 있습니다. 서버 환경에 맞게 적절히 수정해 주십시오.
				JSONObject jsonObject = new JSONObject();

				jsonObject.put("name", fileItem.getName());
				jsonObject.put("fileName", fileItem.getFileName());
				//jsonObject.put("lastSavedDirectoryPath", fileItem.getLastSavedDirPath().replaceAll("\\\\", "/")); 
				//jsonObject.put("lastSavedFilePath", fileItem.getLastSavedFilePath().replaceAll("\\\\", "/")); 
				jsonObject.put("lastSavedFileName", fileItem.getLastSavedFileName());
				jsonObject.put("fileSize", Long.toString(fileItem.getFileSize()));
				jsonObject.put("fileNameWithoutFileExt", fileItem.getFileNameWithoutFileExt());
				jsonObject.put("fileExtension", fileItem.getFileExtension());
				jsonObject.put("contentType", fileItem.getContentType());
				jsonObject.put("isSaved", Boolean.toString(fileItem.isSaved()));
				jsonObject.put("isEmptyFile", Boolean.toString(fileItem.isEmptyFile()));
				jsonObject.put("groupFileId", fileId);

				/* 저장(이동) 함수들
				fileItem.save();
				fileItem.save(String saveDirPath);
				fileItem.save(String saveDirPath, boolean overwrite);
				fileItem.saveAs(String saveDirPath, String fileName);
				fileItem.saveAs(String saveDirPath, String fileName, boolean overwrite); 
				*/
				fileExtension = fileItem.getFileExtension();        // 파일확장자 구하기
				fileNm = fileItemId + "." + fileExtension;            // FILEITEMID + 확장자를 실제 저장 파일명으로

				// 실제파일 최종위치 저장
				fileItem.saveAs(saveFilePath, fileNm);                // 저장처리
				fileNmAlias = fileItem.getFileName();                // 원본파일명(다운로드시 해당 명칭으로 다운로드 되도록 한다.)
				fileSize = Long.toString(fileItem.getFileSize());// 파일크기

				StringWriter stringWriter = new StringWriter();
				jsonObject.writeJSONString(stringWriter);
				logger.debug(jsonObject.toString());
				writer.println(jsonObject.toString());
				logger.debug("##########################################################upload end");

				logger.debug("##########################################################uploaded file info DB save Start");
				// DB 저장
				FileVO fileVO = new FileVO();
				fileVO.setFileItemId(fileItemId);
				fileVO.setFileId(fileId);
				fileVO.setFileNm(fileNm);
				fileVO.setFileNmAlias(fileNmAlias);
				fileVO.setFilePathCd(filePathCd);
				fileVO.setFileSize(fileSize);
				fileVO.setRegiIdxx(regiIdxx);
				fileVO.setUpdtIdxx(regiIdxx);
				commonFileService.createFile(fileVO);
				logger.debug("##########################################################uploaded file info DB save End");
			}
		} catch (CrossUploaderException ex) {
			res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			logger.debug(ex.getMessage());
			writer.print(ex.getMessage().replaceAll("\"", "'"));
		} catch (Exception ex) {
			// 업로드 외 로직에서 예외 발생시 업로드 중인 모든 파일을 삭제합니다. 
			fileUpload.deleteUploadedFiles();
			res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			logger.debug(ex.getMessage());
		} finally {
			// 파일 업로드 객체에서 사용한 자원을 해제합니다.
			fileUpload.clear();
			logger.debug("fileUpload clear");
		}
	}

	/* namo 사용으로 미사용 
	//@RequestMapping(value = "/fileDownloader")
	public void fileDownloader(@RequestParam String commFileLoc, @RequestParam String commFileName, HttpServletRequest req, HttpServletResponse res) throws Exception {
		String path = req.getServletContext().getRealPath(File.separator);

		File dfile = new File(path + File.separatorChar + commFileLoc + File.separatorChar + commFileName);
		if (dfile.isFile()) {
			res.setHeader("Content-Type", "application/octet-stream;");
			res.setHeader("Content-Disposition", "attachment;filename=\"" + URLEncoder.encode(commFileName, "UTF-8") + "\";");

			OutputStream os = res.getOutputStream();
			FileInputStream fis = new FileInputStream(dfile);
			int n = 0;
			byte b[] = new byte[1024 * 4];
			while((n = fis.read(b)) != -1 ) {
				os.write(b, 0, n);
			}
			fis.close();
			os.close();
		} else {
			throw new FileNotFoundException("해당화일을 찾을 수 없습니다.");
		}
	}
	 */
}
