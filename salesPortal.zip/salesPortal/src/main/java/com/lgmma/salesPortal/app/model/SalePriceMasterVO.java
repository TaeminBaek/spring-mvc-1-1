package com.lgmma.salesPortal.app.model;

import java.util.List;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.props.SalePriceMasterPriceListType;

public class SalePriceMasterVO extends PagingParamVO implements Cloneable {

	//TB_SALEPRICE_MASTER
	@NotBlank(message="영업조직{errors.required}")
	private String vkorg;
	private String vkorgText;
	private String vtweg;
	private String vtwegName;
	private String kunnr;
	private String name1;
	private String indoKunnr;
	private String indoName;
	private String sawnName;
	private String sawnCode;
	private String regiName;
	private String matnr;
	private String spType;
	private String pltypName;
	private String finalIndo;
	private String spTypeName;
	@Pattern(regexp="(\\d{8}|)$", message="{errors.date}")
	private String spStaYmd;
	@Pattern(regexp="(\\d{8}|)$", message="{errors.date}")
	private String spEndYmd;
	private String spMonFYmd;
	private String spMonTYmd;
	private String spTypeKind;
	private String spTypeKindName;
	private String konwa;
	private String kmein;
	private String kmeinName;
	private float price;
	private double reqQtySum;
	private String bigoText;

	@Pattern(regexp="(\\d{8}|)$", message="{errors.date}")
	private String searchDate; //기준일
	private String fullMatchYn; //제품코드가 정확히 일치하는 것을 찾을지 여부
	private String userId;
	private String saleManCode;
	private String spAdminYn;
	private String soldYn;
	private List<SalePriceMasterHisVO> hisList;
	private List<OrderType> orderTypeList;

	private String saveAct;

	//판가생성 RFC 리턴 & 결과값
	private String eReturn; 	//리턴메시지
	private String eSubrc;		//리턴코드
	private String msg;			//이벤트 메시지
	private String kunwe;		//인도처코드
	private String pltyp;		//가격리스트유형
	private String wtyVParnr;	//최종인도처코드
	private String kbetr;		//판가
	private String datab;		//판가시작일
	private String datbi;		//판가종료일
	private String stockSumCnt;
	private String stockInfo;
	private List<SalePriceMasterPriceListType> priceList;
	private String lvorm;		//자재단종여부

	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getVtweg() {
		return vtweg;
	}
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	public String getVtwegName() {
		return vtwegName;
	}
	public void setVtwegName(String vtwegName) {
		this.vtwegName = vtwegName;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getIndoKunnr() {
		return indoKunnr;
	}
	public void setIndoKunnr(String indoKunnr) {
		this.indoKunnr = indoKunnr;
	}
	
	public String getIndoName() {
		return indoName;
	}
	public void setIndoName(String indoName) {
		this.indoName = indoName;
	}
	public String getSawnName() {
		return sawnName;
	}
	public void setSawnName(String sawnName) {
		this.sawnName = sawnName;
	}
	public String getRegiName() {
		return regiName;
	}
	public void setRegiName(String regiName) {
		this.regiName = regiName;
	}
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getSpType() {
		return spType;
	}
	public void setSpType(String spType) {
		this.spType = spType;
	}
	public String getPltypName() {
		return pltypName;
	}
	public void setPltypName(String pltypName) {
		this.pltypName = pltypName;
	}
	public String getFinalIndo() {
		return finalIndo;
	}
	public void setFinalIndo(String finalIndo) {
		this.finalIndo = finalIndo;
	}
	public String getSpTypeName() {
		return spTypeName;
	}
	public void setSpTypeName(String spTypeName) {
		this.spTypeName = spTypeName;
	}
	public String getSpStaYmd() {
		return spStaYmd;
	}
	public void setSpStaYmd(String spStaYmd) {
		this.spStaYmd = spStaYmd;
	}
	public String getSpEndYmd() {
		return spEndYmd;
	}
	public void setSpEndYmd(String spEndYmd) {
		this.spEndYmd = spEndYmd;
	}
	public String getSpTypeKind() {
		return spTypeKind;
	}
	public void setSpTypeKind(String spTypeKind) {
		this.spTypeKind = spTypeKind;
	}
	
	public String getSpTypeKindName() {
		return spTypeKindName;
	}
	public void setSpTypeKindName(String spTypeKindName) {
		this.spTypeKindName = spTypeKindName;
	}
	public String getKonwa() {
		return konwa;
	}
	public void setKonwa(String konwa) {
		this.konwa = konwa;
	}
	public String getKmein() {
		return kmein;
	}
	public void setKmein(String kmein) {
		this.kmein = kmein;
	}
	
	public String getKmeinName() {
		return kmeinName;
	}
	public void setKmeinName(String kmeinName) {
		this.kmeinName = kmeinName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getBigoText() {
		return bigoText;
	}
	public void setBigoText(String bigoText) {
		this.bigoText = bigoText;
	}
	public String getSearchDate() {
		return searchDate;
	}
	public void setSearchDate(String searchDate) {
		this.searchDate = searchDate;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSaleManCode() {
		return saleManCode;
	}
	public void setSaleManCode(String saleManCode) {
		this.saleManCode = saleManCode;
	}
	public String getSpAdminYn() {
		return spAdminYn;
	}
	public void setSpAdminYn(String spAdminYn) {
		this.spAdminYn = spAdminYn;
	}
	public String getSoldYn() {
		return soldYn;
	}
	public void setSoldYn(String soldYn) {
		this.soldYn = soldYn;
	}
	public List<SalePriceMasterHisVO> getHisList() {
		return hisList;
	}
	public void setHisList(List<SalePriceMasterHisVO> hisList) {
		this.hisList = hisList;
	}

	public String getSaveAct() {
		return saveAct;
	}
	public void setSaveAct(String saveAct) {
		this.saveAct = saveAct;
	}
	
	public String geteReturn() {
		return eReturn;
	}
	public void seteReturn(String eReturn) {
		this.eReturn = eReturn;
	}
	public String geteSubrc() {
		return eSubrc;
	}
	public void seteSubrc(String eSubrc) {
		this.eSubrc = eSubrc;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getKunwe() {
		return kunwe;
	}
	public void setKunwe(String kunwe) {
		this.kunwe = kunwe;
	}
	public String getPltyp() {
		return pltyp;
	}
	public void setPltyp(String pltyp) {
		this.pltyp = pltyp;
	}
	public String getWtyVParnr() {
		return wtyVParnr;
	}
	public void setWtyVParnr(String wtyVParnr) {
		this.wtyVParnr = wtyVParnr;
	}
	public String getKbetr() {
		return kbetr;
	}
	public void setKbetr(String kbetr) {
		this.kbetr = kbetr;
	}
	public String getDatab() {
		return datab;
	}
	public void setDatab(String datab) {
		this.datab = datab;
	}
	public String getDatbi() {
		return datbi;
	}
	public void setDatbi(String datbi) {
		this.datbi = datbi;
	}
	@Override
	public Object clone()
	{
		try{
			SalePriceMasterVO salePriceMasterVO = (SalePriceMasterVO)super.clone();
			return salePriceMasterVO;
		}catch(CloneNotSupportedException e){
			e.printStackTrace();
		}
		return null;
	}
	public String getStockSumCnt() {
		return stockSumCnt;
	}
	public void setStockSumCnt(String stockSumCnt) {
		this.stockSumCnt = stockSumCnt;
	}
	public String getStockInfo() {
		return stockInfo;
	}
	public void setStockInfo(String stockInfo) {
		this.stockInfo = stockInfo;
	}
	public String getVkorgText() {
		return vkorgText;
	}
	public void setVkorgText(String vkorgText) {
		this.vkorgText = vkorgText;
	}
	public void setPriceList(List<SalePriceMasterPriceListType> priceList) {
		this.priceList = priceList;
	}
	public List<SalePriceMasterPriceListType> getPriceList() {
		return priceList;
	}
	public String getLvorm() {
		return lvorm;
	}
	public void setLvorm(String lvorm) {
		this.lvorm = lvorm;
	}
	public String getFullMatchYn() {
		return fullMatchYn;
	}
	public void setFullMatchYn(String fullMatchYn) {
		this.fullMatchYn = fullMatchYn;
	}
	public String getSawnCode() {
		return sawnCode;
	}
	public void setSawnCode(String sawnCode) {
		this.sawnCode = sawnCode;
	}
	public String getSpMonFYmd() {
		return spMonFYmd;
	}
	public void setSpMonFYmd(String spMonFYmd) {
		this.spMonFYmd = spMonFYmd;
	}
	public String getSpMonTYmd() {
		return spMonTYmd;
	}
	public void setSpMonTYmd(String spMonTYmd) {
		this.spMonTYmd = spMonTYmd;
	}
	public List<OrderType> getOrderTypeList() {
		return orderTypeList;
	}
	public void setOrderTypeList(List<OrderType> orderTypeList) {
		this.orderTypeList = orderTypeList;
	}
	public double getReqQtySum() {
		return reqQtySum;
	}
	public void setReqQtySum(double reqQtySum) {
		this.reqQtySum = reqQtySum;
	}
	
	
}
