package com.lgmma.salesPortal.app.model;

public class OrderProdJindVO extends PagingParamVO {
	
	private String jindIdxx;  //주문제품군ID
	private String tvkotVkorg;  //주문제품군ID
	private String compCode;    //판매처ID
	private String matnr;		//제품
	private String condValue;	//제품가격
	private String partnNumb;	//인도처ID
	private String name;		//인도처명
	private String street;		//인도처주소
	private String title;		//인도처 경칭
	private String postlCode;	//인도처 우편번호
	private String contury;		
	private String telephone;	//인도처 전화번호
	private String faxNumber;	//인도처 팩스번호
	
	//주문상세 SAP 인도처 정보
	private String NAME1;
	private String PSTLZ;
	private String STRAS;
	private String TELF1;
	
	
	
	
	public String getCondValue() {
		return condValue;
	}
	public void setCondValue(String condValue) {
		this.condValue = condValue;
	}
	public String getJindIdxx() {
		return jindIdxx;
	}
	public void setJindIdxx(String jindIdxx) {
		this.jindIdxx = jindIdxx;
	}
	public String getNAME1() {
		return NAME1;
	}
	public void setNAME1(String nAME1) {
		NAME1 = nAME1;
	}
	public String getPSTLZ() {
		return PSTLZ;
	}
	public void setPSTLZ(String pSTLZ) {
		PSTLZ = pSTLZ;
	}
	public String getSTRAS() {
		return STRAS;
	}
	public void setSTRAS(String sTRAS) {
		STRAS = sTRAS;
	}
	public String getTELF1() {
		return TELF1;
	}
	public void setTELF1(String tELF1) {
		TELF1 = tELF1;
	}
	public String getPostlCode() {
		return postlCode;
	}
	public void setPostlCode(String postlCode) {
		this.postlCode = postlCode;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContury() {
		return contury;
	}
	public void setContury(String contury) {
		this.contury = contury;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getTvkotVkorg() {
		return tvkotVkorg;
	}
	public void setTvkotVkorg(String tvkotVkorg) {
		this.tvkotVkorg = tvkotVkorg;
	}
	
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getPartnNumb() {
		return partnNumb;
	}
	public void setPartnNumb(String partnNumb) {
		this.partnNumb = partnNumb;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getFaxNumber() {
		return faxNumber;
	}
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}
	
	
}
