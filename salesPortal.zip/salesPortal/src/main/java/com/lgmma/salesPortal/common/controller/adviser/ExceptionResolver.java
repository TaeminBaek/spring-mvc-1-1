package com.lgmma.salesPortal.common.controller.adviser;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;
import com.lgmma.salesPortal.security.authentication.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.text.MessageFormat;

/**
 * 같은 컨텍스트 내에 모든 컨트롤러에서 발생한 예외를 처리하는 리졸버. 
 * 각각의 컨트롤러에서 @ExceptionHandler 가 붙은 메서드가 있으면 그것이 우선함.
 */
@ControllerAdvice
public class ExceptionResolver {
	public static final String DEFAULT_ERROR_VIEW = "error";

    @Autowired
    private MessageSourceAccessor messageSourceAccessor;
	/**
	 * @param e
	 * @return
	 * @throws NoSuchMessageException 
	 * @throws IOException 
	 */
	@ExceptionHandler(Exception.class)
	@ResponseBody
	public Object defaultErrorHandler(HttpServletRequest request, HttpServletResponse response, Exception e) throws IOException {
		response.setContentType("text/html; charset=UTF-8");
		String message = e.getMessage();
		String fieldName = "";
		if(e instanceof NoHandlerFoundException) {	//404
			message = messageSourceAccessor.getMessage("fail.find.page");
		} else if(e instanceof AuthenticationServiceException) {
			response.getWriter().write("<script language='javascript' type='text/javascript'>alert('" + e.getMessage() + "');self.opener=self;window.close();</script>");
			response.getWriter().flush();
			response.getWriter().close();
			return null;
		} else if(e instanceof DuplicateKeyException) {
			message = messageSourceAccessor.getMessage("fail.common.sql.dup");
		} else if(e instanceof DataIntegrityViolationException) {
			message = messageSourceAccessor.getMessage("fail.common.sql.toolong");
		} else if(e instanceof DataAccessException) {
			message = messageSourceAccessor.getMessage("fail.common.db");
		} else if(e instanceof SQLException) {
//			Object[] rep = {((SQLException) e).getSQLState(), e.getMessage()};
//			message = messageSourceAccessor.getMessage("fail.common.sql", rep);
			message = messageSourceAccessor.getMessage("fail.common.db");
		} else if(e instanceof MethodArgumentNotValidException) {
			message = ((MethodArgumentNotValidException) e).getBindingResult().getAllErrors().get(0).getDefaultMessage();
			fieldName = ((MethodArgumentNotValidException) e).getBindingResult().getFieldErrors().get(0).getField();
		} else if(e instanceof HttpMessageNotReadableException) {
			if(((HttpMessageNotReadableException) e).getRootCause() instanceof InvalidFormatException){
				message = messageSourceAccessor.getMessage("fail.common.data.format");
			}
		} else if(e instanceof InvalidFormatException) {
			message = messageSourceAccessor.getMessage("fail.common.data.format");
		} else if(e instanceof ServiceException) {
			//메시지가 이미 있으면 메시지 우선, 코드가 있으면 코드로 메시지를 찾는다.
			message = ((ServiceException) e).getErrorMsg() != null ? ((ServiceException) e).getErrorMsg() : getMessage((ServiceException) e);
		} else {
			message = messageSourceAccessor.getMessage("fail.common.msg");
		}
		if( "XMLHttpRequest".equals(request.getHeader("x-requested-with")) ) {
			return JsonResponse.asFailure(fieldName, message);
		} else {
			ModelAndView mav = new ModelAndView();
			UserInfo userInfo = ((CustomAuthenticationToken) SecurityContextHolder.getContext().getAuthentication()).getUserInfo();
			if("E".equals(userInfo.getUserType())){
				mav.setViewName(DEFAULT_ERROR_VIEW);
			}else{
				mav.setViewName("partner/" + DEFAULT_ERROR_VIEW);
			}
		    mav.addObject("exception", message);
		    mav.addObject("url", request.getRequestURL());
		    return mav;
		}
	}

	/**
	 * 예외 메시지 가져오기
	 */
	public String getMessage(ServiceException e) {	
		return Util.nvl(messageSourceAccessor.getMessage(e.getCode()), messageSourceAccessor.getMessage("fail.common.msg")); 
	}
	
	/**
	 * 예외 메시지 가져오기
	 */
	public String getRootMessage(ServiceException e) {	
		Throwable rootCause = ServiceException.getRootCause(e);
		String errorMsg = e == rootCause ? e.getMessage() : rootCause.getMessage();
		if(e.getRep() != null)
		{
			errorMsg = MessageFormat.format(errorMsg, e.getRep());
		}
		return Util.nvl(errorMsg, messageSourceAccessor.getMessage("fail.common.msg")); 
	}
	
}
