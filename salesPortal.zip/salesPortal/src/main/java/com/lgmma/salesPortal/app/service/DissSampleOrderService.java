package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissSampleOrderItemVO;
import com.lgmma.salesPortal.app.model.DissSampleOrderMasterVO;

public interface DissSampleOrderService {
	DissSampleOrderMasterVO getSampleOrderTaskBasicInfo(DissSampleOrderMasterVO dissSampleOrderMasterVO);

	DissSampleOrderMasterVO searchSampleOrderInfo(DissSampleOrderMasterVO dissSampleOrderMasterVO);

	void setDissSampleOrderDetailCodeText(DissSampleOrderMasterVO dissSampleOrderMasterVO);

	void saveDissSampleOrder(DissSampleOrderMasterVO dissSampleOrderMasterVO);

	void saveDissSampleOrderAfterApproval(DissApprCommonParamVO dissApprCommonParamVO);

	List<DirectOrderItemVO> castItemListFrDissItemList(List<DissSampleOrderItemVO> dissSampleOrderItemVOList);

	void applDissSampleOrder (DissApprCommonParamVO dissApprCommonParamVO);

	List<DissSampleOrderMasterVO> selectDissSampleOrderMasterItemList(DissSampleOrderMasterVO dissSampleOrderMasterVO);
	
	List<DissSampleOrderMasterVO> selectDissSampleOrderCustTestList(DissSampleOrderMasterVO dissSampleOrderMasterVO);
	
	List<DissSampleOrderMasterVO> selectDissSampleOrderCustTestOrderList(DissSampleOrderMasterVO dissSampleOrderMasterVO);

	int getSampleOrderCount(DissSampleOrderMasterVO param);

	List<DissSampleOrderMasterVO> getSampleOrderList(DissSampleOrderMasterVO param);

	List<DissSampleOrderMasterVO> getDissSampleListExcelDownload(DissSampleOrderMasterVO param);

	String getApprFormCont(DissSampleOrderMasterVO param);//kjy
}
