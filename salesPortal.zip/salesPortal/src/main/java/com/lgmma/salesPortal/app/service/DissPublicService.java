package com.lgmma.salesPortal.app.service;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissCommentVO;
import com.lgmma.salesPortal.app.model.DissMemberVO;
import com.lgmma.salesPortal.app.model.DissPublicVO;
import com.lgmma.salesPortal.app.model.DissReviewVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.model.EmployVO;

public interface DissPublicService {

	void deleteDissPublicApprType(DissPublicVO param);
	
	void saveDissPublicApprTypeRew(DissPublicVO param);
	
	void saveDissPublicApprType(DissPublicVO param);

	void saveDissPublicApprovalAction(DissStepVO param);
	
	void createComment(DissCommentVO param);

	void sendCommentMail(DissCommentVO param);

	boolean createCommentYn(DissCommentVO param);
	
	List<DissCommentVO> getCommentList(DissCommentVO param);
	
	int getCommentListCount(DissCommentVO param);

	void createReviewReq(DissReviewVO param);

	void createReviewAns(DissReviewVO param);
	
	List<DissReviewVO> getReviewList(DissReviewVO param);

	int getReviewListCount(DissReviewVO param);

	DissPublicVO getDissPublicApprTypeDetail(DissStepVO param);

	DissPublicVO searchSampleOrderNoticeInfo(DissPublicVO dissPublicVO);

	void saveSampleOrderNotice(DissPublicVO dissPublicVO);

	void applSampleOrderNotice(DissApprCommonParamVO dissApprCommonParamVO);

	void chkSalesTeam(String empId);

	void chkTSTeam(String empId);
	
	List<EmployVO> loadEmployList(Map<String, String> param);
	
	String getApprFormContSampleOrderNotice(DissPublicVO param, String templeteFormContent);
	
	String getApprFormContCustTest(DissPublicVO param, String templeteFormContent);
	
	String getApprFormContCustComplete(DissPublicVO param, String templeteFormContent);
	
	String getApprFormContCompGrade(DissPublicVO param, String templeteFormContent);
	
	String getApprFormContMassTrans(DissPublicVO param, String templeteFormContent);

	List<DissStepVO> getDissStepIngList(DissStepVO param);

	List<DissMemberVO> getDefaultApprILine(DissMemberVO param);
}
