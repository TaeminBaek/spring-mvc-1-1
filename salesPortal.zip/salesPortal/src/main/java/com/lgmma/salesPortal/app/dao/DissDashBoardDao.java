package com.lgmma.salesPortal.app.dao;

import com.lgmma.salesPortal.app.model.DissDashBoardVO;

public interface DissDashBoardDao {
	
	DissDashBoardVO getDissDashBoardMyIngSpecInCnt(DissDashBoardVO param);
	
	DissDashBoardVO getDissDashBoardMyIngImpDevCnt(DissDashBoardVO param);

	DissDashBoardVO getDissDashBoardMyIngOneTeamCnt(DissDashBoardVO param);
	
	DissDashBoardVO getDissDashBoardStepSpecInCnt(DissDashBoardVO param);
	
	DissDashBoardVO getDissDashBoardStepImpDevCnt(DissDashBoardVO param);
}
