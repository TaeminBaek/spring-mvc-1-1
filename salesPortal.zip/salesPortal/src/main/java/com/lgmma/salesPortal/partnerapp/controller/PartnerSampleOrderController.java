package com.lgmma.salesPortal.partnerapp.controller;

import com.lgmma.salesPortal.app.controller.CommonController;
import com.lgmma.salesPortal.app.service.OrderService;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.util.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/partner")
public class PartnerSampleOrderController {

	@Autowired
	OrderService orderService;

	@Autowired
	CommonController commonController;

	/**
	 * 견본관리 견본목록 화면 랜딩
	 *
	 * @param mav
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sampleOrderMgmt")
	public ModelAndView sampleOrderMgmt(ModelAndView mav) throws Exception {
		mav.setViewName("partner/sampleOrder/sampleOrderMgmt");
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("orderTypeList", OrderType.values());
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		return mav;
	}
}
