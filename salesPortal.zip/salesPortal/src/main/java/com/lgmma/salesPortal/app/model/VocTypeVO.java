package com.lgmma.salesPortal.app.model;

public class VocTypeVO extends PagingParamVO {
	
	private String seqxNumx;
	private int vocxIdxx;
	private String typeCode;
	
	public String getSeqxNumx() {
		return seqxNumx;
	}
	public void setSeqxNumx(String seqxNumx) {
		this.seqxNumx = seqxNumx;
	}
	public int getVocxIdxx() {
		return vocxIdxx;
	}
	public void setVocxIdxx(int vocxIdxx) {
		this.vocxIdxx = vocxIdxx;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	

}
