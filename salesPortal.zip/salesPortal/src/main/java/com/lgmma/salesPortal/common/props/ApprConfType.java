package com.lgmma.salesPortal.common.props;

public enum ApprConfType {
/**
 * 결재협의구분으로서
*/
	 APPR_CONF_TYPE_SERIES("S"	,"순차","0")
	,APPR_CONF_TYPE_PARALLEL("P","병렬","1")
	;
	String code = null;
	String name = null;
	String gpConfType = null; // GPortal 협의방법

	private ApprConfType(String code, String name,String gpConfType) {
		this.code = code;
		this.name = name;
		this.gpConfType = gpConfType;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getGpConfType() {
		return gpConfType;
	}

	public void setGpConfType(String gpConfType) {
		this.gpConfType = gpConfType;
	}

	public static ApprConfType getApprApprConfType(String code) {
		for(ApprConfType type : ApprConfType.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}

}
