package com.lgmma.salesPortal.app.model;


public class StatisticsCustSuppVO extends PagingParamVO {

	//조회조건
	private String qryType;
	private String sdate;
	private String edate;
	
	//리스트
	private String gubun;
	private String srvcCode;
	private String srvcName;
	private String divxCode;
	private String divxName;
	private int srvcCnt;
	private int m01;
	private int m02;
	private int m03;
	private int m04;
	private int m05;
	private int m06;
	private int m07;
	private int m08;
	private int m09;
	private int m10;
	private int m11;
	private int m12;
	//뷰
	private int divxCnt;
	private float lapsHour;
	private float lapsDate;
	private float avgLapsHour;
	private float avgLapsDate;
	//팝업
	private String typeCode;
	private String codeName;
	
	public String getGubun() {
		return gubun;
	}
	public void setGubun(String gubun) {
		this.gubun = gubun;
	}
	public String getQryType() {
		return qryType;
	}
	public void setQryType(String qryType) {
		this.qryType = qryType;
	}
	public String getSdate() {
		return sdate;
	}
	public void setSdate(String sdate) {
		this.sdate = sdate;
	}
	public String getEdate() {
		return edate;
	}
	public void setEdate(String edate) {
		this.edate = edate;
	}
	public String getSrvcCode() {
		return srvcCode;
	}
	public void setSrvcCode(String srvcCode) {
		this.srvcCode = srvcCode;
	}
	public String getSrvcName() {
		return srvcName;
	}
	public void setSrvcName(String srvcName) {
		this.srvcName = srvcName;
	}
	public String getDivxCode() {
		return divxCode;
	}
	public void setDivxCode(String divxCode) {
		this.divxCode = divxCode;
	}
	public String getDivxName() {
		return divxName;
	}
	public void setDivxName(String divxName) {
		this.divxName = divxName;
	}
	public int getSrvcCnt() {
		return srvcCnt;
	}
	public void setSrvcCnt(int srvcCnt) {
		this.srvcCnt = srvcCnt;
	}
	public int getM01() {
		return m01;
	}
	public void setM01(int m01) {
		this.m01 = m01;
	}
	public int getM02() {
		return m02;
	}
	public void setM02(int m02) {
		this.m02 = m02;
	}
	public int getM03() {
		return m03;
	}
	public void setM03(int m03) {
		this.m03 = m03;
	}
	public int getM04() {
		return m04;
	}
	public void setM04(int m04) {
		this.m04 = m04;
	}
	public int getM05() {
		return m05;
	}
	public void setM05(int m05) {
		this.m05 = m05;
	}
	public int getM06() {
		return m06;
	}
	public void setM06(int m06) {
		this.m06 = m06;
	}
	public int getM07() {
		return m07;
	}
	public void setM07(int m07) {
		this.m07 = m07;
	}
	public int getM08() {
		return m08;
	}
	public void setM08(int m08) {
		this.m08 = m08;
	}
	public int getM09() {
		return m09;
	}
	public void setM09(int m09) {
		this.m09 = m09;
	}
	public int getM10() {
		return m10;
	}
	public void setM10(int m10) {
		this.m10 = m10;
	}
	public int getM11() {
		return m11;
	}
	public void setM11(int m11) {
		this.m11 = m11;
	}
	public int getM12() {
		return m12;
	}
	public void setM12(int m12) {
		this.m12 = m12;
	}
	public int getDivxCnt() {
		return divxCnt;
	}
	public void setDivxCnt(int divxCnt) {
		this.divxCnt = divxCnt;
	}
	public float getLapsHour() {
		return lapsHour;
	}
	public void setLapsHour(float lapsHour) {
		this.lapsHour = lapsHour;
	}
	public float getLapsDate() {
		return lapsDate;
	}
	public void setLapsDate(float lapsDate) {
		this.lapsDate = lapsDate;
	}
	public float getAvgLapsHour() {
		return avgLapsHour;
	}
	public void setAvgLapsHour(float avgLapsHour) {
		this.avgLapsHour = avgLapsHour;
	}
	public float getAvgLapsDate() {
		return avgLapsDate;
	}
	public void setAvgLapsDate(float avgLapsDate) {
		this.avgLapsDate = avgLapsDate;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getCodeName() {
		return codeName;
	}
	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}	
}
