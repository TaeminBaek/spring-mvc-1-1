package com.lgmma.salesPortal.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import com.lgmma.salesPortal.app.dao.MsDao;
import com.lgmma.salesPortal.app.model.IcisVO;
import com.lgmma.salesPortal.app.model.SmsVO;
import com.lgmma.salesPortal.app.service.MsService;
import com.lgmma.salesPortal.app.service.SmsService;
import com.lgmma.salesPortal.common.util.StringUtil;

@Transactional(transactionManager = "msSqlTransactionManager")
@Service
public class MsServiceImpl implements MsService {

	@Autowired
	private MsDao msDao;

	@Override
	public List<IcisVO> getIcisList(IcisVO param) {
		return msDao.getIcisList(param);
	}

}
