package com.lgmma.salesPortal.app.model;

public class DissStepVO extends PagingParamVO {

	//TB_D_STEP
	private String stepId;        //과제스텝ID
	private String taskId;      //과제ID
	private String taskType;    //과제구분
	private String stepCd;      //스텝코드
	private Integer degreeNo;   //차수
	private String degreeReason;//차수사유
	private String title;       //제목
	private String apprId;      //품의서ID
	private String fileId;      //파일ID
	private String stepRslt;    //STEP_결과
	private String stepLastYn;  //STEP최종여부
	private int orderNo;
	private String orderId;     // DISS견본주문ID
	private String regiInfo;
	//품의서 정보
	private String apprType;
	private String apprTypeName;
	private String apprStat;
	private String apprStatName;
	//품의 결재라인 체크
	private String apprApplCheck;
	private String apprLineType;
	//품의 결재액션
	private String applStat;
	private String apprLineComment;
	private DissScheduleVO dissScheduleVO;
	private DissTaskResultVO dissTaskResultVO;
	private String stepNm; // 스텝코드명
	private String lastStepId;      // 과제마지막스텝ID
	private String vbeln; // 주문건의 SAP 주문번호
	private String custTestResult;// 주문건의 고객테스트결과
	private String stepRsltName;    //STEP_결과명

	private String regiName;	//등록자명
	private String regiDateFmt; //등록일시

	private String taskName; // 과제명
	private String compResult; // 과제개발완료결과

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getStepCd() {
		return stepCd;
	}

	public void setStepCd(String stepCd) {
		this.stepCd = stepCd;
	}

	public Integer getDegreeNo() {
		return degreeNo;
	}

	public void setDegreeNo(Integer degreeNo) {
		this.degreeNo = degreeNo;
	}

	public String getDegreeReason() {
		return degreeReason;
	}

	public void setDegreeReason(String degreeReason) {
		this.degreeReason = degreeReason;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getApprId() {
		return apprId;
	}

	public void setApprId(String apprId) {
		this.apprId = apprId;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getStepRslt() {
		return stepRslt;
	}

	public void setStepRslt(String stepRslt) {
		this.stepRslt = stepRslt;
	}

	public String getStepLastYn() {
		return stepLastYn;
	}

	public void setStepLastYn(String stepLastYn) {
		this.stepLastYn = stepLastYn;
	}

	public int getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}

	public String getRegiInfo() {
		return regiInfo;
	}

	public void setRegiInfo(String regiInfo) {
		this.regiInfo = regiInfo;
	}

	public String getApprType() {
		return apprType;
	}

	public void setApprType(String apprType) {
		this.apprType = apprType;
	}

	public String getApprTypeName() {
		return apprTypeName;
	}

	public void setApprTypeName(String apprTypeName) {
		this.apprTypeName = apprTypeName;
	}

	public String getApprStat() {
		return apprStat;
	}

	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}

	public String getApprStatName() {
		return apprStatName;
	}

	public void setApprStatName(String apprStatName) {
		this.apprStatName = apprStatName;
	}

	public String getApprApplCheck() {
		return apprApplCheck;
	}

	public void setApprApplCheck(String apprApplCheck) {
		this.apprApplCheck = apprApplCheck;
	}

	public String getApprLineType() {
		return apprLineType;
	}

	public void setApprLineType(String apprLineType) {
		this.apprLineType = apprLineType;
	}

	public String getApplStat() {
		return applStat;
	}

	public void setApplStat(String applStat) {
		this.applStat = applStat;
	}

	public String getApprLineComment() {
		return apprLineComment;
	}

	public void setApprLineComment(String apprLineComment) {
		this.apprLineComment = apprLineComment;
	}

	public DissScheduleVO getDissScheduleVO() {
		return dissScheduleVO;
	}

	public void setDissScheduleVO(DissScheduleVO dissScheduleVO) {
		this.dissScheduleVO = dissScheduleVO;
	}

	public DissTaskResultVO getDissTaskResultVO() {
		return dissTaskResultVO;
	}

	public void setDissTaskResultVO(DissTaskResultVO dissTaskResultVO) {
		this.dissTaskResultVO = dissTaskResultVO;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getStepNm() {
		return stepNm;
	}

	public void setStepNm(String stepNm) {
		this.stepNm = stepNm;
	}

	public String getLastStepId() {
		return lastStepId;
	}

	public void setLastStepId(String lastStepId) {
		this.lastStepId = lastStepId;
	}

	public String getVbeln() {
		return vbeln;
	}

	public void setVbeln(String vbeln) {
		this.vbeln = vbeln;
	}

	public String getCustTestResult() {
		return custTestResult;
	}

	public void setCustTestResult(String custTestResult) {
		this.custTestResult = custTestResult;
	}

	public String getStepRsltName() {
		return stepRsltName;
	}

	public void setStepRsltName(String stepRsltName) {
		this.stepRsltName = stepRsltName;
	}

	public String getRegiName() {
		return regiName;
	}

	public void setRegiName(String regiName) {
		this.regiName = regiName;
	}

	public String getRegiDateFmt() {
		return regiDateFmt;
	}

	public void setRegiDateFmt(String regiDateFmt) {
		this.regiDateFmt = regiDateFmt;
	}

	public String getCompResult() {
		return compResult;
	}

	public void setCompResult(String compResult) {
		this.compResult = compResult;
	}
}
