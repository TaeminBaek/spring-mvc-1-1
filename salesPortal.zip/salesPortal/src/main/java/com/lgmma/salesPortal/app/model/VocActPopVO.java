package com.lgmma.salesPortal.app.model;

public class VocActPopVO extends PagingParamVO {

	private int vactIdxx;
	private int vocxIdxx;
	private int levlNumx;
	private String fildDate1;
	private String longText1;
	private String dealComp;
	private String gradIdxx;
	private String fildQtyx1;
	private String fildPric1;
	private String fildFlag1;
	private String shrtText1;
	private String shrtText2;
	private String shrtText3;
	private String erpxNoxx;
	private String endxFlag;
	private String regiIdxx;
	private String regiDate;
	private String acptIdxx;
	private String actxName;
	private String lognName;
	private String mailAddr;
	private String srvcCode;
	private String srvcName;
	private String divxCode;
	private String divxName;
	private String vocxFdate1;
	private String fildText2;
	private String reqxDate;
	private String tvkotVkorg;
	private String indoIdxx;
	private String indoAddr;
	private String indoPost;
	private String indoTelx;
	private String indoManx;
	private String actGradIdxx;
	private String actFildQtyx1;
	private String qtyxUnit;
	private String fildText4;
	private String vocFlag;
	private String actxCode;
	private String fildText1;
	private String company;
	private String vtext;
	private String contText;
	private String yymmDate;
	private String kunnr;
	private String titlText;
	private String longText2;
	private String ordReason;
	private String oldsCond;
	private String newxCond;
	private String shrtText4;
	private String shrtText5;
	private String vocaIndoIdxx;
	private String shrtText6;
	private String compCode;
	private String incotermsSend;
	//다음 Activity
	private int workSeqx;
	private String mustIsxx;
	private String teamCode;
	private String srvcDept;
	//VOC 상태
	private String vocxStat;
	
	public int getVactIdxx() {
		return vactIdxx;
	}
	public void setVactIdxx(int vactIdxx) {
		this.vactIdxx = vactIdxx;
	}
	public int getVocxIdxx() {
		return vocxIdxx;
	}
	public void setVocxIdxx(int vocxIdxx) {
		this.vocxIdxx = vocxIdxx;
	}
	public int getLevlNumx() {
		return levlNumx;
	}
	public void setLevlNumx(int levlNumx) {
		this.levlNumx = levlNumx;
	}
	public String getFildDate1() {
		return fildDate1;
	}
	public void setFildDate1(String fildDate1) {
		this.fildDate1 = fildDate1;
	}
	public String getLongText1() {
		return longText1;
	}
	public void setLongText1(String longText1) {
		this.longText1 = longText1;
	}
	public String getDealComp() {
		return dealComp;
	}
	public void setDealComp(String dealComp) {
		this.dealComp = dealComp;
	}
	public String getGradIdxx() {
		return gradIdxx;
	}
	public void setGradIdxx(String gradIdxx) {
		this.gradIdxx = gradIdxx;
	}
	public String getFildQtyx1() {
		return fildQtyx1;
	}
	public void setFildQtyx1(String fildQtyx1) {
		this.fildQtyx1 = fildQtyx1;
	}
	public String getFildPric1() {
		return fildPric1;
	}
	public void setFildPric1(String fildPric1) {
		this.fildPric1 = fildPric1;
	}
	public String getFildFlag1() {
		return fildFlag1;
	}
	public void setFildFlag1(String fildFlag1) {
		this.fildFlag1 = fildFlag1;
	}
	public String getShrtText1() {
		return shrtText1;
	}
	public void setShrtText1(String shrtText1) {
		this.shrtText1 = shrtText1;
	}
	public String getShrtText2() {
		return shrtText2;
	}
	public void setShrtText2(String shrtText2) {
		this.shrtText2 = shrtText2;
	}
	public String getShrtText3() {
		return shrtText3;
	}
	public void setShrtText3(String shrtText3) {
		this.shrtText3 = shrtText3;
	}
	public String getErpxNoxx() {
		return erpxNoxx;
	}
	public void setErpxNoxx(String erpxNoxx) {
		this.erpxNoxx = erpxNoxx;
	}
	public String getEndxFlag() {
		return endxFlag;
	}
	public void setEndxFlag(String endxFlag) {
		this.endxFlag = endxFlag;
	}
	public String getRegiIdxx() {
		return regiIdxx;
	}
	public void setRegiIdxx(String regiIdxx) {
		this.regiIdxx = regiIdxx;
	}
	public String getRegiDate() {
		return regiDate;
	}
	public void setRegiDate(String regiDate) {
		this.regiDate = regiDate;
	}
	public String getAcptIdxx() {
		return acptIdxx;
	}
	public void setAcptIdxx(String acptIdxx) {
		this.acptIdxx = acptIdxx;
	}
	public String getActxName() {
		return actxName;
	}
	public void setActxName(String actxName) {
		this.actxName = actxName;
	}
	public String getLognName() {
		return lognName;
	}
	public void setLognName(String lognName) {
		this.lognName = lognName;
	}
	public String getMailAddr() {
		return mailAddr;
	}
	public void setMailAddr(String mailAddr) {
		this.mailAddr = mailAddr;
	}
	public String getSrvcCode() {
		return srvcCode;
	}
	public void setSrvcCode(String srvcCode) {
		this.srvcCode = srvcCode;
	}
	public String getDivxCode() {
		return divxCode;
	}
	public void setDivxCode(String divxCode) {
		this.divxCode = divxCode;
	}
	public String getVocxFdate1() {
		return vocxFdate1;
	}
	public void setVocxFdate1(String vocxFdate1) {
		this.vocxFdate1 = vocxFdate1;
	}
	public String getFildText2() {
		return fildText2;
	}
	public void setFildText2(String fildText2) {
		this.fildText2 = fildText2;
	}
	public String getReqxDate() {
		return reqxDate;
	}
	public void setReqxDate(String reqxDate) {
		this.reqxDate = reqxDate;
	}
	public String getTvkotVkorg() {
		return tvkotVkorg;
	}
	public void setTvkotVkorg(String tvkotVkorg) {
		this.tvkotVkorg = tvkotVkorg;
	}
	public String getIndoIdxx() {
		return indoIdxx;
	}
	public void setIndoIdxx(String indoIdxx) {
		this.indoIdxx = indoIdxx;
	}
	public String getIndoAddr() {
		return indoAddr;
	}
	public void setIndoAddr(String indoAddr) {
		this.indoAddr = indoAddr;
	}
	public String getIndoPost() {
		return indoPost;
	}
	public void setIndoPost(String indoPost) {
		this.indoPost = indoPost;
	}
	public String getIndoTelx() {
		return indoTelx;
	}
	public void setIndoTelx(String indoTelx) {
		this.indoTelx = indoTelx;
	}
	public String getIndoManx() {
		return indoManx;
	}
	public void setIndoManx(String indoManx) {
		this.indoManx = indoManx;
	}
	public String getActGradIdxx() {
		return actGradIdxx;
	}
	public void setActGradIdxx(String actGradIdxx) {
		this.actGradIdxx = actGradIdxx;
	}
	public String getActFildQtyx1() {
		return actFildQtyx1;
	}
	public void setActFildQtyx1(String actFildQtyx1) {
		this.actFildQtyx1 = actFildQtyx1;
	}
	public String getQtyxUnit() {
		return qtyxUnit;
	}
	public void setQtyxUnit(String qtyxUnit) {
		this.qtyxUnit = qtyxUnit;
	}
	public String getFildText4() {
		return fildText4;
	}
	public void setFildText4(String fildText4) {
		this.fildText4 = fildText4;
	}
	public String getVocFlag() {
		return vocFlag;
	}
	public void setVocFlag(String vocFlag) {
		this.vocFlag = vocFlag;
	}
	public String getActxCode() {
		return actxCode;
	}
	public void setActxCode(String actxCode) {
		this.actxCode = actxCode;
	}
	public String getFildText1() {
		return fildText1;
	}
	public void setFildText1(String fildText1) {
		this.fildText1 = fildText1;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getVtext() {
		return vtext;
	}
	public void setVtext(String vtext) {
		this.vtext = vtext;
	}
	public String getContText() {
		return contText;
	}
	public void setContText(String contText) {
		this.contText = contText;
	}
	public String getYymmDate() {
		return yymmDate;
	}
	public void setYymmDate(String yymmDate) {
		this.yymmDate = yymmDate;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getTitlText() {
		return titlText;
	}
	public void setTitlText(String titlText) {
		this.titlText = titlText;
	}
	public String getLongText2() {
		return longText2;
	}
	public void setLongText2(String longText2) {
		this.longText2 = longText2;
	}
	public String getOrdReason() {
		return ordReason;
	}
	public void setOrdReason(String ordReason) {
		this.ordReason = ordReason;
	}
	public String getOldsCond() {
		return oldsCond;
	}
	public void setOldsCond(String oldsCond) {
		this.oldsCond = oldsCond;
	}
	public String getNewxCond() {
		return newxCond;
	}
	public void setNewxCond(String newxCond) {
		this.newxCond = newxCond;
	}
	public String getShrtText4() {
		return shrtText4;
	}
	public void setShrtText4(String shrtText4) {
		this.shrtText4 = shrtText4;
	}
	public String getShrtText5() {
		return shrtText5;
	}
	public void setShrtText5(String shrtText5) {
		this.shrtText5 = shrtText5;
	}
	public String getVocaIndoIdxx() {
		return vocaIndoIdxx;
	}
	public void setVocaIndoIdxx(String vocaIndoIdxx) {
		this.vocaIndoIdxx = vocaIndoIdxx;
	}
	public String getShrtText6() {
		return shrtText6;
	}
	public void setShrtText6(String shrtText6) {
		this.shrtText6 = shrtText6;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getIncotermsSend() {
		return incotermsSend;
	}
	public void setIncotermsSend(String incotermsSend) {
		this.incotermsSend = incotermsSend;
	}
	public String getSrvcName() {
		return srvcName;
	}
	public void setSrvcName(String srvcName) {
		this.srvcName = srvcName;
	}
	public String getDivxName() {
		return divxName;
	}
	public void setDivxName(String divxName) {
		this.divxName = divxName;
	}
	public int getWorkSeqx() {
		return workSeqx;
	}
	public void setWorkSeqx(int workSeqx) {
		this.workSeqx = workSeqx;
	}
	public String getMustIsxx() {
		return mustIsxx;
	}
	public void setMustIsxx(String mustIsxx) {
		this.mustIsxx = mustIsxx;
	}
	public String getTeamCode() {
		return teamCode;
	}
	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}
	public String getSrvcDept() {
		return srvcDept;
	}
	public void setSrvcDept(String srvcDept) {
		this.srvcDept = srvcDept;
	}
	public String getVocxStat() {
		return vocxStat;
	}
	public void setVocxStat(String vocxStat) {
		this.vocxStat = vocxStat;
	}
	
}
