package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissImpDevDao;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.DissImpDevVO;
import com.lgmma.salesPortal.app.model.EmployVO;

@Repository
public class DissImpDevDaoImpl implements DissImpDevDao{
	
	private static final String MAPPER_NAMESPACE = "DISSIMPDEV_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public void createDissImpDev(DissImpDevVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissImpDev", param);
	}
	
	@Override
	public int getDissTaskNameCount(DissImpDevVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissTaskNameCount", param);
	}
	
	@Override
	public int getDissImpDevListCount(DissImpDevVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissImpDevListCount", param);
	}

	@Override
	public List<DissImpDevVO> getDissImpDevList(DissImpDevVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissImpDevList", param);
	}
	
	@Override
	public List<DissImpDevVO> getDissImpDevLeaderTeamList() {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissImpDevLeaderTeamList");
	}	
	
	@Override
	public List<CommonCodeVO> getDissStepGroupToStepCdList(CommonCodeVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissStepGroupToStepCdList", param);
	}	
	
	@Override
	public DissImpDevVO getDissImpDevDetail(DissImpDevVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissImpDevDetail", param);
	}
	
	@Override
	public void updateDissImpDev(DissImpDevVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissImpDev", param);
	}
	
	@Override
	public void deleteDissImpDevAll(DissImpDevVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissImpDevAll", param);
	}
	
	@Override
	public void updateDissImpDevProposalAppr(DissImpDevVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissImpDevProposalAppr", param);
	}
	
	@Override
	public void createDissImpDevHis(DissImpDevVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissImpDevHis", param);
	}
	
	@Override
	public void updateDissImpDevHisProposalAppr(DissImpDevVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissImpDevHisProposalAppr", param);
	}
	
	@Override
	public void createDissImpDevHisProposalAppr(DissImpDevVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissImpDevHisProposalAppr", param);
	}
	
	@Override
	public void createDissImpDevHisProposalApprRew(DissImpDevVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissImpDevHisProposalApprRew", param);
	}
	
	@Override
	public void createDissImpDevHisLevelChgAppr(DissImpDevVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissImpDevHisLevelChgAppr", param);
	}
	
	@Override
	public void updateDissImpDevHis(DissImpDevVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissImpDevHis", param);
	}
	
	@Override
	public void deleteDissImpDevHisAll(DissImpDevVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissImpDevHisAll", param);
	}
	
	@Override
	public DissImpDevVO getDissImpDevHis(DissImpDevVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissImpDevHis", param);
	}
	
	@Override
	public DissImpDevVO getDissImpDevHisDetail(DissImpDevVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissImpDevHisDetail", param);
	}

	@Override
	public List<DissImpDevVO> getDissImpDevListExcelDownload(DissImpDevVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissImpDevListExcelDownload", param);
	}

	@Override
	public void updateLeader(DissImpDevVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateLeader", param);
	}

	@Override
	public List<EmployVO> getEmployByLeaderChange(Map<String, String> map) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getEmployByLeaderChange", map);
	}
}
