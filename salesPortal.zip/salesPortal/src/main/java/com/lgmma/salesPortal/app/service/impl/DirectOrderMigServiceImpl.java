package com.lgmma.salesPortal.app.service.impl;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.dao.DirectOrderMigDao;
import com.lgmma.salesPortal.app.model.DirectOrderMigVO;
import com.lgmma.salesPortal.app.service.DirectOrderMigService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

@Service
public class DirectOrderMigServiceImpl implements DirectOrderMigService {
	private static Logger logger = LoggerFactory.getLogger(DirectOrderMigServiceImpl.class); 
	private final String FNC_SAP_SEARCH_ORDER = "ZSDE02_DISPLAY_ORDER_LIST";

	@Autowired
	private JcoConnector jcoConnector;
    
	@Autowired
	private DirectOrderMigDao directOrderMigDao;

	/**
	 * 주문 SAP 데이타 이관용 임시작업 테이블에 입력
	 */
	@Transactional
	@Override
	public void createDirectOrderMig(DirectOrderMigVO param) {
		param = (DirectOrderMigVO) StringUtil.nullToEmptyString(param);
		String workId	= Util.getUUID();
		param.setWorkId(workId);
		JcoTableParam<?> tableParam = new JcoTableParam<Object>();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		tableParam.put("ET_DATA", paramMap);

		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_SALES_ORG", param.getiSalesOrg()); 
		inputParam.put("I_DISTR_CHAN", param.getiDistrChan()); 
		inputParam.put("I_DOC_DATE_F", param.getiDocDateF()); 
		inputParam.put("I_DOC_DATE_T", param.getiDocDateT()); 
		inputParam.put("I_VBELN", param.getiVbeln()); 
		Map<String, Object> outputParam = new HashMap<String, Object>();

		jcoConnector.executeFunction(FNC_SAP_SEARCH_ORDER, inputParam, outputParam, tableParam, false);

		List<DirectOrderMigVO> directOrderMigVOList = (List<DirectOrderMigVO>) tableParam.get("ET_DATA", DirectOrderMigVO.class);
		logger.debug("#####################################################################################################");
		if(directOrderMigVOList.size() > 0) {
			int i = 0;
			for(DirectOrderMigVO directOrderMigVO : directOrderMigVOList) {
				directOrderMigVO.setWorkId(workId);
				directOrderMigVO.setiSalesOrg(param.getiSalesOrg());
				directOrderMigVO.setiDistrChan(param.getiDistrChan());
				directOrderMigVO.setiDocDateF(param.getiDocDateF());
				directOrderMigVO.setiDocDateT(param.getiDocDateT());
				directOrderMigVO.setiVbeln(param.getiVbeln());
				directOrderMigVO.setRegiIdxx("MIG");
				logger.debug(i + directOrderMigVO.toString());
				i++;
				directOrderMigDao.createDirectOrderMig(directOrderMigVO);
			}
			if(!param.getProcExcuteYn().equals("N")){
				createDirectOrderMigTrans(param);
			}
		}
		logger.debug("#####################################################################################################");
	}

	/**
	 * 주문 이관용 임시작업 테이블의 내역을 주문테이블에 이관적용
	 * 프로시져로 처리
	 */
	@Transactional
	@Override
	public void createDirectOrderMigTrans(DirectOrderMigVO param) {
		directOrderMigDao.createDirectOrderMigTrans(param);
		logger.debug("######param.getrErrcode()	["+param.getR_ERRCODE()+"]");
		logger.debug("######param.getrErrmesg()	["+param.getR_ERRMESG()+"]");
		if(!"0".equals(param.getR_ERRCODE())){
			throw new ServiceException(param.getR_ERRCODE(),param.getR_ERRMESG());
		}
	}

}
