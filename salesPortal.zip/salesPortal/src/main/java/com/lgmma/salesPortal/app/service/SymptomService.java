package com.lgmma.salesPortal.app.service;
import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.CustomerCreditAssessInquiryVO;
import com.lgmma.salesPortal.app.model.SalesPriceChageRateVO;
import com.lgmma.salesPortal.app.model.SalesTrendByProdAccontVO;


public interface SymptomService {
		
	int getSalesPriceChageRateListCount(SalesPriceChageRateVO param);

	List <SalesPriceChageRateVO> getSalesPriceChageRateList(SalesPriceChageRateVO param) throws Exception;
		
	int getSalesTrendByProdAccontCount(SalesTrendByProdAccontVO param);
	
	List <SalesTrendByProdAccontVO> getSalesTrendByProdAccontList(SalesTrendByProdAccontVO param) throws Exception;
	
	List <CustomerCreditAssessInquiryVO> getCustomerCreditAssessInquiryList (CustomerCreditAssessInquiryVO param) throws Exception;
	
	Map<String, Object> getCustomerCreditAssessReport (CustomerCreditAssessInquiryVO param) throws Exception;
	
	int getCustomerCreditAssessInquiryCount(CustomerCreditAssessInquiryVO param);
}
