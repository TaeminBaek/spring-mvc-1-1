package com.lgmma.salesPortal.app.model;

public class VocSendMailToCustVO extends PagingParamVO {
	//VOC ACT 등록시 고객 메일발송
	private String reqxDate;
	private String reqxHour;
	private String regiDate;
	private String titlText;
	private String contText;
	private String longText1;
	private String actxName;
	private String srvcName;
	private String divxName;
	private String toMail;
	private String vocxIdxx;
	
	public String getReqxDate() {
		return reqxDate;
	}
	public void setReqxDate(String reqxDate) {
		this.reqxDate = reqxDate;
	}
	public String getReqxHour() {
		return reqxHour;
	}
	public void setReqxHour(String reqxHour) {
		this.reqxHour = reqxHour;
	}
	public String getRegiDate() {
		return regiDate;
	}
	public void setRegiDate(String regiDate) {
		this.regiDate = regiDate;
	}
	public String getTitlText() {
		return titlText;
	}
	public void setTitlText(String titlText) {
		this.titlText = titlText;
	}
	public String getContText() {
		return contText;
	}
	public void setContText(String contText) {
		this.contText = contText;
	}
	public String getLongText1() {
		return longText1;
	}
	public void setLongText1(String longText1) {
		this.longText1 = longText1;
	}
	public String getActxName() {
		return actxName;
	}
	public void setActxName(String actxName) {
		this.actxName = actxName;
	}
	public String getSrvcName() {
		return srvcName;
	}
	public void setSrvcName(String srvcName) {
		this.srvcName = srvcName;
	}
	public String getDivxName() {
		return divxName;
	}
	public void setDivxName(String divxName) {
		this.divxName = divxName;
	}
	public String getToMail() {
		return toMail;
	}
	public void setToMail(String toMail) {
		this.toMail = toMail;
	}
	public String getVocxIdxx() {
		return vocxIdxx;
	}
	public void setVocxIdxx(String vocxIdxx) {
		this.vocxIdxx = vocxIdxx;
	}

	
}
