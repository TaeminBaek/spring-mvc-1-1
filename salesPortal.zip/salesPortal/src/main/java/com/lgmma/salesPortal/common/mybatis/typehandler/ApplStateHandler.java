package com.lgmma.salesPortal.common.mybatis.typehandler;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.ibatis.type.StringTypeHandler;

import com.lgmma.salesPortal.common.props.ApplState;

public class ApplStateHandler extends StringTypeHandler {
	@Override
	public String getNullableResult(ResultSet rs, String columnName) throws SQLException {
		return getResult(rs.getString(columnName));
	}

	@Override
	public String getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
		return getResult(rs.getString(columnIndex));
	}

	@Override
	public String getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
		return getResult(cs.getString(columnIndex));
	}

	public String getResult(String applState) throws SQLException {
		return applState == null ? "" : ApplState.getApplState(applState).getName();
	}

}
