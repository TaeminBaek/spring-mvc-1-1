package com.lgmma.salesPortal.app.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.service.GportalPostProcess;

@Service
public class GportalPostProcessImpl implements GportalPostProcess {

	private static Logger logger = LoggerFactory.getLogger(GportalPostProcessImpl.class); 

	@Override
	public void saveApprId(ApprVO apprVO) {
		logger.debug("#####[saveApprId Temp & don't work]");
	}

	@Override
	public void deleteApprId(ApprVO apprVO) {
		logger.debug("#####[deleteApprId Temp & don't work]");
	}

	@Override
	public void completeProcess(ApprVO apprVO) {
		logger.debug("#####[completeProcess Temp & don't work]");
	}

	@Override
	public void rejectProcess(ApprVO apprVO) {
		logger.debug("#####[rejectProcess Temp & don't work]");
	}

	@Override
	public String getApprContent(String keyId) {
		logger.debug("#####[getApprContent Temp & don't work]");
		return "";
	}

}
