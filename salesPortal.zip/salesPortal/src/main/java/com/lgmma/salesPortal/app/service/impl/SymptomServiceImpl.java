package com.lgmma.salesPortal.app.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.dao.SymptomDao;
import com.lgmma.salesPortal.app.model.CustomerCreditAssessInquiryVO;
import com.lgmma.salesPortal.app.model.SalesPriceChageRateVO;
import com.lgmma.salesPortal.app.model.SalesTrendByProdAccontVO;
import com.lgmma.salesPortal.app.service.SymptomService;

@Transactional
@Service
public class SymptomServiceImpl implements SymptomService {

	@Autowired
	private SymptomDao symptomDao;

	@Override
	public int getSalesPriceChageRateListCount(SalesPriceChageRateVO param) {
		return symptomDao.getSalesPriceChageRateListCount(param);
	}

	@Override
	public List<SalesPriceChageRateVO> getSalesPriceChageRateList(SalesPriceChageRateVO param) throws Exception {
		return symptomDao.getSalesPriceChageRateList(param);
	}

	@Override
	public int getSalesTrendByProdAccontCount(SalesTrendByProdAccontVO param) {
		return symptomDao.getSalesTrendByProdAccontCount(param);
	}

	@Override
	public List<SalesTrendByProdAccontVO> getSalesTrendByProdAccontList(SalesTrendByProdAccontVO param)
			throws Exception {
		return symptomDao.getSalesTrendByProdAccontList(param);
	}

	@Override
	public int getCustomerCreditAssessInquiryCount(CustomerCreditAssessInquiryVO param) {
		return symptomDao.getCustomerCreditAssessInquiryCount(param);
	}

	@Override
	public List<CustomerCreditAssessInquiryVO> getCustomerCreditAssessInquiryList(CustomerCreditAssessInquiryVO param)
			throws Exception {
		return symptomDao.getCustomerCreditAssessInquiryList(param);
	}

	@Override
	public Map<String, Object> getCustomerCreditAssessReport(CustomerCreditAssessInquiryVO param) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		// 기본정보
		returnMap.put("BASE_INFO", symptomDao.getCustomerBaseInfo(param));
		// 평가정보
		returnMap.put("CREDIT_RATING", symptomDao.getCustomerCreditRating(param));
		// 주요주주
		returnMap.put("STOCK_HOLDER", symptomDao.getCustomerStockHolder(param));
		// 재무정보
		returnMap.put("FINANCIAL_INFO", symptomDao.getCustomerFinancialInfo(param));
		// 재무비율
		returnMap.put("FINANCIAL_RATIO", symptomDao.getCustomerFinancialRatio(param));
		// 관계회사
		returnMap.put("RELATED_COMPANY", symptomDao.getRelatedCompany(param));
		// 주요거래처
		returnMap.put("MAJOR_CUSTOMER", symptomDao.getCustomerMajorCustomer(param));
		return returnMap;
	}
}
