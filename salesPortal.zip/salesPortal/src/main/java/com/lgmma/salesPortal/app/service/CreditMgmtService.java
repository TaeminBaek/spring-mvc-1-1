package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.CompDamboVO;
import com.lgmma.salesPortal.app.model.CreditDomesticVO;
import com.lgmma.salesPortal.app.model.CreditExportVO;
import com.lgmma.salesPortal.app.model.CreditGradeReportVO;
import com.lgmma.salesPortal.app.model.CustomerCreditListVO;
import com.lgmma.salesPortal.app.model.DomesticDelayCreditVO;
import com.lgmma.salesPortal.app.model.ExportDelayCreditVO;
import com.lgmma.salesPortal.app.model.PartnerCreditVO;
import com.lgmma.salesPortal.app.model.RiskCreditVO;

public interface CreditMgmtService {
	

	List<String> getKunnr(String param);
	
	List<CustomerCreditListVO> getCustomerCreditList(CustomerCreditListVO param);
	
	List<CreditDomesticVO> getCreditDomesticList(CreditDomesticVO param);
	
	List<CreditExportVO> getCreditExportList(CreditExportVO param);
	
	List<RiskCreditVO> getRiskyCreditList(RiskCreditVO param);
	
	List<DomesticDelayCreditVO> getDomesticDelayCreditList(DomesticDelayCreditVO param);
	
	List<ExportDelayCreditVO> getExportDelayCreditList(ExportDelayCreditVO param);
	
	int getCreditGradeReportListCount(CreditGradeReportVO param);
	
	List<CreditGradeReportVO> getCreditGradeReportList(CreditGradeReportVO param);
	
	List<CreditGradeReportVO> getErpCreditInfo(CreditGradeReportVO param);
	
	int getErpDamboInfoCount(CompDamboVO param);
	
	List<CompDamboVO> getErpDamboInfo(CompDamboVO param);
	
	List<PartnerCreditVO> getParterCreditInfo(PartnerCreditVO param);
	
	List<PartnerCreditVO> getParterCreditHoldInfo(PartnerCreditVO param);
	
	List<PartnerCreditVO> getParterCreditExpiredInfo(PartnerCreditVO param);
	
	List<PartnerCreditVO> getParterCreditCashInfo(PartnerCreditVO param);
	
	List<PartnerCreditVO> getParterCreditBillInfo(PartnerCreditVO param);
}
