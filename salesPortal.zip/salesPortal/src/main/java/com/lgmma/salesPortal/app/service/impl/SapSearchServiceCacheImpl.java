package com.lgmma.salesPortal.app.service.impl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.CustomerCreditListVO;
import com.lgmma.salesPortal.app.model.WorkStatVO;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.app.service.SapSearchServiceCache;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.model.DDLBItem;
import com.lgmma.salesPortal.common.model.SapMasterCode;
import com.lgmma.salesPortal.common.props.Vkorg;

@Service
public class SapSearchServiceCacheImpl implements SapSearchServiceCache {
	private static Logger logger = LoggerFactory.getLogger(SapSearchServiceCacheImpl.class); 
	private final String FNC_SAP_MASTER_CODE = "ZSDE01_MASTER_CODE";		// SAPCODE 가져오기
	private final String FNC_SAP_MAIN_MONTLY_PROFIT = "ZCO_TABLE_PA";		// 메인화면 월별 영업이익
	private final String FNC_SAP_CREDITLIST = "ZSD_CUSTOMER_CREDIT_LIST";	// 채권현황
	
	@Autowired
	private JcoConnector jcoConnector;

	@Autowired
	private CompanyDao companyDao;
	/**
	 * <pre>
	 *  마스터 코드 정보 조회-복수값
	 * -----------------------------------------------
	 *  필수 입력   GUBUN
	 * -----------------------------------------------
	 *	영업조직		01			계정지정그룹	08
	 *	사업장			02			계정그룹		09  
	 *	영업그룹		03			고객그룹1		10  
	 *	플랜트			04			고객그룹2		11  
	 *	제품군			05			고객그룹3		12  
	 *	국가			06			고객그룹4		13  
	 *	운송지역구분	07			고객그룹5		14 
	 *	저장위치		15			자재그룹1		17
	 *	자재그룹2		18			자재그룹3		19
	 *	오더사유		22			출하조건		23
	 *	유통경로		24			영업지역		25
	 *	통화			26			자재번호		27
	 *	지급조건키		28			가격리스트		29
	 *	인도조건		30			운송경로		31
	 *	부킹요청		32			운송수단		33
	 *------------------------------------------------
	 * </pre>
	 *
	 * @param   gubun    필수입력 구분자 - "01", "01,02,03" 형태
	 * @return  마스코 코드명, 코드정보를 담은 배열 반환	 
	 */
	
	@Cacheable( cacheNames="sapRfcCommonCodeCache" , key="#root.methodName.concat('-').concat(#zgubun)")
	@Override
	public List<DDLBItem> getSapCommonCodeListCache(String zgubun) {
		List<DDLBItem> returnItems = new ArrayList<DDLBItem>();
		List<SapMasterCode> items = null;
		JcoTableParam tableParam = new JcoTableParam();

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("SIGN"		, "I");
		paramMap.put("OPTION"	, "EQ");
		paramMap.put("LOW"		, zgubun);
		paramMap.put("HIGH"		, null);
		tableParam.put("GUBUN", paramMap);

		jcoConnector.executeFunction(FNC_SAP_MASTER_CODE, tableParam);
		items = (List<SapMasterCode>) tableParam.get("T_CODE01", SapMasterCode.class);
		for(SapMasterCode item : items) {
			if(item == null) continue;
			DDLBItem tranItem = new DDLBItem();
			tranItem.setCode(item.getZcode());			// 코드
			tranItem.setText(item.getZtext().trim());	// 명
			tranItem.setCodeNum2(item.getZgubun());		// 코드구분
			if(!tranItem.getText().equals(""))
				returnItems.add(tranItem);
		}
		return returnItems;
	}
	
	@Cacheable( cacheNames="sapRfcHomeChartCache",  key="#root.methodName.concat('-').concat(#year).concat('-').concat(#month)")
	@Override
	public Map<String, WorkStatVO> getNetProfitListCache(String year, String month) {
			Map<String, WorkStatVO> monthlyProfitMap = new HashMap<String, WorkStatVO>();
		
			JcoTableParam tableParam = new JcoTableParam();
			Map<String, Object> paramMap = new HashMap<String, Object>();
			
			Map<String, Object> inputParam = new HashMap<String, Object>();
			inputParam.put("I_GJAHR", year); //년도
			inputParam.put("I_PERDE", month);  //월
			
			Map<String, Object> outputParam = new HashMap<String, Object>();
			
			jcoConnector.executeFunction(FNC_SAP_MAIN_MONTLY_PROFIT, inputParam, outputParam, tableParam);

			HashMap<String, List<WorkStatVO>> profitMap = new HashMap<String, List<WorkStatVO>>();
			List<WorkStatVO> monthlyPmmaProfit = (List<WorkStatVO>) tableParam.get("ET_PMMAG", WorkStatVO.class);
			double monthlyPmmaZyuyy = Math.round(Double.parseDouble(monthlyPmmaProfit.get(0).getZyuyy())/1000000);
			monthlyPmmaProfit.get(0).setZyuyy(String.valueOf(monthlyPmmaZyuyy));
			
			List<WorkStatVO> monthlyMmaProfit = (List<WorkStatVO>) tableParam.get("ET_MMA", WorkStatVO.class);
			double monthlyMmaZyuyy = Math.round(Double.parseDouble(monthlyMmaProfit.get(0).getZyuyy())/1000000);
			monthlyMmaProfit.get(0).setZyuyy(String.valueOf(monthlyMmaZyuyy));
			
			monthlyProfitMap.put("monthlyPmmaProfit", monthlyPmmaProfit.get(0));
			monthlyProfitMap.put("monthlyMmaProfit", monthlyMmaProfit.get(0));
		
		return monthlyProfitMap;
	}
	@Override
	public List<String> getKunnr(String param) {
		return companyDao.getKunnr(param);
	}
	
	@Cacheable( cacheNames="sapRfcCommonCodeCache",  key="#root.methodName.concat('-').concat(#gjahr).concat('-').concat(#gsber).concat('-').concat(#vtweg).concat('-').concat(#name1)")
	@Override
	public List<CustomerCreditListVO> getCustomerCreditListCache(String gjahr
																 ,String gsber
																 ,String vtweg
																 ,String name1) {
		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_GAAP","X"); //X:K-GAAP, 공백:IFRS
		logger.debug("######I_GAAP	["+"X"+"]");
		inputParam.put("I_GJAHR", gjahr.replace(".", "").trim());//회계년월
		logger.debug("######I_GJAHR	["+gjahr.replace(".", "")+"]");
		
		
		//영업조직
		if (!(gsber == null || gsber.equals(""))) {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("SIGN", "I");
			paramMap.put("OPTION", "EQ");
			paramMap.put("LOW", gsber);
			paramMap.put("HIGH", null);
			tableParam.put("R_GSBER", paramMap);
		} else {
			List<Map> gsberMapList = new ArrayList<Map>();
			for (Vkorg org : Vkorg.values()) {
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("SIGN", "I");
				paramMap.put("OPTION", "EQ");
				paramMap.put("LOW", org.getCode());
				paramMap.put("HIGH", null);
				gsberMapList.add(paramMap);
			}
			tableParam.put("R_GSBER", gsberMapList);
		}
		
		//유통경로
		if (!(vtweg == null || vtweg.equals(""))) {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("SIGN", "I");
			paramMap.put("OPTION", "EQ");
			paramMap.put("LOW", vtweg);
			paramMap.put("HIGH", null);
			tableParam.put("R_VTWEG", paramMap);
		}
		
		//고객코드
		if (!(name1 == null || name1.equals(""))) {
			List<String> kunnrList = getKunnr(name1);
			List<Map> kunnrMapList = new ArrayList<Map>();
			for (int i = 0; i < kunnrList.size(); i++) {
				Map kunnrMap = new HashMap<String, Object>();
				kunnrMap.put("SIGN", "I");
				kunnrMap.put("OPTION", "EQ");
				kunnrMap.put("LOW", kunnrList.get(i));
				logger.debug("##################kunnrList.get(i)####"+kunnrList.get(i)+"]");
				kunnrMap.put("HIGH", null);
				kunnrMapList.add(kunnrMap);
			}
			tableParam.put("R_KUNNR", kunnrMapList);
		}
		
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_CREDITLIST, inputParam, outputParam, tableParam);
		
		//tableParam 디버깅
		logger.debug("######tableParams");
		List<Object> aList = (List<Object>) tableParam.get("R_GSBER");
		if(aList != null) {
			for(int i=0 ;i<aList.size(); i++) {
				logger.debug("######R_GSBER SIGN	["+((Map)aList.get(i)).get("SIGN")+"]");
				logger.debug("######R_GSBER OPTION	["+((Map)aList.get(i)).get("OPTION")+"]");
				logger.debug("######R_GSBER LOW	["+((Map)aList.get(i)).get("LOW")+"]");
				logger.debug("######R_GSBER HIGH	["+((Map)aList.get(i)).get("HIGH")+"]");
				logger.debug("###########################");
			}
		}
		List<Object> bList = (List<Object>) tableParam.get("R_VTWEG");
		if(bList != null) {
			for(int i=0 ;i<bList.size(); i++) {
				logger.debug("######R_VTWEG SIGN	["+((Map)bList.get(i)).get("SIGN")+"]");
				logger.debug("######R_VTWEG OPTION	["+((Map)bList.get(i)).get("OPTION")+"]");
				logger.debug("######R_VTWEG LOW	["+((Map)bList.get(i)).get("LOW")+"]");
				logger.debug("######R_VTWEG HIGH	["+((Map)bList.get(i)).get("HIGH")+"]");
				logger.debug("###########################");
			}
		}
		List<Object> cList = (List<Object>) tableParam.get("R_KUNNR");
		if(cList != null) {
			for(int i=0 ;i<cList.size(); i++) {
				logger.debug("######R_KUNNR(" +i+	")");
				logger.debug("######R_KUNNR SIGN	["+((Map)cList.get(i)).get("SIGN")+"]");
				logger.debug("######R_KUNNR OPTION	["+((Map)cList.get(i)).get("OPTION")+"]");
				logger.debug("######R_KUNNR LOW	["+((Map)cList.get(i)).get("LOW")+"]");
				logger.debug("######R_KUNNR HIGH	["+((Map)cList.get(i)).get("HIGH")+"]");
				logger.debug("###########################");
			}
		}
		
		List<CustomerCreditListVO> list = (List<CustomerCreditListVO>) tableParam.get("T_LIST", CustomerCreditListVO.class);
		
		return list;
	}
}
