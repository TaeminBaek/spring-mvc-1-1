package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.HighValueGoalVO;
import com.lgmma.salesPortal.app.service.DirectOrderService;
import com.lgmma.salesPortal.app.service.HighValueMgmtService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.Util;


//org.springframework.security.web.access.ExceptionTranslationFilter
@Controller
@RequestMapping("/highValue") 
public class HighValueController {
	
	@Autowired
	CommonController commonController;
	
	@Autowired
	HighValueMgmtService highValueMgmtService;
	
	@Autowired
	DirectOrderService directOrderService; 

	@RequestMapping(value = "/highValueItemMgmt")
	public ModelAndView highValueItemMgmt(ModelAndView mav) throws Exception {
		mav.setViewName("highValue/highValueItemMgmt");
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));                         
		mav.addObject("orderTypeList", OrderType.getHighValueDirectOrderTypeList());
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		ObjectMapper mapper = new ObjectMapper();
		CommonCodeVO commonCodeVO = new CommonCodeVO();
		commonCodeVO.setGrupCode("HVALUEMMA");
		mav.addObject("HVALUEMMA", mapper.writeValueAsString(commonController.getCode(commonCodeVO).get("items")));
		commonCodeVO.setGrupCode("HVALUEPMMA");
		mav.addObject("HVALUEPMMA", mapper.writeValueAsString(commonController.getCode(commonCodeVO).get("items")));
		return mav;
	}

	@RequestMapping(value = "/getHighValueItemList.json")
	public Map getHighValueItemList(@RequestBody(required = true) DirectOrderMasterVO param) throws Exception {
		param.setOrderTypeList(OrderType.getHighValueDirectOrderTypeList());
		List<DirectOrderMasterVO> storeData = directOrderService.getDirectOrderMasterItemList(param);
		List<HighValueGoalVO> hValueComboList = getHighValueComboList(storeData);
		return JsonResponse.asSuccess("itemsCount", directOrderService.getDirectOrderMasterItemListCount(param), "storeData", storeData
				,"hValueComboList", hValueComboList);
	}
	/**
	 * 
	 * <pre>
	 * 주문-고부가항목 콤보 리스트 받아오기
	 * </pre>
	 * 
	 * @param orderList
	 * @return hValueComboList
	 * 
	 */
	public List<HighValueGoalVO> getHighValueComboList(List<DirectOrderMasterVO> orderList){
		List<HighValueGoalVO> hValueComboList = new ArrayList<HighValueGoalVO>(); // return list
		Map<String, HighValueGoalVO> paramMap = new HashMap<String, HighValueGoalVO>();
		for(DirectOrderMasterVO orderVO : orderList) {
			//코드 조회 위한 VO - 년도, 영업조직, 코드그룹 값 필요
			HighValueGoalVO hValueVO = new HighValueGoalVO();
			hValueVO.setYyyy(orderVO.getChkWadatIst().substring(0, 4)); 
			hValueVO.setVkorg(orderVO.getSalesOrg().trim());
			hValueVO.setGrupCode("HVALUE"+orderVO.getSalesOrgText().trim());
			paramMap.put(hValueVO.getYyyy() + "_" + hValueVO.getVkorg(), hValueVO);
		}

		Iterator<String> ite = paramMap.keySet().iterator();
		while(ite.hasNext()) {
			String key = ite.next();
			HighValueGoalVO param = paramMap.get(key);
			HighValueGoalVO hValueVO = new HighValueGoalVO();
			hValueVO.setComboType(key);
			hValueVO.setComboList(highValueMgmtService.getHighValueGoalList(param));
			hValueComboList.add(hValueVO);
		}
		return hValueComboList;
	}
	
	@RequestMapping(value = "/updateHighValue.json")
	public Map updateHighValue(@RequestBody(required = true) List<DirectOrderItemVO> paramList) throws Exception {
		highValueMgmtService.updateHighValue(paramList);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/highValueCgMgmt")
	public ModelAndView highValueCgMgmt(ModelAndView mav) throws Exception {
		mav.setViewName("system/highValueCgMgmt");
		mav.addObject("currentYear", Util.getToday("YYYY"));
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		return mav;
	}
	
	@RequestMapping(value = "/getHighValueCGList.json")
	public Map getHighValueCGList(@RequestBody HighValueGoalVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", highValueMgmtService.getHighValueGoalCount(param), "storeData",
				highValueMgmtService.getHighValueGoalList(param));
	}
	
	@RequestMapping(value = "/getHighValueCodeList.json")
	public Map getHighValueCodeList(@RequestBody HighValueGoalVO param) throws Exception {
		List<CommonCodeVO> returnList = highValueMgmtService.getHighValueCodeList(param);
		return JsonResponse.asSuccess("storeData", returnList);
	}
	
	@RequestMapping(value = "/getYearHighValueCodeList.json")
	public Map getYearHighValueCodeList(@RequestBody HighValueGoalVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", highValueMgmtService.getYearHighValueCodeList(param));
	}
	
	@RequestMapping(value = "/createHighValueGoal.json")
	public Map createHighValueGoal(@RequestBody(required = true) List<HighValueGoalVO> paramList) throws Exception {
		highValueMgmtService.createHighValueGoal(paramList);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/updateHighValueGoal.json")
	public Map updateHighValueGoal(@RequestBody(required = true) List<HighValueGoalVO> paramList) throws Exception {
		highValueMgmtService.updateHighValueGoal(paramList);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/deleteHighValueGoal.json")
	public Map deleteHighValueGoal(@RequestBody(required = true) HighValueGoalVO param) throws Exception {
		highValueMgmtService.deleteHighValueGoal(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
}
