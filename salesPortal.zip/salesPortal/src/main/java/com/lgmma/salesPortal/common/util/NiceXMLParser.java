package com.lgmma.salesPortal.common.util;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
public class NiceXMLParser {

	private static Logger logger = LoggerFactory.getLogger(NiceXMLParser.class); 
	public static HashSecurity md5 = new HashSecurity();

	public static HashMap readXml(String[] nodeNames, String biznum) throws IOException {
		
		String uid = "lgmma";
		String pwd = "1242";
		String strUrl = "http://w.datapoint.co.kr/tower/lookup/lookup.info?uid="+uid;

		String apikey = URLEncoder.encode(md5.getMD5(uid + md5.getMD5(pwd)+ new SimpleDateFormat("yyyyMMdd").format(new Date())),"UTF-8");

		HashMap xml = new HashMap();

		strUrl = strUrl+"&apikey="+apikey+"&pkg=G05001&business="+biznum+"&cid=lgmma";
		try {
			if(CheckURL(strUrl)==1)
				xml = getXml(strUrl,nodeNames, biznum);
		} catch (Exception ex){
			logger.error(ex.getMessage());
		}

		return xml;
	}

	public static HashMap getXml(String strUrl, String[] targetNames, String biznum){
		HashMap resultMap = new HashMap();
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		try {
			DocumentBuilder newDocumentBuilder = factory.newDocumentBuilder();

			URL url = new URL(strUrl);
			URLConnection conn = url.openConnection();
			
			Document doc = newDocumentBuilder.parse(conn.getInputStream());
			Element element = doc.getDocumentElement();
			
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			StreamResult res = new StreamResult(new StringWriter());
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(new DOMSource(doc), res);

			resultMap.put("XML", res.getWriter().toString());
			resultMap.put("URL", strUrl);

			//�ֻ������ LA >> Items >> Item
			NodeList list0318 = (NodeList)element.getElementsByTagName("LA0318");
			Node node0318 = list0318.item(0);
			if("1".equals(node0318.getChildNodes().item(1).getAttributes().getNamedItem("count").getNodeValue())){
				NamedNodeMap nMap0318 = node0318.getChildNodes().item(1).getChildNodes().item(1).getAttributes();
				Node nd0318 = nMap0318.getNamedItem("grade");
				resultMap.put("KIS_GRADE", nd0318.getNodeValue());
			}else{
				resultMap.put("KIS_GRADE",  " ");
			}

			NodeList list0320 = (NodeList)element.getElementsByTagName("LA0320");
			Node node0320 = list0320.item(0);
			if("1".equals(node0320.getChildNodes().item(1).getAttributes().getNamedItem("count").getNodeValue())){
				NamedNodeMap nMap0320 = node0320.getChildNodes().item(1).getChildNodes().item(1).getAttributes();
				Node nd0320 = nMap0320.getNamedItem("watch_dcls_grdnm");
				Node nd0320_1 = nMap0320.getNamedItem("watchgrd");
				resultMap.put("WATCH_GRADE", nd0320.getNodeValue());
				resultMap.put("WATCH_GRADE_CODE", nd0320_1.getNodeValue());
				if(!nMap0320.getNamedItem("bizno").getNodeValue().equals(biznum))
					resultMap.put("ERROR", "사업자번호 오류 req:["+biznum+"] res:["+nMap0320.getNamedItem("bizno").getNodeValue()+"]");
			}else{
				resultMap.put("WATCH_GRADE", " ");
				resultMap.put("WATCH_GRADE_CODE", " ");
				
			}
			

			NodeList list0304 = (NodeList)element.getElementsByTagName("LA0304");
			Node node0304 = list0304.item(0);
			if("1".equals(node0304.getChildNodes().item(1).getAttributes().getNamedItem("count").getNodeValue())){
				NamedNodeMap nMap0304 = node0304.getChildNodes().item(1).getChildNodes().item(1).getAttributes();
				Node nd0304 = nMap0304.getNamedItem("grade");
				resultMap.put("CF_GRADE", nd0304.getNodeValue());	
			}else{
				resultMap.put("CF_GRADE","999");
			}

			
			NodeList list1001 = (NodeList)element.getElementsByTagName("LA1001");
			Node node1001 = list1001.item(0);
			NamedNodeMap nMap1001 = node1001.getChildNodes().item(1).getAttributes();
			Node nd1001 = nMap1001.getNamedItem("count");
			resultMap.put("OT_STOP", nd1001.getNodeValue());	
			
			
			NodeList list1002 = (NodeList)element.getElementsByTagName("LA1002");
			Node node1002 = list1002.item(0);
			NamedNodeMap nMap1002 = node1002.getChildNodes().item(1).getAttributes();
			Node nd1002 = nMap1002.getNamedItem("count");
			resultMap.put("ST_MG", nd1002.getNodeValue());	
			

/*           
            NodeList nodeList = (NodeList)element.getElementsByTagName("item");
            for(int i=0, len=nodeList.getLength(); i<len; i++) {
                Node node = nodeList.item(i);
                System.out.println("nodename:"+node.getNodeName());
                System.out.println("getAttributes$$$:"+node.getAttributes());

                String[] map = StringUtil.split(node.getAttributes().toString(),"\" ");
                for(int j=0, maplen=map.length; j<maplen;j++){
                	System.out.println(j+": "+StringUtil.replace(map[j], "\"", ""));
                	String[] attribute = StringUtil.replace(map[j], "\"", "").split("=");
                	if(attribute.length>1){
                		resultMap.put(attribute[0].trim(), attribute[1]);
                    	attributeName = attribute[0].trim(); 
                    	System.out.println("attributeName :: "+attributeName);
                    	attributeValue = attribute[1];
                	}else{
                		resultMap.put(attribute[0].trim(), "");
                    	attributeName = attribute[0].trim(); 
                    	attributeValue = "";
                	}
                	System.out.println(attributeName+":"+attributeValue);

                	for(int k=0; k<targetNames.length; k++){
                		if(targetNames[k].equals(attributeName)){
                			System.out.println("targetNames [k] :: "+targetNames[k]);
                			resultMap.put(attributeName, attributeValue);
                		}
                	}

                }
            }
*/

		} catch (Exception ex) {}

		return resultMap;
	}


	public static int CheckURL(String url) {	// result 0:�̻� ���� , 1:�̻����
		int result = 0;
		HttpClient client = new HttpClient();
		GetMethod method = null;
		int statusCode = 0;

		try {
			method = new GetMethod(url);
			method.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, new DefaultHttpMethodRetryHandler(3, false));
			statusCode = client.executeMethod( method );
			if( statusCode == HttpStatus.SC_OK ) {
				result = 1;
			}
		} catch( UnknownHostException e ) {
			logger.error(e.getMessage());
		} catch( Exception e ) {
			e.printStackTrace();
		}finally{
			method.releaseConnection();
		}
		return result;
	}

}
