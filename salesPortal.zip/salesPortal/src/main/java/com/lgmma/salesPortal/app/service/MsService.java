package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.IcisVO;

public interface MsService {
	public List<IcisVO> getIcisList(IcisVO param);
}
