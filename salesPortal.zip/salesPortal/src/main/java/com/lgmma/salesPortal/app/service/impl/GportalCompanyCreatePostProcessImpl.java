package com.lgmma.salesPortal.app.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.CompOrganEditVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.model.NewCompOrganEditVO;
import com.lgmma.salesPortal.app.model.OrganVO;
import com.lgmma.salesPortal.app.model.SmsVO;
import com.lgmma.salesPortal.app.service.CompanyService;
import com.lgmma.salesPortal.app.service.GportalPostProcess;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.app.service.SmsService;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.util.StringUtil;

import freemarker.template.Configuration;

@Transactional
@Service
public class GportalCompanyCreatePostProcessImpl implements GportalPostProcess {

	private static Logger logger = LoggerFactory.getLogger(GportalCompanyCreatePostProcessImpl.class); 

	private final String REPORT_TEMPLATE_COMP_CREATE = "REPORT_TEMPLATE_COMP_CREATE";

	private final String FNC_SAP_CUSTOMER_CREATE = "ZSDE01_CUSTOMER_CREATE";
	private final String FNC_SAP_CUSTOMER_CHANGE1 = "ZSDE01_CUSTOMER_CHANGE1";
	private final String FNC_SAP_CUSTOMER_CHANGE2 = "ZSDE01_CUSTOMER_CHANGE2";

	@Autowired
	private JcoConnector jcoConnector;
	
	@Autowired
	private SmsService smsService;

	@Autowired
	private CompanyDao companyDao;

	@Autowired
	private SapSearchService sapSearchService;

	@Autowired
	private CommonFileServiceImpl commonFileService;

	@Autowired
	private CompanyService companyService;

    @Autowired
    @Qualifier(value="reportFreemarkerConfiguration")
    private Configuration reportTemplateConfiguration;

	@Autowired
    private PlatformTransactionManager transactionManager;

    @Override
	public void saveApprId(ApprVO apprVO) {
		CompOrganEditVO param = new CompOrganEditVO();
		param.setCompEditId(apprVO.getKeyId());
		param.setApprId(apprVO.getApprId());
		companyDao.updateCompOrgEditApprId(param);
	}

	@Override
	public void deleteApprId(ApprVO apprVO) {
		CompOrganEditVO param = new CompOrganEditVO();
		param.setApprId(apprVO.getApprId());
		companyDao.updateCompOrgEditIdToNull(param);
	}

	@Override
	public void completeProcess(ApprVO apprVO) {
		DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
		transactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//transaction start
		TransactionStatus tx = transactionManager.getTransaction(transactionDefinition);

		CompanyVO companyVO = null;

		NewCompOrganEditVO param = new NewCompOrganEditVO();
		param.setApprId(apprVO.getApprId());
		NewCompOrganEditVO vo = (NewCompOrganEditVO) StringUtil.nullToEmptyString(companyDao.getCompOrganEditDetail(param));

		if(vo != null) {
			// 타 영업조직에 erp 전송상태가 S 인 건으로 존재하는지 확인 
            // erp에 전송할려는 영업조직은 신규이나 이미 다른 영업조직이 있는 경우는 gubun=B
            // ex) mma를 생성하고자 하는경우 pmma로 생성된 거래선이 있는경우는 영업조직 추가이다.

			Map<String, String> paramMap = new HashMap<String, String>();
			paramMap.put("vkorg", vo.getVkorg());
			paramMap.put("compCode", vo.getCompCode());
			paramMap.put("erpxSend", "S");
			int existCount = companyDao.countOtherOrganExists(paramMap);

			HashMap<String, Object> inputParams = new HashMap<String, Object>();			
			inputParams.put("I_GUBUN", existCount > 0 ? "B" : "A");
			inputParams.put("I_CTRYCD", vo.getExpCntCode());
			inputParams.put("I_BUYRCD", vo.getExpCompCode());

			Map<String, Object> outputParams = new HashMap<String, Object>();
			outputParams.put("E_SUBRC","");

			if(existCount > 0) {	//타조직에 등록된 업체를 다른조직에서 등록할때 일반데이터(주소, 국가, 운송지역 등)는 ZSDE01_CUSTOMER_CREATE 로 변경되지 않는다. 따라서 ZSDE01_CUSTOMER_CHANGE1 를 미리 호출
				callChangeCustomer(vo);
			}
			try {
				JcoTableParam tableParam = new JcoTableParam();
				HashMap<String, Object> companyMap = new HashMap<String, Object>();
				companyMap.put("SALES_ORG", vo.getVkorg());         // 영업조직
				companyMap.put("KUNNR", vo.getKunnr());             // 고객번호
				companyMap.put("PARTN_ROLE", "AG");         // 파트너기능  AG:판매처
				companyMap.put("PARTN_NUMB", existCount > 0 ? vo.getKunnr() : "NEW");   // 고객번호    (신규 고객생성:NEW, 영업조직만 생성:erp코드(kunnr)
				companyMap.put("ADRNR", "");                // 주소
				companyMap.put("TITLE", "");      	       // 경칭
				companyMap.put("NAME", vo.getName1());              // 이름 1
				companyMap.put("NAME2", "");                // 이름 2
				companyMap.put("STREET", vo.getStrasFull());            // 주소    사업장주소
				companyMap.put("COUNTRY", vo.getLand1());           // 국가키
				if(vo.getLand1().equals("KR")){
					companyMap.put("POSTL_CODE", vo.getPostlz());       // 우편번호  사업장우편번호
				}else{//국가선택에 따라 우편번호 null 인경우 SAP에서 error 나서 강제로 국가별로 필수자리로 맞춰서 insert
					if("GB".equals(vo.getLand1())){
						companyMap.put("POSTL_CODE","999999999");  //영국은 필수9자리
					}else if("BR".equals(vo.getLand1())){
						companyMap.put("POSTL_CODE","88888888");  //브라질 8자리 20190226 신규
					}else if("RU".equals(vo.getLand1())||"SE".equals(vo.getLand1())||"IN".equals(vo.getLand1())||"CN".equals(vo.getLand1())||"PL".equals(vo.getLand1())||"SG".equals(vo.getLand1())||"CA".equals(vo.getLand1())){
						companyMap.put("POSTL_CODE","666666");  //러시아, 스웨덴, 인도, 중국, 폴란드, 싱가포르, 캐나다 6자리
					}else if("US".equals(vo.getLand1())||"GR".equals(vo.getLand1())||"MY".equals(vo.getLand1())||"VN".equals(vo.getLand1())||"SA".equals(vo.getLand1())||"UA".equals(vo.getLand1())
						||"IR".equals(vo.getLand1())||"IL".equals(vo.getLand1())||"IT".equals(vo.getLand1())||"ID".equals(vo.getLand1())||"FR".equals(vo.getLand1())||"AE".equals(vo.getLand1())){
						companyMap.put("POSTL_CODE","55555");  //미국,그리스,말레이지아,베트남,사우디,우크라이나,이란,이스라엘,이탈리아,인도네시아,프랑스,아랍에미리트 5자리
					}else if("AR".equals(vo.getLand1())||"TN".equals(vo.getLand1())||"PT".equals(vo.getLand1())||"ZA".equals(vo.getLand1())||"HU".equals(vo.getLand1())){
						companyMap.put("POSTL_CODE","4444"); //아르헨티나,튀니지,포르투갈,남아공,헝가리 4자리
					}else if("TW".equals(vo.getLand1())||"IS".equals(vo.getLand1())||"DZ".equals(vo.getLand1())){
						companyMap.put("POSTL_CODE","333");  //대만,아이슬란드, 알제리
					}else if("LK".equals(vo.getLand1())||"OM".equals(vo.getLand1())||"EG".equals(vo.getLand1())||"TC".equals(vo.getLand1())||"PK".equals(vo.getLand1())||"PE".equals(vo.getLand1())||"HK".equals(vo.getLand1())){
						companyMap.put("POSTL_CODE","1"); //스리랑카,오만,이집트,터어키카이코진,파키스탄,페루,홍콩 1자리이상
					}else{
						companyMap.put("POSTL_CODE",StringUtil.replace(vo.getPostlz(), "-", ""));       // 우편번호  사업장우편번호
					}
				}
				companyMap.put("CITY","");                 // 도시
				companyMap.put("TELEPHONE", vo.getTelf1Full());        // 첫번째 전화번호
				companyMap.put("FAX_NUMBER", vo.getTelfx());        // 팩스번호
				companyMap.put("LANGU", "");                // 언어키
				companyMap.put("TRANSPZONE", vo.getLzone());        // 운송지역 또는 상품납품지역
				companyMap.put("VTEXT", "");                // 설명

				Iterable<String> result = Splitter.fixedLength(10).split(vo.getName1());
				String[] nameParts = Iterables.toArray(result, String.class);
				companyMap.put("SORT1", nameParts[0]);             // 탐색조건 1    탐색용어
				companyMap.put("SORT2", "");         // 탐색조건 2    고객코드
				companyMap.put("REGION", "RE");               // 지역 (주, 지방, 군)
				companyMap.put("SMTP_ADDR", "");            // 인터넷메일 (SMTP) 주소
				companyMap.put("URI_TYPE", "");             // URI 유형플래그
				companyMap.put("URI_LENGTH", "");           // URI 필드길이
				companyMap.put("URI_ADDR", "");             // 일반적 자원 식별자 (URI)

				Map<String, Object> organMap = new HashMap<String, Object>();
				organMap.put("SALES_ORG", vo.getVkorg());         // 영업조직
				organMap.put("KUNNR", vo.getKunnr());             // 고객번호
				organMap.put("PARTN_ROLE", "VE");         // 파트너기능:담당영업사원
				organMap.put("PARTN_NUMB", vo.getSaleMan1());    // 고객번호 :담당영업사원
				organMap.put("ADRNR", "");                // 주소
				organMap.put("TITLE", "");      	       // 경칭
				organMap.put("NAME", "");                 // 이름 1
				organMap.put("NAME2", "");                // 이름 2
				organMap.put("STREET", "");               // 주소    사업장주소
				organMap.put("COUNTRY", "");              // 국가키
				organMap.put("POSTL_CODE", "");           // 우편번호  사업장우편번호
				organMap.put("CITY", "");                 // 도시
				organMap.put("TELEPHONE", "");           // 첫번째 전화번호
				organMap.put("FAX_NUMBER", "");           // 팩스번호
				organMap.put("LANGU", "");                // 언어키
				organMap.put("TRANSPZONE", "");           // 운송지역 또는 상품납품지역
				organMap.put("VTEXT", "");                // 설명
				organMap.put("SORT1", "");                // 탐색조건 1    탐색용어
				organMap.put("SORT2", "");         // 탐색조건 2    고객코드
				organMap.put("REGION", "");               // 지역 (주, 지방, 군)
				organMap.put("SMTP_ADDR", "");            // 인터넷메일 (SMTP) 주소
				organMap.put("URI_TYPE", "");             // URI 유형플래그
				organMap.put("URI_LENGTH", "");           // URI 필드길이
				organMap.put("URI_ADDR", "");             // 일반적 자원 식별자 (URI)
				tableParam.put("T_BAPIPARNR", Arrays.asList(companyMap, organMap));

				Map<String, Object> customer = new HashMap<String, Object>();
				customer.put("PARTN_NUMB", vo.getKunnr());              // 고객번호                                   
				customer.put("SALES_ORG", vo.getVkorg());               // 영업조직                             
				customer.put("DISTR_CHAN", "");                 // 유통경로                             
				customer.put("DIVISION", "");                   // 제품군                               
				customer.put("SALES_DIST", vo.getBzirk());              // 영업지역                             
				customer.put("SALES_OFF", vo.getVkbur());               // 사업장                               
				customer.put("SALES_GRP", vo.getVkgrp());               // 영업그룹                             
				customer.put("CUST_GROUP", "");                 // 고객그룹                             
				customer.put("CURRENCY", vo.getWaers());                // 통화                                 
				customer.put("INCOTERMS1", "");                 // 인도조건 (파트 1)                    
				customer.put("INCOTERMS2", "");                 // 인도조건 (파트 2)                    
				customer.put("PMNTTRMS", "");                   // 지급조건키                           
				customer.put("KKBER", "");                      // 여신관리영역                         
				customer.put("ACCNT_ASGN", vo.getKtgrd());              // 해당고객의 계정지정그룹              
				customer.put("CUST_GRP1", vo.getKvgr1());               // 고객그룹 1                           
				customer.put("CUST_GRP2", vo.getKvgr2());               // 고객그룹 2                           
				customer.put("CUST_GRP3", vo.getKvgr3());               // 고객그룹 3                           
				customer.put("CUST_GRP4", vo.getKvgr4());               // 고객그룹 4                           
				customer.put("CUST_GRP5", vo.getKvgr5());               // 고객그룹 5                           
				customer.put("ERNAM", "");                      // 오브젝트 생성인 이름                 
				customer.put("ERDAT", "");                      // 레코드생성일                         
				customer.put("NAME1", vo.getName1());                   // 이름 1                               
				customer.put("LIFNR", "");                      // 구매처 또는 채권자 계정번호          
				customer.put("VBUND", "");                      // 관계사 ID                            
				customer.put("KONZS", "");                      // 그룹키                               
				customer.put("STCD1", vo.getCeoBirthday());                      // 대표자주민번호                       
				customer.put("STCD2", StringUtil.remove(vo.getStcd2(), '-'));      //사업자등록번호                           
				customer.put("STCEG", vo.getStcd2()); //stcd2           // 사업자등록번호
				customer.put("J_1KFREPRE", vo.getJ1kfrepre());         // 대표자이름                           
				customer.put("CEOFNM", vo.getCeoFullNm().equals("") ? "." : vo.getCeoFullNm());         // 대표자이름1 (1이 있고 2가 없으면 전송오류 발생 . 으로 강제 replace)                          
				customer.put("CEOENM", vo.getCeoEtcNm().equals("") ? "." : vo.getCeoEtcNm());         // 대표자이름 2                          
				customer.put("J_1KFTBUS", vo.getJ1kftbus());           // 사업유형                             
				customer.put("J_1KFTIND", vo.getJ1kftind());           // 산업유형                             
				customer.put("KTOKD", "Z001");                  // 고객계정그룹                         
				customer.put("BRSCH", "");                      // 직종                                 
				customer.put("BRAN1", "");                      // 산업계코드 1                         
				customer.put("BRAN2", "");                      // 산업계코드 2                         
				customer.put("BRAN3", "");                      // 산업계코드 3                         
				customer.put("BRAN4", "");                      // 산업계코드 4                         
				customer.put("BRAN5", "");                      // 산업계코드 5                         
				customer.put("ABLAD", "");                      // 하역지점                             
				customer.put("KNFAK", "");                      // 고객공장달력                         
				customer.put("DEFAB", "");                      // 기본 하역지점                        
				customer.put("KALKS", "");                      // 가격결정절차는 해당 고객에게 지정됐음
				customer.put("MRNKZ", "");                      // 수동송장유지보수     
                customer.put("GRADE", vo.getCompGrade());                           
                customer.put("ZTERM", vo.getMonyCond());                           
                tableParam.put("T_CUSTOMER", customer);

				Map<String, Object> ethics = new HashMap<String, Object>();
				ethics.put("BUKRS", "1000");      //회사 코드                                
//				ethics.put("ZVSEQ", "");      //매핑키                                   
				ethics.put("KUNNR", vo.getKunnr());      //고객 번호 1                              
				ethics.put("ZVNAME", vo.getName1());      //이름 1                                   
				ethics.put("INDTYP", vo.getJ1kftind());      //산업유형                                 
				ethics.put("ZITEM", vo.getTradeItem());      //주요거래품목                             
				ethics.put("ZSPNY", vo.getReportYn());      //신고대상 거래선 여부                     
				ethics.put("ZSPTY", vo.getReportType());      //신고대상 유형                            
				ethics.put("ZSTOCK", vo.getStockYn());      //상장여부                                 
				ethics.put("STCD2", StringUtil.remove(vo.getStcd2(), '-'));      //사업자등록번호                           
				ethics.put("REPRES", vo.getJ1kfrepre());      //대표자 이름                              
				ethics.put("ZDPSCN", vo.getCeoBirthday());      //대표자 주민번호                          
				ethics.put("ZDPLG", vo.getRelationLg());      //대표자와 LG의 관계                       
                tableParam.put("T_ETHICS", ethics);

    			jcoConnector.executeFunction(FNC_SAP_CUSTOMER_CREATE, inputParams, outputParams, tableParam);			

	            // 전송성공:0보다 큰 정수, 실패:-1, 사업자등록번호 중복:0
	            String eReturn = outputParams.get("E_RETURN").toString().trim();
				int rtnCode = Integer.parseInt((outputParams.get("E_SUBRC")).toString());

				if(rtnCode > 0) {	//성공
					logger.debug(eReturn);
					List<Map<String, Object>> buyers = (List) tableParam.get("T_CUSTOMER");
		            vo.setErpxSend("S");

		            companyVO = new CompanyVO();
					companyVO.setCompCode(vo.getCompCode());
					companyVO.setVkorg(vo.getVkorg());
					//null point exception 방지
					companyVO = (CompanyVO) StringUtil.nullToEmptyString(companyDao.getCompanyDetail(companyVO));
					companyVO.setErpRegYn("Y");
					companyVO.setKunnr(StringUtil.isNullToString(buyers.get(0).get("PARTN_NUMB")).trim());
					//ERP전송 전송후 ERP코드와 계정그룹='Z001'를 셋팅
					companyVO.setKtokd("Z001");
					companyVO.setCompCode(vo.getCompCode());
					companyVO.setName1(vo.getName1());
					companyVO.setJ1kfrepre(vo.getJ1kfrepre());
					companyVO.setCeoBirthday(vo.getCeoBirthday());
					companyVO.setStcd2(vo.getStcd2());
					companyVO.setSortl(nameParts[0]);
					companyVO.setLand1(vo.getLand1());
					companyVO.setPostlz(vo.getPostlz());
					companyVO.setStrasPre(vo.getStrasPre());
					companyVO.setStras(vo.getStras());
					companyVO.setPostlz2(vo.getPostlz2());
					companyVO.setStras2Pre(vo.getStras2Pre());
					companyVO.setStras2(vo.getStras2());
					companyVO.setLzone(vo.getLzone());
					companyVO.setTelf1(vo.getTelf1());
					companyVO.setTelfx(vo.getTelfx());
					companyVO.setJ1kftbus(vo.getJ1kftbus());
					companyVO.setJ1kftind(vo.getJ1kftind());
					companyVO.setUmsat(vo.getUmsat());
					companyVO.setJmzah(vo.getJmzah());
					companyVO.setMadeDate(vo.getMadeDate());
					companyVO.setHomePage(vo.getHomePage());
					companyVO.setErpxRegi("Y");
					companyVO.setCompGrade(vo.getCompGrade());
					companyVO.setCreditRating(vo.getCreditRating());
					companyVO.setLimitAmount(vo.getLimitAmount());
					companyVO.setLimitCurrency(vo.getLimitCurrency());
					companyVO.setLimitExpYmd(vo.getLimitExpYmd());
					companyVO.setExpCompCode(vo.getExpCompCode());
					companyVO.setExpCntCode(vo.getExpCntCode());
					companyVO.setUpdtIdxx(vo.getRegiIdxx());
					companyVO.setCeoFullNm(vo.getCeoFullNm());
					companyVO.setCeoEtcNm(vo.getCeoEtcNm());
					companyVO.setTradeItem (vo.getTradeItem ());
					companyVO.setReportYn  (vo.getReportYn  ());
					companyVO.setReportType(vo.getReportType());
					companyVO.setStockYn   (vo.getStockYn   ());
					companyVO.setRelationLg(vo.getRelationLg());

					companyDao.updateCompany(companyVO);

					OrganVO organVo= new OrganVO();
					organVo.setCompCode(vo.getCompCode());
					organVo.setVkorg(vo.getVkorg());
					organVo = (OrganVO) StringUtil.nullToEmptyString(companyDao.getCompanyEtc(organVo));

					organVo.setBzirk(vo.getBzirk());
					organVo.setVkbur(vo.getVkbur());
					organVo.setVkgrp(vo.getVkgrp());
					organVo.setWaers(vo.getWaers());
					organVo.setKtgrd(vo.getKtgrd());
					organVo.setKvgr1(vo.getKvgr1());
					organVo.setKvgr2(vo.getKvgr2());
					organVo.setKvgr3(vo.getKvgr3());
					organVo.setKvgr4(vo.getKvgr4());
					organVo.setKvgr5(vo.getKvgr5());
					organVo.setVtweg("10");
					organVo.setCustInfo(vo.getCustInfo());
					organVo.setUsgeGrad(vo.getUsgeGrad());
					organVo.setUsgeQtyx(vo.getUsgeQtyx());
					organVo.setSalePric(vo.getSalePric());
					organVo.setPartProd(vo.getPartProd());
					organVo.setSaleMan1(vo.getSaleMan1());
					organVo.setMonyCond(vo.getMonyCond());
					organVo.setBasiBigo(vo.getBasiBigo());
					organVo.setErpxSman(apprVO.getRegiIdxx());
					organVo.setErpxSday("sysdate");
					organVo.setErpxSend("S");
					organVo.setGuarExptYmd(vo.getGuarExptYmd());
					organVo.setFileId(vo.getFileId());
					organVo.setDealIdxx(vo.getDealIdxx());
					organVo.setUpdtIdxx(vo.getUpdtIdxx());

					companyDao.updateOrgan(organVo);
				} else {	//실패 rfc1
					logger.error(eReturn);
					vo.setErpxSend("F");
				}
				companyDao.updateCompEditErpStat(vo);

		        if(rtnCode > 0) {	//성공
					//기안자 sms 전송
					SmsVO smsVo = new SmsVO();
					smsVo.setTrPhone(apprVO.getSawnHpxxNum1());
					smsVo.setTrMsg(vo.getName1() + " [" + companyVO.getKunnr() + "]의 고객등록 정보가 ERP에 전송되었습니다.");
					smsVo.setTrEtc1(vo.getApprId());
					smsService.sendSms(smsVo);
		        } else {	//실패
					SmsVO smsVo = new SmsVO();
					smsVo.setTrPhone(apprVO.getSawnHpxxNum1());
					smsVo.setTrMsg(vo.getName1() + "의 고객등록건의 ERP 전송에 실패하였습니다. 실패사유 - " + eReturn);
					smsVo.setTrEtc1(vo.getApprId());
					smsService.sendSms(smsVo);
		        }
			} catch (Exception e) {
				//메일이나 SMS 전송시 오류가 발생해도 커밋은 해야한다.
		        transactionManager.commit(tx);
				throw e;
			}
		}
	}

	private void callChangeCustomer(NewCompOrganEditVO vo) {
		CompanyVO companyVO = new CompanyVO();
		companyVO.setCompCode(vo.getCompCode());
		companyVO.setVkorg(vo.getVkorg());
		//null point exception 방지
		companyVO = (CompanyVO) StringUtil.nullToEmptyString(companyDao.getCompanyDetail(companyVO));

		Map<String, Object> outputParams = new HashMap<String, Object>();
		JcoTableParam tableParam = new JcoTableParam();

		Map<String, Object> company = new HashMap<String, Object>();
		company.put("PARTN_NUMB", vo.getKunnr());              // 고객번호
		company.put("SALES_ORG", vo.getVkorg());               // 영업조직
		company.put("NAME1", vo.getName1());                   // 이름 1
		company.put("SORT1", companyVO.getSortl());                   // 검색어 1
		//            company.put("SORT2", vo.getCompCode());                   // 검색어 2 회사코드를 32바이트로 변경하면서 더이상 넘기지 않음 
		company.put("STREET", vo.getStrasFull());                  // 번지 및 상세주소
		company.put("POSTL_CODE", companyVO.getPostlz());              // 우편번호
		company.put("CITY", "");                 // 도시
		company.put("COUNTRY", vo.getLand1());           // 국가키
		company.put("TRANSPZONE", vo.getLzone());        // 운송지역 또는 상품납품지역
		company.put("TELEPHONE", vo.getTelf1Full());        // 첫번째 전화번호
		company.put("FAX_NUMBER", vo.getTelfx());        // 팩스번호
		company.put("SMTP_ADDR", "");            // 전자메일주소
		company.put("LIFNR", "");                      // 공급업체 또는 채권자 계정번호
		company.put("STCD1", vo.getCeoBirthday());                      // 대표자주민번호                       
		company.put("STCD2", StringUtil.remove(vo.getStcd2(), '-'));      //사업자등록번호                           
		company.put("STCEG", vo.getStcd2()); //stcd2           // 사업자등록번호
		company.put("J_1KFREPRE", vo.getJ1kfrepre());         // 대표자 이름
		company.put("CEOFNM", vo.getCeoFullNm().equals("") ? "." : vo.getCeoFullNm());         // 대표자이름1 (1이 있고 2가 없으면 전송오류 발생 . 으로 강제 replace)                          
		company.put("CEOENM", vo.getCeoEtcNm().equals("") ? "." : vo.getCeoEtcNm());         // 대표자이름 2                          
		company.put("J_1KFTBUS", companyVO.getJ1kftbus());           // 사업유형
		company.put("J_1KFTIND", companyVO.getJ1kftind());           // 산업유형
		tableParam.put("T_LIST", company);

		jcoConnector.executeFunction(FNC_SAP_CUSTOMER_CHANGE1, null, outputParams, tableParam);			
	}

	@Override
	public void rejectProcess(ApprVO apprVO) {
		CompOrganEditVO param = new CompOrganEditVO();
		param.setApprId(apprVO.getApprId());
	}

	@Override
	public String getApprContent(String compEditId) {
		CompOrganEditVO param = new CompOrganEditVO();
		param.setCompEditId(compEditId);
		NewCompOrganEditVO vo = (NewCompOrganEditVO) StringUtil.nullToEmptyString(companyDao.getCompOrganEditDetail(param));
		CompanyVO companyVo = new CompanyVO();
		companyVo.setCompCode(vo.getCompCode());
		companyVo.setVkorg(vo.getVkorg());
		companyVo = (CompanyVO) StringUtil.nullToEmptyString(companyDao.getCompanyDetail(companyVo));
		companyVo.setOrganVO((OrganVO) StringUtil.nullToEmptyString(companyVo.getOrganVO()));
		companyVo.setLimitAmount(StringUtil.setComma(StringUtil.nullConvert(companyVo.getLimitAmount())));

		vo.setKvgr1Text(sapSearchService.getMasterCodeName("10", vo.getKvgr1()));
		vo.setKvgr2Text(sapSearchService.getMasterCodeName("11", vo.getKvgr2()));
		vo.setKvgr3Text(sapSearchService.getMasterCodeName("12", vo.getKvgr3()));
		vo.setKvgr4Text(sapSearchService.getMasterCodeName("13", vo.getKvgr4()));
		vo.setKvgr5Text(sapSearchService.getMasterCodeName("14", vo.getKvgr5()));
		vo.setMonyCondText(sapSearchService.getMasterCodeName("28", vo.getMonyCond()));

		vo.setKtgrd(sapSearchService.getMasterCodeName("08", vo.getKtgrd()));
		vo.setWaers(sapSearchService.getMasterCodeName("26", vo.getWaers()));
		vo.setVkbur(sapSearchService.getMasterCodeName("02", vo.getVkbur()));
		vo.setVkgrp(sapSearchService.getMasterCodeName("03", vo.getVkgrp()));
		vo.setBzirk(sapSearchService.getMasterCodeName("25", vo.getBzirk()));
		vo.setLand1Text(sapSearchService.getMasterCodeName("06", vo.getLand1()));
		vo.setLzoneText(sapSearchService.getMasterCodeName("07", vo.getLzone()));

		FileVO fileVO = new FileVO();
		fileVO.setFileId(vo.getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("editVo", vo);
		map.put("companyVo", companyVo);
		map.put("fileVoList", fileVoList);
    	try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate(REPORT_TEMPLATE_COMP_CREATE + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
    	return "";
	}
}
