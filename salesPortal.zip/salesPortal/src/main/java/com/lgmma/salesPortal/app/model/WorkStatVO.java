package com.lgmma.salesPortal.app.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import javax.validation.constraints.Pattern;
	
public class WorkStatVO extends PagingParamVO implements Cloneable{
	
	private String vkorg;
	@Pattern(regexp="(\\d{4}|)$", message="{errors.yyyy}")
	private String yyyy;
	@Pattern(regexp="(\\d{2}|)$", message="{errors.mm}")
	private String mm;
	private String yyyyMm;
	private String yyyyMmDd;
	
	
	private String gubun;
	
	
	//메인화면, 업무현황 목록 
	private String sort   ;	  // 정렬순서
	private String note   ;   // 구분text
	private String value1 ;   // 전월실적
	private String value2 ;   // 당월계획
	private String value3 ;   // 당월실적
	private String value4 ;   // 차이	
	
	//메인화면 영업이익
	private String zyuyy;
	
	
	private String e_tot  ;   // 월합영업일		
	private String e_cur ;	  // 현재일까지 영업일 	
								 
	 // 매출								
	 private String vtweg   ; // 유통		
	 private String vkbur   ; // 구분		
	 private String vkburnm ; // 구분명		
	 private String kunnr   ; // 판매처		
	 private String kunnrnm ; // 상호		
	 private String mvgr1   ; // lcdc		
	 private String mvgr1nm ; // lcd		
	 private String qnty1   ; // 전월수량	
	 private String amnt1   ; // 전월금액	
	 private String pric1   ; // 전월판가	
	 private String qnty2   ; // 계획1수량	
	 private String amnt2   ; // 계획1금액	
	 private String pric2   ; // 계획1판가	
	 private String qnty3   ; // 계획2수량	
	 private String amnt3   ; // 계획2금액	
	 private String pric3   ; // 계획2판가	
	 private String qnty4   ; // 실적수량	
	 private String amnt4   ; // 실적금액	
	 private String pric4   ; // 실적판가	
	 private String kvgr1   ; // 구분1
	 private String kvgr1nm ; // 구분1명
	 private String kvgr2   ; // 구분2
	 private String kvgr2nm ; // 구분2명
	 
	 
	
	 // pmma 재고 & 생산현황 				
	 private String bzirk   ; // 저장위치	
	 private String bzirknm ; // 위치명		
								 
	 // mma 매출  			 
	 private String vtwegnm ; // 유통명		
						  
	// mma 재고 & 생산 현황 
	 private String vkorgnm ; // 제품		

	 private String colSpan ;
	 private String rowSpan ;
	 private String rowSpan2 ;
	 private String rowSpan3 ;
	 
	 private List<String> headerList;
	 private String headerSize;
	 private String totalRow;
	 private String bgColor;
	
	 private Double[] ticksArr; //홈화면 차트 눈금
	 
	/*sorting*/
	public static Comparator<WorkStatVO> sortProfitDESC = new Comparator<WorkStatVO>() {
		
		@Override
		public int compare(WorkStatVO o1, WorkStatVO o2) {
			double data1 =  Double.parseDouble(o1.getZyuyy());
			double data2 = Double.parseDouble(o2.getZyuyy());
			return Double.compare(data2, data1);
		}
	};
	
	/*sorting*/
	public static Comparator<WorkStatVO> sortSalesDESC = new Comparator<WorkStatVO>() {
		
		@Override
		public int compare(WorkStatVO o1, WorkStatVO o2) {
			double data1 =  Double.parseDouble(o1.getValue3());
			double data2 = Double.parseDouble(o2.getValue3());
			return Double.compare(data2, data1);
		}
	};
	public String getYyyy() {
		return yyyy;
	}

	public void setYyyy(String yyyy) {
		this.yyyy = yyyy;
	}

	public String getMm() {
		return mm;
	}

	public void setMm(String mm) {
		this.mm = mm;
	}

	public String getYyyyMmDd() {
		return yyyyMmDd;
	}

	public void setYyyyMmDd(String yyyyMmDd) {
		this.yyyyMmDd = yyyyMmDd;
	}

	public String getGubun() {
		return gubun;
	}

	public void setGubun(String gubun) {
		this.gubun = gubun;
	}	
	
	
	public String getYyyyMm() {
		return yyyyMm;
	}

	public void setYyyyMm(String yyyyMm) {
		this.yyyyMm = yyyyMm;
	}

	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}

	

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getValue1() {
		return value1;
	}

	public void setValue1(String value1) {
		this.value1 = value1;
	}

	public String getValue2() {
		return value2;
	}

	public void setValue2(String value2) {
		this.value2 = value2;
	}

	public String getValue3() {
		return value3;
	}

	public void setValue3(String value3) {
		this.value3 = value3;
	}

	public String getValue4() {
		return value4;
	}

	public void setValue4(String value4) {
		this.value4 = value4;
	}

	public String getZyuyy() {
		return zyuyy;
	}

	public void setZyuyy(String zyuyy) {
		this.zyuyy = zyuyy;
	}

	public String getE_tot() {
		return e_tot;
	}

	public void setE_tot(String e_tot) {
		this.e_tot = e_tot;
	}

	public String getE_cur() {
		return e_cur;
	}

	public void setE_cur(String e_cur) {
		this.e_cur = e_cur;
	}

	public String getVtweg() {
		return vtweg;
	}

	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}

	public String getVkbur() {
		return vkbur;
	}

	public void setVkbur(String vkbur) {
		this.vkbur = vkbur;
	}

	public String getVkburnm() {
		return vkburnm;
	}

	public void setVkburnm(String vkburnm) {
		this.vkburnm = vkburnm;
	}

	public String getKunnr() {
		return kunnr;
	}

	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}

	public String getKunnrnm() {
		return kunnrnm;
	}

	public void setKunnrnm(String kunnrnm) {
		this.kunnrnm = kunnrnm;
	}

	public String getMvgr1() {
		return mvgr1;
	}

	public void setMvgr1(String mvgr1) {
		this.mvgr1 = mvgr1;
	}

	public String getMvgr1nm() {
		return mvgr1nm;
	}

	public void setMvgr1nm(String mvgr1nm) {
		this.mvgr1nm = mvgr1nm;
	}

	public String getQnty1() {
		return qnty1;
	}

	public void setQnty1(String qnty1) {
		this.qnty1 = qnty1;
	}

	public String getAmnt1() {
		return amnt1;
	}

	public void setAmnt1(String amnt1) {
		this.amnt1 = amnt1;
	}

	public String getPric1() {
		return pric1;
	}

	public void setPric1(String pric1) {
		this.pric1 = pric1;
	}

	public String getQnty2() {
		return qnty2;
	}

	public void setQnty2(String qnty2) {
		this.qnty2 = qnty2;
	}

	public String getAmnt2() {
		return amnt2;
	}

	public void setAmnt2(String amnt2) {
		this.amnt2 = amnt2;
	}

	public String getPric2() {
		return pric2;
	}

	public void setPric2(String pric2) {
		this.pric2 = pric2;
	}

	public String getQnty3() {
		return qnty3;
	}

	public void setQnty3(String qnty3) {
		this.qnty3 = qnty3;
	}

	public String getAmnt3() {
		return amnt3;
	}

	public void setAmnt3(String amnt3) {
		this.amnt3 = amnt3;
	}

	public String getPric3() {
		return pric3;
	}

	public void setPric3(String pric3) {
		this.pric3 = pric3;
	}

	public String getQnty4() {
		return qnty4;
	}

	public void setQnty4(String qnty4) {
		this.qnty4 = qnty4;
	}

	public String getAmnt4() {
		return amnt4;
	}

	public void setAmnt4(String amnt4) {
		this.amnt4 = amnt4;
	}

	public String getPric4() {
		return pric4;
	}

	public void setPric4(String pric4) {
		this.pric4 = pric4;
	}

	public String getBzirk() {
		return bzirk;
	}

	public void setBzirk(String bzirk) {
		this.bzirk = bzirk;
	}

	public String getBzirknm() {
		return bzirknm;
	}

	public void setBzirknm(String bzirknm) {
		this.bzirknm = bzirknm;
	}

	public String getVtwegnm() {
		return vtwegnm;
	}

	public void setVtwegnm(String vtwegnm) {
		this.vtwegnm = vtwegnm;
	}

	public String getVkorgnm() {
		return vkorgnm;
	}

	public void setVkorgnm(String vkorgnm) {
		this.vkorgnm = vkorgnm;
	}

	public String getKvgr1() {
		return kvgr1;
	}

	public void setKvgr1(String kvgr1) {
		this.kvgr1 = kvgr1;
	}

	public String getKvgr1nm() {
		return kvgr1nm;
	}

	public void setKvgr1nm(String kvgr1nm) {
		this.kvgr1nm = kvgr1nm;
	}

	public String getKvgr2() {
		return kvgr2;
	}

	public void setKvgr2(String kvgr2) {
		this.kvgr2 = kvgr2;
	}

	public String getKvgr2nm() {
		return kvgr2nm;
	}

	public void setKvgr2nm(String kvgr2nm) {
		this.kvgr2nm = kvgr2nm;
	}

	public String getColSpan() {
		return colSpan;
	}

	public void setColSpan(String colSpan) {
		this.colSpan = colSpan;
	}

	public String getRowSpan() {
		return rowSpan;
	}

	public void setRowSpan(String rowSpan) {
		this.rowSpan = rowSpan;
	}

	public String getRowSpan2() {
		return rowSpan2;
	}

	public void setRowSpan2(String rowSpan2) {
		this.rowSpan2 = rowSpan2;
	}
	
	public String getRowSpan3() {
		return rowSpan3;
	}

	public void setRowSpan3(String rowSpan3) {
		this.rowSpan3 = rowSpan3;
	}

	public List<String> getHeaderList() {
		return headerList;
	}
	
	public void setHeaderList(WorkStatVO workStat) {
		
		List<String> headers = new ArrayList<String>();
		
		if(workStat.getMvgr1nm()!=null && workStat.getMvgr1nm()!="")
			headers.add(workStat.getMvgr1nm());
		if(workStat.getVtweg()!=null && workStat.getVtweg()!="")
			headers.add(workStat.getVtweg());
		if(workStat.getVtwegnm()!=null && workStat.getVtwegnm()!="")
			headers.add(workStat.getVtwegnm());
		if(workStat.getVkburnm()!=null && workStat.getVkburnm()!="")
			headers.add(workStat.getVkburnm());
		if(workStat.getKvgr1nm()!=null && workStat.getKvgr1nm()!="")
			headers.add(workStat.getKvgr1nm());
		if(workStat.getKvgr2nm()!=null && workStat.getKvgr2nm()!="")
			headers.add(workStat.getKvgr2nm());
		if(workStat.getKunnrnm()!=null && workStat.getKunnrnm()!="")
			headers.add(workStat.getKunnrnm());
	
		this.headerList = headers;
	}

	public String getHeaderSize() {
		return headerSize;
	}

	public void setHeaderSize(String headerSize) {
		this.headerSize = headerSize;
	}

	public String getTotalRow() {
		return totalRow;
	}

	public void setTotalRow(String totalRow) {
		this.totalRow = totalRow;
	}

	public String getBgColor() {
		return bgColor;
	}

	public void setBgColor(String bgColor) {
		this.bgColor = bgColor;
	}

	public Double[] getTicksArr() {
		return ticksArr;
	}

	public void setTicksArr(Double[] ticksArr) {
		this.ticksArr = ticksArr;
	}
	
	@Override
	public Object clone()
	{
		try{
			WorkStatVO workStatVO = (WorkStatVO)super.clone();
			return workStatVO;
		}catch(CloneNotSupportedException e){
			e.printStackTrace();
		}
		return null;
	}
	
}
