package com.lgmma.salesPortal.common.props;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.lgmma.salesPortal.common.model.DDLBItem;

public enum SalePriceMasterSpKind {
/**
 * 판가구분유형으로서
*/
	 SP_TYPE_KIND_PATNR(	"PATNR"	,"실제인도처"	,"A512"	,"WTY_V_PARNR")
	,SP_TYPE_KIND_PLTYP(	"PLTYP"	,"가격리스트"	,"A511"	,"PLTYP")
	;
	String code		= null;		// 판가구분코드
	String name		= null;		// 판가구분명
	String rfcGubun	= null;		// ZSE07_CREATE_SALES_PRICE rfc 구분
	String rfcColNmByGubun	= null;	// ZSE07_CREATE_SALES_PRICE rfc 구분에 따른 필수 사용 컬럼명

	private SalePriceMasterSpKind(String code, String name, String rfcGubun, String rfcColNmByGubun) {
		this.code				= code;
		this.name				= name;
		this.rfcGubun			= rfcGubun;
		this.rfcColNmByGubun	= rfcColNmByGubun;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRfcGubun() {
		return rfcGubun;
	}

	public void setRfcGubun(String rfcGubun) {
		this.rfcGubun = rfcGubun;
	}

	public String getRfcColNmByGubun() {
		return rfcColNmByGubun;
	}

	public void setRfcColNmByGubun(String rfcColNmByGubun) {
		this.rfcColNmByGubun = rfcColNmByGubun;
	}

	public static SalePriceMasterSpKind getSalePriceMasterSpKind(String code) {
		for(SalePriceMasterSpKind type : SalePriceMasterSpKind.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
	
	public static List<DDLBItem> getSpKindItemList(){
		List<DDLBItem> itemList = new ArrayList<DDLBItem>();
		List<SalePriceMasterSpKind> spKindList = new ArrayList< SalePriceMasterSpKind >(Arrays.asList(SalePriceMasterSpKind.values()));
		for(SalePriceMasterSpKind spKind : spKindList) {
			DDLBItem item = new DDLBItem();
			item.setCode(spKind.getCode());
			item.setText(spKind.getName());
			itemList.add(item);
		}
		return itemList;
	}
}
