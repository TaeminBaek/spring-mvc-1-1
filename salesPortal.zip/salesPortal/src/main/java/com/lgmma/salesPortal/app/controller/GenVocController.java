package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.GenVocVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.service.GenVocMgmtService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.props.Times;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

@Controller
@RequestMapping("/genvoc") 
public class GenVocController {
	
	@Autowired
	private GenVocMgmtService genVocMgmtService;
	
    @Autowired
    private MailingService mailingService;
	
	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	
	@RequestMapping(value = "/genVocMgmt")
	public ModelAndView genVocMgmtInfo(ModelAndView mav ) throws Exception {
		mav.setViewName("voc/genVocMgmt");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("times", new ArrayList< Times >(Arrays.asList(Times.values())));
		
		String today = Util.getToday(Util.YmdHmsFmt);
		mav.addObject("regiDate", today);
		return mav;
	}

	@RequestMapping(value = "/getGenVocItemList.json")
	public Map getGenVocItemList(@RequestBody(required = false) GenVocVO param) throws Exception {
		List<GenVocVO> items = new ArrayList<GenVocVO>();
		GenVocVO item = new GenVocVO();
		item.setVocxItem("");
		item.setItemName("전체");
		items.add(item);
		
		List<GenVocVO> vocItems = genVocMgmtService.getGenVocItemList();
		items.addAll(vocItems);
		
		return JsonResponse.asSuccess("items", items );
	}
	
	@RequestMapping(value = "/getGenVocList.json")
	public Map getGenVocList(@RequestBody(required = true) GenVocVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", genVocMgmtService.getGenVocCount(param), "storeData", genVocMgmtService.getGenVocList(param));
	}
	
	@RequestMapping(value = "/getGenVocDetail.json")
	public Map getGenVocDetail(@RequestBody GenVocVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", genVocMgmtService.getGenVocDetail(param));
	}
	
	@RequestMapping(value = "/updateGenVocReply.json")
	public Map updateGenVocReply(@RequestBody GenVocVO param) throws Exception {
		genVocMgmtService.updateGenVocReply(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/createGenVocReply.json")
	public Map createGenVocReply(@RequestBody GenVocVO param) throws Exception {
		genVocMgmtService.createGenVocReply(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/deleteGenVocReply.json")
	public Map deleteGenVocReply(@RequestBody GenVocVO param) throws Exception {
		genVocMgmtService.deleteGenVocReply(param);
		return JsonResponse.asSuccess("success", "삭제되었습니다");
	}
	
	@RequestMapping(value = "/sendGenVocReplyEmail.json")
	public Map sendGenVocReplyEmail(@RequestBody GenVocVO param) throws Exception {
		
		GenVocVO genVocVO = (GenVocVO)StringUtil.nullToEmptyString(genVocMgmtService.getGenVocDetail(param));
		
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("REGI_DATE", genVocVO.getRegiDate());
		paramMap.put("CUST_NAME", genVocVO.getCustName());
		paramMap.put("TELX_NUMX", genVocVO.getTelxNumx());
		paramMap.put("MAIL_ADDR", genVocVO.getMailAddr());
		paramMap.put("VKORG", genVocVO.getvName());
		paramMap.put("VOCX_ITEM", genVocVO.getItemName());
		paramMap.put("REQX_DATE", genVocVO.getReqxDate());
		paramMap.put("REQX_HOUR", genVocVO.getReqxHour());
		paramMap.put("TITL_TEXT", genVocVO.getTitlText());
		paramMap.put("CONT_TEXT", genVocVO.getContText());
		
		//최근 답변
		paramMap.put("REPLY_SAWN_NAME", genVocVO.getReplyList().get(genVocVO.getReplyList().size()-1).getSawnName());
		paramMap.put("REPLY_REGI_DATE", genVocVO.getReplyList().get(genVocVO.getReplyList().size()-1).getRegiDate());
		paramMap.put("REPLY_POSI_NAME", genVocVO.getReplyList().get(genVocVO.getReplyList().size()-1).getPosiName());
		paramMap.put("REPLY_DEPT_NAME", genVocVO.getReplyList().get(genVocVO.getReplyList().size()-1).getDeptName());
		paramMap.put("REPLY_TITL_TEXT", genVocVO.getReplyList().get(genVocVO.getReplyList().size()-1).getTitlText());
		paramMap.put("REPLY_CONT_TEXT", genVocVO.getReplyList().get(genVocVO.getReplyList().size()-1).getContText());
		

		SendMailVO sendMailVO = new SendMailVO();
		sendMailVO.setMailType(MailType.VOC_REPLY_REGISTER_TO_CUSTOMER);
		sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
		sendMailVO.setReceiverEmail(genVocVO.getMailAddr());
		sendMailVO.setReceiverName(genVocVO.getCustName());
		sendMailVO.setParams(paramMap);
		mailingService.sendMail(sendMailVO);
		
		genVocMgmtService.updateGenVocEmailSendYn(param);
		
		return JsonResponse.asSuccess("success", "전송되었습니다");
	}
}
