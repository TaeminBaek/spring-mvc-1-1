package com.lgmma.salesPortal.app.model;

public class CommonCodeVO extends PagingParamVO {
	private String codeIdxx;
	private String grupCode;
	private String codeName;
	private String deleIsxx;
	private String condVal1;
	private String condVal2;
	private String dpOrder;
	private String regiName;
	private String code;
	private String text;

	public String getCodeIdxx() {
		return codeIdxx;
	}
	public void setCodeIdxx(String codeIdxx) {
		this.codeIdxx = codeIdxx;
	}
	public String getGrupCode() {
		return grupCode;
	}
	public void setGrupCode(String grupCode) {
		this.grupCode = grupCode;
	}
	public String getCodeName() {
		return codeName;
	}
	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}
	public String getDeleIsxx() {
		return deleIsxx;
	}
	public void setDeleIsxx(String deleIsxx) {
		this.deleIsxx = deleIsxx;
	}
	public String getCondVal1() {
		return condVal1;
	}
	public void setCondVal1(String condVal1) {
		this.condVal1 = condVal1;
	}
	public String getCondVal2() {
		return condVal2;
	}
	public void setCondVal2(String condVal2) {
		this.condVal2 = condVal2;
	}
	public String getDpOrder() {
		return dpOrder;
	}
	public void setDpOrder(String dpOrder) {
		this.dpOrder = dpOrder;
	}
	public String getRegiName() {
		return regiName;
	}
	public void setRegiName(String regiName) {
		this.regiName = regiName;
	}
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
