package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissReviewVO;

public interface CommonReviewDao {

	int getReviewListCount(DissReviewVO param);
	
	List<DissReviewVO> getReviewList(DissReviewVO param);

	DissReviewVO getReview(DissReviewVO param);

	void createReview(DissReviewVO param);

	void createReviewAns(DissReviewVO param);

	void deleteReview(DissReviewVO param);

}
