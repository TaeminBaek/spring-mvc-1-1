package com.lgmma.salesPortal.app.controller;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.lgmma.salesPortal.app.model.DissDailyVO;
import com.lgmma.salesPortal.app.model.DissExcelDownloadVO;
import com.lgmma.salesPortal.app.model.DissImpDevVO;
import com.lgmma.salesPortal.app.model.DissSampleOrderMasterVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterHisVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;
import com.lgmma.salesPortal.app.service.DissDailyActService;
import com.lgmma.salesPortal.app.service.DissImpDevService;
import com.lgmma.salesPortal.app.service.DissSampleOrderService;
import com.lgmma.salesPortal.app.service.DissSpecInService;
import com.lgmma.salesPortal.app.service.SalePriceMasterMgmtService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

import freemarker.template.Configuration;
import net.sf.jxls.transformer.XLSTransformer;

@Controller
@RequestMapping("/excel") 
public class ExcelController {

	private static Logger logger = LoggerFactory.getLogger(ExcelController.class);

	@Autowired
    @Qualifier(value="excelFreemarkerConfiguration")
    private Configuration excelFreemarkerConfiguration;

	@Autowired
	DissSpecInService dissSpecInService;

	@Autowired
	DissImpDevService dissImpDevService;

	@Autowired
	DissDailyActService dissDailyActService;

	@Autowired
	DissSampleOrderService dissSampleOrderService;

	@Autowired
	private SalePriceMasterMgmtService salePriceMasterMgmtService;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;


	@RequestMapping(value = "/salePriceMasterExcelDownload", method = RequestMethod.POST)
	public void salePriceMasterExcelDownload(HttpServletRequest req, HttpServletResponse res, SalePriceMasterVO param) throws Exception {
		List<SalePriceMasterVO> salePriceMasterList = salePriceMasterMgmtService.getsalePriceMasterList(param);
		List<SalePriceMasterVO> copySalePriceMasterList = new ArrayList<SalePriceMasterVO>();
		for(SalePriceMasterVO salePriceMasterVO : salePriceMasterList){
			copySalePriceMasterList.add((SalePriceMasterVO) StringUtil.nullToEmptyString(salePriceMasterVO));
		}
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("list", copySalePriceMasterList);
		excelDownLoad(req, res, paramMap, "SALE_PRICE_MASTER_LIST");
	}

	@RequestMapping(value = "/dissSpecInListExcelDownload", method = RequestMethod.GET)
	public void dissSpecInListExcelDownload(HttpServletRequest req, HttpServletResponse res, DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		req.setCharacterEncoding("euc-kr");
		List<DissExcelDownloadVO> specInExcelList = dissSpecInService.getDissSpecInListExcelDownload(param);
		List<DissExcelDownloadVO> copySpecInExcelDownloadVO = new ArrayList<DissExcelDownloadVO>();
		Map<String, Object> paramMap = new HashMap<String, Object>();

		for(DissExcelDownloadVO dissSpecInExcelDownloadVO : specInExcelList){
			dissSpecInExcelDownloadVO.setApprStat(ApprState.getApprState(dissSpecInExcelDownloadVO.getApprStat()).getName());
			copySpecInExcelDownloadVO.add((DissExcelDownloadVO) StringUtil.nullToEmptyString(dissSpecInExcelDownloadVO));
		}

		paramMap.put("list", copySpecInExcelDownloadVO);
		excelDownLoad(req, res, paramMap, "DISS_SPEC_IN_LIST");
	}

	@RequestMapping(value = "/dissImpDevExcelDownload", method = RequestMethod.GET)
	public void dissImpDevExcelDownload(HttpServletRequest req, HttpServletResponse res, DissImpDevVO param) throws Exception {
		param = (DissImpDevVO) StringUtil.nullToEmptyString(param);
		req.setCharacterEncoding("euc-kr");
		List<DissImpDevVO> impDevExcelList = dissImpDevService.getDissImpDevListExcelDownload(param);
		List<DissImpDevVO> copyImpDevVO = new ArrayList<DissImpDevVO>();
		Map<String, Object> paramMap = new HashMap<String, Object>();

		for(DissImpDevVO dissImpDevVO : impDevExcelList){
			dissImpDevVO.setApprStat(ApprState.getApprState(dissImpDevVO.getApprStat()).getName());
			copyImpDevVO.add((DissImpDevVO) StringUtil.nullToEmptyString(dissImpDevVO));
		}

		paramMap.put("list", copyImpDevVO);
		excelDownLoad(req, res, paramMap, "DISS_IMP_DEV_LIST");
	}

	@RequestMapping(value = "/dissDailyActListExcelDownload", method = RequestMethod.GET)
	public void dissDailyActListExcelDownload(HttpServletRequest req, HttpServletResponse res, DissDailyVO param) throws Exception {
		req.setCharacterEncoding("euc-kr");
		param = (DissDailyVO) StringUtil.nullToEmptyString(param);
		List<DissDailyVO> dailyActVOList = dissDailyActService.getDissDailyActListExcelDownload(param);
		List<DissDailyVO> copyDailyActVOList = new ArrayList<DissDailyVO>();

		DissSpecInVO dissSpecInVO = new DissSpecInVO();
		dissSpecInVO.setScType("D");
		List<DissExcelDownloadVO> specInExcelList = dissSpecInService.getDissSpecInListExcelDownload(dissSpecInVO);
		List<DissExcelDownloadVO> copySpecInExcelDownloadVO = new ArrayList<DissExcelDownloadVO>();

		Map<String, Object> paramMap = new HashMap<String, Object>();
		
		for(DissDailyVO dissDailyVO : dailyActVOList) {
			dissDailyVO.setApprFormCont(dissDailyVO.getApprFormCont().replaceAll("<(/)?([a-zA-Z]*)(\\s[a-zA-Z]*=[^>]*)?(\\s)*(/)?>", "").replaceAll("&nbsp;", " "));
			copyDailyActVOList.add((DissDailyVO) StringUtil.nullToEmptyString(dissDailyVO));
		}
		
		for(DissExcelDownloadVO dissSpecInExcelDownloadVO : specInExcelList){
			dissSpecInExcelDownloadVO.setApprStat(ApprState.getApprState(dissSpecInExcelDownloadVO.getApprStat()).getName());
			copySpecInExcelDownloadVO.add((DissExcelDownloadVO) StringUtil.nullToEmptyString(dissSpecInExcelDownloadVO));
		}
		
		paramMap.put("list", copyDailyActVOList);
		paramMap.put("list2", copySpecInExcelDownloadVO);
		excelDownLoad(req, res, paramMap, "DISS_DAILY_ACT_LIST");
	}

	@RequestMapping(value = "/dissDailyActStatInfoExcelDownload", method = RequestMethod.GET)
	public void dissDailyActStatInfoExcelDownload(HttpServletRequest req, HttpServletResponse res, DissDailyVO param) throws Exception {
		req.setCharacterEncoding("euc-kr");
		param = (DissDailyVO) StringUtil.nullToEmptyString(param);
		List<DissDailyVO> dailyActVOList1 = dissDailyActService.getDissDailyActStatList(param);
		List<DissDailyVO> dailyActVOList2 = dissDailyActService.getDissDailyActStatInfoExcelDownload(param);
		List<DissDailyVO> dailyActVOList3 = dissDailyActService.getDissDailyActStatInfoExcelDownload2(param);
		List<DissDailyVO> copyDailyActVOList1 = new ArrayList<DissDailyVO>();
		List<DissDailyVO> copyDailyActVOList2 = new ArrayList<DissDailyVO>();
		List<DissDailyVO> copyDailyActVOList3 = new ArrayList<DissDailyVO>();
		Map<String, Object> paramMap = new HashMap<String, Object>();

		for(DissDailyVO dissDailyVO : dailyActVOList1)
			if(!("소계".equals(dissDailyVO.getRegiName()) || "총계".equals(dissDailyVO.getRegiName())))
				copyDailyActVOList1.add((DissDailyVO) StringUtil.nullToEmptyString(dissDailyVO));

		for(DissDailyVO dissDailyVO : dailyActVOList2)
			if(!("소계".equals(dissDailyVO.getDevLevelName()) || "총계".equals(dissDailyVO.getDevLevelName())))
				copyDailyActVOList2.add((DissDailyVO) StringUtil.nullToEmptyString(dissDailyVO));

		for(DissDailyVO dissDailyVO : dailyActVOList3)
			if(!("소계".equals(dissDailyVO.getRegiName()) || "총계".equals(dissDailyVO.getRegiName())))
				copyDailyActVOList3.add((DissDailyVO) StringUtil.nullToEmptyString(dissDailyVO));

		paramMap.put("list1", copyDailyActVOList1);
		paramMap.put("list2", copyDailyActVOList2);
		paramMap.put("list3", copyDailyActVOList3);
		excelDownLoad(req, res, paramMap, "DISS_DAILY_ACT_STAT_INFO");
	}

	@RequestMapping(value = "/dissSampleListExcelDownload", method = RequestMethod.GET)
	public void dissSampleListExcelDownload(HttpServletRequest req, HttpServletResponse res, DissSampleOrderMasterVO param) throws Exception {
		param = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(param);
		List<DissSampleOrderMasterVO> dissSampleOrderList = dissSampleOrderService.getDissSampleListExcelDownload(param);
		req.setCharacterEncoding("euc-kr");
		List<DissSampleOrderMasterVO> copyDissSampleOrder = new ArrayList<DissSampleOrderMasterVO>();
		for(DissSampleOrderMasterVO dissSampleOrder : dissSampleOrderList){
			dissSampleOrder = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(dissSampleOrder);
			if("".equals(dissSampleOrder.getProcStatText()))
				dissSampleOrder.setProcStatText("미전송");
			copyDissSampleOrder.add(dissSampleOrder);
		}

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("list", copyDissSampleOrder);
		excelDownLoad(req, res, paramMap, "DISS_SAMPLE_LIST");
	}

	private void excelDownLoad(HttpServletRequest req, HttpServletResponse res, Map<String, Object> paramMap, String type) {
		String fileName = "";
        try {
            InputStream is = null; 
            XLSTransformer xls = new XLSTransformer();
            
            switch(type) {
            case "SALE_PRICE_MASTER_LIST":
            	is = new BufferedInputStream(new FileInputStream(messageSourceAccessor.getMessage("excel.template") + "SALE_PRICE_MASTER_LIST.xls"));
				fileName = "SALE_PRICE_MASTER_LIST_Download_";
				break;
            case "DISS_SPEC_IN_LIST":
            	is = new BufferedInputStream(new FileInputStream(messageSourceAccessor.getMessage("excel.template") + "DISS_SPEC_IN_LIST_EXCEL_DOWNLOAD.xls"));
				fileName = "SPEC-IN_Download_";
				break;
			case "DISS_IMP_DEV_LIST":
				is = new BufferedInputStream(new FileInputStream(messageSourceAccessor.getMessage("excel.template") + "DISS_IMP_DEV_LIST_EXCEL_DOWNLOAD.xls"));
				fileName = "IMP-DEV_Download_";
				break;
			case "DISS_DAILY_ACT_LIST":
				is = new BufferedInputStream(new FileInputStream(messageSourceAccessor.getMessage("excel.template") + "DISS_DAILY_ACT_LIST_EXCEL_DOWNLOAD.xls"));
				fileName = "Daily-Act_Download_";
				break;
			case "DISS_DAILY_ACT_STAT_INFO":
				is = new BufferedInputStream(new FileInputStream(messageSourceAccessor.getMessage("excel.template") + "DISS_DAILY_ACT_STAT_INFO_EXCEL_DOWNLOAD.xls"));
				fileName = "Daily-Act_Stat_Download_";
				break;
			case "DISS_SAMPLE_LIST":
				is = new BufferedInputStream(new FileInputStream(messageSourceAccessor.getMessage("excel.template") + "DISS_SAMPLE_LIST_EXCEL_DOWNLOAD.xls"));
				fileName = "D.I.S.S_Sample_Download_";
				break;
			default:
				throw new Exception();
            }
            
            Workbook workbook = xls.transformXLS(is, paramMap);
            res.setHeader("Set-Cookie","fileDownload=true; path=/");
            res.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + Util.getToday("yyyyMMdd") + ".xls\"");
            OutputStream os = res.getOutputStream();
            workbook.write(os);
            is.close();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

	@RequestMapping(value = "/salePriceMasterExcelUpload", method = RequestMethod.POST)
	public Map salePriceMasterExcelUpload(HttpServletRequest req, HttpServletResponse res) throws Exception {
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
		multipartResolver.setDefaultEncoding("UTF-8");
		MultipartHttpServletRequest multipartRequest = multipartResolver.resolveMultipart(req);
		CommonsMultipartFile file = (CommonsMultipartFile) multipartRequest.getFile("excelFile");

		String fileName = file.getOriginalFilename();

		Workbook tempWorkbook;
		if(fileName.endsWith(".xls")) {
	        tempWorkbook = new HSSFWorkbook(file.getInputStream());
	    } else if(fileName.endsWith(".xlsx")) {
	        tempWorkbook = new XSSFWorkbook(file.getInputStream());
	    } else {
	    	throw new ServiceException("", "올바른 파일이 아닙니다.");
	    }

		ArrayList<Integer> failIdxList = new ArrayList<Integer>();
		int successCnt = 0;
		int failCnt = 0;

		try {
			Sheet sheet = tempWorkbook.getSheetAt(0);

			for(int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
				try {
					Row row = sheet.getRow(i);
					if (row.getCell(0).toString().equals(""))	continue;

					int j = 0;

					SalePriceMasterHisVO param = new SalePriceMasterHisVO();
					param.setVkorg(row.getCell(j++).toString());
					param.setVtweg(row.getCell(j++).toString());
					param.setKunnr(row.getCell(j++).toString());j++;j++;		// 고객명 skip, 담당자 skip
					param.setMatnr(row.getCell(j++).toString());
					param.setIndoKunnr(row.getCell(j++).toString());j++;		// 인도처명 skip
					param.setSpTypeKind(row.getCell(j++).toString());
					param.setSpType(row.getCell(j++).toString());
					param.setKmein(row.getCell(j++).toString());
					param.setKonwa(row.getCell(j++).toString());
					param.setSpStaYmd(row.getCell(j++).toString());
					param.setSpEndYmd(row.getCell(j++).toString());
					param.setSpCreYmd(Util.getToday("yyyyMMdd"));
					param.setRegiIdxx(multipartRequest.getParameter("regiIdxx"));
					param.setPrice(Float.parseFloat(row.getCell(j++).toString()));

					salePriceMasterMgmtService.salePriceMasterExcelUpload(param);
					successCnt++;
				} catch (Exception e) {
					failIdxList.add(i + 1);
					failCnt++;
				}
			}
		} catch (Exception e) {
			throw new ServiceException("", "올바른 파일이 아닙니다.");
		} finally {
			tempWorkbook.close();
		}

		return JsonResponse.asSuccess("success", "완료되었습니다.", "successCnt", successCnt, "failCnt", failCnt, "failIdxList", failIdxList);
	}
/*
	private void excelDownLoad(HttpServletResponse res, Map<String, Object> paramMap, String type) {
		try {
			StringBuffer content = new StringBuffer();
			String fileName = "";
			switch(type) {
			case "DISS_SPEC_IN_LIST":
				content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate("DISS_SPEC_IN_LIST_EXCEL_DOWNLOAD.txt"), paramMap));
				fileName = "SPEC-IN_Download_";
				break;
			case "DISS_IMP_DEV_LIST":
				content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate("DISS_IMP_DEV_LIST_EXCEL_DOWNLOAD.txt"), paramMap));
				fileName = "제품개선개발_Download_";
				break;
			case "DISS_DAILY_ACT_LIST":
				content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate("DISS_DAILY_ACT_LIST_EXCEL_DOWNLOAD.txt"), paramMap));
				fileName = "Daily활동_Download_";
				break;
			case "DISS_DAILY_ACT_STAT_INFO":
				content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate("DISS_DAILY_ACT_STAT_INFO_EXCEL_DOWNLOAD.txt"), paramMap));
				fileName = "Daily활동_통계_Download_";
				break;
			case "DISS_DAILY_ACT_STAT_INFO2":
				content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate("DISS_DAILY_ACT_STAT_INFO_EXCEL_DOWNLOAD2.txt"), paramMap));
				fileName = "Daily활동_통계_Download2_";
				break;
			case "DISS_SAMPLE_LIST":
				content.append(FreeMarkerTemplateUtils.processTemplateIntoString(excelFreemarkerConfiguration.getTemplate("DISS_SAMPLE_LIST_EXCEL_DOWNLOAD.txt"), paramMap));
				fileName = "D.I.S.S_견본관리_Download_";
				break;
			default:
				throw new Exception();
			}

			fileName = java.net.URLEncoder.encode(fileName+Util.getToday("yyyyMMdd"), "UTF-8") + ".xls";

			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie","fileDownload=true; path=/");
			res.setHeader("Content-Disposition","attachment;filename=\""+fileName+"\"");
			res.setHeader("Content-Description", "JSP Generated Data");

			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();
		} catch(Exception e) {
			logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
		}
	}
*/

/*
	@RequestMapping(value = "/dissSampleListExcelDownload", method = RequestMethod.GET)
    public String dissSampleListExcelDownload(HttpServletRequest req, HttpServletResponse res, Model model) throws Exception {
        SXSSFWorkbook workbook = excelService.dissSampleListExcelDownload();
        
        model.addAttribute("locale", Locale.KOREA);
        model.addAttribute("workbook", workbook);
        model.addAttribute("workbookName", "DISS_SAMPLE_LIST_EXCEL_DOWNLOAD");
        
        return "excelDownloadView";
    }
*/

}
