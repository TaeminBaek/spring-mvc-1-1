package com.lgmma.salesPortal.common.props;

public enum Months {
/**
 * 월로서
*/
	 JAN("01","JAN")
	,FEB("02","FEB")
	,MAR("03","MAR")
	,APR("04","APR")
	,MAY("05","MAY")
	,JUN("06","JUN")
	,JUL("07","JUL")
	,AUG("08","AUG")
	,SEP("09","SEP")
	,OCT("10","OCT")
	,NOV("11","NOV")
	,DEC("12","DEC")
	;
	String code = null;
	String name = null;

	private Months(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
