package com.lgmma.salesPortal.app.service;

import com.lgmma.salesPortal.app.model.ContractMasterVO;

public interface ContractService {

	ContractMasterVO getContractMaster(String orderId);

	void updateContractMaster(ContractMasterVO param);

}
