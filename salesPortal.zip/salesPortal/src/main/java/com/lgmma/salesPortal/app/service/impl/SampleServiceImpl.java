package com.lgmma.salesPortal.app.service.impl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.dao.SampleDao;
import com.lgmma.salesPortal.app.model.SampleVO;
import com.lgmma.salesPortal.app.service.SampleService;



@Transactional
@Service
public class SampleServiceImpl implements SampleService {
	
	
    @Autowired
    private SampleDao sampleDao;

	@Override
	public List<SampleVO> getSample(SampleVO param) throws Exception {
		return sampleDao.getSample(param);
	}
	
	@Override
	public int getSampleCount(SampleVO param) {
		return sampleDao.getSampleCount(param);
	}

	public void updateSample(SampleVO param) throws Exception {
		sampleDao.updateSample(param);
	}
	
	public void createSample(SampleVO param) throws Exception {
		sampleDao.createSample(param);
	}
	
	public void deleteSample(SampleVO param) throws Exception {
		sampleDao.deleteSample(param);
	}

}
