package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissStepDao;
import com.lgmma.salesPortal.app.model.DissStepVO;

@Repository
public class DissStepDaoImpl implements DissStepDao{
	
	private static final String MAPPER_NAMESPACE = "DISSSTEP_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;
	
	@Override
	public void createDissStep(DissStepVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissStep", param);
	}
	
	@Override
	public List<DissStepVO> getDissStepRegiList(DissStepVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissStepRegiList", param);
	}
	
	@Override
	public void deleteDissStepAll(DissStepVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissStepAll", param);
	}

	@Override
	public void deleteDissStep(DissStepVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissStep", param);
	}

	@Override
	public void updateStepLastYnYByStepCd(DissStepVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateStepLastYnYByStepCd", param);
	}

	@Override
	public int getDissStepMaxDegreeNo(DissStepVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissStepMaxDegreeNo", param);
	}
	
	@Override
	public void updateDissStepLastYn(DissStepVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissStepLastYn", param);
	}
	
	@Override
	public String getDissStepLastImpDevProposalStepId(DissStepVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissStepLastImpDevProposalStepId", param);
	}

	@Override
	public List<DissStepVO> getDissStepRsltList(DissStepVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissStepRsltList", param);
	}
	
	@Override
	public String getDissStepNextDegreeReason(DissStepVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissStepNextDegreeReason", param);
	}

	@Override
	public DissStepVO getDissStepByApprId(DissStepVO dissStepVO){
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissStepByApprId",dissStepVO);
	}

	@Override
	public DissStepVO getDissStep(DissStepVO dissStepVO){
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissStep",dissStepVO);
	}

	@Override
	public List<DissStepVO> getDissStepIngList(DissStepVO dissStepVO) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissStepIngList",dissStepVO);
	}

	@Override
	public List<DissStepVO> getDissStepAll(DissStepVO dissStepVO) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissStepAll",dissStepVO);
	}

	@Override
	public List<DissStepVO> getDissStepCompAppr(DissStepVO dissStepVO) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissStepCompAppr", dissStepVO);
	}
	
	@Override
	public String getDissStepReWriteRejectApprYn(DissStepVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissStepReWriteRejectApprYn", param);
	}
	
	@Override
	public DissStepVO getDissStepRsltInfo(DissStepVO dissStepVO){
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissStepRsltInfo",dissStepVO);
	}
	
	@Override
	public void updateDissStepRslt(DissStepVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissStepRslt", param);
	}

	@Override
	public void updateCheckDate(DissStepVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateCheckDate", param);
	}
}
