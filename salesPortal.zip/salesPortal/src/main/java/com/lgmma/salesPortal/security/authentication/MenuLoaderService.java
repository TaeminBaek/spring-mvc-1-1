package com.lgmma.salesPortal.security.authentication;

import java.io.File;
import java.io.IOException;

import javax.script.ScriptEngine;
import javax.script.ScriptException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.common.model.MenuItem;


@Service
public class MenuLoaderService {

	@Autowired
    private ScriptEngine javaScriptEngine;

	private static Logger logger = LoggerFactory.getLogger(MenuLoaderService.class); 

	public MenuItem getUserMenu(UserDetails user, String menuFile) {
		MenuItem root = new MenuItem();
		try {
			// create JAXB context and initializing Marshaller
			JAXBContext jaxbContext = JAXBContext.newInstance(MenuItem.class);

			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

			Resource resource = new ClassPathResource(menuFile);

		    // specify the location and name of xml file to be read
			File XMLfile = resource.getFile();
			// this will create Java object - country from the XML file
			javaScriptEngine.put("user", user);
			root = (MenuItem) jaxbUnmarshaller.unmarshal(XMLfile);
			if(root.getMenuItems().size() > 0) {
				appendMenu(root, user);
			}

		} catch (JAXBException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		return root;
	}

	private void appendMenu(MenuItem parent, UserDetails user) {
		parent.setSelected(false);
		for(int i = 0 ; i < parent.getMenuItems().size() ; i ++) {
			MenuItem child = parent.getMenuItems().get(i);
			boolean result = true;
			boolean hasRole = false;
			if(!child.getUrl().equals("")) {
				try {
					child.setUrl((String)javaScriptEngine.eval(child.getUrl()));
				} catch (ScriptException e) {
					logger.error(e.getMessage());
				}
			}
			if(!child.getScript().equals("")) {
			    String script = child.getScript();
			    try {
			    	result = (boolean)javaScriptEngine.eval(script);
				} catch (ScriptException e) {
					logger.error(e.getMessage());
				}
			}
			for(GrantedAuthority authority : user.getAuthorities()) {
				if(child.getRole().contains(authority.getAuthority())) {
					hasRole = true;
					continue;
				}
			}
			if(!hasRole || !result)
	    		child.setVisible(false);
			else
	    		child.setVisible(true);

	    	if(child.getMenuItems() != null && child.getMenuItems().size() > 0) {
				appendMenu(child, user);
    		}
		}
	}
}
