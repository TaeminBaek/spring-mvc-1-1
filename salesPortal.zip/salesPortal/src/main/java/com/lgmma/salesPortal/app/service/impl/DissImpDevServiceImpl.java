
package com.lgmma.salesPortal.app.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.lgmma.salesPortal.app.dao.CommonApprDao;
import com.lgmma.salesPortal.app.dao.CommonDao;
import com.lgmma.salesPortal.app.dao.DissFieldTestDao;
import com.lgmma.salesPortal.app.dao.DissImpDevDao;
import com.lgmma.salesPortal.app.dao.DissKpiDao;
import com.lgmma.salesPortal.app.dao.DissMemberDao;
import com.lgmma.salesPortal.app.dao.DissRecipeDao;
import com.lgmma.salesPortal.app.dao.DissScheduleDao;
import com.lgmma.salesPortal.app.dao.DissStepDao;
import com.lgmma.salesPortal.app.dao.DissTaskResultDao;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissFieldTestVO;
import com.lgmma.salesPortal.app.model.DissImpDevVO;
import com.lgmma.salesPortal.app.model.DissKpiVO;
import com.lgmma.salesPortal.app.model.DissMemberVO;
import com.lgmma.salesPortal.app.model.DissRecipeVO;
import com.lgmma.salesPortal.app.model.DissScheduleVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.model.DissTaskResultVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.DissImpDevService;
import com.lgmma.salesPortal.app.service.DissPublicService;
import com.lgmma.salesPortal.app.service.DissSpecInService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.props.ApplState;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

import freemarker.template.Configuration;

@Service
public class DissImpDevServiceImpl implements DissImpDevService {

	private static Logger logger = LoggerFactory.getLogger(DissImpDevServiceImpl.class);
	private final String REPORT_TEMPLATE_DISS_SPECIN_IMP_DEV_PROPOSAL 	  = "REPORT_TEMPLATE_DISS_SPECIN_IMP_DEV_PROPOSAL"; //kjy	
	private final String REPORT_TEMPLATE_DISS_PROD_IMP_DEV_PROPOSAL   	  = "REPORT_TEMPLATE_DISS_PROD_IMP_DEV_PROPOSAL";
	private final String REPORT_TEMPLATE_DISS_PUBLIC_IMP_DEV_PRESCRIPTION = "REPORT_TEMPLATE_DISS_PUBLIC_IMP_DEV_PRESCRIPTION";
	private final String REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_EVAL   		  = "REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_EVAL";
	
	@Autowired
	private DissCommonApprMgmtService dissCommonApprMgmtService;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Autowired
	private CommonFileService commonFileService;
	
	@Autowired
	DissImpDevDao dissImpDevDao;

	@Autowired
	DissKpiDao dissKpiDao;

	@Autowired
	DissScheduleDao dissScheduleDao;

	@Autowired
	DissMemberDao dissMemberDao;

	@Autowired
	DissStepDao dissStepDao;

	@Autowired
	DissFieldTestDao dissFieldTestDao;

	@Autowired
	DissTaskResultDao dissTaskResultDao;

	@Autowired
	DissRecipeDao dissRecipeDao;

	@Autowired
	CommonApprDao commonApprDao;

	@Autowired
	private CommonService commonService;

	@Autowired
	private DissSpecInService dissSpecInService;
	
	@Autowired
	private SapSearchService sapSearchService;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;

	@Autowired
	private DissPublicService dissPublicService;

	@Autowired
	CommonDao commonDao;

	@Autowired
	private MailingService mailingService;
	
	@Autowired
    @Qualifier(value="reportFreemarkerConfiguration")
    private Configuration reportTemplateConfiguration;

	@Transactional
	@Override
	public void createDissImpDev(DissImpDevVO param) {
		int cntDissKpi = param.getDissKpiList().size();
		int cntDissSchedule = param.getDissScheduleList().size();
		int cntDissMember = param.getDissMemberList().size();
		String stepId = Util.getUUID();
		//DISS 개선개발과제마스터 등록
		param.setTaskId(Util.getUUID());
		param.setTaskType("IMPDEV");
		dissImpDevDao.createDissImpDev(param);
		//DISS 개선개발과제마스터 HIS 등록
		param.setStepId(stepId);
		dissImpDevDao.createDissImpDevHis(param);
		//DISS KPI관리 등록
		if (cntDissKpi > 0) {
			for (DissKpiVO vo : param.getDissKpiList()) {
				vo.setKpiId(Util.getUUID());
				vo.setTaskId(param.getTaskId());
				vo.setTaskType("IMPDEV");
				vo.setRegiIdxx(param.getRegiIdxx());
				dissKpiDao.createDissKpi(vo);
				//DISS KPI관리 HIS 등록
				vo.setStepId(stepId);
				dissKpiDao.createDissKpiHis(vo);
			}
		}
		//DISS 과제일정관리 등록
		if (cntDissSchedule > 0) {
			for (DissScheduleVO vo : param.getDissScheduleList()) {
				// 견본송부일정 인경우 영업팀소속 담당자인지 체크
				if("400".equals(vo.getStepGroup()))
					dissPublicService.chkSalesTeam(vo.getEmpId());

				vo.setTaskId(param.getTaskId());
				vo.setTaskType("IMPDEV");
				vo.setPlanCompYmd(vo.getCompGoalYmd());
				vo.setRegiIdxx(param.getRegiIdxx());
				dissScheduleDao.createDissSchedule(vo);
				//DISS 과제일정관리 HIS 등록
				vo.setStepId(stepId);
				dissScheduleDao.createDissScheduleHis(vo);
			}
		}
		//DISS 과제멤버관리 등록
		if (cntDissMember > 0) {
			for (DissMemberVO vo : param.getDissMemberList()) {
				if (!vo.getMngEmpId().equals("")) {
					vo.setTaskMemberId(Util.getUUID());
					vo.setTaskId(param.getTaskId());
					vo.setTaskType("IMPDEV");
					vo.setRegiIdxx(param.getRegiIdxx());
					dissMemberDao.createDissMember(vo);
					//DISS 과제멤버관리 HIS 등록
					vo.setStepId(stepId);
					dissMemberDao.createDissMemberHis(vo);
				}
			}
		}
		//DISS 차수 단계 등록
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(Util.getUUID());
		dissStepVO.setTaskId(param.getTaskId());
		dissStepVO.setTaskType("IMPDEV"); //개선개발 DISS_TASK_TYPE
		dissStepVO.setStepCd("300900"); //차수생성 DISS_STEP_CD
		dissStepVO.setDegreeNo(1);
		dissStepVO.setStepLastYn("Y");
		dissStepVO.setRegiIdxx(param.getRegiIdxx());
		dissStepDao.createDissStep(dissStepVO);
		//DISS 개발제안 단계 등록
		String apprId = Util.getUUID();
		dissStepVO.setApprId(apprId);
		dissStepVO.setStepId(stepId);
		dissStepVO.setStepCd("200100"); //개발제안 DISS_STEP_CD
		dissStepDao.createDissStep(dissStepVO);
		//공통품의
		String saveType = param.getApprVO().getSaveType();
		String apprStat = ("SAVE".equals(saveType)) ? ApprState.APPR_PROCEEDING.getCode() : ApprState.TEMP_SAVE.getCode();
		String apprType = ApprType.APPR_TYPE_DISS_IMPDEV_PROPOSAL.getCode();
		ApprVO apprVO = param.getApprVO();
		apprVO.setApprId(apprId);
		apprVO.setApprType(apprType);
		apprVO.setApprStat(apprStat);
		apprVO.setRegiIdxx(param.getRegiIdxx());
		apprVO.setUpdtIdxx(param.getUpdtIdxx());
		
		dissStepVO.setApprType(apprType); //KJY
		
		// 업무테이블 품의서 기초내용 작성 호출  kjy
		String templeteFormContent = param.getApprVO().getFormCont();
		dissStepVO.setFileId(param.getApprVO().getFileId());// 20200824
		param.getApprVO().setTempleteFormContent(getApprFormContProposal(dissStepVO, templeteFormContent));			
		
		dissCommonApprMgmtService.saveDissCommonAppr(apprVO, apprStat, false);
	}

	@Override
	public int getDissTaskNameCount(DissImpDevVO param) {
		return dissImpDevDao.getDissTaskNameCount(param);
	}

	@Override
	public int getDissImpDevListCount(DissImpDevVO param) {
		return dissImpDevDao.getDissImpDevListCount(param);
	}

	@Override
	public List<DissImpDevVO> getDissImpDevList(DissImpDevVO param) {
		return dissImpDevDao.getDissImpDevList(param);
	}

	@Override
	public List<DissImpDevVO> getDissImpDevLeaderTeamList() {
		return dissImpDevDao.getDissImpDevLeaderTeamList();
	}

	@Override
	public List<CommonCodeVO> getDissStepGroupToStepCdList(CommonCodeVO param) {
		return dissImpDevDao.getDissStepGroupToStepCdList(param);
	}

	@Override
	public DissImpDevVO getDissImpDevDetail(DissImpDevVO param) {
		//제품개선개발 과제 마스터 조회
		DissImpDevVO returnItem = dissImpDevDao.getDissImpDevDetail(param);
		//KPI조회
		DissKpiVO paramKpi = new DissKpiVO();
		paramKpi.setTaskId(param.getTaskId());
		List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiList(paramKpi);
		returnItem.setDissKpiList(dissKpiList);
		//멤버 LISTAGG 조회
		DissMemberVO paramMember = new DissMemberVO();
		paramMember.setTaskId(param.getTaskId());
		List<DissMemberVO> dissMemberListaggList = dissMemberDao.getDissMemberListaggList(paramMember);
		returnItem.setDissMemberListaggList(dissMemberListaggList);
		//멤버 조회(수정시 사용)
		List<DissMemberVO> dissMemberList = dissMemberDao.getDissMemberList(paramMember);
		returnItem.setDissMemberList(dissMemberList);
		//일정조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getTaskId());
		List<DissScheduleVO> dissScheduleList = dissScheduleDao.getDissScheduleList(paramSchedule);
		returnItem.setDissScheduleList(dissScheduleList);
		//과제STEP 조회
		DissStepVO paramStep = new DissStepVO();
		paramStep.setTaskId(param.getTaskId());
		paramStep.setUpdtIdxx(param.getUpdtIdxx());
		List<DissStepVO> dissStepList = dissStepDao.getDissStepRegiList(paramStep);
		returnItem.setDissStepList(dissStepList);

		return returnItem;
	}

	@Transactional
	@Override
	public void updateDissImpDevAll(DissImpDevVO param) {
		int cntDissKpi = param.getDissKpiList().size();
		int cntDissSchedule = param.getDissScheduleList().size();
		int cntDissMember = param.getDissMemberList().size();
		DissStepVO dissStepVO = new DissStepVO();
		String stepId = "";
		//개선개발 제안서 최종 스텝ID조회
		dissStepVO.setTaskId(param.getTaskId());
		stepId = dissStepDao.getDissStepLastImpDevProposalStepId(dissStepVO);
		//DISS 개선개발과제마스터 수정
		dissImpDevDao.updateDissImpDev(param);
		//DISS 개선개발과제마스터 HIS 수정
		param.setStepId(stepId);
		dissImpDevDao.updateDissImpDevHis(param);
		//DISS KPI관리 삭제
		DissKpiVO dissKpiVO = new DissKpiVO();
		dissKpiVO.setTaskId(param.getTaskId());
		dissKpiDao.deleteDissKpiAll(dissKpiVO);
		//DISS KPI관리 HIS 삭제
		dissKpiVO.setStepId(stepId);
		dissKpiDao.deleteDissKpiHisAll(dissKpiVO);
		//DISS KPI관리 등록
		if (cntDissKpi > 0) {
			for (DissKpiVO vo : param.getDissKpiList()) {
				vo.setKpiId(Util.getUUID());
				vo.setTaskId(param.getTaskId());
				vo.setTaskType("IMPDEV");
				vo.setRegiIdxx(param.getRegiIdxx());
				dissKpiDao.createDissKpi(vo);
				//DISS KPI관리 HIS 등록
				vo.setStepId(stepId);
				dissKpiDao.createDissKpiHis(vo);
			}
		}
		//DISS 과제일정관리 수정 또는 신규
		if (cntDissSchedule > 0) {
			for (DissScheduleVO vo : param.getDissScheduleList()) {
				//담당자가 없으면 삭제
				if (vo.getEmpId().equals("")) {
					vo.setTaskId(param.getTaskId());
					dissScheduleDao.deleteDissSchedule(vo);
					vo.setStepId(stepId);
					dissScheduleDao.deleteDissScheduleHis(vo);
				} else {
					// 견본송부일정 인경우 영업팀소속 담당자인지 체크
					if ("400".equals(vo.getStepGroup())) {
						dissPublicService.chkSalesTeam(vo.getEmpId());
					}
					vo.setTaskId(param.getTaskId());
					vo.setTaskType("IMPDEV");
					vo.setPlanCompYmd(vo.getCompGoalYmd());
					vo.setRegiIdxx(param.getRegiIdxx());
					dissScheduleDao.mergeDissSchedule(vo);
					//DISS 과제일정관리 HIS 수정 또는 신규
					vo.setStepId(stepId);
					dissScheduleDao.mergeDissScheduleHis(vo);
				}
			}
		}
		//DISS 과제멤버관리 삭제
		DissMemberVO dissMemberVO = new DissMemberVO();
		dissMemberVO.setTaskId(param.getTaskId());
		dissMemberDao.deleteDissMemberAll(dissMemberVO);
		//DISS 과제멤버관리 HIS 삭제
		dissMemberVO.setStepId(stepId);
		dissMemberDao.deleteDissMemberHisAll(dissMemberVO);
		//DISS 과제멤버관리 등록
		if (cntDissMember > 0) {
			for (DissMemberVO vo : param.getDissMemberList()) {
				if (!vo.getMngEmpId().equals("")) {
					vo.setTaskMemberId(Util.getUUID());
					vo.setTaskId(param.getTaskId());
					vo.setTaskType("IMPDEV");
					vo.setRegiIdxx(param.getRegiIdxx());
					dissMemberDao.createDissMember(vo);
					//DISS 과제멤버관리 HIS 등록
					vo.setStepId(stepId);
					dissMemberDao.createDissMemberHis(vo);
				}
			}
		}
	}

	@Transactional
	@Override
	public void updateDissImpDev(DissImpDevVO param) {
		int cntDissKpi      = param.getDissKpiList().size();
		int cntDissSchedule = param.getDissScheduleList().size();
		int cntDissMember = param.getDissMemberList().size();
		String stepId = Util.getUUID();
		DissStepVO dissStepVO = new DissStepVO();
		//스텝 최대 차수 조회
		int maxStepDgreeNo = 1;
		dissStepVO.setTaskId(param.getTaskId());
		maxStepDgreeNo = dissStepDao.getDissStepMaxDegreeNo(dissStepVO);
		//DISS 과제수정 단계 등록
		dissStepVO.setStepId(stepId);
		dissStepVO.setTaskId(param.getTaskId());
		dissStepVO.setTaskType("IMPDEV"); //개선개발 DISS_TASK_TYPE
		dissStepVO.setStepCd("900000"); //과제수정 DISS_STEP_CD
		dissStepVO.setDegreeNo(maxStepDgreeNo);
		dissStepVO.setStepLastYn("Y");
		dissStepVO.setRegiIdxx(param.getRegiIdxx());
		//스텝최종여부 N으로 변경
		dissStepDao.updateDissStepLastYn(dissStepVO);
		dissStepDao.createDissStep(dissStepVO);
		//DISS KPI관리 등록
		if (cntDissKpi > 0) {
			DissKpiVO dissKpiVO = new DissKpiVO();
			dissKpiVO.setTaskId(param.getTaskId());
			dissKpiDao.deleteDissKpiAll(dissKpiVO);
			for (DissKpiVO vo : param.getDissKpiList()) {
				vo.setKpiId(Util.getUUID());
				vo.setTaskId(param.getTaskId());
				vo.setTaskType("IMPDEV");
				vo.setRegiIdxx(param.getRegiIdxx());
				dissKpiDao.createDissKpi(vo);
				//DISS KPI관리 HIS 등록
				vo.setStepId(stepId);
				dissKpiDao.createDissKpiHis(vo);
			}
		}

		//DISS 과제멤버관리 삭제
		DissMemberVO dissMemberVO = new DissMemberVO();
		dissMemberVO.setTaskId(param.getTaskId());
		dissMemberDao.deleteDissMemberAll(dissMemberVO);
		//DISS 과제멤버관리 등록
		if (cntDissMember > 0) {
			for (DissMemberVO vo : param.getDissMemberList()) {
				if (!vo.getMngEmpId().equals("")) {
					vo.setTaskMemberId(Util.getUUID());
					vo.setTaskId(param.getTaskId());
					vo.setTaskType("IMPDEV");
					vo.setRegiIdxx(param.getRegiIdxx());
					dissMemberDao.createDissMember(vo);
					//DISS 과제멤버관리 HIS 등록
					vo.setStepId(stepId);
					dissMemberDao.createDissMemberHis(vo);
				}
			}
		}

		/* 일정 수정은 품의를 통해서 가능하도록 수정 CSR ID:4326392
		//DISS 과제일정관리 수정 또는 신규
		if (cntDissSchedule > 0) {
			for (DissScheduleVO vo : param.getDissScheduleList()) {
				//담당자가 없으면 삭제
				if (vo.getEmpId().equals("")) {
					vo.setTaskId(param.getTaskId());
					dissScheduleDao.deleteDissSchedule(vo);
				} else {
					// 견본송부일정 인경우 영업팀소속 담당자인지 체크
					if ("400".equals(vo.getStepGroup())) {
						dissPublicService.chkSalesTeam(vo.getEmpId());
					}

					vo.setTaskId(param.getTaskId());
					vo.setTaskType("IMPDEV");
					vo.setRegiIdxx(param.getRegiIdxx());
					dissScheduleDao.mergeDissSchedule(vo);
					//DISS 과제일정관리 HIS 수정 또는 신규
					vo.setStepId(stepId);
					dissScheduleDao.mergeDissScheduleHis(vo);
				}
			}
		}
		*/
	}

	@Transactional
	@Override
	public void updateImpDevSchedule(DissImpDevVO param) {
		boolean tempChk = !"".equals(param.getStepId());

		String stepId = tempChk ? param.getStepId() : Util.getUUID();
		String apprId = tempChk ? param.getApprId() : Util.getUUID();
		String taskType = "IMPDEV";
		String taskId   = param.getTaskId();

		// 권한 체크
		DissImpDevVO checkImpDevVO = (DissImpDevVO) StringUtil.nullToEmptyString(dissImpDevDao.getDissImpDevDetail(param));
		if(!param.getUpdtIdxx().equals(checkImpDevVO.getLeaderEmpId())) {
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.\n(제품개선개발 일정수정은 과제 리더만 가능 합니다.)");
		}

//		checkImpDevVO.setStepId(stepId);
//		if(tempChk)	dissImpDevDao.deleteDissImpDevHisAll(checkImpDevVO);
//		dissImpDevDao.createDissImpDevHis(checkImpDevVO);

		if(!tempChk) {
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setTaskId(taskId);
			dissStepVO.setTaskType(taskType);
			dissStepVO.setApprId(apprId);
			dissStepVO.setStepId(stepId);
			dissStepVO.setStepCd("900000"); // 과제수정스텝으로
			dissStepVO.setUpdtIdxx(param.getUpdtIdxx());
			dissStepVO.setRegiIdxx(param.getRegiIdxx());
			dissStepDao.createDissStep(dissStepVO);
		}

		// 스케쥴 원본데이타 가져오기
		DissScheduleVO scheduleVOParam = new DissScheduleVO();
		scheduleVOParam.setTaskId(taskId);
		List<DissScheduleVO> dissScheduleVOList = dissScheduleDao.getDissScheduleList(scheduleVOParam);
		List<DissScheduleVO> editedScheduleVOList = param.getDissScheduleList();
		
		// 원본데이타와 수정 데이타 머지하면서 히스토리 생성
		for(DissScheduleVO dissScheduleVO : dissScheduleVOList) {
			dissScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(dissScheduleVO);
			for(DissScheduleVO editScheduleVO: editedScheduleVOList) {
				editScheduleVO = (DissScheduleVO) StringUtil.nullToEmptyString(editScheduleVO);
				if(dissScheduleVO.getStepGroup().equals(editScheduleVO.getStepGroup())){
					dissScheduleVO.setStepId(stepId);
					dissScheduleVO.setCompGoalYmd(editScheduleVO.getCompGoalYmd());
					dissScheduleVO.setEmpId(editScheduleVO.getEmpId());
					dissScheduleVO.setDevEmpId(editScheduleVO.getDevEmpId());
					dissScheduleVO.setUpdtIdxx(param.getUpdtIdxx());
					dissScheduleVO.setRegiIdxx(param.getRegiIdxx());
					dissScheduleDao.mergeDissScheduleHis(dissScheduleVO);
				}
			}
		}

		ApprVO apprVO = param.getApprVO();
		apprVO.setApprId(apprId);
		apprVO.setRegiIdxx(param.getRegiIdxx());
		apprVO.setUpdtIdxx(param.getUpdtIdxx());

		dissCommonApprMgmtService.saveDissCommonAppr(apprVO, ApprState.APPR_PROCEEDING.getCode(), false);
	}

	@Override
	public void deleteImpDevScheduleEdit(DissImpDevVO param) {
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(param.getApprId());
		apprVO = commonApprDao.getAppr(apprVO);
		if(!apprVO.getRegiIdxx().equals(param.getUpdtIdxx())){
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
		}

		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(param.getStepId());
		DissScheduleVO dissScheduleVO = new DissScheduleVO();
		dissScheduleVO.setStepId(param.getStepId());

		dissCommonApprMgmtService.deleteDissAppr(apprVO);
		dissStepDao.deleteDissStep(dissStepVO);
		dissScheduleDao.deleteDissScheduleHisAll(dissScheduleVO);
	}

	@Override
	public void applDissImpDevScheduleEdit(DissApprCommonParamVO dissApprCommonParamVO) {
		String apprId = dissApprCommonParamVO.getApprId();
		String taskId = dissApprCommonParamVO.getTaskId();
		String stepId = dissApprCommonParamVO.getStepId();

		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(apprId);                     // 품의서ID
		apprLineVO.setApprEmpId(dissApprCommonParamVO.getApprEmpId());              // 결재자사번
		apprLineVO.setApprLineComment(dissApprCommonParamVO.getApprLineComment());  // 결재자의견
		apprLineVO.setApplStat(dissApprCommonParamVO.getApplStat());                 // 결재자 결재결과
		apprLineVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());

		// DISS 공통 품의서 결재 호출
		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);

		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(apprId);
		if(dissCommonApprMgmtService.checkListApplActYn(apprVO, dissApprCommonParamVO.getApprEmpId())
		&& ApplState.APPL_APPROVE.getCode().equals(dissApprCommonParamVO.getApplStat())) {
			DissScheduleVO scheduleVOParam = new DissScheduleVO();
			scheduleVOParam.setStepId(stepId);
			List<DissScheduleVO> editedScheduleVOList = dissScheduleDao.getDissScheduleHisList(scheduleVOParam);

			for(DissScheduleVO dissScheduleVO : editedScheduleVOList) {
				dissScheduleVO.setTaskId(taskId);
				dissScheduleDao.updateDissSchedule(dissScheduleVO);
			}
		}
	}

	@Transactional
	@Override
	public void deleteDissImpDevAll(DissStepVO param) {
		//개선개발 제안서 최종 스텝ID조회
		String stepId = dissStepDao.getDissStepLastImpDevProposalStepId(param);
		//DISS 개선개발과제마스터 삭제
		DissImpDevVO dissImpDevVO = new DissImpDevVO();
		dissImpDevVO.setTaskId(param.getTaskId());
		dissImpDevDao.deleteDissImpDevAll(dissImpDevVO);
		//DISS 개선개발과제마스터 HIS 삭제
		dissImpDevVO.setStepId(stepId);
		dissImpDevDao.deleteDissImpDevHisAll(dissImpDevVO);
		//DISS KPI관리 삭제
		DissKpiVO dissKpiVO = new DissKpiVO();
		dissKpiVO.setTaskId(param.getTaskId());
		dissKpiDao.deleteDissKpiAll(dissKpiVO);
		//DISS KPI관리 HIS 삭제
		dissKpiVO.setStepId(stepId);
		dissKpiDao.deleteDissKpiHisAll(dissKpiVO);
		//DISS 과제일정관리 삭제
		DissScheduleVO dissScheduleVO = new DissScheduleVO();
		dissScheduleVO.setTaskId(param.getTaskId());
		dissScheduleDao.deleteDissScheduleAll(dissScheduleVO);
		//DISS 과제일정관리 HIS 삭제
		dissScheduleVO.setStepId(stepId);
		dissScheduleDao.deleteDissScheduleHisAll(dissScheduleVO);
		//DISS 과제멤버관리 삭제
		DissMemberVO dissMemberVO = new DissMemberVO();
		dissMemberVO.setTaskId(param.getTaskId());
		dissMemberDao.deleteDissMemberAll(dissMemberVO);
		//DISS 과제멤버관리 HIS 삭제
		dissMemberVO.setStepId(stepId);
		dissMemberDao.deleteDissMemberHisAll(dissMemberVO);
		//DISS 과제STEP 삭제
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setTaskId(param.getTaskId());
		dissStepDao.deleteDissStepAll(dissStepVO);
		//공통 품의서 삭제
		ApprVO apprVO = new ApprVO();
		String apprId = param.getApprId();
		apprVO.setApprId(apprId);
		ApprVO checkApprVO = commonApprDao.getAppr(apprVO);
		if (!checkApprVO.getRegiIdxx().equals(param.getUpdtIdxx())) {
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
		}
		dissCommonApprMgmtService.deleteDissAppr(apprVO);
	}

	@Transactional
	@Override
	public void deleteDissImpDevApprType(DissImpDevVO param) {
		String stepId = param.getStepId();
		String apprType = param.getApprVO().getApprType();

		//개선개발 제안서
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PROPOSAL.getCode())) {
			//DISS 개선개발과제마스터 HIS 삭제
			dissImpDevDao.deleteDissImpDevHisAll(param);
			//DISS KPI관리 HIS 삭제
			DissKpiVO paramKpi = new DissKpiVO();
			paramKpi.setStepId(stepId);
			dissKpiDao.deleteDissKpiHisAll(paramKpi);
		}
		//개선개발 변경
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_LEVEL_CHG.getCode())) {
			//DISS 개선개발과제마스터 HIS 삭제
			dissImpDevDao.deleteDissImpDevHisAll(param);
		}
		//소재개발 결과등록
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode())) {
			//개발결과 삭제
			DissTaskResultVO paramTaskResult = new DissTaskResultVO();
			paramTaskResult.setStepId(stepId);
			dissTaskResultDao.deleteDissTaskResultAll(paramTaskResult);
			//DISS 처방 삭제
			DissRecipeVO paramRecipe = new DissRecipeVO();
			paramRecipe.setStepId(stepId);
			dissRecipeDao.deleteDissRecipeAll(paramRecipe);
			//DISS KPI관리 HIS 삭제
			DissKpiVO paramKpi = new DissKpiVO();
			paramKpi.setStepId(stepId);
			dissKpiDao.deleteDissKpiHisAll(paramKpi);
		}
		//TS견본검증결과보고
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_SAMPLEEVAL.getCode())) {
			//DISS KPI관리 HIS 삭제
			DissKpiVO paramKpi = new DissKpiVO();
			paramKpi.setStepId(stepId);
			dissKpiDao.deleteDissKpiHisAll(paramKpi);
		}
		//DISS 스텝 삭제
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(stepId);
		dissStepDao.deleteDissStep(dissStepVO);
		//DISS 스텝 최종여부 N으로 변경
		dissStepDao.updateDissStepLastYn(dissStepVO);
		//공통품의 삭제
		ApprVO apprVO = param.getApprVO();
		ApprVO checkApprVO = commonApprDao.getAppr(apprVO);
		if (!checkApprVO.getRegiIdxx().equals(param.getUpdtIdxx())) {
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
		}
		dissCommonApprMgmtService.deleteDissAppr(apprVO);
	}

	@Transactional
	@Override
	public void saveDissImpDevApprTypeRew(DissImpDevVO param) {
		String regiIdxx = param.getRegiIdxx();
		String rewStepId = Util.getUUID();
		String rewApprId = Util.getUUID();
		String stepId = param.getStepId();
		String apprType = param.getApprVO().getApprType();
		Integer degreeNo = 1;
		DissStepVO dissStepVO = new DissStepVO();
		//스텝의 최대 차수 조회
		dissStepVO.setTaskId(param.getTaskId());
		degreeNo = dissStepDao.getDissStepMaxDegreeNo(dissStepVO);
		//개선개발 제안서
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PROPOSAL.getCode())) {
			//DISS 개선개발과제마스터 HIS 등록
			param.setRewStepId(rewStepId);
			dissImpDevDao.createDissImpDevHisProposalApprRew(param);
			//DISS KPI관리 HIS 조회
			DissKpiVO paramKpi = new DissKpiVO();
			paramKpi.setStepId(stepId);
			List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisList(paramKpi);
			int cntDissKpi = dissKpiList.size();
			//DISS KPI관리 HIS 등록
			if (cntDissKpi > 0) {
				for (DissKpiVO vo : dissKpiList) {
					vo.setKpiId(Util.getUUID());
					vo.setStepId(rewStepId);
					vo.setRegiIdxx(regiIdxx);
					dissKpiDao.createDissKpiHis(vo);
				}
			}
		}
		//개선개발 변경
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_LEVEL_CHG.getCode())) {
			//DISS 개선개발과제마스터 HIS 등록
			param.setRewStepId(rewStepId);
			dissImpDevDao.createDissImpDevHisProposalApprRew(param);
		}
		//소재개발 결과등록
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode())) {
			//개발결과 등록
			DissTaskResultVO paramTaskResult = new DissTaskResultVO();
			paramTaskResult.setStepId(stepId);
			DissTaskResultVO dissTaskResultVO = dissTaskResultDao.getDissTaskResultDetail(paramTaskResult);
			dissTaskResultVO.setStepId(rewStepId);
			dissTaskResultVO.setRegiIdxx(regiIdxx);
			dissTaskResultDao.createDissTaskResult(dissTaskResultVO);
			//DISS 처방 조회
			DissRecipeVO paramRecipe = new DissRecipeVO();
			paramRecipe.setStepId(stepId);
			List<DissRecipeVO> dissRecipeList = dissRecipeDao.getDissRecipeList(paramRecipe);
			int cntDissRecipe = dissRecipeList.size();
			//DISS KPI관리 HIS 조회
			DissKpiVO paramKpi = new DissKpiVO();
			paramKpi.setStepId(stepId);
			List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisList(paramKpi);
			int cntDissKpi = dissKpiList.size();
			Integer recipeNo = 1;
			//DISS 처방 등록
			if (cntDissRecipe > 0) {
				for (DissRecipeVO vo : dissRecipeList) {
					vo.setRecipeId(Util.getUUID());
					recipeNo = 1;
					//KPI 리스트에 처방ID 매핑
					for (int i = 0; i < cntDissKpi; i++) {
						recipeNo = dissKpiList.get(i).getRecipeNo();
						if (recipeNo == vo.getRecipeNo()) {
							dissKpiList.get(i).setRecipeId(vo.getRecipeId());
						}
					}
					vo.setRegiIdxx(regiIdxx);
					dissRecipeDao.createDissRecipe(vo);
				}
			}
			//DISS KPI관리 HIS 등록
			if (cntDissKpi > 0) {
				for (DissKpiVO vo : dissKpiList) {
					vo.setStepId(rewStepId);
					vo.setKpiId(Util.getUUID());
					vo.setRegiIdxx(regiIdxx);
					dissKpiDao.createDissKpiHis(vo);
				}
			}
		}
		//TS견본검증결과보고
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_SAMPLEEVAL.getCode())) {
			//TS견본검증결과 조회
			DissStepVO paramStep = new DissStepVO();
			paramStep.setStepId(stepId);
			DissStepVO dissStepRsltVO = dissStepDao.getDissStepRsltInfo(paramStep);
			//TS견본검증결과 VO 셋팅
			dissStepVO.setStepRslt(dissStepRsltVO.getStepRslt());
			//DISS KPI관리 HIS 조회
			DissKpiVO paramKpi = new DissKpiVO();
			paramKpi.setStepId(stepId);
			List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisList(paramKpi);
			int cntDissKpi = dissKpiList.size();
			//DISS KPI관리 HIS 등록
			if (cntDissKpi > 0) {
				for (DissKpiVO vo : dissKpiList) {
					vo.setStepId(rewStepId);
					vo.setKpiId(Util.getUUID());
					vo.setRegiIdxx(regiIdxx);
					dissKpiDao.createDissKpiHis(vo);
				}
			}
		}
		//DISS 스텝
		dissStepVO.setApprId(rewApprId);
		dissStepVO.setStepId(stepId);
		dissStepVO.setTaskId(param.getTaskId());
		dissStepVO.setTaskType(param.getTaskType());
		dissStepVO.setStepCd(param.getStepCd());
		dissStepVO.setDegreeNo(degreeNo);
		dissStepVO.setStepLastYn("Y");
		dissStepVO.setRegiIdxx(regiIdxx);
		//스텝최종여부 N으로 변경
		dissStepDao.updateDissStepLastYn(dissStepVO);
		//DISS 스텝 등록
		dissStepVO.setStepId(rewStepId);
		dissStepDao.createDissStep(dissStepVO);
		//공통품의
		String apprStat = ApprState.TEMP_SAVE.getCode();
		ApprVO apprVO = param.getApprVO();
		apprVO.setApprId(rewApprId);
		apprVO.setApprStat(apprStat);
		apprVO.setRegiIdxx(param.getRegiIdxx());
		apprVO.setUpdtIdxx(param.getUpdtIdxx());

		dissCommonApprMgmtService.saveDissCommonAppr(apprVO, apprStat, false);
	}

	@Transactional
	@Override
	public void saveDissImpDevApprType(DissImpDevVO param) {
		String apprType = param.getApprVO().getApprType();
		String apprId = "";
		Integer degreeNo = 1;
		DissStepVO dissStepVO = new DissStepVO();
		String stepId = "";

		if (param.getApprVO().getApprId().equals("")) {
			apprId = Util.getUUID();
			//스텝의 최대 차수 조회
			dissStepVO.setTaskId(param.getTaskId());
			degreeNo = dissStepDao.getDissStepMaxDegreeNo(dissStepVO);
		}
		//스텝ID 신규, 수정 분기
		if (param.getStepId().equals("")) {
			stepId = Util.getUUID();
		} else {
			stepId = param.getStepId();
		}
		//개선개발 제안서
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PROPOSAL.getCode())) {
			int cntDissKpi = param.getDissKpiList().size();
			if (param.getStepId().equals("")) {
				//DISS 개선개발과제마스터 HIS 신규
				param.setStepId(stepId);
				if (param.getTaskType().equals("IMPDEV")) {
					dissImpDevDao.createDissImpDevHisProposalAppr(param);
				} else if (param.getTaskType().equals("SPECIN")) {
					dissImpDevDao.createDissImpDevHis(param);
				}
			} else {
				//DISS 개선개발과제마스터 HIS 수정
				dissImpDevDao.updateDissImpDevHisProposalAppr(param);
			}
			//DISS KPI관리 HIS 삭제
			DissKpiVO dissKpiVO = new DissKpiVO();
			dissKpiVO.setStepId(stepId);
			dissKpiDao.deleteDissKpiHisAll(dissKpiVO);
			//DISS KPI관리 HIS 등록
			if (cntDissKpi > 0) {
				for (DissKpiVO vo : param.getDissKpiList()) {
					vo.setKpiId(Util.getUUID());
					vo.setTaskType(param.getTaskType());
					vo.setRegiIdxx(param.getRegiIdxx());
					vo.setStepId(stepId);
					dissKpiDao.createDissKpiHis(vo);
				}
			}
			//품의서ID가 없으면 단계 등록
			if (param.getApprVO().getApprId().equals("")) {
				//DISS 개선개발 변경 단계 등록
				dissStepVO.setApprId(apprId);
				dissStepVO.setStepId(stepId);
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType());
				dissStepVO.setStepCd(param.getStepCd());
				dissStepVO.setDegreeNo(degreeNo);
				dissStepVO.setStepLastYn("Y");
				dissStepVO.setRegiIdxx(param.getRegiIdxx());
				dissStepVO.setApprType(param.getApprVO().getApprType()); //kjy
				
				//스텝최종여부 N으로 변경
				dissStepDao.updateDissStepLastYn(dissStepVO);
				dissStepDao.createDissStep(dissStepVO);
				//공통품의 apprId 설정
				param.getApprVO().setApprId(apprId);
			} else { // kjy
				dissStepVO.setStepId(param.getStepId());
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType());
				dissStepVO.setApprType(param.getApprVO().getApprType());
			}
			// 업무테이블 품의서 기초내용 작성 호출  kjy
			String templeteFormContent = param.getApprVO().getFormCont();
			dissStepVO.setFileId(param.getApprVO().getFileId());// 20200824
			param.getApprVO().setTempleteFormContent(getApprFormContProposal(dissStepVO, templeteFormContent));		
		}
		//개선개발 변경
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_LEVEL_CHG.getCode())) {
			//품의서ID가 없으면 단계 등록
			if (param.getApprVO().getApprId().equals("")) {
				//개발등급 변경 HIS 등록
				param.setStepId(stepId);
				dissImpDevDao.createDissImpDevHisLevelChgAppr(param);
				//DISS 개선개발 변경 단계 등록
				dissStepVO.setApprId(apprId);
				dissStepVO.setStepId(stepId);
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType());
				dissStepVO.setStepCd(param.getStepCd());
				dissStepVO.setDegreeNo(degreeNo);
				dissStepVO.setStepLastYn("Y");
				dissStepVO.setRegiIdxx(param.getRegiIdxx());
				//스텝최종여부 N으로 변경
				dissStepDao.updateDissStepLastYn(dissStepVO);
				dissStepDao.createDissStep(dissStepVO);
				//공통품의 apprId 설정
				param.getApprVO().setApprId(apprId);
			}
		}
		//F/Test 계획
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_PLAN.getCode())
				|| apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_RESULT.getCode())) {
			int cntDissKpi = param.getDissKpiList().size();
			//품의서ID가 없으면 등록
			if (param.getApprVO().getApprId().equals("")) {
				//DISS KPI관리 HIS 등록
				if (cntDissKpi > 0) {
					DissKpiVO paramKpi = new DissKpiVO();
					paramKpi.setTaskId(param.getTaskId());
					List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiList(paramKpi);
					String kpiIdI = "";
					String kpiIdJ = "";
					for (int i = 0; i < dissKpiList.size(); i++) {
						kpiIdI = dissKpiList.get(i).getKpiId();
						for (int j = 0; j < param.getDissKpiList().size(); j++) {
							kpiIdJ = param.getDissKpiList().get(j).getKpiId();
							if (kpiIdI.equals(kpiIdJ)) {
								//F/Test 계획 : 개발결과
								if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_PLAN.getCode())) {
									dissKpiList.get(i).setDevResult(param.getDissKpiList().get(j).getDevResult());
								}
								//F/Test 결과 : F/T결과
								if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_RESULT.getCode())) {
									dissKpiList.get(i).setFtResult(param.getDissKpiList().get(j).getFtResult());
								}
							}
						}
					}
					for (DissKpiVO vo : dissKpiList) {
						vo.setStepId(stepId);
						vo.setRegiIdxx(param.getRegiIdxx());
						dissKpiDao.createDissKpiHis(vo);
					}
				}
				//F/Test 계획 등록
				DissFieldTestVO dissFieldTestVO = param.getFieldTestVO();
				dissFieldTestVO.setStepId(stepId);
				dissFieldTestVO.setRegiIdxx(param.getRegiIdxx());
				dissFieldTestDao.createDissFieldTest(dissFieldTestVO);
				//DISS F/Test 계획 단계 등록
				dissStepVO.setApprId(apprId);
				dissStepVO.setStepId(stepId);
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType()); //개선개발 DISS_TASK_TYPE
				dissStepVO.setStepCd(param.getStepCd());
				dissStepVO.setDegreeNo(degreeNo);
				dissStepVO.setStepLastYn("Y");
				dissStepVO.setRegiIdxx(param.getRegiIdxx());
				//스텝최종여부 N으로 변경
				dissStepDao.updateDissStepLastYn(dissStepVO);
				dissStepDao.createDissStep(dissStepVO);
				//공통품의 apprId 설정
				param.getApprVO().setApprId(apprId);
				//품의서ID가 있으면 수정
			} else {
				//DISS KPI관리 HIS 수정
				for (DissKpiVO vo : param.getDissKpiList()) {
					vo.setStepId(stepId);
					vo.setRegiIdxx(param.getRegiIdxx());
					dissKpiDao.updateDissKpiHis(vo);
				}
				//F/Test 계획 수정
				DissFieldTestVO dissFieldTestVO = param.getFieldTestVO();
				dissFieldTestVO.setStepId(stepId);
				dissFieldTestVO.setRegiIdxx(param.getRegiIdxx());
				dissFieldTestDao.updateDissFieldTest(dissFieldTestVO);
			}
		}
		//Comp'd처방,소재개발 결과등록
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_COMPOUND.getCode())
				|| apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode())) {
			//품의서ID가 없으면 개발결과 등록
			if (param.getApprVO().getApprId().equals("")) {
				DissTaskResultVO dissTaskResultVO = param.getDissTaskResultVO();
				dissTaskResultVO.setStepId(stepId);
				dissTaskResultVO.setDegreeNo(degreeNo);
				dissTaskResultVO.setRegiIdxx(param.getRegiIdxx());
				dissTaskResultDao.createDissTaskResult(dissTaskResultVO);
				//DISS F/Test 계획 단계 등록
				dissStepVO.setApprId(apprId);
				dissStepVO.setStepId(stepId);
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType()); //개선개발 DISS_TASK_TYPE
				dissStepVO.setStepCd(param.getStepCd());
				dissStepVO.setDegreeNo(degreeNo);
				dissStepVO.setStepLastYn("Y");
				dissStepVO.setRegiIdxx(param.getRegiIdxx());
				
				dissStepVO.setApprType(param.getApprVO().getApprType()); //kjy
				
				//스텝최종여부 N으로 변경
				dissStepDao.updateDissStepLastYn(dissStepVO);
				dissStepDao.createDissStep(dissStepVO);
				//공통품의 apprId 설정
				param.getApprVO().setApprId(apprId);
				//품의서ID가 있으면 개발결과 수정
			} else {
				DissTaskResultVO dissTaskResultVO = param.getDissTaskResultVO();
				dissTaskResultVO.setStepId(stepId);
				dissTaskResultVO.setRegiIdxx(param.getRegiIdxx());
				dissTaskResultDao.updateDissTaskResult(dissTaskResultVO);
				//kjy
				dissStepVO.setStepId(param.getStepId());
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType());
				dissStepVO.setApprType(param.getApprVO().getApprType());
				
			}
			//소재개발 결과등록
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode())) {
				//DISS 처방 삭제
				DissRecipeVO dissRecipeVO = new DissRecipeVO();
				dissRecipeVO.setStepId(stepId);
				dissRecipeDao.deleteDissRecipeAll(dissRecipeVO);
				int cntDissRecipe = param.getDissRecipeList().size();
				int cntDissKpi = param.getDissKpiList().size();
				Integer recipeNo = 1;
				//DISS 처방 등록
				if (cntDissRecipe > 0) {
					for (DissRecipeVO vo : param.getDissRecipeList()) {
						vo.setRecipeId(Util.getUUID());
						recipeNo = 1;
						//KPI 리스트에 처방ID 매핑
						for (int i = 0; i < cntDissKpi; i++) {
							recipeNo = param.getDissKpiList().get(i).getRecipeNo();
							if (recipeNo == vo.getRecipeNo()) {
								param.getDissKpiList().get(i).setRecipeId(vo.getRecipeId());
							}
						}
						vo.setTaskId(param.getTaskId());
						vo.setTaskType(param.getTaskType());
						vo.setUseYn("Y");
						vo.setRegiIdxx(param.getRegiIdxx());
						dissRecipeDao.createDissRecipe(vo);
					}
				}
				//DISS KPI관리 HIS 삭제
				DissKpiVO dissKpiVO = new DissKpiVO();
				dissKpiVO.setStepId(stepId);
				dissKpiDao.deleteDissKpiHisAll(dissKpiVO);
				//DISS KPI관리 HIS 등록
				if (cntDissKpi > 0) {
					for (DissKpiVO vo : param.getDissKpiList()) {
						vo.setStepId(stepId);
						vo.setKpiId(Util.getUUID());
						vo.setTaskType(param.getTaskType());
						vo.setRegiIdxx(param.getRegiIdxx());
						dissKpiDao.createDissKpiHis(vo);
					}
				}
			}
			// 업무테이블 품의서 기초내용 작성 호출  kjy
			String templeteFormContent = param.getApprVO().getFormCont();
			dissStepVO.setFileId(param.getApprVO().getFileId());// 20200824
			param.getApprVO().setTempleteFormContent(getApprFormContPrescription(dissStepVO, templeteFormContent));	
		}
		//TS견본검증결과보고
		if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_SAMPLEEVAL.getCode())) {
			//품의서ID가 없으면 개발결과 등록
			if (param.getApprVO().getApprId().equals("")) {
				dissStepVO.setApprId(apprId);
				dissStepVO.setStepId(stepId);
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType()); //개선개발 DISS_TASK_TYPE
				dissStepVO.setStepCd(param.getStepCd());
				dissStepVO.setDegreeNo(degreeNo);
				dissStepVO.setStepRslt(param.getDissStepVO().getStepRslt());
				dissStepVO.setStepLastYn("Y");
				dissStepVO.setRegiIdxx(param.getRegiIdxx());
				dissStepVO.setApprType(param.getApprVO().getApprType()); //kjy
				//스텝최종여부 N으로 변경
				dissStepDao.updateDissStepLastYn(dissStepVO);
				dissStepDao.createDissStep(dissStepVO);
				//공통품의 apprId 설정
				param.getApprVO().setApprId(apprId);
			} else {
				dissStepVO.setStepId(stepId);
				dissStepVO.setStepRslt(param.getDissStepVO().getStepRslt());
				dissStepVO.setRegiIdxx(param.getRegiIdxx());
				//kjy
				dissStepVO.setTaskId(param.getTaskId());
				dissStepVO.setTaskType(param.getTaskType());
				dissStepVO.setApprType(param.getApprVO().getApprType());
				
				dissStepDao.updateDissStepRslt(dissStepVO);
			}
			int cntDissKpi = param.getDissKpiList().size();
			//DISS KPI관리 HIS 삭제
			DissKpiVO dissKpiVO = new DissKpiVO();
			dissKpiVO.setStepId(stepId);
			dissKpiDao.deleteDissKpiHisAll(dissKpiVO);
			//DISS KPI관리 HIS 등록
			if (cntDissKpi > 0) {
				for (DissKpiVO vo : param.getDissKpiList()) {
					vo.setStepId(stepId);
					vo.setKpiId(Util.getUUID());
					vo.setTaskType(param.getTaskType());
					vo.setRegiIdxx(param.getRegiIdxx());
					dissKpiDao.createDissKpiHis(vo);
				}
			}
			// 업무테이블 품의서 기초내용 작성 호출  kjy
			String templeteFormContent = param.getApprVO().getFormCont();
			dissStepVO.setFileId(param.getApprVO().getFileId());// 20200824
			param.getApprVO().setTempleteFormContent(getApprFormContSampleEval(dissStepVO, templeteFormContent));
		}
		//공통품의
		String saveType = param.getApprVO().getSaveType();
		String apprStat = ("SAVE".equals(saveType)) ? ApprState.APPR_PROCEEDING.getCode() : ApprState.TEMP_SAVE.getCode();
		ApprVO apprVO = param.getApprVO();
		apprVO.setApprStat(apprStat);
		apprVO.setRegiIdxx(param.getRegiIdxx());
		apprVO.setUpdtIdxx(param.getUpdtIdxx());

		dissCommonApprMgmtService.saveDissCommonAppr(apprVO, apprStat, false);
	}

	@Override
	public String getApprFormContProposal(DissStepVO param, String templeteFormContent) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();
		//String templeteFormContent = null;
		DissSpecInVO dissSpecInVO = new DissSpecInVO();		
		DissImpDevVO dissImpDevVO2 = new DissImpDevVO();
		String template = null;		
		//String apprType = param.getApprType();	변수 확인 후 input 파라미터 삭제 하자..
		
		// 헤더 조회. 
		if ("SPECIN".equals(param.getTaskType())) {
			dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInTaskBasicInfoDetail(param));
			dissSpecInVO.setTaskType(param.getTaskType());			
			template = REPORT_TEMPLATE_DISS_SPECIN_IMP_DEV_PROPOSAL;
			
			map.put("dissSpecInVO"  , dissSpecInVO);
			
		} else if ("IMPDEV".equals(param.getTaskType())) {			
			template = REPORT_TEMPLATE_DISS_PROD_IMP_DEV_PROPOSAL;			
			
			dissImpDevVO2 = (DissImpDevVO) StringUtil.nullToEmptyString(getDissImpDevTaskBasicInfoDetail(param));
			dissImpDevVO2.setTaskType(param.getTaskType());
			map.put("dissSpecInVO"  , dissImpDevVO2);
		} else {
			throw new ServiceException("", "과제구분 정보가 잘못되었습니다.");
		}	
		
		// 개선개발제안서	getTaskType = "SPECIN"	임. 제품개발은 확인 필요함.
		DissImpDevVO dissImpDevVO = (DissImpDevVO) StringUtil.nullToEmptyString(getDissImpDevApprTypeDetail(param));
		
		//일정조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getTaskId());		
		
		List<DissScheduleVO> getDissScheduleList = dissScheduleDao.getDissScheduleList(paramSchedule);		

		List<DissScheduleVO> dissScheduleList = new ArrayList<DissScheduleVO>();
		for(DissScheduleVO schedule : getDissScheduleList) {
			dissScheduleList.add((DissScheduleVO)StringUtil.nullToEmptyString(schedule));
		}
		
		map.put("dissImpDevVO", dissImpDevVO);
		map.put("dissScheduleList", dissScheduleList);
		map.put("templeteFormContent", templeteFormContent);
		
		List<DissKpiVO> dissKpiList = new ArrayList<DissKpiVO>();
		for(DissKpiVO impDev : dissImpDevVO.getDissKpiList()) {			
			dissKpiList.add((DissKpiVO)StringUtil.nullToEmptyString(impDev));
		}
		map.put("dissKpiList", dissKpiList);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);
		
		map.put("fileVoList", fileVoList);
		
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}
	
	/**
	 * DISS SPEC-IN/제품 소재개발결과등록  내용 
	 *
	 * @param DissStepVO	 
	 * @return
	 */
	@Override
	public String getApprFormContPrescription(DissStepVO param, String templeteFormContent) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();
		DissSpecInVO dissSpecInVO = new DissSpecInVO();		
		DissImpDevVO dissImpDevVO2 = new DissImpDevVO();
		String template = null;
		
		// 헤더 조회. 
		if ("SPECIN".equals(param.getTaskType())) {
			dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInTaskBasicInfoDetail(param));			
			dissSpecInVO.setTaskType(param.getTaskType());						
			map.put("dissSpecInVO"  , dissSpecInVO);
		} else if ("IMPDEV".equals(param.getTaskType())) {
			dissImpDevVO2 = (DissImpDevVO) StringUtil.nullToEmptyString(getDissImpDevTaskBasicInfoDetail(param));			
			dissImpDevVO2.setTaskType(param.getTaskType());			
			map.put("dissSpecInVO"  , dissImpDevVO2);
		} else {
			throw new ServiceException("", "과제구분 정보가 잘못되었습니다.");
		}
		
		template = REPORT_TEMPLATE_DISS_PUBLIC_IMP_DEV_PRESCRIPTION;  // spec-in, 제품개선 공통 템플릿.
		
		// 개선개발제안서	getTaskType = "SPECIN"	임. 제품개발은 확인 필요함.
		DissImpDevVO dissImpDevVO = (DissImpDevVO) StringUtil.nullToEmptyString(getDissImpDevApprTypeDetail(param));
		dissImpDevVO.setTaskType(param.getTaskType());		
		
		//일정조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getTaskId());		
		
		List<DissScheduleVO> getDissScheduleList = dissScheduleDao.getDissScheduleList(paramSchedule);		

		List<DissScheduleVO> dissScheduleList = new ArrayList<DissScheduleVO>();
		for(DissScheduleVO schedule : getDissScheduleList) {
			dissScheduleList.add((DissScheduleVO)StringUtil.nullToEmptyString(schedule));
		}
		
		map.put("dissImpDevVO", dissImpDevVO);
		map.put("getDissTaskResultVO", dissImpDevVO.getDissTaskResultVO());
		map.put("dissScheduleList", dissScheduleList);
		map.put("templeteFormContent", templeteFormContent);
		
		//kpi
		List<DissKpiVO> dissKpiList = new ArrayList<DissKpiVO>();
		for(DissKpiVO impDev : dissImpDevVO.getDissKpiList()) {			
			dissKpiList.add((DissKpiVO)StringUtil.nullToEmptyString(impDev));
		}
		map.put("dissKpiList", dissKpiList);		
		
		// 담당자.
		List<DissTaskResultVO> dissTaskResultList = new ArrayList<DissTaskResultVO>();
		for(DissTaskResultVO schedule : dissImpDevVO.getDissTaskResultList()) {
			dissTaskResultList.add((DissTaskResultVO)StringUtil.nullToEmptyString(schedule));
		}
		map.put("dissTaskResultList", dissTaskResultList);
		
		// 처방개발결과
		List<DissRecipeVO> dissRecipeList = new ArrayList<DissRecipeVO>();
		for(DissRecipeVO schedule : dissImpDevVO.getDissRecipeList()) {
			dissRecipeList.add((DissRecipeVO)StringUtil.nullToEmptyString(schedule));
		}
		map.put("dissRecipeList", dissRecipeList);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);
		
		map.put("fileVoList", fileVoList);
				
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}
	
	/**
	 * DISS SPEC-IN/제품 소재 견본검증결과
	 *
	 * @param DissStepVO	 
	 * @return
	 */
	@Override
	public String getApprFormContSampleEval(DissStepVO param, String templeteFormContent) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();
		//String templeteFormContent = null;
		DissSpecInVO dissSpecInVO = new DissSpecInVO();		
		DissImpDevVO dissImpDevVO2 = new DissImpDevVO();
		String template = null;		
		//String apprType = param.getApprType();
		
		// 헤더 조회. 
		if ("SPECIN".equals(param.getTaskType())) {	
			
			dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInTaskBasicInfoDetail(param));						
			dissSpecInVO.setTaskType(param.getTaskType());						
			map.put("dissSpecInVO"  , dissSpecInVO);
			
		} else if ("IMPDEV".equals(param.getTaskType())) {				
			
			dissImpDevVO2 = (DissImpDevVO) StringUtil.nullToEmptyString(getDissImpDevTaskBasicInfoDetail(param));		
			dissImpDevVO2.setTaskType(param.getTaskType());			
			map.put("dissSpecInVO"  , dissImpDevVO2);
		} else {
			throw new ServiceException("", "과제구분 정보가 잘못되었습니다.");
		}
		
		template = REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_EVAL;  // spec-in, 제품개선 공통 템플릿.
		
		// 개선개발제안서	getTaskType = "SPECIN"	임. 제품개발은 확인 필요함.
		DissImpDevVO dissImpDevVO = (DissImpDevVO) StringUtil.nullToEmptyString(getDissImpDevApprTypeDetail(param));
		dissImpDevVO.setTaskType(param.getTaskType());	
		
		//일정조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getTaskId());		
		
		List<DissScheduleVO> getDissScheduleList = dissScheduleDao.getDissScheduleList(paramSchedule);		

		List<DissScheduleVO> dissScheduleList = new ArrayList<DissScheduleVO>();
		for(DissScheduleVO schedule : getDissScheduleList) {
			dissScheduleList.add((DissScheduleVO)StringUtil.nullToEmptyString(schedule));
		}
		
		map.put("dissImpDevVO"		 , dissImpDevVO);
		map.put("dissStepVO"  		 , dissImpDevVO.getDissStepVO());
		map.put("dissScheduleList"	 , dissScheduleList);
		map.put("templeteFormContent", templeteFormContent);
		
		//kpi
		List<DissKpiVO> dissKpiList = new ArrayList<DissKpiVO>();
		for(DissKpiVO impDev : dissImpDevVO.getDissKpiList()) {			
			dissKpiList.add((DissKpiVO)StringUtil.nullToEmptyString(impDev));
		}
		map.put("dissKpiList", dissKpiList);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);
		
		map.put("fileVoList", fileVoList);
				
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate( template + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}

	@Transactional
	@Override
	public void saveDissImpDevApprovalAction(DissStepVO param) {

		//결재미완료건 조회
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(param.getApprId());
		int applIncompleteCount = commonApprDao.getApplIncompleteCount(apprVO);
		//최종결재 완료예정 결재시 후처리 시작
		String apprType = param.getApprType();
		String applStat = param.getApplStat();
		if (applIncompleteCount == 1 && applStat.equals(ApplState.APPL_APPROVE.getCode())) {
			//개선개발 제안서
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PROPOSAL.getCode())) {
				//DISS 개선개발 제안서 HIS 조회
				DissImpDevVO paramDissImpDev = new DissImpDevVO();
				paramDissImpDev.setStepId(param.getStepId());
				DissImpDevVO dissImpDevVO = dissImpDevDao.getDissImpDevHis(paramDissImpDev);
				dissImpDevVO.setTaskId(param.getTaskId());
				dissImpDevVO.setRegiIdxx(param.getRegiIdxx());
				if (dissImpDevVO.getTaskType().equals("IMPDEV")) {
					//DISS 개선개발과제 제안서 수정
					dissImpDevDao.updateDissImpDevProposalAppr(dissImpDevVO);
				} else if (dissImpDevVO.getTaskType().equals("SPECIN")) {
					//DISS 개선개발과제 제안서 등록
					dissImpDevDao.createDissImpDev(dissImpDevVO);
				}
				//DISS KPI관리 HIS 삭제
				DissKpiVO paramKpi = new DissKpiVO();
				paramKpi.setTaskId(param.getTaskId());
				dissKpiDao.deleteDissKpiAll(paramKpi);
				//DISS KPI HIS 조회
				paramKpi.setStepId(param.getStepId());
				List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisList(paramKpi);
				//DISS KPI관리 등록
				if (!dissKpiList.isEmpty()) {
					for (DissKpiVO vo : dissKpiList) {
						vo.setTaskId(param.getTaskId());
						vo.setRegiIdxx(param.getRegiIdxx());
						dissKpiDao.createDissKpi(vo);
					}
				}
				//DISS 일정 완료일 수정
				String compYmd = DateUtil.getToday();
				DissScheduleVO paramSchedule = new DissScheduleVO();
				paramSchedule.setTaskId(param.getTaskId());
				paramSchedule.setRegiIdxx(param.getRegiIdxx());
				paramSchedule.setCompYmd(compYmd);
				paramSchedule.setStepGroup("200");
				dissScheduleDao.updateDissScheduleCompYmd(paramSchedule);
				//DISS 일정 HIS 완료일 수정
				paramSchedule.setStepId(param.getStepId());
				dissScheduleDao.updateDissScheduleHisCompYmd(paramSchedule);
			}
			//개발등급 변경
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_LEVEL_CHG.getCode())) {
				//DISS 개선개발 제안서 HIS 조회
				DissImpDevVO paramDissImpDev = new DissImpDevVO();
				paramDissImpDev.setStepId(param.getStepId());
				DissImpDevVO dissImpDevVO = dissImpDevDao.getDissImpDevHis(paramDissImpDev);
				//DISS 개선개발과제 제안서 수정
				dissImpDevVO.setTaskId(param.getTaskId());
				dissImpDevVO.setRegiIdxx(param.getRegiIdxx());
				dissImpDevDao.updateDissImpDevProposalAppr(dissImpDevVO);
			}
			//F/Test 계획,F/Test 결과
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_PLAN.getCode())
					|| apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_RESULT.getCode())) {
				//DISS KPI관리 HIS 조회
				DissKpiVO paramKpi = new DissKpiVO();
				paramKpi.setStepId(param.getStepId());
				List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisList(paramKpi);
				//DISS KPI관리 수정
				if (!dissKpiList.isEmpty()) {
					for (DissKpiVO vo : dissKpiList) {
						vo.setRegiIdxx(param.getRegiIdxx());
						dissKpiDao.updateDissKpi(vo);
					}
				}
				if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_RESULT.getCode())) {
					//DISS 일정 완료일 수정
					String compYmd = DateUtil.getToday();
					DissScheduleVO paramSchedule = new DissScheduleVO();
					paramSchedule.setTaskId(param.getTaskId());
					paramSchedule.setRegiIdxx(param.getRegiIdxx());
					paramSchedule.setCompYmd(compYmd);
					paramSchedule.setStepGroup("300");
					dissScheduleDao.updateDissScheduleCompYmd(paramSchedule);
					//DISS 일정 HIS 완료일 수정
					paramSchedule.setStepId(param.getStepId());
					dissScheduleDao.createDissScheduleHisBySelect(paramSchedule);
				}
			}
			// 소재개발결과등록, TS견본검증결과보고
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_SAMPLEEVAL.getCode())
			 || apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode())) {
				//DISS 일정 완료일 수정
				String compYmd = DateUtil.getToday();
				DissScheduleVO paramSchedule = new DissScheduleVO();
				paramSchedule.setTaskId(param.getTaskId());
				paramSchedule.setRegiIdxx(param.getRegiIdxx());
				paramSchedule.setCompYmd(compYmd);
				paramSchedule.setStepGroup("300");
				dissScheduleDao.updateDissScheduleCompYmd(paramSchedule);
				//DISS 일정 HIS 완료일 수정
				paramSchedule.setStepId(param.getStepId());
				dissScheduleDao.createDissScheduleHisBySelect(paramSchedule);
			}
		}
		//DISS 공통 품의서 결재액션(결재자,협의자 승인,협의,반려 처리)
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(param.getApprId());
		apprLineVO.setApprLineComment(param.getApprLineComment());
		apprLineVO.setApprEmpId(param.getUpdtIdxx());
		apprLineVO.setApplStat(param.getApplStat());
		apprLineVO.setApprLineType(param.getApprLineType());
		apprLineVO.setUpdtIdxx(param.getUpdtIdxx());

		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);
	}

	@Override
	public DissImpDevVO getDissImpDevApprTypeDetail(DissStepVO param) {
		String taskType = param.getTaskType();
		String stepId = param.getStepId();
		String apprType = param.getApprType();
		DissImpDevVO returnItem = new DissImpDevVO();
		DissImpDevVO paramImpDev = new DissImpDevVO();
		paramImpDev.setStepId(stepId);
		paramImpDev.setTaskId(param.getTaskId());
		int maxStepDgreeNo = 1;
		DissStepVO paramStep = new DissStepVO();
		//스텝ID가 없으면 등록 초기 정보 조회
		if (stepId == "") {
			//제품개선개발 과제 마스터 조회(과제유형 : SPECIN, 소재개발결과등록) 
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode())) {
				if (taskType.equals("SPECIN")) {
					//개선개발 과제조회
					returnItem = dissImpDevDao.getDissImpDevDetail(paramImpDev);
				}
			}
			//Comp'd처방 KPI조회 안함
			if (!apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_COMPOUND.getCode())) {
				//TS견본검증결과보고 KPI HIS 조회
				if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_SAMPLEEVAL.getCode())) {
					//스텝 최대 차수 조회
					paramStep.setTaskId(param.getTaskId());
					maxStepDgreeNo = dissStepDao.getDissStepMaxDegreeNo(paramStep);
					//KPI HIS 조회
					DissKpiVO paramKpi = new DissKpiVO();
					paramKpi.setTaskId(param.getTaskId());
					paramKpi.setDegreeNo(maxStepDgreeNo);
					List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisSampleEvalRegList(paramKpi);
					returnItem.setDissKpiList(dissKpiList);
				} else {
					//KPI조회
					DissKpiVO paramKpi = new DissKpiVO();
					paramKpi.setTaskId(param.getTaskId());
					List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiList(paramKpi);
					returnItem.setDissKpiList(dissKpiList);
				}
			}
			//F/T결과 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_RESULT.getCode())) {
				//스텝 최대 차수 조회
				paramStep.setTaskId(param.getTaskId());
				maxStepDgreeNo = dissStepDao.getDissStepMaxDegreeNo(paramStep);
				DissFieldTestVO paramFieldTest = new DissFieldTestVO();
				paramFieldTest.setTaskId(param.getTaskId());
				paramFieldTest.setDegreeNo(maxStepDgreeNo);
				DissFieldTestVO dissFieldTest = dissFieldTestDao.getDissFieldTestDetail(paramFieldTest);
				returnItem.setFieldTestVO(dissFieldTest);
			}
			//Comp'd처방,소재개발 결과등록 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_COMPOUND.getCode())
					|| apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode())) {
				if (taskType.equals("IMPDEV")) {
					//멤버 조회
					DissMemberVO paramMember = new DissMemberVO();
					paramMember.setTaskId(param.getTaskId());
					List<DissMemberVO> dissMemberList = dissMemberDao.getDissMemberList(paramMember);
					returnItem.setDissMemberList(dissMemberList);
				}
				//일정 담당자 조회
				DissScheduleVO paramSchedule = new DissScheduleVO();
				paramSchedule.setTaskId(param.getTaskId());
				paramSchedule.setStepGroup("300");
				DissScheduleVO dissScheduleVO = dissScheduleDao.getDissScheduleDetail(paramSchedule);
				returnItem.setDissScheduleVO(dissScheduleVO);
			}
		} else {
			//제품개선개발 제안서 HIS 조회(과제유형 : SPECIN) 
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PROPOSAL.getCode())
					&& taskType.equals("SPECIN")) {
				returnItem = dissImpDevDao.getDissImpDevHisDetail(paramImpDev);
			}
			//KPI조회(Comp'd처방 KPI조회 안함)
			if (!apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_COMPOUND.getCode())) {
				//KPI HIS 조회
				DissKpiVO paramKpi = new DissKpiVO();
				paramKpi.setStepId(param.getStepId());
				paramKpi.setTaskId(param.getTaskId());
				//F/Test계획, F/Test결과 KPI HIS 조회
				if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_PLAN.getCode())
						|| apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_RESULT.getCode())) {
					List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisList(paramKpi);
					returnItem.setDissKpiList(dissKpiList);
					//개발등급 변경 KPI 조회
				} else if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_LEVEL_CHG.getCode())) {
					List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiList(paramKpi);
					returnItem.setDissKpiList(dissKpiList);
					//소재개발결과등록 KPI HIS 조회
				} else if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode())) {
					paramKpi.setTaskId("");
					List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisList(paramKpi);
					returnItem.setDissKpiList(dissKpiList);
					//TS견본검증결과보고 KPI HIS 조회
				} else if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_SAMPLEEVAL.getCode())) {
					paramKpi.setTaskId("");
					List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisList(paramKpi);
					returnItem.setDissKpiList(dissKpiList);
					//개선개발 제안서 KPI HIS 조회
				} else if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PROPOSAL.getCode())) {
					paramKpi.setTaskId("");
					List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisList(paramKpi);
					returnItem.setDissKpiList(dissKpiList);
				}
			}
			//F/t계획,F/Test결과 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_PLAN.getCode())
					|| apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_FT_RESULT.getCode())) {
				DissFieldTestVO paramFieldTest = new DissFieldTestVO();
				paramFieldTest.setStepId(stepId);
				DissFieldTestVO dissFieldTest = dissFieldTestDao.getDissFieldTestDetail(paramFieldTest);
				returnItem.setFieldTestVO(dissFieldTest);
			}
			//Comp'd처방 개발완료 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_COMPOUND.getCode())
					|| apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode())) {
				DissTaskResultVO paramTaskResult = new DissTaskResultVO();
				paramTaskResult.setStepId(stepId);
				DissTaskResultVO dissTaskResult = dissTaskResultDao.getDissTaskResultDetail(paramTaskResult);
				/*
				//요청플랜트명
				if (!StringUtil.isNullToString(dissTaskResult.getReqPlant()).equals("")) {
					dissTaskResult.setReqPlantNm(sapSearchService.getMasterCodeName("04", dissTaskResult.getReqPlant()));
				}
				*/
				returnItem.setDissTaskResultVO(dissTaskResult);
				//개발결과 담당영업사원 리스트
				returnItem.setDissTaskResultList(dissTaskResultDao.getDissTaskResultSaleEmpList(paramTaskResult));

			}
			//소재개발 결과등록 처방 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PRESCRIPTION.getCode())) {
				DissRecipeVO paramRecipe = new DissRecipeVO();
				paramRecipe.setStepId(stepId);
				List<DissRecipeVO> dissRecipeList = dissRecipeDao.getDissRecipeList(paramRecipe);
				returnItem.setDissRecipeList(dissRecipeList);
			}
			//TS견본검증결과보고 TS견본검증결과 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_SAMPLEEVAL.getCode())) {
				paramStep.setStepId(stepId);
				DissStepVO dissStepVO = dissStepDao.getDissStepRsltInfo(paramStep);
				returnItem.setDissStepVO(dissStepVO);
			}
			//반려재신청품의유무
			String reWriteRejectApprYn = dissStepDao.getDissStepReWriteRejectApprYn(param);
			returnItem.setReWriteRejectApprYn(reWriteRejectApprYn);
		}

		return returnItem;
	}

	@Override
	public DissImpDevVO getDissImpDevScheduleCommon(DissImpDevVO param) {
		DissImpDevVO returnItem = new DissImpDevVO();
		//일정조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getTaskId());
		List<DissScheduleVO> dissScheduleList = dissScheduleDao.getDissScheduleList(paramSchedule);
		returnItem.setDissScheduleList(dissScheduleList);
		//과제STEP 조회
		DissStepVO paramStep = new DissStepVO();
		paramStep.setTaskId(param.getTaskId());
		paramStep.setUpdtIdxx(param.getUpdtIdxx());
		List<DissStepVO> dissStepList = dissStepDao.getDissStepRegiList(paramStep);
		returnItem.setDissStepList(dissStepList);
		//스텝 최대 차수 조회
		int maxStepDgreeNo = 1;
		maxStepDgreeNo = dissStepDao.getDissStepMaxDegreeNo(paramStep);
		returnItem.setMaxStepDgreeNo(maxStepDgreeNo);

		return returnItem;
	}

	@Transactional
	@Override
	public void createDissImpDevDegree(DissStepVO param) {
		String stepId = Util.getUUID();
		String stepCd = "300900";

		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(stepId);
		dissStepVO.setTaskId(param.getTaskId());
		dissStepVO.setTaskType(param.getTaskType()); // DISS_TASK_TYPE
		dissStepVO.setStepCd(stepCd); //차수생성 DISS_STEP_CD
		dissStepVO.setDegreeNo(param.getDegreeNo() + 1);
		dissStepVO.setDegreeReason(param.getDegreeReason());
		dissStepVO.setStepLastYn("Y");
		dissStepVO.setRegiIdxx(param.getRegiIdxx());
		//스텝최종여부 N으로 변경
		dissStepDao.updateDissStepLastYn(dissStepVO);
		//DISS 차수 단계 등록
		dissStepDao.createDissStep(dissStepVO);
		//DISS 과제일정관리 수정
		DissScheduleVO dissScheduleVO = param.getDissScheduleVO();
		dissScheduleVO.setTaskId(param.getTaskId());
		dissScheduleVO.setStepGroup("300");
		dissScheduleVO.setCompYmd("");
		dissScheduleVO.setRegiIdxx(param.getRegiIdxx());
		dissScheduleDao.updateDissScheduleCompGoalYmd(dissScheduleVO);
		//DISS 과제일정관리 HIS 등록
		dissScheduleVO.setTaskType(param.getTaskType());
		dissScheduleVO.setRegiIdxx(param.getRegiIdxx());
		dissScheduleVO.setStepId(stepId);
		dissScheduleDao.createDissScheduleHis(dissScheduleVO);
	}

	@Override
	public DissImpDevVO getDissImpDevStepRsltDetail(DissStepVO param) {

		DissImpDevVO returnItem = new DissImpDevVO();

		//차수현황 일정 조회
		DissScheduleVO paramSchedule = new DissScheduleVO();
		paramSchedule.setTaskId(param.getTaskId());
		paramSchedule.setDegreeNo(param.getDegreeNo());
		List<DissScheduleVO> dissScheduleList = dissScheduleDao.getDissScheduleStepRsltList(paramSchedule);
		returnItem.setDissScheduleList(dissScheduleList);
		//차수현황 과제STEP 조회
		DissStepVO paramStep = new DissStepVO();
		paramStep.setTaskId(param.getTaskId());
		paramStep.setDegreeNo(param.getDegreeNo());
		paramStep.setUpdtIdxx(param.getUpdtIdxx());
		List<DissStepVO> dissStepList = dissStepDao.getDissStepRsltList(paramStep);
		returnItem.setDissStepList(dissStepList);
		//다음차수 생성사유
		String nextDegreeReason = dissStepDao.getDissStepNextDegreeReason(paramStep);
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setDegreeReason(nextDegreeReason);
		returnItem.setDissStepVO(dissStepVO);
		//차수현황 KPI HIS 조회
		DissKpiVO paramKpi = new DissKpiVO();
		paramKpi.setTaskId(param.getTaskId());
		paramKpi.setDegreeNo(param.getDegreeNo());
		List<DissKpiVO> dissKpiList = dissKpiDao.getDissKpiHisStepRsltList(paramKpi);
		returnItem.setDissKpiList(dissKpiList);

		return returnItem;
	}

	@Override
	public DissImpDevVO getDissImpDevTaskBasicInfoDetail(DissStepVO param) {
		String stepId = param.getStepId();
		String apprType = param.getApprType();
		DissImpDevVO returnItem;
		DissImpDevVO paramImpDev = new DissImpDevVO();
		paramImpDev.setStepId(stepId);
		paramImpDev.setTaskId(param.getTaskId());
		if (stepId == "") {
			//제품개선개발 과제 마스터 조회
			returnItem = dissImpDevDao.getDissImpDevDetail(paramImpDev);
		} else {
			//제품개선개발 제안서, 개발등급 변경 과제 마스터 HIS 조회
			if (apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_PROPOSAL.getCode())
					|| apprType.equals(ApprType.APPR_TYPE_DISS_IMPDEV_LEVEL_CHG.getCode())) {
				returnItem = dissImpDevDao.getDissImpDevHisDetail(paramImpDev);
			} else {
				returnItem = dissImpDevDao.getDissImpDevDetail(paramImpDev);
			}
		}

		return returnItem;
	}

	@Override
	public List<DissImpDevVO> getDissImpDevListExcelDownload(DissImpDevVO param) {
		return dissImpDevDao.getDissImpDevListExcelDownload(param);
	}

	@Override
	public void updateLeader(DissImpDevVO param) {
		DissImpDevVO checkImpDevVO = dissImpDevDao.getDissImpDevDetail(param);
		if(!param.getUpdtIdxx().equals(checkImpDevVO.getLeaderEmpId())){
			throw new ServiceException("", "올바른 사용자 접근이 아닙니다.\n(제품개선개발 리더 변경은 과제 리더만 가능합니다.)");
		}

		if(!checkImpDevVO.getLeaderEmpId().equals(param.getLeaderEmpId())) {
			String stepId = Util.getUUID();
			checkImpDevVO.setTaskType("IMPDEV");
			checkImpDevVO.setStepId(stepId);
			checkImpDevVO.setLeaderEmpId(param.getLeaderEmpId());
			dissImpDevDao.createDissImpDevHis(checkImpDevVO);

			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setTaskId(param.getTaskId());
			dissStepVO.setTaskType("IMPDEV");
			dissStepVO.setStepId(stepId);
			dissStepVO.setStepCd("900000"); // 과제수정스텝으로
			dissStepVO.setUpdtIdxx(param.getUpdtIdxx());
			dissStepVO.setRegiIdxx(param.getRegiIdxx());
			dissStepDao.createDissStep(dissStepVO);

			dissImpDevDao.updateLeader(param);

			String mailTitle = "D.I.S.S. 과제의 기존 리더 요청으로 신규 리더로 변경이 완료되었습니다. [" + checkImpDevVO.getTaskName() + "]";
			Map<String,String> mailParamMap = new HashMap<>();
			mailParamMap.put("taskName", checkImpDevVO.getTaskName());
			mailParamMap.put("leaderChange", checkImpDevVO.getLeaderEmpNm() + " -> " + param.getLeaderEmpNm());

			Map<String, String> map = new HashMap<String, String>();
			map.put("sawnCode1", checkImpDevVO.getLeaderEmpId());
			map.put("sawnCode2", param.getLeaderEmpId());
			for(EmployVO employVO : dissImpDevDao.getEmployByLeaderChange(map)) {
				SendMailVO sendMailVO = new SendMailVO();
				sendMailVO.setTitle(mailTitle);
				sendMailVO.setMailType(MailType.DISS_CHANGE_LEADER_IMPDEV);
				sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
				sendMailVO.setReceiverEmail(employVO.getMailAddr());
				sendMailVO.setParams(mailParamMap);
				mailingService.sendMail(sendMailVO);
			}

			EmployVO employVO = new EmployVO();
			employVO.setTeamCode("H3002");	//전략기획팀(제품개발Part)
			employVO.setPageSize(10);
			for(EmployVO part : commonDao.getEmployList(employVO)) {
				SendMailVO sendMailVO = new SendMailVO();
				sendMailVO.setTitle(mailTitle);
				sendMailVO.setMailType(MailType.DISS_CHANGE_LEADER_IMPDEV);
				sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
				sendMailVO.setReceiverEmail(part.getMailAddr());
				sendMailVO.setParams(mailParamMap);
				mailingService.sendMail(sendMailVO);
			}
		}
	}

	@Override
	public List<DissScheduleVO> getDissScheduleHisList(String stepId) {
		DissScheduleVO dissScheduleVO = new DissScheduleVO();
		dissScheduleVO.setStepId(stepId);

		return dissScheduleDao.getDissScheduleHisList(dissScheduleVO);
	}
}
