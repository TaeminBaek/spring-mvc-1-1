package com.lgmma.salesPortal.app.model;

import java.util.List;

public class DissSampleOrderMasterVO extends SampleOrderMasterVO {
	// Diss sampleOrder added Column
	private String taskId;          // 과제ID
	private String taskType;        // 과제유형
	private Integer degreeNo;       // 차수
	private String dissCustCode;    // DISS 고객코드
	private String dissCustErpCode; // DISS 고객ERP코드
	private String custTestResult;  // 고객테스트결과
	private String custTestFCd;     // 고객테스트실패사유
	private String custTestFDtlCd;  // 고객테스트실패사유상세
	private List<DissSampleOrderItemVO> dissSampleOrderItemList; // diss용 자재리스트

	// 디폴트 조회용추가정보
	private String taskName;        // 과제명
	private String stepId;          // 스텝ID
	private String stepCd;          // 스텝코드
	private String dissCustName;    // 고객명
	private String custErpCode;     // 고객ERP코드(스펙인고객기본정보)
	private String custIndoCode;    // 고객인도처코드(스펙인고객기본정보)
	private ApprVO apprVO;          // 품의서정보
	private String saveMode;        // 저장유형(액션처리를 위해서)
	private String taskLastStepId;  // 과제마지막스텝id
	private String custTestResultName;  // 고객테스트결과명
	private String custTestFCdName;     // 고객테스트실패사유명
	private String custTestFDtlCdName;  // 고객테스트실패사유상세명

	private String scApprId;

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public Integer getDegreeNo() {
		return degreeNo;
	}

	public void setDegreeNo(Integer degreeNo) {
		this.degreeNo = degreeNo;
	}

	public String getDissCustCode() {
		return dissCustCode;
	}

	public void setDissCustCode(String dissCustCode) {
		this.dissCustCode = dissCustCode;
	}

	public String getDissCustErpCode() {
		return dissCustErpCode;
	}

	public void setDissCustErpCode(String dissCustErpCode) {
		this.dissCustErpCode = dissCustErpCode;
	}

	public List<DissSampleOrderItemVO> getDissSampleOrderItemList() {
		return dissSampleOrderItemList;
	}

	public void setDissSampleOrderItemList(List<DissSampleOrderItemVO> dissSampleOrderItemList) {
		this.dissSampleOrderItemList = dissSampleOrderItemList;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getStepCd() {
		return stepCd;
	}

	public void setStepCd(String stepCd) {
		this.stepCd = stepCd;
	}

	public String getDissCustName() {
		return dissCustName;
	}

	public void setDissCustName(String dissCustName) {
		this.dissCustName = dissCustName;
	}

	public String getCustErpCode() {
		return custErpCode;
	}

	public void setCustErpCode(String custErpCode) {
		this.custErpCode = custErpCode;
	}

	public String getCustIndoCode() {
		return custIndoCode;
	}

	public void setCustIndoCode(String custIndoCode) {
		this.custIndoCode = custIndoCode;
	}

	public ApprVO getApprVO() {
		return apprVO;
	}

	public void setApprVO(ApprVO apprVO) {
		this.apprVO = apprVO;
	}

	public String getSaveMode() {
		return saveMode;
	}

	public void setSaveMode(String saveMode) {
		this.saveMode = saveMode;
	}

	public String getTaskLastStepId() {
		return taskLastStepId;
	}

	public void setTaskLastStepId(String taskLastStepId) {
		this.taskLastStepId = taskLastStepId;
	}

	public String getCustTestResult() {
		return custTestResult;
	}

	public void setCustTestResult(String custTestResult) {
		this.custTestResult = custTestResult;
	}

	public String getCustTestFCd() {
		return custTestFCd;
	}

	public void setCustTestFCd(String custTestFCd) {
		this.custTestFCd = custTestFCd;
	}

	public String getCustTestFDtlCd() {
		return custTestFDtlCd;
	}

	public void setCustTestFDtlCd(String custTestFDtlCd) {
		this.custTestFDtlCd = custTestFDtlCd;
	}

	public String getCustTestResultName() {
		return custTestResultName;
	}

	public void setCustTestResultName(String custTestResultName) {
		this.custTestResultName = custTestResultName;
	}

	public String getCustTestFCdName() {
		return custTestFCdName;
	}

	public void setCustTestFCdName(String custTestFCdName) {
		this.custTestFCdName = custTestFCdName;
	}

	public String getCustTestFDtlCdName() {
		return custTestFDtlCdName;
	}

	public void setCustTestFDtlCdName(String custTestFDtlCdName) {
		this.custTestFDtlCdName = custTestFDtlCdName;
	}

	public String getScApprId() {
		return scApprId;
	}

	public void setScApprId(String scApprId) {
		this.scApprId = scApprId;
	}

}
