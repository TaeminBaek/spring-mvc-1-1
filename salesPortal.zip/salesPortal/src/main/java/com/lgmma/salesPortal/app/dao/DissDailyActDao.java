package com.lgmma.salesPortal.app.dao;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.DissDailyVO;
import com.lgmma.salesPortal.app.model.EmployVO;

public interface DissDailyActDao {
	
	void createDissDailyAct(DissDailyVO param);
	
	int getDissDailyActListCount(DissDailyVO param);
	
	List<DissDailyVO> getDissDailyActList(DissDailyVO param);
	
	DissDailyVO getDissDailyActDetail(DissDailyVO param);

	DissDailyVO getDissDailyActDetailLast(DissDailyVO param);

	void updateDissDailyAct(DissDailyVO param);
	
	void deleteDissDailyAct(DissDailyVO param);
	
	List<DissDailyVO> getDissDailyActStatList(DissDailyVO param);

	List<DissDailyVO> getDissDailyActListExcelDownload(DissDailyVO param);

	List<DissDailyVO> getDissDailyActStatInfoExcelDownload(DissDailyVO param);

	List<DissDailyVO> getDissDailyActStatInfoExcelDownload2(DissDailyVO param);
	
	List<EmployVO> loadEmployList(Map<String, String> param);
}
