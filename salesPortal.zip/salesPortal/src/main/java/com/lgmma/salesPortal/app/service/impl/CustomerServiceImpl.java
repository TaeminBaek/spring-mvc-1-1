package com.lgmma.salesPortal.app.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.dao.CustomerDao;
import com.lgmma.salesPortal.app.model.CompFileListVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.CustReqVO;
import com.lgmma.salesPortal.app.service.CustomerService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.props.Vkorg;

@Transactional
@Service
public class CustomerServiceImpl implements CustomerService {
	private final String FNC_SAP_CUSTOMER2 = "ZSDE03_SALES_LIST_CUSTOMER2";
	
	@Autowired
	private CustomerDao customerDao;

	@Autowired
	private CompanyDao companyDao;

	@Autowired
	private JcoConnector jcoConnector;

	@Autowired
	private SapSearchService sapSearchService;

	@Override
	public List<String> getKunnr(String param) {
		return companyDao.getKunnr(param);
	}

	@Override
	public List<CompFileListVO> getCompFileList(CompFileListVO param){
		String fromMonth = param.getFromMonth().replace(".", "").trim();
		String toMonth = param.getToMonth().replace(".", "").trim();
		param.setFromMonth(fromMonth);
		param.setToMonth(toMonth);
		
		JcoTableParam tableParam = new JcoTableParam();
		
		//고객코드
		if (!(param.getPknam() == null || param.getPknam().equals(""))) {
			List<String> kunnrList = getKunnr(param.getPknam());
			List<Map> kunnrListMap = new ArrayList<Map>();

			for (int i = 0; i < kunnrList.size(); i++) {
				Map kunnrMap = new HashMap<String, Object>();
				kunnrMap.put("SIGN", "I");
				kunnrMap.put("OPTION", "EQ");
				kunnrMap.put("LOW", kunnrList.get(i));
				kunnrMap.put("HIGH", null);
				kunnrListMap.add(kunnrMap);
			}

			tableParam.put("CUSTOMERRANGE", kunnrListMap);
		}
		
		//영업조직
		if (!(param.getVkorg() == null || param.getVkorg().equals(""))) {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("SIGN", "I");
			paramMap.put("OPTION", "EQ");
			paramMap.put("LOW", param.getVkorg());
			paramMap.put("HIGH", null);
			tableParam.put("SALESORGRANGE", paramMap);
		} else {
			for (Vkorg org : Vkorg.values()) {
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("SIGN", "I");
				paramMap.put("OPTION", "EQ");
				paramMap.put("LOW", org.getCode());
				paramMap.put("HIGH", null);
				tableParam.put("SALESORGRANGE", paramMap);
			}
		}
		
		//유통경로
		if (!(param.getVtweg() == null || param.getVtweg().equals(""))) {
			String[] channelArray = param.getVtweg().split(",");
			for (int i = 0; i < channelArray.length; i++) {
				Map<String, Object> vtwegMap = new HashMap<String, Object>();
				vtwegMap.put("SIGN", "I");
				vtwegMap.put("OPTION", "EQ");
				vtwegMap.put("LOW", channelArray[i]);
				vtwegMap.put("HIGH", null);
				tableParam.put("VTWEG", vtwegMap);
			}
		}
		
		//업종
		if (!(param.getKvgr5() == null || param.getKvgr5().equals(""))) {
			Map<String, Object> Kvgr5Map = new HashMap<String, Object>();
			Kvgr5Map.put("SIGN", "I");
			Kvgr5Map.put("OPTION", "EQ");
			Kvgr5Map.put("LOW", param.getKvgr5());
			Kvgr5Map.put("HIGH", null);
			tableParam.put("KVGR5", Kvgr5Map);
		}
		
		//기간
		if (!(param.getFromMonth() == null || param.getFromMonth().equals(""))) {
			Map<String, Object> spmonMap = new HashMap<String, Object>();
			spmonMap.put("SIGN", "I");
			spmonMap.put("OPTION", "BT");
			spmonMap.put("LOW", param.getFromMonth() );
			spmonMap.put("HIGH", param.getToMonth() );
			tableParam.put("SPMON", spmonMap);
		}

		jcoConnector.executeFunction(FNC_SAP_CUSTOMER2, tableParam);
		
		List<CompFileListVO> rows = (List<CompFileListVO>) tableParam.get("T_LIST", CompFileListVO.class);
		rows.remove(rows.size()-1);
		
		sortCompFile(param,rows);
		
		for(int i=0; i<rows.size(); i++) {
			rows.get(i).setrIndex(i);
			String iClass = sapSearchService.getMasterCodeName("14", rows.get(i).getKvgr3());
			rows.get(i).setiClass(iClass);
		}
		
		return rows;
	}
	//매출관련 헤더별 정렬
	public void sortCompFile(CompFileListVO param, List<CompFileListVO> list) {
		if(param.getOrderBy().equals("M"))
			Collections.sort(list, CompFileListVO.sortMDESC);
		else if(param.getOrderBy().equals("W"))
			Collections.sort(list, CompFileListVO.sortWDESC);
		else if(param.getOrderBy().equals("F"))
			Collections.sort(list, CompFileListVO.sortFDESC);
		
	}

	@Override
	public void createCustomer(CompanyVO param) {
		if(!param.getTelf1().equals("") && !param.getTelf2().equals("")) {
			param.setTelf1(param.getTelf1() + "-");
		}
		if(!param.getTelf2().equals("") && !param.getTelf3().equals("")) {
			param.setTelf2(param.getTelf2() + "-");
		}
		param.setTelf1Full(param.getTelf1() + param.getTelf2() + param.getTelf3());

		if(!param.getFax1().equals("") && !param.getFax2().equals("")) {
			param.setFax1(param.getFax1() + "-");
		}
		if(!param.getFax2().equals("") && !param.getFax3().equals("")) {
			param.setFax2(param.getFax2() + "-");
		}
		param.setTelfx(param.getFax1() + param.getFax2() + param.getFax3());
		customerDao.createCustomer(param);
		param.getOrganVO().setCompCode(param.getCompCode());
		customerDao.createOrgan(param.getOrganVO());
	}

	@Override
	public int getCustomerRequestsCount(CustReqVO param) {
		return customerDao.getCustomerRequestsCount(param);
	}

	@Override
	public List<CustReqVO> getCustomerRequestsList(CustReqVO param) {
		return customerDao.getCustomerRequestsList(param);
	}

	@Override
	public CustReqVO getCustomerRequestDetail(CustReqVO param) {
		return customerDao.getCustomerRequestDetail(param);
	}
}
