package com.lgmma.salesPortal.common.props;

public enum Vtweg {
/**
 * 유통경로로서
*/
	 VTWEG_DOMESTIC("10","내수")
	,VTWEG_DOMESTIC_FOREIGN_CURRENCY("11","내수(외화용)")
	,VTWEG_DOMESTIC_LOCAL("20","로칼")
	,VTWEG_EXPORT("30","직수출")
	,VTWEG_EXPORT_LOCAL("40","로컬수출")
	,VTWEG_ETC("90","기타")
	;
	String code = null;
	String name = null;

	private Vtweg(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static Vtweg getVtweg(String code) {
		for(Vtweg type : Vtweg.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
		
}
