package com.lgmma.salesPortal.app.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.dao.DirectOrderDao;
import com.lgmma.salesPortal.app.dao.HighValueGoalDao;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.HighValueGoalVO;
import com.lgmma.salesPortal.app.service.HighValueMgmtService;



@Transactional
@Service
public class HighValueMgmtServiceImpl implements HighValueMgmtService {
	
	
	@Autowired
	private DirectOrderDao directOrderDao;
	
	@Autowired
	private HighValueGoalDao highValueGoalDao;
		
	@Override
	public void updateHighValue(List<DirectOrderItemVO> paramList) {
		for(DirectOrderItemVO param : paramList) {
			directOrderDao.updateHighValue(param);
		}
	}

	@Override
	public int getHighValueGoalCount(HighValueGoalVO param) {
		return highValueGoalDao.getHighValueGoalCount(param);
	}

	@Override
	public List<HighValueGoalVO> getHighValueGoalList(HighValueGoalVO param) {
		return highValueGoalDao.getHighValueGoalList(param);
	}

	@Override
	public List<CommonCodeVO> getHighValueCodeList(HighValueGoalVO param) {
		return highValueGoalDao.getHighValueCodeList(param);
	}
	
	@Override
	public void createHighValueGoal(List<HighValueGoalVO> paramList) {
		for(HighValueGoalVO param : paramList) {
			highValueGoalDao.createHighValueGoal(param);
		}
	}

	@Override
	public void updateHighValueGoal(List<HighValueGoalVO> paramList) {
		for(HighValueGoalVO param : paramList) {
			highValueGoalDao.updateHighValueGoal(param);
		}
	}

	@Override
	public void deleteHighValueGoal(HighValueGoalVO param) {
		highValueGoalDao.deleteHighValueGoal(param);
	}

	@Override
	public List<CommonCodeVO> getYearHighValueCodeList(HighValueGoalVO param) {
		return highValueGoalDao.getYearHighValueCodeList(param);
	}

	@Override
	public List<HighValueGoalVO> getHighValueCGResultList(HighValueGoalVO param) {
		return highValueGoalDao.getHighValueCGResultList(param);
	}

}
