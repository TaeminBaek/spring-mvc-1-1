package com.lgmma.salesPortal.config;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import net.sf.ehcache.CacheManager;

/**
 * @author nahong01
 *         캐시 설정 Config 
 */

@Configuration
@EnableCaching
public class EhcacheConfig {

	// 기본캐시설정값
	final static String		CACHE_EVICTION_POLICY		= "LRU";
	final static boolean	CACHE_ETERNAL				= false;
	final static String		CACHE_TRANSACTIONAL_MODE	= "OFF";
	final static String		CACHE_MAX_BYTES_LOCAL_HEAP	= "10m";
	@Bean(destroyMethod="shutdown")
	public net.sf.ehcache.CacheManager ehCaheManager () {
		net.sf.ehcache.config.Configuration config = new net.sf.ehcache.config.Configuration();
		// 각각 관리 되어야 하는 캐시들을 이름과 유지시간을 설정하여 여러개 등록해서 사용
		config.addCache(cacheConfig("sapRfcCommonCodeCache",3600)); // SAP공통코드캐시 1시간(3600초)동안 캐시유지
		config.addCache(cacheConfig("sapRfcHomeChartCache",32400)); // 홈화면 차트 캐시 6시간(32400초)동안 캐시유지
		config.addCache(cacheConfig("getCommonCodeDbAllCache",32400)); // 공통코드전체조회 캐시 6시간(32400초)동안 캐시유지
		return CacheManager.newInstance(config);
	}

	/* 멀티캐시 등록가능 하도록 */
	private net.sf.ehcache.config.CacheConfiguration cacheConfig(String name, int cacheTimeToLiveSeconds) {
		net.sf.ehcache.config.CacheConfiguration cacheConfiguration = new net.sf.ehcache.config.CacheConfiguration();
		cacheConfiguration.setName(name);
		cacheConfiguration.setTimeToLiveSeconds(cacheTimeToLiveSeconds);
		cacheConfiguration.setMemoryStoreEvictionPolicy(CACHE_EVICTION_POLICY);
		cacheConfiguration.setEternal(CACHE_ETERNAL);
		cacheConfiguration.setTransactionalMode(CACHE_TRANSACTIONAL_MODE);
		cacheConfiguration.setMaxBytesLocalHeap(CACHE_MAX_BYTES_LOCAL_HEAP);
		return cacheConfiguration;
	}

	@Bean
	public org.springframework.cache.CacheManager cacheManager() {
		return new EhCacheCacheManager(ehCaheManager());
	}
}
