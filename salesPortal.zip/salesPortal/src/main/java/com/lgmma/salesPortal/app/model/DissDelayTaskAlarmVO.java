package com.lgmma.salesPortal.app.model;

public class DissDelayTaskAlarmVO extends PagingParamVO {
	private String taskId;              // 과제id
	private String taskType;            // 과제유형
	private String taskName;            // 과제명
	private String compGoalYmd;         // 완료계획일
	private String stepGroupName;       // 일정명
	private String salesEmpMail;        // 스펙인영업담당자이메일
	private String tsEmpMail;           // 스펙인TS담당자이메일
	private String devEmpMail;       	// 스펙인개발개발리더이메일	
	private String leaderEmpMail;       // 제품개선개발리더이메일

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getCompGoalYmd() {
		return compGoalYmd;
	}

	public void setCompGoalYmd(String compGoalYmd) {
		this.compGoalYmd = compGoalYmd;
	}

	public String getStepGroupName() {
		return stepGroupName;
	}

	public void setStepGroupName(String stepGroupName) {
		this.stepGroupName = stepGroupName;
	}

	public String getSalesEmpMail() {
		return salesEmpMail;
	}

	public void setSalesEmpMail(String salesEmpMail) {
		this.salesEmpMail = salesEmpMail;
	}

	public String getTsEmpMail() {
		return tsEmpMail;
	}

	public void setTsEmpMail(String tsEmpMail) {
		this.tsEmpMail = tsEmpMail;
	}
	
	public String getDevEmpMail() {
		return devEmpMail;
	}
	
	public void setDevEmpMail(String devEmpMail) {
		this.devEmpMail = devEmpMail;
	}

	public String getLeaderEmpMail() {
		return leaderEmpMail;
	}

	public void setLeaderEmpMail(String leaderEmpMail) {
		this.leaderEmpMail = leaderEmpMail;
	}
}
