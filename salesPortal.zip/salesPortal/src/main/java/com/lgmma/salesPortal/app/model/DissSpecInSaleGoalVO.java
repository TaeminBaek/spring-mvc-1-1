package com.lgmma.salesPortal.app.model;

/**
 * @author nahong01
 * @description SpecIn매출목표
 */
public class DissSpecInSaleGoalVO extends PagingParamVO {
	private String taskId;
	private String stepId;
	private String salegoalId;
	private String yyyy;
	private Integer seq;
	private Integer goal01;
	private Integer goal02;
	private Integer goal03;
	private Integer goal04;
	private Integer goal05;
	private Integer goal06;
	private Integer goal07;
	private Integer goal08;
	private Integer goal09;
	private Integer goal10;
	private Integer goal11;
	private Integer goal12;
	private Integer goalTotal;

	/* VIEW COLUMN */
	private Integer addYear;

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getSalegoalId() {
		return salegoalId;
	}

	public void setSalegoalId(String salegoalId) {
		this.salegoalId = salegoalId;
	}

	public String getYyyy() {
		return yyyy;
	}

	public void setYyyy(String yyyy) {
		this.yyyy = yyyy;
	}

	public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	public Integer getGoal01() {
		return goal01;
	}

	public void setGoal01(Integer goal01) {
		this.goal01 = goal01;
	}

	public Integer getGoal02() {
		return goal02;
	}

	public void setGoal02(Integer goal02) {
		this.goal02 = goal02;
	}

	public Integer getGoal03() {
		return goal03;
	}

	public void setGoal03(Integer goal03) {
		this.goal03 = goal03;
	}

	public Integer getGoal04() {
		return goal04;
	}

	public void setGoal04(Integer goal04) {
		this.goal04 = goal04;
	}

	public Integer getGoal05() {
		return goal05;
	}

	public void setGoal05(Integer goal05) {
		this.goal05 = goal05;
	}

	public Integer getGoal06() {
		return goal06;
	}

	public void setGoal06(Integer goal06) {
		this.goal06 = goal06;
	}

	public Integer getGoal07() {
		return goal07;
	}

	public void setGoal07(Integer goal07) {
		this.goal07 = goal07;
	}

	public Integer getGoal08() {
		return goal08;
	}

	public void setGoal08(Integer goal08) {
		this.goal08 = goal08;
	}

	public Integer getGoal09() {
		return goal09;
	}

	public void setGoal09(Integer goal09) {
		this.goal09 = goal09;
	}

	public Integer getGoal10() {
		return goal10;
	}

	public void setGoal10(Integer goal10) {
		this.goal10 = goal10;
	}

	public Integer getGoal11() {
		return goal11;
	}

	public void setGoal11(Integer goal11) {
		this.goal11 = goal11;
	}

	public Integer getGoal12() {
		return goal12;
	}

	public void setGoal12(Integer goal12) {
		this.goal12 = goal12;
	}

	public Integer getGoalTotal() {
		return goalTotal;
	}

	public void setGoalTotal(Integer goalTotal) {
		this.goalTotal = goalTotal;
	}

	public Integer getAddYear() {
		return addYear;
	}

	public void setAddYear(Integer addYear) {
		this.addYear = addYear;
	}
}
