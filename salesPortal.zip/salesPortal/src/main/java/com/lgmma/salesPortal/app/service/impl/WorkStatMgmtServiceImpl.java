package com.lgmma.salesPortal.app.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.model.WorkStatVO;
import com.lgmma.salesPortal.app.service.SapSearchServiceCache;
import com.lgmma.salesPortal.app.service.WorkStatMgmtService;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.Util;

@Transactional
@Service
public class WorkStatMgmtServiceImpl implements WorkStatMgmtService {

	private static Logger logger = LoggerFactory.getLogger(WorkStatMgmtServiceImpl.class);
	private final String FNC_SAP_WORKSTATLIST = "ZSDE03_SELECT_MAIN_SCREEN";		//업무현황 리스트
	private final String FNC_SAP_WORKSTATVIEW = "ZSDE03_SELECT_DETAIL";				//업무현황 상세 - 매출, 회전일, 재고, 생산
	private final String FNC_SAP_MAIN_MONTLY_SALES = "ZSDE03_SELECT_MAIN_SCREEN2";	//메인화면 월별 매출
	private final String FNC_SAP_MAIN_MONTLY_PROFIT = "ZCO_TABLE_PA";				//메인화면 월별 영업이익
	
	@Autowired
	private JcoConnector jcoConnector;
	
	@Autowired
	private SapSearchServiceCache sapSearchServiceCache;
	
	/**
	 * 업무현황 리스트
	 */
	@Override
	public List<WorkStatVO> getworkStatList(WorkStatVO param) {
		List<WorkStatVO> returnList = new ArrayList<WorkStatVO>();
		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		tableParam.put("T_LIST", paramMap);
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_SPMON", param.getYyyyMm()); //기간-년월 
		inputParam.put("I_VKORG", param.getVkorg());  //영업조직
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_WORKSTATLIST, inputParam, outputParam, tableParam);
		
		List<WorkStatVO> rows = (List<WorkStatVO>) tableParam.get("T_LIST", WorkStatVO.class);
		
		for(WorkStatVO row : rows) {
			
			double value1=0; //전월실적
			double value2=0; //당월계획
			double value3=0; //당월실적
			
			if(row.getSort().equals("2")){
				// 단위:억 으로 변환 매출(백만원)
				value1 = Math.round(Double.parseDouble(row.getValue1())/1000000);
				value2 = Math.round(Double.parseDouble(row.getValue2())/1000000);
				value3 = Math.round(Double.parseDouble(row.getValue3())/1000000);
			}else if(row.getSort().equals("1") ||row.getSort().equals("4") || row.getSort().equals("5")){
				//단위 :톤으로 변환 매출(톤),재고(톤), 생산(톤)
				value1 = Math.round(Double.parseDouble(row.getValue1())/1000); 
				value2 = Math.round(Double.parseDouble(row.getValue2())/1000); 
				value3 = Math.round(Double.parseDouble(row.getValue3())/1000); 
			
			}else if(row.getSort().equals("3")) {
				//채권(회전일)로 수정 
				value1 = Double.parseDouble(row.getValue1());
				value2 = Double.parseDouble(row.getValue2());
				value3 = Double.parseDouble(row.getValue3());
			}
			
			WorkStatVO returnVo = new WorkStatVO();
			returnVo.setNote(row.getNote());
			returnVo.setValue1(String.valueOf(value1));
			returnVo.setValue2(String.valueOf(value2));
			returnVo.setValue3(String.valueOf(value3));
			returnVo.setValue4(String.valueOf(value2-value3));

			returnVo.setE_tot((String)outputParam.get("E_TOT"));
			returnVo.setE_cur((String)outputParam.get("E_CUR"));
			returnList.add(returnVo);
		}
		return returnList;
	}
	/**
	 * 업무현황 상세
	 */
	@Override
	public List<WorkStatVO> getworkStatView(WorkStatVO param) {
		List<WorkStatVO> returnList = new ArrayList<WorkStatVO>();
		JcoTableParam tableParam = new JcoTableParam();
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		tableParam.put("T_LIST", paramMap);
		
		Map<String, Object> inputParam = new HashMap<String, Object>();
		inputParam.put("I_SPMON", param.getYyyyMm().replace(".", ""));//기간-년월 
		inputParam.put("I_VKORG", param.getVkorg());				  //영업조직
		inputParam.put("I_GUBUN", param.getGubun());				  //구분자 'SA' : 매출, 'BO' : 채권, 'ST' : 재고, 'PD' : 생산
		
		Map<String, Object> outputParam = new HashMap<String, Object>();
		
		jcoConnector.executeFunction(FNC_SAP_WORKSTATVIEW, inputParam, outputParam, tableParam);
		
		List<WorkStatVO> rows = (List<WorkStatVO>) tableParam.get("T_LIST", WorkStatVO.class);
		
		if(rows.size()!=0) {
			
			if(param.getVkorg() == null || param.getVkorg().equals("1000")) {
				if(param.getGubun().equals("SA")) {
					returnList = getMMASalesStatTable(rows);									//MMA 매출
				} else if (param.getGubun().equals("BO")){
					returnList = getBondStatTable(rows);										//MMA 회전일
				} else if(param.getGubun().equals("ST") || param.getGubun().equals("PD")) {
					returnList = getMMAStockProductTable(rows);									//MMA 재고, 생산
				}
			} else if(param.getVkorg().equals("3000")){
				if(param.getGubun().equals("SA")) {
					returnList = getPMMASalesStatTable(rows);									//PMMA 매출
				} else if (param.getGubun().equals("BO")){
					returnList = getBondStatTable(rows);										//PMMA 회전일
				} else if(param.getGubun().equals("ST") || param.getGubun().equals("PD")) {
					returnList = getPMMAStockProductTable(rows);								//PMMA 재고, 생산
				}
			}
			
			
		} else {
			returnList = rows;
		}
		return returnList;
	}
	
	/**
	 * MMA 매출현황
	 * @param param
	 * @return
	 */
	public List<WorkStatVO> getMMASalesStatTable(List<WorkStatVO> param){
		
		List<WorkStatVO> returnList = new ArrayList<WorkStatVO>();
		
		double	qnty1=0,   qnty2=0,   qnty3=0,   qnty4=0, 
				amnt1=0,   amnt2=0,   amnt3=0,   amnt4=0,
				qnty1_o=0, qnty2_o=0, qnty3_o=0, qnty4_o=0, 
				amnt1_o=0, amnt2_o=0, amnt3_o=0, amnt4_o=0,
				pric1=0,   pric2=0,   pric3=0,   pric4=0,
				
		
		//토탈합계
		tot_qnty1=0,   tot_qnty2=0,   tot_qnty3=0,   tot_qnty4=0,
		tot_amnt1=0,   tot_amnt2=0,   tot_amnt3=0,   tot_amnt4=0,
		tot_qnty1_o=0, tot_qnty2_o=0, tot_qnty3_o=0, tot_qnty4_o=0,
		tot_amnt1_o=0, tot_amnt2_o=0, tot_amnt3_o=0, tot_amnt4_o=0,
		tot_pric1=0,   tot_pric2=0,   tot_pric3=0,   tot_pric4=0,
		
		//제품별합계
		mvgr1nm_tot_qnty1=0,   mvgr1nm_tot_qnty2=0,   mvgr1nm_tot_qnty3=0,   mvgr1nm_tot_qnty4=0,
		mvgr1nm_tot_amnt1=0,   mvgr1nm_tot_amnt2=0,   mvgr1nm_tot_amnt3=0,   mvgr1nm_tot_amnt4=0,
		mvgr1nm_tot_qnty1_o=0, mvgr1nm_tot_qnty2_o=0, mvgr1nm_tot_qnty3_o=0, mvgr1nm_tot_qnty4_o=0,
		mvgr1nm_tot_amnt1_o=0, mvgr1nm_tot_amnt2_o=0, mvgr1nm_tot_amnt3_o=0, mvgr1nm_tot_amnt4_o=0,
		mvgr1nm_tot_pric1=0,   mvgr1nm_tot_pric2=0,   mvgr1nm_tot_pric3=0,   mvgr1nm_tot_pric4=0,
		
		//유통별합계
		vtwegnm_tot_qnty1=0,   vtwegnm_tot_qnty2=0,   vtwegnm_tot_qnty3=0,   vtwegnm_tot_qnty4=0,
		vtwegnm_tot_amnt1=0,   vtwegnm_tot_amnt2=0,   vtwegnm_tot_amnt3=0,   vtwegnm_tot_amnt4=0,
		vtwegnm_tot_qnty1_o=0, vtwegnm_tot_qnty2_o=0, vtwegnm_tot_qnty3_o=0, vtwegnm_tot_qnty4_o=0,
		vtwegnm_tot_amnt1_o=0, vtwegnm_tot_amnt2_o=0, vtwegnm_tot_amnt3_o=0, vtwegnm_tot_amnt4_o=0,
		vtwegnm_tot_pric1=0,   vtwegnm_tot_pric2=0,   vtwegnm_tot_pric3=0,   vtwegnm_tot_pric4=0,
		
		//LG/NLG별합계
		kvgr1nm_tot_qnty1=0,   kvgr1nm_tot_qnty2=0,   kvgr1nm_tot_qnty3=0,   kvgr1nm_tot_qnty4=0,
		kvgr1nm_tot_amnt1=0,   kvgr1nm_tot_amnt2=0,   kvgr1nm_tot_amnt3=0,   kvgr1nm_tot_amnt4=0,
		kvgr1nm_tot_qnty1_o=0, kvgr1nm_tot_qnty2_o=0, kvgr1nm_tot_qnty3_o=0, kvgr1nm_tot_qnty4_o=0,
		kvgr1nm_tot_amnt1_o=0, kvgr1nm_tot_amnt2_o=0, kvgr1nm_tot_amnt3_o=0, kvgr1nm_tot_amnt4_o=0,
		kvgr1nm_tot_pric1=0,   kvgr1nm_tot_pric2=0,   kvgr1nm_tot_pric3=0,   kvgr1nm_tot_pric4=0,
		
		//구분별합계
		kvgr2nm_tot_qnty1=0,   kvgr2nm_tot_qnty2=0,   kvgr2nm_tot_qnty3=0,   kvgr2nm_tot_qnty4=0,
		kvgr2nm_tot_amnt1=0,   kvgr2nm_tot_amnt2=0,   kvgr2nm_tot_amnt3=0,   kvgr2nm_tot_amnt4=0,
		kvgr2nm_tot_qnty1_o=0, kvgr2nm_tot_qnty2_o=0, kvgr2nm_tot_qnty3_o=0, kvgr2nm_tot_qnty4_o=0,
		kvgr2nm_tot_amnt1_o=0, kvgr2nm_tot_amnt2_o=0, kvgr2nm_tot_amnt3_o=0, kvgr2nm_tot_amnt4_o=0,
		kvgr2nm_tot_pric1=0,   kvgr2nm_tot_pric2=0,   kvgr2nm_tot_pric3=0,   kvgr2nm_tot_pric4=0;
		
		int row_j=0, row_cnt1=0, 
			row_k=0, row_cnt2=0,
			row_m=0, row_cnt3=0,
			row_n=0, row_cnt4=0;
		
		for(int i=0;i<param.size();i++) {
			//수량
			qnty1_o = Double.parseDouble(param.get(i).getQnty1());
			qnty2_o = Double.parseDouble(param.get(i).getQnty2());
			qnty3_o = Double.parseDouble(param.get(i).getQnty3());
			qnty4_o = Double.parseDouble(param.get(i).getQnty4());
			
			//금액
			amnt1_o = Double.parseDouble(param.get(i).getAmnt1());
			amnt2_o = Double.parseDouble(param.get(i).getAmnt2());
			amnt3_o = Double.parseDouble(param.get(i).getAmnt3());
			amnt4_o = Double.parseDouble(param.get(i).getAmnt4());
			
			//수량 KG-->톤
			qnty1 = Math.round(qnty1_o/1000);
			qnty2 = Math.round(qnty2_o/1000);
			qnty3 = Math.round(qnty3_o/1000);
			qnty4 = Math.round(qnty4_o/1000);
			
			//금액 원-->백만원 				
			amnt1 = Math.round(amnt1_o/1000000);
			amnt2 = Math.round(amnt2_o/1000000);
			amnt3 = Math.round(amnt3_o/1000000);
			amnt4 = Math.round(amnt4_o/1000000);				
			
			//판가 : 금액/수량=원/KG
			if(!param.get(i).getQnty1().equals("0")) 
				pric1 = Math.round(amnt1_o/qnty1_o);	
			else 
				pric1 = 0;
			if(!param.get(i).getQnty2().equals("0")) 
				pric2 = Math.round(amnt2_o/qnty2_o);	
			else 
				pric2 = 0;
			if(!param.get(i).getQnty3().equals("0")) 
				pric3 = Math.round(amnt3_o/qnty3_o);	
			else 
				pric3 = 0;
			if(!param.get(i).getQnty4().equals("0")) 
				pric4 = Math.round(amnt4_o/qnty4_o);		
			else 
				pric4 = 0;
			
			// 토탈합계 
			tot_qnty1 += qnty1;		tot_qnty2 += qnty2;		tot_qnty3 += qnty3;		tot_qnty4 += qnty4;
			tot_amnt1 += amnt1;		tot_amnt2 += amnt2;		tot_amnt3 += amnt3;		tot_amnt4 += amnt4;	
			tot_qnty1_o += qnty1_o;	tot_qnty2_o += qnty2_o;	
			tot_qnty3_o += qnty3_o;	tot_qnty4_o += qnty4_o;
			tot_amnt1_o += amnt1_o;	tot_amnt2_o += amnt2_o;	
			tot_amnt3_o += amnt3_o;	tot_amnt4_o += amnt4_o;	
			
			// 제품별 합계
			mvgr1nm_tot_qnty1 += qnty1;		mvgr1nm_tot_qnty2 += qnty2;		mvgr1nm_tot_qnty3 += qnty3;		mvgr1nm_tot_qnty4 += qnty4;
			mvgr1nm_tot_amnt1 += amnt1;		mvgr1nm_tot_amnt2 += amnt2;		mvgr1nm_tot_amnt3 += amnt3;		mvgr1nm_tot_amnt4 += amnt4;	
			mvgr1nm_tot_qnty1_o +=qnty1_o;	mvgr1nm_tot_qnty2_o += qnty2_o;
			mvgr1nm_tot_qnty3_o += qnty3_o;	mvgr1nm_tot_qnty4_o += qnty4_o;
			mvgr1nm_tot_amnt1_o += amnt1_o;	mvgr1nm_tot_amnt2_o += amnt2_o;	
			mvgr1nm_tot_amnt3_o += amnt3_o;	mvgr1nm_tot_amnt4_o += amnt4_o;
			
			// 유통별 합계
			vtwegnm_tot_qnty1 += qnty1;		vtwegnm_tot_qnty2 += qnty2;		vtwegnm_tot_qnty3 += qnty3;		vtwegnm_tot_qnty4 += qnty4;
			vtwegnm_tot_amnt1 += amnt1;		vtwegnm_tot_amnt2 += amnt2;		vtwegnm_tot_amnt3 += amnt3;		vtwegnm_tot_amnt4 += amnt4;	
			vtwegnm_tot_qnty1_o += qnty1_o;	vtwegnm_tot_qnty2_o += qnty2_o;	
			vtwegnm_tot_qnty3_o += qnty3_o;	vtwegnm_tot_qnty4_o += qnty4_o;
			vtwegnm_tot_amnt1_o += amnt1_o;	vtwegnm_tot_amnt2_o += amnt2_o;	
			vtwegnm_tot_amnt3_o += amnt3_o;	vtwegnm_tot_amnt4_o += amnt4_o;	
			
			// LG/NLG별 합계
			kvgr1nm_tot_qnty1 += qnty1;		kvgr1nm_tot_qnty2 += qnty2;		kvgr1nm_tot_qnty3 += qnty3;		kvgr1nm_tot_qnty4 += qnty4;
			kvgr1nm_tot_amnt1 += amnt1;		kvgr1nm_tot_amnt2 += amnt2;		kvgr1nm_tot_amnt3 += amnt3;		kvgr1nm_tot_amnt4 += amnt4;	
			kvgr1nm_tot_qnty1_o += qnty1_o;	kvgr1nm_tot_qnty2_o += qnty2_o;	
			kvgr1nm_tot_qnty3_o += qnty3_o;	kvgr1nm_tot_qnty4_o += qnty4_o;
			kvgr1nm_tot_amnt1_o += amnt1_o;	kvgr1nm_tot_amnt2_o += amnt2_o;	
			kvgr1nm_tot_amnt3_o += amnt3_o;	kvgr1nm_tot_amnt4_o += amnt4_o;	
			
			//구분별 합계
			kvgr2nm_tot_qnty1 += qnty1;		kvgr2nm_tot_qnty2 += qnty2;		kvgr2nm_tot_qnty3 += qnty3;		kvgr2nm_tot_qnty4 += qnty4;
			kvgr2nm_tot_amnt1 += amnt1;		kvgr2nm_tot_amnt2 += amnt2;		kvgr2nm_tot_amnt3 += amnt3;		kvgr2nm_tot_amnt4 += amnt4;
			kvgr2nm_tot_qnty1_o += qnty1_o;	kvgr2nm_tot_qnty1_o += qnty2_o;	
			kvgr2nm_tot_qnty3_o += qnty3_o;	kvgr2nm_tot_qnty4_o += qnty4_o;
			kvgr2nm_tot_amnt1_o += amnt1_o;	kvgr2nm_tot_amnt1_o += amnt2_o;	
			kvgr2nm_tot_amnt3_o += amnt3_o;	kvgr2nm_tot_amnt4_o += amnt4_o;	
			
			String titl_gubn1 = param.get(i).getMvgr1nm(); // 제품
			String titl_gubn2 = param.get(i).getMvgr1nm()+param.get(i).getVtwegnm(); // 유통
			String titl_gubn3 = param.get(i).getMvgr1nm()+param.get(i).getVtwegnm()+param.get(i).getKvgr1nm(); // LG/NLG
			String titl_gubn4 = param.get(i).getMvgr1nm()+param.get(i).getVtwegnm()+param.get(i).getKvgr1nm()+param.get(i).getKvgr2nm(); // 구분
			
			WorkStatVO vo = new WorkStatVO();
			vo.setQnty1(String.valueOf(qnty1));
			vo.setQnty2(String.valueOf(qnty2));
			vo.setQnty3(String.valueOf(qnty3));
			vo.setQnty4(String.valueOf(qnty4));
			vo.setAmnt1(String.valueOf(amnt1));
			vo.setAmnt2(String.valueOf(amnt2));
			vo.setAmnt3(String.valueOf(amnt3));
			vo.setAmnt4(String.valueOf(amnt4));
			vo.setPric1(String.valueOf(pric1));
			vo.setPric2(String.valueOf(pric2));
			vo.setPric3(String.valueOf(pric3));
			vo.setPric4(String.valueOf(pric4));
			
			vo.setKunnrnm(param.get(i).getKunnrnm());

			vo.setHeaderSize("5");
			vo.setHeaderList(vo);
			
			returnList.add(vo);
			
			// 제품
			if(i==row_j && i<param.size()){
				for(row_j=i, row_cnt1=0; row_j<param.size(); row_j++){
					
					if(titl_gubn1.equals(param.get(row_j).getMvgr1nm())){
						row_cnt1++;
						
					} else {
						break; 
					}				
				}
			}	
			
			// 유통
			if(i==row_k && i<param.size()){		
				for(row_k=i, row_cnt2=0; row_k<param.size(); row_k++){
					
					if(titl_gubn2.equals(param.get(row_k).getMvgr1nm()+param.get(row_k).getVtwegnm())){
						row_cnt2++;
					} else {
						break; 
					}			
				}
			}
			
			// LG/NLG	
			if(i==row_m && i<param.size()){		
				for(row_m=i, row_cnt3=0; row_m<param.size(); row_m++){
					
					if(titl_gubn3.equals(param.get(row_m).getMvgr1nm()+param.get(row_m).getVtwegnm()+param.get(row_m).getKvgr1nm())) {
						row_cnt3++;
					} else {
						break; 
					}			
				}
			}
			
			// 구분	
			if(i==row_n && i<param.size()){		
				for(row_n=i, row_cnt4=0; row_n<param.size(); row_n++){
					if(titl_gubn4.equals(param.get(row_n).getMvgr1nm()+param.get(row_n).getVtwegnm()+param.get(row_n).getKvgr1nm()+param.get(row_n).getKvgr2nm())) 
						row_cnt4++;
					else {
						break; 
					}			
				}
			}	
			
			//구분별 합계				
			if(i!=0 && (i==row_n-1)){
				
				WorkStatVO kvgr2nm_tot = new WorkStatVO();
				kvgr2nm_tot.setQnty1(String.valueOf(kvgr2nm_tot_qnty1));
				kvgr2nm_tot.setQnty2(String.valueOf(kvgr2nm_tot_qnty2));
				kvgr2nm_tot.setQnty3(String.valueOf(kvgr2nm_tot_qnty3));
				kvgr2nm_tot.setQnty4(String.valueOf(kvgr2nm_tot_qnty4));
				kvgr2nm_tot.setAmnt1(String.valueOf(kvgr2nm_tot_amnt1));
				kvgr2nm_tot.setAmnt2(String.valueOf(kvgr2nm_tot_amnt2));
				kvgr2nm_tot.setAmnt3(String.valueOf(kvgr2nm_tot_amnt3));
				kvgr2nm_tot.setAmnt4(String.valueOf(kvgr2nm_tot_amnt4));
				
				if(kvgr2nm_tot_qnty1_o != 0) 
					kvgr2nm_tot_pric1 = Math.round(kvgr2nm_tot_amnt1_o/kvgr2nm_tot_qnty1_o); 
				else kvgr2nm_tot_pric1=0;	
				if(kvgr2nm_tot_qnty2_o != 0) 
					kvgr2nm_tot_pric2 = Math.round(kvgr2nm_tot_amnt2_o/kvgr2nm_tot_qnty2_o); 
				else kvgr2nm_tot_pric2=0;
				if(kvgr2nm_tot_qnty3_o != 0) 
					kvgr2nm_tot_pric3 = Math.round(kvgr2nm_tot_amnt3_o/kvgr2nm_tot_qnty3_o); 
				else kvgr2nm_tot_pric3=0;
				if(kvgr2nm_tot_qnty4_o != 0) 
					kvgr2nm_tot_pric4 = Math.round(kvgr2nm_tot_amnt4_o/kvgr2nm_tot_qnty4_o); 
				else kvgr2nm_tot_pric4=0;
			
				kvgr2nm_tot.setPric1(String.valueOf(kvgr2nm_tot_pric1));
				kvgr2nm_tot.setPric2(String.valueOf(kvgr2nm_tot_pric2));
				kvgr2nm_tot.setPric3(String.valueOf(kvgr2nm_tot_pric3));
				kvgr2nm_tot.setPric4(String.valueOf(kvgr2nm_tot_pric4));
				
				//합계 헤더명
				kvgr2nm_tot.setMvgr1nm(param.get(row_n-1).getMvgr1nm()); 
				kvgr2nm_tot.setVtwegnm(param.get(row_n-1).getVtwegnm());
				kvgr2nm_tot.setKvgr1nm(param.get(row_n-1).getKvgr1nm());
				kvgr2nm_tot.setKvgr2nm(param.get(row_n-1).getKvgr2nm() + " 합계");

				kvgr2nm_tot.setHeaderList(kvgr2nm_tot);
				kvgr2nm_tot.setHeaderSize("5");
				kvgr2nm_tot.setTotalRow("Y");
				kvgr2nm_tot.setBgColor("bg-gry1");
				
				returnList.add(kvgr2nm_tot);
				
				kvgr2nm_tot_qnty1=0;	 kvgr2nm_tot_qnty2=0;	 kvgr2nm_tot_qnty3=0;	 kvgr2nm_tot_qnty4=0;
				kvgr2nm_tot_amnt1=0;	 kvgr2nm_tot_amnt2=0;	 kvgr2nm_tot_amnt3=0;	 kvgr2nm_tot_amnt4=0;
				kvgr2nm_tot_qnty1_o=0;   kvgr2nm_tot_qnty2_o=0;  kvgr2nm_tot_qnty3_o=0;  kvgr2nm_tot_qnty4_o=0;
				kvgr2nm_tot_amnt1_o=0;   kvgr2nm_tot_amnt2_o=0;  kvgr2nm_tot_amnt3_o=0;  kvgr2nm_tot_amnt4_o=0;
				kvgr2nm_tot_pric1=0;	 kvgr2nm_tot_pric2=0;	 kvgr2nm_tot_pric3=0;	 kvgr2nm_tot_pric4=0;
			}		
			
			// LG/NLG별 합계			
			if(i==row_m-1 ){	
																																										
				WorkStatVO kvgr1nm_tot = new WorkStatVO();
				kvgr1nm_tot.setQnty1(String.valueOf(kvgr1nm_tot_qnty1));
				kvgr1nm_tot.setQnty2(String.valueOf(kvgr1nm_tot_qnty2));
				kvgr1nm_tot.setQnty3(String.valueOf(kvgr1nm_tot_qnty3));	
				kvgr1nm_tot.setQnty4(String.valueOf(kvgr1nm_tot_qnty4));
				kvgr1nm_tot.setAmnt1(String.valueOf(kvgr1nm_tot_amnt1));
				kvgr1nm_tot.setAmnt2(String.valueOf(kvgr1nm_tot_amnt2));
				kvgr1nm_tot.setAmnt3(String.valueOf(kvgr1nm_tot_amnt3));
				kvgr1nm_tot.setAmnt4(String.valueOf(kvgr1nm_tot_amnt4));
				
				if(kvgr1nm_tot_qnty1_o != 0) 
					kvgr1nm_tot_pric1 = Math.round(kvgr1nm_tot_amnt1_o/kvgr1nm_tot_qnty1_o); 
				else 
					kvgr1nm_tot_pric1 = 0;
				if(kvgr1nm_tot_qnty2_o != 0) 
					kvgr1nm_tot_pric2 = Math.round(kvgr1nm_tot_amnt2_o/kvgr1nm_tot_qnty2_o); 
				else 
					kvgr1nm_tot_pric2 = 0;
				if(kvgr1nm_tot_qnty3_o != 0) 
					kvgr1nm_tot_pric3 = Math.round(kvgr1nm_tot_amnt3_o/kvgr1nm_tot_qnty3_o); 
				else 
					kvgr1nm_tot_pric3 = 0;
				if(kvgr1nm_tot_qnty4_o != 0) 
					kvgr1nm_tot_pric4 = Math.round(kvgr1nm_tot_amnt4_o/kvgr1nm_tot_qnty4_o); 
				else 
					kvgr1nm_tot_pric4 = 0;
				
				kvgr1nm_tot.setPric1(String.valueOf(kvgr1nm_tot_pric1));
				kvgr1nm_tot.setPric2(String.valueOf(kvgr1nm_tot_pric2));
				kvgr1nm_tot.setPric3(String.valueOf(kvgr1nm_tot_pric3));
				kvgr1nm_tot.setPric4(String.valueOf(kvgr1nm_tot_pric4));
				
				kvgr1nm_tot.setMvgr1nm(param.get(row_m-1).getMvgr1nm());
				kvgr1nm_tot.setVtwegnm(param.get(row_m-1).getVtwegnm());
				kvgr1nm_tot.setKvgr1nm(param.get(row_m-1).getKvgr1nm() +" 합계");

				kvgr1nm_tot.setHeaderList(kvgr1nm_tot);
				kvgr1nm_tot.setHeaderSize("5");
				kvgr1nm_tot.setTotalRow("Y");
				kvgr1nm_tot.setBgColor("bg-gry2");
				
				returnList.add(kvgr1nm_tot);
				
				kvgr1nm_tot_qnty1=0;	 kvgr1nm_tot_qnty2=0;	 kvgr1nm_tot_qnty3=0;	 kvgr1nm_tot_qnty4=0;
				kvgr1nm_tot_amnt1=0;	 kvgr1nm_tot_amnt2=0;	 kvgr1nm_tot_amnt3=0;	 kvgr1nm_tot_amnt4=0;
				kvgr1nm_tot_qnty1_o=0;   kvgr1nm_tot_qnty2_o=0;   kvgr1nm_tot_qnty3_o=0;   kvgr1nm_tot_qnty4_o=0;
				kvgr1nm_tot_amnt1_o=0;   kvgr1nm_tot_amnt2_o=0;   kvgr1nm_tot_amnt3_o=0;   kvgr1nm_tot_amnt4_o=0;
				kvgr1nm_tot_pric1=0;	 kvgr1nm_tot_pric2=0;	 kvgr1nm_tot_pric3=0;	 kvgr1nm_tot_pric4=0;
			}	
			
			// 유통별 합계		
			if(i==row_k-1){	

				WorkStatVO vtwegnm_tot = new WorkStatVO();
				vtwegnm_tot.setQnty1(String.valueOf(vtwegnm_tot_qnty1));
				vtwegnm_tot.setQnty2(String.valueOf(vtwegnm_tot_qnty2));
				vtwegnm_tot.setQnty3(String.valueOf(vtwegnm_tot_qnty3));
				vtwegnm_tot.setQnty4(String.valueOf(vtwegnm_tot_qnty4));
				vtwegnm_tot.setAmnt1(String.valueOf(vtwegnm_tot_amnt1));
				vtwegnm_tot.setAmnt2(String.valueOf(vtwegnm_tot_amnt2));
				vtwegnm_tot.setAmnt3(String.valueOf(vtwegnm_tot_amnt3));
				vtwegnm_tot.setAmnt4(String.valueOf(vtwegnm_tot_amnt4));
				
				if(vtwegnm_tot_qnty1_o != 0) 
					vtwegnm_tot_pric1 = Math.round(vtwegnm_tot_amnt1_o/vtwegnm_tot_qnty1_o); 
				else	
					vtwegnm_tot_pric1 = 0;
				if(vtwegnm_tot_qnty2_o != 0) 
					vtwegnm_tot_pric2 = Math.round(vtwegnm_tot_amnt2_o/vtwegnm_tot_qnty2_o); 
				else	
					vtwegnm_tot_pric2 = 0;
				if(vtwegnm_tot_qnty3_o != 0) 
					vtwegnm_tot_pric3 = Math.round(vtwegnm_tot_amnt3_o/vtwegnm_tot_qnty3_o); 
				else	
					vtwegnm_tot_pric3 = 0;
				if(vtwegnm_tot_qnty4_o != 0) 
					vtwegnm_tot_pric4 = Math.round(vtwegnm_tot_amnt4_o/vtwegnm_tot_qnty4_o); 
				else	
					vtwegnm_tot_pric4 = 0;						
				
				vtwegnm_tot.setPric1(String.valueOf(vtwegnm_tot_pric1));
				vtwegnm_tot.setPric2(String.valueOf(vtwegnm_tot_pric2));
				vtwegnm_tot.setPric3(String.valueOf(vtwegnm_tot_pric3));
				vtwegnm_tot.setPric4(String.valueOf(vtwegnm_tot_pric4));
				
				vtwegnm_tot.setMvgr1nm(param.get(row_k-1).getMvgr1nm());
				vtwegnm_tot.setVtwegnm(param.get(row_k-1).getVtwegnm() +" 합계");
				
				vtwegnm_tot.setHeaderList(vtwegnm_tot);
				vtwegnm_tot.setHeaderSize("5");
				vtwegnm_tot.setTotalRow("Y");
				vtwegnm_tot.setBgColor("commonAppr");
				
				returnList.add(vtwegnm_tot);
				
				vtwegnm_tot_qnty1=0;	 vtwegnm_tot_qnty2=0;	 vtwegnm_tot_qnty3=0;	 vtwegnm_tot_qnty4=0;
				vtwegnm_tot_amnt1=0;	 vtwegnm_tot_amnt2=0;	 vtwegnm_tot_amnt3=0;	 vtwegnm_tot_amnt4=0;						
				vtwegnm_tot_qnty1_o=0;   vtwegnm_tot_qnty2_o=0;   vtwegnm_tot_qnty3_o=0;   vtwegnm_tot_qnty4_o=0;
				vtwegnm_tot_amnt1_o=0;   vtwegnm_tot_amnt2_o=0;   vtwegnm_tot_amnt3_o=0;   vtwegnm_tot_amnt4_o=0;
				vtwegnm_tot_pric1=0;	 vtwegnm_tot_pric2=0;	 vtwegnm_tot_pric3=0;	 vtwegnm_tot_pric4=0;
			}	
			
			// 제품별 합계		
			if(i==row_j-1){	
				WorkStatVO mvgr1nm_tot = new WorkStatVO();
				mvgr1nm_tot.setQnty1(String.valueOf(mvgr1nm_tot_qnty1));
				mvgr1nm_tot.setQnty2(String.valueOf(mvgr1nm_tot_qnty2));
				mvgr1nm_tot.setQnty3(String.valueOf(mvgr1nm_tot_qnty3));
				mvgr1nm_tot.setQnty4(String.valueOf(mvgr1nm_tot_qnty4));
				mvgr1nm_tot.setAmnt1(String.valueOf(mvgr1nm_tot_amnt1));
				mvgr1nm_tot.setAmnt2(String.valueOf(mvgr1nm_tot_amnt2));
				mvgr1nm_tot.setAmnt3(String.valueOf(mvgr1nm_tot_amnt3));
				mvgr1nm_tot.setAmnt4(String.valueOf(mvgr1nm_tot_amnt4));
				
				if(mvgr1nm_tot_qnty1_o != 0) 
					mvgr1nm_tot_pric1 = Math.round(mvgr1nm_tot_amnt1_o/mvgr1nm_tot_qnty1_o);	
				else 
					mvgr1nm_tot_pric1 = 0;
				if(mvgr1nm_tot_qnty2_o != 0) 
					mvgr1nm_tot_pric2 = Math.round(mvgr1nm_tot_amnt2_o/mvgr1nm_tot_qnty2_o);	
				else 
					mvgr1nm_tot_pric2 = 0;
				if(mvgr1nm_tot_qnty3_o != 0) 
					mvgr1nm_tot_pric3 = Math.round(mvgr1nm_tot_amnt3_o/mvgr1nm_tot_qnty3_o);	
				else 
					mvgr1nm_tot_pric3 = 0;
				if(mvgr1nm_tot_qnty4_o != 0) 
					mvgr1nm_tot_pric4 = Math.round(mvgr1nm_tot_amnt4_o/mvgr1nm_tot_qnty4_o);	
				else 
					mvgr1nm_tot_pric4 = 0;	
				
				mvgr1nm_tot.setPric1(String.valueOf(mvgr1nm_tot_pric1));
				mvgr1nm_tot.setPric2(String.valueOf(mvgr1nm_tot_pric2));
				mvgr1nm_tot.setPric3(String.valueOf(mvgr1nm_tot_pric3));
				mvgr1nm_tot.setPric4(String.valueOf(mvgr1nm_tot_pric4));
				
				mvgr1nm_tot.setMvgr1nm(param.get(row_j-1).getMvgr1nm() +" 합계");

				mvgr1nm_tot.setHeaderList(mvgr1nm_tot);
				mvgr1nm_tot.setHeaderSize("5");
				mvgr1nm_tot.setTotalRow("Y");
				mvgr1nm_tot.setBgColor("bg-blue");
				
				returnList.add(mvgr1nm_tot);
				
				mvgr1nm_tot_qnty1=0;	 mvgr1nm_tot_qnty2=0;	 mvgr1nm_tot_qnty3=0;	 mvgr1nm_tot_qnty4=0;
				mvgr1nm_tot_amnt1=0;	 mvgr1nm_tot_amnt2=0;	 mvgr1nm_tot_amnt3=0;	 mvgr1nm_tot_amnt4=0;
				mvgr1nm_tot_qnty1_o=0;   mvgr1nm_tot_qnty2_o=0;   mvgr1nm_tot_qnty3_o=0;   mvgr1nm_tot_qnty4_o=0;
				mvgr1nm_tot_amnt1_o=0;   mvgr1nm_tot_amnt2_o=0;   mvgr1nm_tot_amnt3_o=0;   mvgr1nm_tot_amnt4_o=0;
				mvgr1nm_tot_pric1=0;	 mvgr1nm_tot_pric2=0;	 mvgr1nm_tot_pric3=0;	 mvgr1nm_tot_pric4=0;
			}
			
			//토탈 합계
			if(i==param.size()-1){	
				
				WorkStatVO tot = new WorkStatVO();
				tot.setQnty1(String.valueOf(tot_qnty1)); 
				tot.setQnty2(String.valueOf(tot_qnty2));
				tot.setQnty3(String.valueOf(tot_qnty3));
				tot.setQnty4(String.valueOf(tot_qnty4));
				
				tot.setAmnt1(String.valueOf(tot_amnt1)); 
				tot.setAmnt2(String.valueOf(tot_amnt2));
				tot.setAmnt3(String.valueOf(tot_amnt3));
				tot.setAmnt4(String.valueOf(tot_amnt4));
				
				if(tot_qnty1_o != 0 ) 
					tot_pric1 = Math.round(tot_amnt1_o/tot_qnty1_o); 
				else 
					tot_pric1=0;	
				if(tot_qnty2_o != 0 ) 
					tot_pric2 = Math.round(tot_amnt2_o/tot_qnty2_o); 
				else 
					tot_pric2=0;
				if(tot_qnty3_o != 0 ) 
					tot_pric3 = Math.round(tot_amnt3_o/tot_qnty3_o); 
				else 
					tot_pric3=0;
				if(tot_qnty4_o != 0 ) 
					tot_pric4 = Math.round(tot_amnt4_o/tot_qnty4_o); 
				else 
					tot_pric4=0;
				
				tot.setPric1(String.valueOf(tot_pric1)); 
				tot.setPric2(String.valueOf(tot_pric2));
				tot.setPric3(String.valueOf(tot_pric3));
				tot.setPric4(String.valueOf(tot_pric4));
				
				tot.setMvgr1nm("총 합계");
				tot.setHeaderSize("5");
				tot.setTotalRow("Y");
				tot.setHeaderList(tot);
				tot.setBgColor("bg-red");
				
				returnList.add(tot);
				
			}

		}

			return returnList;
	};
	
	/**
	 * PMMA 매출 현황
	 * @param param
	 * @return
	 */
	public List<WorkStatVO> getPMMASalesStatTable(List<WorkStatVO> param){
		
		List<WorkStatVO> returnList = new ArrayList<WorkStatVO>();
		
		double	qnty1=0,	qnty2=0,	qnty3=0,	qnty4=0,
				amnt1=0,	amnt2=0,	amnt3=0,	amnt4=0,
				qnty1_o=0,	qnty2_o=0,	qnty3_o=0,	qnty4_o=0, 
				amnt1_o=0,	amnt2_o=0,	amnt3_o=0,	amnt4_o=0,
				pric1=0,	pric2=0,	pric3=0,	pric4=0,
					
		//토탈합계
		tot_qnty1=0,	tot_qnty2=0,	tot_qnty3=0,	tot_qnty4=0,
		tot_amnt1=0,	tot_amnt2=0,	tot_amnt3=0,	tot_amnt4=0,
		tot_qnty1_o=0,	tot_qnty2_o=0,	tot_qnty3_o=0,	tot_qnty4_o=0,
		tot_amnt1_o=0,	tot_amnt2_o=0,	tot_amnt3_o=0,	tot_amnt4_o=0,
		tot_pric1=0,	tot_pric2=0,	tot_pric3=0,	tot_pric4=0,

		//지역별합계
		vkbur_tot_qnty1=0,		vkbur_tot_qnty2=0,		vkbur_tot_qnty3=0,		vkbur_tot_qnty4=0,
		vkbur_tot_amnt1=0,		vkbur_tot_amnt2=0,		vkbur_tot_amnt3=0,		vkbur_tot_amnt4=0,
		vkbur_tot_qnty1_o=0,	vkbur_tot_qnty2_o=0,	vkbur_tot_qnty3_o=0,	vkbur_tot_qnty4_o=0,
		vkbur_tot_amnt1_o=0,	vkbur_tot_amnt2_o=0,	vkbur_tot_amnt3_o=0,	vkbur_tot_amnt4_o=0,
		vkbur_tot_pric1=0,		vkbur_tot_pric2=0,		vkbur_tot_pric3=0,		vkbur_tot_pric4=0,

		//유통별합계
		vtweg_tot_qnty1=0,		vtweg_tot_qnty2=0,		vtweg_tot_qnty3=0,		vtweg_tot_qnty4=0,
		vtweg_tot_amnt1=0,		vtweg_tot_amnt2=0,		vtweg_tot_amnt3=0,		vtweg_tot_amnt4=0,
		vtweg_tot_qnty1_o=0,	vtweg_tot_qnty2_o=0,	vtweg_tot_qnty3_o=0,	vtweg_tot_qnty4_o=0,
		vtweg_tot_pric1=0,		vtweg_tot_pric2=0,		vtweg_tot_pric3=0,		vtweg_tot_pric4=0;
		
		int row_j=0, row_k=0, row_m=0, 
			row_cnt1=0, row_cnt2=0;
		
		for(int i=0;i<param.size();i++) {
			//수량
			qnty1_o = Double.parseDouble(param.get(i).getQnty1());
			qnty2_o = Double.parseDouble(param.get(i).getQnty2());
			qnty3_o = Double.parseDouble(param.get(i).getQnty3());
			qnty4_o = Double.parseDouble(param.get(i).getQnty4());
			
			//금액
			amnt1_o = Double.parseDouble(param.get(i).getAmnt1());
			amnt2_o = Double.parseDouble(param.get(i).getAmnt2());
			amnt3_o = Double.parseDouble(param.get(i).getAmnt3());
			amnt4_o = Double.parseDouble(param.get(i).getAmnt4());
			
			//수량 KG-->톤
			qnty1 = Math.round(qnty1_o/1000);
			qnty2 = Math.round(qnty2_o/1000);
			qnty3 = Math.round(qnty3_o/1000);
			qnty4 = Math.round(qnty4_o/1000);
			
			//금액 원-->백만원 				
			amnt1 = Math.round(amnt1_o/1000000);
			amnt2 = Math.round(amnt2_o/1000000);
			amnt3 = Math.round(amnt3_o/1000000);
			amnt4 = Math.round(amnt4_o/1000000);				
			
			//판가  금액/수량=원/KG
			if(!param.get(i).getQnty1().equals("0")) 
				pric1 = Math.round(amnt1_o/qnty1_o);	
			else 
				pric1 = 0;
			if(!param.get(i).getQnty2().equals("0")) 
				pric2 = Math.round(amnt2_o/qnty2_o);	
			else 
				pric2 = 0;
			if(!param.get(i).getQnty3().equals("0")) 
				pric3 = Math.round(amnt3_o/qnty3_o);	
			else 
				pric3 = 0;
			if(!param.get(i).getQnty4().equals("0")) 
				pric4 = Math.round(amnt4_o/qnty4_o);		
			else 
				pric4 = 0;
			
			// 토탈합계 
			tot_qnty1 += qnty1;		tot_qnty2 += qnty2;		tot_qnty3 += qnty3;		tot_qnty4 += qnty4;
			tot_amnt1 += amnt1;		tot_amnt2 += amnt2;		tot_amnt3 += amnt3;		tot_amnt4 += amnt4;	
			tot_qnty1_o += qnty1_o;	tot_qnty2_o += qnty2_o;	
			tot_qnty3_o += qnty3_o;	tot_qnty4_o += qnty4_o;
			tot_amnt1_o += amnt1_o;	tot_amnt2_o += amnt2_o;	
			tot_amnt3_o += amnt3_o;	tot_amnt4_o += amnt4_o;	
							
			//지역합계
			vkbur_tot_qnty1 += qnty1;	vkbur_tot_qnty2 += qnty2;	vkbur_tot_qnty3 += qnty3;	vkbur_tot_qnty4 += qnty4;
			vkbur_tot_amnt1 += amnt1;	vkbur_tot_amnt2 += amnt2;	vkbur_tot_amnt3 += amnt3;	vkbur_tot_amnt4 += amnt4;	
			vkbur_tot_qnty1_o += qnty1_o;	vkbur_tot_qnty2_o += qnty2_o;	
			vkbur_tot_qnty3_o += qnty3_o;	vkbur_tot_qnty4_o += qnty4_o;
			vkbur_tot_amnt1_o += amnt1_o;	vkbur_tot_amnt2_o += amnt2_o;	
			vkbur_tot_amnt3_o += amnt3_o;	vkbur_tot_amnt4_o += amnt4_o;
			
			WorkStatVO vo = new WorkStatVO();
			
			vo.setQnty1(String.valueOf(qnty1));
			vo.setQnty2(String.valueOf(qnty2));
			vo.setQnty3(String.valueOf(qnty3));
			vo.setQnty4(String.valueOf(qnty4));
			vo.setAmnt1(String.valueOf(amnt1));
			vo.setAmnt2(String.valueOf(amnt2));
			vo.setAmnt3(String.valueOf(amnt3));
			vo.setAmnt4(String.valueOf(amnt4));
			vo.setPric1(String.valueOf(pric1));
			vo.setPric2(String.valueOf(pric2));
			vo.setPric3(String.valueOf(pric3));
			vo.setPric4(String.valueOf(pric4));
			
			vo.setKunnrnm(param.get(i).getKunnrnm()); //업체명
			
			String vtweg   = param.get(i).getVtweg(); //유통경로
			String vkburnm = param.get(i).getVkburnm(); //지역
			
			// 유통
			if(i==row_j && i<param.size()){
				
				for(row_j=i, row_cnt1=0; row_j<param.size(); row_j++){
					
					if(vtweg.equals(param.get(row_j).getVtweg())){
						row_cnt1++;
					} else {
						break; 
					}
				}
				
				//code -> text
				if(vtweg.equals("10"))
					vo.setVtwegnm("내수");
				else if(vtweg.equals("20"))
					vo.setVtwegnm("로칼");
				else if(vtweg.equals("30"))
					vo.setVtwegnm("직수출");
				else if(vtweg.equals("40"))
					vo.setVtwegnm("로컬수출");
				else if(vtweg.equals("90"))
					vo.setVtwegnm("기타");
				
				vo.setRowSpan(String.valueOf(row_cnt1));
			}	
			
			// 지역
			if(i==row_k && i<param.size()){		
				
				for(row_k=i, row_cnt2=0; row_k<param.size();row_k++){
					
					if(vkburnm.equals(param.get(row_k).getVkburnm()) && row_k<param.size()-1) 
						row_cnt2++;
					else {
						if(row_cnt2>0) {
							vo.setVkburnm(vkburnm);
							vo.setRowSpan2(String.valueOf(row_cnt2));
						}	
						
						break; 
					}
				}			
			}
			
			//기타지역, 기타업체
			if(param.get(i).getKunnrnm().equals("기타") 
				&& (param.get(i).getVkburnm().equals("기타") ||param.get(i).getVkburnm().equals(""))) {
				vo.setColSpan("2");
				vo.setVkburnm("기타");
				vo.setKunnrnm(""); //colspan 적용 위해 값 비우기
				vo.setVtwegnm(""); //rowspan 적용 위해 값 비우기
				vo.setRowSpan(""); //상위카테고리(유통)별 rowspan 적용 위해 값 비우기
			}
			
			returnList.add(vo);

			// 시판합계, 수출합계
			if(i==row_j-1){	
				
				WorkStatVO vkbur_tot = new WorkStatVO();
				vkbur_tot.setQnty1(String.valueOf(vkbur_tot_qnty1));
				vkbur_tot.setQnty2(String.valueOf(vkbur_tot_qnty2));
				vkbur_tot.setQnty3(String.valueOf(vkbur_tot_qnty3));
				vkbur_tot.setQnty4(String.valueOf(vkbur_tot_qnty4));
				vkbur_tot.setAmnt1(String.valueOf(vkbur_tot_amnt1));
				vkbur_tot.setAmnt2(String.valueOf(vkbur_tot_amnt2));
				vkbur_tot.setAmnt3(String.valueOf(vkbur_tot_amnt3));
				vkbur_tot.setAmnt4(String.valueOf(vkbur_tot_amnt4));
				
				if(vkbur_tot_qnty1_o !=0 ) 
					vkbur_tot_pric1 = Math.round(vkbur_tot_amnt1_o/vkbur_tot_qnty1_o); 
				else 
					vkbur_tot_pric1 = 0;
				if(vkbur_tot_qnty2_o !=0 ) 
					vkbur_tot_pric2 = Math.round(vkbur_tot_amnt2_o/vkbur_tot_qnty2_o); 
				else 
					vkbur_tot_pric2 = 0;
				if(vkbur_tot_qnty3_o !=0 ) 
					vkbur_tot_pric3 = Math.round(vkbur_tot_amnt3_o/vkbur_tot_qnty3_o); 
				else 
					vkbur_tot_pric3 = 0;
				if(vkbur_tot_qnty4_o !=0 ) 
					vkbur_tot_pric4 = Math.round(vkbur_tot_amnt4_o/vkbur_tot_qnty4_o); 
				else 
					vkbur_tot_pric4 = 0;	
				
				vkbur_tot.setPric1(String.valueOf(vkbur_tot_pric1));
				vkbur_tot.setPric2(String.valueOf(vkbur_tot_pric2));
				vkbur_tot.setPric3(String.valueOf(vkbur_tot_pric3));
				vkbur_tot.setPric4(String.valueOf(vkbur_tot_pric4));
				
				if (param.get(i).getVtweg().equals("10")) {
					vkbur_tot.setVtwegnm("시판 합계");
				}else {
					vkbur_tot.setVtwegnm("수출 합계");
				}
				
				vkbur_tot.setColSpan("3");
				vkbur_tot.setRowSpan("");
				returnList.add(vkbur_tot);
				
				vkbur_tot_qnty1=0;	 vkbur_tot_qnty2=0;	 vkbur_tot_qnty3=0;	 vkbur_tot_qnty4=0;
				vkbur_tot_amnt1=0;	 vkbur_tot_amnt2=0;	 vkbur_tot_amnt3=0;	 vkbur_tot_amnt4=0;						
				vkbur_tot_qnty1_o=0;   vkbur_tot_qnty2_o=0;   vkbur_tot_qnty3_o=0;   vkbur_tot_qnty4_o=0;
				vkbur_tot_amnt1_o=0;   vkbur_tot_amnt2_o=0;   vkbur_tot_amnt3_o=0;   vkbur_tot_amnt4_o=0;
				vkbur_tot_pric1=0;	 vkbur_tot_pric2=0;	 vkbur_tot_pric3=0;	 vkbur_tot_pric4=0;
			}	
			
			//토탈 합계
			if(i==param.size()-1){	
				
				WorkStatVO tot = new WorkStatVO();
				tot.setQnty1(String.valueOf(tot_qnty1)); 
				tot.setQnty2(String.valueOf(tot_qnty2));
				tot.setQnty3(String.valueOf(tot_qnty3));
				tot.setQnty4(String.valueOf(tot_qnty4));
				
				tot.setAmnt1(String.valueOf(tot_amnt1)); 
				tot.setAmnt2(String.valueOf(tot_amnt2));
				tot.setAmnt3(String.valueOf(tot_amnt3));
				tot.setAmnt4(String.valueOf(tot_amnt4));
				
				if(tot_qnty1_o != 0 ) 
					tot_pric1 = Math.round(tot_amnt1_o/tot_qnty1_o); 
				else 
					tot_pric1=0;	
				if(tot_qnty2_o != 0 ) 
					tot_pric2 = Math.round(tot_amnt2_o/tot_qnty2_o); 
				else 
					tot_pric2=0;
				if(tot_qnty3_o != 0 ) 
					tot_pric3 = Math.round(tot_amnt3_o/tot_qnty3_o); 
				else 
					tot_pric3=0;
				if(tot_qnty4_o != 0 ) 
					tot_pric4 = Math.round(tot_amnt4_o/tot_qnty4_o); 
				else 
					tot_pric4=0;
				
				tot.setPric1(String.valueOf(tot_pric1)); 
				tot.setPric2(String.valueOf(tot_pric2));
				tot.setPric3(String.valueOf(tot_pric3));
				tot.setPric4(String.valueOf(tot_pric4));
				
				tot.setVtwegnm("총 합계");
				tot.setColSpan("3");
				returnList.add(tot);
				
			}
		}
		
		return returnList;
	}
	
	/**
	 * 회전일
	 * @param param
	 * @return
	 */
	public List<WorkStatVO> getBondStatTable(List<WorkStatVO> param){
		List<WorkStatVO> returnList = new ArrayList<WorkStatVO>();
		
		double qnty1=0,	 qnty2=0,	 qnty3=0,	 qnty4=0;
		int j=0, row_cnt=0;
		String kvgr1="";
		
		for(int i=0;i<param.size();i++){
			qnty1 = Math.round(Double.parseDouble(param.get(i).getQnty1()));  
			qnty2 = Math.round(Double.parseDouble(param.get(i).getQnty2()));
			qnty3 = Math.round(Double.parseDouble(param.get(i).getQnty3()));
			qnty4 = Math.round(Double.parseDouble(param.get(i).getQnty4()));

			WorkStatVO vo = new WorkStatVO();
			vo.setQnty1(String.valueOf(qnty1));
			vo.setQnty2(String.valueOf(qnty2));
			vo.setQnty3(String.valueOf(qnty3));
			vo.setQnty4(String.valueOf(qnty4));
			
			if(param.get(i).getVkorg().equals("3000")){
				vo.setVkburnm(param.get(i).getVkburnm()); //구분
				vo.setKvgr1nm(param.get(i).getKvgr1nm()); //유통
				if(i==0) { //내수 첫 행 
					vo.setRowSpan("3");
				} else if(i==3) { //로칼
					continue;
				} else if(i==4) { //수출 첫 행
					vo.setRowSpan("3");
				} else if(i==param.size()-1) {//TOTAL
					vo.setColSpan("2");
					vo.setVkburnm("");
				} else { // 나머지
					vo.setKvgr1nm(""); //유통
				}
				
			} else {
				kvgr1 = param.get(i).getKvgr1(); //유통
				vo.setVkburnm(param.get(i).getVkburnm()); //구분
				if(i==j && i<param.size()-1){
					for(j=i, row_cnt=0;j<param.size();j++){
						if(kvgr1.equals(param.get(j).getKvgr1())) {
							row_cnt++;
						} else {
							vo.setRowSpan(String.valueOf(row_cnt));
							vo.setKvgr1nm(param.get(i).getKvgr1nm());
							break; 
						}
						
					}
				}
				
				//전체 합계 행
				if(i==param.size()-4) {
					vo.setRowSpan("4");
					vo.setKvgr1nm("합계");
				}
			}

			returnList.add(vo);
		}
		
		return returnList;
	}
	/**
	 * MMA 재고/생산현황
	 * @param param
	 * @return
	 */
	public List<WorkStatVO> getMMAStockProductTable(List<WorkStatVO> param){
		List<WorkStatVO> returnList = new ArrayList<WorkStatVO>();
		double qnty1=0, qnty2=0, qnty3=0, qnty4=0;  
		int row_j=0, row_k=0, row_m=0, row_cnt1=0, row_cnt2=0, row_cnt3=0; 
		
		for(int i=0;i<param.size();i++){
			qnty1 = Math.round(Double.parseDouble(param.get(i).getQnty1())/1000);
			qnty2 = Math.round(Double.parseDouble(param.get(i).getQnty2())/1000);
			qnty3 = Math.round(Double.parseDouble(param.get(i).getQnty3())/1000);
			qnty4 = Math.round(Double.parseDouble(param.get(i).getQnty4())/1000);
			
			String vkorgnm = param.get(i).getVkorgnm(); //구분1 (제품)
			String vtwegnm = param.get(i).getVtwegnm(); //구분2 
			String vkburnm = param.get(i).getVkburnm(); 
			
			WorkStatVO vo = new WorkStatVO();
			
			vo.setQnty1(String.valueOf(qnty1));
			vo.setQnty2(String.valueOf(qnty2));
			vo.setQnty3(String.valueOf(qnty3));
			vo.setQnty4(String.valueOf(qnty4));
			vo.setBzirknm(param.get(i).getBzirknm());
			
			//구분1(제품) count
			if(i==row_j && i<param.size()){
				for(row_j=i, row_cnt1=0;row_j<param.size();row_j++){
					if(!param.get(row_j).getVtwegnm().equals("재고") && row_j<param.size()-1) row_cnt1++;
					else{
						row_cnt1++;
						row_j++;
						vo.setVkorgnm(vkorgnm);
						vo.setRowSpan(String.valueOf(row_cnt1));
						break; 
					}				
				}
			}
			
			//구분2(입고,출고, 재고) count
			if(i==row_k && i<param.size()){
				for(row_k=i, row_cnt2=0;row_m<param.size();row_k++){
					if(vtwegnm.equals(param.get(row_k).getVtwegnm()) && row_m<param.size()-1) row_cnt2++;
					else {
						
						vo.setVtwegnm(vtwegnm);
						
						if(vtwegnm.equals("재고")) {
							vo.setBzirknm("");
							vo.setColSpan("3");	//재고
						} else {
							vo.setRowSpan2(String.valueOf(row_cnt2));//구분2	
						}
						
						break; 
					}			
				}
			}
			
			//구분3 count
			if(i==row_m && i<param.size()){
				for(row_m=i, row_cnt3=0;row_m<param.size();row_m++){
					
					if(vkburnm.equals(param.get(row_m).getVkburnm()) && row_m<param.size()-1) row_cnt3++;
					else {
							vo.setVkburnm(vkburnm);
								
							if(row_cnt3>1) {
									vo.setRowSpan3(String.valueOf(row_cnt3)); //구분3
							} else if(vkburnm.equals("입고합계") || vkburnm.equals("출고합계") || vkburnm.equals("기타") ) {
								vo.setBzirknm("");
								vo.setColSpan("2");
							} else if(vkburnm.equals("재고")) {
								vo.setVkburnm("");
							}
							
						break; 
					}				
				}
			}
			returnList.add(vo);	
		}
		return returnList;
	}
	/**
	 * PMMA 재고/생산현황
	 * @param param
	 * @return
	 */
	public List<WorkStatVO> getPMMAStockProductTable(List<WorkStatVO> param){
		List<WorkStatVO> returnList = new ArrayList<WorkStatVO>();
		
		double 	qnty1=0,	 		  qnty2=0,			  qnty3=0,			  qnty4=0, 
				vkburnm_tot_qnty1=0,  vkburnm_tot_qnty2=0,  vkburnm_tot_qnty3=0,  vkburnm_tot_qnty4=0,
				tot_qnty1=0,		  tot_qnty2=0,		  tot_qnty3=0,		  tot_qnty4=0; 
		
		int row_j=0,  row_cnt1=0;
		
		for(int i=0;i<param.size();i++){
			qnty1 = Math.round(Double.parseDouble(param.get(i).getQnty1())/1000);  
			qnty2 = Math.round(Double.parseDouble(param.get(i).getQnty2())/1000);
			qnty3 = Math.round(Double.parseDouble(param.get(i).getQnty3())/1000);
			qnty4 = Math.round(Double.parseDouble(param.get(i).getQnty4())/1000);
			
			vkburnm_tot_qnty1 += qnty1;  
			vkburnm_tot_qnty2 += qnty2;
			vkburnm_tot_qnty3 += qnty3;
			vkburnm_tot_qnty4 += qnty4;				

			tot_qnty1 += qnty1;
			tot_qnty2 += qnty2;
			tot_qnty3 += qnty3;
			tot_qnty4 += qnty4;
			
			String vkburnm = param.get(i).getVkburnm(); //구분

			WorkStatVO vo = new WorkStatVO();
			vo.setQnty1(String.valueOf(qnty1));
			vo.setQnty2(String.valueOf(qnty2));
			vo.setQnty3(String.valueOf(qnty3));
			vo.setQnty4(String.valueOf(qnty4));
			vo.setBzirk(param.get(i).getBzirk());
			if(param.get(i).getBzirk().equals("3052")) {
				vo.setBzirknm("WISCOM");
			} else {
				vo.setBzirknm(param.get(i).getBzirknm());
			}
			
			//구분 count
			if(i==row_j && i<param.size()){
				for(row_j=i, row_cnt1=0;row_j<param.size();row_j++){
					if(param.get(row_j).getVkburnm().equals(vkburnm) && row_j<param.size()-1) row_cnt1++;
					else{
						if(row_cnt1>0) {
							vo.setVkburnm(vkburnm);
							vo.setRowSpan(String.valueOf(row_cnt1));
						}	
						break; 
					}				
				}
			}
			
			//구분별 합계 행
			if(i!=0 && (i==row_j-1) ){
				vo.setColSpan("2");
				vo.setBzirk(vkburnm+" 합계");
				vo.setBzirknm("");
				vo.setQnty1(String.valueOf(vkburnm_tot_qnty1));
				vo.setQnty2(String.valueOf(vkburnm_tot_qnty2));
				vo.setQnty3(String.valueOf(vkburnm_tot_qnty3));
				vo.setQnty4(String.valueOf(vkburnm_tot_qnty4));
				
				vkburnm_tot_qnty1 = 0;	vkburnm_tot_qnty2 = 0;	vkburnm_tot_qnty3 = 0;	vkburnm_tot_qnty4 = 0;
				
			}
			
			//전체 합계 행
			if(i==param.size()-1) {
				vo.setColSpan("3");
				vo.setVkburnm("전체 합계");
				vo.setBzirk("");
				vo.setBzirknm("");
				vo.setQnty1(String.valueOf(tot_qnty1));
				vo.setQnty2(String.valueOf(tot_qnty2));
				vo.setQnty3(String.valueOf(tot_qnty3));
				vo.setQnty4(String.valueOf(tot_qnty4));
			}
			
			returnList.add(vo);
		}
		
		return returnList;
	}
	
	//메인 매출 차트 데이터 가져오기
	@Override
	public List<List<WorkStatVO>> getMonthlySalesStatList(WorkStatVO param) {
		List<List<WorkStatVO>> returnList = new ArrayList<List<WorkStatVO>>();
		List<WorkStatVO> inputList = new ArrayList<WorkStatVO>();		//조회용 파라미터(년월, 영업조직) 저장할 리스트

		String today = Util.getToday();
		String startMonth = DateUtil.addMonth(today, -12);	//조회 시작년월	(12개월 전)
		
		// 현재 일자가 10일 미만이면 조회년월 기간을 한달 앞당김(전월까지 조회)
		if(Integer.parseInt(today.substring(6)) < 10) {
			startMonth = DateUtil.addMonth(startMonth, -1);
		}
		
		//1년치 조회 파라미터 저장
		for(int i=0; i<12; i++) {
			WorkStatVO workStatVo = new WorkStatVO();
			workStatVo.setYyyyMm(startMonth.substring(0, 6));
			workStatVo.setVkorg(param.getVkorg());
			inputList.add(workStatVo) ;
			startMonth = DateUtil.addMonth(startMonth, 1);	//조회년월 1개월 증가
		}
		
		List<List<WorkStatVO>> saleList = new ArrayList<List<WorkStatVO>>();	
		if(param.getVkorg() != null && param.getVkorg() != "") {
			saleList.addAll(getMonthlySalesStatListEach(inputList)); //영업조직별 매출
		} else {
			saleList.addAll(getMonthlySalesStatListAll(inputList)); //전사 매출
		}
		
		returnList.addAll(saleList);
		return returnList;
		
	}
	
	//영업이익 or 매출 차트 눈금 만들기
	public Double[] sortDataAndGetTicks(String targetData, List<WorkStatVO> list) {
		
		Double[] ticks = new Double[5];
		
		List<WorkStatVO> sortList = new ArrayList<WorkStatVO>();
		for(WorkStatVO workVO : list) {
			WorkStatVO cloneVO = (WorkStatVO)workVO.clone();
			sortList.add(cloneVO);
		}
		
		if(targetData.equals("profit")) { //영업이익
			Collections.sort(sortList, WorkStatVO.sortProfitDESC);
			Double minValue = Math.floor(Double.parseDouble(sortList.get(sortList.size()-1).getZyuyy())/10) * 10;
			Double maxValue = Math.ceil(Double.parseDouble(sortList.get(0).getZyuyy())/10) * 10;
			
			Double tickInterval = Math.ceil(((maxValue - minValue) / 4)/10) * 10;
			ticks[0] = minValue;
			ticks[1] = minValue + tickInterval;
			ticks[2] = minValue + tickInterval*2;
			ticks[3] = minValue + tickInterval*3;
			ticks[4] = minValue + tickInterval*4;
			
		} else if(targetData.equals("sales")) { //매출
			Collections.sort(sortList, WorkStatVO.sortSalesDESC);
			Double minValue = Math.floor(Double.parseDouble(sortList.get(sortList.size()-1).getValue3())/1000) * 1000;
			Double maxValue = Math.ceil(Double.parseDouble(sortList.get(0).getValue3())/1000) * 1000;
			
			Double tickInterval = Math.ceil(((maxValue - minValue) / 4)/1000) * 1000;
			
			ticks[0] = minValue;
			ticks[1] = minValue + tickInterval;
			ticks[2] = minValue + tickInterval*2;
			ticks[3] = minValue + tickInterval*3;
			ticks[4] = minValue + tickInterval*4;
			
		}
		
		return ticks;
		
	}
	
	//영업조직별, 월별 영업이익
	public Map<String, List<WorkStatVO>> getNetProfitList(WorkStatVO param){
		
		List<WorkStatVO> inputList = new ArrayList<WorkStatVO>();	//조회년월 저장할 리스트	
		
		String today = Util.getToday();
		String startMonth = DateUtil.addMonth(today, -12);	//조회 시작년월	(12개월 전)
		
		// 현재 일자가 10일 미만이면 조회년월 기간을 한달 앞당김(전월까지 조회)
		if(Integer.parseInt(today.substring(6)) < 10) {
			startMonth = DateUtil.addMonth(startMonth, -1);
		}
		
		for(int i=0; i<12; i++) {
			WorkStatVO workStatVo = new WorkStatVO();
			workStatVo.setYyyyMm(startMonth.substring(0, 6));
			inputList.add(workStatVo) ;
			startMonth = DateUtil.addMonth(startMonth, 1);
			
		}
		
		Map<String, List<WorkStatVO>> profitList = new HashMap<String, List<WorkStatVO>>();
		List<WorkStatVO> pmmaProfitList = new ArrayList<WorkStatVO>();
		List<WorkStatVO> mmaProfitList = new ArrayList<WorkStatVO>();
				
		for(WorkStatVO input : inputList) {
			String year = input.getYyyyMm().substring(0, 4);
			String month = "0"+ input.getYyyyMm().substring(4);
			
			Map<String, WorkStatVO> monthlyProfitMap = sapSearchServiceCache.getNetProfitListCache(year, month);
			
			pmmaProfitList.add(monthlyProfitMap.get("monthlyPmmaProfit"));
			mmaProfitList.add(monthlyProfitMap.get("monthlyMmaProfit"));
		
		}
		
		profitList.put("pmmaProfit", pmmaProfitList);
		profitList.put("mmaProfit", mmaProfitList);
		
		
		return profitList;
	}
	
	//영업조직별 , 월별 매출 (내수, 수출)
	public List<List<WorkStatVO>> getMonthlySalesStatListEach(List<WorkStatVO> inputList) {

		List<List<WorkStatVO>> returnList = new ArrayList<List<WorkStatVO>>();
		
		for(WorkStatVO inputVo : inputList) {
			List<WorkStatVO> outputList = new ArrayList<WorkStatVO>();
			
			JcoTableParam tableParam = new JcoTableParam();
			Map<String, Object> paramMap = new HashMap<String, Object>();
			tableParam.put("T_LIST", paramMap);
			
			Map<String, Object> inputParam = new HashMap<String, Object>();
			inputParam.put("I_SPMON", inputVo.getYyyyMm()); //기간-년월 
			inputParam.put("I_VKORG", inputVo.getVkorg());  //영업조직
			
			Map<String, Object> outputParam = new HashMap<String, Object>();
			try {
				jcoConnector.executeFunction(FNC_SAP_MAIN_MONTLY_SALES, inputParam, outputParam, tableParam);
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			List<WorkStatVO> rows = (List<WorkStatVO>) tableParam.get("T_LIST", WorkStatVO.class);
			
			for(WorkStatVO row : rows) {
				if(row.getSort().equals("201") || row.getSort().equals("202")){	//201:내수 , 202:수출
					row.setYyyy(inputVo.getYyyyMm().substring(0,4));
					row.setMm(inputVo.getYyyyMm().substring(4));
					double value3 = Math.round(Double.parseDouble(row.getValue3())/1000000);
					row.setValue3(String.valueOf(value3));
					outputList.add(row);
				} 
			}
			returnList.add(outputList);
		} 
		return returnList;
	} 
	//월별 전사 매출(내수, 수출)
	public List<List<WorkStatVO>> getMonthlySalesStatListAll(List<WorkStatVO> inputList) {

		List<List<WorkStatVO>> returnList = new ArrayList<List<WorkStatVO>>();
		
		int orgCnt = 0;
		for(Vkorg org : Vkorg.values()) {
			for(int i=0; i<inputList.size(); i++) {
				List<WorkStatVO> outputList = new ArrayList<WorkStatVO>();

				JcoTableParam tableParam = new JcoTableParam();
				Map<String, Object> paramMap = new HashMap<String, Object>();
				tableParam.put("T_LIST", paramMap);
				
				Map<String, Object> inputParam = new HashMap<String, Object>();
				inputParam.put("I_SPMON", inputList.get(i).getYyyyMm()); //기간-년월 
				inputParam.put("I_VKORG", org.getCode());  //영업조직
				
				Map<String, Object> outputParam = new HashMap<String, Object>();
				try {
					jcoConnector.executeFunction(FNC_SAP_MAIN_MONTLY_SALES, inputParam, outputParam, tableParam);
				}catch(Exception e) {
					e.printStackTrace();
				}
				
				List<WorkStatVO> rows = (List<WorkStatVO>) tableParam.get("T_LIST", WorkStatVO.class);
				
				if(orgCnt == 0) { 
					for(WorkStatVO row : rows) {
						if(row.getSort().equals("201") || row.getSort().equals("202")){
							row.setYyyy(inputList.get(i).getYyyyMm().substring(0,4));
							row.setMm(inputList.get(i).getYyyyMm().substring(4));
							double value3 = Math.round(Double.parseDouble(row.getValue3())/1000000);
							row.setValue3(String.valueOf(value3));
							outputList.add(row);
						} 
					}
					returnList.add(outputList);
				} else {
					for(WorkStatVO row : rows) {
						if(row.getSort().equals("201")){
							row.setYyyy(inputList.get(i).getYyyyMm().substring(0,4));
							row.setMm(inputList.get(i).getYyyyMm().substring(4));
							double value3 = Math.round(Double.parseDouble(row.getValue3())/1000000);
							double oldValue3 = Double.parseDouble(returnList.get(i).get(0).getValue3());
							returnList.get(i).get(0).setValue3(String.valueOf(oldValue3+value3)); 
						} else if(row.getSort().equals("202")){
							row.setYyyy(inputList.get(i).getYyyyMm().substring(0,4));
							row.setMm(inputList.get(i).getYyyyMm().substring(4));
							double value3 = Math.round(Double.parseDouble(row.getValue3())/1000000);
							double oldValue3 = Double.parseDouble(returnList.get(i).get(1).getValue3());
							returnList.get(i).get(1).setValue3(String.valueOf(oldValue3+value3));
						} 
					}
				}
				
			} 
			orgCnt++;
		}
		return returnList;
	}
	


}
