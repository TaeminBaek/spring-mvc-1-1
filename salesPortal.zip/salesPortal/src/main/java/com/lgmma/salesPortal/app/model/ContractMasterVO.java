package com.lgmma.salesPortal.app.model;

import java.util.List;

public class ContractMasterVO implements Cloneable {

	private String contractType;
	private String orderId;
	private String purchNoC;
	private String salesOrg;
	private String htmlSrc;
	private String today;
	private String nextWeek;
	private String nextMonth;
	private String todayKor;
	private String todayEng;
	private String validity;
	private String prodType;
	private String incoterms1;
	private String incoterms2;
	private String pmnttrms;
	private String pmnttrmsShort;
	private String shipmentTime;
	private String port;
	private String destination;
	private String insurence;
	private String packing;
	private String specialTerms;
	private String marking;
	private String contractName;
	private String contractAddr1;
	private String contractAddr2;
	private String contractAddr3;
	private String contractAddr4;
	private String mainBan1;
	private String mainBan2;
	private String mainBan3;
	private String mainBan4;
	private String mainBan5;
	private String telf1;
	private String bigoZ002;
	private String empTelNo;
	private String empTelNo2;
	private String faxNo;
	private String empMail;
	private List<ContractItemVO> items;

	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getPurchNoC() {
		return purchNoC;
	}
	public void setPurchNoC(String purchNoC) {
		this.purchNoC = purchNoC;
	}
	public String getHtmlSrc() {
		return htmlSrc;
	}
	public void setHtmlSrc(String htmlSrc) {
		this.htmlSrc = htmlSrc;
	}
	public String getProdType() {
		return prodType;
	}
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}
	public List<ContractItemVO> getItems() {
		return items;
	}
	public void setItems(List<ContractItemVO> items) {
		this.items = items;
	}
	public String getSalesOrg() {
		return salesOrg;
	}
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	public String getIncoterms1() {
		return incoterms1;
	}
	public void setIncoterms1(String incoterms1) {
		this.incoterms1 = incoterms1;
	}
	public String getIncoterms2() {
		return incoterms2;
	}
	public void setIncoterms2(String incoterms2) {
		this.incoterms2 = incoterms2;
	}
	public String getMarking() {
		return marking;
	}
	public void setMarking(String marking) {
		this.marking = marking;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getInsurence() {
		return insurence;
	}
	public void setInsurence(String insurence) {
		this.insurence = insurence;
	}
	public String getPacking() {
		return packing;
	}
	public void setPacking(String packing) {
		this.packing = packing;
	}
	public String getSpecialTerms() {
		return specialTerms;
	}
	public void setSpecialTerms(String specialTerms) {
		this.specialTerms = specialTerms;
	}
	public String getShipmentTime() {
		return shipmentTime;
	}
	public void setShipmentTime(String shipmentTime) {
		this.shipmentTime = shipmentTime;
	}
	public String getPmnttrms() {
		return pmnttrms;
	}
	public void setPmnttrms(String pmnttrms) {
		this.pmnttrms = pmnttrms;
	}
	public String getTodayKor() {
		return todayKor;
	}
	public void setTodayKor(String todayKor) {
		this.todayKor = todayKor;
	}
	public String getTodayEng() {
		return todayEng;
	}
	public void setTodayEng(String todayEng) {
		this.todayEng = todayEng;
	}
	public String getValidity() {
		return validity;
	}
	public void setValidity(String validity) {
		this.validity = validity;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getToday() {
		return today;
	}
	public void setToday(String today) {
		this.today = today;
	}
	public String getContractName() {
		return contractName;
	}
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}
	public String getContractAddr1() {
		return contractAddr1;
	}
	public void setContractAddr1(String contractAddr1) {
		this.contractAddr1 = contractAddr1;
	}
	public String getContractAddr2() {
		return contractAddr2;
	}
	public void setContractAddr2(String contractAddr2) {
		this.contractAddr2 = contractAddr2;
	}
	public String getContractAddr3() {
		return contractAddr3;
	}
	public void setContractAddr3(String contractAddr3) {
		this.contractAddr3 = contractAddr3;
	}
	public String getContractAddr4() {
		return contractAddr4;
	}
	public void setContractAddr4(String contractAddr4) {
		this.contractAddr4 = contractAddr4;
	}
	public String getTelf1() {
		return telf1;
	}
	public void setTelf1(String telf1) {
		this.telf1 = telf1;
	}
	public String getBigoZ002() {
		return bigoZ002;
	}
	public void setBigoZ002(String bigoZ002) {
		this.bigoZ002 = bigoZ002;
	}
	public String getEmpTelNo() {
		return empTelNo;
	}
	public void setEmpTelNo(String empTelNo) {
		this.empTelNo = empTelNo;
	}
	public String getFaxNo() {
		return faxNo;
	}
	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}
	public String getEmpMail() {
		return empMail;
	}
	public void setEmpMail(String empMail) {
		this.empMail = empMail;
	}
	public String getEmpTelNo2() {
		return empTelNo2;
	}
	public void setEmpTelNo2(String empTelNo2) {
		this.empTelNo2 = empTelNo2;
	}
	public String getPmnttrmsShort() {
		return pmnttrmsShort;
	}
	public void setPmnttrmsShort(String pmnttrmsShort) {
		this.pmnttrmsShort = pmnttrmsShort;
	}
	public String getMainBan1() {
		return mainBan1;
	}
	public void setMainBan1(String mainBan1) {
		this.mainBan1 = mainBan1;
	}
	public String getMainBan2() {
		return mainBan2;
	}
	public void setMainBan2(String mainBan2) {
		this.mainBan2 = mainBan2;
	}
	public String getMainBan3() {
		return mainBan3;
	}
	public void setMainBan3(String mainBan3) {
		this.mainBan3 = mainBan3;
	}
	public String getMainBan4() {
		return mainBan4;
	}
	public void setMainBan4(String mainBan4) {
		this.mainBan4 = mainBan4;
	}
	public String getMainBan5() {
		return mainBan5;
	}
	public void setMainBan5(String mainBan5) {
		this.mainBan5 = mainBan5;
	}
	public String getNextWeek() {
		return nextWeek;
	}
	public void setNextWeek(String nextWeek) {
		this.nextWeek = nextWeek;
	}
	public String getNextMonth() {
		return nextMonth;
	}
	public void setNextMonth(String nextMonth) {
		this.nextMonth = nextMonth;
	}
}
