package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissStepVO;

public interface CommonApprDao {

	List<ApprVO> getApprList(ApprVO param);

	ApprVO getAppr(ApprVO param);

	void updateAppr(ApprVO param);

	void createAppr(ApprVO param);

	void deleteAppr(ApprVO param);

	int getApprListCount(ApprVO param);

	List<ApprLineVO> getApprLineList(ApprLineVO param);

	ApprVO getApprLine(ApprLineVO param);

	void createApprLine(ApprLineVO param);

	void deleteApprLineAll(ApprVO param);

	void updateApprFromGPortal(ApprVO param);

	void updateApprLineFromGPortal(ApprLineVO param);

	void updateApprStatApprovalResult(ApprVO param);

	void updateApprLineStatApprovalResult(ApprLineVO param);

	void updateRelApprId(ApprVO param);

	void cancelAppr(ApprVO param);
	
	void cancelApprLine(ApprLineVO param);

	String apprAccessAuthCheck(ApprVO param);

	String checkApprApplyResult(ApprLineVO apprLineVO);
	
	int getDissMyApprListCount(ApprLineVO param);
	
	List<ApprLineVO> getDissMyApprList(ApprLineVO param);
	
	ApprLineVO getDissMyApprDetail(ApprLineVO param);
	
	int getDissMyApprReqListCount(ApprVO param);
	
	List<ApprVO> getDissMyApprReqList(ApprVO param);
	
	int getApplIncompleteCount(ApprVO param);

	DissStepVO loadDissApprDoc(DissStepVO param);

	public void updateApprLineYn(ApprVO param);
	
	DissStepVO getGportalDissStepByApprId(DissStepVO param);
}
