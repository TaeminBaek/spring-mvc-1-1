package com.lgmma.salesPortal.app.service;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.CollectAccountDetailVO;
import com.lgmma.salesPortal.app.model.CollectExpectedDateVO;
import com.lgmma.salesPortal.app.model.SalesPrepareIncreaseVO;
import com.lgmma.salesPortal.app.model.SalesContinuityDecreaseVO;
import com.lgmma.salesPortal.app.model.OperatingProfitContinuityDecreaseVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.CreditLimitRateVO;
import com.lgmma.salesPortal.app.model.CustBondOverdueInformationVO;
import com.lgmma.salesPortal.common.model.DDLBItem;

public interface SapSearchService {

	List<DDLBItem> getSapCommonCodeList(String zgubun);

	String getSapCommonCodeName(String zgubun, String code);

	Map getImportCorpCredit(String impNationCode, String impCorpCode);
	
	String getMasterCodeName(String codeNum2, String code);
	
	List<Map> getCompanySalesYearList(String kunnr, String vkorg, String fromYear, String toYear);
	
	List<Map> getCompanySalesMonthList(String kunnr, String vkorg, String fromYearMonth, String toYearMonth);

	List<Map> getCompanyBondList(String kunnr, String vkorg, String yyyyMM);
	
	List<Map> getPartSalesExpList(String ispmon, String ivkorg, String ikvgr3);
	
	List<Map> getPartSalesExpView(String ispmon, String ivkorg, String ikunnr, String ikvgr3);

	Map<String, String> getCompanyCredit(CompanyVO param);
	
	List<Map> getMonthPurchaseRecordList(String vkorg, String jproName, String compCode, String sdate, String edate);
	
	List<Map> getDayPurchaseRecordList(String vkorg, String jproName, String compCode, String sdate, String edate, String userType, String sawnCode);

	Map<String, String> getExpCompanyCredit(CompanyVO param);
	
	List<CollectAccountDetailVO> getCollectAccountDetailList(CollectAccountDetailVO param);
	
	List<CollectExpectedDateVO> getCollectExpectedDateList(CollectExpectedDateVO param);
	
	List<SalesPrepareIncreaseVO> getSalesPrepareIncreaseList(SalesPrepareIncreaseVO param);
	
	List<SalesContinuityDecreaseVO> getSalesContinuityDecreaseList(SalesContinuityDecreaseVO param);
	
	List<OperatingProfitContinuityDecreaseVO> getOperatingProfitContinuityDecreaseList(OperatingProfitContinuityDecreaseVO param);
	
	List<CreditLimitRateVO> getCreditLimitRateList (CreditLimitRateVO param);
	
	List<CustBondOverdueInformationVO> getCustBondOverdueInformationList (CustBondOverdueInformationVO param);
			
}
