package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissStepVO;

public interface DissStepDao {
	
	void createDissStep(DissStepVO param);
	
	List<DissStepVO> getDissStepRegiList(DissStepVO param);
	
	void deleteDissStepAll(DissStepVO param);

	void deleteDissStep(DissStepVO param);

	void updateStepLastYnYByStepCd(DissStepVO param);

	int getDissStepMaxDegreeNo(DissStepVO param);
	
	void updateDissStepLastYn(DissStepVO param);
	
	String getDissStepLastImpDevProposalStepId(DissStepVO param);
	
	List<DissStepVO> getDissStepRsltList(DissStepVO param);

	String getDissStepNextDegreeReason(DissStepVO param);

	DissStepVO getDissStepByApprId(DissStepVO dissStepVO);

	DissStepVO getDissStep(DissStepVO dissStepVO);

	List<DissStepVO> getDissStepIngList(DissStepVO dissStepVO);

	List<DissStepVO> getDissStepAll(DissStepVO dissStepVO);

	List<DissStepVO> getDissStepCompAppr(DissStepVO dissStepVO);
	
	String getDissStepReWriteRejectApprYn(DissStepVO param);
	
	DissStepVO getDissStepRsltInfo(DissStepVO dissStepVO);
	
	void updateDissStepRslt(DissStepVO param);

	void updateCheckDate(DissStepVO param);
}
