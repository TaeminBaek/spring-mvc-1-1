package com.lgmma.salesPortal.app.service;

import com.lgmma.salesPortal.app.model.DirectOrderMigVO;

public interface DirectOrderMigService {

	void createDirectOrderMig(DirectOrderMigVO param);

	void createDirectOrderMigTrans(DirectOrderMigVO param);
	
}
