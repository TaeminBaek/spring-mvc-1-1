package com.lgmma.salesPortal.app.dao;

import com.lgmma.salesPortal.app.model.DissFieldTestVO;

public interface DissFieldTestDao {
	
	DissFieldTestVO getDissFieldTestDetail(DissFieldTestVO param);
	
	void createDissFieldTest(DissFieldTestVO param);
	
	void updateDissFieldTest(DissFieldTestVO param);
	
	void deleteDissFieldTestAll(DissFieldTestVO param);
	

}
