package com.lgmma.salesPortal.app.model;

import java.util.Comparator;

public class CompFileListVO extends PagingParamVO{

	private String zgubun; 
	private String kunnr; // 업체코드
	private String vkorg; // 영업조직
	private String vtweg; // 유통채널
	private String kvgr5; // 업종
	private String iClass; // 업종명
	private String pknam; // 고객명
	private String pkunag; // 고객코드
	
	private String fromMonth; //검색기간-시작월
	private String toMonth; //검색기간-종료월
	

	private String umnetwr; // 매출금액
	private String ummenge; // 매출수량
	private String zzfield1; // 매출총이익
	private String zzfield2; // 이익율
	
	private String kvgr3;

	private Integer rowCount;
	
	private String orderBy;
	
	/*sorting*/
	public static Comparator<CompFileListVO> sortFDESC = new Comparator<CompFileListVO>() {
		
		@Override
		public int compare(CompFileListVO o1, CompFileListVO o2) {
			double data1 =  Double.parseDouble(o1.getZzfield1());
			double data2 = Double.parseDouble(o2.getZzfield1());
			return Double.compare(data2, data1);
		}
	};
	
	/*sorting*/
	public static Comparator<CompFileListVO> sortMDESC = new Comparator<CompFileListVO>() {
		
		@Override
		public int compare(CompFileListVO o1, CompFileListVO o2) {
			double data1 =  Double.parseDouble(o1.getUmmenge());
			double data2 = Double.parseDouble(o2.getUmmenge());
			return Double.compare(data2, data1);
		}
	};	
	/*sorting*/
	public static Comparator<CompFileListVO> sortWDESC = new Comparator<CompFileListVO>() {
		
		@Override
		public int compare(CompFileListVO o1, CompFileListVO o2) {
			double data1 =  Double.parseDouble(o1.getUmnetwr());
			double data2 = Double.parseDouble(o2.getUmnetwr());
			return Double.compare(data2, data1);
		}
	};
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getVtweg() {
		return vtweg;
	}
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}

	public String getPknam() {
		return pknam;
	}
	public void setPknam(String pknam) {
		this.pknam = pknam;
	}
	public String getPkunag() {
		return pkunag;
	}
	public void setPkunag(String pkunag) {
		this.pkunag = pkunag;
	}
	public String getUmnetwr() {
		return umnetwr;
	}
	public void setUmnetwr(String umnetwr) {
		this.umnetwr = umnetwr;
	}
	public String getUmmenge() {
		return ummenge;
	}
	public void setUmmenge(String ummenge) {
		this.ummenge = ummenge;
	}
	public String getZzfield1() {
		return zzfield1;
	}
	public void setZzfield1(String zzfield1) {
		this.zzfield1 = zzfield1;
	}
	public String getZzfield2() {
		return zzfield2;
	}
	public void setZzfield2(String zzfield2) {
		this.zzfield2 = zzfield2;
	}
	public String getiClass() {
		return iClass;
	}
	public void setiClass(String iClass) {
		this.iClass = iClass;
	}
	public String getKvgr5() {
		return kvgr5;
	}
	public void setKvgr5(String kvgr5) {
		this.kvgr5 = kvgr5;
	}
	public String getKvgr3() {
		return kvgr3;
	}
	public void setKvgr3(String kvgr3) {
		this.kvgr3 = kvgr3;
	}
	public String getZgubun() {
		return zgubun;
	}
	public void setZgubun(String zgubun) {
		this.zgubun = zgubun;
	}
	public Integer getRowCount() {
		return rowCount;
	}
	public void setRowCount(Integer rowCount) {
		this.rowCount = rowCount;
	}
	public String getFromMonth() {
		return fromMonth;
	}
	public void setFromMonth(String fromMonth) {
		this.fromMonth = fromMonth;
	}
	public String getToMonth() {
		return toMonth;
	}
	public void setToMonth(String toMonth) {
		this.toMonth = toMonth;
	}
	public String getOrderBy() {
		return orderBy;
	}
	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}
	
}
