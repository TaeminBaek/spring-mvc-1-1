package com.lgmma.salesPortal.app.model;

public class ContractItemVO implements Cloneable {

	private String orderId;
	private int seq;
	private String itemNo;
	private String materialName;
	private String fullName;
	private String upperFullName;
	private String shortName;
	private String purity;
	private String hsCode;
	private String unNumber;
	private int reqQty;
	private float pr00Price;
	private String currency;
	private String plant;
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getMaterialName() {
		return materialName;
	}
	public void setMaterialName(String materialName) {
		this.materialName = materialName;
	}
	public int getReqQty() {
		return reqQty;
	}
	public void setReqQty(int reqQty) {
		this.reqQty = reqQty;
	}
	public float getPr00Price() {
		return pr00Price;
	}
	public void setPr00Price(float pr00Price) {
		this.pr00Price = pr00Price;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getItemNo() {
		return itemNo;
	}
	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPurity() {
		return purity;
	}
	public void setPurity(String purity) {
		this.purity = purity;
	}
	public String getHsCode() {
		return hsCode;
	}
	public void setHsCode(String hsCode) {
		this.hsCode = hsCode;
	}
	public String getUnNumber() {
		return unNumber;
	}
	public void setUnNumber(String unNumber) {
		this.unNumber = unNumber;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getUpperFullName() {
		return upperFullName;
	}
	public void setUpperFullName(String upperFullName) {
		this.upperFullName = upperFullName;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
}
