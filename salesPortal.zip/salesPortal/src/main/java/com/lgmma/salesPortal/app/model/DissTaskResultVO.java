package com.lgmma.salesPortal.app.model;

import java.util.List;

public class DissTaskResultVO extends PagingParamVO {
	
	//TB_D_TASKRESULT
	private String stepId;				// 과제스텝ID
	private int    degreeNo;            // 차수
	private String stdCd;               // 규격
	private String stdChgYn;            // 규격변경여부
	private String curGrade;            // 기존GRADE
	private String newGrade;            // 신규GRADE
	private int    prodQty;             // 생산량
	private String prodPurpose;         // 생산목적
	private String sampleCompYmd;       // 샘플생산완료희망일
	private String recipeEmpId;         // 처방개발자
	private String visitYn;             // 참관여부
	private String exhaustPlan;         // 샘플소진계획
	private int    exhaustContRate;     // 소진함량(%)
	private String exhaustObjGrade;     // 소진대상GRADE
	private String saleEmpId;           // 담당영업사원
	private String reqPlant;            // 요청플랜트
	//조회 및 수정
	private String recipeEmpNm;         // 처방개발자명
	private String recipeEmpTeamName;   // 처방개발자팀코드명
	private String recipeEmpPosiName;   // 처방개발자직위코드명
	//개발결과 담당영업사원
	private String saleEmpNm;           // 담당영업사원명
	private String saleEmpTeamName;     // 담당영업사원팀코드명
	private String saleEmpPosiName;     // 담당영업사원직위코드명 
	//코드명
	private String stdChgYnNm;          // 규격변경여부명
	private String reqPlantNm;          // 요청플랜트명
	
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public int getDegreeNo() {
		return degreeNo;
	}
	public void setDegreeNo(int degreeNo) {
		this.degreeNo = degreeNo;
	}
	public String getStdCd() {
		return stdCd;
	}
	public void setStdCd(String stdCd) {
		this.stdCd = stdCd;
	}
	public String getStdChgYn() {
		return stdChgYn;
	}
	public void setStdChgYn(String stdChgYn) {
		this.stdChgYn = stdChgYn;
	}
	public String getCurGrade() {
		return curGrade;
	}
	public void setCurGrade(String curGrade) {
		this.curGrade = curGrade;
	}
	public String getNewGrade() {
		return newGrade;
	}
	public void setNewGrade(String newGrade) {
		this.newGrade = newGrade;
	}
	public int getProdQty() {
		return prodQty;
	}
	public void setProdQty(int prodQty) {
		this.prodQty = prodQty;
	}
	public String getProdPurpose() {
		return prodPurpose;
	}
	public void setProdPurpose(String prodPurpose) {
		this.prodPurpose = prodPurpose;
	}
	public String getSampleCompYmd() {
		return sampleCompYmd;
	}
	public void setSampleCompYmd(String sampleCompYmd) {
		this.sampleCompYmd = sampleCompYmd;
	}
	public String getRecipeEmpId() {
		return recipeEmpId;
	}
	public void setRecipeEmpId(String recipeEmpId) {
		this.recipeEmpId = recipeEmpId;
	}
	public String getVisitYn() {
		return visitYn;
	}
	public void setVisitYn(String visitYn) {
		this.visitYn = visitYn;
	}
	public String getExhaustPlan() {
		return exhaustPlan;
	}
	public void setExhaustPlan(String exhaustPlan) {
		this.exhaustPlan = exhaustPlan;
	}
	public int getExhaustContRate() {
		return exhaustContRate;
	}
	public void setExhaustContRate(int exhaustContRate) {
		this.exhaustContRate = exhaustContRate;
	}
	public String getExhaustObjGrade() {
		return exhaustObjGrade;
	}
	public void setExhaustObjGrade(String exhaustObjGrade) {
		this.exhaustObjGrade = exhaustObjGrade;
	}
	public String getSaleEmpId() {
		return saleEmpId;
	}
	public void setSaleEmpId(String saleEmpId) {
		this.saleEmpId = saleEmpId;
	}
	public String getReqPlant() {
		return reqPlant;
	}
	public void setReqPlant(String reqPlant) {
		this.reqPlant = reqPlant;
	}
	public String getRecipeEmpNm() {
		return recipeEmpNm;
	}
	public void setRecipeEmpNm(String recipeEmpNm) {
		this.recipeEmpNm = recipeEmpNm;
	}
	public String getRecipeEmpTeamName() {
		return recipeEmpTeamName;
	}
	public void setRecipeEmpTeamName(String recipeEmpTeamName) {
		this.recipeEmpTeamName = recipeEmpTeamName;
	}
	public String getRecipeEmpPosiName() {
		return recipeEmpPosiName;
	}
	public void setRecipeEmpPosiName(String recipeEmpPosiName) {
		this.recipeEmpPosiName = recipeEmpPosiName;
	}
	public String getSaleEmpNm() {
		return saleEmpNm;
	}
	public void setSaleEmpNm(String saleEmpNm) {
		this.saleEmpNm = saleEmpNm;
	}
	public String getSaleEmpTeamName() {
		return saleEmpTeamName;
	}
	public void setSaleEmpTeamName(String saleEmpTeamName) {
		this.saleEmpTeamName = saleEmpTeamName;
	}
	public String getSaleEmpPosiName() {
		return saleEmpPosiName;
	}
	public void setSaleEmpPosiName(String saleEmpPosiName) {
		this.saleEmpPosiName = saleEmpPosiName;
	}
	public String getStdChgYnNm() {
		return stdChgYnNm;
	}
	public void setStdChgYnNm(String stdChgYnNm) {
		this.stdChgYnNm = stdChgYnNm;
	}
	public String getReqPlantNm() {
		return reqPlantNm;
	}
	public void setReqPlantNm(String reqPlantNm) {
		this.reqPlantNm = reqPlantNm;
	}
	
}
