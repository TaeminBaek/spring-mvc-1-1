package com.lgmma.salesPortal.app.service;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.WorkStatVO;

public interface WorkStatMgmtService {
	
	List<WorkStatVO> getworkStatList(WorkStatVO param);
	
	List<WorkStatVO> getworkStatView(WorkStatVO param);
	
	List<List<WorkStatVO>> getMonthlySalesStatList(WorkStatVO param);

	Map<String, List<WorkStatVO>> getNetProfitList(WorkStatVO param);
	
	Double[] sortDataAndGetTicks(String targetData, List<WorkStatVO> list);
}
