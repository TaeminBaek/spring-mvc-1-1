package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.VocVO;
import com.lgmma.salesPortal.app.model.VocGradeVO;
import com.lgmma.salesPortal.app.model.VocActVO;
import com.lgmma.salesPortal.app.model.VocTypeVO;
import com.lgmma.salesPortal.app.model.VocActPopVO;
import com.lgmma.salesPortal.app.model.VocSendMailToEmpVO;
import com.lgmma.salesPortal.app.model.VocSendMailToCustVO;


public interface VocDao {
	
	int getVocListCount(VocVO param);
	
	List<VocVO> getVocList(VocVO param);
	
	VocVO getVocDetail(VocVO param);
	
	void createVoc(VocVO param);
	
	void createVocGrade(VocGradeVO param);	
	
	void updateVoc(VocVO param);
	
	void deleteVocGrade(VocVO param);
	
	void deleteVocType(VocVO param);
	
	void deleteVoc(VocVO param);
	
	void deleteVocAct(VocVO param);
	
	List<VocGradeVO> getVocGradeList(VocVO param);
	
	List<VocActVO> getVocActList(VocVO param);	
	
	void createVocAct(VocVO param);
	
	void createVocType(VocTypeVO param);
	
	List<VocTypeVO> getVocTypeList(VocVO param);
	
	VocActPopVO getVocActPop(VocActVO param);
	
	VocActPopVO getPersonFind(VocActVO param);	
	
	VocActPopVO getActivityName(VocActPopVO param);
	
	void updateVocActPop(VocActPopVO param);
	
	void updateVocActPopStat(VocActPopVO param);
	
	void createVocActPop(VocActPopVO param);
	
	VocVO getVocIdxx(VocActVO param);
	
	VocActVO getVocCustActInputHis(VocVO param);
	
	VocActVO getVocCustActAnswerHis(VocVO param);
	
	void updateVocActApprVoc(VocActPopVO param);
	
	void insertVocActApprVocAct(VocActPopVO param);
	
	VocSendMailToEmpVO getVocSendMailToEmp(VocVO param);
	
	VocSendMailToEmpVO getVocSendMailToEmpInfo(VocActPopVO param);
	
	List<VocSendMailToEmpVO> getVocSendMailToEmpInList(VocActPopVO param);
	
	VocSendMailToCustVO getVocSendMailToCustOut(VocActPopVO param);
	
	VocSendMailToEmpVO getVocSendMailToEmpInfoAppr(VocActPopVO param);
	
	List<VocSendMailToEmpVO> getVocSendMailToEmpInApprList(VocActPopVO param);	
}
