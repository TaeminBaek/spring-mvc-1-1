package com.lgmma.salesPortal.app.dao;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.CompCreditVO;
import com.lgmma.salesPortal.app.model.CompDamboVO;
import com.lgmma.salesPortal.app.model.CompEtcSaleYearVO;
import com.lgmma.salesPortal.app.model.CompOrganEditVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.NewCompOrganEditVO;
import com.lgmma.salesPortal.app.model.OrganVO;
import com.lgmma.salesPortal.app.model.GenVocVO;

public interface CompanyDao {

	public List<String> getKunnr(String param);

	public int getCompanyCount(CompanyVO param);

	public List<CompanyVO> getCompanyList(CompanyVO param);

	public CompanyVO getCompanyDetail(CompanyVO param);

	public void updateCompany(CompanyVO param);
	
	public OrganVO getCompanyEtc(OrganVO param);
	
	public List<CompEtcSaleYearVO> getCompanyEtcSaleYearList(OrganVO param);
	
	public int getCompanyEtcKunnrCount(OrganVO param);
	
	public void updateEtc(OrganVO param);
	
	public void createEtcAddOrg(OrganVO param);
	
	public void deleteEtcSaleYear(OrganVO param);
	
	public void createEtcSaleYear(CompEtcSaleYearVO param);
	
	public int getDamboCount(CompDamboVO param);

	public List<CompDamboVO> getDamboList(CompDamboVO param);
	
	public void updateDambo(CompDamboVO param);
	
	public void createDambo(CompDamboVO param);
	
	public List<CompDamboVO> getConfirmDamboList(CompDamboVO param);
	
	public void createDamboHistory(CompDamboVO param);
	
	public int getCreditCount(CompCreditVO param);

	public List<CompCreditVO> getCreditList(CompCreditVO param);
	
	public int getSampleDocCount(GenVocVO param);

	public List<GenVocVO> getSampleDocList(GenVocVO param);

	public void createCredit(CompCreditVO param);

	public void updateCreditApprId(CompCreditVO param);

	public void updateCreditApprIdToNull(CompCreditVO param);

	public CompCreditVO getCreditDetail(CompCreditVO param);

	public void updateCreditErpStat(CompCreditVO vo);

	public Long getAddAmntSum(CompanyVO param);

	public void updateCredit(CompCreditVO param);

	public void createCompOrganEdit(CompOrganEditVO param);

	public void updateOrgan(OrganVO organVO);

	public void updateCompOrgEditApprId(CompOrganEditVO param);

	public void updateCompOrgEditIdToNull(CompOrganEditVO param);

	public NewCompOrganEditVO getCompOrganEditDetail(CompOrganEditVO param);

	public List<NewCompOrganEditVO> getCompOrganEditList(CompOrganEditVO param);

	public int countOtherOrganExists(Map<String, String> paramMap);

	public void updateCompEditErpStat(CompOrganEditVO param);

	public void deleteCompOrganEdit(CompOrganEditVO param);

	public void createNewCompOrganEdit(NewCompOrganEditVO param);
	
	public String getName1ByCompCode(String compCode);

	public String getCompanyCreditGrade(String stcd2);
	
	int getDamboItemListCount(CompDamboVO param);
}
