package com.lgmma.salesPortal.app.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.model.SalePriceCloseVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;
import com.lgmma.salesPortal.app.service.DiagnosisService;

@Service
public class DiagnosisServiceImpl implements DiagnosisService{

	private static Logger logger = LoggerFactory.getLogger(DiagnosisServiceImpl.class); 

	@Override
	public List<SalePriceMasterVO> getSalePriceChangeRateList(SalePriceCloseVO param) {
		return null;
	}
}
