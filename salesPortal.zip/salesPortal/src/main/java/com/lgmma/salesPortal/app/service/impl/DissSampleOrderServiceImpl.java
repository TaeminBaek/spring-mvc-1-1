package com.lgmma.salesPortal.app.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.lgmma.salesPortal.app.dao.CommonApprDao;
import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.dao.DissImpDevDao;
import com.lgmma.salesPortal.app.dao.DissSampleOrderDao;
import com.lgmma.salesPortal.app.dao.DissScheduleDao;
import com.lgmma.salesPortal.app.dao.DissStepDao;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissImpDevVO;
import com.lgmma.salesPortal.app.model.DissSampleOrderItemVO;
import com.lgmma.salesPortal.app.model.DissSampleOrderMasterVO;
import com.lgmma.salesPortal.app.model.DissScheduleVO;
import com.lgmma.salesPortal.app.model.DissSpecInSaleGoalVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.model.SmsVO;
import com.lgmma.salesPortal.app.service.CommonApprMgmtService;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.app.service.DirectOrderService;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.DissSampleOrderService;
import com.lgmma.salesPortal.app.service.DissSpecInService;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.SmsService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.common.props.ApplState;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.CommissionType;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.props.OrderStatus;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.props.SalePriceMasterPriceListType;
import com.lgmma.salesPortal.common.props.SalePriceMasterUnitType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

import freemarker.template.Configuration;

@Service
public class DissSampleOrderServiceImpl implements DissSampleOrderService {

	private static Logger logger = LoggerFactory.getLogger(DissSampleOrderServiceImpl.class);
	private final String FNC_SAP_ORDER_LIST = "ZSDE02_DISPLAY_ORDER_STATUS";
	private final String REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER = "REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER";

	@Autowired
	private JcoConnector jcoConnector;

	@Autowired
	private DissSpecInService dissSpecInService;

	@Autowired
	private SapSearchServiceImpl sapSearchService;

	@Autowired
	private CommonApprMgmtService commonApprMgmtService;

	@Autowired
	private DissCommonApprMgmtService dissCommonApprMgmtService;

	@Autowired
	private DissSampleOrderDao dissSampleOrderDao;

	@Autowired
	private DissStepDao dissStepDao;

	@Autowired
	private DissImpDevDao dissImpDevDao;

	@Autowired
	private DirectOrderService directOrderService;
	
	@Autowired
	private CommonFileService commonFileService;

	@Autowired
	private DissScheduleDao dissScheduleDao;

	@Autowired
	private CommonApprDao commonApprDao;

	@Autowired
	private CompanyDao companyDao;

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;

	@Autowired
	private MailingService mailingService;

	@Autowired
	private SmsService smsService;
	
	@Autowired
    @Qualifier(value="reportFreemarkerConfiguration")
    private Configuration reportTemplateConfiguration;

	/**
	 * 과제 구분에 따른 견본오더 기본 체크 정보 및 디폴트정보 구하기
	 *
	 * @param dissSampleOrderMasterVO
	 * @return DissSampleOrderParamVO
	 */
	@Override
	public DissSampleOrderMasterVO getSampleOrderTaskBasicInfo(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		dissSampleOrderMasterVO = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(dissSampleOrderMasterVO);
		if ("SPECIN".equals(dissSampleOrderMasterVO.getTaskType())) {
			return getTaskBasicSpecInInfo(dissSampleOrderMasterVO);
		} else if ("IMPDEV".equals(dissSampleOrderMasterVO.getTaskType())) {
			return getTaskBasicImpDevInfo(dissSampleOrderMasterVO);
		} else {
			throw new ServiceException("", "과제구분 정보가 잘못되었습니다.");
		}
	}

	/**
	 * 스펙인 견본오더 기본 체크 정보 및 디폴트정보 구하기
	 *
	 * @param dissSampleOrderMasterVO
	 * @return DissSampleOrderParamVO
	 */
	private DissSampleOrderMasterVO getTaskBasicSpecInInfo(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		// Diss 기본정보 조회
		DissSpecInVO dissSpecInVOParam = new DissSpecInVO();
		dissSpecInVOParam.setTaskId(dissSampleOrderMasterVO.getTaskId());
		DissSpecInVO dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInInfo(dissSpecInVOParam));

		if (!("".equals(dissSpecInVO.getCustIndoCode()) && "".equals(dissSpecInVO.getCustErpCode()))) {
			// 디폴트 데이타 셋팅
			dissSampleOrderMasterVO.setDissCustCode(dissSpecInVO.getCustCode());         // DISS고객 코드
			dissSampleOrderMasterVO.setDissCustName(dissSpecInVO.getCustName());        //  DISS고객명

			dissSampleOrderMasterVO.setCustErpCode(dissSpecInVO.getCustErpCode());       // DISS 고객ERP코드
			dissSampleOrderMasterVO.setCustIndoCode(dissSpecInVO.getCustIndoCode());     // DISS 고객인도처코드

			if (!"".equals(dissSpecInVO.getCustErpCode())) { // 거래선 등록 고객이면 판매처,인도처 모두 셋팅
				dissSampleOrderMasterVO.setDissCustErpCode(dissSpecInVO.getCustErpCode());
				// 판매처
				dissSampleOrderMasterVO.setCompCode(dissSpecInVO.getCustCode());
				dissSampleOrderMasterVO.setPartnNumbAg(dissSpecInVO.getCustErpCode());
				dissSampleOrderMasterVO.setPartnNameAg(dissSpecInVO.getCustName());
				// 인도처
				dissSampleOrderMasterVO.setPartnNumbWe(dissSpecInVO.getCustErpCode());
				dissSampleOrderMasterVO.setPartnNameWe(dissSpecInVO.getCustName());
				// 담당영업사원
				dissSampleOrderMasterVO.setPartnNumbVe(dissSpecInVO.getCustSalesEmpId());
				dissSampleOrderMasterVO.setPartnNameVe(dissSpecInVO.getCustSalesEmpNm());
				// 고객통화
				dissSampleOrderMasterVO.setCurrency(dissSpecInVO.getCustCurrency());
			} else {  // 인도처만 등록 고객이면 인도처만
				dissSampleOrderMasterVO.setPartnNumbWe(dissSpecInVO.getCustIndoCode());
				dissSampleOrderMasterVO.setPartnNameWe(dissSpecInVO.getCustName());
			}

			dissSampleOrderMasterVO.setDivision(dissSpecInVO.getProdType());             // 제품군
			dissSampleOrderMasterVO.setSalesOrg((dissSpecInVO.getProdType().isEmpty()) ? "" : dissSpecInVO.getProdType() + "00"); // 제품군에 따른 영업조직
			dissSampleOrderMasterVO.setTaskName(dissSpecInVO.getTaskName());             // 과제명
			dissSampleOrderMasterVO.setDegreeNo(dissSpecInVO.getDegreeNo());             // 차수
			dissSampleOrderMasterVO.setOrdReason("003"); // 견본기타 기본으로
			dissSampleOrderMasterVO.setReqDateH(DateUtil.formatDate(DateUtil.getToday(), ".")); // 출하요청일 오늘날짜 디폴트

			// TS 추천 Grade 를 디폴트로
			if (!dissSpecInVO.getTsGrade().isEmpty()) {
				List<DissSampleOrderItemVO> itemList = new ArrayList<>();
				DissSampleOrderItemVO tmpItem = new DissSampleOrderItemVO();
				tmpItem.setMaterial(dissSpecInVO.getTsGrade());
				itemList.add((DissSampleOrderItemVO) StringUtil.nullToEmptyString(tmpItem));
				dissSampleOrderMasterVO.setDissSampleOrderItemList(itemList);
			}
			dissSampleOrderMasterVO = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(dissSampleOrderMasterVO);
			// 코드 명칭 셋팅
			setDissSampleOrderDetailCodeText(dissSampleOrderMasterVO);
		}

		return dissSampleOrderMasterVO;
	}

	/**
	 * 개선개발 견본오더 기본 체크 정보 및 디폴트정보 구하기
	 *
	 * @param dissSampleOrderMasterVO
	 * @return DissSampleOrderMasterVO
	 */
	private DissSampleOrderMasterVO getTaskBasicImpDevInfo(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		DissImpDevVO dissImpDevVOParam = new DissImpDevVO();
		dissImpDevVOParam.setTaskId(dissSampleOrderMasterVO.getTaskId());
		DissImpDevVO dissImpDevVO = dissImpDevDao.getDissImpDevDetail(dissImpDevVOParam);

		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setTaskId(dissSampleOrderMasterVO.getTaskId());
		int degreeNo = dissStepDao.getDissStepMaxDegreeNo(dissStepVO);

		dissSampleOrderMasterVO.setTaskId(dissImpDevVO.getTaskId());
		dissSampleOrderMasterVO.setDivision(dissImpDevVO.getProdType());             // 제품군
		dissSampleOrderMasterVO.setSalesOrg((dissImpDevVO.getProdType().isEmpty()) ? "" : dissImpDevVO.getProdType() + "00"); // 제품군에 따른 영업조직
		dissSampleOrderMasterVO.setTaskName(dissImpDevVO.getTaskName());             // 과제명
		dissSampleOrderMasterVO.setDegreeNo(degreeNo);             // 차수
		dissSampleOrderMasterVO.setOrdReason("003"); // 견본기타 기본으로
		dissSampleOrderMasterVO.setReqDateH(DateUtil.formatDate(DateUtil.getToday(), ".")); // 출하요청일 오늘날짜 디폴트

		dissSampleOrderMasterVO = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(dissSampleOrderMasterVO);
		// 코드 명칭 셋팅
		setDissSampleOrderDetailCodeText(dissSampleOrderMasterVO);

		return dissSampleOrderMasterVO;
	}

	/**
	 * 견본조회
	 *
	 * @param dissSampleOrderMasterVO
	 * @return DissSampleOrderMasterVO
	 */
	@Override
	public DissSampleOrderMasterVO searchSampleOrderInfo(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		// 견본조회를 위한 파라미터 구하기(step에 조회를 위한 기본정보가 모두 존재)
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO.setStepId(dissSampleOrderMasterVO.getStepId());
		dissStepVO = (DissStepVO) StringUtil.nullToEmptyString(dissStepDao.getDissStep(dissStepVO));

		// 견본 마스터 정보 조회
		dissSampleOrderMasterVO = dissSampleOrderDao.getDissSampleOrderMaster(dissStepVO.getOrderId());
		// 견본 제품리스트 정보 조회
		dissSampleOrderMasterVO.setDissSampleOrderItemList(dissSampleOrderDao.getDissSampleOrderItemList(dissStepVO.getOrderId()));

		dissSampleOrderMasterVO = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(dissSampleOrderMasterVO);

		setDissSampleOrderDetailCodeText(dissSampleOrderMasterVO);

		return dissSampleOrderMasterVO;
	}

	/**
	 * 견본정보의 ERP코드명 맵핑
	 *
	 * @param dissSampleOrderMasterVO
	 */
	@Override
	public void setDissSampleOrderDetailCodeText(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		if (!dissSampleOrderMasterVO.getSalesOrg().equals(""))
			dissSampleOrderMasterVO.setSalesOrgText("[" + dissSampleOrderMasterVO.getSalesOrg() + "]" + Vkorg.getVkorg(dissSampleOrderMasterVO.getSalesOrg()).getName());
		if (!dissSampleOrderMasterVO.getDistrChan().equals(""))
			dissSampleOrderMasterVO.setDistrChanText("[" + dissSampleOrderMasterVO.getDistrChan() + "]" + sapSearchService.getMasterCodeName("24", dissSampleOrderMasterVO.getDistrChan()));
		if (!dissSampleOrderMasterVO.getDivision().equals(""))
			dissSampleOrderMasterVO.setDivisionText("[" + dissSampleOrderMasterVO.getDivision() + "]" + sapSearchService.getMasterCodeName("05", dissSampleOrderMasterVO.getDivision()));
		if (!dissSampleOrderMasterVO.getPmnttrms().equals(""))
			dissSampleOrderMasterVO.setPmnttrmsText("[" + dissSampleOrderMasterVO.getPmnttrms() + "]" + sapSearchService.getMasterCodeName("28", dissSampleOrderMasterVO.getPmnttrms()));
		if (!dissSampleOrderMasterVO.getIncoterms1().equals(""))
			dissSampleOrderMasterVO.setIncoterms1Text("[" + dissSampleOrderMasterVO.getIncoterms1() + "]" + sapSearchService.getMasterCodeName("30", dissSampleOrderMasterVO.getIncoterms1()));
		if (!dissSampleOrderMasterVO.getShipCond().equals(""))
			dissSampleOrderMasterVO.setShipCondText("[" + dissSampleOrderMasterVO.getShipCond() + "]" + sapSearchService.getMasterCodeName("23", dissSampleOrderMasterVO.getShipCond()));
		if (!dissSampleOrderMasterVO.getOrdReason().equals(""))
			dissSampleOrderMasterVO.setOrdReasonText("[" + dissSampleOrderMasterVO.getOrdReason() + "]" + sapSearchService.getMasterCodeName("22", dissSampleOrderMasterVO.getOrdReason()));
		if (!dissSampleOrderMasterVO.getPartnNumbZ6().equals(""))
			dissSampleOrderMasterVO.setPartnNameZ6("[" + dissSampleOrderMasterVO.getPartnNumbZ6() + "]" + sapSearchService.getMasterCodeName("36", dissSampleOrderMasterVO.getPartnNumbZ6()));
		if (!dissSampleOrderMasterVO.getPartnNumbZ4().equals(""))
			dissSampleOrderMasterVO.setPartnNameZ4("[" + dissSampleOrderMasterVO.getPartnNumbZ4() + "]" + sapSearchService.getMasterCodeName("35", dissSampleOrderMasterVO.getPartnNumbZ4()));
		if (!dissSampleOrderMasterVO.getAccntAsgn().equals(""))
			dissSampleOrderMasterVO.setAccntAsgnText("[" + dissSampleOrderMasterVO.getAccntAsgn() + "]" + sapSearchService.getMasterCodeName("08", dissSampleOrderMasterVO.getAccntAsgn()));
		if (!dissSampleOrderMasterVO.getZzroute().equals(""))
			dissSampleOrderMasterVO.setZzrouteText("[" + dissSampleOrderMasterVO.getZzroute() + "]" + sapSearchService.getMasterCodeName("31", dissSampleOrderMasterVO.getZzroute()));
		if (!dissSampleOrderMasterVO.getZland1().equals(""))
			dissSampleOrderMasterVO.setZland1Text("[" + dissSampleOrderMasterVO.getZland1() + "]" + sapSearchService.getMasterCodeName("37", dissSampleOrderMasterVO.getZland1()));
		if (!dissSampleOrderMasterVO.getZztrnsWay1().equals(""))
			dissSampleOrderMasterVO.setZztrnsWay1Text("[" + dissSampleOrderMasterVO.getZztrnsWay1() + "]" + sapSearchService.getMasterCodeName("33", dissSampleOrderMasterVO.getZztrnsWay1()));
		if (!dissSampleOrderMasterVO.getZztrnsWay2().equals(""))
			dissSampleOrderMasterVO.setZztrnsWay2Text("[" + dissSampleOrderMasterVO.getZztrnsWay2() + "]" + sapSearchService.getMasterCodeName("33", dissSampleOrderMasterVO.getZztrnsWay2()));
		if (!dissSampleOrderMasterVO.getUnloadPt().equals(""))
			dissSampleOrderMasterVO.setUnloadPtText("[" + dissSampleOrderMasterVO.getUnloadPt() + "]" + sapSearchService.getMasterCodeName("15", dissSampleOrderMasterVO.getUnloadPt()));
		if (!dissSampleOrderMasterVO.getCondType().equals(""))
			dissSampleOrderMasterVO.setCondTypeText("[" + dissSampleOrderMasterVO.getCondType() + "]" + (CommissionType.getCommission(dissSampleOrderMasterVO.getCondType()) == null ? "" : CommissionType.getCommission(dissSampleOrderMasterVO.getCondType()).getText()));

		// 견본에서 orderItemList 없이 조회
		if (dissSampleOrderMasterVO.getDissSampleOrderItemList() != null) {
			for (DissSampleOrderItemVO orderItemVO : dissSampleOrderMasterVO.getDissSampleOrderItemList()) {
				if (!dissSampleOrderMasterVO.getPriceList().equals(""))
					orderItemVO.setPltypName(SalePriceMasterPriceListType.getSalePriceMasterPriceListType(dissSampleOrderMasterVO.getPriceList()).getName());
				if (!StringUtil.isNullToString(orderItemVO.getCondUnit()).equals(""))
					orderItemVO.setCondUnitText(SalePriceMasterUnitType.getSalePriceMasterUnitType(orderItemVO.getCondUnit()).getName());
				if (!StringUtil.isNullToString(orderItemVO.getPlant()).equals(""))
					orderItemVO.setPlantText("[" + orderItemVO.getPlant() + "]" + sapSearchService.getMasterCodeName("04", orderItemVO.getPlant()));
				if (!StringUtil.isNullToString(orderItemVO.getStoreLoc()).equals(""))
					orderItemVO.setStoreLocText("[" + orderItemVO.getStoreLoc() + "]" + sapSearchService.getMasterCodeName("15", orderItemVO.getStoreLoc()));
			}
		}
	}

	/**
	 * DISS 견본품의 결재 처리
	 *
	 * @param dissApprCommonParamVO
	 */
	@Override
	@Transactional
	public void applDissSampleOrder(DissApprCommonParamVO dissApprCommonParamVO) {
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setApprId(dissApprCommonParamVO.getApprId());                     // 품의서ID
		apprLineVO.setApprEmpId(dissApprCommonParamVO.getApprEmpId());              // 결재자사번
		apprLineVO.setApprLineComment(dissApprCommonParamVO.getApprLineComment());  // 결재자의견
		apprLineVO.setApplStat(dissApprCommonParamVO.getApplStat());                 // 결재자 결재결과
		apprLineVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());

		// DISS 공통 품의서 결재 호출
		dissCommonApprMgmtService.approvalDissCommonAppr(apprLineVO);

		if("A".equals(dissApprCommonParamVO.getApplStat())) {
			DissScheduleVO dissScheduleVO = new DissScheduleVO();
			dissScheduleVO.setCompYmd(DateUtil.getToday());
			dissScheduleVO.setRegiIdxx(dissApprCommonParamVO.getRegiIdxx());
			dissScheduleVO.setTaskId(dissApprCommonParamVO.getTaskId());
			dissScheduleVO.setStepGroup("400");
			dissScheduleDao.updateDissScheduleCompYmd(dissScheduleVO);
		}
	}

	@Override
	public void saveDissSampleOrderAfterApproval(DissApprCommonParamVO dissApprCommonParamVO) {
		// 마지막 결재자 결재 후 ERP 전송
		ApprVO apprVO = new ApprVO();
		apprVO.setApprId(ApprType.APPR_TYPE_DISS_SAMPLE.getCode().equals(dissApprCommonParamVO.getApprType())
				? dissApprCommonParamVO.getApprId() : dissApprCommonParamVO.getRelApprId());

		// 마지막 결재자 결재 완료 체크
		if(dissCommonApprMgmtService.checkListApplActYn(apprVO, dissApprCommonParamVO.getApprEmpId())
		&& ApplState.APPL_APPROVE.getCode().equals(dissApprCommonParamVO.getApplStat())) {
			try {
				DissSampleOrderMasterVO dissSampleOrderMasterVO = new DissSampleOrderMasterVO();

				if(ApprType.APPR_TYPE_DISS_SAMPLE.getCode().equals(dissApprCommonParamVO.getApprType())) {
					dissSampleOrderMasterVO.setStepId(dissApprCommonParamVO.getStepId());
				} else {
					DissStepVO relStepVO = new DissStepVO();
					relStepVO.setApprId(dissApprCommonParamVO.getRelApprId());
					dissSampleOrderMasterVO.setStepId(dissStepDao.getDissStepByApprId(relStepVO).getStepId());
				}

				dissSampleOrderMasterVO = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(searchSampleOrderInfo(dissSampleOrderMasterVO));
				dissSampleOrderMasterVO.setSaveMode("ERP");
				dissSampleOrderMasterVO.setApprVO(new ApprVO());
				dissSampleOrderMasterVO.setUpdtIdxx(dissApprCommonParamVO.getUpdtIdxx());
				saveDissSampleOrder(dissSampleOrderMasterVO);
			} catch(ServiceException e) {	// ERP 전송 실패 시 메일, SMS 발송
				apprVO = commonApprMgmtService.getAppr(apprVO);
//				DissSpecInVO dissSpecInVO = new DissSpecInVO();
//				dissSpecInVO.setTaskId(dissApprCommonParamVO.getTaskId());

				Map<String,String> mailParamMap = new HashMap<>();
				String url= messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=";

				try {
					url += URLEncoder.encode("/dissPublic/dissSampleOrderMgmt","UTF-8")  + "?apprId=" + apprVO.getApprId();
				} catch (UnsupportedEncodingException e1) {
					logger.error(e1.getMessage());
				}

				mailParamMap.put("message", e.getErrorMsg());
				mailParamMap.put("url",url);
				mailParamMap.put("apprTitle", apprVO.getApprTitle());

				SendMailVO sendMailVO = new SendMailVO();
				sendMailVO.setTitle(MailType.DISS_SAMPLE_ERP_SAVE_FAIL.getTitle());
				sendMailVO.setMailType(MailType.DISS_SAMPLE_ERP_SAVE_FAIL);
				sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
				sendMailVO.setReceiverEmail(apprVO.getSawnMailAddr());
				sendMailVO.setParams(mailParamMap);
				mailingService.sendMail(sendMailVO);

				SmsVO smsVo = new SmsVO();
				smsVo.setTrPhone(apprVO.getSawnHpxxNum1());
				smsVo.setTrMsg("[" + apprVO.getApprTitle() + "] 견본 품의서의 ERP전송에 실패했습니다. " + e.getErrorMsg());
				smsVo.setTrEtc1(ApprType.APPR_TYPE_DISS_SAMPLE.getCode().equals(dissApprCommonParamVO.getApprType()) ? dissApprCommonParamVO.getApprId() : dissApprCommonParamVO.getRelApprId());
				smsService.sendSms(smsVo);
			} catch(Exception e) {}
		}
		
	}

	/**
	 * DISS 견본 저장
	 *
	 * @param dissSampleOrderMasterVO
	 */
	@Override
	public void saveDissSampleOrder(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		if ("".equals(dissSampleOrderMasterVO.getSaveMode())) {
			throw new ServiceException("", "견본 처리 구분이 지정되지 않았습니다.");
		}

		if ("TMP".equals(dissSampleOrderMasterVO.getSaveMode())) { // 임시저장인경우
			// 기본저장
			saveDissSampleOrderTables(dissSampleOrderMasterVO);
			
			// 업무테이블 품의서 기초내용 작성 호출  temp	
			//dissSampleOrderMasterVO.getApprVO().setTempleteFormContent(getApprFormCont(dissSampleOrderMasterVO));
						
			// 공통 결재 저장액션
			dissSampleOrderMasterVO.getApprVO().setApprId(dissSampleOrderMasterVO.getApprId()); // 기본저장시 apprId 셋팅
			dissSampleOrderMasterVO.getApprVO().setUpdtIdxx(dissSampleOrderMasterVO.getUpdtIdxx());
			dissSampleOrderMasterVO.getApprVO().setRegiIdxx(dissSampleOrderMasterVO.getRegiIdxx());
			dissCommonApprMgmtService.saveDissCommonAppr(dissSampleOrderMasterVO.getApprVO(), ApprState.TEMP_SAVE.getCode(), false);

			// SPEC-IN 등록 품의와 병렬 진행 시 SPEC-IN 등록 품의에 relApprId 셋팅
			String relApprId = dissSampleOrderMasterVO.getApprVO().getRelApprId();
			if(!relApprId.equals("")) {
				// 병렬 등록 후 GateReview 처리 시, 결재 요청자가 결재라인에 포함된 것으로 인식되는 현상 방지
				DissSpecInVO dissSpecInVO = new DissSpecInVO();
				dissSpecInVO.setTaskId(dissSampleOrderMasterVO.getTaskId());
				dissSpecInVO.setUpdtIdxx(dissSampleOrderMasterVO.getUpdtIdxx());
				dissSpecInVO = dissSpecInService.getDissSpecInInfo(dissSpecInVO);
				for(ApprLineVO apprLineVO : dissSampleOrderMasterVO.getApprVO().getApprLineRList())
					if(apprLineVO.getApprEmpId().equals(dissSpecInVO.getTsEmpId()))
						throw new ServiceException("","견본품의 병렬 등록 시 TS 담당자는 결재라인에 추가할 수 없습니다.");
				for(ApprLineVO apprLineVO : dissSampleOrderMasterVO.getApprVO().getApprLineIList())
					if(apprLineVO.getApprEmpId().equals(dissSpecInVO.getTsEmpId()))
						throw new ServiceException("","견본품의 병렬 등록 시 TS 담당자는 결재라인에 추가할 수 없습니다.");

				ApprVO relApprVO = new ApprVO();
				relApprVO.setApprId(relApprId);
				relApprVO.setRelApprId(dissSampleOrderMasterVO.getApprVO().getApprId());

				// 병렬 진행 중인 SPEC-IN 등록 품의서의 상태가 임시저장 상태가 아니면 에러 발생
				if(!ApprState.TEMP_SAVE.getCode().equals(commonApprDao.getAppr(relApprVO).getApprStat()))
					throw new ServiceException("", "GateReview 처리가 이미 완료되어 견본품의 등록이 불가능합니다.\n해당 품의 결재 완료 후 다시 등록하시기 바랍니다.");
				commonApprDao.updateRelApprId(relApprVO);
			}
		} else if ("REQ".equals(dissSampleOrderMasterVO.getSaveMode())) {  // 결재요청인경우
			// 기본저장
			saveDissSampleOrderTables(dissSampleOrderMasterVO);

			// 업무테이블 품의서 기초내용 작성 호출  kjy	
			dissSampleOrderMasterVO.getApprVO().setTempleteFormContent(getApprFormCont(dissSampleOrderMasterVO));			

			// 공통 결재 저장액션
			dissSampleOrderMasterVO.getApprVO().setApprId(dissSampleOrderMasterVO.getApprId()); // 기본저장시 apprId 셋팅
			dissSampleOrderMasterVO.getApprVO().setUpdtIdxx(dissSampleOrderMasterVO.getUpdtIdxx());
			dissSampleOrderMasterVO.getApprVO().setRegiIdxx(dissSampleOrderMasterVO.getRegiIdxx());
			dissCommonApprMgmtService.saveDissCommonAppr(dissSampleOrderMasterVO.getApprVO(), ApprState.APPR_PROCEEDING.getCode(), false);
		} else if ("DEL".equals(dissSampleOrderMasterVO.getSaveMode())) { // 삭제인경우
			// 품의서 삭제
			dissSampleOrderMasterVO.getApprVO().setUpdtIdxx(dissSampleOrderMasterVO.getUpdtIdxx());
			dissSampleOrderMasterVO.getApprVO().setRegiIdxx(dissSampleOrderMasterVO.getRegiIdxx());

			ApprVO checkApprVO = commonApprDao.getAppr(dissSampleOrderMasterVO.getApprVO());
			if(!checkApprVO.getRegiIdxx().equals(dissSampleOrderMasterVO.getUpdtIdxx())){
				throw new ServiceException("", "올바른 사용자 접근이 아닙니다.");
			}
			dissCommonApprMgmtService.deleteDissAppr(dissSampleOrderMasterVO.getApprVO());
			// 견본오더마스터 삭제
			dissSampleOrderDao.deleteDissSampleOrderMaster(dissSampleOrderMasterVO.getOrderId());
			// 견본오더아이템 삭제
			dissSampleOrderDao.deleteDissSampleOrderItemAll(dissSampleOrderMasterVO.getOrderId());
			// 스텝삭제
			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setStepId(dissSampleOrderMasterVO.getStepId());
			dissStepVO.setStepCd(dissSampleOrderMasterVO.getStepCd());
			dissStepVO.setTaskId(dissSampleOrderMasterVO.getTaskId());
			dissStepDao.deleteDissStep(dissStepVO);
			// 이전스텝 최종 복구
			dissStepDao.updateStepLastYnYByStepCd(dissStepVO);

			// SPEC-IN 등록 품의와 병렬 진행 시 SPEC-IN 등록 품의에 relApprId 셋팅
			ApprVO relApprVO = new ApprVO();
			relApprVO.setApprId(dissSampleOrderMasterVO.getApprVO().getRelApprId());
			relApprVO.setRelApprId("");
			commonApprDao.updateRelApprId(relApprVO);
		} else if ("REW".equals(dissSampleOrderMasterVO.getSaveMode())) { // 반려건 재작성 인경우
			dissSampleOrderMasterVO.setStepId(""); // 스텝ID를 지우고 저장처리
			dissSampleOrderMasterVO.setPurchNoC(""); // PO번호 다시 셋팅
			// 기본저장
			saveDissSampleOrderTables(dissSampleOrderMasterVO);
			
			// 업무테이블 품의서 기초내용 작성 호출  kjy	
			//dissSampleOrderMasterVO.getApprVO().setTempleteFormContent(getApprFormCont(dissSampleOrderMasterVO));
			
			// 공통 결재 저장액션
			dissSampleOrderMasterVO.getApprVO().setApprId(dissSampleOrderMasterVO.getApprId()); // 기본저장시 apprId 셋팅
			dissSampleOrderMasterVO.getApprVO().setUpdtIdxx(dissSampleOrderMasterVO.getUpdtIdxx());
			dissSampleOrderMasterVO.getApprVO().setRegiIdxx(dissSampleOrderMasterVO.getRegiIdxx());
			dissCommonApprMgmtService.saveDissCommonAppr(dissSampleOrderMasterVO.getApprVO(), ApprState.TEMP_SAVE.getCode(), false);
		} else if ("ERP".equals(dissSampleOrderMasterVO.getSaveMode())) { // 수정후SAP전송
			// 먼저 저장(견본테이블처리)
			saveDissSampleOrderTables(dissSampleOrderMasterVO);

			// Item list를 DirectOrderItemVO 리스트로 변환셋팅
			dissSampleOrderMasterVO.setOrderItemList(castItemListFrDissItemList(dissSampleOrderMasterVO.getDissSampleOrderItemList()));

			if ("".equals(dissSampleOrderMasterVO.getVbeln())) { // ERP주문번호가 없으면 TB_ORDER 생성 후 전송
				// 영업주문테이블 생성 및 sap 전송처리
				directOrderService.createDirectOrder(dissSampleOrderMasterVO);

				// 견본테이블 sap 주문번호 업데이트
				dissSampleOrderDao.updateAfterSendErp(dissSampleOrderMasterVO);
			} else { // ERP주문번호가 있으면 수정 후 전송
				directOrderService.updateDirectOrder(dissSampleOrderMasterVO);
			}

		}
	}
	
	/**
	 * DISS SPEC-IN DISS 견본 내용 
	 *
	 * @param DissSampleOrderMasterVO	 
	 * @return
	 */
	@Override
	public String getApprFormCont(DissSampleOrderMasterVO param) {
		
		StringBuffer content = new StringBuffer();
		Map<String, Object> map = new HashMap<String, Object>();
		String templeteFormContent = null;		
		
		// 견본조회		
		DissSampleOrderMasterVO dissSampleOrderVO = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(searchSampleOrderInfo(param));		
				
		List<DissSampleOrderItemVO> dissSampleOrderList = new ArrayList<DissSampleOrderItemVO>();
		for(DissSampleOrderItemVO sampleOrder : dissSampleOrderVO.getDissSampleOrderItemList()) {			
			dissSampleOrderList.add((DissSampleOrderItemVO)StringUtil.nullToEmptyString(sampleOrder));
		}
		
		templeteFormContent = param.getApprVO().getFormCont();
		
		map.put("dissSampleOrderVO"  , dissSampleOrderVO);		
		map.put("dissSampleOrderList", dissSampleOrderList);
		map.put("templeteFormContent", templeteFormContent);
		
		FileVO fileVO = new FileVO();
		fileVO.setFileId(param.getApprVO().getFileId());
		List<FileVO> fileVoList = commonFileService.getFileList(fileVO);
		
		map.put("fileVoList", fileVoList);
		
		if ("SPECIN".equals(dissSampleOrderVO.getTaskType())) {
			// 스펙인 기본정보 조회 20200713				
			DissSpecInVO dissSpecInVOParam = new DissSpecInVO();
			dissSpecInVOParam.setTaskId(param.getTaskId());
			dissSpecInVOParam.setUpdtIdxx(param.getUpdtIdxx());
			
			DissSpecInVO dissSpecInVOTemp = new DissSpecInVO();
			dissSpecInVOTemp = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInInfo(dissSpecInVOParam));
			
			//logger.debug("  dissSpecInVOTemp getStepId======" + dissSpecInVOTemp.getGateStepId());
			
			dissSpecInVOParam.setStepId(dissSpecInVOTemp.getGateStepId());
			dissSpecInVOParam.setUpdtIdxx(param.getUpdtIdxx());		
							
			DissSpecInVO dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInInfoHisAll(dissSpecInVOParam));		
			
			List<DissSpecInSaleGoalVO> dissSaleGoalList = new ArrayList<DissSpecInSaleGoalVO>();		
			for(DissSpecInSaleGoalVO saleGoal : dissSpecInVO.getDissSpecInSaleGoalList()) {
				dissSaleGoalList.add((DissSpecInSaleGoalVO)StringUtil.nullToEmptyString(saleGoal));					
			}
			
			map.put("dissSpecInVO", dissSpecInVO);
			map.put("dissSaleGoalList", dissSaleGoalList);
		}
		try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				reportTemplateConfiguration.getTemplate(REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER + ".txt"), map));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
		
    	return "";
	}

	/**
	 * DISS 견본 저장(결재의뢰 까지 사용)
	 *
	 * @param dissSampleOrderMasterVO
	 */
	private void saveDissSampleOrderTables(DissSampleOrderMasterVO dissSampleOrderMasterVO) {

		// PO번호 생성
		if (dissSampleOrderMasterVO.getPurchNoC().equals("")) {
			dissSampleOrderMasterVO.setPurchNoC(directOrderService.makePurchNo(OrderType.SAMPLE.getCode()));
		}

		// 날짜컬럼 셋팅
		setDateCols(dissSampleOrderMasterVO);

		// 주문유형지정(견본으로)
		dissSampleOrderMasterVO.setDocType(OrderType.SAMPLE.getCode());

		// 판매처 통화키 확인
		dissSampleOrderMasterVO = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(dissSampleOrderMasterVO);
		if("".equals(dissSampleOrderMasterVO.getCurrency())){
			CompanyVO companyVO = new CompanyVO();
			companyVO.setCompCode(dissSampleOrderMasterVO.getCompCode());
			companyVO.setVkorg(dissSampleOrderMasterVO.getSalesOrg());
			companyVO = companyDao.getCompanyDetail(companyVO);
			if(companyVO == null)	throw new ServiceException("","해당 영업 조직에 고객 정보가 없습니다.\n영업조직 확장을 진행하신 후 다시 시도해 주세요.");
			String waers = StringUtil.nullConvert(companyVO.getOrganVO().getWaers());
			dissSampleOrderMasterVO.setCurrency(waers);
		}

		if ("".equals(dissSampleOrderMasterVO.getStepId())) { // stepId 가 없으면 insert
			String tmpOrderId = Util.getUUID();   // 주문ID
			String tmpStepId = Util.getUUID();   // 스텝ID
			String tmpApprId = Util.getUUID();   // 품의서ID 생성

			dissSampleOrderMasterVO.setOrderId(tmpOrderId);
			dissSampleOrderMasterVO.setApprId(tmpApprId);
			dissSampleOrderMasterVO.setStepId(tmpStepId);
			dissSampleOrderMasterVO.setStepCd("400200");

			DissStepVO dissStepVO = new DissStepVO();
			dissStepVO.setStepId(tmpStepId);
			dissStepVO.setStepCd(dissSampleOrderMasterVO.getStepCd());
			dissStepVO.setTaskId(dissSampleOrderMasterVO.getTaskId());
			// 이전 견본 스텝 LastYn N으로
			dissStepDao.updateDissStepLastYn(dissStepVO);

			dissStepVO.setTaskType(dissSampleOrderMasterVO.getTaskType());
			dissStepVO.setApprId(tmpApprId);
			dissStepVO.setOrderId(tmpOrderId);
			dissStepVO.setDegreeNo(dissSampleOrderMasterVO.getDegreeNo());
			dissStepVO.setRegiIdxx(dissSampleOrderMasterVO.getRegiIdxx());
			dissStepVO.setUpdtIdxx(dissSampleOrderMasterVO.getUpdtIdxx());
			// 견본 스텝 생성
			dissStepDao.createDissStep(dissStepVO);

			// 견본마스터 생성
			dissSampleOrderDao.createDissSampleOrderMaster(dissSampleOrderMasterVO);
			// 견본Items 생성
			createSampleOrderItems(dissSampleOrderMasterVO);
			// 품의서 등록,수정자 셋팅
			dissSampleOrderMasterVO.getApprVO().setRegiIdxx(dissSampleOrderMasterVO.getRegiIdxx());
			dissSampleOrderMasterVO.getApprVO().setUpdtIdxx(dissSampleOrderMasterVO.getUpdtIdxx());
		} else { // stepId가 있으면 update
			dissSampleOrderDao.updateDissSampleOrderMaster(dissSampleOrderMasterVO);
			dissSampleOrderDao.deleteDissSampleOrderItemAll(dissSampleOrderMasterVO.getOrderId());
			createSampleOrderItems(dissSampleOrderMasterVO);
			// 품의서 수정자 셋팅
			dissSampleOrderMasterVO.getApprVO().setUpdtIdxx(dissSampleOrderMasterVO.getUpdtIdxx());
		}
	}

	/**
	 * 견본주문 날짜 컬럼 셋팅
	 *
	 * @param dissSampleOrderMasterVO
	 */
	private void setDateCols(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		int reqDateH = Integer.parseInt(StringUtil.remove(dissSampleOrderMasterVO.getReqDateH(), '.'));
		int today = Integer.parseInt(DateUtil.getToday());

		dissSampleOrderMasterVO.setReqDateH(today > reqDateH ? today + "" : reqDateH + "");
		dissSampleOrderMasterVO.setPriceDate(dissSampleOrderMasterVO.getReqDateH());
		dissSampleOrderMasterVO.setDocDate(today + "");
	}

	/**
	 * 견본주문 자재리스트저장
	 *
	 * @param param
	 */
	private void createSampleOrderItems(DissSampleOrderMasterVO param) {
		int i = 0;
		for (DissSampleOrderItemVO item : param.getDissSampleOrderItemList()) {
			item.setOrderId(param.getOrderId());
			i++;
			item.setSeq(i * 10);
			item.setCondPUnt(1);
			item.setRegiIdxx(param.getRegiIdxx());
			item.setUpdtIdxx(param.getUpdtIdxx());
			item.setCurrency(param.getCurrency());// 판매처 마스터의 통화를 맵핑
			item.setReqDate(param.getReqDateH()); // 주문마스터의 요청일을 아이템 요청일에 맵핑
			item = (DissSampleOrderItemVO) StringUtil.nullToEmptyString(item);
			if (StringUtil.isNullToString(item.getHighValueYn()).equals("")) {
				item.setHighValueYn("N");
			}
			dissSampleOrderDao.createDissSampleOrderItem(item);
		}
	}


	/**
	 * DISS 견본제품리스트를 원래 견본제품리스트로 캐스팅
	 *
	 * @return
	 */
	@Override
	public List<DirectOrderItemVO> castItemListFrDissItemList(List<DissSampleOrderItemVO> dissSampleOrderItemVOList) {
		List<DirectOrderItemVO> directOrderItemVOList = new ArrayList<>();
		for (DissSampleOrderItemVO dissSampleOrderItemVO : dissSampleOrderItemVOList) {
			DirectOrderItemVO directOrderItemVO = dissSampleOrderItemVO;
			directOrderItemVOList.add(directOrderItemVO);
		}

		return directOrderItemVOList;
	}

	/**
	 * DISS 견본리스트 조회
	 *
	 * @param dissSampleOrderMasterVO
	 * @return
	 */
	@Override
	public List<DissSampleOrderMasterVO> selectDissSampleOrderMasterItemList(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		List<DissSampleOrderMasterVO> dissSampleOrderMasterVOList = dissSampleOrderDao.selectDissSampleOrderMasterItemList(dissSampleOrderMasterVO);
		if (dissSampleOrderMasterVOList.size() > 0) {
			setSapOrderStatus(dissSampleOrderMasterVOList, setDateCondition(dissSampleOrderMasterVOList));
		}
		return dissSampleOrderMasterVOList;
	}
	
	/**
	 * DISS 견본 리스트 조회(고객Test결과 신규등록)
	 *
	 * @param dissSampleOrderMasterVO
	 * @return
	 */
	@Override
	public List<DissSampleOrderMasterVO> selectDissSampleOrderCustTestList(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		List<DissSampleOrderMasterVO> dissSampleOrderMasterVOList = dissSampleOrderDao.selectDissSampleOrderCustTestList(dissSampleOrderMasterVO);
		if (dissSampleOrderMasterVOList.size() > 0) {
			setSapOrderStatus(dissSampleOrderMasterVOList, setDateCondition(dissSampleOrderMasterVOList));
		}
		return dissSampleOrderMasterVOList;
	}
	
	/**
	 * DISS 견본 리스트 조회(고객Test결과 등록내역)
	 *
	 * @param dissSampleOrderMasterVO
	 * @return
	 */
	@Override
	public List<DissSampleOrderMasterVO> selectDissSampleOrderCustTestOrderList(DissSampleOrderMasterVO dissSampleOrderMasterVO) {
		List<DissSampleOrderMasterVO> dissSampleOrderMasterVOList = dissSampleOrderDao.selectDissSampleOrderCustTestOrderList(dissSampleOrderMasterVO);
		if (dissSampleOrderMasterVOList.size() > 0) {
			setSapOrderStatus(dissSampleOrderMasterVOList, setDateCondition(dissSampleOrderMasterVOList));
		}
		return dissSampleOrderMasterVOList;
	}		


	/**
	 * DISS 견본 리스트의 주문상태 셋팅
	 *
	 * @param orderList
	 * @param dateFromTo
	 */
	private void setSapOrderStatus(List<DissSampleOrderMasterVO> orderList, String[] dateFromTo) {
		String tempOrderId = "";
		for (DissSampleOrderMasterVO orderVO : orderList) {
			if (orderVO.getVbeln() != null && !orderVO.getVbeln().equals("")) {
				if (!tempOrderId.equals(orderVO.getVbeln())) { //order id 당 한번씩만 rfc 호출하도록
					tempOrderId = orderVO.getVbeln();
					JcoTableParam tableParam = new JcoTableParam();
					Map<String, Object> inputParams = new HashMap<String, Object>();
					Map<String, Object> erpOrderIdMap = new HashMap<String, Object>();
					List<Map<String, String>> itemList = new ArrayList<>();

					if (!orderVO.getSalesOrg().equals("")) {
						inputParams.put("I_VKORG", orderVO.getSalesOrg());
					}
					inputParams.put("I_GUBUN", "W");
					erpOrderIdMap.put("SIGN", "I");
					erpOrderIdMap.put("OPTION", "EQ");
					erpOrderIdMap.put("LOW", tempOrderId);
					tableParam.put("VBELNRANGE", erpOrderIdMap);

					//조회된 목록의 주문일자로 FROM - TO 설정
					Map<String, Object> dateParamMap = new HashMap<String, Object>();
					dateParamMap.put("SIGN", "I");
					dateParamMap.put("OPTION", "BT");
					dateParamMap.put("LOW", dateFromTo[0]);
					dateParamMap.put("HIGH", dateFromTo[1]);
					tableParam.put("DATERANGE", dateParamMap);

					jcoConnector.executeFunction(FNC_SAP_ORDER_LIST, inputParams, tableParam);
					//sapOrderList
					List<Map<String, Object>> sapOrderList = (List) tableParam.get("T_LIST");

					for (Map<String, Object> sapOrder : sapOrderList) {
						for (DirectOrderMasterVO innerOrderVO : orderList) {
							if (sapOrder.get("VBELN").equals(innerOrderVO.getVbeln())) {
								innerOrderVO.setProcStat(sapOrder.get("WBSTK") + "");
								innerOrderVO.setProcStatText(OrderStatus.getStatus(sapOrder.get("WBSTK") + "").getName());
							}
						}
					}
				}
			}
		}
	}

	/**
	 * 견본 주문상태를 가져오기 위한 조회 날짜 범위 셋팅
	 *
	 * @param orderList
	 * @return
	 */
	private String[] setDateCondition(List<DissSampleOrderMasterVO> orderList) {
		String fromDate = "";
		String toDate = "";
		for (DirectOrderMasterVO orderVO : orderList) {
			if (orderVO.getDocDate() != null && !orderVO.getDocDate().equals("")) {
				fromDate = StringUtils.remove(orderVO.getDocDate(), '.');
				toDate = StringUtils.remove(orderVO.getDocDate(), '.');
				break;
			}
		}
		for (DirectOrderMasterVO orderVO : orderList) {
			if (orderVO.getDocDate() != null && !orderVO.getDocDate().equals("")) {
				if (Integer.parseInt(fromDate) > Integer.parseInt(StringUtils.remove(orderVO.getDocDate(), '.'))) {
					fromDate = StringUtils.remove(orderVO.getDocDate(), '.');
				}
				if (Integer.parseInt(toDate) < Integer.parseInt(StringUtils.remove(orderVO.getDocDate(), '.'))) {
					toDate = StringUtils.remove(orderVO.getDocDate(), '.');
				}
			}
		}
		// +- 1월로 검색범위 확대
		return new String[]{DateUtil.addYearMonthDay(fromDate, 0, -1, 0), DateUtil.addYearMonthDay(toDate, 0, 1, 0)};
	}

	/**
	 * Diss 견본조회카운트
	 * @param param
	 * @return
	 */
	@Override
	public int getSampleOrderCount(DissSampleOrderMasterVO param) {
		return dissSampleOrderDao.getSampleOrderCount(param);
	}

	/**
	 * Diss 견본조회
	 * @param param
	 * @return
	 */
	@Override
	public List<DissSampleOrderMasterVO> getSampleOrderList(DissSampleOrderMasterVO param) {
		List<DissSampleOrderMasterVO> masterList = dissSampleOrderDao.getSampleOrderList(param);
		if(masterList.size() > 0) {
			for (DissSampleOrderMasterVO master : masterList) {
				master.setDistrChanText(sapSearchService.getMasterCodeName("24", StringUtil.isNullToString(master.getDistrChan())));
			}
			//화면에서 넘어온 조회조건이 아닌 조회된 데이터 셋의 확정일 from - to 로 rfc조회범위를 좁힌다.
			//해당 rfc의 일자는 필수
			setSapOrderStatus(masterList, setDateCondition(masterList));
		}
		return masterList;
	}

	@Override
	public List<DissSampleOrderMasterVO> getDissSampleListExcelDownload(DissSampleOrderMasterVO param) {
		List<DissSampleOrderMasterVO> masterList = dissSampleOrderDao.getDissSampleListExcelDownload(param);
		if(masterList.size() > 0) {
			for (DissSampleOrderMasterVO master : masterList) {
				master.setDistrChanText(sapSearchService.getMasterCodeName("24", StringUtil.isNullToString(master.getDistrChan())));
			}
			setSapOrderStatus(masterList, setDateCondition(masterList));
		}
		return masterList;
	}
}
