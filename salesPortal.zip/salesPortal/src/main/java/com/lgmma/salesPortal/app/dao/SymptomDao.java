package com.lgmma.salesPortal.app.dao;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.CustomerCreditAssessInquiryVO;
import com.lgmma.salesPortal.app.model.SalesPriceChageRateVO;
import com.lgmma.salesPortal.app.model.SalesTrendByProdAccontVO;

public interface SymptomDao {

	int getSalesPriceChageRateListCount(SalesPriceChageRateVO param);

	List<SalesPriceChageRateVO> getSalesPriceChageRateList(SalesPriceChageRateVO param);

	int getSalesTrendByProdAccontCount(SalesTrendByProdAccontVO param);

	List<SalesTrendByProdAccontVO> getSalesTrendByProdAccontList(SalesTrendByProdAccontVO param);

	List<CustomerCreditAssessInquiryVO> getCustomerCreditAssessInquiryList(CustomerCreditAssessInquiryVO param);

	Map<String, Object> getCustomerBaseInfo(CustomerCreditAssessInquiryVO param);

	int getCustomerCreditAssessInquiryCount(CustomerCreditAssessInquiryVO param);

	List<Map<String, Object>> getCustomerCreditRating(CustomerCreditAssessInquiryVO param);

	List<Map<String, Object>> getCustomerStockHolder(CustomerCreditAssessInquiryVO param);

	List<Map<String, Object>> getCustomerFinancialInfo(CustomerCreditAssessInquiryVO param);

	List<Map<String, Object>> getCustomerFinancialRatio(CustomerCreditAssessInquiryVO param);

	List<Map<String, Object>> getCustomerMajorCustomer(CustomerCreditAssessInquiryVO param);

	List<Map<String, Object>> getRelatedCompany(CustomerCreditAssessInquiryVO param);

}
