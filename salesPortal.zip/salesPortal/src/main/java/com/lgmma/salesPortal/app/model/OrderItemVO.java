package com.lgmma.salesPortal.app.model;

import com.lgmma.salesPortal.common.model.validation.Max2Byte;

public class OrderItemVO extends PagingParamVO {
	
	//TBS_ORDERITEM
	private int eitmHdid;    //ITEM ID
	private int eordHdid;    //ITEM ID
	private String erpxIdxx;    //ERP주문 ID       
	private String erpxSubx;    //ERP주문 SUB ID   
	private int shipQtyx;    //출하수량         
	private String jumnBigo;    //비고 주문        
	private String procStat;    //진행상태         
	private String procStatNm;    //진행상태 명         
	private String jproIdxx;    //제품ID 주문      
	private String jproName;    //제품명 주문
	private int jumnQtyx;    //수량 주문        
	private int jumnDrum;    //드럼 주문        
	private String areqDate;    //도착요청일 주문  
	private String areqTime;    //도착요청시간 주문
	private String jindIdxx;    //인도처ID 주문    
	private String jindName;    //인도처명_주문    
	private String jindTelNo;    //인도처_전화    
	private String jindAddr;    //인도처 주소 주문 
	private String cindIdxx;    //인도처ID_확정    
	private String cindAddr;    //인도처주소_확정  
	private String cproIdxx;    //제품ID 확정      
	private String cproName;    //제품명 확정      
	private int confQtyx;    //수량 확정        
	private int confDrum;    //드럼 확정        
	private float confPric;    //가격 확정        
	private String arriDate;    //도착예정일 확정  
	private String arriTime;    //도착예정시간 확정
	private String tvtwtVtweg;  //유통경로ID 확정  
	private String tvtwtVtext;  //유통경로명 확정  
	private String t001wWerks;  //플랜트ID 확정    
	private String t001wName1;  //플랜트명 확정    
	private String dreqDate;    //납품요청일 확정  
	private String t001lTgort;  //저장위치ID 확정  
	private String tbsbtVsbed;  //출하조건ID 확정  
	private String t001lLgobe;  //저장위치명 확정  
	private String tbsbtVtext;  //출하조건명 확정  
	@Max2Byte(value=500, eng=1000, message="출하담당비고{errors.maxlength.kor}")
	private String cdepBigo;    //출하담당비고     
	@Max2Byte(value=500, eng=1000, message="거래명세서비고{errors.maxlength.kor}")
	private String dealBigo;    //거래명세서 비고  
	@Max2Byte(value=500, eng=1000, message="고객전달사항{errors.maxlength.kor}")
	private String custBigo  ;  //고객전달사항     
	private String cmanIdxx  ;  //확정자ID         
	private String confDate  ;  //확정등록일자
	
	private String tvkotvkorg;	//상세 출하수량 가져올때필요함
	private String lfimg;
	private String rejectReason;

	//확정시 sap 전송에 필요한 인도처 정보
	private String jindTelephone;
	private String jindTitle;
	private String jindPostlCode;
	private String jindCountry;
	//확정시 sap 전송에 필요한 자재 정보
	private String condType;
	private String condValue;
	private String meins;
	private String currency;
	
	private String highValueYn;
	private String highValue;

	public String getLfimg() {
		return lfimg;
	}
	public void setLfimg(String lfimg) {
		this.lfimg = lfimg;
	}
	public String getTvkotvkorg() {
		return tvkotvkorg;
	}
	public void setTvkotvkorg(String tvkotvkorg) {
		this.tvkotvkorg = tvkotvkorg;
	}
	public int getEitmHdid() {
		return eitmHdid;
	}
	public void setEitmHdid(int eitmHdid) {
		this.eitmHdid = eitmHdid;
	}
	public int getEordHdid() {
		return eordHdid;
	}
	public void setEordHdid(int eordHdid) {
		this.eordHdid = eordHdid;
	}
	public String getErpxIdxx() {
		return erpxIdxx;
	}
	public void setErpxIdxx(String erpxIdxx) {
		this.erpxIdxx = erpxIdxx;
	}
	public String getErpxSubx() {
		return erpxSubx;
	}
	public void setErpxSubx(String erpxSubx) {
		this.erpxSubx = erpxSubx;
	}
	public int getShipQtyx() {
		return shipQtyx;
	}
	public void setShipQtyx(int shipQtyx) {
		this.shipQtyx = shipQtyx;
	}
	public String getJumnBigo() {
		return jumnBigo;
	}
	public void setJumnBigo(String jumnBigo) {
		this.jumnBigo = jumnBigo;
	}
	public String getProcStat() {
		return procStat;
	}
	public void setProcStat(String procStat) {
		this.procStat = procStat;
	}
	public String getJproIdxx() {
		return jproIdxx;
	}
	public void setJproIdxx(String jproIdxx) {
		this.jproIdxx = jproIdxx;
	}
	public String getJproName() {
		return jproName;
	}
	public void setJproName(String jproName) {
		this.jproName = jproName;
	}
	public int getJumnQtyx() {
		return jumnQtyx;
	}
	public void setJumnQtyx(int jumnQtyx) {
		this.jumnQtyx = jumnQtyx;
	}
	public int getJumnDrum() {
		return jumnDrum;
	}
	public void setJumnDrum(int jumnDrum) {
		this.jumnDrum = jumnDrum;
	}
	public String getAreqDate() {
		return areqDate;
	}
	public void setAreqDate(String areqDate) {
		this.areqDate = areqDate;
	}
	public String getAreqTime() {
		return areqTime;
	}
	public void setAreqTime(String areqTime) {
		this.areqTime = areqTime;
	}
	public String getJindIdxx() {
		return jindIdxx;
	}
	public void setJindIdxx(String jindIdxx) {
		this.jindIdxx = jindIdxx;
	}
	public String getJindName() {
		return jindName;
	}
	public void setJindName(String jindName) {
		this.jindName = jindName;
	}
	public String getJindAddr() {
		return jindAddr;
	}
	public void setJindAddr(String jindAddr) {
		this.jindAddr = jindAddr;
	}
	public String getCindIdxx() {
		return cindIdxx;
	}
	public void setCindIdxx(String cindIdxx) {
		this.cindIdxx = cindIdxx;
	}
	public String getCindAddr() {
		return cindAddr;
	}
	public void setCindAddr(String cindAddr) {
		this.cindAddr = cindAddr;
	}
	public String getCproIdxx() {
		return cproIdxx;
	}
	public void setCproIdxx(String cproIdxx) {
		this.cproIdxx = cproIdxx;
	}
	public String getCproName() {
		return cproName;
	}
	public void setCproName(String cproName) {
		this.cproName = cproName;
	}
	public int getConfQtyx() {
		return confQtyx;
	}
	public void setConfQtyx(int confQtyx) {
		this.confQtyx = confQtyx;
	}
	public int getConfDrum() {
		return confDrum;
	}
	public void setConfDrum(int confDrum) {
		this.confDrum = confDrum;
	}
	public float getConfPric() {
		return confPric;
	}
	public void setConfPric(float confPric) {
		this.confPric = confPric;
	}
	public String getArriDate() {
		return arriDate;
	}
	public void setArriDate(String arriDate) {
		this.arriDate = arriDate;
	}
	public String getArriTime() {
		return arriTime;
	}
	public void setArriTime(String arriTime) {
		this.arriTime = arriTime;
	}
	public String getTvtwtVtweg() {
		return tvtwtVtweg;
	}
	public void setTvtwtVtweg(String tvtwtVtweg) {
		this.tvtwtVtweg = tvtwtVtweg;
	}
	public String getTvtwtVtext() {
		return tvtwtVtext;
	}
	public void setTvtwtVtext(String tvtwtVtext) {
		this.tvtwtVtext = tvtwtVtext;
	}
	public String getT001wWerks() {
		return t001wWerks;
	}
	public void setT001wWerks(String t001wWerks) {
		this.t001wWerks = t001wWerks;
	}
	public String getT001wName1() {
		return t001wName1;
	}
	public void setT001wName1(String t001wName1) {
		this.t001wName1 = t001wName1;
	}
	public String getDreqDate() {
		return dreqDate;
	}
	public void setDreqDate(String dreqDate) {
		this.dreqDate = dreqDate;
	}
	public String getT001lTgort() {
		return t001lTgort;
	}
	public void setT001lTgort(String t001lTgort) {
		this.t001lTgort = t001lTgort;
	}
	public String getTbsbtVsbed() {
		return tbsbtVsbed;
	}
	public void setTbsbtVsbed(String tbsbtVsbed) {
		this.tbsbtVsbed = tbsbtVsbed;
	}
	public String getT001lLgobe() {
		return t001lLgobe;
	}
	public void setT001lLgobe(String t001lLgobe) {
		this.t001lLgobe = t001lLgobe;
	}
	public String getTbsbtVtext() {
		return tbsbtVtext;
	}
	public void setTbsbtVtext(String tbsbtVtext) {
		this.tbsbtVtext = tbsbtVtext;
	}
	public String getCdepBigo() {
		return cdepBigo;
	}
	public void setCdepBigo(String cdepBigo) {
		this.cdepBigo = cdepBigo;
	}
	public String getDealBigo() {
		return dealBigo;
	}
	public void setDealBigo(String dealBigo) {
		this.dealBigo = dealBigo;
	}
	public String getCustBigo() {
		return custBigo;
	}
	public void setCustBigo(String custBigo) {
		this.custBigo = custBigo;
	}
	public String getCmanIdxx() {
		return cmanIdxx;
	}
	public void setCmanIdxx(String cmanIdxx) {
		this.cmanIdxx = cmanIdxx;
	}
	public String getConfDate() {
		return confDate;
	}
	public void setConfDate(String confDate) {
		this.confDate = confDate;
	}
	public String getJindTelNo() {
		return jindTelNo;
	}
	public void setJindTelNo(String jindTelNo) {
		this.jindTelNo = jindTelNo;
	}
	public String getJindTelephone() {
		return jindTelephone;
	}
	public void setJindTelephone(String jindTelephone) {
		this.jindTelephone = jindTelephone;
	}
	public String getJindTitle() {
		return jindTitle;
	}
	public void setJindTitle(String jindTitle) {
		this.jindTitle = jindTitle;
	}
	public String getJindPostlCode() {
		return jindPostlCode;
	}
	public void setJindPostlCode(String jindPostlCode) {
		this.jindPostlCode = jindPostlCode;
	}
	public String getJindCountry() {
		return jindCountry;
	}
	public void setJindCountry(String jindCountry) {
		this.jindCountry = jindCountry;
	}
	public String getCondType() {
		return condType;
	}
	public void setCondType(String condType) {
		this.condType = condType;
	}
	public String getCondValue() {
		return condValue;
	}
	public void setCondValue(String condValue) {
		this.condValue = condValue;
	}
	public String getMeins() {
		return meins;
	}
	public void setMeins(String meins) {
		this.meins = meins;
	}
	public String getProcStatNm() {
		return procStatNm;
	}
	public void setProcStatNm(String procStatNm) {
		this.procStatNm = procStatNm;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public String getHighValueYn() {
		return highValueYn;
	}
	public void setHighValueYn(String highValueYn) {
		this.highValueYn = highValueYn;
	}
	public String getHighValue() {
		return highValue;
	}
	public void setHighValue(String highValue) {
		this.highValue = highValue;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
 	
 	
}
