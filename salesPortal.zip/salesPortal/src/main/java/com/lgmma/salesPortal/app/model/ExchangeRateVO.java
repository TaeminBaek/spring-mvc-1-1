package com.lgmma.salesPortal.app.model;

import javax.validation.constraints.Pattern;

public class ExchangeRateVO extends PagingParamVO {
	/* columns */
	private String yyyyMmdd;
	private String usdxRate;
	private String jpyxRate;
	private String euroRate;
	private String jpyUsdRate;
	private String euroUsdRate;
	private String cnyxRate;
	private String gbpxRate;
	private String sgdxRate;

	/* view columns */
	private String yyyymm;
	private String yyyymmdd;

	/* condition */
	@Pattern(regexp="(\\d{4}|)$", message="{errors.yyyy}")
	private String searchYyyy;
	private String searchMm;
	private String searchYyyyMm;


	public String getYyyyMmdd() {
		return yyyyMmdd;
	}
	public void setYyyyMmdd(String yyyyMmdd) {
		this.yyyyMmdd = yyyyMmdd;
	}
	public String getUsdxRate() {
		return usdxRate;
	}
	public void setUsdxRate(String usdxRate) {
		this.usdxRate = usdxRate;
	}
	public String getJpyxRate() {
		return jpyxRate;
	}
	public void setJpyxRate(String jpyxRate) {
		this.jpyxRate = jpyxRate;
	}
	public String getEuroRate() {
		return euroRate;
	}
	public void setEuroRate(String euroRate) {
		this.euroRate = euroRate;
	}
	public String getCnyxRate() {
		return cnyxRate;
	}
	public void setCnyxRate(String cnyxRate) {
		this.cnyxRate = cnyxRate;
	}
	public String getGbpxRate() {
		return gbpxRate;
	}
	public void setGbpxRate(String gbpxRate) {
		this.gbpxRate = gbpxRate;
	}
	public String getSgdxRate() {
		return sgdxRate;
	}
	public void setSgdxRate(String sgdxRate) {
		this.sgdxRate = sgdxRate;
	}
	public String getSearchYyyy() {
		return searchYyyy;
	}
	public void setSearchYyyy(String searchYyyy) {
		this.searchYyyy = searchYyyy;
	}
	public String getSearchMm() {
		return searchMm;
	}
	public void setSearchMm(String searchMm) {
		this.searchMm = searchMm;
	}
	public String getSearchYyyyMm() {
		return searchYyyyMm;
	}
	public void setSearchYyyyMm(String searchYyyyMm) {
		this.searchYyyyMm = searchYyyyMm;
	}
	public String getYyyymm() {
		return yyyymm;
	}
	public void setYyyymm(String yyyymm) {
		this.yyyymm = yyyymm;
	}
	public String getYyyymmdd() {
		return yyyymmdd;
	}
	public void setYyyymmdd(String yyyymmdd) {
		this.yyyymmdd = yyyymmdd;
	}
	public String getJpyUsdRate() {
		return jpyUsdRate;
	}
	public void setJpyUsdRate(String jpyUsdRate) {
		this.jpyUsdRate = jpyUsdRate;
	}
	public String getEuroUsdRate() {
		return euroUsdRate;
	}
	public void setEuroUsdRate(String euroUsdRate) {
		this.euroUsdRate = euroUsdRate;
	}

}
