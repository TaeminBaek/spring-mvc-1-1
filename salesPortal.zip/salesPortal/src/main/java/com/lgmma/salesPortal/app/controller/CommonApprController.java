package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.service.CommonApprMgmtService;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.app.service.CompanyService;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.GPortalRestService;
import com.lgmma.salesPortal.app.service.GportalPostProcess;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;
import com.lgmma.salesPortal.security.authentication.UserInfo;

@Controller
@RequestMapping("/apprCommon")
public class CommonApprController {

	private static Logger logger = LoggerFactory.getLogger(CommonApprController.class); 

	@Autowired
	private CommonApprMgmtService commonApprMgmtService;

	@Autowired
	private CommonFileService commonFileService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private GPortalRestService gPortalRestService;

	@Autowired
	private DissCommonApprMgmtService dissCommonApprMgmtService;

	@RequestMapping(value = "/apprCommonPopLoad")
	public ModelAndView apprGeneralMgmtLoad(ModelAndView mav) {
		mav.setViewName("apprCommon/apprCommonPopLoad");
		return mav;
	}

	/**
	 * 공통품의서 화면 컨트롤러
	 * @param mav
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/apprCommonPopEdit")
	public ModelAndView apprGeneralMgmt(ModelAndView mav, ApprVO param) {
		ApprVO apprVo = commonApprMgmtService.getAppr(param);
		String viewName = "View";
		if(apprVo == null || apprVo.getApprId() == null || apprVo.getApprId().length() == 0 || ApprState.TEMP_SAVE.getCode().equals(apprVo.getApprStat()) || ApprState.getApprState(apprVo.getApprStat()).getEditYn()) {
			if(apprVo == null) {

				// 문서유형 체크
				if(param.getApprType() == null || param.getApprType().trim().length() == 0) {
					return returnWithErrorMessage(mav,"문서유형이 지정되어야 합니다.");
				}
				// 고객정보 필수 품의서 체크
				if(ApprType.getApprType(param.getApprType()).isReqCustYn()) {
					if( (param.getCompCode() == null || param.getCompCode().trim().length() == 0)) {
						if(param.getVkorg() == null || param.getVkorg().trim().length() == 0) {
							return returnWithErrorMessage(mav,"영업구분이 지정되어야 합니다.");
						}
						return returnWithErrorMessage(mav,"고객 정보가 지정되어야 합니다.");
					}
					CompanyVO paramCompanyVO = new CompanyVO();
					paramCompanyVO.setCompCode(param.getCompCode());
					paramCompanyVO.setVkorg(param.getVkorg());
					CompanyVO companyVO = companyService.getCompanyDetail(paramCompanyVO);
					param.setCompCode(companyVO.getCompCode());
					param.setCompName(companyVO.getName1());
				}

				mav.addObject("DisplayPopTitle", ApprType.getApprType(param.getApprType()).getName());

				// 기안자 기본정보 셋팅
				UserInfo userInfo = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo();
				String dpRegisterInfo = userInfo.getTeamName() + " " + userInfo.getSawnName() + " " + userInfo.getPosiName();
				param.setDpRegisterInfo(dpRegisterInfo);

				// 작성일 디폴트 현재시간셋팅
				String setRegiDateFmt = Util.getToday(Util.YmdHmsFmt);
				param.setRegiDateFmt(setRegiDateFmt);

				// 업무테이블 품의서 기초내용 작성 호출
				param.setFormCont(getApprFormContent(param));

			}
			viewName = "Edit";
		}else {
			mav.addObject("DisplayPopTitle", ApprType.getApprType(apprVo.getApprType()).getName());
			viewName = "View";
		}

		mav.addObject("isReqCustYn", ApprType.getApprType(param.getApprType()).isReqCustYn() ? "Y":"N");			// 고객정보 필수여부
		mav.addObject("isReqApprLineYn", ApprType.getApprType(param.getApprType()).isReqApprLineYn() ? "Y":"N");	// 결재라인 필수여부
		mav.addObject("paramAppr", param);
		mav.addObject("apprType", ApprType.values());
		mav.setViewName("apprCommon/apprCommonPop"+viewName);

		// 품의서 접근권한 체크
		if(!commonApprMgmtService.apprAccessAuthCheck(param) && !StringUtil.isEmpty(param.getApprId())){
			mav.addObject("apprErrorMsg", "품의서 접근 권한이 없습니다.");
		}

		return mav;
	}

	/**
	 * 에러처리
	 */
	private ModelAndView returnWithErrorMessage(ModelAndView mav,String msg) {
		mav.addObject("apprErrorMsg", msg);
		mav.setViewName("apprCommon/apprCommonPopEdit");
		return mav;
	}

	/**
	 * 품의서 조회(결재자 리스트를 포함한)
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/getApprContainLineList.json")
	public Map getApprContainLineList(@RequestBody(required = true) ApprVO param) {
		ApprVO rtApprVo = commonApprMgmtService.getAppr(param);
		return JsonResponse.asSuccess("storeData", commonApprMgmtService.getApprContainLineList(rtApprVo));
	}

	/**
	 * 품의서 저장(임시저장 및 상신 모두 처리)
	 * @param param
	 * @return
	 */
	@Transactional
	@RequestMapping(value = "/saveAppr.json")
	public Map saveApprCommon(@RequestBody(required = true) @Valid ApprVO param) {

		// 저장구분에 따른 상태값 셋팅
		param.setApprStat(("SAVE".equals(param.getSaveType())) ? ApprState.APPR_PROCEEDING.getCode():ApprState.TEMP_SAVE.getCode());

		// VKORG 셋팅(세션의 VKORG 셋팅)
		if(param.getVkorg() == null || param.getVkorg().trim().length() == 0) {
			param.setVkorg(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getVkorg());
		}

		// 결재라인 셋팅(유효성 체크시 다시 셋팅)
		List<ApprLineVO> apprLineList = new ArrayList<ApprLineVO>();
		if(param.getApprLineAList() != null) apprLineList.addAll(param.getApprLineAList());
		if(param.getApprLineCList() != null) apprLineList.addAll(param.getApprLineCList());
		if(param.getApprLineRList() != null) apprLineList.addAll(param.getApprLineRList());
		if(param.getApprLineIList() != null) apprLineList.addAll(param.getApprLineIList());
		param.setApprLineList(apprLineList);

		// 품의서 유효성 체크
		Map rtMap = checkApprValidaion(param);

		if((boolean) rtMap.get("success")) {
			ApprVO validParam = (ApprVO) rtMap.get("apprVO");
			// apprId가 없으면 신규입력
			if(validParam.getApprId() ==  null || validParam.getApprId().length() == 0 ) {
				validParam.setApprId(Util.getUUID());
				commonApprMgmtService.createAppr(validParam);
			}else {
				commonApprMgmtService.updateAppr(validParam);
			}
		}else {
			return rtMap;
		}
		return JsonResponse.asSuccess();
	}

	/**
	 * 품의서 저장 체크
	 * @param param
	 * @return
	 */
	private Map checkApprValidaion(ApprVO param) {
		List<ApprLineVO> apprLineList = new ArrayList<ApprLineVO>();
		//기본 필수 체크
		if(param.getApprType() == null || param.getApprType().isEmpty()) {
			return JsonResponse.asFailure("문서유형을 선택하셔야 합니다.");
		}
		//저장인경우세부 check 
		if("SAVE".equals(param.getSaveType())) {
			if(StringUtil.isEmpty(param.getSecrCode())) {
				return JsonResponse.asFailure("보안설정을 반드시 지정해야 합니다.");
			}
			if(StringUtil.isEmpty(param.getSaveCode())) {
				return JsonResponse.asFailure("보존년한을 반드시 지정해야 합니다.");
			}
			if(ApprType.getApprType(param.getApprType()).isReqApprLineYn()) {
				if(param.getApprLineAList().isEmpty()) return JsonResponse.asFailure("결재라인을 반드시 지정해야 합니다.");
			}
			if(ApprType.getApprType(param.getApprType()).isReqCustYn()) {
				if(StringUtil.isEmpty(param.getCompCode())) return JsonResponse.asFailure("고객(판매처)을 반드시 지정해야 합니다.");
			}

			// 결재라인 지정시 결재자는 반드시 지정되도록
			if(!"Y".equals(StringUtil.nullConvert(param.getLineAYn()))) {
				if("Y".equals(StringUtil.nullConvert(param.getLineCYn()))) {
					return JsonResponse.asFailure("합의자 지정시 결재자를 반드시 지정해야 합니다.");
				}
				if("Y".equals(StringUtil.nullConvert(param.getLineRYn()))) {
					return JsonResponse.asFailure("참조자 지정시 결재자를 반드시 지정해야 합니다.");
				}
				/* 품의서가 아닌 일반 작성 문서의 경우 통보자만 지정할수 있음
				if("Y".equals(StringUtil.nullConvert(param.getLineIYn()))) {
					return JsonResponse.asFailure("통보자 지정시 결재자를 반드시 지정해야 합니다.");
				}
				*/
			}

			// 결재라인별 체크 ####################################################### START
			if("Y".equals(StringUtil.nullConvert(param.getLineAYn()))) {
				if(param.getApprLineAList().isEmpty()) return JsonResponse.asFailure("결재자가 지정되지 않았습니다.");
				else apprLineList.addAll(param.getApprLineAList());
			}
			if("Y".equals(StringUtil.nullConvert(param.getLineCYn()))) {
				if(param.getApprLineCList().isEmpty()) return JsonResponse.asFailure("합의자가 지정되지 않았습니다.");
				else apprLineList.addAll(param.getApprLineCList());

				if(StringUtil.isEmpty(param.getGwdcCode())) return JsonResponse.asFailure("합의방법이 지정되지 않았습니다.");
				if(StringUtil.isEmpty(param.getConfLoca())) return JsonResponse.asFailure("합의위치가 지정되지 않았습니다.");
			}
			if("Y".equals(StringUtil.nullConvert(param.getLineRYn()))) {
				if(param.getApprLineRList().isEmpty()) return JsonResponse.asFailure("참조자가 지정되지 않았습니다.");
				else apprLineList.addAll(param.getApprLineRList());
			}
			if("Y".equals(StringUtil.nullConvert(param.getLineIYn()))) {
				if(param.getApprLineIList().isEmpty()) return JsonResponse.asFailure("통보자가 지정되지 않았습니다.");
				else apprLineList.addAll(param.getApprLineIList());
			}
			// 결재라인별 체크 ####################################################### END

			// 결재라인 필수 직책 체크 추가(실제 저장하는 서비스에서 체크 - 저장된 후에 체크 되어야 해서 저장 후 체크 되도록 함)

			// 결재라인이 필수가 아니고 결재라인이 없을경우 저장시 바로 작성 완료로셋팅
			if(!ApprType.getApprType(param.getApprType()).isReqApprLineYn()) {
				if(!"Y".equals(StringUtil.nullConvert(param.getLineAYn()))) {
					param.setApprStat(ApprState.APPR_WRITE_COMPLETE.getCode());
				}
			}

		}
		if(!apprLineList.isEmpty()) {
			param.setApprLineList(apprLineList);
		}
		return JsonResponse.asSuccess("apprVO",param);
	}

	/**
	 * 품의서 삭제
	 * */
	@RequestMapping(value = "/deleteAppr.json")
	public Map deleteApprCommon(@RequestBody(required = true) ApprVO param) throws Exception {
		commonApprMgmtService.deleteAppr(param);
		commonFileService.deleteFilesByFileId(param.getFileId());
		return JsonResponse.asSuccess();
	}

	/**
	 * GPortal 연계결재시 GPortal 에서 호출 실행
	 * */
	@RequestMapping(value = "/GPortalApproval")
	public void approvalFromGPortal(HttpServletRequest request, HttpServletResponse response,
			  @RequestParam(value="apprId", required=true)			String apprId
			, @RequestParam(value="apprEmpId", required=true)		String apprEmpId
			, @RequestParam(value="apprStatus", required=true)		String apprStatus
			, @RequestParam(value="apprEmpComment", required=false)	String apprEmpComment
			, @RequestParam(value="forceExcute", required=false, defaultValue="N") String forceExcute
			) throws Exception {
		logger.debug("################GPortalApproval-TEST");
		gPortalRestService.approvalAtcionFromGPortal(apprId, apprEmpId, apprStatus, apprEmpComment, forceExcute);
		response.getWriter().write("APPROVAL ATCION FROM GPORTAL END");
	}

	/**
	 * GPortal 결재 회수
	 * */
	@RequestMapping(value = "/cancelGPortalApproval")
	public void cancelGPortalApproval(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value="apprId", required=true)			String apprId
			, @RequestParam(value="apprEmpId", required=true)		String apprEmpId
			, @RequestParam(value="apprMessage", required=false)	String apprMessage
			) throws Exception {
		logger.debug("################CancelGPortalApproval-TEST");
		dissCommonApprMgmtService.cancelGPortalApproval(apprId, apprEmpId, apprMessage);
		response.getWriter().write("CANCEL GPORTAL APPROVAL ATCION END");
	}

	/**
	 * 업무테이블 templete form content 호출
	 */
	private String getApprFormContent(ApprVO param) {
		GportalPostProcess gportalPostProcess = (GportalPostProcess)Util.getBean(ApprType.getApprType(param.getApprType()).getGpPostServiceBeanName());
		return gportalPostProcess.getApprContent(param.getKeyId());
	}

}
