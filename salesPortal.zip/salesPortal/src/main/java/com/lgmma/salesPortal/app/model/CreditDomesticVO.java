package com.lgmma.salesPortal.app.model;

public class CreditDomesticVO extends PagingParamVO {
	private String vkorg;
	private String kkber;
	private String kunnr;
	private String name1;
	private String spmon;
	private String custSeqn;
	private String ed6sal;
	private String vat;
	private String zterm;
	private String vtext;
	private String maxday;
	private String adday;
	private String kgrdcd;
	private String grade;
	private String zrate;
	private String ename;
	private String confAmnt;
	private String guarAmnt;
	private String addAmnt;
	private String ssobl;
	private String klimkc;
	private String oblig;
	private String jlimkc;
	private String waers;

	private String vtweg; //유통채널
	
	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}

	public String getKkber() {
		return kkber;
	}

	public void setKkber(String kkber) {
		this.kkber = kkber;
	}

	public String getKunnr() {
		return kunnr;
	}

	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}

	public String getName1() {
		return name1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}

	public String getSpmon() {
		return spmon;
	}

	public void setSpmon(String spmon) {
		this.spmon = spmon;
	}

	public String getCustSeqn() {
		return custSeqn;
	}

	public void setCustSeqn(String custSeqn) {
		this.custSeqn = custSeqn;
	}

	public String getEd6sal() {
		return ed6sal;
	}

	public void setEd6sal(String ed6sal) {
		this.ed6sal = ed6sal;
	}

	public String getVat() {
		return vat;
	}

	public void setVat(String vat) {
		this.vat = vat;
	}

	public String getZterm() {
		return zterm;
	}

	public void setZterm(String zterm) {
		this.zterm = zterm;
	}

	public String getVtext() {
		return vtext;
	}

	public void setVtext(String vtext) {
		this.vtext = vtext;
	}

	public String getMaxday() {
		return maxday;
	}

	public void setMaxday(String maxday) {
		this.maxday = maxday;
	}

	public String getAdday() {
		return adday;
	}

	public void setAdday(String adday) {
		this.adday = adday;
	}

	public String getKgrdcd() {
		return kgrdcd;
	}

	public void setKgrdcd(String kgrdcd) {
		this.kgrdcd = kgrdcd;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getZrate() {
		return zrate;
	}

	public void setZrate(String zrate) {
		this.zrate = zrate;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getConfAmnt() {
		return confAmnt;
	}

	public void setConfAmnt(String confAmnt) {
		this.confAmnt = confAmnt;
	}

	public String getGuarAmnt() {
		return guarAmnt;
	}

	public void setGuarAmnt(String guarAmnt) {
		this.guarAmnt = guarAmnt;
	}

	public String getAddAmnt() {
		return addAmnt;
	}

	public void setAddAmnt(String addAmnt) {
		this.addAmnt = addAmnt;
	}

	public String getSsobl() {
		return ssobl;
	}

	public void setSsobl(String ssobl) {
		this.ssobl = ssobl;
	}

	public String getKlimkc() {
		return klimkc;
	}

	public void setKlimkc(String klimkc) {
		this.klimkc = klimkc;
	}

	public String getOblig() {
		return oblig;
	}

	public void setOblig(String oblig) {
		this.oblig = oblig;
	}

	public String getJlimkc() {
		return jlimkc;
	}

	public void setJlimkc(String jlimkc) {
		this.jlimkc = jlimkc;
	}

	public String getWaers() {
		return waers;
	}

	public void setWaers(String waers) {
		this.waers = waers;
	}

	public String getVtweg() {
		return vtweg;
	}

	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}

}
