package com.lgmma.salesPortal.app.service;

import com.lgmma.salesPortal.common.model.LogVO;

public interface HttpLogService {

	public void createLog(LogVO log);
}
