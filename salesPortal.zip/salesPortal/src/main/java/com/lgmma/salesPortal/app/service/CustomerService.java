package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.CompFileListVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.CustReqVO;

public interface CustomerService {
	
	List<String> getKunnr(String param);

	List<CompFileListVO> getCompFileList(CompFileListVO param);

	void createCustomer(CompanyVO param);

	int getCustomerRequestsCount(CustReqVO param);

	List<CustReqVO> getCustomerRequestsList(CustReqVO param);

	CustReqVO getCustomerRequestDetail(CustReqVO param);
	
}
