package com.lgmma.salesPortal.common.factory;

import java.lang.reflect.Proxy;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.spring.SqlSessionFactoryBean;

public class CustomSqlSessionFactoryBean extends SqlSessionFactoryBean {
	
	private static CustomSqlSessionFactoryBean customSqlSessionFactoryBean;	
	public static CustomSqlSessionFactoryBean getInstance()
	{
		if(customSqlSessionFactoryBean == null)
		{
			customSqlSessionFactoryBean = new CustomSqlSessionFactoryBean();
		}
		return customSqlSessionFactoryBean;
	}

	private SqlSessionFactory sqlSessionFactoryProxy;	
	
    public SqlSessionFactory getParentObject() throws Exception
    {
    	return super.getObject();
    }
    
    public void refresh() throws Exception
    {
    	super.afterPropertiesSet();
    	additinalConfigurationWork();
    }

    @Override
    public void afterPropertiesSet() throws Exception
    {
    	super.afterPropertiesSet();
    	sqlSessionFactoryProxy = (SqlSessionFactory)Proxy.newProxyInstance(
			 SqlSessionFactory.class.getClassLoader(),
			 new Class[] { SqlSessionFactory.class },
			 new CustomSqlSessionFactoryProxy(this)
    	);
    	additinalConfigurationWork();
    }
    
    private void additinalConfigurationWork() throws Exception
    {
    	this.sqlSessionFactoryProxy.getConfiguration().setJdbcTypeForNull(JdbcType.NULL);    	
    	this.sqlSessionFactoryProxy.getConfiguration().setMapUnderscoreToCamelCase(true);
    }
    
    @Override
    public SqlSessionFactory getObject() throws Exception 
    {
    	if (this.sqlSessionFactoryProxy == null) {
    		afterPropertiesSet();
    	}
    	return this.sqlSessionFactoryProxy;
    }
    
}
