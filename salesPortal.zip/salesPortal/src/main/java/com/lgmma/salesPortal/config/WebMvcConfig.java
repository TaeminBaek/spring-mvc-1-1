package com.lgmma.salesPortal.config;

import java.util.ArrayList;
import java.util.List;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
import org.springframework.web.accept.ContentNegotiationManager;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.mvc.WebContentInterceptor;
import org.springframework.web.servlet.view.AbstractView;
import org.springframework.web.servlet.view.BeanNameViewResolver;
import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
import org.springframework.web.servlet.view.tiles3.TilesConfigurer;
import org.springframework.web.servlet.view.tiles3.TilesViewResolver;

import com.lgmma.salesPortal.common.util.ExcelDownloadView;
import com.lgmma.salesPortal.config.interceptor.DefaultInterceptor;
import com.lgmma.salesPortal.config.viewresolver.CustomObjectMapper;
import com.lgmma.salesPortal.config.viewresolver.JsonViewResolver;
import com.lgmma.salesPortal.config.viewresolver.PdfViewResolver;

@Configuration
@EnableWebMvc
@EnableScheduling
@EnableAsync
@ComponentScan(basePackages = {
		"com.lgmma.salesPortal.app",
		"com.lgmma.salesPortal.partnerapp",
		"com.lgmma.salesPortal.common",
		"com.lgmma.salesPortal.security"
		})
public class WebMvcConfig extends WebMvcConfigurerAdapter {
	@Autowired
	ReloadableResourceBundleMessageSource messageSource;

	/*
	 * 정적 리소스 경로 설정
	 */
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/html/**", "/web-resource/**", "/download/**")
				.addResourceLocations("/html/", "/web-resource/", "/download/");
		// namoEditor 셋팅
		registry.addResourceHandler("/namoEditor/**").addResourceLocations("/web-resource/namoEditor/");
		registry.addResourceHandler("/namoEditor/binary/**").addResourceLocations("/namoEditor/binary/");
	}

	/*
	 * json 을 제외한 모든 컨트롤러의 인터셉터. 선택한 메뉴를 좌측 메뉴구조에서 활성화를 위한 작업등을 담당한다.
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		WebContentInterceptor wci = new WebContentInterceptor();
		wci.setCacheSeconds(0);
		registry.addInterceptor(wci);
		registry.addInterceptor(new DefaultInterceptor()).excludePathPatterns(
				  "/adminLoginPage"
				, "/*/*.json"
				, "/common/**"
				, "/adminLogin"
				, "/SSOLogin"
				, "/loginPage"
				, "/partnerLogin"
				, "/partner/webAccountInfo"
				, "/namoEditor/**"
				, "/apprCommon/GPortalApproval"
				, "/contract/**"
				, "/logout"
				, "/favicon.ico"
				, "/dissAppr/GPortalApproval"
				);
	}

	/*
	 * 모든 URL 패턴에도 해당하지 않으면 서버의 디폴트 서블릿으로 포워드하는 설정. noHandler 에러 잡기 위해 enable 안한다! AppInitializer 의 customizeRegistration 참고.
	 */
//	@Override
//	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
//		configurer.enable();
//	}

	/*
	 * Controller 작성하지 않고 이런 식으로 바로 RequestMapping 과 뷰이름을 지정.
	 * web.xml 의 welcome-file 을 구현
	 */
//	@Override
//	public void addViewControllers(ViewControllerRegistry registry) {
//		registry.addViewController("/").setViewName("forward:/home");
//	}

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**").allowedOrigins("*").allowedMethods("GET", "POST","HEAD").allowCredentials(false).maxAge(3600L);
	}

	/*
	 * Configure TilesConfigurer.
	 */
	@Bean
	public TilesConfigurer tilesConfigurer() {
		TilesConfigurer tilesConfigurer = new TilesConfigurer();
		tilesConfigurer.setDefinitions(new String[] { "/WEB-INF/views/tiles/tiles.xml" });
		tilesConfigurer.setCheckRefresh(true);
		return tilesConfigurer;
	}

	@Bean
	public ViewResolver contentNegotiatingViewResolver(ContentNegotiationManager manager) {
		ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();
		resolver.setContentNegotiationManager(manager);

		// Define all possible view resolvers
		List<ViewResolver> resolvers = new ArrayList<ViewResolver>();

		resolvers.add(beanNameViewResolver());
		resolvers.add(pdfViewResolver());
		resolvers.add(tilesViewResolver());
		resolvers.add(jsonViewResolver());
		// for html
//		InternalResourceViewResolver internalResourceViewResolver = new InternalResourceViewResolver();
//		internalResourceViewResolver.setPrefix("/html/");
//		internalResourceViewResolver.setSuffix(".html");
//		resolvers.add(internalResourceViewResolver);
		resolver.setViewResolvers(resolvers);
		return resolver;
	}

	private ViewResolver beanNameViewResolver() {
		BeanNameViewResolver viewResolver = new BeanNameViewResolver();
		viewResolver.setOrder(0);
		return viewResolver;
	}

	@Bean
	public ViewResolver jsonViewResolver() {
		return new JsonViewResolver();
	}

	public ViewResolver pdfViewResolver() {
		return new PdfViewResolver();
	}

	@Bean
	public MappingJackson2HttpMessageConverter converter() {
		CustomObjectMapper com = new CustomObjectMapper();
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
		converter.setObjectMapper(com);
		return converter;
	}

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		converters.add(converter());
		super.configureMessageConverters(converters);
	}

	@Bean
	public ViewResolver tilesViewResolver() {
		TilesViewResolver viewResolver = new TilesViewResolver();
		viewResolver.setOrder(1);
		return viewResolver;
	}
	/*
	 * JSP 뷰 리졸버 
	 * @return
	 */
	/**
	 * 멀티파트 리졸버 -> 한글 문제로 oreilly cos 로 변경

	@Bean(name="multipartResolver")
	public CommonsMultipartResolver multipartResolver() {
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
		multipartResolver.setDefaultEncoding("UTF-8");
		return multipartResolver;
	}
	 */
	/*
	 * 자바스크립트 엔진
	 */
	@Bean(name = "javaScriptEngine")
	public ScriptEngine javaScriptEngine() {
		ScriptEngineManager manager = new ScriptEngineManager();
		return manager.getEngineByName("JavaScript");
	}

	/*
	 * email sender
	 */
	@Bean(name = "mailSender")
	public JavaMailSenderImpl mailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setDefaultEncoding("UTF-8");
		mailSender.setHost("165.244.241.190");
		return mailSender;
	}

	/*
	 * email template
	 */
	@Bean(name = "freemarkerConfiguration")
	public FreeMarkerConfigurationFactoryBean getFreeMarkerConfiguration() {
		FreeMarkerConfigurationFactoryBean bean = new FreeMarkerConfigurationFactoryBean();
		bean.setDefaultEncoding("UTF-8");
		bean.setTemplateLoaderPath("/WEB-INF/views/mailTemplates/");
		return bean;
	}

	/*
	 * report template
	 */
	@Bean(name = "reportFreemarkerConfiguration")
	public FreeMarkerConfigurationFactoryBean getReportFreeMarkerConfiguration() {
		FreeMarkerConfigurationFactoryBean bean = new FreeMarkerConfigurationFactoryBean();
		bean.setDefaultEncoding("UTF-8");
		bean.setTemplateLoaderPath("/WEB-INF/views/reportTemplates/");
		return bean;
	}

	/*
	 * excel template
	 */
	@Bean(name = "excelFreemarkerConfiguration")
	public FreeMarkerConfigurationFactoryBean excelFreemarkerConfiguration() {
		FreeMarkerConfigurationFactoryBean bean = new FreeMarkerConfigurationFactoryBean();
		bean.setDefaultEncoding("UTF-8");
		bean.setTemplateLoaderPath("/WEB-INF/views/excelTemplates/");
		return bean;
	}

	@Bean(name = "sendMailJobExecutor")
	public ThreadPoolTaskExecutor sendMailJobExecutor() {
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setCorePoolSize(10);
		taskExecutor.setMaxPoolSize(100);
		return taskExecutor;
	}

	/*
	 * GPortal appr connect
	 */
	@Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		return restTemplate;
	}

	/*
	 * job threadPollTaskExecutor
	 */
	@Bean(name = "jobScheduledExecutor")
	public ThreadPoolTaskExecutor jobScheduledExecutor() {
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setCorePoolSize(1);
		taskExecutor.setMaxPoolSize(100);
		return taskExecutor;
	}

	/*
	 * updateOrderWadatIstMainJobScheduledExecutor
	 */
	@Bean(name = "updateOrderWadatIstMainJobScheduledExecutor")
	public ThreadPoolTaskExecutor updateOrderWadatIstMainJobScheduledExecutor() {
		// 전체 수행시간이 길어질 경우 다음 스켸쥴 시간에 수행되지 않도록 MaxPoolSize 를 1로 설정
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setCorePoolSize(1);
		taskExecutor.setMaxPoolSize(1);
		return taskExecutor;
	}

	/*
	 * updateOrderWadatIstJobScheduledExecutor
	 */
	@Bean(name = "updateOrderWadatIstJobScheduledExecutor")
	public ThreadPoolTaskExecutor updateOrderWadatIstJobScheduledExecutor() {
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setCorePoolSize(5);
		taskExecutor.setMaxPoolSize(5);
		taskExecutor.setQueueCapacity(3000);
		return taskExecutor;
	}

	/*
	 * httpLogJobExecutor
	 */
	@Bean(name = "httpLogJobExecutor")
	public ThreadPoolTaskExecutor httpLogJobExecutor() {
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setCorePoolSize(10);
		taskExecutor.setMaxPoolSize(100);
		return taskExecutor;
	}

	/*
	 * ExcelDownloadView
	 */
	@Bean(name = "excelDownloadView")
	public AbstractView excelDownloadView() {
		return new ExcelDownloadView();
	}
}
