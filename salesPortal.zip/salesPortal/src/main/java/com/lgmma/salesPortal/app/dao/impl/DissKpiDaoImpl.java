package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissKpiDao;
import com.lgmma.salesPortal.app.model.DissKpiVO;

@Repository
public class DissKpiDaoImpl implements DissKpiDao{
	
	private static final String MAPPER_NAMESPACE = "DISSKPI_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;
	 
	@Override
	public void createDissKpi(DissKpiVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissKpi", param);
	}
	
	@Override
	public List<DissKpiVO> getDissKpiList(DissKpiVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissKpiList", param);
	}
	
	@Override
	public void deleteDissKpiAll(DissKpiVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissKpiAll", param);
	}
	
	@Override
	public void createDissKpiHis(DissKpiVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissKpiHis", param);
	}
	
	@Override
	public void deleteDissKpiHisAll(DissKpiVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissKpiHisAll", param);
	}
	
	@Override
	public List<DissKpiVO> getDissKpiHisList(DissKpiVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissKpiHisList", param);
	}
	
	@Override
	public List<DissKpiVO> getDissImpdevProposalKpiHisList(DissKpiVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissImpdevProposalKpiHisList", param);
	}
	
	@Override
	public void updateDissKpi(DissKpiVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissKpi", param);
	}
	
	@Override
	public void updateDissKpiHis(DissKpiVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissKpiHis", param);
	}
	
	@Override
	public List<DissKpiVO> getDissKpiHisStepRsltList(DissKpiVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissKpiHisStepRsltList", param);
	}	
	
	@Override
	public List<DissKpiVO> getDissKpiHisSampleEvalRegList(DissKpiVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissKpiHisSampleEvalRegList", param);
	}	
}
