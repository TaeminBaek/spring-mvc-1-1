package com.lgmma.salesPortal.app.model;

import com.lgmma.salesPortal.common.model.validation.Max2Byte;
import com.lgmma.salesPortal.common.props.OrderType;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.Max;
import javax.validation.constraints.Pattern;
import java.util.List;

public class DirectOrderMasterVO extends PagingParamVO implements Cloneable{

	private String orderId;
	@NotBlank(message = "주문유형{errors.required}")
	@Max2Byte(value = 2, eng = 4, message = "주문유형{errors.maxlength.kor}")
	private String docType;
	private String ordReason;
	@NotBlank(message = "판매조직{errors.required}")
	private String salesOrg;
	@NotBlank(message = "유통경로{errors.required}")
	private String distrChan;
	@NotBlank(message = "제품군{errors.required}")
	private String division;
	private String reqDateH;
	private String priceDate;
	private String shipCond;
	private String shipType;
	@Max2Byte(value = 10, eng = 20, message = "PO번호{errors.maxlength.kor}")
	private String purchNoC;
	private String docDate;
	private String pmnttrms;
	private String incoterms1;
	@Max2Byte(value = 14, eng = 28, message = "인도조건2{errors.maxlength.kor}")
	private String incoterms2;
	@Max2Byte(value = 9, eng = 18, message = "회계지정{errors.maxlength.kor}")
	private String assNumber;
	private String accntAsgn;
	private String priceList;
	private String zzroute;
	private String zbkqYn;
	private String billBlock;
	private String reasonRej;
	private String zland1;
	private String zztrnsWay1;
	private String zztrnsWay2;
	@Max(value = 9999, message = "수량1{errors.range.max}")
	private int zztrnsQty1;
	@Max(value = 9999, message = "수량2{errors.range.max}")
	private int zztrnsQty2;
	private String zdptbg;
	@NotBlank(message="판매처{errors.required}")
	private String partnNumbAg;
	private String compCode;
	private String partnerYn;
	@NotBlank(message="인도처{errors.required}")
	private String partnNumbWe;
	private String partnNumbVe;
	private String partnNumbZ4;
	private String partnNumbZ6;
	private String partnNumbZ7;
	private String partnNameAg;
	private String partnNameWe;
	private String partnNameVe;
	private String partnNameZ4;
	private String partnNameZ6;
	private String partnNameZ7;
	private String partnMailWe;
	@Max2Byte(value = 12, eng = 25, message = "하역지점{errors.maxlength.kor}")
	private String unloadPt;
	@Max2Byte(value = 2000, eng = 4000, message = "출하담당자 비고{errors.maxlength.kor}")
	private String bigoZ002;
	@Max2Byte(value = 2000, eng = 4000, message = "고객PO번호{errors.maxlength.kor}")
	private String bigoZ012;
	@Max2Byte(value = 2000, eng = 4000, message = "선적항{errors.maxlength.kor}")
	private String bigoZ014;
	@Max2Byte(value = 2000, eng = 4000, message = "견본비고{errors.maxlength.kor}")
	private String bigoZ025;
	private String bigoZ001;    //거래명세 (전자상거래 주문에서만 사용)
	private String condType;
	private String condTypeText;
	private float condValue;
	@Max2Byte(value = 20, eng = 40, message = "회사명{errors.maxlength.kor}")
	private String partnNumbZ4Name;
	@Max2Byte(value = 30, eng = 60, message = "담당자{errors.maxlength.kor}")
	private String partnNumbZ4Empnm;
	@Max2Byte(value = 15, eng = 30, message = "전화번호{errors.maxlength.kor}")
	@Pattern(regexp = "^[0-9|-]*$", message = "{errors.phone}")
	private String partnNumbZ4Telephone;
	private float price;
	private String liablilityYn;
	private String vbeln;
	private String sapRtnType;
	private String apprId;
	@Max2Byte(value = 50, eng = 100, message = "결재문서번호{errors.maxlength.kor}")
	private String refDocNo;
	private String wadatIst;
	private String wadatIstFrom;
	private String wadatIstTo;
	private String vkbur; // 관리팀 코드

	private String salesOrgText;
	private String docTypeText;
	private String distrChanText;
	private String divisionText;
	private String shipCondText;
	private String incoterms1Text;
	private String ordReasonText;
	private String pmnttrmsText;
	private String accntAsgnText;
	private String priceListText;
	private String zzrouteText;
	private String zbkqYnText;
	private String zland1Text;
	private String zztrnsWay1Text;
	private String zztrnsWay2Text;
	private String unloadPtText;
	
	private String newPmnttrms;
	private String pmnttrmsOrgan;
	private String pmnttrmsOrganText;
	private String procStat;
	private String procStatText;
	private String material;
	private String condUnit;
	private String condUnitText;
	private String reqQty;
	private String sdate;
	private String edate;
	private List<OrderType> orderTypeList;

	private List<DirectOrderItemVO> orderItemList;
	
	//고부가제품 관리용
	private String seq;			
	private String highValueYn;
	private String highValue;
	private String highValueText;
	
	private String plant;
	private String plantText;
	private String storeLoc;
	private String storeLocText;
	private String pr00Price;
	private String currency;
	private String priceListI;
	
	private String chkWadatIst;
	private String dealName;
	////////////////////////////////////
	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getOrdReason() {
		return ordReason;
	}

	public void setOrdReason(String ordReason) {
		this.ordReason = ordReason;
	}

	public String getSalesOrg() {
		return salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public String getDistrChan() {
		return distrChan;
	}

	public void setDistrChan(String distrChan) {
		this.distrChan = distrChan;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getReqDateH() {
		return reqDateH;
	}

	public void setReqDateH(String reqDateH) {
		this.reqDateH = reqDateH;
	}

	public String getPriceDate() {
		return priceDate;
	}

	public void setPriceDate(String priceDate) {
		this.priceDate = priceDate;
	}

	public String getShipCond() {
		return shipCond;
	}

	public void setShipCond(String shipCond) {
		this.shipCond = shipCond;
	}

	public String getShipType() {
		return shipType;
	}

	public void setShipType(String shipType) {
		this.shipType = shipType;
	}

	public String getPurchNoC() {
		return purchNoC;
	}

	public void setPurchNoC(String purchNoC) {
		this.purchNoC = purchNoC;
	}

	public String getDocDate() {
		return docDate;
	}

	public void setDocDate(String docDate) {
		this.docDate = docDate;
	}

	public String getPmnttrms() {
		return pmnttrms;
	}

	public void setPmnttrms(String pmnttrms) {
		this.pmnttrms = pmnttrms;
	}

	public String getIncoterms1() {
		return incoterms1;
	}

	public void setIncoterms1(String incoterms1) {
		this.incoterms1 = incoterms1;
	}

	public String getAssNumber() {
		return assNumber;
	}

	public void setAssNumber(String assNumber) {
		this.assNumber = assNumber;
	}

	public String getAccntAsgn() {
		return accntAsgn;
	}

	public void setAccntAsgn(String accntAsgn) {
		this.accntAsgn = accntAsgn;
	}

	public String getPriceList() {
		return priceList;
	}

	public void setPriceList(String priceList) {
		this.priceList = priceList;
	}

	public String getZzroute() {
		return zzroute;
	}

	public void setZzroute(String zzroute) {
		this.zzroute = zzroute;
	}

	public String getZbkqYn() {
		return zbkqYn;
	}

	public void setZbkqYn(String zbkqYn) {
		this.zbkqYn = zbkqYn;
	}

	public String getZland1() {
		return zland1;
	}

	public void setZland1(String zland1) {
		this.zland1 = zland1;
	}

	public String getZztrnsWay1() {
		return zztrnsWay1;
	}

	public void setZztrnsWay1(String zztrnsWay1) {
		this.zztrnsWay1 = zztrnsWay1;
	}

	public String getZztrnsWay2() {
		return zztrnsWay2;
	}

	public void setZztrnsWay2(String zztrnsWay2) {
		this.zztrnsWay2 = zztrnsWay2;
	}

	public int getZztrnsQty1() {
		return zztrnsQty1;
	}

	public void setZztrnsQty1(int zztrnsQty1) {
		this.zztrnsQty1 = zztrnsQty1;
	}

	public int getZztrnsQty2() {
		return zztrnsQty2;
	}

	public void setZztrnsQty2(int zztrnsQty2) {
		this.zztrnsQty2 = zztrnsQty2;
	}

	public String getZdptbg() {
		return zdptbg;
	}

	public void setZdptbg(String zdptbg) {
		this.zdptbg = zdptbg;
	}

	public String getPartnNumbAg() {
		return partnNumbAg;
	}

	public void setPartnNumbAg(String partnNumbAg) {
		this.partnNumbAg = partnNumbAg;
	}

	public String getCompCode() {
		return compCode;
	}

	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}

	public String getPartnNumbWe() {
		return partnNumbWe;
	}

	public void setPartnNumbWe(String partnNumbWe) {
		this.partnNumbWe = partnNumbWe;
	}

	public String getPartnNumbVe() {
		return partnNumbVe;
	}

	public void setPartnNumbVe(String partnNumbVe) {
		this.partnNumbVe = partnNumbVe;
	}

	public String getPartnNumbZ4() {
		return partnNumbZ4;
	}

	public void setPartnNumbZ4(String partnNumbZ4) {
		this.partnNumbZ4 = partnNumbZ4;
	}

	public String getPartnNumbZ6() {
		return partnNumbZ6;
	}

	public void setPartnNumbZ6(String partnNumbZ6) {
		this.partnNumbZ6 = partnNumbZ6;
	}

	public String getPartnNumbZ7() {
		return partnNumbZ7;
	}

	public void setPartnNumbZ7(String partnNumbZ7) {
		this.partnNumbZ7 = partnNumbZ7;
	}

	public String getUnloadPt() {
		return unloadPt;
	}

	public void setUnloadPt(String unloadPt) {
		this.unloadPt = unloadPt;
	}

	public String getBigoZ002() {
		return bigoZ002;
	}

	public void setBigoZ002(String bigoZ002) {
		this.bigoZ002 = bigoZ002;
	}

	public String getBigoZ014() {
		return bigoZ014;
	}

	public void setBigoZ014(String bigoZ014) {
		this.bigoZ014 = bigoZ014;
	}

	public String getCondType() {
		return condType;
	}

	public void setCondType(String condType) {
		this.condType = condType;
	}

	public float getCondValue() {
		return condValue;
	}

	public void setCondValue(float condValue) {
		this.condValue = condValue;
	}

	public String getPartnNumbZ4Name() {
		return partnNumbZ4Name;
	}

	public void setPartnNumbZ4Name(String partnNumbZ4Name) {
		this.partnNumbZ4Name = partnNumbZ4Name;
	}

	public String getPartnNumbZ4Empnm() {
		return partnNumbZ4Empnm;
	}

	public void setPartnNumbZ4Empnm(String partnNumbZ4Empnm) {
		this.partnNumbZ4Empnm = partnNumbZ4Empnm;
	}

	public String getPartnNumbZ4Telephone() {
		return partnNumbZ4Telephone;
	}

	public void setPartnNumbZ4Telephone(String partnNumbZ4Telephone) {
		this.partnNumbZ4Telephone = partnNumbZ4Telephone;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getLiablilityYn() {
		return liablilityYn;
	}

	public void setLiablilityYn(String liablilityYn) {
		this.liablilityYn = liablilityYn;
	}

	public String getVbeln() {
		return vbeln;
	}

	public void setVbeln(String vbeln) {
		this.vbeln = vbeln;
	}

	public String getSapRtnType() {
		return sapRtnType;
	}

	public void setSapRtnType(String sapRtnType) {
		this.sapRtnType = sapRtnType;
	}

	public String getApprId() {
		return apprId;
	}

	public void setApprId(String apprId) {
		this.apprId = apprId;
	}

	public String getRefDocNo() {
		return refDocNo;
	}

	public void setRefDocNo(String refDocNo) {
		this.refDocNo = refDocNo;
	}

	public String getSalesOrgText() {
		return salesOrgText;
	}

	public void setSalesOrgText(String salesOrgText) {
		this.salesOrgText = salesOrgText;
	}

	public String getDistrChanText() {
		return distrChanText;
	}

	public void setDistrChanText(String distrChanText) {
		this.distrChanText = distrChanText;
	}

	public String getDivisionText() {
		return divisionText;
	}

	public void setDivisionText(String divisionText) {
		this.divisionText = divisionText;
	}

	public String getShipCondText() {
		return shipCondText;
	}

	public void setShipCondText(String shipCondText) {
		this.shipCondText = shipCondText;
	}

	public String getIncoterms1Text() {
		return incoterms1Text;
	}

	public void setIncoterms1Text(String incoterms1Text) {
		this.incoterms1Text = incoterms1Text;
	}

	public String getOrdReasonText() {
		return ordReasonText;
	}

	public void setOrdReasonText(String ordReasonText) {
		this.ordReasonText = ordReasonText;
	}

	public String getPmnttrmsText() {
		return pmnttrmsText;
	}

	public void setPmnttrmsText(String pmnttrmsText) {
		this.pmnttrmsText = pmnttrmsText;
	}

	public String getAccntAsgnText() {
		return accntAsgnText;
	}

	public void setAccntAsgnText(String accntAsgnText) {
		this.accntAsgnText = accntAsgnText;
	}

	public String getPriceListText() {
		return priceListText;
	}

	public void setPriceListText(String priceListText) {
		this.priceListText = priceListText;
	}

	public String getZzrouteText() {
		return zzrouteText;
	}

	public void setZzrouteText(String zzrouteText) {
		this.zzrouteText = zzrouteText;
	}

	public String getZbkqYnText() {
		return zbkqYnText;
	}

	public void setZbkqYnText(String zbkqYnText) {
		this.zbkqYnText = zbkqYnText;
	}

	public String getZland1Text() {
		return zland1Text;
	}

	public void setZland1Text(String zland1Text) {
		this.zland1Text = zland1Text;
	}

	public String getZztrnsWay1Text() {
		return zztrnsWay1Text;
	}

	public void setZztrnsWay1Text(String zztrnsWay1Text) {
		this.zztrnsWay1Text = zztrnsWay1Text;
	}

	public String getZztrnsWay2Text() {
		return zztrnsWay2Text;
	}

	public void setZztrnsWay2Text(String zztrnsWay2Text) {
		this.zztrnsWay2Text = zztrnsWay2Text;
	}

	public List<DirectOrderItemVO> getOrderItemList() {
		return orderItemList;
	}

	public void setOrderItemList(List<DirectOrderItemVO> orderItemList) {
		this.orderItemList = orderItemList;
	}

	public String getBigoZ025() {
		return bigoZ025;
	}

	public void setBigoZ025(String bigoZ025) {
		this.bigoZ025 = bigoZ025;
	}

	public String getBillBlock() {
		return billBlock;
	}

	public void setBillBlock(String billBlock) {
		this.billBlock = billBlock;
	}

	public String getIncoterms2() {
		return incoterms2;
	}

	public void setIncoterms2(String incoterms2) {
		this.incoterms2 = incoterms2;
	}

	public String getReasonRej() {
		return reasonRej;
	}

	public void setReasonRej(String reasonRej) {
		this.reasonRej = reasonRej;
	}

	public String getPartnNameWe() {
		return partnNameWe;
	}

	public void setPartnNameWe(String partnNameWe) {
		this.partnNameWe = partnNameWe;
	}

	public String getPartnNameZ7() {
		return partnNameZ7;
	}

	public void setPartnNameZ7(String partnNameZ7) {
		this.partnNameZ7 = partnNameZ7;
	}

	public String getProcStat() {
		return procStat;
	}

	public void setProcStat(String procStat) {
		this.procStat = procStat;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getCondUnit() {
		return condUnit;
	}

	public void setCondUnit(String condUnit) {
		this.condUnit = condUnit;
	}

	public String getCondUnitText() {
		return condUnitText;
	}

	public void setCondUnitText(String condUnitText) {
		this.condUnitText = condUnitText;
	}

	public String getReqQty() {
		return reqQty;
	}

	public void setReqQty(String reqQty) {
		this.reqQty = reqQty;
	}

	public String getSdate() {
		return sdate;
	}

	public void setSdate(String sdate) {
		this.sdate = sdate;
	}

	public String getEdate() {
		return edate;
	}

	public void setEdate(String edate) {
		this.edate = edate;
	}

	public String getPartnNameAg() {
		return partnNameAg;
	}

	public void setPartnNameAg(String partnNameAg) {
		this.partnNameAg = partnNameAg;
	}

	public String getDocTypeText() {
		return docTypeText;
	}

	public void setDocTypeText(String docTypeText) {
		this.docTypeText = docTypeText;
	}

	public String getPartnNameVe() {
		return partnNameVe;
	}

	public void setPartnNameVe(String partnNameVe) {
		this.partnNameVe = partnNameVe;
	}

	public String getProcStatText() {
		return procStatText;
	}

	public void setProcStatText(String procStatText) {
		this.procStatText = procStatText;
	}

	public String getPartnNameZ6() {
		return partnNameZ6;
	}

	public void setPartnNameZ6(String partnNameZ6) {
		this.partnNameZ6 = partnNameZ6;
	}

	public String getCondTypeText() {
		return condTypeText;
	}

	public void setCondTypeText(String condTypeText) {
		this.condTypeText = condTypeText;
	}

	public String getPartnNameZ4() {
		return partnNameZ4;
	}

	public void setPartnNameZ4(String partnNameZ4) {
		this.partnNameZ4 = partnNameZ4;
	}

	public String getUnloadPtText() {
		return unloadPtText;
	}

	public void setUnloadPtText(String unloadPtText) {
		this.unloadPtText = unloadPtText;
	}

	public List<OrderType> getOrderTypeList() {
		return orderTypeList;
	}

	public void setOrderTypeList(List<OrderType> orderTypeList) {
		this.orderTypeList = orderTypeList;
	}

	public String getBigoZ012() {
		return bigoZ012;
	}

	public void setBigoZ012(String bigoZ012) {
		this.bigoZ012 = bigoZ012;
	}

	public String getBigoZ001() {
		return bigoZ001;
	}

	public void setBigoZ001(String bigoZ001) {
		this.bigoZ001 = bigoZ001;
	}

	public String getPartnerYn() {
		return partnerYn;
	}

	public void setPartnerYn(String partnerYn) {
		this.partnerYn = partnerYn;
	}

	public String getWadatIst() {
		return wadatIst;
	}

	public void setWadatIst(String wadatIst) {
		this.wadatIst = wadatIst;
	}

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getHighValueYn() {
		return highValueYn;
	}

	public void setHighValueYn(String highValueYn) {
		this.highValueYn = highValueYn;
	}

	public String getHighValue() {
		return highValue;
	}

	public void setHighValue(String highValue) {
		this.highValue = highValue;
	}

	public String getHighValueText() {
		return highValueText;
	}

	public void setHighValueText(String highValueText) {
		this.highValueText = highValueText;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPlantText() {
		return plantText;
	}

	public void setPlantText(String plantText) {
		this.plantText = plantText;
	}

	public String getStoreLoc() {
		return storeLoc;
	}

	public void setStoreLoc(String storeLoc) {
		this.storeLoc = storeLoc;
	}

	public String getStoreLocText() {
		return storeLocText;
	}

	public void setStoreLocText(String storeLocText) {
		this.storeLocText = storeLocText;
	}

	public String getPr00Price() {
		return pr00Price;
	}

	public void setPr00Price(String pr00Price) {
		this.pr00Price = pr00Price;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getChkWadatIst() {
		return chkWadatIst;
	}

	public void setChkWadatIst(String chkWadatIst) {
		this.chkWadatIst = chkWadatIst;
	}

	public String getWadatIstFrom() {
		return wadatIstFrom;
	}

	public void setWadatIstFrom(String wadatIstFrom) {
		this.wadatIstFrom = wadatIstFrom;
	}

	public String getWadatIstTo() {
		return wadatIstTo;
	}

	public void setWadatIstTo(String wadatIstTo) {
		this.wadatIstTo = wadatIstTo;
	}

	@Override
	public Object clone()
	{
		try{
			DirectOrderMasterVO directOrderMasterVO = (DirectOrderMasterVO)super.clone();
			return directOrderMasterVO;
		}catch(CloneNotSupportedException e){
			e.printStackTrace();
		}
		return null;
	}

	public String getPmnttrmsOrgan() {
		return pmnttrmsOrgan;
	}

	public void setPmnttrmsOrgan(String pmnttrmsOrgan) {
		this.pmnttrmsOrgan = pmnttrmsOrgan;
	}

	public String getPmnttrmsOrganText() {
		return pmnttrmsOrganText;
	}

	public void setPmnttrmsOrganText(String pmnttrmsOrganText) {
		this.pmnttrmsOrganText = pmnttrmsOrganText;
	}

	public String getNewPmnttrms() {
		return newPmnttrms;
	}

	public void setNewPmnttrms(String newPmnttrms) {
		this.newPmnttrms = newPmnttrms;
	}

	public String getPriceListI() {
		return priceListI;
	}

	public void setPriceListI(String priceListI) {
		this.priceListI = priceListI;
	}

	public String getDealName() {
		return dealName;
	}

	public void setDealName(String dealName) {
		this.dealName = dealName;
	}

	public String getPartnMailWe() {
		return partnMailWe;
	}

	public void setPartnMailWe(String partnMailWe) {
		this.partnMailWe = partnMailWe;
	}

	public String getVkbur() {
		return vkbur;
	}

	public void setVkbur(String vkbur) {
		this.vkbur = vkbur;
	}
}
