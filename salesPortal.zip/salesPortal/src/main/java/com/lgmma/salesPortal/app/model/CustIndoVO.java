package com.lgmma.salesPortal.app.model;

public class CustIndoVO extends PagingParamVO {
	private int indoCode;
	private int saleCode;
	private String vkorg;
	private String indoName;
	private String kunnr;
	private String pstlz;
	private String stras;
	private String telf1;
	private String telfx;
	private String lzone;
	public int getIndoCode() {
		return indoCode;
	}
	public void setIndoCode(int indoCode) {
		this.indoCode = indoCode;
	}
	public int getSaleCode() {
		return saleCode;
	}
	public void setSaleCode(int saleCode) {
		this.saleCode = saleCode;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getIndoName() {
		return indoName;
	}
	public void setIndoName(String indoName) {
		this.indoName = indoName;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getPstlz() {
		return pstlz;
	}
	public void setPstlz(String pstlz) {
		this.pstlz = pstlz;
	}
	public String getStras() {
		return stras;
	}
	public void setStras(String stras) {
		this.stras = stras;
	}
	public String getTelf1() {
		return telf1;
	}
	public void setTelf1(String telf1) {
		this.telf1 = telf1;
	}
	public String getTelfx() {
		return telfx;
	}
	public void setTelfx(String telfx) {
		this.telfx = telfx;
	}
	public String getLzone() {
		return lzone;
	}
	public void setLzone(String lzone) {
		this.lzone = lzone;
	}
}
