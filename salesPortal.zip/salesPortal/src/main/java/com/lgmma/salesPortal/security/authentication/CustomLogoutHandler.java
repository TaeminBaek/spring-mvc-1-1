package com.lgmma.salesPortal.security.authentication;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutHandler;

import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.config.WebSecurityConfig;

public class CustomLogoutHandler implements LogoutHandler {

	public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) 
	{
		UserInfo userInfo = Util.getUserInfo();
		if(userInfo != null)
		{
//			request.setAttribute(WebSecurityConfig.USERNAME_PARAM_NAME, userInfo.getUsername());			
		}
	}

}
