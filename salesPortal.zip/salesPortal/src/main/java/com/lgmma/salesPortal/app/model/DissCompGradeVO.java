package com.lgmma.salesPortal.app.model;

public class DissCompGradeVO extends PagingParamVO {

	//TB_D_COMPGRADE
	private String stepId;			// 과제스텝ID
	private String compGrade;       // GRADE
	
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getCompGrade() {
		return compGrade;
	}
	public void setCompGrade(String compGrade) {
		this.compGrade = compGrade;
	}

}
