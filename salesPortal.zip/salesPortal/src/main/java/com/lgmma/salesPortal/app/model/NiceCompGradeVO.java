package com.lgmma.salesPortal.app.model;

public class NiceCompGradeVO {

	private String stcd2;
	private String orgiStcd;
	private String kisdate;
	private String kisGrade;
	private String watchGrade;
	private String cfGrade;
	private String otStop;
	private String stMg;
	private String compFlag;
	private String modiNote;
	private String watchGradeCode;
	public String getStcd2() {
		return stcd2;
	}
	public void setStcd2(String stcd2) {
		this.stcd2 = stcd2;
	}
	public String getOrgiStcd() {
		return orgiStcd;
	}
	public void setOrgiStcd(String orgiStcd) {
		this.orgiStcd = orgiStcd;
	}
	public String getKisdate() {
		return kisdate;
	}
	public void setKisdate(String kisdate) {
		this.kisdate = kisdate;
	}
	public String getKisGrade() {
		return kisGrade;
	}
	public void setKisGrade(String kisGrade) {
		this.kisGrade = kisGrade;
	}
	public String getWatchGrade() {
		return watchGrade;
	}
	public void setWatchGrade(String watchGrade) {
		this.watchGrade = watchGrade;
	}
	public String getCfGrade() {
		return cfGrade;
	}
	public void setCfGrade(String cfGrade) {
		this.cfGrade = cfGrade;
	}
	public String getOtStop() {
		return otStop;
	}
	public void setOtStop(String otStop) {
		this.otStop = otStop;
	}
	public String getStMg() {
		return stMg;
	}
	public void setStMg(String stMg) {
		this.stMg = stMg;
	}
	public String getCompFlag() {
		return compFlag;
	}
	public void setCompFlag(String compFlag) {
		this.compFlag = compFlag;
	}
	public String getModiNote() {
		return modiNote;
	}
	public void setModiNote(String modiNote) {
		this.modiNote = modiNote;
	}
	public String getWatchGradeCode() {
		return watchGradeCode;
	}
	public void setWatchGradeCode(String watchGradeCode) {
		this.watchGradeCode = watchGradeCode;
	}

}
