package com.lgmma.salesPortal.app.service;

import com.lgmma.salesPortal.app.model.SampleOrderMasterVO;

import java.util.List;

public interface SampleOrderService {

	void createSampleOrder(SampleOrderMasterVO param);

	int getSampleDocCount(SampleOrderMasterVO param);

	List<SampleOrderMasterVO> getSampleDocList(SampleOrderMasterVO param);

	int getSampleOrderCount(SampleOrderMasterVO param);

	List<SampleOrderMasterVO> getSampleOrderList(SampleOrderMasterVO param);

	SampleOrderMasterVO getSampleOrderDetail(String orderId);

	void createDirectOrderAndSendErp(SampleOrderMasterVO param);

	void updateSampleOrder(SampleOrderMasterVO param);

	void setDateColRemoveFormat(SampleOrderMasterVO param);

	void updateSampleOrderAndSendErp(SampleOrderMasterVO param);

	void deleteSampleOrder(SampleOrderMasterVO param);

	void deleteSampleOrderAndSendErp(SampleOrderMasterVO param);

	SampleOrderMasterVO getVocInfo(String vactIdxx);

	void regSampleOrderFile(SampleOrderMasterVO param);

	void updateSampleOrderCommentAndSendErp(SampleOrderMasterVO param);
}
