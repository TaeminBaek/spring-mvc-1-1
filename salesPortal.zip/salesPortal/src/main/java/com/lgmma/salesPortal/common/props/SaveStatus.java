package com.lgmma.salesPortal.common.props;

public enum SaveStatus {
/**
 * 저장상태로서
*/
	 SAVE_STATUS_INSERT("I","입력")
	,SAVE_STATUS_UPDATE("U","수정")
	,SAVE_STATUS_DELETE("D","삭제")
	;
	String code = null;
	String name = null;

	private SaveStatus(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
}
