package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.HighValueGoalVO;
import com.lgmma.salesPortal.app.service.DirectOrderService;
import com.lgmma.salesPortal.app.service.HighValueMgmtService;
import com.lgmma.salesPortal.common.model.DDLBItem;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.props.SalePriceMasterPriceListType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;

import freemarker.template.Configuration;


@Controller
@RequestMapping("/directOrder") 
public class DirectOrderController {

	@Autowired
	private DirectOrderService directOrderService;
	
	@Autowired
	private HighValueMgmtService highValueMgmtService;
	
	@Autowired
	private CommonController commonController;
	
    @Autowired
    @Qualifier(value="excelFreemarkerConfiguration")
    private Configuration excelFreemarkerConfiguration;

	private final String DIRECT_ORDER_EXCEL_TEMPLATE = "DIRECT_ORDER_EXCEL_DOWNLOAD";

	private static Logger logger = LoggerFactory.getLogger(DirectOrderController.class);

	@RequestMapping(value = "/directOrderInfo")                                                         
	public ModelAndView directOrderInfo(ModelAndView mav) throws Exception {                            
		mav.setViewName("directOrder/directOrderInfo");                                                               
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));                         
		mav.addObject("orderTypeList", OrderType.values());
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), 1)));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		return mav;                                                                                       
	}                                                                                                   

	@RequestMapping(value = "/getDirectOrderList.json")
	public Map getDirectOrderList(@RequestBody(required=true) DirectOrderMasterVO param) throws Exception {
		param.setOrderTypeList(OrderType.getDirectOrderTypeList());
		return JsonResponse.asSuccess("itemsCount", directOrderService.getDirectOrderMasterItemListCount(param), "storeData", directOrderService.getDirectOrderMasterItemList(param));
	}
	
	@RequestMapping(value = "/getDeliveryInfoPopupList.json")
	public Map getDeliveryInfoPopupList(@RequestParam(required=true) String orderId) throws Exception {
		return JsonResponse.asSuccess("storeData", directOrderService.getOrderDeliveryInfo(orderId));
	}

	@RequestMapping(value = "/getDirectOrderDetail.json")
	public Map getDirectOrderDetail(@RequestBody(required=true) DirectOrderMasterVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", directOrderService.getDirectOrderDetail(param.getOrderId()));
	}
	
	@RequestMapping(value = "/detail/{docType}")                                                         
	public ModelAndView orderDetail(ModelAndView mav, @PathVariable("docType") String docType) throws Exception {
		mav.addObject("mode", "edit");
		if(docType.equals(OrderType.MARKETING.getCode())) {
			marketingOrderRegist(mav);
			mav.setViewName("directOrder/detail/marketingOrderRegist");
		} else if(docType.equals(OrderType.EXPORT.getCode())) {
			exportOrderRegist(mav);
			mav.setViewName("directOrder/detail/exportOrderRegist");                                                               
		} else if(docType.equals(OrderType.CLAIM.getCode())) {
			claimOrderRegist(mav);
			mav.setViewName("directOrder/detail/claimOrderRegist");                                                               
		}else if(docType.equals(OrderType.CLAIM_EXPORT.getCode())) {
			exportOrderRegist(mav);
			mav.setViewName("directOrder/detail/claimExportOrderRegist");                                                               
		} else if(docType.equals(OrderType.CY_EXPORT_SHIP.getCode())) {
			cyExportShipOrderRegist(mav);
			mav.setViewName("directOrder/detail/cyExportShipOrderRegist");                                                               
		} else if(docType.equals(OrderType.OTHERS.getCode())) {
			othersOrderRegist(mav);
			mav.setViewName("directOrder/detail/othersOrderRegist");                                                               
		} else if(docType.equals(OrderType.QUANTITY_ADJUST_MINUS.getCode())) {
			quantityAdjustMinusOrderRegist(mav);
			mav.setViewName("directOrder/detail/quantityAdjustMinusOrderRegist");                                                               
		} else if(docType.equals(OrderType.QUANTITY_ADJUST_PLUS.getCode())) {
			quantityAdjustPlusOrderRegist(mav);
			mav.setViewName("directOrder/detail/quantityAdjustPlusOrderRegist");                                                               
		} else if(docType.equals(OrderType.RETURNS_INBOUND.getCode())) {
			returnsInboundOrderRegist(mav);
			mav.setViewName("directOrder/detail/returnsInboundOrderRegist");                                                               
		} else if(docType.equals(OrderType.SALES_LOSS.getCode())) {
			salesLossOrderRegist(mav);
			mav.setViewName("directOrder/detail/salesLossOrderRegist");                                                               
		} else if(docType.equals(OrderType.SALES_SURPLUS.getCode())) {
			salesSurplusOrderRegist(mav);
			mav.setViewName("directOrder/detail/salesSurplusOrderRegist");                                                               
		} else if(docType.equals(OrderType.SAMPLE.getCode())) {
			sampleOrderRegist(mav);
			mav.setViewName("directOrder/detail/sampleOrderRegist");                                                               
		} else if(docType.equals(OrderType.SPECIAL_PRICE.getCode())) {
			specialPriceOrderRegist(mav);
			mav.setViewName("directOrder/detail/specialPriceOrderRegist");                                                               
		} else if(docType.equals(OrderType.SHIPPING.getCode())) {
			shippingOrderRegist(mav);
			mav.setViewName("directOrder/detail/shippingOrderRegist");                                                               
		} else if(docType.equals(OrderType.ESALES.getCode())) {
			esalesOrderRegist(mav);
			mav.setViewName("directOrder/detail/esalesOrderRegist");                                                               
		} else {
			throw new HttpClientErrorException(HttpStatus.NOT_FOUND);
		}
		return mav;                                                                                       
	}

	@RequestMapping(value = "/createOrder.json")
	public Map createOrder(@RequestBody(required=true) @Valid DirectOrderMasterVO param) throws Exception {
		directOrderService.createDirectOrder(param);
		return JsonResponse.asSuccess("success", "생성 되었습니다.");
	}
	
	@RequestMapping(value = "/updateOrder.json")
	public Map updateOrder(@RequestBody(required=true) @Valid DirectOrderMasterVO param) throws Exception {
		directOrderService.updateDirectOrder(param);
		return JsonResponse.asSuccess("success", "수정 되었습니다.");
	}

	//비고만 수정 납품문서 skip 하는 rfc ZSDE02_CHANGE_SALES_ORDER3 호출
	@RequestMapping(value = "/updateOrderComment.json")
	public Map updateOrderComment(@RequestBody(required=true) @Valid DirectOrderMasterVO param) throws Exception {
		directOrderService.updateCommentText(param);
		return JsonResponse.asSuccess("success", "수정 되었습니다.");
	}
	
	@RequestMapping(value = "/deleteOrder.json")
	public Map deleteOrder(@RequestBody(required=true) DirectOrderMasterVO param) throws Exception {
		directOrderService.deleteDirectOrder(param);
		return JsonResponse.asSuccess("success", "삭제 되었습니다.");
	}
	
	@RequestMapping(value = "/exportOrderRegist")                                                         
	public ModelAndView exportOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.EXPORT);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.EXPORT);
		mav.addObject("priceList", SalePriceMasterPriceListType.getExportSalePriceList());                                                               
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/exportOrderRegist");                                                               
		return mav;                                                                                       
	}

	private List<HighValueGoalVO> getHighValueGoalList(String grupCode) {
		HighValueGoalVO param = new HighValueGoalVO();
		param.setGrupCode(grupCode);
		param.setYyyy(DateUtil.getCurrentYear());
		param.setPageSize(highValueMgmtService.getHighValueGoalCount(param));
		return highValueMgmtService.getHighValueGoalList(param);
	}

	@RequestMapping(value = "/marketingOrderRegist")                                                         
	public ModelAndView marketingOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.MARKETING);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.MARKETING);
		mav.addObject("priceList", SalePriceMasterPriceListType.getNormalSalePriceList());                                                               
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/marketingOrderRegist");  
		return mav;                                                                                       
	}

	@RequestMapping(value = "/specialPriceOrderRegist")                                                         
	public ModelAndView specialPriceOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.SPECIAL_PRICE);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.SPECIAL_PRICE);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/specialPriceOrderRegist");                                                               
		return mav;                                                                                       
	}

	@RequestMapping(value = "/sampleOrderRegist")                                                         
	public ModelAndView sampleOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.SAMPLE);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.SAMPLE);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/sampleOrderRegist");                                                               
		return mav;                                                                                       
	}
	
	@RequestMapping(value = "/cyExportShipOrderRegist")                                                         
	public ModelAndView cyExportShipOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.CY_EXPORT_SHIP);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.CY_EXPORT_SHIP);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/cyExportShipOrderRegist");                                                               
		return mav;                                                                                       
	}
	
	@RequestMapping(value = "/salesLossOrderRegist")                                                         
	public ModelAndView salesLossOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.SALES_LOSS);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.SALES_LOSS);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/salesLossOrderRegist");                                                               
		return mav;                                                                                       
	}
	
	@RequestMapping(value = "/salesSurplusOrderRegist")                                                         
	public ModelAndView salesSurplusOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.SALES_SURPLUS);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.SALES_SURPLUS);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/salesSurplusOrderRegist");                                                               
		return mav;                                                                                       
	}
	
	@RequestMapping(value = "/quantityAdjustPlusOrderRegist")                                                         
	public ModelAndView quantityAdjustPlusOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.QUANTITY_ADJUST_PLUS);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.QUANTITY_ADJUST_PLUS);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/quantityAdjustPlusOrderRegist");                                                               
		return mav;                                                                                       
	}
	
	@RequestMapping(value = "/quantityAdjustMinusOrderRegist")                                                         
	public ModelAndView quantityAdjustMinusOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.QUANTITY_ADJUST_MINUS);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.QUANTITY_ADJUST_MINUS);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/quantityAdjustMinusOrderRegist");                                                               
		return mav;                                                                                       
	}
	
	@RequestMapping(value = "/shippingOrderRegist")                                                         
	public ModelAndView shippingOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.SHIPPING);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.SHIPPING);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/shippingOrderRegist");                                                               
		return mav;                                                                                       
	}
	
	@RequestMapping(value = "/returnsInboundOrderRegist")                                                         
	public ModelAndView returnsInboundOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.RETURNS_INBOUND);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.RETURNS_INBOUND);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/returnsInboundOrderRegist");                                                               
		return mav;                                                                                       
	}
	
	@RequestMapping(value = "/claimOrderRegist")                                                         
	public ModelAndView claimOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.CLAIM);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.CLAIM);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/claimOrderRegist");                                                               
		return mav;                                                                                       
	}
	
	//무상수출주문 추가
	@RequestMapping(value = "/claimExportOrderRegist")                                                         
	public ModelAndView claimExportOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.CLAIM_EXPORT);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.CLAIM_EXPORT);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/claimExportOrderRegist");                                                               
		return mav;                                                                                       
	}
	
	@RequestMapping(value = "/othersOrderRegist")                                                         
	public ModelAndView othersOrderRegist(ModelAndView mav) throws Exception {                            
		mav.addObject("orderType", OrderType.OTHERS);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = getOrderCode(OrderType.OTHERS);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		mav.setViewName("directOrder/othersOrderRegist");                                                               
		return mav;                                                                                       
	}

	@RequestMapping(value = "/esalesOrderRegist")
	public ModelAndView esalesOrderRegist(ModelAndView mav) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("vkorgSelect", ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getVkorg());
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));

		Map<String, Object> codeMap = getOrderCode(OrderType.ESALES);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));                                                               
		mav.addObject("domesticSalePriceList", mapper.writeValueAsString(SalePriceMasterPriceListType.getSalePriceListItemList(SalePriceMasterPriceListType.getDomesticSalePriceList())));                                                               
		mav.addObject("exportSalePriceList", mapper.writeValueAsString(SalePriceMasterPriceListType.getSalePriceListItemList(SalePriceMasterPriceListType.getExportSalePriceList())));
		//관리팀
		mav.addObject("vkburList", commonController.getSapCommonCodeListWithSelectDDLB("02").get("items"));
		return mav;
	}
	
	/**
	 * 코드내역 맵핑
	 *        -- HSH : 견본에서 사용하기 위해서 private >> public 으로 변경
	 * @param orderType
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> getOrderCode(OrderType orderType) throws Exception {
		/*
		 * 오더사유 (거래사유)	ORD_REASON	22
			SD 문서 통화	CURRENCY	26
			판매 조직	SALES_ORG	01
			유통 경로	DISTR_CHAN	24
			픞랜트 04
			저장위치 15
			제품군	DIVISION	05
			출하 조건	SHIP_COND	23
			영업 그룹	SALES_GRP	03
			사업장	SALES_OFF	02
			인도조건 (파트 1)	INCOTERMS1	30
			고객그룹 1	CUST_GRP1	10
			고객그룹 2	CUST_GRP2	11
			고객그룹 3	CUST_GRP3	12
			고객그룹 4	CUST_GRP4	13
			고객그룹 5	CUST_GRP5	14
			지급 조건 키	PMNTTRMS	28
			해당고객의 계정지정그룹	ACCNT_ASGN	08
			가격리스트 유형	PRICE_LIST	29
			운송경로	ZZROUTE	31
			부킹요청	ZBKQ_YN	32
			최종도착국	ZLAND1	37
			운송수단1	ZZTRNS_WAY1	33
			운송수단2	ZZTRNS_WAY2	33
			Forward	Z4	35
			수출커미션	Z6	36
		 */
		Map<String, Object> codeMap = new HashMap<String, Object>();

		codeMap.put("commitionType", commonController.getCommissionDDLB().get("items"));
//		codeMap.put("priceList", orderType == OrderType.EXPORT ? SalePriceMasterPriceListType.getExportSalePriceList() : SalePriceMasterPriceListType.getDomesticSalePriceList());
//		codeMap.put("01", commonController.getSapCommonCodeListDDLB("01").get("items"));
		codeMap.put("01", commonController.getVkorgDDLB().get("items"));
//		codeMap.put("02", commonController.getSapCommonCodeListDDLB("02").get("items"));
//		codeMap.put("03", commonController.getSapCommonCodeListDDLB("03").get("items"));
//		codeMap.put("04", commonController.getSapCommonCodeListDDLB("04").get("items"));
		codeMap.put("04", commonController.getSapCommonCodeListDDLB("04").get("items"));
		codeMap.put("05", commonController.getSapCommonCodeListDDLB("05").get("items"));
		codeMap.put("08", commonController.getSapCommonCodeListDDLB("08").get("items"));
//		codeMap.put("10", commonController.getSapCommonCodeListDDLB("10").get("items"));
//		codeMap.put("11", commonController.getSapCommonCodeListDDLB("11").get("items"));
//		codeMap.put("12", commonController.getSapCommonCodeListDDLB("12").get("items"));
//		codeMap.put("13", commonController.getSapCommonCodeListDDLB("13").get("items"));
//		codeMap.put("14", commonController.getSapCommonCodeListDDLB("14").get("items"));
		codeMap.put("15", commonController.getSapCommonCodeListDDLB("15").get("items"));
		codeMap.put("22", commonController.getSapCommonCodeListDDLB("22").get("items"));
		codeMap.put("23", commonController.getSapCommonCodeListDDLB("23").get("items"));
		if(orderType == orderType.EXPORT || orderType == orderType.SPECIAL_PRICE) {	//특가주문에서 유통경로를 수출로...
			codeMap.put("31", commonController.getSapCommonCodeListDDLB("31").get("items"));
//			codeMap.put("32", commonController.getSapCommonCodeListDDLB("32").get("items"));
			codeMap.put("37", commonController.getSapCommonCodeListDDLB("37").get("items"));
			codeMap.put("33", commonController.getSapCommonCodeListDDLB("33").get("items"));
			codeMap.put("35", commonController.getSapCommonCodeListDDLB("35").get("items"));

			List<DDLBItem> commissionComp = (List<DDLBItem>) commonController.getSapCommonCodeListDDLB("36").get("items");
			List<DDLBItem> newCommissionComp = new ArrayList<DDLBItem>();
			//사용하는 것만
			for(DDLBItem item : commissionComp) {
				if(item.getCode().equals("0000011239") || item.getCode().equals("0000022549") || item.getCode().equals("0000021986")) {
					newCommissionComp.add(item);
				}
			}
			codeMap.put("36", newCommissionComp);

			List<DDLBItem> distChan = (List<DDLBItem>) commonController.getSapCommonCodeListDDLB("24").get("items");
			List<DDLBItem> newDistChan = new ArrayList<DDLBItem>();
			//사용하는 것만
			for(DDLBItem item : distChan) {
				if(orderType == orderType.EXPORT && (item.getCode().equals("30") || item.getCode().equals("40"))) {
					newDistChan.add(item);
				} else {
					newDistChan.add(item);
				}
			}
			codeMap.put("24", newDistChan);
		} else {
			codeMap.put("24", commonController.getSapCommonCodeListDDLB("24").get("items"));
		}
		codeMap.put("26", commonController.getSapCommonCodeListDDLB("26").get("items"));
		codeMap.put("28", commonController.getSapCommonCodeListDDLB("28").get("items"));
//		codeMap.put("29", commonController.getSapCommonCodeListDDLB("29").get("items"));
		codeMap.put("30", commonController.getSapCommonCodeListDDLB("30").get("items"));
		return codeMap;
	}                                                                                                   
	
	@RequestMapping(value = "/directOrderExcelDownload", method = RequestMethod.POST)
	public void excelTest(DirectOrderMasterVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		//조회 시작일, 종료일 포맷 제거
		param.setSdate(param.getSdate().replace(".", ""));
		param.setEdate(param.getEdate().replace(".", ""));
		//조회할 주문유형 리스트 셋팅
		param.setOrderTypeList(OrderType.getDirectOrderTypeList());
		//contents 인코딩 설정
		req.setCharacterEncoding("euc-kr");
		//pageSize 설정
		int directInfoCnt = directOrderService.getDirectOrderMasterItemListCount(param);
		param.setPageSize(directInfoCnt);
		
		//조회한 주문 리스트
		List<DirectOrderMasterVO> directOrderList = directOrderService.getDirectOrderMasterItemList(param);
		
		//null -> empty String
		List<DirectOrderMasterVO> copyDirectOrderList = new ArrayList<DirectOrderMasterVO>();
		for(DirectOrderMasterVO dirOrderVO : directOrderList){
			copyDirectOrderList.add((DirectOrderMasterVO) StringUtil.nullToEmptyString(dirOrderVO));
		}
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("directOrderList", copyDirectOrderList);
		
		try {
			StringBuffer content = new StringBuffer();
			//contents 생성 (html)
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
					excelFreemarkerConfiguration.getTemplate(DIRECT_ORDER_EXCEL_TEMPLATE + ".txt"), paramMap));
			
			//contents 내보내기 (xls)
			String fileName = "주문현황_Download_"+Util.getToday("yyyyMMdd");
			String ext = ".xls";
			fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
			
			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie","fileDownload=true; path=/");
			res.setHeader("Content-Disposition","attachment;filename=\""+fileName+ext+"\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();

		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
		}
		 
//		excelDownService.excelDownload(paramMap, res);
		
	}

	@RequestMapping(value = "/orderListForPaymentChange")                                                         
	public ModelAndView orderListForPaymentChange(ModelAndView mav) throws Exception {                            
		mav.setViewName("directOrder/orderListForPaymentChange");                                                               
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));                         
		mav.addObject("orderTypeList", OrderType.values());
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		return mav;                                                                                       
	}                                                                                                   

	@RequestMapping(value = "/getOrderForPaymentChangeList.json")
	public Map getOrderForPaymentChangeList(@RequestBody(required = true) DirectOrderMasterVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", directOrderService.getDirectOrderCount(param), "storeData", directOrderService.getOrderForPaymentChangeList(param), "paymentCondition", commonController.getSapCommonCodeListDDLB("28").get("items"));
	}

	//지급조건만 수정 - 납품문서 skip 하는 rfc ZSDE02_CHANGE_SALES_ORDER3 호출
	@RequestMapping(value = "/updatePmnttrms.json")
	public Map updatePmnttrms(@RequestBody DirectOrderMasterVO[] params) throws Exception {
		directOrderService.updatePmnttrms(params);
		return JsonResponse.asSuccess("success", "수정 되었습니다.");
	}
	
}
