package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissCustTestDao;
import com.lgmma.salesPortal.app.model.DissCustTestVO;

@Repository
public class DissCustTestDaoImpl implements DissCustTestDao{
	
	private static final String MAPPER_NAMESPACE = "DISSCUSTTEST_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public DissCustTestVO getDissCustTestInfo(DissCustTestVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissCustTestInfo", param);
	}
	
	@Override
	public void createDissCustTest(DissCustTestVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissCustTest", param);
	}
	
	@Override
	public void updateDissCustTest(DissCustTestVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissCustTest", param);
	}
	
	@Override
	public void deleteDissCustTestAll(DissCustTestVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissCustTestAll", param);
	}	

}
