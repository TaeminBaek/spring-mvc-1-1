package com.lgmma.salesPortal.app.model;

import java.util.List;

public class FileVO extends PagingParamVO {
	/* columns */
	private String fileItemId;
	private String fileId;
	private String filePathCd;
	private String fileNm;
	private String fileNmAlias;
	private String fileSize;
	private String downLoadUrl;

	/* fileList */
	private List<FileVO> fileList;

	public String getFileItemId() {
		return fileItemId;
	}
	public void setFileItemId(String fileItemId) {
		this.fileItemId = fileItemId;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFilePathCd() {
		return filePathCd;
	}
	public void setFilePathCd(String filePathCd) {
		this.filePathCd = filePathCd;
	}
	public String getFileNm() {
		return fileNm;
	}
	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}
	public String getFileNmAlias() {
		return fileNmAlias;
	}
	public void setFileNmAlias(String fileNmAlias) {
		this.fileNmAlias = fileNmAlias;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	public List<FileVO> getFileList() {
		return fileList;
	}
	public void setFileList(List<FileVO> fileList) {
		this.fileList = fileList;
	}
	public String getDownLoadUrl() {
		return downLoadUrl;
	}
	public void setDownLoadUrl(String downLoadUrl) {
		this.downLoadUrl = downLoadUrl;
	}

}
