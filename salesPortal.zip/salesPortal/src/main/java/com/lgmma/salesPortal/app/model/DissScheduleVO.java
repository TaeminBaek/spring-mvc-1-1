package com.lgmma.salesPortal.app.model;

public class DissScheduleVO extends PagingParamVO {
	
	//TB_D_SCHEDULE
	private String taskId;		//과제ID
	private String stepGroup;   //일정구분
	private String taskType;    //과제구분
	private int    orderNo;     //순서
	private String planCompYmd; //계획일
	private String compGoalYmd; //완료목표일
	private String compYmd;     //완료일
	private String empId;       //담당자
	private String devEmpId;    //개발담당자
	//일정 조회
	private String empNm;
	private String empTeamName;
	private String empPosiName;
	private String devEmpNm;
	private String devEmpTeamName;
	private String devEmpPosiName;
	//HIS
	private String stepId;
	//차수현황
	private int    degreeNo;     //차수
	
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getStepGroup() {
		return stepGroup;
	}
	public void setStepGroup(String stepGroup) {
		this.stepGroup = stepGroup;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public int getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}
	public String getPlanCompYmd() {
		return planCompYmd;
	}
	public void setPlanCompYmd(String planCompYmd) {
		this.planCompYmd = planCompYmd;
	}
	public String getCompGoalYmd() {
		return compGoalYmd;
	}
	public void setCompGoalYmd(String compGoalYmd) {
		this.compGoalYmd = compGoalYmd;
	}
	public String getCompYmd() {
		return compYmd;
	}
	public void setCompYmd(String compYmd) {
		this.compYmd = compYmd;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpNm() {
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	public String getEmpTeamName() {
		return empTeamName;
	}
	public void setEmpTeamName(String empTeamName) {
		this.empTeamName = empTeamName;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getEmpPosiName() {
		return empPosiName;
	}
	public void setEmpPosiName(String empPosiName) {
		this.empPosiName = empPosiName;
	}
	public int getDegreeNo() {
		return degreeNo;
	}
	public void setDegreeNo(int degreeNo) {
		this.degreeNo = degreeNo;
	}

	public String getDevEmpId() {
		return devEmpId;
	}

	public void setDevEmpId(String devEmpId) {
		this.devEmpId = devEmpId;
	}

	public String getDevEmpNm() {
		return devEmpNm;
	}

	public void setDevEmpNm(String devEmpNm) {
		this.devEmpNm = devEmpNm;
	}

	public String getDevEmpTeamName() {
		return devEmpTeamName;
	}

	public void setDevEmpTeamName(String devEmpTeamName) {
		this.devEmpTeamName = devEmpTeamName;
	}

	public String getDevEmpPosiName() {
		return devEmpPosiName;
	}

	public void setDevEmpPosiName(String devEmpPosiName) {
		this.devEmpPosiName = devEmpPosiName;
	}
}
