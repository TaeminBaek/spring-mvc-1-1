package com.lgmma.salesPortal.app.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.service.CommonApprMgmtService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.Util;

@Controller
@RequestMapping("/apprGeneral") 
public class ApprGeneralController {

	private static Logger logger = LoggerFactory.getLogger(ApprGeneralController.class); 

	@Autowired
	private CommonApprMgmtService commonApprMgmtService;

	@RequestMapping(value = "/apprGeneralMgmt")
	public ModelAndView apprGeneralMgmt(ModelAndView mav ) throws Exception {
		String today = Util.getToday(Util.YmdFmt);
		String tempYmd = DateUtil.addMonth(Util.getToday(),-3);
		mav.addObject("defaultToDay", today);
		mav.addObject("defaultFrDay",Util.convertDateStrFormat(tempYmd, Util.Ymd, Util.YmdFmt));
		mav.setViewName("apprGeneral/apprGeneralMgmt");
		return mav;
	}

	@RequestMapping(value = "/getApprList.json")
	public Map getApprList(@RequestBody(required = true) ApprVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", commonApprMgmtService.getApprList(param),"itemsCount",commonApprMgmtService.getApprListCount(param));
	}



}
