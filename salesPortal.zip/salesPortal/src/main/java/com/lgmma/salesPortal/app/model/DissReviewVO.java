package com.lgmma.salesPortal.app.model;

public class DissReviewVO extends PagingParamVO {
	/* DISS Comment param */
	private String apprId;
	private String apprReviewId;
	private String apprReviewReq;
	private String apprReviewAns;
	
	/* view columns */
	private String answIdxx;
	private String answDate;
	private String reviewReqEmpNm;
	private String reviewReqPosiNm;
	private String reviewReqTeamNm;
	private String reviewAnsEmpNm;
	private String reviewAnsPosiNm;
	private String reviewAnsTeamNm;
	
	private String taskId;
	private String dailyActId;
	private String taskType;

	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getApprReviewId() {
		return apprReviewId;
	}
	public void setApprReviewId(String apprReviewId) {
		this.apprReviewId = apprReviewId;
	}
	public String getApprReviewReq() {
		return apprReviewReq;
	}
	public void setApprReviewReq(String apprReviewReq) {
		this.apprReviewReq = apprReviewReq;
	}
	public String getApprReviewAns() {
		return apprReviewAns;
	}
	public void setApprReviewAns(String apprReviewAns) {
		this.apprReviewAns = apprReviewAns;
	}
	public String getAnswIdxx() {
		return answIdxx;
	}
	public void setAnswIdxx(String answIdxx) {
		this.answIdxx = answIdxx;
	}
	public String getAnswDate() {
		return answDate;
	}
	public void setAnswDate(String answDate) {
		this.answDate = answDate;
	}
	public String getReviewReqEmpNm() {
		return reviewReqEmpNm;
	}
	public void setReviewReqEmpNm(String reviewReqEmpNm) {
		this.reviewReqEmpNm = reviewReqEmpNm;
	}
	public String getReviewReqPosiNm() {
		return reviewReqPosiNm;
	}
	public void setReviewReqPosiNm(String reviewReqPosiNm) {
		this.reviewReqPosiNm = reviewReqPosiNm;
	}
	public String getReviewReqTeamNm() {
		return reviewReqTeamNm;
	}
	public void setReviewReqTeamNm(String reviewReqTeamNm) {
		this.reviewReqTeamNm = reviewReqTeamNm;
	}
	public String getReviewAnsEmpNm() {
		return reviewAnsEmpNm;
	}
	public void setReviewAnsEmpNm(String reviewAnsEmpNm) {
		this.reviewAnsEmpNm = reviewAnsEmpNm;
	}
	public String getReviewAnsPosiNm() {
		return reviewAnsPosiNm;
	}
	public void setReviewAnsPosiNm(String reviewAnsPosiNm) {
		this.reviewAnsPosiNm = reviewAnsPosiNm;
	}
	public String getReviewAnsTeamNm() {
		return reviewAnsTeamNm;
	}
	public void setReviewAnsTeamNm(String reviewAnsTeamNm) {
		this.reviewAnsTeamNm = reviewAnsTeamNm;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getDailyActId() {
		return dailyActId;
	}
	public void setDailyActId(String dailyActId) {
		this.dailyActId = dailyActId;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
}