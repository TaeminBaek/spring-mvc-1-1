package com.lgmma.salesPortal.common.props;

public enum CompanyReportType {
/**
 * 고객정보 신고대상 유형
*/
	 FAMILY("1","대주주친인척")
	,CURRENT_OFFICIAL("2","현직임직원")
	,FORMER_OFFICIAL("3","전직임직원")
	;
	String code = null;
	String text = null;

	private CompanyReportType(String code, String text) {
		this.code = code;
		this.text = text;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
		
	public static CompanyReportType getCompanyReportType(String code) {
		for(CompanyReportType type : CompanyReportType.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}

}
