package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissCompGradeVO;

public interface DissCompGradeDao {	
	
	DissCompGradeVO getDissCompGradeInfo(DissCompGradeVO param);
	
	void createDissCompGrade(DissCompGradeVO param);
	
	void updateDissCompGrade(DissCompGradeVO param);
	
	void deleteDissCompGradeAll(DissCompGradeVO param);
	

}
