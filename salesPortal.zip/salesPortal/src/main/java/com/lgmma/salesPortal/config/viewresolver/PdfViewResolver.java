package com.lgmma.salesPortal.config.viewresolver;

import java.util.Locale;

import org.springframework.web.servlet.View;
import org.springframework.web.servlet.ViewResolver;

import com.lgmma.salesPortal.app.controller.view.PDFView;

public class PdfViewResolver implements ViewResolver {

	@Override
	public View resolveViewName(String viewName, Locale locale) throws Exception {
		PDFView view = new PDFView();
		return view;
	}

}