package com.lgmma.salesPortal.app.model;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

import com.lgmma.salesPortal.common.model.validation.BusinessNo;
import com.lgmma.salesPortal.common.model.validation.Max2Byte;

public class CompanyVO extends PagingParamVO {
	private String compCode;
	private String partnerYn;
	private String kunnr;
	private String ktokd;
	@NotBlank(message="고객명{errors.required}")
	@Max2Byte(value=21, eng=42, message="고객명{errors.maxlength.kor}")
	private String name1;
	@NotBlank(message="대표자명{errors.required}")
	@Max2Byte(value=5, eng=10, message="대표자명1{errors.maxlength.kor}")
	private String j1kfrepre;
	@BusinessNo(required=false, message="{errors.businessno}")
	private String stcd2;
	private String sortl;
	private String land1;
	private String postlz;
	private String strasPre;
	private String stras;
	@Max2Byte(value=17, eng=34, message="사업장주소{errors.maxlength.kor}")
	private String strasFull;
	private String postlz2;
	private String stras2Pre;
	private String stras2;
	private String stras2Full;
	private String lzone;
	private String stkzu;
	private String telf1Full;	//'-' 포함 전체 전화번호
	@NotBlank(message="전화번호{errors.required}")
	@Pattern(regexp="^[0-9|-]*$", message="{errors.phone}")
	private String telf1;
	@NotBlank(message="전화번호{errors.required}")
	@Pattern(regexp="^[0-9|-]*$", message="{errors.phone}")
	private String telf2;
	@NotBlank(message="전화번호{errors.required}")
	@Pattern(regexp="^[0-9|-]*$", message="{errors.phone}")
	private String telf3;
	private String telfx;	//'-' 포함 전체 팩스번호
	@Pattern(regexp="^[0-9|-]*$", message="{errors.fax}")
	private String fax1;
	@Pattern(regexp="^[0-9|-]*$", message="{errors.fax}")
	private String fax2;
	@Pattern(regexp="^[0-9|-]*$", message="{errors.fax}")
	private String fax3;
	private String j1kftbus;
	private String j1kftind;
	private int umsat;
	private int jmzah;
	private String madeDate;
	private String homePage;
	private String staxc;
	private String erpxRegi;
	private String compGrade;
	private String creditRating;
	private String limitAmount;
	private String limitCurrency;
	private String expCompCode;
	private String expCntCode;
	private String watchGrade;
	private String compLevl1;
	private String compLevl2;
	@NotBlank(message="영업조직{errors.required}")
	private String vkorg;
	private String vkorgText;
	private String erpRegYn;
	private String salesEmpName;
	private String kvgr3;
//	@NotBlank(message="대표자 생년월일{errors.required}")
	private String ceoBirthday;
	private String limitExpYmd;
	@Max2Byte(value=15, eng=30, message="대표자명2{errors.maxlength.kor}")
	private String ceoFullNm;
	@Max2Byte(value=15, eng=30, message="추가 대표자명{errors.maxlength.kor}")
	private String ceoEtcNm;
//	@Max2Byte(value=25, eng=50, message="주요거래품목{errors.maxlength.kor}")
	private String tradeItem;
	private String reportYn;
	private String reportType;
	private String reportTypeText;
	private String stockYn;
//	@Max2Byte(value=50, eng=100, message="대표자와 LG의 관계{errors.maxlength.kor}")
	private String relationLg;
	@Valid
	private OrganVO organVO;

	private String scFrYmd;
	private String scToYmd;

	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getKtokd() {
		return ktokd;
	}
	public void setKtokd(String ktokd) {
		this.ktokd = ktokd;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getJ1kfrepre() {
		return j1kfrepre;
	}
	public void setJ1kfrepre(String j1kfrepre) {
		this.j1kfrepre = j1kfrepre;
	}
	public String getStcd2() {
		return stcd2;
	}
	public void setStcd2(String stcd2) {
		this.stcd2 = stcd2;
	}
	public String getSortl() {
		return sortl;
	}
	public void setSortl(String sortl) {
		this.sortl = sortl;
	}
	public String getLand1() {
		return land1;
	}
	public void setLand1(String land1) {
		this.land1 = land1;
	}
	public String getPostlz() {
		return postlz;
	}
	public void setPostlz(String postlz) {
		this.postlz = postlz;
	}
	public String getStras() {
		return stras;
	}
	public void setStras(String stras) {
		this.stras = stras;
	}
	public String getPostlz2() {
		return postlz2;
	}
	public void setPostlz2(String postlz2) {
		this.postlz2 = postlz2;
	}
	public String getStras2() {
		return stras2;
	}
	public void setStras2(String stras2) {
		this.stras2 = stras2;
	}
	public String getLzone() {
		return lzone;
	}
	public void setLzone(String lzone) {
		this.lzone = lzone;
	}
	public String getStkzu() {
		return stkzu;
	}
	public void setStkzu(String stkzu) {
		this.stkzu = stkzu;
	}
	public String getTelf1() {
		return telf1;
	}
	public void setTelf1(String telf1) {
		this.telf1 = telf1;
	}
	public String getJ1kftbus() {
		return j1kftbus;
	}
	public void setJ1kftbus(String j1kftbus) {
		this.j1kftbus = j1kftbus;
	}
	public String getJ1kftind() {
		return j1kftind;
	}
	public void setJ1kftind(String j1kftind) {
		this.j1kftind = j1kftind;
	}
	public int getUmsat() {
		return umsat;
	}
	public void setUmsat(int umsat) {
		this.umsat = umsat;
	}
	public int getJmzah() {
		return jmzah;
	}
	public void setJmzah(int jmzah) {
		this.jmzah = jmzah;
	}
	public String getMadeDate() {
		return madeDate;
	}
	public void setMadeDate(String madeDate) {
		this.madeDate = madeDate;
	}
	public String getHomePage() {
		return homePage;
	}
	public void setHomePage(String homePage) {
		this.homePage = homePage;
	}
	public String getStaxc() {
		return staxc;
	}
	public void setStaxc(String staxc) {
		this.staxc = staxc;
	}
	public String getErpxRegi() {
		return erpxRegi;
	}
	public void setErpxRegi(String erpxRegi) {
		this.erpxRegi = erpxRegi;
	}
	public String getCompGrade() {
		return compGrade;
	}
	public void setCompGrade(String compGrade) {
		this.compGrade = compGrade;
	}
	public String getCreditRating() {
		return creditRating;
	}
	public void setCreditRating(String creditRating) {
		this.creditRating = creditRating;
	}
	public String getLimitAmount() {
		return limitAmount;
	}
	public void setLimitAmount(String limitAmount) {
		this.limitAmount = limitAmount;
	}
	public String getLimitCurrency() {
		return limitCurrency;
	}
	public void setLimitCurrency(String limitCurrency) {
		this.limitCurrency = limitCurrency;
	}
	public String getExpCompCode() {
		return expCompCode;
	}
	public void setExpCompCode(String expCompCode) {
		this.expCompCode = expCompCode;
	}
	public String getExpCntCode() {
		return expCntCode;
	}
	public void setExpCntCode(String expCntCode) {
		this.expCntCode = expCntCode;
	}
	public String getWatchGrade() {
		return watchGrade;
	}
	public void setWatchGrade(String watchGrade) {
		this.watchGrade = watchGrade;
	}
	public String getCompLevl1() {
		return compLevl1;
	}
	public void setCompLevl1(String compLevl1) {
		this.compLevl1 = compLevl1;
	}
	public String getCompLevl2() {
		return compLevl2;
	}
	public void setCompLevl2(String compLevl2) {
		this.compLevl2 = compLevl2;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public OrganVO getOrganVO() {
		return organVO;
	}
	public void setOrganVO(OrganVO organVO) {
		this.organVO = organVO;
	}
	public String getTelf2() {
		return telf2;
	}
	public void setTelf2(String telf2) {
		this.telf2 = telf2;
	}
	public String getTelf3() {
		return telf3;
	}
	public void setTelf3(String telf3) {
		this.telf3 = telf3;
	}
	public String getErpRegYn() {
		return erpRegYn;
	}
	public void setErpRegYn(String erpRegYn) {
		this.erpRegYn = erpRegYn;
	}
	public String getSalesEmpName() {
		return salesEmpName;
	}
	public void setSalesEmpName(String salesEmpName) {
		this.salesEmpName = salesEmpName;
	}
	public String getKvgr3() {
		return kvgr3;
	}
	public void setKvgr3(String kvgr3) {
		this.kvgr3 = kvgr3;
	}
	public String getVkorgText() {
		return vkorgText;
	}
	public void setVkorgText(String vkorgText) {
		this.vkorgText = vkorgText;
	}
	public String getTelf1Full() {
		return telf1Full;
	}
	public void setTelf1Full(String telf1Full) {
		this.telf1Full = telf1Full;
	}
	public String getFax1() {
		return fax1;
	}
	public void setFax1(String fax1) {
		this.fax1 = fax1;
	}
	public String getFax2() {
		return fax2;
	}
	public void setFax2(String fax2) {
		this.fax2 = fax2;
	}
	public String getFax3() {
		return fax3;
	}
	public void setFax3(String fax3) {
		this.fax3 = fax3;
	}
	public String getTelfx() {
		return telfx;
	}
	public void setTelfx(String telfx) {
		this.telfx = telfx;
	}
	public String getStrasPre() {
		return strasPre;
	}
	public void setStrasPre(String strasPre) {
		this.strasPre = strasPre;
	}
	public String getStras2Pre() {
		return stras2Pre;
	}
	public void setStras2Pre(String stras2Pre) {
		this.stras2Pre = stras2Pre;
	}
	public String getCeoBirthday() {
		return ceoBirthday;
	}
	public void setCeoBirthday(String ceoBirthday) {
		this.ceoBirthday = ceoBirthday;
	}
	public String getLimitExpYmd() {
		return limitExpYmd;
	}
	public void setLimitExpYmd(String limitExpYmd) {
		this.limitExpYmd = limitExpYmd;
	}
	public String getCeoFullNm() {
		return ceoFullNm;
	}
	public void setCeoFullNm(String ceoFullNm) {
		this.ceoFullNm = ceoFullNm;
	}
	public String getCeoEtcNm() {
		return ceoEtcNm;
	}
	public void setCeoEtcNm(String ceoEtcNm) {
		this.ceoEtcNm = ceoEtcNm;
	}
	public String getStrasFull() {
		return strasFull;
	}
	public void setStrasFull(String strasFull) {
		this.strasFull = strasFull;
	}
	public String getStras2Full() {
		return stras2Full;
	}
	public void setStras2Full(String stras2Full) {
		this.stras2Full = stras2Full;
	}
	public String getPartnerYn() {
		return partnerYn;
	}
	public void setPartnerYn(String partnerYn) {
		this.partnerYn = partnerYn;
	}
	public String getTradeItem() {
		return tradeItem;
	}
	public void setTradeItem(String tradeItem) {
		this.tradeItem = tradeItem;
	}
	public String getReportYn() {
		return reportYn;
	}
	public void setReportYn(String reportYn) {
		this.reportYn = reportYn;
	}
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	public String getStockYn() {
		return stockYn;
	}
	public void setStockYn(String stockYn) {
		this.stockYn = stockYn;
	}
	public String getRelationLg() {
		return relationLg;
	}
	public void setRelationLg(String relationLg) {
		this.relationLg = relationLg;
	}
	public String getReportTypeText() {
		return reportTypeText;
	}
	public void setReportTypeText(String reportTypeText) {
		this.reportTypeText = reportTypeText;
	}
	public String getScFrYmd() {
		return scFrYmd;
	}
	public void setScFrYmd(String scFrYmd) {
		this.scFrYmd = scFrYmd;
	}
	public String getScToYmd() {
		return scToYmd;
	}
	public void setScToYmd(String scToYmd) {
		this.scToYmd = scToYmd;
	}
}
