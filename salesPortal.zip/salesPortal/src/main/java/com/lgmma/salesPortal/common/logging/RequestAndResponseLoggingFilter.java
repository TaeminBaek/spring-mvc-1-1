package com.lgmma.salesPortal.common.logging;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import com.lgmma.salesPortal.app.service.HttpLogService;
import com.lgmma.salesPortal.common.model.LogVO;

@Component(value="httpLoggingFilter")
//@WebFilter(urlPatterns="/*")
//@Order(10)
public class RequestAndResponseLoggingFilter extends OncePerRequestFilter {

	@Autowired
	private HttpLogService httpLogService;
	private static final List<String> EXCLUDE_PATHS = Arrays.asList("/favicon.ico", "/web-resource/**");

	private boolean includeResponsePayload = true;
	private int maxPayloadLength = 1500;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		AntPathMatcher pathMatcher = new AntPathMatcher();
		boolean excludePath = false;
		for(String pattern : EXCLUDE_PATHS) {
			excludePath = pathMatcher.matchStart(pattern, request.getRequestURI());
			if(excludePath)
				break;
		}
		if(!excludePath) {
			LogVO log = new LogVO();
	        log.setRequestTime(new Date());
	        log.setHttpMethod(request.getMethod());
	        log.setPath(request.getRequestURI());
	        log.setClientIp(request.getRemoteAddr());
	        log.setUserId(request.getUserPrincipal() != null ? request.getUserPrincipal().getName() : "");

			ContentCachingRequestWrapper wrappedRequest = new ContentCachingRequestWrapper(request);
			ContentCachingResponseWrapper wrappedResponse = new ContentCachingResponseWrapper(response);

			filterChain.doFilter(wrappedRequest, wrappedResponse); // ======== This performs the actual request!

			String requestBody = this.getContentAsString(wrappedRequest.getContentAsByteArray(), this.maxPayloadLength,
					request.getCharacterEncoding());
			if (requestBody.length() > 0) {
		        log.setRequestBody(requestBody);
			}

	        log.setParameterMap(this.getTypeSafeRequest(request));
			log.setResponseTime(new Date());
	        log.setHttpStatus(response.getStatus());
			if (includeResponsePayload && request.getRequestURI().indexOf("/fileDownload") < 0) {
				byte[] buf = wrappedResponse.getContentAsByteArray();
		        log.setResponseBody(getContentAsString(buf, this.maxPayloadLength, response.getCharacterEncoding()));
			}

			httpLogService.createLog(log);
			wrappedResponse.copyBodyToResponse(); // IMPORTANT: copy content of response back into original response
		} else {
			filterChain.doFilter(request, response); // 로깅할 url 이 아니면 다음 필터로...
		}
	}

	private String getContentAsString(byte[] buf, int maxLength, String charsetName) {
		if (buf == null || buf.length == 0)
			return "";
		int length = Math.min(buf.length, this.maxPayloadLength);
		try {
			return new String(buf, 0, length, charsetName);
		} catch (UnsupportedEncodingException ex) {
			return "Unsupported Encoding";
		}
	}

	//사용자 입력 패스워드 등을 남기지 않기 위해서...
	private String getTypeSafeRequest(HttpServletRequest request) {
		StringBuffer buf = new StringBuffer();
		Enumeration<?> requestParamNames = request.getParameterNames();
		while (requestParamNames.hasMoreElements()) {
			String requestParamName = (String) requestParamNames.nextElement();
			String requestParamValue = "";
			if (requestParamName.equalsIgnoreCase("mbbPwd")) {
				requestParamValue = "********";
			} else {
				requestParamValue = request.getParameter(requestParamName);
			}
			buf.append(requestParamName + "=[" + requestParamValue + "]");
		}
		return getContentAsString(buf.toString().getBytes(), this.maxPayloadLength, request.getCharacterEncoding());
	}
}