package com.lgmma.salesPortal.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.dao.CommonFileDao;
import com.lgmma.salesPortal.app.model.FileVO;
import com.lgmma.salesPortal.app.service.CommonFileService;
import com.lgmma.salesPortal.common.props.FilePath;
import com.lgmma.salesPortal.common.util.FileUploadUtil;

@Service
public class CommonFileServiceImpl implements CommonFileService {

	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	@Autowired
	private FileUploadUtil fileUploadUtil;

	@Autowired
	private CommonFileDao commonFileDao;

	@Override
	public int getFileListCount(FileVO fileVO) {
		return commonFileDao.getFileListCnt(fileVO);
	}

	@Override
	public List<FileVO> getFileList(FileVO fileVO) {
		List<FileVO> fileList = commonFileDao.getFileList(fileVO);
		for(FileVO fileVo : fileList) {
			fileVo.setDownLoadUrl(messageSourceAccessor.getMessage("file.download.url") + fileVo.getFileItemId());
		}
		return fileList;
	}

	@Override
	public FileVO getFileDetail(FileVO fileVO) {
		return commonFileDao.getFileDetail(fileVO);
	}

	@Override
	public void createFile(FileVO fileVO) {
		commonFileDao.createFile(fileVO);
	}

	@Override
	public void deleteFile(FileVO fileVO) {
		commonFileDao.deleteFile(fileVO);
	}

	@Override
	public void deleteFiles(FileVO fileVO) throws Exception {
		if(!fileVO.getFileList().isEmpty()) {
			for(FileVO delParamFileVO:fileVO.getFileList()) {
				FileVO delFileVO = getFileDetail(delParamFileVO);
				String delFilePath = messageSourceAccessor.getMessage(FilePath.getFilePath(delFileVO.getFilePathCd()).getFilePathProp(), "");
				deleteFile(delParamFileVO);										// DB 파일정보 삭제
				fileUploadUtil.deleteFile(delFilePath, delFileVO.getFileNm());	// 실제 파일 삭제
			}
		}
	}

	@Override
	public void deleteFilesByFileId(String fileId) throws Exception {
		FileVO paramVO = new FileVO();
		paramVO.setFileId(fileId);
		FileVO fileVO = new FileVO();
		fileVO.setFileList(getFileList(paramVO));
		deleteFiles(fileVO);
	}
}
