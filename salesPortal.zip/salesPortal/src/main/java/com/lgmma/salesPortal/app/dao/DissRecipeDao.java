package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissRecipeVO;

public interface DissRecipeDao {
	
	List<DissRecipeVO> getDissRecipeList(DissRecipeVO param);
	
	void createDissRecipe(DissRecipeVO param);
	
	void updateDissRecipe(DissRecipeVO param);
	
	void deleteDissRecipeAll(DissRecipeVO param);
	

}
