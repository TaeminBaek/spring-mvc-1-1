package com.lgmma.salesPortal;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;
import org.springframework.web.servlet.support.AbstractDispatcherServletInitializer;

public class SecurityInitializer extends AbstractSecurityWebApplicationInitializer 
{
	@Override
	protected String getDispatcherWebApplicationContextSuffix() {
		return AbstractDispatcherServletInitializer.DEFAULT_SERVLET_NAME;
	}
	
	/**
	 * Override this if HttpSessionEventPublisher should be added as a listener. 
	 * This should be true, if session management has specified a maximum number of sessions.
	 */
	@Override
	protected boolean enableHttpSessionEventPublisher() {
		return true;
	}
}
