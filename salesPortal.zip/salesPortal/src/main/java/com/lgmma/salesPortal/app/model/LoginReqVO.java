package com.lgmma.salesPortal.app.model;

public class LoginReqVO extends PagingParamVO {

	private int reqxNumx;
	private int compCode;
	private int userNumx;
	private String lognIdxx;
	private String lognPwdx;
	private String lognName;
	private String mailAddr;
	private String deptName;
	private String deptPosi;
	private String telxNum1;
	private String telxNum2;
	private String telxNum3;
	private String bizxNumx;
	private String postCode;
	private String postAddr1;
	private String postAddr2;
	private String hpxxNum1;
	private String hpxxNum2;
	private String hpxxNum3;
	private String prodPmma;
	private String prodMma;
	private String compName;
	private String ceoxName;
	private String bigoText;
	private String servGrad;
	private String reqxDate;
	private String rejectReason;
	private String deptIdxx;
	private String deptPmma;

	public int getReqxNumx() {
		return reqxNumx;
	}
	public void setReqxNumx(int reqxNumx) {
		this.reqxNumx = reqxNumx;
	}
	public String getLognIdxx() {
		return lognIdxx;
	}
	public void setLognIdxx(String lognIdxx) {
		this.lognIdxx = lognIdxx;
	}
	public String getLognPwdx() {
		return lognPwdx;
	}
	public void setLognPwdx(String lognPwdx) {
		this.lognPwdx = lognPwdx;
	}
	public String getLognName() {
		return lognName;
	}
	public void setLognName(String lognName) {
		this.lognName = lognName;
	}
	public String getMailAddr() {
		return mailAddr;
	}
	public void setMailAddr(String mailAddr) {
		this.mailAddr = mailAddr;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptPosi() {
		return deptPosi;
	}
	public void setDeptPosi(String deptPosi) {
		this.deptPosi = deptPosi;
	}
	public String getTelxNum1() {
		return telxNum1;
	}
	public void setTelxNum1(String telxNum1) {
		this.telxNum1 = telxNum1;
	}
	public String getTelxNum2() {
		return telxNum2;
	}
	public void setTelxNum2(String telxNum2) {
		this.telxNum2 = telxNum2;
	}
	public String getTelxNum3() {
		return telxNum3;
	}
	public void setTelxNum3(String telxNum3) {
		this.telxNum3 = telxNum3;
	}
	public String getBizxNumx() {
		return bizxNumx;
	}
	public void setBizxNumx(String bizxNumx) {
		this.bizxNumx = bizxNumx;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getPostAddr1() {
		return postAddr1;
	}
	public void setPostAddr1(String postAddr1) {
		this.postAddr1 = postAddr1;
	}
	public String getPostAddr2() {
		return postAddr2;
	}
	public void setPostAddr2(String postAddr2) {
		this.postAddr2 = postAddr2;
	}
	public String getHpxxNum1() {
		return hpxxNum1;
	}
	public void setHpxxNum1(String hpxxNum1) {
		this.hpxxNum1 = hpxxNum1;
	}
	public String getHpxxNum2() {
		return hpxxNum2;
	}
	public void setHpxxNum2(String hpxxNum2) {
		this.hpxxNum2 = hpxxNum2;
	}
	public String getHpxxNum3() {
		return hpxxNum3;
	}
	public void setHpxxNum3(String hpxxNum3) {
		this.hpxxNum3 = hpxxNum3;
	}
	public String getProdPmma() {
		return prodPmma;
	}
	public void setProdPmma(String prodPmma) {
		this.prodPmma = prodPmma;
	}
	public String getProdMma() {
		return prodMma;
	}
	public void setProdMma(String prodMma) {
		this.prodMma = prodMma;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getCeoxName() {
		return ceoxName;
	}
	public void setCeoxName(String ceoxName) {
		this.ceoxName = ceoxName;
	}
	public String getBigoText() {
		return bigoText;
	}
	public void setBigoText(String bigoText) {
		this.bigoText = bigoText;
	}
	public String getServGrad() {
		return servGrad;
	}
	public void setServGrad(String servGrad) {
		this.servGrad = servGrad;
	}
	public String getReqxDate() {
		return reqxDate;
	}
	public void setReqxDate(String reqxDate) {
		this.reqxDate = reqxDate;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public String getDeptIdxx() {
		return deptIdxx;
	}
	public void setDeptIdxx(String deptIdxx) {
		this.deptIdxx = deptIdxx;
	}
	public String getDeptPmma() {
		return deptPmma;
	}
	public void setDeptPmma(String deptPmma) {
		this.deptPmma = deptPmma;
	}
	public int getCompCode() {
		return compCode;
	}
	public void setCompCode(int compCode) {
		this.compCode = compCode;
	}
	public int getUserNumx() {
		return userNumx;
	}
	public void setUserNumx(int userNumx) {
		this.userNumx = userNumx;
	}
}
