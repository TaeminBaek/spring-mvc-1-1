package com.lgmma.salesPortal.app.dao.impl;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.SampleDao;
import com.lgmma.salesPortal.app.model.SampleVO;

@Repository
public class SampleDaoImpl implements SampleDao {

    private static final String MAPPER_NAMESPACE = "SAMPLE_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public List<SampleVO> getSample(SampleVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSample", param);
	}
	
	@Override
	public int getSampleCount(SampleVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getSampleCount", param);
	}

	@Override
	public void updateSample(SampleVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateSample", param);
	}
	
	@Override
	public void createSample(SampleVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createSample", param);
	}
	
	@Override
	public void deleteSample(SampleVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "deleteSample", param);
	}

}
