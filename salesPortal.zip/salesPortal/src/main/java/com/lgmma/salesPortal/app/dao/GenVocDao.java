package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.GenVocVO;


public interface GenVocDao {
	

	List<GenVocVO> getGenVocItemList();
	
	int getGenVocCount(GenVocVO param);
	
	List<GenVocVO> getGenVocList(GenVocVO param);

	GenVocVO getGenVocDetail(GenVocVO param);
	
	List<GenVocVO> getGenVocReply(GenVocVO param);
	
	void updateGenVocReply(GenVocVO param);

	void createGenVocReply(GenVocVO param);
	
	void deleteGenVocReply(GenVocVO param);
	
	void updateGenVocEmailSendYn(GenVocVO param);
}
