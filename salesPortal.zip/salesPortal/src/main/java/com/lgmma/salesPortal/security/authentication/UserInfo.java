package com.lgmma.salesPortal.security.authentication;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

import org.springframework.security.core.CredentialsContainer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.SpringSecurityCoreVersion;
import org.springframework.security.core.userdetails.UserDetails;

import com.lgmma.salesPortal.common.model.MenuItem;

import freemarker.template.utility.StringUtil;

public class UserInfo implements CredentialsContainer, UserDetails {

	private static final long serialVersionUID = SpringSecurityCoreVersion.SERIAL_VERSION_UID;
	
	private Collection<GrantedAuthority> authorities = new TreeSet<GrantedAuthority>();
	
	private final boolean accountNonExpired;

	private final boolean accountNonLocked;

	private final boolean credentialsNonExpired;

	private boolean enabled = true;
	private String password;

	private String sawnCode;
	private String sawnName;
	private String sawnIdxx;
	private String mailAddr;
	private String jiklCode;
	private String salesManYn;
	private String teamCode;
	private String teamName;
	private String posiCode;
	private String posiName;
	private String vkorg;
	private String adminYn;
	
	//사용자 타입 P : 파트너 E : 임직원
	private String userType;
	//모든 판가 등록/수정 권한
	private String salePriceAdminYn;

	//파트너사 전용
	private String compCode;
	private String compName;
	private String kunnr;
	private boolean pwdExpired = false;
	private String hpxxNum;

	
	//사용자 메뉴 Map
	private Map<String, MenuItem> allowedMenuMap = new HashMap<String, MenuItem>();

	public Map<String, MenuItem> getAllowedMenuMap() {
		return allowedMenuMap;
	}

	public void setAllowedMenuMap(Map<String, MenuItem> allowedMenuMap) {
		this.allowedMenuMap = allowedMenuMap;
	}	

	public UserInfo() {
		this.accountNonExpired = true;
		this.accountNonLocked = true;
		this.credentialsNonExpired = true;
	}
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return this.authorities;
	}

	@Override
	public boolean isAccountNonExpired() {
		return this.accountNonExpired;
	}

	@Override
	public boolean isAccountNonLocked() {
		return this.accountNonLocked;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return this.credentialsNonExpired;
	}
	@Override
	public String getPassword() {
		return this.password;
	}
	@Override
	public String getUsername() {
		return this.sawnCode;
	}
	@Override
	public boolean isEnabled() {
		return this.enabled;
	}
	@Override
	public void eraseCredentials() {
		this.password = "";
	}
	public void setAuthorities(Collection<GrantedAuthority> authorities) {
		this.authorities = authorities;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSawnCode() {
		return sawnCode;
	}

	public void setSawnCode(String sawnCode) {
		this.sawnCode = sawnCode;
	}

	public String getSawnName() {
		return sawnName;
	}

	public void setSawnName(String sawnName) {
		this.sawnName = sawnName;
	}

	public String getSawnIdxx() {
		return sawnIdxx;
	}

	public void setSawnIdxx(String sawnIdxx) {
		this.sawnIdxx = sawnIdxx;
	}

	public String getMailAddr() {
		return mailAddr;
	}

	public void setMailAddr(String mailAddr) {
		this.mailAddr = mailAddr;
	}

	public String getTeamCode() {
		return teamCode;
	}

	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getPosiCode() {
		return posiCode;
	}

	public void setPosiCode(String posiCode) {
		this.posiCode = posiCode;
	}

	public String getPosiName() {
		return posiName;
	}

	public void setPosiName(String posiName) {
		this.posiName = posiName;
	}

	public String getAdminYn() {
		return adminYn;
	}

	public void setAdminYn(String adminYn) {
		this.adminYn = adminYn;
	}

	public boolean isAdmin() {
		return StringUtil.getYesNo(this.adminYn);
	}

	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getCompCode() {
		return compCode;
	}

	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}

	public String getCompName() {
		return compName;
	}

	public void setCompName(String compName) {
		this.compName = compName;
	}

	public String getKunnr() {
		return kunnr;
	}

	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public boolean isPwdExpired() {
		return pwdExpired;
	}

	public void setPwdExpired(boolean pwdExpired) {
		this.pwdExpired = pwdExpired;
	}

	public String getHpxxNum() {
		return hpxxNum;
	}

	public void setHpxxNum(String hpxxNum) {
		this.hpxxNum = hpxxNum;
	}

	public String getSalePriceAdminYn() {
		return salePriceAdminYn;
	}

	public void setSalePriceAdminYn(String salePriceAdminYn) {
		this.salePriceAdminYn = salePriceAdminYn;
	}

	public String getJiklCode() {
		return jiklCode;
	}

	public void setJiklCode(String jiklCode) {
		this.jiklCode = jiklCode;
	}

	public String getSalesManYn() {
		return salesManYn;
	}

	public void setSalesManYn(String salesManYn) {
		this.salesManYn = salesManYn;
	}

}
