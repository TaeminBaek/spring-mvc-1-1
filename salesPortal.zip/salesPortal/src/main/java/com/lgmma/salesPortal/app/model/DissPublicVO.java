package com.lgmma.salesPortal.app.model;

import java.util.List;

public class DissPublicVO extends PagingParamVO {

	private String taskId;                      //과제ID
	private String taskType;                    //과제구분
	private String stepId;                      //스텝ID
	private String stepCd;                      //스텝코드
	private String processType;                 //공정
	private String saveMode;                    // 저장유형
	private DissStepVO dissStepVO;              // 스텝VO
	private DissCompTaskVO dissCompTaskVO;      //과제개발완료VO
	private List<DissKpiVO> dissKpiList;        //KPI
	private ApprVO apprVO;                      //품의
	private DissCustTestVO dissCustTestVO;      //과제고객TEST결과VO
	private DissCustTestOrderVO dissCustTestOrderVO;            //DISS고객TEST결과견본ITEM별VO
	private List<DissCustTestOrderVO> dissCustTestOrderList;    //DISS고객TEST결과견본ITEM별List
	private DissMassTransVO dissMassTransVO;    //양산이관보고VO
	private DissCompGradeVO dissCompGradeVO;    //규격제정/개정VO
	private String reWriteRejectApprYn;         //반려재신청품의유무
	private String apprType;                    //품의유형
	
	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getStepCd() {
		return stepCd;
	}

	public void setStepCd(String stepCd) {
		this.stepCd = stepCd;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public DissCompTaskVO getDissCompTaskVO() {
		return dissCompTaskVO;
	}

	public void setDissCompTaskVO(DissCompTaskVO dissCompTaskVO) {
		this.dissCompTaskVO = dissCompTaskVO;
	}

	public List<DissKpiVO> getDissKpiList() {
		return dissKpiList;
	}

	public void setDissKpiList(List<DissKpiVO> dissKpiList) {
		this.dissKpiList = dissKpiList;
	}

	public ApprVO getApprVO() {
		return apprVO;
	}

	public void setApprVO(ApprVO apprVO) {
		this.apprVO = apprVO;
	}

	public DissCustTestVO getDissCustTestVO() {
		return dissCustTestVO;
	}

	public void setDissCustTestVO(DissCustTestVO dissCustTestVO) {
		this.dissCustTestVO = dissCustTestVO;
	}

	public DissCustTestOrderVO getDissCustTestOrderVO() {
		return dissCustTestOrderVO;
	}

	public void setDissCustTestOrderVO(DissCustTestOrderVO dissCustTestOrderVO) {
		this.dissCustTestOrderVO = dissCustTestOrderVO;
	}

	public List<DissCustTestOrderVO> getDissCustTestOrderList() {
		return dissCustTestOrderList;
	}

	public void setDissCustTestOrderList(List<DissCustTestOrderVO> dissCustTestOrderList) {
		this.dissCustTestOrderList = dissCustTestOrderList;
	}

	public DissMassTransVO getDissMassTransVO() {
		return dissMassTransVO;
	}

	public void setDissMassTransVO(DissMassTransVO dissMassTransVO) {
		this.dissMassTransVO = dissMassTransVO;
	}

	public DissCompGradeVO getDissCompGradeVO() {
		return dissCompGradeVO;
	}

	public void setDissCompGradeVO(DissCompGradeVO dissCompGradeVO) {
		this.dissCompGradeVO = dissCompGradeVO;
	}

	public DissStepVO getDissStepVO() {
		return dissStepVO;
	}

	public void setDissStepVO(DissStepVO dissStepVO) {
		this.dissStepVO = dissStepVO;
	}

	public String getSaveMode() {
		return saveMode;
	}

	public void setSaveMode(String saveMode) {
		this.saveMode = saveMode;
	}

	public String getReWriteRejectApprYn() {
		return reWriteRejectApprYn;
	}

	public void setReWriteRejectApprYn(String reWriteRejectApprYn) {
		this.reWriteRejectApprYn = reWriteRejectApprYn;
	}

	public String getApprType() {
		return apprType;
	}

	public void setApprType(String apprType) {
		this.apprType = apprType;
	}
}
