package com.lgmma.salesPortal.app.service;

import com.lgmma.salesPortal.app.model.SmsVO;


public interface SmsService {
	public void sendSms(SmsVO param);
}
