package com.lgmma.salesPortal.app.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissCommentVO;
import com.lgmma.salesPortal.app.model.DissDailyVO;
import com.lgmma.salesPortal.app.model.DissMemberVO;
import com.lgmma.salesPortal.app.model.DissPublicVO;
import com.lgmma.salesPortal.app.model.DissReviewVO;
import com.lgmma.salesPortal.app.model.DissSampleOrderMasterVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.DissDailyActService;
import com.lgmma.salesPortal.app.service.DissImpDevService;
import com.lgmma.salesPortal.app.service.DissPublicService;
import com.lgmma.salesPortal.app.service.DissSampleOrderService;
import com.lgmma.salesPortal.app.service.DissSpecInService;
import com.lgmma.salesPortal.common.exception.ServiceException;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;

import freemarker.template.Configuration;

/**
 * DISS 공용 컨트롤러
 */
@Controller
@RequestMapping("/dissPublic")
public class DissPublicController {

	private static Logger logger = LoggerFactory.getLogger(DissPublicController.class);

	private final String REPORT_TEMPLATE_DISS_PUBLIC_COMP_GRADE_APPR = "REPORT_TEMPLATE_DISS_PUBLIC_COMP_GRADE_APPR";
	private final String REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER_APPR = "REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER_APPR";
	
	@Autowired
	DissSpecInService dissSpecInService;

	@Autowired
	DissSampleOrderService dissSampleOrderService;

	@Autowired
	DissImpDevService dissImpDevService;

	@Autowired
	DissPublicService dissPublicService;
	
	@Autowired
	DissDailyActService dissDailyActService;

	@Autowired
	DissCommonApprMgmtService dissCommonApprMgmtService;

	@Autowired
	CommonController commonController;

	@Autowired
	DirectOrderController directOrderController;

	@Autowired
	@Qualifier(value="reportFreemarkerConfiguration")
	private Configuration reportTemplateConfiguration;

	@Autowired
    @Qualifier(value="excelFreemarkerConfiguration")
    private Configuration excelFreemarkerConfiguration;

	/**
	 * 공통 기본정보영역을 위한 과제기본정보조회
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getDissTaskBasicInfoDetail.json")
	public Map getDissPubTaskBasicInfo(@RequestBody(required = true) DissStepVO param) throws Exception {
		String taskType = param.getTaskType();

		if ("SPECIN".equals(taskType)) {
			DissSpecInVO dissSpecInHisVO = new DissSpecInVO();
			if(ApprType.APPR_TYPE_DISS_SPECIN_SCHEDULE_EDIT.getCode().equals(param.getApprType()) && !"".equals(param.getStepId())) {
				dissSpecInHisVO.setStepId(param.getStepId());
				dissSpecInHisVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInInfoHis(dissSpecInHisVO));
			}

			return JsonResponse.asSuccess("storeData", dissSpecInService.getDissSpecInTaskBasicInfoDetail(param), "dissSpecInHisVO", dissSpecInHisVO);
		} else if ("IMPDEV".equals(taskType)) {
			return JsonResponse.asSuccess("storeData", dissImpDevService.getDissImpDevTaskBasicInfoDetail(param));
		} else {
			throw new ServiceException("", "과제구분 정보가 잘못되었습니다.");
		}
	}

	/**
	 * 견본입력을 위한 과제기본정보조회
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getSampleOrderTaskBasicInfo.json")
	public Map getSampleOrderTaskBasicInfo(@RequestBody(required = true) DissSampleOrderMasterVO param) throws Exception {
		DissSampleOrderMasterVO dissSampleOrderMasterVO = dissSampleOrderService.getSampleOrderTaskBasicInfo(param);
		return JsonResponse.asSuccess("storeData", dissSampleOrderMasterVO);
	}
	/**
	 * 견본등록 품의서 템플릿
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getSampleOrderTemplate.json")
	public Map getSampleOrderTemplate(@RequestBody(required = true) DissPublicVO param) throws Exception {
		StringBuffer content = new StringBuffer();
		content.append(reportTemplateConfiguration.getTemplate(REPORT_TEMPLATE_DISS_PUBLIC_SAMPLE_ORDER_APPR + ".txt"));
		return JsonResponse.asSuccess("template",content.toString());
	}
	/**
	 * 견본 저장
	 * DissSampleOrderMasterVO.saveMode 값에 따라서 서비스에서 분기 처리한다.
	 *
	 * @param dissSampleOrderMasterVO
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveDissSampleOrder.json")
	public Map saveDissSampleOrder(@RequestBody(required = true) DissSampleOrderMasterVO dissSampleOrderMasterVO) throws Exception {
		dissSampleOrderMasterVO = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(dissSampleOrderMasterVO);
		dissSampleOrderService.saveDissSampleOrder(dissSampleOrderMasterVO);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	/**
	 * 견본정보 조회
	 *
	 * @param dissSampleOrderMasterVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/searchSampleOrderInfo.json")
	public Map searchSampleOrderInfo(@RequestBody(required = true) DissSampleOrderMasterVO dissSampleOrderMasterVO) throws Exception {
		dissSampleOrderMasterVO = (DissSampleOrderMasterVO) StringUtil.nullToEmptyString(dissSampleOrderMasterVO);
		return JsonResponse.asSuccess("storeData", dissSampleOrderService.searchSampleOrderInfo(dissSampleOrderMasterVO));
	}

	/**
	 * 견본품의 결재처리
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/applDissSampleOrder.json")
	public Map applDissSampleOrder(@RequestBody(required = true) DissApprCommonParamVO dissApprCommonParamVO) throws Exception {
		dissApprCommonParamVO = (DissApprCommonParamVO) StringUtil.nullToEmptyString(dissApprCommonParamVO);
		dissApprCommonParamVO.setApprEmpId(dissApprCommonParamVO.getUpdtIdxx()); // 결재자는 반드시 로그인한 사원으로 체크 한다.
		dissSampleOrderService.applDissSampleOrder(dissApprCommonParamVO);
		dissSampleOrderService.saveDissSampleOrderAfterApproval(dissApprCommonParamVO);
		return JsonResponse.asSuccess();
	}

	/**
	 * DISS 견본 리스트 조회
	 *
	 * @param dissSampleOrderMasterVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/selectDissSampleOrderMasterItemList.json")
	public Map selectDissSampleOrderMasterItemList(@RequestBody(required = true) DissSampleOrderMasterVO dissSampleOrderMasterVO) throws Exception {
		return JsonResponse.asSuccess("storeData", dissSampleOrderService.selectDissSampleOrderMasterItemList(dissSampleOrderMasterVO));
	}

	/**
	 * DISS 견본 리스트 조회(고객Test결과 신규등록)
	 * @param dissSampleOrderMasterVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/selectDissSampleOrderCustTestList.json")
	public Map selectDissSampleOrderCustTestList(@RequestBody(required = true) DissSampleOrderMasterVO dissSampleOrderMasterVO) throws Exception {
		return JsonResponse.asSuccess("storeData", dissSampleOrderService.selectDissSampleOrderCustTestList(dissSampleOrderMasterVO));
	}

	/**
	 * DISS 견본 리스트 조회(고객Test결과 등록내역)
	 *
	 * @param dissSampleOrderMasterVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/selectDissSampleOrderCustTestOrderList.json")
	public Map selectDissSampleOrderCustTestOrderList(@RequestBody(required = true) DissSampleOrderMasterVO dissSampleOrderMasterVO) throws Exception {
		return JsonResponse.asSuccess("storeData", dissSampleOrderService.selectDissSampleOrderCustTestOrderList(dissSampleOrderMasterVO));
	}



	/**
	 * Daily 활동 조회 화면
	 * @param mav
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/dissPublicDailyActMgmt")
	public ModelAndView dissPublicDailyActMgmt(ModelAndView mav ) throws Exception {
		mav.setViewName("dissPublic/dissPublicDailyActMgmt");
		mav.addObject("defaultFrDay", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-12)));
		mav.addObject("defaultToDay", DateUtil.defaultFormatDate(DateUtil.getToday()));
		return mav;
	}
	
	/**
	 * Daily 목록 조회
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/getDissDailyActList.json")
	public Map getDissDailyActList(@RequestBody(required = true) DissDailyVO param) throws Exception {
		param = (DissDailyVO) StringUtil.nullToEmptyString(param);
		return JsonResponse.asSuccess("itemsCount", dissDailyActService.getDissDailyActListCount(param), "storeData", dissDailyActService.getDissDailyActList(param));
	}
	
	/**
	 * Daily 활동 저장
	 * @param  dissDailyVO
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveDissDailyAct.json")
	public Map saveDissDailyAct(@RequestBody(required = true) DissDailyVO dissDailyVO) throws Exception {
		dissDailyVO = (DissDailyVO) StringUtil.nullToEmptyString(dissDailyVO);
		dissDailyActService.saveDissDailyAct(dissDailyVO);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}
	/**
	 * Daily 활동 초기정보 조회 (신규등록시 사용)
	 * @param  dissDailyVO
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/getDissDailyActInfo.json")
	public Map getDissDailyActInfo(@RequestBody(required = true) DissDailyVO param) throws Exception {
		DissDailyVO dissDailyVO = (DissDailyVO) StringUtil.nullToEmptyString(dissDailyActService.getDissDailyActInfo(param));
		return JsonResponse.asSuccess("storeData", dissDailyVO);
	}
	
	/**
	 * Daily 활동 정보 조회
	 * @param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/getDissDailyActDetail.json")
	public Map getDissDailyActDetail(@RequestBody(required = true) DissDailyVO param) throws Exception {
		DissDailyVO dissDailyVO = (DissDailyVO) StringUtil.nullToEmptyString(dissDailyActService.getDissDailyActDetail(param));
		return JsonResponse.asSuccess("storeData", dissDailyVO);
	}

	/**
	 * 마지막 입력된 해당 고객 Daily 활동 정보 조회(로그인한 사원 기준)
	 * @param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/getDissDailyActDetailLast.json")
	public Map getDissDailyActDetailLast(@RequestBody(required = true) DissDailyVO param) throws Exception {
		DissDailyVO dissDailyVO = dissDailyActService.getDissDailyActDetailLast(param);
		if(dissDailyVO == null){
			dissDailyVO = new DissDailyVO();
			dissDailyVO = (DissDailyVO) StringUtil.nullToEmptyString(dissDailyVO);
		}else{
			dissDailyVO = (DissDailyVO) StringUtil.nullToEmptyString(dissDailyVO);
		}
		return JsonResponse.asSuccess("storeData", dissDailyVO);
	}

	/**
	 * Daily 활동 삭제
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/deleteDissDailyAct.json")
	public Map deleteDissDailyAct(@RequestBody(required = true) DissDailyVO param ) throws Exception {
		param = (DissDailyVO) StringUtil.nullToEmptyString(param);
		dissDailyActService.deleteDissDailyAct(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * Daily 활동 결재처리
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveDissDailyActApprovalAction.json")
	public Map saveDissDailyActApprovalAction(@RequestBody(required = true) DissApprCommonParamVO param) throws Exception {
		param = (DissApprCommonParamVO) StringUtil.nullToEmptyString(param);
		param.setApprEmpId(param.getUpdtIdxx()); // 결재자는 반드시 로그인한 사원으로 체크 한다.
		dissDailyActService.saveDissDailyActApprovalAction(param);
		return JsonResponse.asSuccess();
	}
	
	/**
	 * Daily 통계 조회 화면
	 * @param mav
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/dissPublicDailyActStatInfo")
	public ModelAndView dissPublicDailyActStatInfo(ModelAndView mav ) throws Exception {
		mav.setViewName("dissPublic/dissPublicDailyActStatInfo");
		mav.addObject("defaultScYyyy", DateUtil.getCurrentYear());
		return mav;
	}
	
	/**
	 * Daily 통계 조회
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/getDissDailyActStatList.json")
	public Map getDissDailyActStatList(@RequestBody(required = true) DissDailyVO param) throws Exception {
		param = (DissDailyVO) StringUtil.nullToEmptyString(param);
		return JsonResponse.asSuccess("storeData", dissDailyActService.getDissDailyActStatList(param));
	}
	/**
	 * 규격제정/개정 품의서 템플릿
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getCompGradeApprTemplate.json")
	public Map getCompGradeApprTemplate(@RequestBody(required = true) DissPublicVO param) throws Exception {
		StringBuffer content = new StringBuffer();
		content.append(reportTemplateConfiguration.getTemplate(REPORT_TEMPLATE_DISS_PUBLIC_COMP_GRADE_APPR + ".txt"));
		return JsonResponse.asSuccess("template",content.toString());
	}

	/**
	 * DISS 품의서유형별 상세 조회
	 *
	 * @param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getDissPublicApprTypeDetail.json")
	public Map getDissPublicApprTypeDetail(@RequestBody(required = true) DissStepVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissPublicService.getDissPublicApprTypeDetail(param));
	}

	/**
	 * DISS 품의서 유형별 저장 (WinPop)
	 */
	@RequestMapping(value = "/saveDissPublicApprType.json")
	public Map saveDissPublicApprType(@RequestBody DissPublicVO param) throws Exception {
		String saveMode = param.getSaveMode();
		if(saveMode.equals("TMP") || saveMode.equals("REQ")) {
			dissPublicService.saveDissPublicApprType(param); //임시저장, 결재의뢰
		}else if(saveMode.equals("REW")) {
			dissPublicService.saveDissPublicApprTypeRew(param); //반려재신청
		}else if(saveMode.equals("DEL")) {
			dissPublicService.deleteDissPublicApprType(param); //삭제
		}		
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	/**
	 * DISS 품의서 결재액션
	 */
	@RequestMapping(value = "/saveDissPublicApprovalAction.json")
	public Map saveDissPublicApprovalAction(@RequestBody DissStepVO param) throws Exception {
		dissPublicService.saveDissPublicApprovalAction(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	/**
	 * DISS 품의서 댓글 등록액션
	 */
	@RequestMapping(value = "/createComment.json")
	public Map createComment(@RequestBody DissCommentVO param) throws Exception {
//		if(!dissPublicService.createCommentYn(param)) { return JsonResponse.asFailure("작성 권한이 없습니다"); }

		dissPublicService.createComment(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/resendCommentMail.json")
	public Map resendCommentMail(@RequestBody DissCommentVO param) throws Exception {
		dissPublicService.sendCommentMail(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	/**
	 * DISS 품의서 댓글 등록액션 권한 체크
	 */
	@RequestMapping(value = "/createCommentYn.json")
	public Map createCommentYn(@RequestBody DissCommentVO param) throws Exception {
		if(dissPublicService.createCommentYn(param))
			return JsonResponse.asSuccess("storeData", "Y");
		else
			return JsonResponse.asSuccess("storeData", "N");
			
	}
	
	/**
	 * DISS 품의서 댓글 조회
	 */
	@RequestMapping(value = "/getCommentList.json")
	public Map getCommentList(@RequestBody DissCommentVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissPublicService.getCommentList(param), "itemsCount", dissPublicService.getCommentListCount(param));
	}
	
	/**
	 * DISS 품의서 Review 등록액션
	 */
	@RequestMapping(value = "/createReviewReq.json")
	public Map createReviewReq(@RequestBody DissReviewVO param) throws Exception {
		dissPublicService.createReviewReq(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	/**
	 * DISS 품의서 Review 등록액션
	 */
	@RequestMapping(value = "/createReviewAns.json")
	public Map createReviewAns(@RequestBody DissReviewVO param) throws Exception {
		dissPublicService.createReviewAns(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	/**
	 * DISS 품의서 Review 조회
	 */
	@RequestMapping(value = "/getReviewList.json")
	public Map getReviewList(@RequestBody DissReviewVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissPublicService.getReviewList(param), "itemsCount", dissPublicService.getReviewListCount(param));
	}

	/**
	 * 견본일정공지 조회
	 *
	 * @param dissPublicVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/searchSampleOrderNoticeInfo.json")
	public Map searchSampleOrderNoticeInfo(@RequestBody(required = true) DissPublicVO dissPublicVO) throws Exception {
		dissPublicVO = (DissPublicVO) StringUtil.nullToEmptyString(dissPublicVO);
		return JsonResponse.asSuccess("storeData", dissPublicService.searchSampleOrderNoticeInfo(dissPublicVO));
	}

	/**
	 * 견본일정공지 저장
	 *
	 * @param dissPublicVO
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveSampleOrderNotice.json")
	public Map saveSampleOrderNotice(@RequestBody(required = true) DissPublicVO dissPublicVO) throws Exception {
		dissPublicVO = (DissPublicVO) StringUtil.nullToEmptyString(dissPublicVO);
		dissPublicService.saveSampleOrderNotice(dissPublicVO);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	/**
	 * 견본일정공지 결재처리
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/applSampleOrderNotice.json")
	public Map applSampleOrderNotice(@RequestBody(required = true) DissApprCommonParamVO dissApprCommonParamVO) throws Exception {
		dissApprCommonParamVO = (DissApprCommonParamVO) StringUtil.nullToEmptyString(dissApprCommonParamVO);
		dissApprCommonParamVO.setApprEmpId(dissApprCommonParamVO.getUpdtIdxx()); // 결재자는 반드시 로그인한 사원으로 체크 한다.
		dissPublicService.applSampleOrderNotice(dissApprCommonParamVO);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	/**
	 * 공통 차수 생성 체크
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 */
	@RequestMapping(value = "/checkDissDegreeCreateAuth.json")
	public Map checkDissDegreeCreateAuth(@RequestBody(required = true) DissApprCommonParamVO dissApprCommonParamVO){
		dissApprCommonParamVO = (DissApprCommonParamVO) StringUtil.nullToEmptyString(dissApprCommonParamVO);
		return JsonResponse.asSuccess("storeData",dissCommonApprMgmtService.checkDissDegreeCreateAuth(dissApprCommonParamVO));
	}

	/**
	 * 공통 과제수정 체크
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 */
	@RequestMapping(value = "/checkDissTaskEditAuth")
	public Map checkDissTaskEditAuth(@RequestBody(required = true) DissApprCommonParamVO dissApprCommonParamVO){
		dissApprCommonParamVO = (DissApprCommonParamVO) StringUtil.nullToEmptyString(dissApprCommonParamVO);
		return JsonResponse.asSuccess("storeData",dissCommonApprMgmtService.checkDissTaskEditAuth(dissApprCommonParamVO));
	}

	@RequestMapping(value = "/dissSampleOrderMgmt")
	public ModelAndView dissSampleOrderMgmt(ModelAndView mav ) throws Exception {
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("orderTypeList", OrderType.values());
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		mav.addObject("apprStatList", commonController.getApprStateDDLB().get("items"));
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> codeMap = directOrderController.getOrderCode(OrderType.SAMPLE);
		mav.addObject("codeMap", mapper.writeValueAsString(codeMap));
		mav.setViewName("dissPublic/dissSampleOrderMgmt");
		return mav;
	}

	/**
	 * 견본관리 견본목록 조회
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/getSampleOrderList.json")
	public Map getSampleOrderList(@RequestBody(required = true) DissSampleOrderMasterVO param) {
		return JsonResponse.asSuccess("storeData", dissSampleOrderService.getSampleOrderList(param),"itemsCount",dissSampleOrderService.getSampleOrderCount(param));
	}
	
	/*
	 * GPortal 결재 회수
	 */
	@RequestMapping(value = "/cancelDissApproval")
	public Map cancelGPortalApproval(@RequestBody(required=true) Map<String, String> param) {
		dissCommonApprMgmtService.cancelGPortalApproval(param.get("apprId"), param.get("apprEmpId"), param.get("apprMessage"));
		return JsonResponse.asSuccess("success", "처리되었습니다.");
	}

	@RequestMapping(value = "/loadEmployList.json")
	public Map getEmployList(@RequestBody(required=true) Map<String, String> param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissPublicService.loadEmployList(param));
	}

	@RequestMapping(value = "/loadDissApprDoc.json")
	public Map loadDissApprDoc(@RequestBody(required=true) DissStepVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissCommonApprMgmtService.loadDissApprDoc(param));
	}

	@Transactional
	@RequestMapping(value = "/dissAddApprLine.json")
	public Map dissAddApprLine(@RequestBody(required=true) ApprVO param) throws Exception {
		dissCommonApprMgmtService.addApprLine(param);
		return JsonResponse.asSuccess("success", "처리되었습니다.");
	}

	@RequestMapping(value = "/getDissStepIngList.json")
	public Map getDissStepIngList(@RequestBody(required=true) DissStepVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissPublicService.getDissStepIngList(param));
	}

	@RequestMapping(value = "/getDefaultApprILine.json")
	public Map getDefaultApprILine(@RequestBody(required=true) DissMemberVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissPublicService.getDefaultApprILine(param));
	}
}
