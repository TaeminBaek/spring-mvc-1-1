package com.lgmma.salesPortal.app.model;

public class DissDelayGateReviewAlarmVO extends PagingParamVO {
	private String taskId;              // 과제id
	private String taskName;            // 과제명
	private String regiYmd;				// 등록일
	private String tsEmpMail;           // 스펙인TS담당자이메일

	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getRegiYmd() {
		return regiYmd;
	}
	public void setRegiYmd(String regiYmd) {
		this.regiYmd = regiYmd;
	}
	public String getTsEmpMail() {
		return tsEmpMail;
	}
	public void setTsEmpMail(String tsEmpMail) {
		this.tsEmpMail = tsEmpMail;
	}
}
