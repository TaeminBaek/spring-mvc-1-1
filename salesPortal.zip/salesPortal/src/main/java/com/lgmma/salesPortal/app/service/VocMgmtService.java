package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.VocVO;
import com.lgmma.salesPortal.app.model.VocActVO;
import com.lgmma.salesPortal.app.model.VocActPopVO;

public interface VocMgmtService {
	
	int getVocListCount(VocVO param);
	
	List<VocVO> getVocList(VocVO param);
	
	VocVO getVocDetail(VocVO param);
	
	List<VocActVO> getVocActList(VocVO param);
	
	void createVocMgmt(VocVO param);
	
	void updateVocMgmt(VocVO param);
	
	void deleteVocMgmt(VocVO param);
	
	VocActPopVO getVocActPop(VocActVO param);
	
	VocActPopVO getPersonFind(VocActVO param);
	
	VocActPopVO getActivityName(VocActPopVO param);
	
	void saveVocActPop(VocActPopVO param);
	
	VocVO getVocIdxx(VocActVO param);
	
	void saveVocActAppr(VocActPopVO param);
}
