package com.lgmma.salesPortal.app.model;

import java.util.List;

public class DissFieldTestVO extends PagingParamVO {
	
	//TB_D_FIELDTEST
	private String stepId;			// 과제스텝ID
	private String stepPurpose;     // 배경및목적
	private String prodLine;        // 생산라인
	private String testFacility;    // TEST설비
	private int    prodQty;         // 생산량
	private String testFrYmd;       // TEST계획시작일
	private String testToYmd;       // TEST계획종료일
	private String exhaustPlan;     // 소진계획
	private String prodNote;        // 생산시유의사항
	private String lotNo;           // LOT_NO
	//F/T 결과 조회시 조건
	private String taskId;
	private int degreeNo;
	
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getStepPurpose() {
		return stepPurpose;
	}
	public void setStepPurpose(String stepPurpose) {
		this.stepPurpose = stepPurpose;
	}
	public String getProdLine() {
		return prodLine;
	}
	public void setProdLine(String prodLine) {
		this.prodLine = prodLine;
	}
	public String getTestFacility() {
		return testFacility;
	}
	public void setTestFacility(String testFacility) {
		this.testFacility = testFacility;
	}
	public int getProdQty() {
		return prodQty;
	}
	public void setProdQty(int prodQty) {
		this.prodQty = prodQty;
	}
	public String getTestFrYmd() {
		return testFrYmd;
	}
	public void setTestFrYmd(String testFrYmd) {
		this.testFrYmd = testFrYmd;
	}
	public String getTestToYmd() {
		return testToYmd;
	}
	public void setTestToYmd(String testToYmd) {
		this.testToYmd = testToYmd;
	}
	public String getExhaustPlan() {
		return exhaustPlan;
	}
	public void setExhaustPlan(String exhaustPlan) {
		this.exhaustPlan = exhaustPlan;
	}
	public String getProdNote() {
		return prodNote;
	}
	public void setProdNote(String prodNote) {
		this.prodNote = prodNote;
	}
	public String getLotNo() {
		return lotNo;
	}
	public void setLotNo(String lotNo) {
		this.lotNo = lotNo;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public int getDegreeNo() {
		return degreeNo;
	}
	public void setDegreeNo(int degreeNo) {
		this.degreeNo = degreeNo;
	}
}
