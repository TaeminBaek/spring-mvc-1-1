package com.lgmma.salesPortal.common.model;

public class SapExchangeRate {
	private String exFromCurrCD;
	private String exToBamt;

	public String getExFromCurrCD() {
		return exFromCurrCD;
	}
	public void setExFromCurrCD(String exFromCurrCD) {
		this.exFromCurrCD = exFromCurrCD;
	}
	public String getExToBamt() {
		return exToBamt;
	}
	public void setExToBamt(String exToBamt) {
		this.exToBamt = exToBamt;
	}
}
