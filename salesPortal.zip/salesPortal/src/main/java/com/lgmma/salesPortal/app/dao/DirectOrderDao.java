package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;


public interface DirectOrderDao {

	int getPurchNoSeq();

	void createDirectOrderMaster(DirectOrderMasterVO param);

	void createDirectOrderItem(DirectOrderItemVO param);

	void updateErpOrderId(DirectOrderMasterVO param);
	
	List<DirectOrderMasterVO> getHomeOrderList(DirectOrderMasterVO param);

	int getDirectOrderCount(DirectOrderMasterVO param);

	List<DirectOrderMasterVO> getDirectOrderList(DirectOrderMasterVO param);

	List<DirectOrderItemVO> getDirectOrderItemList(String orderId);

	DirectOrderMasterVO getDirectOrderDetail(DirectOrderMasterVO param);

	void updateDirectOrderMaster(DirectOrderMasterVO param);

	void deleteDirectOrderItems(DirectOrderMasterVO param);

	void deleteDirectOrderMaster(DirectOrderMasterVO param);
	
	int getDirectOrderMasterItemListCount(DirectOrderMasterVO param);
	
	List<DirectOrderMasterVO> getDirectOrderMasterItemList(DirectOrderMasterVO param);
	
	void updateHighValue(DirectOrderItemVO param);

	String getDirectOrderId(String vbeln);

	void updateDirectOrderItem(DirectOrderItemVO item);

	DirectOrderMasterVO getDirectOrderMaster(String orderId);
}
