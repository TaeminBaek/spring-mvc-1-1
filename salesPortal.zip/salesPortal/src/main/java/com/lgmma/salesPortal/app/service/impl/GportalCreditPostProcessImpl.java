package com.lgmma.salesPortal.app.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.lgmma.salesPortal.app.dao.CompanyDao;
import com.lgmma.salesPortal.app.dao.LoginDao;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.CompCreditVO;
import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.model.SmsVO;
import com.lgmma.salesPortal.app.service.GportalPostProcess;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.app.service.SmsService;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.props.MailType;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.security.authentication.UserInfo;

import freemarker.template.Configuration;

@Transactional
@Service
public class GportalCreditPostProcessImpl implements GportalPostProcess {

	private static Logger logger = LoggerFactory.getLogger(GportalCreditPostProcessImpl.class); 

	private final String FNC_SAP_CREDIT_CHANGE = "ZSDE01_CREDIT_CHANGE";
	private final String FNC_SAP_EXP_CREDIT_CHANGE = "ZSDE01_CREDIT_CHANGE_EX";
	private final String REPORT_TEMPLATE_CREDIT = "REPORT_TEMPLATE_CREDIT";
	private final String REPORT_TEMPLATE_EXP_CREDIT = "REPORT_TEMPLATE_EXP_CREDIT";

	@Autowired
	private JcoConnector jcoConnector;
	
	@Autowired
	private MessageSourceAccessor messageSourceAccessor;
	
	@Autowired
	private MailingService mailingService;
	
	@Autowired
	private SmsService smsService;
	
	@Autowired
	private CompanyDao companyDao;
	
	@Autowired
	private LoginDao loginDao;

    @Autowired
    @Qualifier(value="reportFreemarkerConfiguration")
    private Configuration reportTemplateConfiguration;
    
	@Autowired
    private PlatformTransactionManager transactionManager;

    @Override
	public void saveApprId(ApprVO apprVO) {
		CompCreditVO param = new CompCreditVO();
		param.setCompCreditId(apprVO.getKeyId());
		param.setApprId(apprVO.getApprId());
		companyDao.updateCreditApprId(param);
	}

	@Override
	public void deleteApprId(ApprVO apprVO) {
		CompCreditVO param = new CompCreditVO();
		param.setApprId(apprVO.getApprId());
		companyDao.updateCreditApprIdToNull(param);
	}

	@Override
	public void completeProcess(ApprVO apprVO) {
		DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
		transactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//transaction start
		TransactionStatus tx = transactionManager.getTransaction(transactionDefinition);

		CompCreditVO param = new CompCreditVO();
		param.setApprId(apprVO.getApprId());
		CompCreditVO vo = companyDao.getCreditDetail(param);
		if(vo != null) {
			try {
				Map<String, Object> inputParams = new HashMap<String, Object>();
				Map<String, Object> outputParams = new HashMap<String, Object>();
				inputParams.put("I_GUBUN", vo.getNowCredit() == 0 ? "C" : "U");
				inputParams.put("I_KUNNR", vo.getKunnr());
				inputParams.put("I_VKORG", vo.getVkorg());
				inputParams.put("I_KLIMK", vo.getKlimk());  // 기존여신 + 플러스분 = 증액후 신규여신이 될 금액
				inputParams.put("I_ADD_AMNT", vo.getAddAmnt()); // 품의 받은 플러스분
				inputParams.put("I_ENDMON", StringUtil.remove(vo.getEndmon(), '.'));
				/*inputParams.put("I_VKBUR", vo.getVkbur());*/

				if(vo.getExpYn() == null || vo.getExpYn().equals(""))
					jcoConnector.executeFunction(FNC_SAP_CREDIT_CHANGE, inputParams, outputParams);			
				else
					jcoConnector.executeFunction(FNC_SAP_EXP_CREDIT_CHANGE, inputParams, outputParams);			
					
				String eReturn = outputParams.get("E_RETURN").toString().trim();
				String eSubrc = outputParams.get("E_SUBRC").toString().trim();

				if(eSubrc.equals("0")) {	//성공
					logger.debug(eReturn);
					vo.setErpStat("S");
				} else {	//실패
					logger.error(eReturn);
					vo.setErpStat("F");
				}
				companyDao.updateCreditErpStat(vo);

		        if(eSubrc.equals("0")) {	//성공
					//담보 담당자
					List<UserInfo> creditEmpList = loginDao.getCreditEmpUserInfo("");
					for(UserInfo creditEmp : creditEmpList) {
						Map<String, String> paramMap = new HashMap<String, String>();
						try {
							//targetUrl 값은 URLEncoder.encode 한다.
							//salesportal.sso.target.url=http://127.0.0.1:7080/SSOLogin
							paramMap.put("apprViewtUrl", messageSourceAccessor.getMessage("salesportal.sso.target.url") + "?targetUrl=" + URLEncoder.encode("/apprCommon/apprCommonPopEdit?apprType=" + ApprType.APPR_TYPE_CREDIT.getCode() + "&apprId=" + apprVO.getApprId(), "UTF-8"));
						} catch (UnsupportedEncodingException e) {
							e.printStackTrace();
						}
				        SendMailVO sendMailVO = new SendMailVO();
						sendMailVO.setTitle("[LX MMA] "+ vo.getName1() + " [" + vo.getKunnr() + "]의 여신 정보가 변경되었습니다.");
						sendMailVO.setMailType(MailType.COMPANY_CREDIT_CONFIRM_TO_CREDITEMP);
						sendMailVO.setSenderEmail(messageSourceAccessor.getMessage("info.mail.sender"));
						sendMailVO.setReceiverEmail(creditEmp.getMailAddr());
						sendMailVO.setParams(paramMap);
						mailingService.sendMail(sendMailVO);
					}
					//기안자 sms 전송
					SmsVO smsVo = new SmsVO();
					smsVo.setTrPhone(apprVO.getSawnHpxxNum1());
					smsVo.setTrMsg(vo.getName1() + " [" + vo.getKunnr() + "]의 여신 정보가 ERP에 전송되었습니다.");
					smsVo.setTrEtc1(vo.getApprId());
					smsService.sendSms(smsVo);
		        } else {	//실패
					SmsVO smsVo = new SmsVO();
					smsVo.setTrPhone(apprVO.getSawnHpxxNum1());
					smsVo.setTrMsg(vo.getName1() + " [" + vo.getKunnr() + "]의 여신 정보 ERP 전송에 실패하었습니다. 실패사유 - " + eReturn);
					smsVo.setTrEtc1(vo.getApprId());
					smsService.sendSms(smsVo);
		        }
			} catch (Exception e) {
				//메일이나 SMS 전송시 오류가 발생해도 커밋은 해야한다.
		        transactionManager.commit(tx);
				throw e;
			}
		}
	}

	@Override
	public void rejectProcess(ApprVO apprVO) {
		CompCreditVO param = new CompCreditVO();
		param.setApprId(apprVO.getApprId());
	}

	@Override
	public String getApprContent(String compCreditId) {
		CompCreditVO param = new CompCreditVO();
		param.setCompCreditId(compCreditId);
		CompCreditVO vo = companyDao.getCreditDetail(param);
		/*if(vo.getVkbur().equals("3000")) {
			vo.setVkbur("PMMA영업팀");
		}else if(vo.getVkbur().equals("3020")) {
			vo.setVkbur("자동차TF팀");
		}else if(vo.getVkbur().equals("1000")) {
			vo.setVkbur("MMA영업팀");
		}*/
    	StringBuffer content = new StringBuffer();
		Map<String, CompCreditVO> map = new HashMap<String, CompCreditVO>();
		map.put("vo", vo);
		if(vo.getExpYn() != null && vo.getExpYn().equals("Y")) {	//수출
	    	try{
	    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
	    				reportTemplateConfiguration.getTemplate(REPORT_TEMPLATE_EXP_CREDIT + ".txt"), map));
	    		return content.toString();
	    	}catch(Exception e){
	    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
	    	}
	    	return "";
		} else {
	    	try{
	    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
	    				reportTemplateConfiguration.getTemplate(REPORT_TEMPLATE_CREDIT + ".txt"), map));
	    		return content.toString();
	    	}catch(Exception e){
	    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
	    	}
	    	return "";
		}
	}
}
