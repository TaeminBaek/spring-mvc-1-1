package com.lgmma.salesPortal.app.model;

public class CompCreditVO extends PagingParamVO {
	private String compCreditId;
	private String vkorg;
	private String vkorgText;
	private String compCode;
	private String kunnr;
	private Long nowCredit;
	private Float itemPrice;
	private Float itemQty;
	private Long totalPrice;
	private Long dayavgSale;
	private String zterm;
	private String compGrade;
	private Float gradePoint;
	private Long tmpcreditLimit;
	private Long dambo;
	private Long klimk;
	private Long addAmnt;
	private Long confAmnt;
	private String endmon;
	private Long ssobl;
	private Long addAmnt1;
	private String expYn;
	private String erpStat;
	private String regiIdxx;
	private String regiDate;
	private String updtIdxx;
	private String updtDate;
	private String apprId;
	private String apprStat;
	private String apprStatName;
	private String kvgr2;
	private String name1;
	private String vkbur;
	
	public String getCompCreditId() {
		return compCreditId;
	}
	public void setCompCreditId(String compCreditId) {
		this.compCreditId = compCreditId;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public Long getNowCredit() {
		return nowCredit;
	}
	public void setNowCredit(Long nowCredit) {
		this.nowCredit = nowCredit;
	}
	public Float getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(Float itemPrice) {
		this.itemPrice = itemPrice;
	}
	public Float getItemQty() {
		return itemQty;
	}
	public void setItemQty(Float itemQty) {
		this.itemQty = itemQty;
	}
	public Long getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Long totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Long getDayavgSale() {
		return dayavgSale;
	}
	public void setDayavgSale(Long dayavgSale) {
		this.dayavgSale = dayavgSale;
	}
	public String getZterm() {
		return zterm;
	}
	public void setZterm(String zterm) {
		this.zterm = zterm;
	}
	public String getCompGrade() {
		return compGrade;
	}
	public void setCompGrade(String compGrade) {
		this.compGrade = compGrade;
	}
	public Float getGradePoint() {
		return gradePoint;
	}
	public void setGradePoint(Float gradePoint) {
		this.gradePoint = gradePoint;
	}
	public Long getTmpcreditLimit() {
		return tmpcreditLimit;
	}
	public void setTmpcreditLimit(Long tmpcreditLimit) {
		this.tmpcreditLimit = tmpcreditLimit;
	}
	public Long getDambo() {
		return dambo;
	}
	public void setDambo(Long dambo) {
		this.dambo = dambo;
	}
	public Long getKlimk() {
		return klimk;
	}
	public void setKlimk(Long klimk) {
		this.klimk = klimk;
	}
	public Long getAddAmnt() {
		return addAmnt;
	}
	public void setAddAmnt(Long addAmnt) {
		this.addAmnt = addAmnt;
	}
	public Long getConfAmnt() {
		return confAmnt;
	}
	public void setConfAmnt(Long confAmnt) {
		this.confAmnt = confAmnt;
	}
	public String getEndmon() {
		return endmon;
	}
	public void setEndmon(String endmon) {
		this.endmon = endmon;
	}
	public Long getSsobl() {
		return ssobl;
	}
	public void setSsobl(Long ssobl) {
		this.ssobl = ssobl;
	}
	public Long getAddAmnt1() {
		return addAmnt1;
	}
	public void setAddAmnt1(Long addAmnt1) {
		this.addAmnt1 = addAmnt1;
	}
	public String getExpYn() {
		return expYn;
	}
	public void setExpYn(String expYn) {
		this.expYn = expYn;
	}
	public String getErpStat() {
		return erpStat;
	}
	public void setErpStat(String erpStat) {
		this.erpStat = erpStat;
	}
	public String getRegiIdxx() {
		return regiIdxx;
	}
	public void setRegiIdxx(String regiIdxx) {
		this.regiIdxx = regiIdxx;
	}
	public String getRegiDate() {
		return regiDate;
	}
	public void setRegiDate(String regiDate) {
		this.regiDate = regiDate;
	}
	public String getUpdtIdxx() {
		return updtIdxx;
	}
	public void setUpdtIdxx(String updtIdxx) {
		this.updtIdxx = updtIdxx;
	}
	public String getUpdtDate() {
		return updtDate;
	}
	public void setUpdtDate(String updtDate) {
		this.updtDate = updtDate;
	}
	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getKvgr2() {
		return kvgr2;
	}
	public void setKvgr2(String kvgr2) {
		this.kvgr2 = kvgr2;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getVkorgText() {
		return vkorgText;
	}
	public void setVkorgText(String vkorgText) {
		this.vkorgText = vkorgText;
	}
	public String getApprStat() {
		return apprStat;
	}
	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}
	public String getApprStatName() {
		return apprStatName;
	}
	public void setApprStatName(String apprStatName) {
		this.apprStatName = apprStatName;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getVkbur() {
		return vkbur;
	}
	public void setVkbur(String vkbur) {
		this.vkbur = vkbur;
	}

}
