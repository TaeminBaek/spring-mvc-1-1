package com.lgmma.salesPortal.app.dao;

import java.util.List;
import java.util.Map;

import com.lgmma.salesPortal.app.model.DissExcelDownloadVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.EmployVO;


public interface DissSpecInDao {

	int getDissSpecInListCount(DissSpecInVO param);

	List<DissSpecInVO> getDissSpecInList(DissSpecInVO param);

	DissSpecInVO getDissSpecInInfo(DissSpecInVO param);

	DissSpecInVO getDissSpecInInfoHis(DissSpecInVO param);

	void createDissSpecIn(DissSpecInVO param);

	void updateDissSpecIn(DissSpecInVO param);

	void createDissSpecInHis(DissSpecInVO param);

	void updateDissSpecInHis(DissSpecInVO param);

	void deleteDissSpecIn(DissSpecInVO param);

	void deleteDissSpecInHis(DissSpecInVO param);

	void changeTsEmpGateReview(DissSpecInVO param);

	void changeTsEmpGateReviewHis(DissSpecInVO param);
	
	void changeSpecInDevLevel(DissSpecInVO param);
	
	void changeSpecInDevLevelHis(DissSpecInVO param);
	
	void changeSpecInCtq(DissSpecInVO param);
	
	void updateDissSpecInGateReviewHis(DissSpecInVO param);

	List<DissExcelDownloadVO> getDissSpecInListExcelDownload(DissSpecInVO param);

	List<DissSpecInVO> getFailSpecInList(DissSpecInVO param);

	int getFailSpecInListCnt(DissSpecInVO param);
}