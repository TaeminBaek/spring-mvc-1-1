 package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.ContractDao;
import com.lgmma.salesPortal.app.model.ContractItemVO;
import com.lgmma.salesPortal.app.model.ContractMasterVO;

@Repository
public class ContractDaoImpl implements ContractDao {
	
	private static final String MAPPER_NAMESPACE = "CONTRACT_MAPPER.";
		
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public void createInitContractMaster(String orderId) {
		sqlSession.update(MAPPER_NAMESPACE + "createInitContractMaster", orderId);
	}

	@Override
	public ContractMasterVO getContractMaster(String orderId) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getContractMaster", orderId);
	}

	@Override
	public void createInitContractItems(String orderId) {
		sqlSession.update(MAPPER_NAMESPACE + "createInitContractItems", orderId);
	}

	@Override
	public List<ContractItemVO> getContractItem(String orderId) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getContractItem", orderId);
	}

	@Override
	public void updateContractMaster(ContractMasterVO master) {
		sqlSession.update(MAPPER_NAMESPACE + "updateContractMaster", master);
	}

	@Override
	public void updateContractItem(ContractItemVO item) {
		sqlSession.update(MAPPER_NAMESPACE + "updateContractItem", item);
	}
	
}
