package com.lgmma.salesPortal.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.DissDashBoardVO;
import com.lgmma.salesPortal.app.service.DissCommonApprMgmtService;
import com.lgmma.salesPortal.app.service.DissDashBoardService;

//org.springframework.security.web.access.ExceptionTranslationFilter
@Controller		
@RequestMapping("/dissDashBoard") 
public class DissDashBoardController {
	
	@Autowired
	private DissDashBoardService dissDashBoardService;
	
	@Autowired
	private DissCommonApprMgmtService dissCommonApprMgmtService;
	
	@RequestMapping(value = "/dissDashBoard")
	public ModelAndView dissDashBoard(ModelAndView mav, DissDashBoardVO param) throws Exception {
		mav.setViewName("dissDashBoard/dissDashBoard");
		param.setLoginEmpId(param.getRegiIdxx());
		//My 진행중
		mav.addObject("myIngData", dissDashBoardService.getDissDashBoardMyIngCnt(param));
		//My 결재
		ApprLineVO apprLineVO = new ApprLineVO();
		apprLineVO.setLoginEmpId(param.getRegiIdxx());
		apprLineVO.setcApplStat("W");
//		apprLineVO.setcToYmd(Util.getToday());
//		apprLineVO.setcFrYmd(DateUtil.addMonth(Util.getToday(), -1));
		mav.addObject("myApprData", dissCommonApprMgmtService.getDissMyApprListCount(apprLineVO));
		
		//일정별 My 할일
		mav.addObject("mySpecInStepData", dissDashBoardService.getDissDashBoardStepSpecInCnt(param));
		mav.addObject("myImpDevStepData", dissDashBoardService.getDissDashBoardStepImpDevCnt(param));
		
		return mav;
	}
	
	/*@RequestMapping(value = "/getDissDashBoardData.json")
	public Map getDissDashBoardMyApprCount(@RequestBody(required = true) DissDashBoardVO param) throws Exception {
		UserInfo loginUserInfo = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo();
		param.setLoginEmpId(loginUserInfo.getSawnCode());
		return JsonResponse.asSuccess("myIngData", dissDashBoardService.getDissDashBoardMyIngCnt(param));
	}*/

}
