package com.lgmma.salesPortal.app.model;

import java.util.Collections;
import java.util.List;

public class OrderListVO extends PagingParamVO {

	private String gubun;		//로그인자
	private String userId;		//로그인사번
	private String eordHdid;    //주문 ID           
	private String tvkotVkorg;  //주문제품군ID      
	private String tvkotVtext;  //주문제품군명      
	private String eordComp;    //주문처ID
	private String eordCompName;    //주문처명
	private String saleComp;    //판매처ID
	private String saleCompName;    //판매처명
	private String coaxIsxx;    //시험성적서첨부여부
	private String sdate;		 //시작날짜
	private String edate;		 //마지막날짜
	private String eitmHdid;    //ITEM ID          
	private String jumnBigo;    //비고 주문        
	private String procStat;    //진행상태         
	private String procStatNm;    //진행상태명         
	private String jproIdxx;    //제품ID 주문      
	private String jproName;    //제품명 주문      
	private String jumnQtyx;    //수량 주문        
	private String jumnDrum;    //드럼 주문        
	private String areqDate;    //도착요청일 주문  
	private String areqTime;    //도착요청시간 주문
	private String jindIdxx;    //인도처ID 주문
	private String jindName;	//인도처명
    private String jindAddr;	//인도처주소
    private String erpxIdxx;	//ERP주문 ID
    private String erpxSubx;	//ERP주문 SUB ID
    private String veslCond;	//운임조건
	private String confQtyx;    //수량 확정        
	private String confDrum;    //드럼 확정
	private String confDate;    //확정일
	private String compCode;    //드럼 확정
	private String cproIdxx;    //확정제품 ID
	private String cproName;    //확정제품 명
	
	private String name1;		//SAP판매처명1
	private String name2;		//SAP판매처명2
	private String lfimg;		//출고수량
	
	private String lfdat;       //납품일
	private String street;    //주소
	private String vstel;     //출하지점/입고지점
	private String name3;      //기사명
	private String telNumber1;//기사 연락처
	
	//SAP 주문목록
	private String vbeln;		//주문번호
	private String audat;		//주문날자
	private String matnr;		//제품ID
	private String vdatu;		//요청날자
	private String kwmeng;		//주문수량 ,드럼수량 공통
	private String wbstk;		//주문상태
	private String ztext;		//주문상태명
	private String posnr;		//ITM_NUMBER
	private String rejectReason;		//불가사유
	
	private String kunnr;		//판매처 없을시 SAP조회용으로 필요
	
	private List<SapOrderListVO> sapOrderList = Collections.emptyList();    //SAP 리스트
	
	private List<SapOrderListVO> sapOrderText = Collections.emptyList();    //SAP 텍스트
	
	
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPosnr() {
		return posnr;
	}
	public void setPosnr(String posnr) {
		this.posnr = posnr;
	}
	public String getVbeln() {
		return vbeln;
	}
	public void setVbeln(String vbeln) {
		this.vbeln = vbeln;
	}
	public String getAudat() {
		return audat;
	}
	public void setAudat(String audat) {
		this.audat = audat;
	}
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getVdatu() {
		return vdatu;
	}
	public void setVdatu(String vdatu) {
		this.vdatu = vdatu;
	}
	public String getKwmeng() {
		return kwmeng;
	}
	public void setKwmeng(String kwmeng) {
		this.kwmeng = kwmeng;
	}
	public String getWbstk() {
		return wbstk;
	}
	public void setWbstk(String wbstk) {
		this.wbstk = wbstk;
	}
	public String getZtext() {
		return ztext;
	}
	public void setZtext(String ztext) {
		this.ztext = ztext;
	}
	public String getLfdat() {
		return lfdat;
	}
	public void setLfdat(String lfdat) {
		this.lfdat = lfdat;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getVstel() {
		return vstel;
	}
	public void setVstel(String vstel) {
		this.vstel = vstel;
	}
	public String getName3() {
		return name3;
	}
	public void setName3(String name3) {
		this.name3 = name3;
	}
	public String getTelNumber1() {
		return telNumber1;
	}
	public void setTelNumber1(String telNumber1) {
		this.telNumber1 = telNumber1;
	}
	public List<SapOrderListVO> getSapOrderText() {
		return sapOrderText;
	}
	public void setSapOrderText(List<SapOrderListVO> sapOrderText) {
		this.sapOrderText = sapOrderText;
	}
	public List<SapOrderListVO> getSapOrderList() {
		return sapOrderList;
	}
	public void setSapOrderList(List<SapOrderListVO> sapOrderList) {
		this.sapOrderList = sapOrderList;
	}
	public String getCproIdxx() {
		return cproIdxx;
	}
	public void setCproIdxx(String cproIdxx) {
		this.cproIdxx = cproIdxx;
	}
	public String getGubun() {
		return gubun;
	}
	public void setGubun(String gubun) {
		this.gubun = gubun;
	}
	public String getEordHdid() {
		return eordHdid;
	}
	public void setEordHdid(String eordHdid) {
		this.eordHdid = eordHdid;
	}
	public String getTvkotVkorg() {
		return tvkotVkorg;
	}
	public void setTvkotVkorg(String tvkotVkorg) {
		this.tvkotVkorg = tvkotVkorg;
	}
	public String getTvkotVtext() {
		return tvkotVtext;
	}
	public void setTvkotVtext(String tvkotVtext) {
		this.tvkotVtext = tvkotVtext;
	}
	public String getEordComp() {
		return eordComp;
	}
	public void setEordComp(String eordComp) {
		this.eordComp = eordComp;
	}
	public String getSaleComp() {
		return saleComp;
	}
	public void setSaleComp(String saleComp) {
		this.saleComp = saleComp;
	}
	public String getCoaxIsxx() {
		return coaxIsxx;
	}
	public void setCoaxIsxx(String coaxIsxx) {
		this.coaxIsxx = coaxIsxx;
	}
	public String getSdate() {
		return sdate;
	}
	public void setSdate(String sdate) {
		this.sdate = sdate;
	}
	public String getEdate() {
		return edate;
	}
	public void setEdate(String edate) {
		this.edate = edate;
	}
	public String getEitmHdid() {
		return eitmHdid;
	}
	public void setEitmHdid(String eitmHdid) {
		this.eitmHdid = eitmHdid;
	}
	public String getJumnBigo() {
		return jumnBigo;
	}
	public void setJumnBigo(String jumnBigo) {
		this.jumnBigo = jumnBigo;
	}
	public String getProcStat() {
		return procStat;
	}
	public void setProcStat(String procStat) {
		this.procStat = procStat;
	}
	public String getJproIdxx() {
		return jproIdxx;
	}
	public void setJproIdxx(String jproIdxx) {
		this.jproIdxx = jproIdxx;
	}
	public String getJproName() {
		return jproName;
	}
	public void setJproName(String jproName) {
		this.jproName = jproName;
	}
	public String getJumnQtyx() {
		return jumnQtyx;
	}
	public void setJumnQtyx(String jumnQtyx) {
		this.jumnQtyx = jumnQtyx;
	}
	public String getJumnDrum() {
		return jumnDrum;
	}
	public void setJumnDrum(String jumnDrum) {
		this.jumnDrum = jumnDrum;
	}
	public String getAreqDate() {
		return areqDate;
	}
	public void setAreqDate(String areqDate) {
		this.areqDate = areqDate;
	}
	public String getAreqTime() {
		return areqTime;
	}
	public void setAreqTime(String areqTime) {
		this.areqTime = areqTime;
	}
	public String getJindIdxx() {
		return jindIdxx;
	}
	public void setJindIdxx(String jindIdxx) {
		this.jindIdxx = jindIdxx;
	}
	public String getJindName() {
		return jindName;
	}
	public void setJindName(String jindName) {
		this.jindName = jindName;
	}
	public String getJindAddr() {
		return jindAddr;
	}
	public void setJindAddr(String jindAddr) {
		this.jindAddr = jindAddr;
	}
	public String getErpxIdxx() {
		return erpxIdxx;
	}
	public void setErpxIdxx(String erpxIdxx) {
		this.erpxIdxx = erpxIdxx;
	}
	public String getErpxSubx() {
		return erpxSubx;
	}
	public void setErpxSubx(String erpxSubx) {
		this.erpxSubx = erpxSubx;
	}
	public String getVeslCond() {
		return veslCond;
	}
	public void setVeslCond(String veslCond) {
		this.veslCond = veslCond;
	}
	public String getConfQtyx() {
		return confQtyx;
	}
	public void setConfQtyx(String confQtyx) {
		this.confQtyx = confQtyx;
	}
	public String getConfDrum() {
		return confDrum;
	}
	public void setConfDrum(String confDrum) {
		this.confDrum = confDrum;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getLfimg() {
		return lfimg;
	}
	public void setLfimg(String lfimg) {
		this.lfimg = lfimg;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getName2() {
		return name2;
	}
	public void setName2(String name2) {
		this.name2 = name2;
	}
	public String getProcStatNm() {
		return procStatNm;
	}
	public void setProcStatNm(String procStatNm) {
		this.procStatNm = procStatNm;
	}
	public String getConfDate() {
		return confDate;
	}
	public void setConfDate(String confDate) {
		this.confDate = confDate;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public String getSaleCompName() {
		return saleCompName;
	}
	public void setSaleCompName(String saleCompName) {
		this.saleCompName = saleCompName;
	}
	public String getCproName() {
		return cproName;
	}
	public void setCproName(String cproName) {
		this.cproName = cproName;
	}
	public String getEordCompName() {
		return eordCompName;
	}
	public void setEordCompName(String eordCompName) {
		this.eordCompName = eordCompName;
	}
	
}
