package com.lgmma.salesPortal.common.util;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lgmma.salesPortal.app.service.impl.GportalPostProcessImpl;

public class HashSecurity {
	private static Logger logger = LoggerFactory.getLogger(GportalPostProcessImpl.class); 
  
    public static String getMD5(String s) throws IOException {
        try {
            String hash = getCryptoMD5String(s);
            return hash;
        }catch(Exception e) {
            logger.error(e.toString());
            throw new IOException(e.toString());
        }
    }
        
    private static byte[] digest(String alg, byte[] input) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance(alg);
        return md.digest(input);
    }

    private static String getCryptoMD5String(String inputValue) throws NoSuchAlgorithmException,IOException {
        if( inputValue == null ) {
            return getCryptoMD5String("default");
        }
        byte[] ret = digest("MD5", inputValue.getBytes());
        String result = encode(ret); 
        return result;
    }
       
       
    private static String encode(byte[] encodeBytes) throws IOException  {
        byte[] buf = Base64.encodeBase64(encodeBytes);
        return new String(buf).trim();
    }
}
