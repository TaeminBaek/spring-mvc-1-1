package com.lgmma.salesPortal.app.model;

public class CompDamboVO extends PagingParamVO {
	
	private String mode;
	private String compCode;
	private String vkorg;
	private String name1;
	private String compDamboId;
	private String custGubun;
	private String dambo;
	private String title;
	private String useYn;
	private String startDate;
	private String endDate;
	private String dcDambo;
	private String historyMsg;
	private String cfnYn;
	private String fixedCollateral;
	private String salesEmpName;
	
	//컨펌시 필요함
	private String kunnr;
	private String guarAmnt;
	
	
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getHistoryMsg() {
		return historyMsg;
	}
	public void setHistoryMsg(String historyMsg) {
		this.historyMsg = historyMsg;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getCompDamboId() {
		return compDamboId;
	}
	public void setCompDamboId(String compDamboId) {
		this.compDamboId = compDamboId;
	}
	public String getCustGubun() {
		return custGubun;
	}
	public void setCustGubun(String custGubun) {
		this.custGubun = custGubun;
	}
	public String getDambo() {
		return dambo;
	}
	public void setDambo(String dambo) {
		this.dambo = dambo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getDcDambo() {
		return dcDambo;
	}
	public void setDcDambo(String dcDambo) {
		this.dcDambo = dcDambo;
	}
	public String getCfnYn() {
		return cfnYn;
	}
	public void setCfnYn(String cfnYn) {
		this.cfnYn = cfnYn;
	}
	public String getFixedCollateral() {
		return fixedCollateral;
	}
	public void setFixedCollateral(String fixedCollateral) {
		this.fixedCollateral = fixedCollateral;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getGuarAmnt() {
		return guarAmnt;
	}
	public void setGuarAmnt(String guarAmnt) {
		this.guarAmnt = guarAmnt;
	}
	public String getSalesEmpName() {
		return salesEmpName;
	}
	public void setSalesEmpName(String salesEmpName) {
		this.salesEmpName = salesEmpName;
	}
	
	
}
