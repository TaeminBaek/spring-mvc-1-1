package com.lgmma.salesPortal.app.model;

public class SalesTrendByProdAccontVO extends PagingParamVO {
	
	private String spmon;
	private String salesOrg;
	private String salesOrgText;
	private String distrChan;
	private String distrChanText;
	private String pkunag;
	private String partnNameAg;
	private String salesMan;
	private String matnr;
	private String stwae;
	private String basme;
	private String umnetwr1;
	private String ummenge1;
	private String unitPrice1;
	private String umnetwr2;
	private String ummenge2;
	private String unitPrice2;
	private String umnetwr3;
	private String ummenge3;
	private String unitPrice3;
	private String umnetwr4;
	private String ummenge4;
	private String unitPrice4;
	private String umnetwr5;
	private String ummenge5;
	private String unitPrice5;
	private String umnetwr6;
	private String ummenge6;
	private String unitPrice6;
	private String kvgr3;

	public String getSpmon() {
		return spmon;
	}
	public void setSpmon(String spmon) {
		this.spmon = spmon;
	}
	public String getSalesOrg() {
		return salesOrg;
	}
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	public String getSalesOrgText() {
		return salesOrgText;
	}
	public void setSalesOrgText(String salesOrgText) {
		this.salesOrgText = salesOrgText;
	}
	public String getDistrChan() {
		return distrChan;
	}
	public void setDistrChan(String distrChan) {
		this.distrChan = distrChan;
	}
	public String getDistrChanText() {
		return distrChanText;
	}
	public void setDistrChanText(String distrChanText) {
		this.distrChanText = distrChanText;
	}
	public String getPkunag() {
		return pkunag;
	}
	public void setPkunag(String pkunag) {
		this.pkunag = pkunag;
	}
	public String getPartnNameAg() {
		return partnNameAg;
	}
	public void setPartnNameAg(String partnNameAg) {
		this.partnNameAg = partnNameAg;
	}
	public String getSalesMan() {
		return salesMan;
	}
	public void setSalesMan(String salesMan) {
		this.salesMan = salesMan;
	}
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getStwae() {
		return stwae;
	}
	public void setStwae(String stwae) {
		this.stwae = stwae;
	}
	public String getBasme() {
		return basme;
	}
	public void setBasme(String basme) {
		this.basme = basme;
	}
	public String getUmnetwr1() {
		return umnetwr1;
	}
	public void setUmnetwr1(String umnetwr1) {
		this.umnetwr1 = umnetwr1;
	}
	public String getUmmenge1() {
		return ummenge1;
	}
	public void setUmmenge1(String ummenge1) {
		this.ummenge1 = ummenge1;
	}
	public String getUnitPrice1() {
		return unitPrice1;
	}
	public void setUnitPrice1(String unitPrice1) {
		this.unitPrice1 = unitPrice1;
	}
	public String getUmnetwr2() {
		return umnetwr2;
	}
	public void setUmnetwr2(String umnetwr2) {
		this.umnetwr2 = umnetwr2;
	}
	public String getUmmenge2() {
		return ummenge2;
	}
	public void setUmmenge2(String ummenge2) {
		this.ummenge2 = ummenge2;
	}
	public String getUnitPrice2() {
		return unitPrice2;
	}
	public void setUnitPrice2(String unitPrice2) {
		this.unitPrice2 = unitPrice2;
	}
	public String getUmnetwr3() {
		return umnetwr3;
	}
	public void setUmnetwr3(String umnetwr3) {
		this.umnetwr3 = umnetwr3;
	}
	public String getUmmenge3() {
		return ummenge3;
	}
	public void setUmmenge3(String ummenge3) {
		this.ummenge3 = ummenge3;
	}
	public String getUnitPrice3() {
		return unitPrice3;
	}
	public void setUnitPrice3(String unitPrice3) {
		this.unitPrice3 = unitPrice3;
	}
	public String getUmnetwr4() {
		return umnetwr4;
	}
	public void setUmnetwr4(String umnetwr4) {
		this.umnetwr4 = umnetwr4;
	}
	public String getUmmenge4() {
		return ummenge4;
	}
	public void setUmmenge4(String ummenge4) {
		this.ummenge4 = ummenge4;
	}
	public String getUnitPrice4() {
		return unitPrice4;
	}
	public void setUnitPrice4(String unitPrice4) {
		this.unitPrice4 = unitPrice4;
	}
	public String getUmnetwr5() {
		return umnetwr5;
	}
	public void setUmnetwr5(String umnetwr5) {
		this.umnetwr5 = umnetwr5;
	}
	public String getUmmenge5() {
		return ummenge5;
	}
	public void setUmmenge5(String ummenge5) {
		this.ummenge5 = ummenge5;
	}
	public String getUnitPrice5() {
		return unitPrice5;
	}
	public void setUnitPrice5(String unitPrice5) {
		this.unitPrice5 = unitPrice5;
	}
	public String getUmnetwr6() {
		return umnetwr6;
	}
	public void setUmnetwr6(String umnetwr6) {
		this.umnetwr6 = umnetwr6;
	}
	public String getUmmenge6() {
		return ummenge6;
	}
	public void setUmmenge6(String ummenge6) {
		this.ummenge6 = ummenge6;
	}
	public String getUnitPrice6() {
		return unitPrice6;
	}
	public void setUnitPrice6(String unitPrice6) {
		this.unitPrice6 = unitPrice6;
	}
	public String getKvgr3() {
		return kvgr3;
	}
	public void setKvgr3(String kvgr3) {
		this.kvgr3 = kvgr3;
	}
	
}
