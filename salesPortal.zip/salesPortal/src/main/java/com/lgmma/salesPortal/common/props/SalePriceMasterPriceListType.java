package com.lgmma.salesPortal.common.props;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.lgmma.salesPortal.common.model.DDLBItem;

public enum SalePriceMasterPriceListType {
/**
 * 판가마스터 가격리스트 유형으로서
*/
	 PLTYP_WHOLESALE("01","도매")
	,PLTYP_RETAIL("02","소매")
	,PLTYP_REGULAR("03","기준판가")
	,PLTYP_DOMESTIC_SALE_A("04","내수판가A")
	,PLTYP_DOMESTIC_SALE_B("05","내수판가B")
	,PLTYP_DOMESTIC_SALE_C("06","내수판가C")
	,PLTYP_EXPORT_SALE_A("07","수출판가A")
	,PLTYP_EXPORT_SALE_B("08","수출판가B")
	,PLTYP_EXPORT_SALE_C("09","수출판가C")
	,PLTYP_EXPORT_SALE_D("10","수출판가D")
	;
	String code = null;
	String name = null;

	private SalePriceMasterPriceListType(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static SalePriceMasterPriceListType getSalePriceMasterPriceListType(String code) {
		for(SalePriceMasterPriceListType type : SalePriceMasterPriceListType.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}

	public static List<SalePriceMasterPriceListType> getNormalSalePriceList() {
		return Arrays.asList(PLTYP_REGULAR
				,PLTYP_DOMESTIC_SALE_A
				,PLTYP_DOMESTIC_SALE_B
				,PLTYP_DOMESTIC_SALE_C
				,PLTYP_EXPORT_SALE_A
				,PLTYP_EXPORT_SALE_B
				,PLTYP_EXPORT_SALE_C
		);
	}
	
	public static List<SalePriceMasterPriceListType> getDomesticSalePriceList() {
		return Arrays.asList(PLTYP_REGULAR
				,PLTYP_DOMESTIC_SALE_A
				,PLTYP_DOMESTIC_SALE_B
				,PLTYP_DOMESTIC_SALE_C
		);
	}

	public static List<SalePriceMasterPriceListType> getExportSalePriceList() {
		return Arrays.asList(PLTYP_REGULAR
				,PLTYP_EXPORT_SALE_A
				,PLTYP_EXPORT_SALE_B
				,PLTYP_EXPORT_SALE_C
				,PLTYP_EXPORT_SALE_D
		);
	}
	
	public static List<DDLBItem> getSalePriceListItemList(List<SalePriceMasterPriceListType> salePriceTypeList){
		List<DDLBItem> itemList = new ArrayList<DDLBItem>();
		for(SalePriceMasterPriceListType salePriceType : salePriceTypeList) {
			DDLBItem item = new DDLBItem();
			item.setCode(salePriceType.getCode());
			item.setText(salePriceType.getName());
			itemList.add(item);
		}
		return itemList;
	}
}
