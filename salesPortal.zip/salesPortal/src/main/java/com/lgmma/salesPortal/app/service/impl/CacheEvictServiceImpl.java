package com.lgmma.salesPortal.app.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.service.CacheEvictService;

@Service
public class CacheEvictServiceImpl implements CacheEvictService{

	private static Logger logger = LoggerFactory.getLogger(CacheEvictServiceImpl.class); 

	@CacheEvict(cacheNames= {"sapRfcCommonCodeCache"}, allEntries=true)
	@Override
	public void sapRfcCommonCodeCacheEvict() {
		logger.warn("#####################################################");
		logger.warn("# sapRfcCommonCodeCache ALL Evict Complete!. ");
		logger.warn("#####################################################");
	}

	@CacheEvict(cacheNames= {"sapRfcHomeChartCache"}, allEntries=true)
	@Override
	public void sapRfcHomeChartCacheEvict() {
		logger.warn("#####################################################");
		logger.warn("# sapRfcHomeChartCache ALL Evict Complete!. ");
		logger.warn("#####################################################");
	}
	@CacheEvict(cacheNames= {"getCommonCodeDbAllCache"}, allEntries=true)
	@Override
	public void getCommonCodeDbAllCacheEvict() {
		logger.warn("#####################################################");
		logger.warn("# getCommonCodeDbAllCache ALL Evict Complete!. ");
		logger.warn("#####################################################");
	}
}
