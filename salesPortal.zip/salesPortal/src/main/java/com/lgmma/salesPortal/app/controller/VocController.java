package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.VocActPopVO;
import com.lgmma.salesPortal.app.model.VocActVO;
import com.lgmma.salesPortal.app.model.VocVO;
import com.lgmma.salesPortal.app.service.VocMgmtService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.props.VocState;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;
import com.lgmma.salesPortal.security.authentication.UserInfo;

import com.lgmma.salesPortal.app.controller.CommonController;

@Controller
@RequestMapping("/voc") 
public class VocController {
	
	@Autowired
	VocMgmtService vocMgmtService;
	
	@Autowired
	CommonController commonController;	
	
	@RequestMapping(value = "/vocMgmt")
	public ModelAndView vocMgmtInfo(ModelAndView mav ) throws Exception {		
		UserInfo loginUserInfo = ((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo();
		mav.setViewName("voc/vocMgmt");
		mav.addObject("loginUserType", loginUserInfo.getUserType());
		mav.addObject("loginUserCompName", loginUserInfo.getCompName());
		mav.addObject("loginUserCompCode", loginUserInfo.getKunnr());
		mav.addObject("loginUserSaleComp", loginUserInfo.getCompCode());
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("vkorgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("vocSrvcList", commonController.getVocSrvcWithSelectDDLB().get("items"));
		mav.addObject("vocStateCd", new ArrayList< VocState >(Arrays.asList(VocState.values())));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));		
		return mav;
	}
	
	@RequestMapping(value = "/getVocList.json")
	public Map getVocList(@RequestBody(required = true) VocVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", vocMgmtService.getVocListCount(param), "storeData", vocMgmtService.getVocList(param));
	}
	
	@RequestMapping(value = "/getVocDetail.json")
	public Map getVocDetail(@RequestBody(required = true) VocVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", vocMgmtService.getVocDetail(param));
	}
	
	@RequestMapping(value = "/getVocDetailPop.json")
	public Map getVocDetailPop(@RequestBody(required = true) VocActVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", vocMgmtService.getVocDetail(vocMgmtService.getVocIdxx(param)));
	}
	
	@RequestMapping(value = "/getVocActList.json")
	public Map getVocActList(@RequestBody(required = true) VocVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", vocMgmtService.getVocActList(param));
	}	

	@RequestMapping(value = "/createVocMgmt.json")
	public Map createVocMgmt(@RequestBody VocVO param) throws Exception {
		vocMgmtService.createVocMgmt(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/updateVocMgmt.json")
	public Map updateVocMgmt(@RequestBody VocVO param) throws Exception {
		vocMgmtService.updateVocMgmt(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/deleteVocMgmt.json")
	public Map deleteVocMgmt(@RequestBody VocVO param) throws Exception {
		vocMgmtService.deleteVocMgmt(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/vocActPopLoad")
	public ModelAndView vocActLoad(ModelAndView mav) {
		mav.setViewName("voc/vocActPopLoad");
		return mav;
	}
	
//	@RequestMapping(value = "/vocActPop")
//	public ModelAndView vocActInfo(ModelAndView mav,VocActVO param ) throws Exception {
//		VocActPopVO vocActPopVO = vocMgmtService.getVocActPop(param);
//		VocActPopVO actxList;
//		String EndxFlag = vocActPopVO.getEndxFlag();
//		
//		if(EndxFlag == null) {
//			actxList = vocMgmtService.getActivityName(vocActPopVO);
//		}else {
//			if(vocActPopVO.getEndxFlag().equals("Y")) {
//				actxList = vocMgmtService.getPersonFind(param);
//			}else {
//				actxList = vocMgmtService.getActivityName(vocActPopVO);
//			}			
//		}
//
//		mav.setViewName("voc/CustActInputPop");
//		mav.addObject("param", param);
//		mav.addObject("actxList", actxList);
//		mav.addObject("vocActPopVO", vocActPopVO);
//		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
//		return mav;
//	}
	@RequestMapping(value = "/getVocActPop.json")
	public Map getVocActPop(@RequestBody(required = true) VocActVO param) throws Exception {
		VocActPopVO vocActPopVO = vocMgmtService.getVocActPop(param);
		VocActPopVO actxList;
		String actxCode = StringUtil.isNullToString(vocActPopVO.getActxCode());
		String endxFlag = StringUtil.isNullToString(vocActPopVO.getEndxFlag());

		if(endxFlag.equals("Y")) {
			actxList = vocMgmtService.getPersonFind(param);
		}else {
			actxList = vocMgmtService.getActivityName(vocActPopVO);
		}
		
		return JsonResponse.asSuccess("storeData", vocActPopVO,"actxList", actxList);
	}	
	
	@RequestMapping(value = "/saveVocActPop.json")
	public Map saveVocActPop(@RequestBody VocActPopVO param) throws Exception {
		vocMgmtService.saveVocActPop(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
}
