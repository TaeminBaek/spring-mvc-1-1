package com.lgmma.salesPortal.app.model;

import java.util.List;

/**
 * @author nahong01
 * @description SpecIn 마스터
 */
public class DissSpecInVO extends PagingParamVO {
	// Table Column
	private String taskId;
	private String taskName;
	private String specinType;
	private String devLevel;
	private String devType;
	private String state;
	private String custCode;
	private String custType;
	private String saleCustCode;
	private String indoCustCode;
	private String lastCustName;
	private String grade;
	private String maker;
	private String prodTypeD;
	private String prodType;
	private String prodUsgType;
	private String prodUsgTypeDtl;
	private String oem;
	private String oemKind;
	private String tsGrade;
	private String tsCtq;
	private String tsOpinion;
	private String tsLevelOpinion;
	private String tsGradeOpinion;
	private String specinOutline;
	private String salesOpinion;
	private String usgFileId;
	private String expAnnualQty;
	private String thisYearGoal;
	private String tsEmpId;
	private String salesEmpId;
	private String leaderGb;
	private String compYmd;
	private String nationCd;
	private String nationArea;
	private String highValueYn;
	private String failTaskId;
	private String failTaskName;
	private String priorityTaskYn;

	// Search Condition Column
	private String scFrYmd;
	private String scToYmd;
	private String scFrCompYmd;
	private String scToCompYmd;
	private String scLeaderEmpNm;
	private String scType;

	// display column
	private String specinTypeNm;
	private String custName;
	private String stepCd;
	private String stepNm;
	private String nationNm;
	private String nationAreaNm;
	private String tsEmpNm;
	private String tsEmpTeamNm;
	private String tsEmpPosiNm;
	private String tsEmpHpno;
	private String tsEmpMail;
	private String salesEmpNm;
	private String salesEmpTeamNm;
	private String salesEmpPosiNm;
	private String preSalesEmpNm;
	private String prodTypeNm;
	private String prodTypeDNm;
	private String prodUsgTypeNm;
	private String devLevelNm;
	private String devTypeNm;
	private String stateNm;
	private String apprStat;
	private String apprStatNm;
	private String compYmdFmt;
	private String regiYmd;
	private String leaderGbNm;
	private String leaderNm;
	private String apprId;
	private String relApprId;
	private String apprType;
	private String stepId;
	private String apprActGb;
	private String taskStat;
	private String taskStatNm;
	private String custErpCode;
	private String custIndoCode;
	private String custSalesEmpId;
	private String custSalesEmpNm;
	private Integer degreeNo;
	private String custCurrency;
	private String taskType;
	private String compResult;
	private String compResultNm;
	private String checkDate;
	private String gateStepId;

	// appr param
	private String apprEmpId;
	private String applStat;
	private String apprLineComment;

	// sub table list
	private List<DissSpecInSaleGoalVO> dissSpecInSaleGoalList;
	private List<DissSpecInSaleGoalVO> dissSpecInSaleGoalListFirst;
	private List<DissKpiVO> dissKpiList;
	private List<DissMemberVO> dissMemberList;
	private List<DissScheduleVO> dissScheduleList;
	private ApprVO apprVO;
	private DissStepVO dissStepVO;

	// save Mode
	private boolean insertYn;
	private String saveMode;

	private String myIngYn;
	private String failTaskYn;
	
	public String getTsEmpHpno() {
		return tsEmpHpno;
	}

	public void setTsEmpHpno(String tsEmpHpno) {
		this.tsEmpHpno = tsEmpHpno;
	}

	public String getTsEmpMail() {
		return tsEmpMail;
	}

	public void setTsEmpMail(String tsEmpMail) {
		this.tsEmpMail = tsEmpMail;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getSpecinType() {
		return specinType;
	}

	public void setSpecinType(String specinType) {
		this.specinType = specinType;
	}

	public String getDevLevel() {
		return devLevel;
	}

	public void setDevLevel(String devLevel) {
		this.devLevel = devLevel;
	}

	public String getDevType() {
		return devType;
	}

	public void setDevType(String devType) {
		this.devType = devType;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getSaleCustCode() {
		return saleCustCode;
	}

	public void setSaleCustCode(String saleCustCode) {
		this.saleCustCode = saleCustCode;
	}

	public String getIndoCustCode() {
		return indoCustCode;
	}

	public void setIndoCustCode(String indoCustCode) {
		this.indoCustCode = indoCustCode;
	}

	public String getLastCustName() {
		return lastCustName;
	}

	public void setLastCustName(String lastCustName) {
		this.lastCustName = lastCustName;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getProdTypeD() {
		return prodTypeD;
	}

	public void setProdTypeD(String prodTypeD) {
		this.prodTypeD = prodTypeD;
	}

	public String getProdType() {
		return prodType;
	}

	public void setProdType(String prodType) {
		this.prodType = prodType;
	}

	public String getProdUsgType() {
		return prodUsgType;
	}

	public void setProdUsgType(String prodUsgType) {
		this.prodUsgType = prodUsgType;
	}

	public String getProdUsgTypeDtl() {
		return prodUsgTypeDtl;
	}

	public void setProdUsgTypeDtl(String prodUsgTypeDtl) {
		this.prodUsgTypeDtl = prodUsgTypeDtl;
	}

	public String getOem() {
		return oem;
	}

	public void setOem(String oem) {
		this.oem = oem;
	}

	public String getOemKind() {
		return oemKind;
	}

	public void setOemKind(String oemKind) {
		this.oemKind = oemKind;
	}

	public String getTsGrade() {
		return tsGrade;
	}

	public void setTsGrade(String tsGrade) {
		this.tsGrade = tsGrade;
	}

	public String getTsCtq() {
		return tsCtq;
	}

	public void setTsCtq(String tsCtq) {
		this.tsCtq = tsCtq;
	}

	public String getTsOpinion() {
		return tsOpinion;
	}

	public void setTsOpinion(String tsOpinion) {
		this.tsOpinion = tsOpinion;
	}

	public String getTsLevelOpinion() {
		return tsLevelOpinion;
	}

	public void setTsLevelOpinion(String tsLevelOpinion) {
		this.tsLevelOpinion = tsLevelOpinion;
	}

	public String getTsGradeOpinion() {
		return tsGradeOpinion;
	}

	public void setTsGradeOpinion(String tsGradeOpinion) {
		this.tsGradeOpinion = tsGradeOpinion;
	}

	public String getSpecinOutline() {
		return specinOutline;
	}

	public void setSpecinOutline(String specinOutline) {
		this.specinOutline = specinOutline;
	}

	public String getSalesOpinion() {
		return salesOpinion;
	}

	public void setSalesOpinion(String salesOpinion) {
		this.salesOpinion = salesOpinion;
	}

	public String getUsgFileId() {
		return usgFileId;
	}

	public void setUsgFileId(String usgFileId) {
		this.usgFileId = usgFileId;
	}

	public String getExpAnnualQty() {
		return expAnnualQty;
	}

	public void setExpAnnualQty(String expAnnualQty) {
		this.expAnnualQty = expAnnualQty;
	}

	public String getThisYearGoal() {
		return thisYearGoal;
	}

	public void setThisYearGoal(String thisYearGoal) {
		this.thisYearGoal = thisYearGoal;
	}

	public String getTsEmpId() {
		return tsEmpId;
	}

	public void setTsEmpId(String tsEmpId) {
		this.tsEmpId = tsEmpId;
	}

	public String getSalesEmpId() {
		return salesEmpId;
	}

	public void setSalesEmpId(String salesEmpId) {
		this.salesEmpId = salesEmpId;
	}

	public String getLeaderGb() {
		return leaderGb;
	}

	public void setLeaderGb(String leaderGb) {
		this.leaderGb = leaderGb;
	}

	public String getCompYmd() {
		return compYmd;
	}

	public void setCompYmd(String compYmd) {
		this.compYmd = compYmd;
	}

	public String getNationCd() {
		return nationCd;
	}

	public void setNationCd(String nationCd) {
		this.nationCd = nationCd;
	}

	public String getNationArea() {
		return nationArea;
	}

	public void setNationArea(String nationArea) {
		this.nationArea = nationArea;
	}

	public String getHighValueYn() {
		return highValueYn;
	}

	public void setHighValueYn(String highValueYn) {
		this.highValueYn = highValueYn;
	}

	public String getFailTaskId() {
		return failTaskId;
	}

	public void setFailTaskId(String failTaskId) {
		this.failTaskId = failTaskId;
	}

	public String getFailTaskName() {
		return failTaskName;
	}

	public void setFailTaskName(String failTaskName) {
		this.failTaskName = failTaskName;
	}

	public String getScFrYmd() {
		return scFrYmd;
	}

	public void setScFrYmd(String scFrYmd) {
		this.scFrYmd = scFrYmd;
	}

	public String getScToYmd() {
		return scToYmd;
	}

	public void setScToYmd(String scToYmd) {
		this.scToYmd = scToYmd;
	}

	public String getScFrCompYmd() {
		return scFrCompYmd;
	}

	public void setScFrCompYmd(String scFrCompYmd) {
		this.scFrCompYmd = scFrCompYmd;
	}

	public String getScToCompYmd() {
		return scToCompYmd;
	}

	public void setScToCompYmd(String scToCompYmd) {
		this.scToCompYmd = scToCompYmd;
	}

	public String getScLeaderEmpNm() {
		return scLeaderEmpNm;
	}

	public void setScLeaderEmpNm(String scLeaderEmpNm) {
		this.scLeaderEmpNm = scLeaderEmpNm;
	}

	public String getScType() {
		return scType;
	}
	
	public void setScType(String scType) {
		this.scType = scType;
	}

	public String getSpecinTypeNm() {
		return specinTypeNm;
	}

	public void setSpecinTypeNm(String specinTypeNm) {
		this.specinTypeNm = specinTypeNm;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getStepCd() {
		return stepCd;
	}

	public void setStepCd(String stepCd) {
		this.stepCd = stepCd;
	}

	public String getStepNm() {
		return stepNm;
	}

	public void setStepNm(String stepNm) {
		this.stepNm = stepNm;
	}

	public String getNationNm() {
		return nationNm;
	}

	public void setNationNm(String nationNm) {
		this.nationNm = nationNm;
	}

	public String getNationAreaNm() {
		return nationAreaNm;
	}

	public void setNationAreaNm(String nationAreaNm) {
		this.nationAreaNm = nationAreaNm;
	}

	public String getTsEmpNm() {
		return tsEmpNm;
	}

	public void setTsEmpNm(String tsEmpNm) {
		this.tsEmpNm = tsEmpNm;
	}

	public String getTsEmpTeamNm() {
		return tsEmpTeamNm;
	}

	public void setTsEmpTeamNm(String tsEmpTeamNm) {
		this.tsEmpTeamNm = tsEmpTeamNm;
	}

	public String getTsEmpPosiNm() {
		return tsEmpPosiNm;
	}

	public void setTsEmpPosiNm(String tsEmpPosiNm) {
		this.tsEmpPosiNm = tsEmpPosiNm;
	}

	public String getSalesEmpNm() {
		return salesEmpNm;
	}

	public void setSalesEmpNm(String salesEmpNm) {
		this.salesEmpNm = salesEmpNm;
	}

	public String getSalesEmpTeamNm() {
		return salesEmpTeamNm;
	}

	public void setSalesEmpTeamNm(String salesEmpTeamNm) {
		this.salesEmpTeamNm = salesEmpTeamNm;
	}

	public String getSalesEmpPosiNm() {
		return salesEmpPosiNm;
	}

	public void setSalesEmpPosiNm(String salesEmpPosiNm) {
		this.salesEmpPosiNm = salesEmpPosiNm;
	}


	public String getPreSalesEmpNm() {
		return preSalesEmpNm;
	}

	public void setPreSalesEmpNm(String preSalesEmpNm) {
		this.preSalesEmpNm = preSalesEmpNm;
	}

	public String getProdTypeNm() {
		return prodTypeNm;
	}

	public void setProdTypeNm(String prodTypeNm) {
		this.prodTypeNm = prodTypeNm;
	}

	public String getProdTypeDNm() {
		return prodTypeDNm;
	}

	public void setProdTypeDNm(String prodTypeDNm) {
		this.prodTypeDNm = prodTypeDNm;
	}

	public String getProdUsgTypeNm() {
		return prodUsgTypeNm;
	}

	public void setProdUsgTypeNm(String prodUsgTypeNm) {
		this.prodUsgTypeNm = prodUsgTypeNm;
	}

	public String getDevLevelNm() {
		return devLevelNm;
	}

	public void setDevLevelNm(String devLevelNm) {
		this.devLevelNm = devLevelNm;
	}

	public String getDevTypeNm() {
		return devTypeNm;
	}

	public void setDevTypeNm(String devTypeNm) {
		this.devTypeNm = devTypeNm;
	}

	public String getStateNm() {
		return stateNm;
	}

	public void setStateNm(String stateNm) {
		this.stateNm = stateNm;
	}

	public String getApprStat() {
		return apprStat;
	}

	public void setApprStat(String apprStat) {
		this.apprStat = apprStat;
	}

	public String getApprStatNm() {
		return apprStatNm;
	}

	public void setApprStatNm(String apprStatNm) {
		this.apprStatNm = apprStatNm;
	}

	public String getCompYmdFmt() {
		return compYmdFmt;
	}

	public void setCompYmdFmt(String compYmdFmt) {
		this.compYmdFmt = compYmdFmt;
	}

	public String getRegiYmd() {
		return regiYmd;
	}

	public void setRegiYmd(String regiYmd) {
		this.regiYmd = regiYmd;
	}

	public String getLeaderGbNm() {
		return leaderGbNm;
	}

	public void setLeaderGbNm(String leaderGbNm) {
		this.leaderGbNm = leaderGbNm;
	}

	public String getLeaderNm() {
		return leaderNm;
	}

	public void setLeaderNm(String leaderNm) {
		this.leaderNm = leaderNm;
	}

	public String getApprId() {
		return apprId;
	}

	public void setApprId(String apprId) {
		this.apprId = apprId;
	}

	public String getRelApprId() {
		return relApprId;
	}
	
	public void setRelApprId(String relApprId) {
		this.relApprId = relApprId;
	}

	public String getApprType() {
		return apprType;
	}

	public void setApprType(String apprType) {
		this.apprType = apprType;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getApprActGb() {
		return apprActGb;
	}

	public void setApprActGb(String apprActGb) {
		this.apprActGb = apprActGb;
	}

	public String getTaskStat() {
		return taskStat;
	}

	public void setTaskStat(String taskStat) {
		this.taskStat = taskStat;
	}

	public String getTaskStatNm() {
		return taskStatNm;
	}

	public void setTaskStatNm(String taskStatNm) {
		this.taskStatNm = taskStatNm;
	}

	public String getCustErpCode() {
		return custErpCode;
	}

	public void setCustErpCode(String custErpCode) {
		this.custErpCode = custErpCode;
	}

	public String getCustIndoCode() {
		return custIndoCode;
	}

	public void setCustIndoCode(String custIndoCode) {
		this.custIndoCode = custIndoCode;
	}

	public String getCustSalesEmpId() {
		return custSalesEmpId;
	}

	public void setCustSalesEmpId(String custSalesEmpId) {
		this.custSalesEmpId = custSalesEmpId;
	}

	public String getCustSalesEmpNm() {
		return custSalesEmpNm;
	}

	public void setCustSalesEmpNm(String custSalesEmpNm) {
		this.custSalesEmpNm = custSalesEmpNm;
	}

	public String getApprEmpId() {
		return apprEmpId;
	}

	public void setApprEmpId(String apprEmpId) {
		this.apprEmpId = apprEmpId;
	}

	public String getApplStat() {
		return applStat;
	}

	public void setApplStat(String applStat) {
		this.applStat = applStat;
	}

	public String getApprLineComment() {
		return apprLineComment;
	}

	public void setApprLineComment(String apprLineComment) {
		this.apprLineComment = apprLineComment;
	}

	public List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalList() {
		return dissSpecInSaleGoalList;
	}

	public void setDissSpecInSaleGoalList(List<DissSpecInSaleGoalVO> dissSpecInSaleGoalList) {
		this.dissSpecInSaleGoalList = dissSpecInSaleGoalList;
	}

	public List<DissSpecInSaleGoalVO> getDissSpecInSaleGoalListFirst() {
		return dissSpecInSaleGoalListFirst;
	}

	public void setDissSpecInSaleGoalListFirst(List<DissSpecInSaleGoalVO> dissSpecInSaleGoalListFirst) {
		this.dissSpecInSaleGoalListFirst = dissSpecInSaleGoalListFirst;
	}

	public List<DissKpiVO> getDissKpiList() {
		return dissKpiList;
	}

	public void setDissKpiList(List<DissKpiVO> dissKpiList) {
		this.dissKpiList = dissKpiList;
	}

	public List<DissMemberVO> getDissMemberList() {
		return dissMemberList;
	}

	public void setDissMemberList(List<DissMemberVO> dissMemberList) {
		this.dissMemberList = dissMemberList;
	}

	public List<DissScheduleVO> getDissScheduleList() {
		return dissScheduleList;
	}

	public void setDissScheduleList(List<DissScheduleVO> dissScheduleList) {
		this.dissScheduleList = dissScheduleList;
	}

	public ApprVO getApprVO() {
		return apprVO;
	}

	public void setApprVO(ApprVO apprVO) {
		this.apprVO = apprVO;
	}

	public DissStepVO getDissStepVO() {
		return dissStepVO;
	}

	public void setDissStepVO(DissStepVO dissStepVO) {
		this.dissStepVO = dissStepVO;
	}

	public boolean isInsertYn() {
		return insertYn;
	}

	public void setInsertYn(boolean insertYn) {
		this.insertYn = insertYn;
	}

	public Integer getDegreeNo() {
		return degreeNo;
	}

	public void setDegreeNo(Integer degreeNo) {
		this.degreeNo = degreeNo;
	}

	public String getCustCurrency() {
		return custCurrency;
	}

	public void setCustCurrency(String custCurrency) {
		this.custCurrency = custCurrency;
	}

	public String getSaveMode() {
		return saveMode;
	}

	public void setSaveMode(String saveMode) {
		this.saveMode = saveMode;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getCompResult() {
		return compResult;
	}

	public void setCompResult(String compResult) {
		this.compResult = compResult;
	}

	public String getCompResultNm() {
		return compResultNm;
	}

	public void setCompResultNm(String compResultNm) {
		this.compResultNm = compResultNm;
	}
	public String getMyIngYn() {
		return myIngYn;
	}

	public void setMyIngYn(String myIngYn) {
		this.myIngYn = myIngYn;
	}

	public String getCheckDate() {
		return checkDate;
	}

	public void setCheckDate(String checkDate) {
		this.checkDate = checkDate;
	}

	public String getFailTaskYn() {
		return failTaskYn;
	}

	public void setFailTaskYn(String failTaskYn) {
		this.failTaskYn = failTaskYn;
	}
	
	public String getGateStepId() {
		return gateStepId;
	}
	
	public void setGateStepId(String gateStepId) {
		this.gateStepId = gateStepId;
	}

	public String getPriorityTaskYn() {
		return priorityTaskYn;
	}
	
	public void setPriorityTaskYn(String priorityTaskYn) {
		this.priorityTaskYn = priorityTaskYn;
	}
}
