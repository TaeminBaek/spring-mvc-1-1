package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.CodeGroupVO;


public interface CodeGroupDao {
	

	int getCodeGroupCount(CodeGroupVO param);
	
	List<CodeGroupVO> getCodeGroupList(CodeGroupVO param);

	void updateCodeGroup(CodeGroupVO param);

	void createCodeGroup(CodeGroupVO param);

}
