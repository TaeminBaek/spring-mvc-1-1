package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.IcisVO;

public interface MsDao {

	public List<IcisVO> getIcisList(IcisVO param);

}
