 package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.CommonDao;
import com.lgmma.salesPortal.app.model.CommonCodeVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.EmployVO;
import com.lgmma.salesPortal.app.model.LoginUserVO;
import com.lgmma.salesPortal.app.model.ProductVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;
import com.lgmma.salesPortal.app.model.VocVO;

@Repository
public class CommonDaoImpl implements CommonDao {
	
	private static final String MAPPER_NAMESPACE = "COMMON_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public List<EmployVO> getEmployList(EmployVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getEmployList", param);
	}

	@Override
	public EmployVO getEmployByPosiCode(EmployVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getEmployByPosiCode", param);
	}

	@Override
	public int getEmployListCount(EmployVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getEmployListCount", param);
	}
	
	@Override
	public List<CommonCodeVO> getCommonCodeComboList(CommonCodeVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCommonCodeComboList", param);
	}

	@Override
	public EmployVO getEmployBySawnCode(String sawnCode) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getEmployBySawnCode", sawnCode);
	}
	
	@Override
	public int getProductPopupCount(ProductVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getProductPopupCount", param);
	}
	
	@Override
	public List<ProductVO> getProductPopupList(ProductVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getProductPopupList", param);
	}

	@Override
	public int getCustomerPopupCount(CompanyVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getCustomerPopupCount", param);
	}

	@Override
	public List<CompanyVO> getCustomerPopupList(CompanyVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCustomerPopupList", param);
	}

	@Override
	public int getWebAccountPopupCount(LoginUserVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getWebAccountPopupCount", param);
	}

	@Override
	public List<LoginUserVO> getWebAccountPopupList(LoginUserVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getWebAccountPopupList", param);
	}

	@Override
	public CompanyVO checkCompanyBusinoDub(Map<String, String> param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "checkCompanyBusinoDub", param);
	}

	@Override
	public Map getMemberNameMail(Map<String, String> param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getMemberNameMail", param);
	}
	
	@Override
	public String getKvgr3(String param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getKvgr3", param);
	}
	
	@Override
	public List<String> getKunnr(Map<String, String> param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getKunnr", param);
	}

	@Override
	public List<VocVO> getVocSrvcList() {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getVocSrvcList");
	}

	@Override
	public List<VocVO> getVocSrvcDivxList(VocVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getVocSrvcDivxList",param);
	}
	
	@Override
	public int getAgencyPopupCount(CompanyVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getAgencyPopupCount", param);
	}

	@Override
	public List<CompanyVO> getAgencyPopupList(CompanyVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getAgencyPopupList", param);
	}

	@Override
	public int getSalePricePopupCount(SalePriceMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getSalePricePopupCount", param);
	}

	@Override
	public List<SalePriceMasterVO> getSalePricePopupList(SalePriceMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSalePricePopupList", param);
	}

	@Override
	public String getPositionName(String posiCode) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getPositionName", posiCode);
	}

	@Override
	public String getTeamName(String teamCode) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getTeamName", teamCode);
	}

	@Override
	public List<CommonCodeVO> getDissProdDivisionDList(CommonCodeVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissProdDivisionDList", param);
	}
	
	@Override
	public List<CommonCodeVO> getDissFailReasonDtlList(CommonCodeVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissFailReasonDtlList", param);
	}

	@Override
	public ProductVO getProductDtl(ProductVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getProductDtl", param);
	}
}
