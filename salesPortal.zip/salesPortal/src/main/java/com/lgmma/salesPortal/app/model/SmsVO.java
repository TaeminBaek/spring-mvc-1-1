package com.lgmma.salesPortal.app.model;

public class SmsVO {

	private String trPhone; // 수신자
	private String trCallback; // 발신자
	private String trMsg; // 메시지
	private String trEtc1; // 관련 apprId

	public String getTrPhone() {
		return trPhone;
	}

	public void setTrPhone(String trPhone) {
		this.trPhone = trPhone;
	}

	public String getTrCallback() {
		return trCallback;
	}

	public void setTrCallback(String trCallback) {
		this.trCallback = trCallback;
	}

	public String getTrMsg() {
		return trMsg;
	}

	public void setTrMsg(String trMsg) {
		this.trMsg = trMsg;
	}

	public String getTrEtc1() {
		return trEtc1;
	}

	public void setTrEtc1(String trEtc1) {
		this.trEtc1 = trEtc1;
	}
}
