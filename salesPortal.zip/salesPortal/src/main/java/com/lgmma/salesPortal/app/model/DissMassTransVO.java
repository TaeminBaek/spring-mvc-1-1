package com.lgmma.salesPortal.app.model;

public class DissMassTransVO extends PagingParamVO {

	//TB_D_MASSTRANS
	private String stepId;				// 과제스텝ID
	private String transYn;             // 이관여부
	private String transScheduleYmd;    // 양산이관일정
	private String massLine;            // 양산라인
	private int    prodQty;             // 생산량(톤)
	private String massGrade;           // 양산GRADE
	private String massFrYmd;           // 양산기간FROM
	private String massToYmd;           // 양산기간TO
	private String lotNo;               // LOT넘버
	//조회
	private String transYnName;			// 이관여부명
	private String massLineName;		// 양산라인명
	
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getTransYn() {
		return transYn;
	}
	public void setTransYn(String transYn) {
		this.transYn = transYn;
	}
	public String getTransScheduleYmd() {
		return transScheduleYmd;
	}
	public void setTransScheduleYmd(String transScheduleYmd) {
		this.transScheduleYmd = transScheduleYmd;
	}
	public String getMassLine() {
		return massLine;
	}
	public void setMassLine(String massLine) {
		this.massLine = massLine;
	}
	public int getProdQty() {
		return prodQty;
	}
	public void setProdQty(int prodQty) {
		this.prodQty = prodQty;
	}
	public String getMassGrade() {
		return massGrade;
	}
	public void setMassGrade(String massGrade) {
		this.massGrade = massGrade;
	}
	public String getMassFrYmd() {
		return massFrYmd;
	}
	public void setMassFrYmd(String massFrYmd) {
		this.massFrYmd = massFrYmd;
	}
	public String getMassToYmd() {
		return massToYmd;
	}
	public void setMassToYmd(String massToYmd) {
		this.massToYmd = massToYmd;
	}
	public String getLotNo() {
		return lotNo;
	}
	public void setLotNo(String lotNo) {
		this.lotNo = lotNo;
	}
	public String getTransYnName() {
		return transYnName;
	}
	public void setTransYnName(String transYnName) {
		this.transYnName = transYnName;
	}
	public String getMassLineName() {
		return massLineName;
	}
	public void setMassLineName(String massLineName) {
		this.massLineName = massLineName;
	}
}
