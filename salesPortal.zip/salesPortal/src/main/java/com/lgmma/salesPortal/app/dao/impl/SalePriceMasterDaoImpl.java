package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.SalePriceMasterDao;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.DirectOrderSimpleVO;
import com.lgmma.salesPortal.app.model.SalePriceCloseDtlVO;
import com.lgmma.salesPortal.app.model.SalePriceCloseVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterHisVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;

@Repository
public class SalePriceMasterDaoImpl implements SalePriceMasterDao {

    private static final String MAPPER_NAMESPACE = "SALEPRICE_MASTER_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public int getsalePriceMasterListCount(SalePriceMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getsalePriceMasterListCount", param);
	}

	@Override
	public List<SalePriceMasterVO> getsalePriceMasterList(SalePriceMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getsalePriceMasterList", param);
	}

	@Override
	public SalePriceMasterVO getsalePriceMasterDetail(SalePriceMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getsalePriceMasterDetail", param);
	}

	@Override
	public List<SalePriceMasterHisVO> getsalePriceMasterHisList(SalePriceMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getsalePriceMasterHisList", param);
	}
	
	@Override
	public int duplicateChkSalePriceMaster(SalePriceMasterHisVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "duplicateChkSalePriceMaster", param);
	}
	
	@Override
	public SalePriceMasterHisVO mergeSalePriceMaster(SalePriceMasterHisVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "mergeSalePriceMaster", param);
	}

	@Override
	public void createSalePriceMasterHis(SalePriceMasterHisVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createPriceMasterHistory", param);
		
	}

	@Override
	public List<SalePriceMasterVO> getSalePriceMasterMergeTargetList(SalePriceMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSalePriceMasterMergeTargetList", param);
	}

	@Override
	public int checkSalePriceMasterMergeTargetCnt(SalePriceMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "checkSalePriceMasterMergeTargetCnt", param);
	}

	@Override
	public void createSalePriceMasterMergeTarget(SalePriceMasterVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createSalePriceMasterMergeTarget", param);
	}

	@Override
	public void updateSalePriceMasterMergeTarget(SalePriceMasterVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateSalePriceMasterMergeTarget", param);
	}

	@Override
	public void deleteSalePriceMasterMergeTarget(SalePriceMasterVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteSalePriceMasterMergeTarget", param);
	}

	@Override
	public void deleteMonthlyCloseDetail(SalePriceCloseVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteMonthlyCloseDetail", param);
	}

	@Override
	public void createMonthlyClose(SalePriceCloseVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createMonthlyClose", param);
	}

	@Override
	public int getMonthlyCloseListCount(SalePriceCloseVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getMonthlyCloseListCount", param);
	}

	@Override
	public List<SalePriceCloseVO> getMonthlyCloseList(SalePriceCloseVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getMonthlyCloseList", param);
	}

	@Override
	public int getPriceMasterExistsOrderListCount(SalePriceCloseVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getPriceMasterExistsOrderListCount", param);
	}

	@Override
	public List<SalePriceMasterVO> getPriceMasterExistsOrderList(SalePriceCloseVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getPriceMasterExistsOrderList", param);
	}

	@Override
	public int getOrderByPriceListCount(SalePriceMasterVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getOrderByPriceListCount", param);
	}

	@Override
	public List<DirectOrderMasterVO> getOrderByPriceList(SalePriceMasterVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getOrderByPriceList", param);
	}

	@Override
	public SalePriceCloseVO getSingleMonthlyClose(SalePriceCloseVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getSingleMonthlyClose", param);
	}

	@Override
	public List<SalePriceCloseDtlVO> getMonthlyCloseDetailListBeforeFinish(SalePriceCloseVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getMonthlyCloseDetailListBeforeFinish", param);
	}

	@Override
	public void updateMonthlyClose(SalePriceCloseVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateMonthlyClose", param);
	}

	@Override
	public void insertMonthlyCloseDetail(SalePriceCloseDtlVO detail) {
		sqlSession.insert(MAPPER_NAMESPACE + "insertMonthlyCloseDetail", detail);
	}

	@Override
	public List<SalePriceCloseDtlVO> getMonthlyCloseDetailListAfterFinish(SalePriceCloseVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getMonthlyCloseDetailListAfterFinish", param);
	}

	@Override
	public void updateMonthlyCloseApprId(SalePriceCloseVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateMonthlyCloseApprId", param);
	}

	@Override
	public List<SalePriceCloseVO> getPriceMasterMonthlyListByApprId(SalePriceCloseVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getPriceMasterMonthlyListByApprId", param);
	}

	@Override
	public int getDifferentOrderPriceAndMasterCount(DirectOrderSimpleVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDifferentOrderPriceAndMasterCount", param);
	}

	@Override
	public List<DirectOrderSimpleVO> getDifferentOrderPriceAndMasterList(DirectOrderSimpleVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDifferentOrderPriceAndMasterList", param);
	}

	@Override
	public void changeSalePriceCloseStatus(SalePriceCloseVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "changeSalePriceCloseStatus", param);
	}
}
