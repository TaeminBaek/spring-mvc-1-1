package com.lgmma.salesPortal.app.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.dao.StatisticsDao;
import com.lgmma.salesPortal.app.model.StatisticsCustSuppVO;
import com.lgmma.salesPortal.app.model.StatisticsOrderVO;
import com.lgmma.salesPortal.app.service.StatisticsService;

@Transactional
@Service
public class StatisticsServiceImpl implements StatisticsService {
	
    @Autowired
    private StatisticsDao statisticsDao;
    
	@Override
	public List<StatisticsOrderVO> getStatOrderList(StatisticsOrderVO param) throws Exception {
		return statisticsDao.getStatOrderList(param);
	}
	
	@Override
	public List<StatisticsOrderVO> getStatOrderView(StatisticsOrderVO param) throws Exception {
		return statisticsDao.getStatOrderView(param);
	}
	
	@Override
	public List<StatisticsCustSuppVO> getStatCustSuppList(StatisticsCustSuppVO param) throws Exception {
		return statisticsDao.getStatCustSuppList(param);
	}
	
	@Override
	public List<StatisticsCustSuppVO> getStatCustSuppView(StatisticsCustSuppVO param) throws Exception {
		return statisticsDao.getStatCustSuppView(param);
	}
	
	@Override
	public List<StatisticsCustSuppVO> getStatCustSuppDetail(StatisticsCustSuppVO param) throws Exception {
		return statisticsDao.getStatCustSuppDetail(param);
	}
}
