package com.lgmma.salesPortal.app.service;

import com.lgmma.salesPortal.app.model.SendMailVO;

public interface MailingService {

	public void sendMail(SendMailVO sendMailVO);
}
