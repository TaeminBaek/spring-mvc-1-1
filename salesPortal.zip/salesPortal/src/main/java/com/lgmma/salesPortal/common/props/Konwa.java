package com.lgmma.salesPortal.common.props;

public enum Konwa {
/**
 * 통화구분으로서
*/
	 KRW("KRW","KRW")
	,USD("USD","USD")
	,EURO("EUR","EUR")
	,CNY("CNY","CNY")
	;
	String code		= null;		// 통화구분코드
	String name		= null;		// 통화구분명

	private Konwa(String code, String name) {
		this.code	= code;
		this.name	= name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static Konwa getKonwa(String code) {
		for(Konwa type : Konwa.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
}
