package com.lgmma.salesPortal.app.model;

import java.util.Map;

import com.lgmma.salesPortal.common.props.MailType;

public class SendMailVO {
	private MailType mailType;
	private String title;
	private String senderEmail;
	private String receiverName;
	private String receiverEmail;
	private Map<String, String> params;

	public String getSenderEmail() {
		return senderEmail;
	}
	public void setSenderEmail(String senderEmail) {
		this.senderEmail = senderEmail;
	}
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	public String getReceiverEmail() {
		return receiverEmail;
	}
	public void setReceiverEmail(String receiverEmail) {
		this.receiverEmail = receiverEmail;
	}
	public MailType getMailType() {
		return mailType;
	}
	public void setMailType(MailType mailType) {
		this.mailType = mailType;
	}
	public Map<String, String> getParams() {
		return params;
	}
	public void setParams(Map<String, String> params) {
		this.params = params;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
}
