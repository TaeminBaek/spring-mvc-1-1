package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissOneTeamDao;
import com.lgmma.salesPortal.app.model.DissOneTeamVO;
import com.lgmma.salesPortal.app.model.EmployVO;

@Repository
public class DissOneTeamDaoImpl implements DissOneTeamDao{
	
	private static final String MAPPER_NAMESPACE = "DISSONETEAM_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public String createDissOneTeamCode() {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "createDissOneTeamCode");
	}
	
	@Override
	public void createDissOneTeam(DissOneTeamVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissOneTeam", param);
	}

	@Override
	public int getDissOneTeamListCount(DissOneTeamVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissOneTeamListCount", param);
	}

	@Override
	public List<DissOneTeamVO> getDissOneTeamList(DissOneTeamVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissOneTeamList", param);
	}

	@Override
	public List<DissOneTeamVO> getDissOneTeamLeaderTeamList() {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissOneTeamLeaderTeamList");
	}

	@Override
	public void updateDissOneTeam(DissOneTeamVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissOneTeam", param);
	}

	@Override
	public void deleteDissOneTeamAll(DissOneTeamVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissOneTeamAll", param);
	}

	@Override
	public void createDissOneTeamHis(DissOneTeamVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissOneTeamHis", param);
		
	}

	@Override
	public void updateDissOneTeamHis(DissOneTeamVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissOneTeamHis", param);
	}

	@Override
	public void deleteDissOneTeamHisAll(DissOneTeamVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissOneTeamHisAll", param);
	}

	@Override
	public DissOneTeamVO getDissOneTeamInfo(DissOneTeamVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissOneTeamInfo",param);
	}

	@Override
	public DissOneTeamVO getDissOneTeamHisInfo(DissOneTeamVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissOneTeamHisInfo",param);
	}

	@Override
	public DissOneTeamVO getDissOneTeamInfoByApprId(DissOneTeamVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissOneTeamInfoByApprId",param);
	}
	
	@Override
	public List<EmployVO> loadEmployList(Map<String, String> param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "loadEmployList",param);
	}
	
	@Override
	public DissOneTeamVO getProdTypeTxt(DissOneTeamVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getProdTypeTxt",param);
	}
}
