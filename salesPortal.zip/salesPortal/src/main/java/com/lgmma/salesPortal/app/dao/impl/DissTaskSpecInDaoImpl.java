package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissTaskSpecInDao;
import com.lgmma.salesPortal.app.model.DissTaskSpecInVO;

@Repository
public class DissTaskSpecInDaoImpl implements DissTaskSpecInDao{
	
	private static final String MAPPER_NAMESPACE = "DISS_TASK_SPECIN_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;
	 
	@Override
	public void createDissTaskSpecIn(DissTaskSpecInVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissTaskSpecIn", param);
	}
	
	@Override
	public List<DissTaskSpecInVO> getDissTaskSpecInList(DissTaskSpecInVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissTaskSpecInList", param);
	}
	
	@Override
	public void deleteDissTaskSpecInAll(DissTaskSpecInVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissTaskSpecInAll", param);
	}
	
	@Override
	public void createDissTaskSpecInHis(DissTaskSpecInVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissTaskSpecInHis", param);
	}
	
	@Override
	public void deleteDissTaskSpecInHisAll(DissTaskSpecInVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissTaskSpecInHisAll", param);
	}
	
	@Override
	public List<DissTaskSpecInVO> getDissTaskSpecInHisList(DissTaskSpecInVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissTaskSpecInHisList", param);
	}
	
	@Override
	public void updateDissTaskSpecIn(DissTaskSpecInVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissTaskSpecIn", param);
	}
	
	@Override
	public void updateDissTaskSpecInHis(DissTaskSpecInVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissTaskSpecInHis", param);
	}
	
	@Override
	public List<DissTaskSpecInVO> getSpecInListWithTotalSaleGoal(DissTaskSpecInVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSpecInListWithTotalSaleGoal", param);
	}

	@Override
	public int getSpecInListWithTotalSaleGoalCnt(DissTaskSpecInVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getSpecInListWithTotalSaleGoalCnt", param);
	}

}
