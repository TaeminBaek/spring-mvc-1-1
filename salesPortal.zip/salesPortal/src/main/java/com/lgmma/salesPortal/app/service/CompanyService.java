package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.CompCreditVO;
import com.lgmma.salesPortal.app.model.CompDamboVO;
import com.lgmma.salesPortal.app.model.CompOrganEditVO;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.GenVocVO;
import com.lgmma.salesPortal.app.model.NewCompOrganEditVO;
import com.lgmma.salesPortal.app.model.OrganVO;

public interface CompanyService {

	int getCompanyCount(CompanyVO param);

	List<CompanyVO> getCompanyList(CompanyVO param);

	CompanyVO getCompanyDetail(CompanyVO param);
	
	OrganVO getCompanyEtc(OrganVO param);
	
	int getCompanyEtcKunnrCount(OrganVO param);
	
	void saveCompanyEtc(OrganVO param);
	
	int getDamboCount(CompDamboVO param);
	
	List<CompDamboVO> getDamboList(CompDamboVO param);
	
	void updateDambo(CompDamboVO param);
	
	void createDambo(CompDamboVO param);
	
	void confirmDambo(CompDamboVO param);
	
	int getCreditCount(CompCreditVO param);
	
	List<CompCreditVO> getCreditList(CompCreditVO param);
	
	int getSampleDocCount(GenVocVO param);
	
	List<GenVocVO> getSampleDocList(GenVocVO param);

	void createCredit(CompCreditVO param);

	Long getAddAmntSum(CompanyVO param);

	void updateCredit(CompCreditVO param);

	CompOrganEditVO updateCompBasic(CompOrganEditVO param);

	List<NewCompOrganEditVO> getCompOrganEditList(CompOrganEditVO param);
	
	void mergeCompanyVO(CompOrganEditVO editVO, CompanyVO companyVO);

	void deleteCompOrganEdit(CompOrganEditVO param);

	NewCompOrganEditVO createCompBasic(NewCompOrganEditVO param);

	String getCompanyCreditGrade(String stcd);

	String exchangeValue(String compGrade);
	
	int getDamboItemListCount(CompDamboVO param);
}
