package com.lgmma.salesPortal.app.service;

import java.io.UnsupportedEncodingException;

import com.lgmma.salesPortal.app.model.ApprVO;

public interface GPortalRestService {

	public void requestApproval(ApprVO paramApprVO);

	public void approvalAtcionFromGPortal(String apprId, String apprEmpId, String apprStatus, String apprEmpComment, String forceExcute) throws UnsupportedEncodingException;
}
