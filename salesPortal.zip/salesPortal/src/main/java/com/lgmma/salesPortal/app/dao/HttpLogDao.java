package com.lgmma.salesPortal.app.dao;

import com.lgmma.salesPortal.common.model.LogVO;

public interface HttpLogDao {

	void createLog(LogVO logVo);

}
