package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.OrderDao;
import com.lgmma.salesPortal.app.model.OrderHeadVO;
import com.lgmma.salesPortal.app.model.OrderItemVO;
import com.lgmma.salesPortal.app.model.OrderListVO;
import com.lgmma.salesPortal.app.model.OrderSaleNameListVO;


@Repository
public class OrderDaoImpl implements OrderDao {

    private static final String MAPPER_NAMESPACE = "ORDER_MAPPER.";

    @Autowired(required=true)
    protected SqlSession sqlSession;

	@Override
	public int getOrderCount(OrderListVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getOrderCount", param);
	}
	
	@Override
	public List<OrderListVO> getOrderList(OrderListVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getOrderList", param);
	}
	
	@Override
	public OrderHeadVO getOrderDetail(OrderHeadVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getOrderHeadDetail", param);
	}
	
	@Override
	public List<OrderItemVO> getOrderItemList(OrderItemVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getOrderItemList", param);
	}
	
	@Override
	public int getSaleNameCount(OrderSaleNameListVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getSaleNameCount", param);
	}
	
	@Override
	public List<OrderSaleNameListVO> getSaleNameList(OrderSaleNameListVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSaleNameList", param);
	}
	
	@Override
	public void createOrderHead(OrderHeadVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createOrderHead", param);
	}
	
	@Override
	public void createOrderItem(OrderItemVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createOrderItem", param);
	}
	
	@Override
	public void updateOrderItem(OrderItemVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateOrderItem", param);
	}
	
	@Override
	public void deleteOrderItem(OrderItemVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "deleteOrderItem", param);
	}
	
	@Override
	public int getOrderConfirmCount(OrderListVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getOrderConfirmCount", param);
	}
	
	@Override
	public List<OrderListVO> getOrderConfirmList(OrderListVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getOrderConfirmList", param);
	}
	
	@Override
	public OrderHeadVO getOrderConfirmDetail(OrderHeadVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getOrderConfirmDetail", param);
	}
	
	@Override
	public List<OrderItemVO> getOrderConfirmItemList(OrderItemVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getOrderConfirmItemList", param);
	}
	
	@Override
	public List<OrderListVO> getSapOrderCompCodeList(OrderListVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getSapOrderCompCodeList", param);
	}

	@Override
	public void updateOrderHead(OrderHeadVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateOrderHead", param);
	}

	@Override
	public void deleteAllOrderItem(OrderHeadVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "deleteAllOrderItem", param);
	}

	@Override
	public void deleteOrderHead(OrderHeadVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "deleteOrderHead", param);
	}

	@Override
	public OrderItemVO getOrderItem(OrderItemVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getOrderItem", param);
	}

	@Override
	public void updateConfirmOrderItem(OrderItemVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateConfirmOrderItem", param);
	}

	@Override
	public OrderHeadVO getConfirmedEaslesOrderHead(String orderId) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getConfirmedEaslesOrderHead", orderId);
	}

	@Override
	public void createConfirmOrderItem(OrderItemVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "createConfirmOrderItem", param);
	}

	@Override
	public void deleteConfirmOrderItem(OrderItemVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "deleteConfirmOrderItem", param);
	}

	@Override
	public void updateOrderItemComment(OrderItemVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateOrderItemComment", param);
	}
	
}
