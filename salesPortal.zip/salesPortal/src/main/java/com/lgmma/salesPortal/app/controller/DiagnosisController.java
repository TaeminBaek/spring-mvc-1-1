package com.lgmma.salesPortal.app.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.SalePriceCloseVO;
import com.lgmma.salesPortal.app.service.DiagnosisService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.util.DateUtil;

@Controller
@RequestMapping("/diagnosis") 
public class DiagnosisController {

	private static Logger logger = LoggerFactory.getLogger(DiagnosisController.class);

	@Autowired
	private CommonController commonController;

	@Autowired
	private DiagnosisService diagnosisService;

	@RequestMapping(value = "/salePriceChangeRate")
	public ModelAndView salePriceChangeRate(ModelAndView mav) throws Exception {
		mav.setViewName("diagnosis/salePriceChangeRate");
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6));
		return mav;
	}

	@RequestMapping(value = "/getSalePriceChangeRateList.json")
	public Map getSalePriceChangeRateList(@RequestBody SalePriceCloseVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", diagnosisService.getSalePriceChangeRateList(param), "storeData", diagnosisService.getSalePriceChangeRateList(param));
	}
}
