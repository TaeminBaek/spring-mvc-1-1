package com.lgmma.salesPortal.app.model;

public class ItemDeliveryVO extends PagingParamVO {

	private String lfdat;           //납품일                    
	private String kunnr;           //고객번호                  
	private String charg;           //Batch                     
	private String lfimg;           //실제수량납품(판매단위)    
	private String matnr;           //자재번호                  
	private String werks;           //플랜트                    
	private String vbelv;           //선행 영업/유통문서        
	private String posnv;           //영업/유통문서의 선행품목  
	private String vbeln;           //차후 영업/유통 문서       
	private String posnn;           //영업/유통문서의 차후품목  
	private String name1;           //이름 1                    
	private String street;          //주소                      
	private String telNumber;       //인도처전화번호            
	private String vstel;           //출하지점/입고지점         
	private String adrnr1;          //운송업체코드              
	private String name2;           //운송사명                  
	private String name3;           //기사명                    
	private String street1;         //차량번호                  
	private String telNumber1;      //기사 연락처               
	private String vtext;           //내역                      
	private String lgort;           //저장위치                  
	private String meins;           //기본단위                  
	private String vtwegName;
	private String vsbedName;
	private String werksName;
	private String lgortName;
	private String areqDate;
	private String cdepBigo;
	private String dealBigo;
	private String custBigo;

	public String getLfdat() {
		return lfdat;
	}
	public void setLfdat(String lfdat) {
		this.lfdat = lfdat;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getCharg() {
		return charg;
	}
	public void setCharg(String charg) {
		this.charg = charg;
	}
	public String getLfimg() {
		return lfimg;
	}
	public void setLfimg(String lfimg) {
		this.lfimg = lfimg;
	}
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getWerks() {
		return werks;
	}
	public void setWerks(String werks) {
		this.werks = werks;
	}
	public String getVbelv() {
		return vbelv;
	}
	public void setVbelv(String vbelv) {
		this.vbelv = vbelv;
	}
	public String getPosnv() {
		return posnv;
	}
	public void setPosnv(String posnv) {
		this.posnv = posnv;
	}
	public String getVbeln() {
		return vbeln;
	}
	public void setVbeln(String vbeln) {
		this.vbeln = vbeln;
	}
	public String getPosnn() {
		return posnn;
	}
	public void setPosnn(String posnn) {
		this.posnn = posnn;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getTelNumber() {
		return telNumber;
	}
	public void setTelNumber(String telNumber) {
		this.telNumber = telNumber;
	}
	public String getVstel() {
		return vstel;
	}
	public void setVstel(String vstel) {
		this.vstel = vstel;
	}
	public String getAdrnr1() {
		return adrnr1;
	}
	public void setAdrnr1(String adrnr1) {
		this.adrnr1 = adrnr1;
	}
	public String getName2() {
		return name2;
	}
	public void setName2(String name2) {
		this.name2 = name2;
	}
	public String getName3() {
		return name3;
	}
	public void setName3(String name3) {
		this.name3 = name3;
	}
	public String getStreet1() {
		return street1;
	}
	public void setStreet1(String street1) {
		this.street1 = street1;
	}
	public String getTelNumber1() {
		return telNumber1;
	}
	public void setTelNumber1(String telNumber1) {
		this.telNumber1 = telNumber1;
	}
	public String getVtext() {
		return vtext;
	}
	public void setVtext(String vtext) {
		this.vtext = vtext;
	}
	public String getLgort() {
		return lgort;
	}
	public void setLgort(String lgort) {
		this.lgort = lgort;
	}
	public String getMeins() {
		return meins;
	}
	public void setMeins(String meins) {
		this.meins = meins;
	}
	public String getVtwegName() {
		return vtwegName;
	}
	public void setVtwegName(String vtwegName) {
		this.vtwegName = vtwegName;
	}
	public String getVsbedName() {
		return vsbedName;
	}
	public void setVsbedName(String vsbedName) {
		this.vsbedName = vsbedName;
	}
	public String getWerksName() {
		return werksName;
	}
	public void setWerksName(String werksName) {
		this.werksName = werksName;
	}
	public String getLgortName() {
		return lgortName;
	}
	public void setLgortName(String lgortName) {
		this.lgortName = lgortName;
	}
	public String getAreqDate() {
		return areqDate;
	}
	public void setAreqDate(String areqDate) {
		this.areqDate = areqDate;
	}
	public String getCdepBigo() {
		return cdepBigo;
	}
	public void setCdepBigo(String cdepBigo) {
		this.cdepBigo = cdepBigo;
	}
	public String getDealBigo() {
		return dealBigo;
	}
	public void setDealBigo(String dealBigo) {
		this.dealBigo = dealBigo;
	}
	public String getCustBigo() {
		return custBigo;
	}
	public void setCustBigo(String custBigo) {
		this.custBigo = custBigo;
	}
}
