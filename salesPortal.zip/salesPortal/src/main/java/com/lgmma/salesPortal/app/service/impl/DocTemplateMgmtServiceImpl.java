package com.lgmma.salesPortal.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.dao.DocTemplateDao;
import com.lgmma.salesPortal.app.model.DocTemplateVO;
import com.lgmma.salesPortal.app.service.DocTemplateMgmtService;
import com.lgmma.salesPortal.common.util.Util;

@Service
public class DocTemplateMgmtServiceImpl implements DocTemplateMgmtService{
	
	@Autowired
	private DocTemplateDao docTemplateDao;
	
	@Override
	public int getDocTemplateCount(DocTemplateVO param) {
		return docTemplateDao.getDocTemplateCount(param);
	}
	@Override
	public List<DocTemplateVO> getDocTemplateList(DocTemplateVO param) {
		return docTemplateDao.getDocTemplateList(param);
	}
	@Override
	public void updateDocTemplate(DocTemplateVO param) {
		docTemplateDao.updateDocTemplate(param);
	}
	@Override
	public void createDocTemplate(DocTemplateVO param) {
		param.setDocTmplId(Util.getUUID());
		docTemplateDao.createDocTemplate(param);
	}
	@Override
	public List<DocTemplateVO> getNotDeletedDocTemplateList(DocTemplateVO param) {
		return docTemplateDao.getNotDeletedDocTemplateList(param);
	}
}
