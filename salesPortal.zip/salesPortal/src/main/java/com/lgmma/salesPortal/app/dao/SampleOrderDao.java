package com.lgmma.salesPortal.app.dao;

import com.lgmma.salesPortal.app.model.DirectOrderItemVO;
import com.lgmma.salesPortal.app.model.SampleOrderMasterVO;
import com.lgmma.salesPortal.app.model.VocGradeVO;

import java.util.List;


public interface SampleOrderDao {

	void createSampleOrderMaster(SampleOrderMasterVO param);

	void createSampleOrderItem(DirectOrderItemVO param);

	void updateErpOrderId(SampleOrderMasterVO param);

	void updateErpMessage(SampleOrderMasterVO param);

	int getSampleOrderCount(SampleOrderMasterVO param);

	List<SampleOrderMasterVO> getSampleOrderList(SampleOrderMasterVO param);

	List<DirectOrderItemVO> getSampleOrderItemList(String orderId);

	SampleOrderMasterVO getSampleOrderDetail(SampleOrderMasterVO param);

	void updateSampleOrderMaster(SampleOrderMasterVO param);

	void deleteSampleOrderItems(SampleOrderMasterVO param);

	void deleteSampleOrderMaster(SampleOrderMasterVO param);

	int getSampleDocCount(SampleOrderMasterVO param);

	List<SampleOrderMasterVO> getSampleDocList(SampleOrderMasterVO param);

	SampleOrderMasterVO getVocInfo(SampleOrderMasterVO param);

	List<DirectOrderItemVO> getVocItemList(String vactIdxx);

	void updateSampleOrderApprId(SampleOrderMasterVO param);

	void updateSampleOrderApprIdToNull(SampleOrderMasterVO param);

	void updateAfterSendErp(SampleOrderMasterVO param);

	void updateSampleOrderAfterVocActInfo(SampleOrderMasterVO param);

	void regSampleOrderFile(SampleOrderMasterVO param);

	void updateSampleOrderComment(SampleOrderMasterVO param);
}
