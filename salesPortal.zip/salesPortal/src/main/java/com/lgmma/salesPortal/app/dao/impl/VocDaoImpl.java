 package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.VocDao;
import com.lgmma.salesPortal.app.model.VocVO;
import com.lgmma.salesPortal.app.model.VocGradeVO;
import com.lgmma.salesPortal.app.model.VocActPopVO;
import com.lgmma.salesPortal.app.model.VocActVO;
import com.lgmma.salesPortal.app.model.VocTypeVO;
import com.lgmma.salesPortal.app.model.VocSendMailToEmpVO;
import com.lgmma.salesPortal.app.model.VocSendMailToCustVO;

@Repository
public class VocDaoImpl implements VocDao{
	
	private static final String MAPPER_NAMESPACE = "VOC_MAPPER.";
	
	 @Autowired(required=true)
	    protected SqlSession sqlSession;

	@Override
	public int getVocListCount(VocVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getVocListCount", param);
	}

	@Override
	public List<VocVO> getVocList(VocVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getVocList", param);
	}

	@Override
	public VocVO getVocDetail(VocVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getVocDetail", param);
	}

	@Override
	public void createVoc(VocVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createVoc", param);
	}

	@Override
	public void createVocGrade(VocGradeVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createVocGrade", param);
	}	
	
	@Override
	public void updateVoc(VocVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateVoc", param);
	}	
	
	@Override
	public void deleteVocGrade(VocVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteVocGrade", param);
	}
	
	@Override
	public void deleteVocType(VocVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteVocType", param);
	}
	
	@Override
	public void deleteVoc(VocVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteVoc", param);
	}
	
	@Override
	public void deleteVocAct(VocVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteVocAct", param);
	}
	
	@Override
	public List<VocGradeVO> getVocGradeList(VocVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getVocGradeList", param);
	}

	@Override
	public List<VocActVO> getVocActList(VocVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getVocActList", param);
	}	
	
	@Override
	public void createVocAct(VocVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createVocAct", param);
	}
	
	@Override
	public void createVocType(VocTypeVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createVocType", param);
	}
	
	@Override
	public List<VocTypeVO> getVocTypeList(VocVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getVocTypeList", param);
	}
	
	@Override
	public VocActPopVO getVocActPop(VocActVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getVocActPop", param);
	}	
	
	@Override
	public VocActPopVO getPersonFind(VocActVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getPersonFind", param);
	}
	
	@Override
	public VocActPopVO getActivityName(VocActPopVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getActivityName", param);
	}
	
	@Override
	public void updateVocActPop(VocActPopVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateVocActPop", param);
	}	
	
	@Override
	public void updateVocActPopStat(VocActPopVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateVocActPopStat", param);
	}	
	
	@Override
	public void createVocActPop(VocActPopVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createVocActPop", param);
	}		
	
	@Override
	public VocVO getVocIdxx(VocActVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getVocIdxx", param);
	}	

	@Override
	public VocActVO getVocCustActInputHis(VocVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getVocCustActInputHis", param);
	}
	
	@Override
	public VocActVO getVocCustActAnswerHis(VocVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getVocCustActAnswerHis", param);
	}
	
	@Override
	public void updateVocActApprVoc(VocActPopVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateVocActApprVoc", param);
	}	
	
	@Override
	public void insertVocActApprVocAct(VocActPopVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "insertVocActApprVocAct", param);
	}
	
	@Override
	public VocSendMailToEmpVO getVocSendMailToEmp(VocVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getVocSendMailToEmp", param);
	}	
	
	@Override
	public VocSendMailToEmpVO getVocSendMailToEmpInfo(VocActPopVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getVocSendMailToEmpInfo", param);
	}		
	
	@Override
	public List<VocSendMailToEmpVO> getVocSendMailToEmpInList(VocActPopVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getVocSendMailToEmpInList", param);
	}
	
	@Override
	public VocSendMailToCustVO getVocSendMailToCustOut(VocActPopVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getVocSendMailToCustOut", param);
	}	
	
	@Override
	public VocSendMailToEmpVO getVocSendMailToEmpInfoAppr(VocActPopVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getVocSendMailToEmpInfoAppr", param);
	}		
	
	@Override
	public List<VocSendMailToEmpVO> getVocSendMailToEmpInApprList(VocActPopVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getVocSendMailToEmpInApprList", param);
	}	
}
