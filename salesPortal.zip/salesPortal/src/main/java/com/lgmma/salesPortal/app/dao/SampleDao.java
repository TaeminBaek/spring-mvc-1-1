package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.SampleVO;

public interface SampleDao {

	List<SampleVO> getSample(SampleVO param);
	
	void updateSample(SampleVO param);
	
	void createSample(SampleVO param);
	
	void deleteSample(SampleVO param);

	int getSampleCount(SampleVO param);

}
