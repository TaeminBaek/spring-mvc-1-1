package com.lgmma.salesPortal.app.service.impl;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.lgmma.salesPortal.app.model.SendMailVO;
import com.lgmma.salesPortal.app.service.MailingService;
import com.lgmma.salesPortal.common.util.StringUtil;

import freemarker.template.Configuration;

@Service
public class MailingServiceImpl implements MailingService {
    @Autowired
    private ThreadPoolTaskExecutor sendMailJobExecutor;
    
    @Autowired
    private JavaMailSenderImpl mailSender;

    @Autowired
    @Qualifier(value="freemarkerConfiguration")
    private Configuration freemarkerConfiguration;
    
	@Autowired
	private MessageSourceAccessor messageSourceAccessor;

	private static Logger logger = LoggerFactory.getLogger(MailingServiceImpl.class); 

	private String geFreeMarkerTemplateContent(SendMailVO sendMailVo){
    	StringBuffer content = new StringBuffer();
    	try{
    		content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
    				freemarkerConfiguration.getTemplate(sendMailVo.getMailType().getTemplate()+".txt"), sendMailVo.getParams()));
    		return content.toString();
    	}catch(Exception e){
    		logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
    	}
    	return "";
    }

	@Override
	public void sendMail(SendMailVO sendMailVo) {
   		sendMailJobExecutor.execute(new SendMailTask(sendMailVo));
	}

	private class SendMailTask implements Runnable {
		private SendMailVO sendMailVo;

		public SendMailTask(final SendMailVO sendMailVo) {
			this.sendMailVo = sendMailVo;
		}

		@Override
		public void run() {
	    	if(sendMailVo.getReceiverEmail().equals("")) {
	    		logger.warn(messageSourceAccessor.getMessage("fail.mail.receiver"));
	    	} else {
				MimeMessage message = mailSender.createMimeMessage();
				MimeMessageHelper helper;
				String receiver = messageSourceAccessor.getMessage("info.mail.test.receiver", "");
				//info.mail.test.receiver 에 세팅된 메일주소가 있으면 그 주소로 날라감
				receiver = receiver.equals("") ? this.sendMailVo.getReceiverEmail() : receiver;
				//vo 에 title 이 있으면 우선적용 아니면 mailType 에서
				String title = StringUtil.isNullToString(sendMailVo.getTitle()).equals("") ? sendMailVo.getMailType().getTitle() : sendMailVo.getTitle();
				try {
					System.out.println(receiver);
					helper = new MimeMessageHelper(message, "UTF-8");
					helper.setFrom(sendMailVo.getSenderEmail());
					helper.setTo(sendMailVo.getReceiverName() + " <" + receiver + ">");
					helper.setSubject(title);
					// 포함된 텍스트가 HTML이라는 의미로 true 플래그를 사용한다
					helper.setText(geFreeMarkerTemplateContent(this.sendMailVo), true);
					mailSender.send(message);
				} catch (NoSuchMessageException | javax.mail.MessagingException e) {
					logger.error(e.getMessage());
				}
	    	}
		}
	}
}
