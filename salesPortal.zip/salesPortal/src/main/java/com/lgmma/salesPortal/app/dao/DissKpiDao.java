package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissKpiVO;

public interface DissKpiDao {
	
	void createDissKpi(DissKpiVO param);
	
	List<DissKpiVO> getDissKpiList(DissKpiVO param);
	
	void deleteDissKpiAll(DissKpiVO param);
	
	void createDissKpiHis(DissKpiVO param);
	
	void deleteDissKpiHisAll(DissKpiVO param);
	
	List<DissKpiVO> getDissKpiHisList(DissKpiVO param);
	
	List<DissKpiVO> getDissImpdevProposalKpiHisList(DissKpiVO param);
	
	void updateDissKpi(DissKpiVO param);
	
	void updateDissKpiHis(DissKpiVO param);
	
	List<DissKpiVO> getDissKpiHisStepRsltList(DissKpiVO param);
	
	List<DissKpiVO> getDissKpiHisSampleEvalRegList(DissKpiVO param);
}
