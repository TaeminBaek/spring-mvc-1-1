package com.lgmma.salesPortal.app.model;

public class DissTaskSpecInVO extends PagingParamVO {
	private String taskId;
	private String specinId;
	
	/* specIn view column */
	private String taskName;
	private String taskStatNm;
	private String devType;
	private String devTypeNm;
	private String devLevel;
	private String devLevelNm;
	private String stepNm;
	private String salesEmpNm;
	private String tsEmpNm;
	private String custCode;
	private String custName;
	private String kunnr;
	
	/* his */
	private String stepId;
	
	/* sale goal */
	private String yyyy;
	private String y0;
	private String y1;
	private String y2;
	
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getSpecinId() {
		return specinId;
	}
	public void setSpecinId(String specinId) {
		this.specinId = specinId;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskStatNm() {
		return taskStatNm;
	}
	public void setTaskStatNm(String taskStatNm) {
		this.taskStatNm = taskStatNm;
	}
	public String getDevType() {
		return devType;
	}
	public void setDevType(String devType) {
		this.devType = devType;
	}
	public String getDevTypeNm() {
		return devTypeNm;
	}
	public void setDevTypeNm(String devTypeNm) {
		this.devTypeNm = devTypeNm;
	}
	public String getDevLevel() {
		return devLevel;
	}
	public void setDevLevel(String devLevel) {
		this.devLevel = devLevel;
	}
	public String getDevLevelNm() {
		return devLevelNm;
	}
	public void setDevLevelNm(String devLevelNm) {
		this.devLevelNm = devLevelNm;
	}
	public String getStepNm() {
		return stepNm;
	}
	public void setStepNm(String stepNm) {
		this.stepNm = stepNm;
	}
	public String getSalesEmpNm() {
		return salesEmpNm;
	}
	public void setSalesEmpNm(String salesEmpNm) {
		this.salesEmpNm = salesEmpNm;
	}
	public String getTsEmpNm() {
		return tsEmpNm;
	}
	public void setTsEmpNm(String tsEmpNm) {
		this.tsEmpNm = tsEmpNm;
	}
	public String getCustCode() {
		return custCode;
	}
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getYyyy() {
		return yyyy;
	}
	public void setYyyy(String yyyy) {
		this.yyyy = yyyy;
	}
	public String getY0() {
		return y0;
	}
	public void setY0(String y0) {
		this.y0 = y0;
	}
	public String getY1() {
		return y1;
	}
	public void setY1(String y1) {
		this.y1 = y1;
	}
	public String getY2() {
		return y2;
	}
	public void setY2(String y2) {
		this.y2 = y2;
	}
}
