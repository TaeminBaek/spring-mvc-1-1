package com.lgmma.salesPortal.app.service;
import java.util.List;

import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.DirectOrderSimpleVO;
import com.lgmma.salesPortal.app.model.SalePriceCloseDtlVO;
import com.lgmma.salesPortal.app.model.SalePriceCloseVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterHisVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;



public interface SalePriceMasterMgmtService {

	int getsalePriceMasterListCount(SalePriceMasterVO param);

	List<SalePriceMasterVO> getsalePriceMasterList(SalePriceMasterVO param) throws Exception;
	
	SalePriceMasterVO getsalePriceMasterDetail(SalePriceMasterVO param);
	
	int duplicateChkSalePriceMaster(SalePriceMasterHisVO param);
	
	void salePriceMasterExcelUpload(SalePriceMasterHisVO param);

	void createSalePriceMaster(SalePriceMasterHisVO param);
	
	void createMultiSalePriceMaster(SalePriceMasterHisVO param);

	void createMonthlyClose(SalePriceCloseVO param);

	int getMonthlyCloseListCount(SalePriceCloseVO param);

	List<SalePriceCloseVO> getMonthlyCloseList(SalePriceCloseVO param);

	void cancelBilling(DirectOrderMasterVO[] params);

	void postBilling(DirectOrderMasterVO[] params);

	int getPriceMasterExistsOrderListCount(SalePriceCloseVO param);

	List<SalePriceMasterVO> getPriceMasterExistsOrderList(SalePriceCloseVO param);

	int getOrderByPriceListCount(SalePriceMasterVO param);

	List<DirectOrderMasterVO> getOrderByPriceList(SalePriceMasterVO param);

	SalePriceCloseVO getSingleMonthlyClose(SalePriceCloseVO param);

	void confirmPriceMasterAndUpdateOrder(SalePriceMasterVO param);

	List<SalePriceCloseDtlVO> getMonthlyCloseDetailList(SalePriceCloseVO param);

	void updateMonthlyClose(SalePriceCloseVO param);

	void updateMonthlyCloseApprId(SalePriceCloseVO[] params);

	int getDifferentOrderPriceAndMasterCount(DirectOrderSimpleVO param);

	List<DirectOrderSimpleVO> getDifferentOrderPriceAndMasterList(DirectOrderSimpleVO param);

	void updateOrderPriceByPriceMaster(DirectOrderSimpleVO[] params);

	void changeSalePriceCloseStatus(SalePriceCloseVO param);

	void updateOrderByNewPriceMaster(DirectOrderMasterVO order);
}
	