package com.lgmma.salesPortal.app.dao.impl;

import com.lgmma.salesPortal.app.dao.CommonApprDao;
import com.lgmma.salesPortal.app.model.ApprLineVO;
import com.lgmma.salesPortal.app.model.ApprVO;
import com.lgmma.salesPortal.app.model.DissStepVO;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CommonApprDaoImpl implements CommonApprDao {
    private static final String MAPPER_NAMESPACE = "COMMONAPPR_MAPPER.";

	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public List<ApprVO> getApprList(ApprVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getApprList", param);
	}

	@Override
	public ApprVO getAppr(ApprVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getAppr", param);
	}

	@Override
	public void updateAppr(ApprVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateAppr", param);
	}

	@Override
	public void createAppr(ApprVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createAppr", param);
	}

	@Override
	public void deleteAppr(ApprVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteAppr", param);
	}

	@Override
	public int getApprListCount(ApprVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getApprListCount", param);
	}

	@Override
	public List<ApprLineVO> getApprLineList(ApprLineVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getApprLineList", param);
	}

	@Override
	public ApprVO getApprLine(ApprLineVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getApprLine", param);
	}

	@Override
	public void createApprLine(ApprLineVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createApprLine", param);
	}

	@Override
	public void deleteApprLineAll(ApprVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteApprLineAll", param);
	}

	@Override
	public void updateApprFromGPortal(ApprVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateApprFromGPortal", param);
	}

	@Override
	public void updateApprLineFromGPortal(ApprLineVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateApprLineFromGPortal", param);
	}

	@Override
	public void updateApprStatApprovalResult(ApprVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateApprStatApprovalResult", param);
	}

	@Override
	public void updateApprLineStatApprovalResult(ApprLineVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateApprLineStatApprovalResult", param);
	}

	@Override
	public void updateRelApprId(ApprVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateRelApprId", param);
	}

	@Override
	public void cancelAppr(ApprVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "cancelAppr", param);
	}
	
	@Override
	public void cancelApprLine(ApprLineVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "cancelApprLine", param);
	}

	@Override
	public String apprAccessAuthCheck(ApprVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "apprAccessAuthCheck", param);
	}

	@Override
	public String checkApprApplyResult(ApprLineVO apprLineVO) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "checkApprApplyResult", apprLineVO);
	}

	@Override
	public int getDissMyApprListCount(ApprLineVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissMyApprListCount", param);
	}

	@Override
	public List<ApprLineVO> getDissMyApprList(ApprLineVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissMyApprList", param);
	}
	
	@Override
	public ApprLineVO getDissMyApprDetail(ApprLineVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissMyApprDetail", param);
	}

	@Override
	public int getDissMyApprReqListCount(ApprVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissMyApprReqListCount", param);
	}

	@Override
	public List<ApprVO> getDissMyApprReqList(ApprVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissMyApprReqList", param);
	}

	@Override
	public int getApplIncompleteCount(ApprVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getApplIncompleteCount", param);
	}
	
	@Override
	public DissStepVO loadDissApprDoc(DissStepVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "loadDissApprDoc", param);
	}

	@Override
	public void updateApprLineYn(ApprVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateApprLineYn", param);
	}
	
	@Override
	public DissStepVO getGportalDissStepByApprId(DissStepVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getGportalDissStepByApprId", param);
	}
}
