package com.lgmma.salesPortal.common.props;

public enum ApprGwScrt {
/**
 * 그룹웨어 보안설정 으로서
*/
	 APPR_GWSECRT_G(	"G"	,"그룹보안"		)
	,APPR_GWSECRT_S(	"S"	,"사용자보안"	)
	;
	String code		= null;
	String name		= null;

	private ApprGwScrt(String code, String name) {
		this.code	= code;
		this.name	= name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static ApprGwScrt getApprGwScrt(String code) {
		for(ApprGwScrt type : ApprGwScrt.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
}
