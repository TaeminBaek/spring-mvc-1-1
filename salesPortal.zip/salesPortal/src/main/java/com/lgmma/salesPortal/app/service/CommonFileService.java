package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.FileVO;

public interface CommonFileService {
	
	public int getFileListCount(FileVO fileVO);

	public List<FileVO> getFileList(FileVO fileVO);

	public FileVO getFileDetail(FileVO fileVO);

	public void createFile(FileVO fileVO);

	public void deleteFile(FileVO fileVO);

	public void deleteFiles(FileVO fileVO) throws Exception;

	void deleteFilesByFileId(String fileId) throws Exception;

}
