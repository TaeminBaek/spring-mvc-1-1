package com.lgmma.salesPortal.app.service;

import org.springframework.cache.annotation.CacheEvict;

public interface CacheEvictService {

	public void sapRfcCommonCodeCacheEvict();
	
	public void sapRfcHomeChartCacheEvict();

	@CacheEvict(cacheNames= {"getCommonCodeDbAllCache"}, allEntries=true)
	void getCommonCodeDbAllCacheEvict();
}
