package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.CommonFileDao;
import com.lgmma.salesPortal.app.model.FileVO;

@Repository
public class CommonFileDaoImpl implements CommonFileDao {

	private static final String MAPPER_NAMESPACE = "FILE_MAPPER.";

	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public List<FileVO> getFileList(FileVO fileVO) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getFileList", fileVO);
	}

	@Override
	public int getFileListCnt(FileVO fileVO) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getFileListCnt", fileVO);
	}

	@Override
	public FileVO getFileDetail(FileVO fileVO) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getFileDetail", fileVO);
	}

	@Override
	public void createFile(FileVO fileVO) {
		sqlSession.insert(MAPPER_NAMESPACE + "createFile", fileVO);
	}

	@Override
	public void deleteFile(FileVO fileVO) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteFile", fileVO);
	}

}
