package com.lgmma.salesPortal.app.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgmma.salesPortal.app.dao.ContractDao;
import com.lgmma.salesPortal.app.model.ContractItemVO;
import com.lgmma.salesPortal.app.model.ContractMasterVO;
import com.lgmma.salesPortal.app.service.ContractService;
import com.lgmma.salesPortal.app.service.SapSearchService;

@Transactional
@Service
public class ContractServiceImpl implements ContractService {
	
	@Autowired
	private SapSearchService sapSearchService;
	
	@Autowired
	private ContractDao contractDao;

	@Override
	public ContractMasterVO getContractMaster(String orderId) {
		// 계약서 최초 생성시 default 값으로 tb_contract_master 에 merge into
//		contractDao.createInitContractMaster(orderId);
//		contractDao.createInitContractItems(orderId);
		ContractMasterVO contractMaster =  contractDao.getContractMaster(orderId);
		contractMaster.setItems(contractDao.getContractItem(orderId));
		contractMaster.setPmnttrms(sapSearchService.getMasterCodeName("28", contractMaster.getPmnttrms()));

		return contractMaster;
	}

	@Override
	public void updateContractMaster(ContractMasterVO param) {
		// 사용안함... 어떤것을 저장하고 어떤것을 저장하지 말지가 애매하다. 
		contractDao.updateContractMaster(param);
		for(ContractItemVO item : param.getItems()) {
			contractDao.updateContractItem(item);
		}
	}

	
}
