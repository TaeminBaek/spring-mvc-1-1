package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.taglibs.standard.tag.common.core.ParamSupport.ParamManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.model.CompDamboVO;
import com.lgmma.salesPortal.app.model.CreditDomesticVO;
import com.lgmma.salesPortal.app.model.CreditExportVO;
import com.lgmma.salesPortal.app.model.CreditGradeReportVO;
import com.lgmma.salesPortal.app.model.CustomerCreditListVO;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.DomesticDelayCreditVO;
import com.lgmma.salesPortal.app.model.ExportDelayCreditVO;
import com.lgmma.salesPortal.app.model.RiskCreditVO;
import com.lgmma.salesPortal.app.service.CompanyService;
import com.lgmma.salesPortal.app.service.CreditMgmtService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.ExcelDownloadView;
import com.lgmma.salesPortal.common.util.StringUtil;
import com.lgmma.salesPortal.common.util.Util;

import freemarker.template.Configuration;
  
@Controller
@RequestMapping("/credit")
public class CreditController {
	private static Logger logger = LoggerFactory.getLogger(CreditController.class); 
	@Autowired
	private CreditMgmtService creditMgmtService;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	@Qualifier(value = "excelFreemarkerConfiguration")
	private Configuration excelFreemarkerConfiguration;
	
	private final String DAMBO_EXCEL_TEMPLATE = "DAMBO_EXCEL_DOWNLOAD";
	
	
	@RequestMapping(value = "/customerCreditList")
	public ModelAndView creditInfo(ModelAndView mav) throws Exception {
		mav.setViewName("credit/customerCreditList");
		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6));
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		return mav;
	}
	
	@RequestMapping(value = "/getCustomerCreditList.json")
	public Map getWorkStatList(@RequestBody(required=false) CustomerCreditListVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", creditMgmtService.getCustomerCreditList(param));
	}
	
	@RequestMapping(value = "/creditMgmt")
	public ModelAndView customerCreditMgmt(ModelAndView mav) throws Exception {
		mav.setViewName("credit/creditMgmt");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		return mav;
	}
	
	@RequestMapping(value = "/getCreditDomesticList.json")
	public Map getCreditDomesticList(@RequestBody(required=false) CreditDomesticVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", creditMgmtService.getCreditDomesticList(param));
	}
	
	@RequestMapping(value = "/getCreditExportList.json")
	public Map getCreditExportList(@RequestBody(required=false) CreditExportVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", creditMgmtService.getCreditExportList(param));
	}
	
	@RequestMapping(value = "/guaranteeMgmt")
	public ModelAndView guaranteeMgmt(ModelAndView mav) throws Exception {
		mav.setViewName("credit/guaranteeMgmt");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		return mav;
	}
	
	@RequestMapping(value = "/riskyCreditMgmt")
	public ModelAndView riskycreditMgmt(ModelAndView mav) throws Exception {
		mav.setViewName("credit/riskyCreditMgmt");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		String today = Util.getToday(Util.YmdFmt);
		mav.addObject("defaultToDay", today);
		return mav;
	}
	 
	@RequestMapping(value = "/getRiskyCreditList.json")
	public Map getRiskyCreditList(@RequestBody(required=false) RiskCreditVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", creditMgmtService.getRiskyCreditList(param));
	}
	
	@RequestMapping(value = "/delayedCreditMgmt")
	public ModelAndView delayedCreditMgmt(ModelAndView mav, DomesticDelayCreditVO domesticDelayCreditVO, ExportDelayCreditVO exportDelayCreditVO) throws Exception {
		mav.setViewName("credit/delayedCreditMgmt");
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		String today = Util.getToday(Util.YmdFmt);
		mav.addObject("defaultToDay", today);
		return mav;

	}
	
	@RequestMapping(value = "/getDomesticDelayCreditList.json")
	public Map getDomesticDelayCreditList(@RequestBody(required=false) DomesticDelayCreditVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", creditMgmtService.getDomesticDelayCreditList(param));
	}

	@RequestMapping(value = "/getExportDelayCreditList.json")
	public Map getExportDelayCreditList(@RequestBody(required=false) ExportDelayCreditVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", creditMgmtService.getExportDelayCreditList(param));
	}
	
	@RequestMapping(value = "/creditGradeInfo")
	public ModelAndView creditGradeInfo(ModelAndView mav) throws Exception {
		mav.setViewName("credit/creditGradeInfo");
		mav.addObject("prevWeek", DateUtil.defaultFormatDate(DateUtil.addDay(DateUtil.getToday(),-7)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		return mav;
	}
	
	@RequestMapping(value = "/getCreditGradeReportList.json")
	public Map getCreditGradeReportList(@RequestBody(required=false) CreditGradeReportVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", creditMgmtService.getCreditGradeReportList(param),
				"itemsCount", creditMgmtService.getCreditGradeReportListCount(param));
	}
	
	@RequestMapping(value = "/getErpDamboInfo.json")
	public Map getErpDamboInfo(@RequestBody(required=false) CompDamboVO param) throws Exception {
		List<CompDamboVO> returnList = creditMgmtService.getErpDamboInfo(param);
		return JsonResponse.asSuccess("storeData",returnList );
	}
	
	@RequestMapping(value = "/lossAndGainCompany")
	public String lossAndGainCompany() throws Exception {
		return "credit/lossAndGainCompany";
		
	}
	@RequestMapping(value = "/lossAndGainProdCust")
	public String lossAndGainProdCust() throws Exception {
		return "credit/lossAndGainProdCust";
		
	}
	@RequestMapping(value = "/lossAndGainProdCustLimit")
	public String lossAndGainProdCustLimit() throws Exception {
		return "credit/lossAndGainProdCustLimit";

	}

	@RequestMapping(value = "/getDamboList.json")
	public Map getDamboList(@RequestBody(required=false) CompDamboVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", companyService.getDamboCount(param), "storeData", companyService.getDamboList(param));
	}
	
	@RequestMapping(value = "/updateDambo.json")
	public Map updateDambo(@RequestBody CompDamboVO param) throws Exception {
		companyService.updateDambo(param);
		return JsonResponse.asSuccess();
	}
	
	@RequestMapping(value = "/confirmDambo.json")
	public Map confirmDambo(@RequestBody CompDamboVO param) throws Exception {
		companyService.confirmDambo(param);
		return JsonResponse.asSuccess();
	}
	
	@RequestMapping(value = "/damboExcelDownload", method = RequestMethod.POST)
	public void excelTest(CompDamboVO param, HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		//param = (CompDamboVO) StringUtil.nullToEmptyString(param);
		//contents 인코딩 설정
		req.setCharacterEncoding("euc-kr");
		//pageSize 설정
		int directInfoCnt = companyService.getDamboItemListCount(param);
		param.setPageSize(directInfoCnt);
		
		List<CompDamboVO> damboList = companyService.getDamboList(param);
		List<CompDamboVO> copyDamboList =  new ArrayList<CompDamboVO>();
		
		for(CompDamboVO damboVo : damboList ) {
			if(damboVo.getVkorg().equals("1000")) {
				damboVo.setVkorg("MMA");
			}else if (damboVo.getVkorg().equals("3000")) {
				damboVo.setVkorg("PMMA");
			}
			copyDamboList.add((CompDamboVO) StringUtil.nullToEmptyString(damboVo));
		}
			
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("damboList", copyDamboList);
		
		
		try {
			StringBuffer content = new StringBuffer();
			//contents 생성 (html)
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
					excelFreemarkerConfiguration.getTemplate(DAMBO_EXCEL_TEMPLATE + ".txt"), paramMap));
			
			//contents 내보내기 (xls)
			String fileName = "담보현황_Download_"+Util.getToday("yyyyMMdd");
			String ext = ".xls";
			fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
			
			res.setContentType("application/vnd.ms-excel");
			res.setHeader("Set-Cookie","fileDownload=true; path=/");
			res.setHeader("Content-Disposition","attachment;filename=\""+fileName+ext+"\"");
			res.setHeader("Content-Description", "JSP Generated Data");
			
			res.getWriter().write(content.toString());
			res.getWriter().flush();
			res.getWriter().close();

		} catch (Exception e) {
			logger.error("Exception occured while processing fmtemplate:"+e.getMessage());
		}
		 
//		excelDownService.excelDownload(paramMap, res);
		
	}
	
	
	
}
