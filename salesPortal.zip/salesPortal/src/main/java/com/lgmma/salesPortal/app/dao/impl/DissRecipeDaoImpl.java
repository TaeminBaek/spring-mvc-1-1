package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissRecipeDao;
import com.lgmma.salesPortal.app.model.DissRecipeVO;

@Repository
public class DissRecipeDaoImpl implements DissRecipeDao{
	
	private static final String MAPPER_NAMESPACE = "DISSRECIPE_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public List<DissRecipeVO> getDissRecipeList(DissRecipeVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissRecipeList", param);
	}
	
	@Override
	public void createDissRecipe(DissRecipeVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissRecipe", param);
	}
	
	@Override
	public void updateDissRecipe(DissRecipeVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissRecipe", param);
	}
	
	@Override
	public void deleteDissRecipeAll(DissRecipeVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissRecipeAll", param);
	}	

}
