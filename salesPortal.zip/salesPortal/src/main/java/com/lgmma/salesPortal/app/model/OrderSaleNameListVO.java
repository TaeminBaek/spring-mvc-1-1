package com.lgmma.salesPortal.app.model;

public class OrderSaleNameListVO extends PagingParamVO {
 	//판매처 팝업 조회시
	private String tvkotVkorg;
	private String tvkotVtext;
	
	private String userId;		//로그인사번
	private String saleManCode; //판매처 담당 영업사원코드
	private String saleManName; //판매처 담당 영업사원이름
 	/** 업체명    */
	private String compName;
 	private String name1;        //파트너일경우 판매처
 	/** 업체ERP코드    */
 	private String kunnr;
 	/** 사업자등록번호    */
 	private String stcd2;
 	/** sap 판매처 코드*/
 	private String compCode;
 	/** 대표자            */
 	private String j1kfrepre;
 	/** 전화번호          */
 	private String telf1;
 	/** 팩스번호          */
 	private String telfx;
 	/** 본점 우편번호     */
 	private String postlz2;
 	/** 본점 우편주소     */
 	private String stras2;
 	/** 일반,잠재,우수 */
 	private String compLevl1;
 	/** 전략,위험 */
 	private String compLevl2;
 	/** 업종        */
 	private String kvgr5;
 	/** 고객그룹2        */
 	private String kvgr2;
 	private String monyCond;
 	private String partnerYn;
 	private String waers;
 	/** ERP 인도처 코드 (DISS 사용)*/
 	private String erpIndoCode;
 	/** 관리팀 코드 */
 	private String vkbur;

	public String getSaleManCode() {
		return saleManCode;
	}
	public void setSaleManCode(String saleManCode) {
		this.saleManCode = saleManCode;
	}
	public String getSaleManName() {
		return saleManName;
	}
	public void setSaleManName(String saleManName) {
		this.saleManName = saleManName;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getTvkotVkorg() {
		return tvkotVkorg;
	}
	public void setTvkotVkorg(String tvkotVkorg) {
		this.tvkotVkorg = tvkotVkorg;
	}
	public String getTvkotVtext() {
		return tvkotVtext;
	}
	public void setTvkotVtext(String tvkotVtext) {
		this.tvkotVtext = tvkotVtext;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getStcd2() {
		return stcd2;
	}
	public void setStcd2(String stcd2) {
		this.stcd2 = stcd2;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getJ1kfrepre() {
		return j1kfrepre;
	}
	public void setJ1kfrepre(String j1kfrepre) {
		this.j1kfrepre = j1kfrepre;
	}
	public String getTelf1() {
		return telf1;
	}
	public void setTelf1(String telf1) {
		this.telf1 = telf1;
	}
	public String getTelfx() {
		return telfx;
	}
	public void setTelfx(String telfx) {
		this.telfx = telfx;
	}
	public String getPostlz2() {
		return postlz2;
	}
	public void setPostlz2(String postlz2) {
		this.postlz2 = postlz2;
	}
	public String getStras2() {
		return stras2;
	}
	public void setStras2(String stras2) {
		this.stras2 = stras2;
	}
	public String getCompLevl1() {
		return compLevl1;
	}
	public void setCompLevl1(String compLevl1) {
		this.compLevl1 = compLevl1;
	}
	public String getCompLevl2() {
		return compLevl2;
	}
	public void setCompLevl2(String compLevl2) {
		this.compLevl2 = compLevl2;
	}
	public String getKvgr5() {
		return kvgr5;
	}
	public void setKvgr5(String kvgr5) {
		this.kvgr5 = kvgr5;
	}
	public String getKvgr2() {
		return kvgr2;
	}
	public void setKvgr2(String kvgr2) {
		this.kvgr2 = kvgr2;
	}
	public String getMonyCond() {
		return monyCond;
	}
	public void setMonyCond(String monyCond) {
		this.monyCond = monyCond;
	}
	public String getPartnerYn() {
		return partnerYn;
	}
	public void setPartnerYn(String partnerYn) {
		this.partnerYn = partnerYn;
	}
	public String getWaers() {
		return waers;
	}
	public void setWaers(String waers) {
		this.waers = waers;
	}
	public String getErpIndoCode() {
		return erpIndoCode;
	}
	public void setErpIndoCode(String erpIndoCode) {
		this.erpIndoCode = erpIndoCode;
	}
	public String getVkbur() {
		return vkbur;
	}
	public void setVkbur(String vkbur) {
		this.vkbur = vkbur;
	}
}
