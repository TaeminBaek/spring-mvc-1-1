package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.DissDailyActDao;
import com.lgmma.salesPortal.app.model.DissDailyVO;
import com.lgmma.salesPortal.app.model.EmployVO;

@Repository
public class DissDailyActDaoImpl implements DissDailyActDao{
	
	private static final String MAPPER_NAMESPACE = "DISS_DAILYACT_MAPPER.";
	
	@Autowired(required=true)
	protected SqlSession sqlSession;

	@Override
	public void createDissDailyAct(DissDailyVO param) {
		sqlSession.insert(MAPPER_NAMESPACE + "createDissDailyAct", param);
		
	}

	@Override
	public int getDissDailyActListCount(DissDailyVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissDailyActListCount", param);
	}

	@Override
	public List<DissDailyVO> getDissDailyActList(DissDailyVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissDailyActList", param);
	}

	@Override
	public DissDailyVO getDissDailyActDetail(DissDailyVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissDailyActDetail", param);
	}

	@Override
	public DissDailyVO getDissDailyActDetailLast(DissDailyVO param) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getDissDailyActDetailLast", param);
	}

	@Override
	public void updateDissDailyAct(DissDailyVO param) {
		sqlSession.update(MAPPER_NAMESPACE + "updateDissDailyAct", param);
		
	}

	@Override
	public void deleteDissDailyAct(DissDailyVO param) {
		sqlSession.delete(MAPPER_NAMESPACE + "deleteDissDailyAct", param);
	}

	@Override
	public List<DissDailyVO> getDissDailyActStatList(DissDailyVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissDailyActStatList", param);
	}
	
	@Override
	public List<DissDailyVO> getDissDailyActListExcelDownload(DissDailyVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissDailyActListExcelDownload", param);
	}

	@Override
	public List<DissDailyVO> getDissDailyActStatInfoExcelDownload(DissDailyVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissDailyActStatInfoExcelDownload", param);
	}

	@Override
	public List<DissDailyVO> getDissDailyActStatInfoExcelDownload2(DissDailyVO param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getDissDailyActStatInfoExcelDownload2", param);
	}

	@Override
	public List<EmployVO> loadEmployList(Map<String, String> param) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "loadEmployList", param);
	}
}
