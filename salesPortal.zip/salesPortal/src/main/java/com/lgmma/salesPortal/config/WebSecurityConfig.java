package com.lgmma.salesPortal.config;

import com.lgmma.salesPortal.security.authentication.CustomLoginUrlAuthenticationEntryPoint;
import com.lgmma.salesPortal.security.authentication.CustomLogoutSuccessHandler;
import com.lgmma.salesPortal.security.authentication.CustomSavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter
{
	public static final String ADMIN_LOGIN_PAGE = "/adminLoginPage";
	public static final String PARTNER_LOGIN_PAGE = "/loginPage";
	public static final String LOGIN_PROCESS_URL = "/user/doLogin";
//	public static final String USERNAME_PARAM_NAME = "empNo";
//	public static final String PASSWORD_PARAM_NAME = "adminPwd";
	public static final String LOGIN_SUCCESS_URL = "/fullScreen";
//	public static final String LOGIN_FAILURE_URL = "adminLogin";
	public static final String LOGOUT_SUCCESS_URL = "/user/logoutSuccess";
	public static final String ACCESS_DENIED_ERROR_URL = "/error";
//	public static final String ACCESS_DENIED_ERROR_URL = "/error/403";
	public static final String REQUSET_ATTRIBUTE_REQUEST_URI_BEFORE_SECURITY = "REQUEST_URI_BEFORE_SECURITY";
	public static final String PARTNER_LOGIN_SUCCESS_URL = "/partner/home";
	public static final String EMP_LOGIN_SUCCESS_URL = "/home";
	
	@Autowired AuthenticationProvider customAuthenticationProvider;
	@Autowired LoginUrlAuthenticationEntryPoint loginUrlAuthenticationEntryPoint;

	@Override
	public void configure(WebSecurity web) throws Exception {
		web
			.ignoring()
				.antMatchers("/favicon.ico","/html/**","/web-resource/**", "/**/error/**", "/download/**", "/index.jsp", "/namoEditor/**","/apprCommon/GPortalApproval","/dissAppr/GPortalApproval")
		;
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		/*		http
			.headers()
			.frameOptions().sameOrigin() //Spring Security 는 디폴트로 iframe 사용을 막고 있다. 동일한 도메인일 경우 허용하도록 설정.
			.and()
			.csrf().disable()
		.authorizeRequests()
//			.antMatchers(LOGIN_PAGE, LOGIN_PROCESS_URL).permitAll()
		.antMatchers("/SSOLogin").permitAll()
			.antMatchers("/**").hasAnyRole("USER")
//			.antMatchers("/db/**").access("hasRole('ADMIN') and hasRole('DBA')")
//			.anyRequest().authenticated()
			.and().httpBasic();
		http
			.formLogin()
			.usernameParameter(USERNAME_PARAM_NAME)
			.passwordParameter(PASSWORD_PARAM_NAME)
            .loginPage(LOGIN_PAGE).permitAll()
            .loginProcessingUrl(LOGIN_PROCESS_URL).permitAll()
			.successHandler(authenticationSuccessHandler())
			.failureHandler(new CustomAuthenticationFailureHandler(LOGIN_SUCCESS_URL))
			.and()
			.exceptionHandling()
			.authenticationEntryPoint(loginUrlAuthenticationEntryPoint)
            .and()
            .logout()
        	.logoutUrl("/logout")
        	//.addLogoutHandler(new CustomLogoutHandler())
        	.logoutSuccessHandler(new CustomLogoutSuccessHandler(LOGOUT_SUCCESS_URL))
            .permitAll()
//            .and()
//            .authorizeRequests().antMatchers("/SSOLogin").permitAll()

//	            .exceptionHandling()
//	        	.accessDeniedHandler(new CustomAccessDeniedHandler(ACCESS_DENIED_ERROR_URL))
			;

	*/	
		http
			.headers()
				.frameOptions().sameOrigin() //Spring Security 는 디폴트로 iframe 사용을 막고 있다. 동일한 도메인일 경우 허용하도록 설정.
				.and()
			.csrf()
				.disable()
			.authorizeRequests()
				.antMatchers("/adminLoginPage", "/adminLogin", "/loginPage", "/partnerLogin", "/SSOLogin", "/common/**", "/sample/**", "/namoEditor/**","/apprCommon/GPortalApproval","/dissAppr/GPortalApproval").permitAll()
				.antMatchers("/**").authenticated()
//				.antMatchers("/partner/**").hasRole("PARTNER")
				.antMatchers("/**").hasRole("USER")
				.antMatchers("/system").hasRole("ADMIN")
				.anyRequest().authenticated()
                // URL 접근 권한
//                .antMatchers("/**")
//                .hasAnyAuthority("EMP").anyRequest().authenticated()
				.and()
				.cors().and()

//			.formLogin()
//				.usernameParameter(USERNAME_PARAM_NAME)
//				.passwordParameter(PASSWORD_PARAM_NAME)
//                .loginPage(LOGIN_PAGE).permitAll()
//                .loginProcessingUrl(LOGIN_PROCESS_URL).permitAll()
//                .successHandler(new CustomSavedRequestAwareAuthenticationSuccessHandler(LOGIN_SUCCESS_URL))
//                .failureHandler(new CustomAuthenticationFailureHandler(LOGIN_SUCCESS_URL))
//                .permitAll()
//                .and()
            .logout()
            	.logoutUrl("/logout")
//            	.addLogoutHandler(new CustomLogoutHandler())
            	.logoutSuccessHandler(new CustomLogoutSuccessHandler(LOGOUT_SUCCESS_URL))
                .permitAll()
                .and()	                
            .exceptionHandling()
                .authenticationEntryPoint(loginUrlAuthenticationEntryPoint)
//            	.accessDeniedHandler(new CustomAccessDeniedHandler(ACCESS_DENIED_ERROR_URL))
            	.and()
            .sessionManagement()
            	//.maximumSessions(1)
            	.and()
         ;
	}

	@Bean
	public LoginUrlAuthenticationEntryPoint loginUrlAuthenticationEntryPoint() {
		LoginUrlAuthenticationEntryPoint loginUrlAuthenticationEntryPoint = new CustomLoginUrlAuthenticationEntryPoint(ADMIN_LOGIN_PAGE);
		return loginUrlAuthenticationEntryPoint;
	}

	@Bean
	public AuthenticationSuccessHandler authenticationSuccessHandler() {
		AuthenticationSuccessHandler authenticationSuccessHandler = new CustomSavedRequestAwareAuthenticationSuccessHandler(LOGIN_SUCCESS_URL);
		return authenticationSuccessHandler;
	}

	/**
	 * 사용자 인증 관련 설정
	 */
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    	//커스텀한 AuthenticationProvider 설정. 
    	auth.authenticationProvider(customAuthenticationProvider);
	}

}
