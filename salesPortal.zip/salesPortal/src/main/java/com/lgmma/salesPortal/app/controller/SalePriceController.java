package com.lgmma.salesPortal.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgmma.salesPortal.app.model.DirectOrderMasterVO;
import com.lgmma.salesPortal.app.model.DirectOrderSimpleVO;
import com.lgmma.salesPortal.app.model.SalePriceCloseVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterHisVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;
import com.lgmma.salesPortal.app.service.DirectOrderService;
import com.lgmma.salesPortal.app.service.SalePriceMasterMgmtService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.Konwa;
import com.lgmma.salesPortal.common.props.OrderType;
import com.lgmma.salesPortal.common.props.SalePriceMasterPriceListType;
import com.lgmma.salesPortal.common.props.SalePriceMasterSpKind;
import com.lgmma.salesPortal.common.props.SalePriceMasterUnitType;
import com.lgmma.salesPortal.common.props.Vkorg;
import com.lgmma.salesPortal.common.props.Vtweg;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.Util;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;

@Controller
@RequestMapping("/salePrice") 
public class SalePriceController {

	private static Logger logger = LoggerFactory.getLogger(SalePriceController.class); 
	
	@Autowired
	private SalePriceMasterMgmtService salePriceMasterMgmtService;
	
	@Autowired
	private DirectOrderService directOrderService;

	@Autowired
	private CommonController commonController;

	@RequestMapping(value = "/salePriceMasterMgmt")
	public ModelAndView salesPriceMasterMgmt(ModelAndView mav ) throws Exception {
		mav.addObject("vkorgCd", new ArrayList< Vkorg >(Arrays.asList(Vkorg.values())));
		mav.addObject("spKindCd", new ArrayList< SalePriceMasterSpKind >(Arrays.asList(SalePriceMasterSpKind.values())));
		mav.addObject("konwaCd", new ArrayList< Konwa >(Arrays.asList(Konwa.values())));
		mav.addObject("kmeinCd", new ArrayList< SalePriceMasterUnitType >(Arrays.asList(SalePriceMasterUnitType.values())));
		mav.addObject("vtwegCd", new ArrayList< Vtweg >(Arrays.asList(Vtweg.values())));
		
		ObjectMapper mapper = new ObjectMapper();
		List<SalePriceMasterPriceListType> normalPriceTypeList = SalePriceMasterPriceListType.getNormalSalePriceList();
		List<SalePriceMasterPriceListType> domesticPriceTypeList = SalePriceMasterPriceListType.getDomesticSalePriceList();
		List<SalePriceMasterPriceListType> exportPriceTypeList = SalePriceMasterPriceListType.getExportSalePriceList();
		
		mav.addObject("normalPrice", mapper.writeValueAsString(SalePriceMasterPriceListType.getSalePriceListItemList(normalPriceTypeList)));
		mav.addObject("domesticPrice", mapper.writeValueAsString(SalePriceMasterPriceListType.getSalePriceListItemList(domesticPriceTypeList)));
		mav.addObject("exportPrice", mapper.writeValueAsString(SalePriceMasterPriceListType.getSalePriceListItemList(exportPriceTypeList)));
		mav.addObject("spKindList",  mapper.writeValueAsString(SalePriceMasterSpKind.getSpKindItemList()));

		String today = Util.getToday(Util.YmdFmt);
		mav.addObject("today", today);
		mav.addObject("defaultYyyyMm", DateUtil.getCurrentYear()+"."+DateUtil.getToday().substring(4, 6)+".01");
		mav.setViewName("salePrice/salePriceMasterMgmt");
		return mav;
	}
	
	@RequestMapping(value = "/getsalePriceMasterList.json")
	public Map getsalePriceMasterList(@RequestBody(required=true) @Valid SalePriceMasterVO param) throws Exception {
		logger.debug("#######################SpAdminYn["+param.getSpAdminYn()+"]");
		logger.debug("#######################UserId["+param.getUserId()+"]");
		return JsonResponse.asSuccess("itemsCount", salePriceMasterMgmtService.getsalePriceMasterListCount(param), "storeData", salePriceMasterMgmtService.getsalePriceMasterList(param));
	}
	
	@RequestMapping(value = "/getsalePriceMasterDetail.json")
	public Map getsalePriceMasterDetail(@RequestBody(required=true) SalePriceMasterVO param) throws Exception {
		SalePriceMasterVO returnVo = salePriceMasterMgmtService.getsalePriceMasterDetail(param);
		return JsonResponse.asSuccess("storeData", returnVo);
	}
	
	@RequestMapping(value = "/duplicateChkSalePriceMaster.json")
	public Map duplicateChkSalePriceMaster(@RequestBody(required=true) @Valid SalePriceMasterHisVO param) throws Exception {
		return JsonResponse.asSuccess("chkCnt", salePriceMasterMgmtService.duplicateChkSalePriceMaster(param));
	}
	
	@RequestMapping(value = "/createSalePriceMaster.json")
	public Map createSalePriceMaster(@RequestBody(required=true) @Valid SalePriceMasterHisVO param) throws Exception {
		salePriceMasterMgmtService.createSalePriceMaster(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}
	
	@RequestMapping(value = "/createMultiSalePriceMaster.json")
	public Map createMultiSalePriceMaster(@RequestBody(required=true) @Valid SalePriceMasterHisVO param) throws Exception {
		salePriceMasterMgmtService.createMultiSalePriceMaster(param);
		return JsonResponse.asSuccess("success", "저장되었습니다");
	}

	@RequestMapping(value = "/salePriceCloseInfo")
	public ModelAndView salePriceCloseInfo(ModelAndView mav) throws Exception {
		mav.setViewName("salePrice/salePriceCloseInfo");
		mav.addObject("userSalesOrg", Vkorg.getVkorg(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getVkorg()));                         
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));
		mav.addObject("land1List", commonController.getSapCommonCodeListWithSelectDDLB("06").get("items"));
		//마감년월 - 오늘이 n월 10일 에서 n+1월 9일 이면 n월 마감
		String today = DateUtil.getToday();
		String toCloseDay = DateUtil.addDay(today, -10);
		mav.addObject("toCloseMonth", DateUtil.defaultFormatDate(toCloseDay.substring(0, 6)));
		mav.addObject("toCloseMonthInt", Integer.parseInt(toCloseDay.substring(4, 6)));
		mav.addObject("searchFromMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-6).substring(0, 6)));
		mav.addObject("searchToMonth", DateUtil.defaultFormatDate(DateUtil.getToday().substring(0, 6)));
		mav.addObject("toCloseMonthFirstDate", DateUtil.formatDate(toCloseDay, ".").substring(0, 8) + "01");
		mav.addObject("toCloseMonthLastDate", DateUtil.formatDate(DateUtil.getLastDate(toCloseDay), "."));
		return mav;
	}
	
	@RequestMapping(value = "/getMonthlyCloseList.json")
	public Map getMonthlyCloseList(@RequestBody(required=true) SalePriceCloseVO param) throws Exception {
		return JsonResponse.asSuccess("itemsCount", salePriceMasterMgmtService.getMonthlyCloseListCount(param), "storeData", salePriceMasterMgmtService.getMonthlyCloseList(param));
	}
	
	@RequestMapping(value = "/createMonthlyClose.json")
	public Map createMonthlyClose(@RequestBody(required=true) SalePriceCloseVO param) throws Exception {
		param.setWorkStat("I");
		param.setSaleMan(SecurityContextHolder.getContext().getAuthentication().getName());
		//param.setVkorg(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getVkorg());
		salePriceMasterMgmtService.createMonthlyClose(param);
		return JsonResponse.asSuccess("success", "저장되었습니다", "storeData", salePriceMasterMgmtService.getSingleMonthlyClose(param));
	}
	
	@RequestMapping(value = "/getDirectOrderList.json")
	public Map getDirectOrderList(@RequestBody(required=true) DirectOrderMasterVO param) throws Exception {
		param.setOrderTypeList(OrderType.getBillingOrderTypeList());
		int itemsCount = directOrderService.getDirectOrderMasterItemListCount(param);
		param.setPageSize(itemsCount);
		return JsonResponse.asSuccess("storeData", directOrderService.getOrderMasterItemForClosingList(param));
	}
	
	@RequestMapping(value = "/cancelBilling.json")
	public Map cancelBilling(@RequestBody DirectOrderMasterVO[] params) throws Exception {
		salePriceMasterMgmtService.cancelBilling(params);
		return JsonResponse.asSuccess("success", "취소되었습니다");
	}
	
	@RequestMapping(value = "/postBilling.json")
	public Map postBilling(@RequestBody DirectOrderMasterVO[] params) throws Exception {
		salePriceMasterMgmtService.postBilling(params);
		return JsonResponse.asSuccess("success", "생성되었습니다");
	}
	
	@RequestMapping(value = "/confirmPriceMasterAndUpdateOrder.json")
	public Map confirmPriceMasterAndUpdateOrder(@RequestBody(required=true) SalePriceMasterVO param) throws Exception {
		param.setOrderTypeList(OrderType.getCloseOrderTypeList());
		salePriceMasterMgmtService.confirmPriceMasterAndUpdateOrder(param);
		return JsonResponse.asSuccess("success", "확정되었습니다");
	}

	@RequestMapping(value = "/updateOrderByNewPriceMaster.json")
	public Map updateOrderByNewPriceMaster(@RequestBody(required=true) DirectOrderMasterVO order) throws Exception {
		//주문 아이템의 판가유형을 변경한다.
		//구분 유형이 가격리스트 일때만 변경 가능하다. 판가A -> 판가B 이런식으로
		salePriceMasterMgmtService.updateOrderByNewPriceMaster(order);
		return JsonResponse.asSuccess();
	}
	
	@RequestMapping(value = "/getPriceMasterExistsOrder.json")
	public Map getPriceMasterExistsOrder(@RequestBody(required=true) SalePriceCloseVO param) throws Exception {
		param.setOrderTypeList(OrderType.getCloseOrderTypeList());
		return JsonResponse.asSuccess("itemsCount", salePriceMasterMgmtService.getPriceMasterExistsOrderListCount(param), "storeData", salePriceMasterMgmtService.getPriceMasterExistsOrderList(param));
	}
	
	@RequestMapping(value = "/getOrderByPriceList.json")
	public Map getOrderByPriceList(@RequestBody(required=true) SalePriceMasterVO param) throws Exception {
		param.setOrderTypeList(OrderType.getCloseOrderTypeList());
		return JsonResponse.asSuccess("storeData", salePriceMasterMgmtService.getOrderByPriceList(param));
	}
	
	@RequestMapping(value = "/getMonthlyCloseDetailList.json")
	public Map getMonthlyCloseDetailList(@RequestBody(required=true) SalePriceCloseVO param) throws Exception {
		param.setOrderTypeList(OrderType.getCloseOrderTypeList());
		//완료된 데이터인지 확인하여 완료되었으면 TB_SALEPRICE_CLOSE_DTL 에서 진행중이면 쿼리로
		return JsonResponse.asSuccess("storeData", salePriceMasterMgmtService.getMonthlyCloseDetailList(param));
	}
	
	@RequestMapping(value = "/finishMonthlyClose.json")
	public Map finishMonthlyClose(@RequestBody(required=true) SalePriceCloseVO param) throws Exception {
		param.setWorkStat("F");
		salePriceMasterMgmtService.updateMonthlyClose(param);
		return JsonResponse.asSuccess();
	}
	
	@RequestMapping(value = "/createMonthlyCloseAppr.json")
	public Map createMonthlyCloseAppr(@RequestBody(required=true) SalePriceCloseVO[] params) throws Exception {
		//품의서작성시 해당 월마감을 동일 uuid 로 묶어준다.
		String apprId = Util.getUUID();
		for(SalePriceCloseVO param : params) {
			param.setApprId(apprId);
		}
		salePriceMasterMgmtService.updateMonthlyCloseApprId(params);
		return JsonResponse.asSuccess("apprId", apprId);
	}
	
	@RequestMapping(value = "/differentOrderPriceAndMasterInfo")                                                         
	public ModelAndView differentOrderPriceAndMasterInfo(ModelAndView mav) throws Exception {                            
		mav.setViewName("salePrice/differentOrderPriceAndMasterInfo");                                                               
		mav.addObject("salesOrgList", commonController.getVkorgDDLB().get("items"));                         
		mav.addObject("orderTypeList", OrderType.values());
		mav.addObject("distrChanList", commonController.getSapCommonCodeListDDLB("24").get("items"));
		mav.addObject("prevMonth", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(),-1)));
		mav.addObject("today", DateUtil.defaultFormatDate(DateUtil.getToday()));
		return mav;                                                                                       
	}                                                                                                   

	@RequestMapping(value = "/getDifferentOrderPriceAndMaster.json")
	public Map getDifferentOrderPriceAndMasterList(@RequestBody(required=true) DirectOrderSimpleVO param) throws Exception {
		param.setSpAdminYn(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getSalePriceAdminYn());
		return JsonResponse.asSuccess("itemsCount", salePriceMasterMgmtService.getDifferentOrderPriceAndMasterCount(param), "storeData", salePriceMasterMgmtService.getDifferentOrderPriceAndMasterList(param));
	}
	
	@RequestMapping(value = "/updateOrderPriceByPriceMaster.json")
	public Map updateOrderPriceByPriceMaster(@RequestBody(required=true) DirectOrderSimpleVO[] params) throws Exception {
		salePriceMasterMgmtService.updateOrderPriceByPriceMaster(params);
		return JsonResponse.asSuccess();
	}
	
	@RequestMapping(value = "/changeSalePriceCloseStatus.json")
	public Map changeSalePriceCloseStatus(@RequestBody(required=true) SalePriceCloseVO param) throws Exception {
		param.setWorkStat("I");
		salePriceMasterMgmtService.changeSalePriceCloseStatus(param);
		return JsonResponse.asSuccess();
	}
	
}
