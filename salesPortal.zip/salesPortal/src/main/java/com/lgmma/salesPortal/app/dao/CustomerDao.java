package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.CustReqVO;
import com.lgmma.salesPortal.app.model.OrganVO;

public interface CustomerDao {

	void createCustomer(CompanyVO param);

	void createOrgan(OrganVO organVO);

	int getCustomerRequestsCount(CustReqVO param);

	List<CustReqVO> getCustomerRequestsList(CustReqVO param);

	CustReqVO getCustomerRequestDetail(CustReqVO param);

}
