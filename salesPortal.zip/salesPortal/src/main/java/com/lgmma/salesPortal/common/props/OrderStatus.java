package com.lgmma.salesPortal.common.props;

import java.util.Arrays;
import java.util.List;

public enum OrderStatus {
/**
 * 주문 진행상태로서
*/
	 NEW_ORDER("NO","신규주문")
	,CONFIRM_HOLD("DB","확정보류")
	,SHIPPING_REJECT("CB","출하불가")
	,CONFIRM_MODIFY("UD","수정확정")
	,CONFIRM_ORDER("OD","주문확정")
	,IN_DELIVERING("SI","납품중")
	,FINISH_DELIVERING("SC","납품완료")
	,PARTIAL_SHIPPING("SP","부분출하")
	,BILLING_COMPLETE("BC","빌링완료")
	,INCOMPLETE_ORDER("OR","미완료")
	;
	String code = null;
	String name = null;

	private OrderStatus(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static OrderStatus getStatus(String code) {
		for(OrderStatus type : OrderStatus.values()) {
			if(type.getCode().equals(code)) {
				return type;
			}
		}
		return null;
	}
	public static List<OrderStatus> getDirectOrderStatus() {
		return Arrays.asList(
				IN_DELIVERING
				,FINISH_DELIVERING
				,PARTIAL_SHIPPING
		);
	}
}
