package com.lgmma.salesPortal.app.service.impl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgmma.salesPortal.app.model.CollectAccountDetailVO;
import com.lgmma.salesPortal.app.model.CollectExpectedDateVO;
import com.lgmma.salesPortal.app.model.SalesPrepareIncreaseVO;
import com.lgmma.salesPortal.app.model.SalesContinuityDecreaseVO;
import com.lgmma.salesPortal.app.model.OperatingProfitContinuityDecreaseVO;
import com.lgmma.salesPortal.app.service.CommonService;
import com.lgmma.salesPortal.app.service.SapSearchService;
import com.lgmma.salesPortal.app.service.SapSearchServiceCache;
import com.lgmma.salesPortal.common.jco.JcoConnector;
import com.lgmma.salesPortal.common.jco.model.JcoTableParam;
import com.lgmma.salesPortal.app.model.CompanyVO;
import com.lgmma.salesPortal.app.model.CreditLimitRateVO;
import com.lgmma.salesPortal.app.model.CustBondOverdueInformationVO;
import com.lgmma.salesPortal.common.model.DDLBItem;
import com.lgmma.salesPortal.common.util.StringUtil;

@Service
public class SapSearchServiceImpl implements SapSearchService {

	private final String FNC_SAP_MASTER_CODE = "ZSDE01_MASTER_CODE";								// SAPCODE 가져오기
	private final String FNC_SAP_IMP_CORP_CREDIT = "ZSDE01_CREDIT_DATA_EX1";						// 직수출 신용 가져오기
	private final String FNC_SAP_CORP_CREDIT = "ZSDE01_CREDIT_DATA";								// 여신 가져오기
	private final String FNC_SAP_EXPCORP_CREDIT = "ZSDE01_CREDIT_DATA_EX2";							// 수출업체 여신 가져오기
	private final String FNC_SAP_CORP_BOND = "ZSDE03_SALES_LIST_BONDS";								// 해당 고객의 채권
	private final String FNC_SAP_CORP_SALE_YEAR = "ZSDE03_SALES_LIST_TERM";							// 해당 고객의 연도실적
	private final String FNC_SAP_CORP_SALE_MONTH = "ZSDE03_SALES_LIST_TERMMON";						// 해당 고객의 연도별 월실적
	private final String FNC_SAP_PARTNER_SALE_EXP_LIST = "ZSDE03_SELECT_PARTNER_SUM";				// 파트너 실적
	private final String FNC_SAP_PARTNER_SALE_EXP_VIEW = "ZSDE03_SELECT_PARTNER_MAIN";				// 파트너 판매처별 실적
	private final String FNC_SAP_PARTNER_MONTH_PURCHASE_RECORD_LIST = "ZSDE02_SELECT_MONTH_SALES";	// 월별 구매실적
	private final String FNC_SAP_PARTNER_DAY_PURCHASE_RECORD_LIST = "ZSDE02_SELECT_DAY_SALES";		// 일별 구매실적
	private final String FNC_SAP_COLLECT_ACCNOUT_DETAIL_LIST = "ZFB_ACCOUNT_RECEIVE"; 				// 수금 계좌 입금 명세 조회	
	private final String FNC_SAP_COLLECT_DUE_DATE_LIST = "ZFB_CONDITION_DUE_DATE"; 					// 수출 수금 예정일 현황	
	private final String FNC_SAP_SALES_PREPARE_INCREASE_LIST = "ZFB_COMPARE_SALES";					// 기존 매출 대비 증가,감소
	private final String FNC_SAP_SALES_CONTINUITY_DECREASE_LIST = "ZFB_DECREASE_SALES";				// 매출 연속 감소
	private final String FNC_SAP_OPERATING_PROFIT_DECREASE_LIST = "ZFB_DECREASE_OPER_PROFIT";		// 영업이익/영업이익률 연속 감소 	
	private final String FNC_SAP_CHANGE_CREDIT_LIMIT_LIST = "ZFB_CHANGE_CREDIT_LIMIT";				// 여신한도 변동율 
	private final String FNC_SAP_CUST_BOND_OVERDUW_INFO_LIST = "ZFB_KUNNR_OVERDUE";					// 거래선 채권 연체 정
								
	
	@Autowired
	private JcoConnector jcoConnector;

	@Autowired
	private SapSearchServiceCache sapSearchServiceCache;
	
	@Autowired
	private CommonService commonService;
	
	/**
	 * <pre>
	 *  마스터 코드 정보 조회-복수값
	 * -----------------------------------------------
	 *  필수 입력   GUBUN
	 * -----------------------------------------------
	 *  영업조직		01			계정지정그룹	08
	 *  사업장		02			계정그룹		09  
	 *	영업그룹		03			고객그룹1		10  
	 * 	플랜트		04			고객그룹2		11  
	 * 	제품군		05			고객그룹3		12  
	 * 	국가			06			고객그룹4		13  
	 * 	운송지역구분	07			고객그룹5		14 
	 *  영업지역		25			통화			26
	 *  유통경로		24
	 *------------------------------------------------
	 * </pre>
	 *
	 * @param   zgubun    필수입력 구분자 - "01", "01,02,03" 형태
	 * @return  마스코 코드명, 코드정보를 담은 배열 반환	 
	 */
	
	@Override
	public List<DDLBItem> getSapCommonCodeList(String zgubun) {
		List<DDLBItem> returnItems = sapSearchServiceCache.getSapCommonCodeListCache(zgubun);
		return returnItems;
	}

	/**
	 * zgubun 한개만 넘겨야함
	 * @param zgubun
	 * @param code
	 * @return
	 */
	@Override
	public String getSapCommonCodeName(String zgubun,String code) {
		String rtnVal = "";
		List<DDLBItem> returnItems = sapSearchServiceCache.getSapCommonCodeListCache(zgubun);
		for(DDLBItem ddlbItem : returnItems){
			if(ddlbItem.getCode().equals(code)){
				return ddlbItem.getText();
			}
		}
		return rtnVal;
	}

	@Override
	public Map getImportCorpCredit(String impNationCode, String impCorpCode) {
		Map<String, Object> inputParams = new HashMap<String, Object>();
		Map<String, Object> outputParams = new HashMap<String, Object>();
	
		inputParams.put("I_CTRYCD", impNationCode);
		inputParams.put("I_BUYRCD", impCorpCode);
			
		jcoConnector.executeFunction(FNC_SAP_IMP_CORP_CREDIT, inputParams, outputParams);
		return outputParams;
	}

	/**
	 * 
	 * <pre>
	 * 마스터 코드값에 해당하는 코드이름 반환
	 * </pre>
	 * 
	 *
	 * @param codeNum2
	 * @param code
	 * @return
	 * @throws Exception
	 */
	@Override
	public String getMasterCodeName(String codeNum2, String code) {
		String  codeName  = "";
		List<DDLBItem> codeItems = getSapCommonCodeList(codeNum2);
		for(DDLBItem c : codeItems) {
			if(c.getCode().equals(code)) {
				codeName=c.getText();
			}
		}
		return codeName;
	}
	
	@Override
	public List<Map> getCompanySalesYearList(String kunnr, String vkorg, String fromYear, String toYear) {
		Map<String, Object> inputParams = new HashMap<String, Object>();
		JcoTableParam tableParam = new JcoTableParam();
	
		inputParams.put("I_KUNAG", kunnr);
		inputParams.put("I_VKORG", vkorg);
		inputParams.put("I_YYYY_S", fromYear);
		inputParams.put("I_YYYY_E", toYear);
			
		jcoConnector.executeFunction(FNC_SAP_CORP_SALE_YEAR, inputParams, tableParam);
	
		return (List<Map>) tableParam.get("T_LIST");
	}
	
	@Override
	public List<Map> getCompanySalesMonthList(String kunnr, String vkorg, String fromYearMonth, String toYearMonth) {
		Map<String, Object> inputParams = new HashMap<String, Object>();
		JcoTableParam tableParam = new JcoTableParam();
	
		inputParams.put("I_KUNAG", kunnr);
		inputParams.put("I_VKORG", vkorg);
		inputParams.put("I_MM_S", fromYearMonth);
		inputParams.put("I_MM_E", toYearMonth);
			
		jcoConnector.executeFunction(FNC_SAP_CORP_SALE_MONTH, inputParams, tableParam);
	
		return (List<Map>) tableParam.get("T_LIST");
	}
	
	@Override
	public List<Map> getCompanyBondList(String kunnr, String vkorg, String yyyyMM) {
		Map<String, Object> inputParams = new HashMap<String, Object>();
		JcoTableParam tableParam = new JcoTableParam();
	
		inputParams.put("I_KUNAG", kunnr);
		inputParams.put("I_VKORG", vkorg);
		inputParams.put("I_SPMON", yyyyMM);
			
		jcoConnector.executeFunction(FNC_SAP_CORP_BOND, inputParams, tableParam);
	
		return (List<Map>) tableParam.get("T_LIST");
	}
	
	@Override
	public List<Map> getPartSalesExpList(String ispmon, String ivkorg, String ikvgr3) {
		Map<String, Object> inputParams = new HashMap<String, Object>();
		JcoTableParam tableParam = new JcoTableParam();
	
		inputParams.put("I_SPMON", ispmon);	// 년월6자리
		inputParams.put("I_VKORG", ivkorg);	// 영업조직
//		inputParams.put("I_KUNNR", ikunnr);	// 거래선(MMA)
		inputParams.put("I_KVGR3", ikvgr3);	// 고객그룹3(PMMA)
			
		jcoConnector.executeFunction(FNC_SAP_PARTNER_SALE_EXP_LIST, inputParams, tableParam);
	
		return (List<Map>) tableParam.get("T_LIST");
	}
	
	@Override
	public List<Map> getPartSalesExpView(String ispmon, String ivkorg, String ikunnr, String ikvgr3) {
		Map<String, Object> inputParams = new HashMap<String, Object>();
		JcoTableParam tableParam = new JcoTableParam();
	
		inputParams.put("I_SPMON", ispmon);	// 년월6자리
		inputParams.put("I_VKORG", ivkorg);	// 영업조직
		inputParams.put("I_KUNNR", ikunnr);	// 거래선(MMA)
		inputParams.put("I_KVGR3", ikvgr3);	// 고객그룹3(PMMA)
			
		jcoConnector.executeFunction(FNC_SAP_PARTNER_SALE_EXP_VIEW, inputParams, tableParam);
	
		return (List<Map>) tableParam.get("T_LIST");
	}
	
	@Override
	public List<Map> getMonthPurchaseRecordList(String vkorg, String jproName, String compCode, String sdate, String edate) {
		Map<String, Object> inputParams = new HashMap<String, Object>();
		JcoTableParam tableParam = new JcoTableParam();
	
		inputParams.put("I_VKORG", vkorg);	// 년월6자리
		
		// 제품코드 넣는 부분.
		if( jproName != null && !jproName.equals("")) {   
			Map<String, String> jepumMap = new HashMap<String, String>();
		 
			jepumMap.put("SIGN","I");
			jepumMap.put("OPTION","EQ");
			jepumMap.put("LOW",jproName);  // 제품코드
			jepumMap.put("HIGH",null);			
		
			tableParam.put("MATNRRANGE",jepumMap);
		}
		
		 // 조회기간 넣는 부분.
		Map<String, String> dateMap = new HashMap<String, String>();

		dateMap.put("SIGN","I");
		dateMap.put("OPTION","BT");
		dateMap.put("LOW",sdate);   	// 출하월 start
		dateMap.put("HIGH",edate);		// 출하월 end
		
		tableParam.put("MONTHS",dateMap);
		
		// 판매처 코드 넣는 부분.
		if(compCode != null && !compCode.equals("")) {
			Map<String, String> compCodeMap = new HashMap<String, String>();
		 
			compCodeMap.put("SIGN","I");
			compCodeMap.put("OPTION","EQ");
			compCodeMap.put("LOW",compCode);  //  판매처 코드
			compCodeMap.put("HIGH",null);			
		
			tableParam.put("CUSTOMERRANGE",compCodeMap);
		}
			
		jcoConnector.executeFunction(FNC_SAP_PARTNER_MONTH_PURCHASE_RECORD_LIST, inputParams, tableParam);
		
		List<Map> resultList = (List<Map>) tableParam.get("T_LIST");
		
		return resultList;
	}
	
	@Override
	public List<Map> getDayPurchaseRecordList(String vkorg, String jproName, String compCode, String sdate, String edate, String userType, String sawnCode) {
		Map<String, Object> inputParams = new HashMap<String, Object>();
		JcoTableParam tableParam = new JcoTableParam();
	
		inputParams.put("I_VKORG", vkorg);	// 년월6자리
		
		// 제품코드 넣는 부분.
		if( jproName != null && !jproName.equals("")) {   
			Map<String, String> jepumMap = new HashMap<String, String>();
		 
			jepumMap.put("SIGN","I");
			jepumMap.put("OPTION","EQ");
			jepumMap.put("LOW",jproName);  // 제품코드
			jepumMap.put("HIGH",null);			
		
			tableParam.put("MATNRRANGE",jepumMap);
		}
		
		 // 조회기간 넣는 부분.
		Map<String, String> dateMap = new HashMap<String, String>();

		dateMap.put("SIGN","I");
		dateMap.put("OPTION","BT");
		dateMap.put("LOW",sdate);   	// 출하일 start
		dateMap.put("HIGH",edate);		// 출하일 end
		
		tableParam.put("DATERANGE",dateMap);
		
		// 판매처 코드 넣는 부분.
		if(compCode != null && !compCode.equals("")) {
			Map<String, String> compCodeMap = new HashMap<String, String>();
		 
			compCodeMap.put("SIGN","I");
			compCodeMap.put("OPTION","EQ");
			compCodeMap.put("LOW",compCode);  //  판매처 코드
			compCodeMap.put("HIGH",null);			
		
			tableParam.put("CUSTOMERRANGE",compCodeMap);
		}else {
		 	//1.사원이면 빈값으로 조회
		 	if(!userType.equals("E")){
		 		
		 		//2. 사원이아니면 거래처 리스트조회후 검색
		 		Map<String, String> param = new HashMap<String, String>();
		 		
		 		param.put("vkorg", vkorg);
				param.put("sawnCode", sawnCode);
				
		 		List<String> kunnrList = commonService.getKunnr(param);
				List<Map> kunnrListMap = new ArrayList<Map>();

				for (int i = 0; i < kunnrList.size(); i++) {
					Map kunnrMap = new HashMap<String, Object>();
					kunnrMap.put("SIGN", "I");
					kunnrMap.put("OPTION", "EQ");
					kunnrMap.put("LOW", kunnrList.get(i));
					kunnrMap.put("HIGH", null);
					kunnrListMap.add(kunnrMap);
				}
				tableParam.put("CUSTOMERRANGE", kunnrListMap);
		 	}
		 }
			
		jcoConnector.executeFunction(FNC_SAP_PARTNER_DAY_PURCHASE_RECORD_LIST, inputParams, tableParam);
		
		List<Map> resultList = (List<Map>) tableParam.get("T_LIST");
		
		return resultList;
	}

	@Override
	public Map<String, String> getCompanyCredit(CompanyVO param) {
		Map<String, String> returnMap = new HashMap<String, String>();
		Map<String, Object> inputParams = new HashMap<String, Object>();
		Map<String, Object> outputParams = new HashMap<String, Object>();

        inputParams.put("I_KUNNR", param.getKunnr());
        inputParams.put("I_VKORG", param.getVkorg());

        jcoConnector.executeFunction(FNC_SAP_CORP_CREDIT, inputParams, outputParams);
/*        
        리턴메시지	E_RETURN
        리턴코드	E_SUBRC
        기준채권회전일	E_ROTA_DATE
        담보금액	E_GUAR_AMNT
        신용한도액	E_CONF_AMNT
        여신한도액	E_KLIMK
        조정 신용한도	E_ADD_AMNT
        선수금	E_SSOBL   
     watchgrade  	E_WGRDCD  
     watchgrade  	E_WGRDTXT 
        부실연체채권	E_BUSIL   
     현재 여신한도   E_CREDIT_AMNT
*/
        returnMap.put("E_RETURN", outputParams.get("E_RETURN").toString().trim());
        returnMap.put("E_SUBRC", outputParams.get("E_SUBRC").toString().trim());
        returnMap.put("E_ROTA_DATE", outputParams.get("E_ROTA_DATE").toString().trim());
        returnMap.put("E_GUAR_AMNT", StringUtil.stringZeroConvert(outputParams.get("E_GUAR_AMNT").toString().trim()));
        returnMap.put("E_CONF_AMNT", StringUtil.stringZeroConvert(outputParams.get("E_CONF_AMNT").toString().trim()));
        returnMap.put("E_KLIMK", StringUtil.stringZeroConvert(outputParams.get("E_KLIMK").toString().trim()));
        returnMap.put("E_SSOBL", StringUtil.stringZeroConvert(StringUtil.remove(outputParams.get("E_SSOBL").toString().trim(), '-')));
        returnMap.put("E_WGRDCD", outputParams.get("E_WGRDCD").toString().trim());
        returnMap.put("E_WGRDTXT", outputParams.get("E_WGRDTXT").toString().trim());
        returnMap.put("E_BUSIL", outputParams.get("E_BUSIL").toString().trim());
        returnMap.put("E_ADD_AMNT", outputParams.get("E_ADD_AMNT").toString().trim());
        //현재 여신한도
        returnMap.put("E_CREDIT_AMNT", (Long.parseLong(StringUtil.nullConvert(returnMap.get("E_CONF_AMNT")).equals("") ? "0" : returnMap.get("E_CONF_AMNT")) + Long.parseLong(StringUtil.nullConvert(returnMap.get("E_ADD_AMNT")).equals("") ? "0" : returnMap.get("E_ADD_AMNT")) + Long.parseLong(StringUtil.nullConvert(returnMap.get("E_GUAR_AMNT")).equals("") ? "0" : returnMap.get("E_GUAR_AMNT")) + Long.parseLong(StringUtil.nullConvert(returnMap.get("E_SSOBL")).equals("") ? "0" : returnMap.get("E_SSOBL"))) + "");
        return returnMap;
	}

	@Override
	public Map<String, String> getExpCompanyCredit(CompanyVO param) {
		Map<String, String> returnMap = new HashMap<String, String>();
		Map<String, Object> inputParams = new HashMap<String, Object>();
		Map<String, Object> outputParams = new HashMap<String, Object>();
		
		inputParams.put("I_KUNNR", param.getKunnr());
		inputParams.put("I_VKORG", param.getVkorg());
		
		jcoConnector.executeFunction(FNC_SAP_EXPCORP_CREDIT, inputParams, outputParams);
		/*        
        리턴메시지	E_RETURN
        리턴코드	E_SUBRC
        기준채권회전일	E_ROTA_DATE
        무역보험공사 보상한도	E_GUAR_AMNT
        신용한도액	E_CONF_AMNT
        여신한도액	E_KLIMK
        기조정금액	E_ADD_AMNT
        선수금	E_SSOBL   
        등급?  	E_CLASCODE  
        부실연체채권	E_BUSIL   
        현재 여신한도   E_CREDIT_AMNT
        진행 중 오더  E_SAUFT
        미결채권       E_SKFOR
		 */
		returnMap.put("E_RETURN", outputParams.get("E_RETURN").toString().trim());
		returnMap.put("E_SUBRC", outputParams.get("E_SUBRC").toString().trim());
		returnMap.put("E_ROTA_DATE", outputParams.get("E_ROTA_DATE").toString().trim());
		returnMap.put("E_GUAR_AMNT", StringUtil.stringZeroConvert(outputParams.get("E_GUAR_AMNT").toString().trim()));
		returnMap.put("E_CONF_AMNT", StringUtil.stringZeroConvert(outputParams.get("E_CONF_AMNT").toString().trim()));
		returnMap.put("E_KLIMK", StringUtil.stringZeroConvert(outputParams.get("E_KLIMK").toString().trim()));
		returnMap.put("E_SSOBL", StringUtil.stringZeroConvert(StringUtil.remove(outputParams.get("E_SSOBL").toString().trim(), '-')));
		returnMap.put("E_CLASCODE", outputParams.get("E_CLASCODE").toString().trim());
		returnMap.put("E_BUSIL", outputParams.get("E_BUSIL").toString().trim());
		returnMap.put("E_ADD_AMNT", outputParams.get("E_ADD_AMNT").toString().trim());
		returnMap.put("E_SAUFT", outputParams.get("E_SAUFT").toString().trim());
		returnMap.put("E_SKFOR", outputParams.get("E_SKFOR").toString().trim());
		//현재 여신한도 = 무역보험공사보상한도 + 기조정금액 + 선수금
		returnMap.put("E_CREDIT_AMNT", (Double.parseDouble(returnMap.get("E_GUAR_AMNT")) + Double.parseDouble(returnMap.get("E_ADD_AMNT")) + Double.parseDouble(returnMap.get("E_SSOBL")) + ""));
		return returnMap;
	}

	@Override
	public List<CollectAccountDetailVO> getCollectAccountDetailList(CollectAccountDetailVO param) {

		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> outputParams = null;
		Map<String, Object> inputParams = new HashMap<String, Object>();
		
		
		//System.out.println("param ::" + param);
					
		inputParams.put("I_GUBUN", param.getPrmgubun());			// 처리구분 (A:전체   1:원화  2:외화  3:어음)
		
		inputParams.put("I_OPTION", param.getPrmexecutionOption());	// 처리구분 (A:전체  2:입금미처리  1:입금처리완료)
			
		// 여신관리영역 : RT_KKBER ( 1000:MMA내수   1100:MMA수출    3000:PMMA내수   3100:PMMA수출 )
		if( param.getPrmkkber() != null && !param.getPrmkkber().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getPrmkkber());
			kkberMap.put("HIGH",   param.getPrmkkber());		
		
			tableParam.put("RT_KKBER", kkberMap);
		}
					
		
		// 입금일자 : RT_TRNDT		
		Map<String, String> dateMap = new HashMap<String, String>();
		dateMap.put("SIGN","I");
		dateMap.put("OPTION","BT");
		dateMap.put("LOW", param.getPrmsdate());   	
		dateMap.put("HIGH",param.getPrmedate());
		
		tableParam.put("RT_TRNDT", dateMap);
					
		// 유통경로 : RT_VTWEG
		if ( param.getPrmdistrChan() != null && !param.getPrmdistrChan().equals("")) {
			Map<String, String> distrChanMap = new HashMap<String, String>();
			
			distrChanMap.put("SIGN",   "I");
			distrChanMap.put("OPTION", "EQ");
			distrChanMap.put("LOW",     param.getPrmdistrChan());
			distrChanMap.put("HIGH",    param.getPrmdistrChan());
			
			tableParam.put("RT_VTWEG", distrChanMap);
		}
					
		// 거래처CODE : RT_KUNNR
		if ( param.getPartnNumbAg() != null && !param.getPartnNumbAg().equals("")) {
			Map<String, String> partnNameMap = new HashMap<String, String>();
		 
			partnNameMap.put("SIGN",   "I");
			partnNameMap.put("OPTION", "EQ");
			partnNameMap.put("LOW",    param.getPartnNumbAg());
			partnNameMap.put("HIGH",   param.getPartnNumbAg());			
		
			tableParam.put("RT_KUNNR", partnNameMap);
		}
		
		// 입금계좌 : RT_UBKNT
		if ( param.getAccountName() != null && !param.getAccountName().equals("")) {
			Map<String, String> accountNameMap = new HashMap<String, String>();
		 
			accountNameMap.put("SIGN",   "I");
			accountNameMap.put("OPTION", "EQ");
			accountNameMap.put("LOW",    param.getAccountName());
			accountNameMap.put("HIGH",   param.getAccountName());		
		
			tableParam.put("RT_UBKNT", accountNameMap);
		}
		
		// 담당자 : RT_PERNR
		if ( param.getcApprEmpId() != null && !param.getcApprEmpId().equals("")) {
			Map<String, String> empMap = new HashMap<String, String>();
		 
			empMap.put("SIGN",   "I");
			empMap.put("OPTION", "EQ");
			empMap.put("LOW",    param.getcApprEmpId());
			empMap.put("HIGH",   param.getcApprEmpId());		
		
			tableParam.put("RT_PERNR", empMap);
		}
				
		jcoConnector.executeFunction(FNC_SAP_COLLECT_ACCNOUT_DETAIL_LIST, inputParams, outputParams, tableParam);
			
		List<CollectAccountDetailVO> resultList = null;
		resultList = (List<CollectAccountDetailVO>) tableParam.get("ET_ITAB", CollectAccountDetailVO.class);
		
		for(CollectAccountDetailVO vo: resultList) {			
			vo.setKkbtx(StringUtils.remove(vo.getKkbtx(), " 여신관리영역"));
		}
		return resultList;
	}

	@Override
	public List<CollectExpectedDateVO> getCollectExpectedDateList(CollectExpectedDateVO param) {
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> outputParams = null;
		Map<String, Object> inputParams = new HashMap<String, Object>();

		param.setGjahr(param.getGjahr().replace(".", ""));

		inputParams.put("I_CDATE", param.getGjahr()); // 조회년월 6자리

		if (param.getRemainingday().equals("")) {
			inputParams.put("I_DTCNT", "0"); // 잔여일
		} else {
			inputParams.put("I_DTCNT", param.getRemainingday());
		}

		// 제품군 : RT_SPART
		if (param.getSalesOrg() != null && !param.getSalesOrg().equals("")) {
			Map<String, String> kkberMap = new HashMap<String, String>();

			kkberMap.put("SIGN", "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW", param.getSalesOrg().substring(0, 2));
			kkberMap.put("HIGH", param.getSalesOrg().substring(0, 2));

			tableParam.put("RT_SPART", kkberMap);
		}

		// 유통경로 : RT_VTWEG
		if (param.getDistrChan() != null && !param.getDistrChan().equals("")) {
			Map<String, String> kkberMap = new HashMap<String, String>();

			kkberMap.put("SIGN", "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW", param.getDistrChan());
			kkberMap.put("HIGH", param.getDistrChan());

			tableParam.put("RT_VTWEG", kkberMap);
		}

		// 고객번호 : RT_KUNNR
		if (param.getPartnNumbAg() != null && !param.getPartnNumbAg().equals("")) {
			Map<String, String> kkberMap = new HashMap<String, String>();

			kkberMap.put("SIGN", "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW", param.getPartnNumbAg());
			kkberMap.put("HIGH", param.getPartnNumbAg());

			tableParam.put("RT_KUNNR", kkberMap);
		}

		// 사원번호 : RT_PERNR
		if (param.getcApprEmpId() != null && !param.getcApprEmpId().equals("")) {
			Map<String, String> kkberMap = new HashMap<String, String>();

			kkberMap.put("SIGN", "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW", param.getcApprEmpId());
			kkberMap.put("HIGH", param.getcApprEmpId());

			tableParam.put("RT_PERNR", kkberMap);
		}

		jcoConnector.executeFunction(FNC_SAP_COLLECT_DUE_DATE_LIST, inputParams, outputParams, tableParam);

		List<CollectExpectedDateVO> resultList = (List<CollectExpectedDateVO>) tableParam.get("ET_ITAB", CollectExpectedDateVO.class);

		return resultList;
	}

	@Override
	public List<SalesPrepareIncreaseVO> getSalesPrepareIncreaseList(SalesPrepareIncreaseVO param) {
		
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> outputParams = null;
		Map<String, Object> inputParams = new HashMap<String, Object>();
	
		//System.out.println("param ::" + param);
		
		param.setGjahr(param.getGjahr().replace(".", ""));
		
		inputParams.put("I_CMONTH", param.getGjahr());				// 조회년월 6자리
		
		inputParams.put("I_GUBUN", param.getGubun());				// 구분
				
		// 제품군 : RT_SPART
		if( param.getSalesOrg() != null && !param.getSalesOrg().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getSalesOrg());
			kkberMap.put("HIGH",   param.getSalesOrg());		
		
			tableParam.put("RT_SPART", kkberMap);
		}
				
		
		// 유통경로 : RT_VTWEG
		if( param.getDistrChan() != null && !param.getDistrChan().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getDistrChan());
			kkberMap.put("HIGH",   param.getDistrChan());		
		
			tableParam.put("RT_VTWEG", kkberMap);
		}
				
		// 사원번호 : RT_PERNR 
		if( param.getcApprEmpId() != null && !param.getcApprEmpId().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getcApprEmpId());
			kkberMap.put("HIGH",   param.getcApprEmpId());		
		
			tableParam.put("RT_PERNR", kkberMap);
		}
				
		//System.out.println("inputParams::"+inputParams);
		//System.out.println("outputParams::"+outputParams);
		//System.out.println("tableParam::"+tableParam);
		
		
		//System.out.println("tableParam::"+tableParam.get("RT_SPART"));		
		//System.out.println("tableParam::"+tableParam.get("RT_VTWEG"));		
		//System.out.println("tableParam::"+tableParam.get("RT_PERNR"));
		
		jcoConnector.executeFunction(FNC_SAP_SALES_PREPARE_INCREASE_LIST, inputParams, outputParams, tableParam);
		
		List<SalesPrepareIncreaseVO> resultList = null;
		resultList = (List<SalesPrepareIncreaseVO>) tableParam.get("ET_ITAB", SalesPrepareIncreaseVO.class);
		
		/*	
		for(int i=0; i<resultList.size(); i++) {			
			resultList.get(i).setrIndex(i+1);				
		}*/
				
		return resultList;
	}

	@Override
	public List<SalesContinuityDecreaseVO> getSalesContinuityDecreaseList(SalesContinuityDecreaseVO param) {
		
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> outputParams = null;
		Map<String, Object> inputParams = new HashMap<String, Object>();
	
		//System.out.println("param ::" + param);
		
		param.setGjahr(param.getGjahr().replace(".", ""));
		
		inputParams.put("I_CMONTH", param.getGjahr());				// 조회년월 6자리
							
		// 제품군 : RT_SPART
		if( param.getSalesOrg() != null && !param.getSalesOrg().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getSalesOrg());
			kkberMap.put("HIGH",   param.getSalesOrg());		
		
			tableParam.put("RT_SPART", kkberMap);
		}
				
		
		// 유통경로 : RT_VTWEG
		if( param.getDistrChan() != null && !param.getDistrChan().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getDistrChan());
			kkberMap.put("HIGH",   param.getDistrChan());		
		
			tableParam.put("RT_VTWEG", kkberMap);
		}
				
		// 사원번호 : RT_PERNR 
		if( param.getcApprEmpId() != null && !param.getcApprEmpId().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getcApprEmpId());
			kkberMap.put("HIGH",   param.getcApprEmpId());		
		
			tableParam.put("RT_PERNR", kkberMap);
		}
				
		//System.out.println("inputParams::"+inputParams);
		//System.out.println("outputParams::"+outputParams);
		//System.out.println("tableParam::"+tableParam);		
		
		//System.out.println("tableParam::"+tableParam.get("RT_SPART"));				
		//System.out.println("tableParam::"+tableParam.get("RT_VTWEG"));		
		//System.out.println("tableParam::"+tableParam.get("RT_PERNR"));
		
		jcoConnector.executeFunction(FNC_SAP_SALES_CONTINUITY_DECREASE_LIST, inputParams, outputParams, tableParam);
		
		List<SalesContinuityDecreaseVO> resultList = null;
		resultList = (List<SalesContinuityDecreaseVO>) tableParam.get("ET_ITAB", SalesContinuityDecreaseVO.class);
		
		/*	
		for(int i=0; i<resultList.size(); i++) {			
			resultList.get(i).setrIndex(i+1);				
		}*/
				
		return resultList;
	}

	@Override
	public List<OperatingProfitContinuityDecreaseVO> getOperatingProfitContinuityDecreaseList(OperatingProfitContinuityDecreaseVO param) {
		
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> outputParams = null;
		Map<String, Object> inputParams = new HashMap<String, Object>();
	
		//System.out.println("param ::" + param);
		
		param.setGjahr(param.getGjahr().replace(".", ""));
		
		inputParams.put("I_CMONTH", param.getGjahr());				// 조회년월 6자리
							
		// 제품군 : RT_SPART
		if( param.getSalesOrg() != null && !param.getSalesOrg().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getSalesOrg());
			kkberMap.put("HIGH",   param.getSalesOrg());		
		
			tableParam.put("RT_SPART", kkberMap);
		}
				
		
		// 유통경로 : RT_VTWEG
		if( param.getDistrChan() != null && !param.getDistrChan().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getDistrChan());
			kkberMap.put("HIGH",   param.getDistrChan());		
		
			tableParam.put("RT_VTWEG", kkberMap);
		}
				
		// 사원번호 : RT_PERNR 
		if( param.getcApprEmpId() != null && !param.getcApprEmpId().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getcApprEmpId());
			kkberMap.put("HIGH",   param.getcApprEmpId());		
		
			tableParam.put("RT_PERNR", kkberMap);
		}
				
		//System.out.println("inputParams::"+inputParams);
		//System.out.println("outputParams::"+outputParams);
		//System.out.println("tableParam::"+tableParam);		
		
		//System.out.println("tableParam::"+tableParam.get("RT_SPART"));				
		//System.out.println("tableParam::"+tableParam.get("RT_VTWEG"));		
		//System.out.println("tableParam::"+tableParam.get("RT_PERNR"));
		
		jcoConnector.executeFunction(FNC_SAP_OPERATING_PROFIT_DECREASE_LIST, inputParams, outputParams, tableParam);
		
		List<OperatingProfitContinuityDecreaseVO> resultList = null;
		resultList = (List<OperatingProfitContinuityDecreaseVO>) tableParam.get("ET_ITAB", OperatingProfitContinuityDecreaseVO.class);
		
		/*	
		for(int i=0; i<resultList.size(); i++) {			
			resultList.get(i).setrIndex(i+1);				
		}*/
				
		return resultList;
	}

	@Override
	public List<CreditLimitRateVO> getCreditLimitRateList(CreditLimitRateVO param) {
		
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> outputParams = null;
		Map<String, Object> inputParams = new HashMap<String, Object>();
	
		//System.out.println("param ::" + param);
		
		param.setGjahr(param.getGjahr().replace(".", ""));
		
		inputParams.put("I_CMONTH", param.getGjahr());				// 조회년월 6자리
		
		// 고객번호 : RT_KUNNR
		if( param.getPartnNumbAg() != null && !param.getPartnNumbAg().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getPartnNumbAg());
			kkberMap.put("HIGH",   param.getPartnNumbAg());		
		
			tableParam.put("RT_KUNNR", kkberMap);
		}
							
		// 고객번호 : RT_VKORG
		if( param.getSalesOrg() != null && !param.getSalesOrg().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getSalesOrg());
			kkberMap.put("HIGH",   param.getSalesOrg());		
		
			tableParam.put("RT_VKORG", kkberMap);
		}
				
		// 사원번호 : RT_PERNR 
		if( param.getcApprEmpId() != null && !param.getcApprEmpId().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getcApprEmpId());
			kkberMap.put("HIGH",   param.getcApprEmpId());		
		
			tableParam.put("RT_PERNR", kkberMap);
		}
				
		//System.out.println("inputParams::"+inputParams);
		//System.out.println("outputParams::"+outputParams);
		//System.out.println("tableParam::"+tableParam);		
		
		//System.out.println("tableParam::"+tableParam.get("RT_SPART"));				
		//System.out.println("tableParam::"+tableParam.get("RT_VTWEG"));		
		//System.out.println("tableParam::"+tableParam.get("RT_PERNR"));
		
		jcoConnector.executeFunction(FNC_SAP_CHANGE_CREDIT_LIMIT_LIST, inputParams, outputParams, tableParam);
		
		List<CreditLimitRateVO> resultList = null;
		resultList = (List<CreditLimitRateVO>) tableParam.get("ET_ITAB", CreditLimitRateVO.class);
		
		/*	
		for(int i=0; i<resultList.size(); i++) {			
			resultList.get(i).setrIndex(i+1);				
		}*/
				
		return resultList;
	}

	@Override
	public List<CustBondOverdueInformationVO> getCustBondOverdueInformationList(CustBondOverdueInformationVO param) {
		
		JcoTableParam tableParam = new JcoTableParam();
		Map<String, Object> outputParams = null;
		Map<String, Object> inputParams = new HashMap<String, Object>();
			
		param.setGjahr(param.getGjahr().replace(".", ""));
		
		inputParams.put("I_CMONTH", param.getGjahr());				// 조회년월 6자리
		
		// 고객번호 : RT_KUNNR
		if( param.getPartnNumbAg() != null && !param.getPartnNumbAg().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getPartnNumbAg());
			kkberMap.put("HIGH",   param.getPartnNumbAg());		
		
			tableParam.put("RT_KUNNR", kkberMap);
		}
							
		// 고객번호 : RT_VKORG
		if( param.getSalesOrg() != null && !param.getSalesOrg().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getSalesOrg());
			kkberMap.put("HIGH",   param.getSalesOrg());		
		
			tableParam.put("RT_VKORG", kkberMap);
		}
				
		// 사원번호 : RT_PERNR 
		if( param.getcApprEmpId() != null && !param.getcApprEmpId().equals("")) {   
			
			Map<String, String> kkberMap = new HashMap<String, String>();
		 
			kkberMap.put("SIGN",   "I");
			kkberMap.put("OPTION", "EQ");
			kkberMap.put("LOW",    param.getcApprEmpId());
			kkberMap.put("HIGH",   param.getcApprEmpId());		
		
			tableParam.put("RT_PERNR", kkberMap);
		}
				
		//System.out.println("inputParams::"+inputParams);
		//System.out.println("outputParams::"+outputParams);
		//System.out.println("tableParam::"+tableParam);		
		
		//System.out.println("tableParam::"+tableParam.get("RT_SPART"));				
		//System.out.println("tableParam::"+tableParam.get("RT_VTWEG"));		
		//System.out.println("tableParam::"+tableParam.get("RT_PERNR"));
		
		jcoConnector.executeFunction(FNC_SAP_CUST_BOND_OVERDUW_INFO_LIST, inputParams, outputParams, tableParam);
		
		List<CustBondOverdueInformationVO> resultList = null;
		resultList = (List<CustBondOverdueInformationVO>) tableParam.get("ET_ITAB", CustBondOverdueInformationVO.class);
						
		return resultList;
	}
	
}
