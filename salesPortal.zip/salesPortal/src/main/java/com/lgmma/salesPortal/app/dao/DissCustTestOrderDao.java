package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.DissCustTestOrderVO;

public interface DissCustTestOrderDao {
	
	List<DissCustTestOrderVO> getDissCustTestOrderList(DissCustTestOrderVO param);
	
	void createDissCustTestOrder(DissCustTestOrderVO param);
	
	void updateDissCustTestOrder(DissCustTestOrderVO param);
	
	void deleteDissCustTestOrderAll(DissCustTestOrderVO param);
	

}
