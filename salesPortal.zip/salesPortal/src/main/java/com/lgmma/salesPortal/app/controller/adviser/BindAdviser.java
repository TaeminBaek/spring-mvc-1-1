package com.lgmma.salesPortal.app.controller.adviser;

import java.util.List;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.InitBinder;

import com.lgmma.salesPortal.app.model.PagingParamVO;
import com.lgmma.salesPortal.security.authentication.CustomAuthenticationToken;

/**
 * @author jklee
 * parameter 를 VO 에 담을때 사번을 주입한다.
 */
@ControllerAdvice
public class BindAdviser {

	@InitBinder
	public void customizeBinding (WebDataBinder binder) {
		Object obj = binder.getTarget();
		if (obj instanceof PagingParamVO) {
			((PagingParamVO) obj).setUserType(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getUserType());
			((PagingParamVO) obj).setRegiIdxx(SecurityContextHolder.getContext().getAuthentication().getName());
			((PagingParamVO) obj).setUpdtIdxx(SecurityContextHolder.getContext().getAuthentication().getName());
		} else if (obj instanceof PagingParamVO[]) {
			for(int i = 0 ; i < ((PagingParamVO[])obj).length ; i++) {
				((PagingParamVO[])obj)[i].setUserType(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getUserType());
				((PagingParamVO[])obj)[i].setRegiIdxx(SecurityContextHolder.getContext().getAuthentication().getName());
				((PagingParamVO[])obj)[i].setUpdtIdxx(SecurityContextHolder.getContext().getAuthentication().getName());
			}
		} else if (obj instanceof List) {
			for(Object o : (List)obj) {
				if(o instanceof PagingParamVO){
					((PagingParamVO)o).setUserType(((CustomAuthenticationToken)SecurityContextHolder.getContext().getAuthentication()).getUserInfo().getUserType());
					((PagingParamVO)o).setRegiIdxx(SecurityContextHolder.getContext().getAuthentication().getName());
					((PagingParamVO)o).setUpdtIdxx(SecurityContextHolder.getContext().getAuthentication().getName());
				}
			}
		}
	}
}
