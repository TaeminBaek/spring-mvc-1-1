package com.lgmma.salesPortal.app.dao;

import java.util.List;
import com.lgmma.salesPortal.app.model.DissMemberVO;

public interface DissMemberDao {
	
	void createDissMember(DissMemberVO param);
	
	List<DissMemberVO> getDissMemberListaggList(DissMemberVO param);

	List<DissMemberVO> getDissMemberListaggHisList(DissMemberVO param);
	
	List<DissMemberVO> getDissMemberList(DissMemberVO param);
	
	List<DissMemberVO> getDissMemberHisList(DissMemberVO param);
	
	void deleteDissMemberAll(DissMemberVO param);
	
	void createDissMemberHis(DissMemberVO param);
	
	void deleteDissMemberHisAll(DissMemberVO param);

	List<DissMemberVO> getImpDevMemberAll(DissMemberVO param);
}
