package com.lgmma.salesPortal.app.dao;

import java.util.List;

import com.lgmma.salesPortal.app.model.ExchangeRateVO;

public interface ExchangeRateDao {

	List<ExchangeRateVO> getExchangeRateList(ExchangeRateVO param);

	List<ExchangeRateVO> getExchangeRateMonAvgList(ExchangeRateVO param);

	ExchangeRateVO getExchangeRateListAvg(ExchangeRateVO param);

	ExchangeRateVO getExchangeRateMonAvgListAvg(ExchangeRateVO param);

	void updateExchangeRate(ExchangeRateVO param);

	void createExchangeRate(ExchangeRateVO param);

	int getExchangeRateCount(ExchangeRateVO param);

	void mergeExchangeRate(ExchangeRateVO param);
	
	ExchangeRateVO getLastExchangeRateInfo();

}
