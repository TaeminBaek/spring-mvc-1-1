package com.lgmma.salesPortal.app.service;
import java.util.List;

import com.lgmma.salesPortal.app.model.ProgramVO;



public interface ProgramMgmtService {
	

	public int getProgramCount(ProgramVO param);

	List<ProgramVO> getProgramList(ProgramVO param);

	public void createProgram(ProgramVO param);

	public void updateProgram(ProgramVO param);


}
