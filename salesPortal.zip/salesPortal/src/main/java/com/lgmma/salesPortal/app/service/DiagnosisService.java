package com.lgmma.salesPortal.app.service;

import java.util.List;

import com.lgmma.salesPortal.app.model.SalePriceCloseVO;
import com.lgmma.salesPortal.app.model.SalePriceMasterVO;

public interface DiagnosisService {

	List<SalePriceMasterVO> getSalePriceChangeRateList(SalePriceCloseVO param);
}
