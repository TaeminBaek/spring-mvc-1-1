package com.lgmma.salesPortal.app.model;

public class DirectOrderSimpleVO extends PagingParamVO implements Cloneable{

	private String orderId;
	private int seq;
	private String docType;
	private String salesOrg;
	private String distrChan;
	private String vbeln;
	private String purchNoC;
	private String partnNumbAg;
	private String partnNumbWe;
	private String partnNumbVe;
	private String partnNameAg;
	private String partnNameWe;
	private String partnNameVe;
	private String partnNameZ7;
	private int price;
	private String wadatIst;
	private String wadatIstFrom;
	private String wadatIstTo;
	private String spStaYmd;
	private String spEndYmd;
	private String salesOrgText;
	private String docTypeText;
	private String distrChanText;
	private String material;
	private String reqQty;
	private int pr00Price;
	private String currency;
	private String condUnit;
	private String condUnitText;
	private String pltypText;
	private String spTypeText;
	private String spTypeKind;
	private String spTypeKindText;
	private String spAdminYn;

	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getSalesOrg() {
		return salesOrg;
	}
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	public String getDistrChan() {
		return distrChan;
	}
	public void setDistrChan(String distrChan) {
		this.distrChan = distrChan;
	}
	public String getVbeln() {
		return vbeln;
	}
	public void setVbeln(String vbeln) {
		this.vbeln = vbeln;
	}
	public String getPurchNoC() {
		return purchNoC;
	}
	public void setPurchNoC(String purchNoC) {
		this.purchNoC = purchNoC;
	}
	public String getPartnNumbAg() {
		return partnNumbAg;
	}
	public void setPartnNumbAg(String partnNumbAg) {
		this.partnNumbAg = partnNumbAg;
	}
	public String getPartnNumbWe() {
		return partnNumbWe;
	}
	public void setPartnNumbWe(String partnNumbWe) {
		this.partnNumbWe = partnNumbWe;
	}
	public String getPartnNumbVe() {
		return partnNumbVe;
	}
	public void setPartnNumbVe(String partnNumbVe) {
		this.partnNumbVe = partnNumbVe;
	}
	public String getPartnNameAg() {
		return partnNameAg;
	}
	public void setPartnNameAg(String partnNameAg) {
		this.partnNameAg = partnNameAg;
	}
	public String getPartnNameWe() {
		return partnNameWe;
	}
	public void setPartnNameWe(String partnNameWe) {
		this.partnNameWe = partnNameWe;
	}
	public String getPartnNameVe() {
		return partnNameVe;
	}
	public void setPartnNameVe(String partnNameVe) {
		this.partnNameVe = partnNameVe;
	}
	public String getPartnNameZ7() {
		return partnNameZ7;
	}
	public void setPartnNameZ7(String partnNameZ7) {
		this.partnNameZ7 = partnNameZ7;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getWadatIst() {
		return wadatIst;
	}
	public void setWadatIst(String wadatIst) {
		this.wadatIst = wadatIst;
	}
	public String getWadatIstFrom() {
		return wadatIstFrom;
	}
	public void setWadatIstFrom(String wadatIstFrom) {
		this.wadatIstFrom = wadatIstFrom;
	}
	public String getWadatIstTo() {
		return wadatIstTo;
	}
	public void setWadatIstTo(String wadatIstTo) {
		this.wadatIstTo = wadatIstTo;
	}
	public String getSalesOrgText() {
		return salesOrgText;
	}
	public void setSalesOrgText(String salesOrgText) {
		this.salesOrgText = salesOrgText;
	}
	public String getDocTypeText() {
		return docTypeText;
	}
	public void setDocTypeText(String docTypeText) {
		this.docTypeText = docTypeText;
	}
	public String getDistrChanText() {
		return distrChanText;
	}
	public void setDistrChanText(String distrChanText) {
		this.distrChanText = distrChanText;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getReqQty() {
		return reqQty;
	}
	public void setReqQty(String reqQty) {
		this.reqQty = reqQty;
	}
	public int getPr00Price() {
		return pr00Price;
	}
	public void setPr00Price(int pr00Price) {
		this.pr00Price = pr00Price;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCondUnit() {
		return condUnit;
	}
	public void setCondUnit(String condUnit) {
		this.condUnit = condUnit;
	}
	public String getCondUnitText() {
		return condUnitText;
	}
	public void setCondUnitText(String condUnitText) {
		this.condUnitText = condUnitText;
	}
	public String getPltypText() {
		return pltypText;
	}
	public void setPltypText(String pltypText) {
		this.pltypText = pltypText;
	}
	public String getSpTypeKind() {
		return spTypeKind;
	}
	public void setSpTypeKind(String spTypeKind) {
		this.spTypeKind = spTypeKind;
	}
	public String getSpTypeKindText() {
		return spTypeKindText;
	}
	public void setSpTypeKindText(String spTypeKindText) {
		this.spTypeKindText = spTypeKindText;
	}
	public String getSpStaYmd() {
		return spStaYmd;
	}
	public void setSpStaYmd(String spStaYmd) {
		this.spStaYmd = spStaYmd;
	}
	public String getSpEndYmd() {
		return spEndYmd;
	}
	public void setSpEndYmd(String spEndYmd) {
		this.spEndYmd = spEndYmd;
	}
	public String getSpTypeText() {
		return spTypeText;
	}
	public void setSpTypeText(String spTypeText) {
		this.spTypeText = spTypeText;
	}
	public String getSpAdminYn() {
		return spAdminYn;
	}
	public void setSpAdminYn(String spAdminYn) {
		this.spAdminYn = spAdminYn;
	}
	
}
