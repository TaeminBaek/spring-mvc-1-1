package com.lgmma.salesPortal.app.model;

import java.util.List;

public class GenVocVO extends PagingParamVO {
	//상담
	private String seqxNumx;
	private String refxNumx;
	private String custName;
	private String posiName;
	private String deptName;
	private String telxNumx;
	private String mailAddr;
	private String titlText;
	private String vkorg;
	private String vocxItem;
	private String reqxDate;
	private String reqxHour;
	private String contText;
	
	private String emailSendYn;
	
	private String sawnName;
	private String vName;
	private String itemName;
	
	List<GenVocVO> replyList;
	
	//견본
	private String vocxIdxx;
	private String compCode;
	private String srvcName;
	private String divxName;
	private String name1;
	private String vocxStat;
	private String apprId;
	private String apprType;
	
	
	public String getSeqxNumx() {
		return seqxNumx;
	}
	public void setSeqxNumx(String seqxNumx) {
		this.seqxNumx = seqxNumx;
	}
	public String getRefxNumx() {
		return refxNumx;
	}
	public void setRefxNumx(String refxNumx) {
		this.refxNumx = refxNumx;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getPosiName() {
		return posiName;
	}
	public void setPosiName(String posiName) {
		this.posiName = posiName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getTelxNumx() {
		return telxNumx;
	}
	public void setTelxNumx(String telxNumx) {
		this.telxNumx = telxNumx;
	}
	public String getMailAddr() {
		return mailAddr;
	}
	public void setMailAddr(String mailAddr) {
		this.mailAddr = mailAddr;
	}
	public String getTitlText() {
		return titlText;
	}
	public void setTitlText(String titlText) {
		this.titlText = titlText;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getVocxItem() {
		return vocxItem;
	}
	public void setVocxItem(String vocxItem) {
		this.vocxItem = vocxItem;
	}
	public String getReqxDate() {
		return reqxDate;
	}
	public void setReqxDate(String reqxDate) {
		this.reqxDate = reqxDate;
	}
	public String getReqxHour() {
		return reqxHour;
	}
	public void setReqxHour(String reqxHour) {
		this.reqxHour = reqxHour;
	}
	public String getContText() {
		return contText;
	}
	public void setContText(String contText) {
		this.contText = contText;
	}
	public String getEmailSendYn() {
		return emailSendYn;
	}
	public void setEmailSendYn(String emailSendYn) {
		this.emailSendYn = emailSendYn;
	}
	public String getSawnName() {
		return sawnName;
	}
	public void setSawnName(String sawnName) {
		this.sawnName = sawnName;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getvName() {
		return vName;
	}
	public void setvName(String vName) {
		this.vName = vName;
	}
	public List<GenVocVO> getReplyList() {
		return replyList;
	}
	public void setReplyList(List<GenVocVO> replyList) {
		this.replyList = replyList;
	}
	public String getSrvcName() {
		return srvcName;
	}
	public void setSrvcName(String srvcName) {
		this.srvcName = srvcName;
	}
	public String getDivxName() {
		return divxName;
	}
	public void setDivxName(String divxName) {
		this.divxName = divxName;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getVocxStat() {
		return vocxStat;
	}
	public void setVocxStat(String vocxStat) {
		this.vocxStat = vocxStat;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getVocxIdxx() {
		return vocxIdxx;
	}
	public void setVocxIdxx(String vocxIdxx) {
		this.vocxIdxx = vocxIdxx;
	}
	public String getApprId() {
		return apprId;
	}
	public void setApprId(String apprId) {
		this.apprId = apprId;
	}
	public String getApprType() {
		return apprType;
	}
	public void setApprType(String apprType) {
		this.apprType = apprType;
	}


}
