package com.lgmma.salesPortal.app.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lgmma.salesPortal.app.dao.DissStepDao;
import com.lgmma.salesPortal.app.model.DissApprCommonParamVO;
import com.lgmma.salesPortal.app.model.DissDashBoardVO;
import com.lgmma.salesPortal.app.model.DissScheduleVO;
import com.lgmma.salesPortal.app.model.DissSpecInVO;
import com.lgmma.salesPortal.app.model.DissStepVO;
import com.lgmma.salesPortal.app.service.DissSampleOrderService;
import com.lgmma.salesPortal.app.service.DissSpecInService;
import com.lgmma.salesPortal.common.model.JsonResponse;
import com.lgmma.salesPortal.common.props.ApprState;
import com.lgmma.salesPortal.common.props.ApprType;
import com.lgmma.salesPortal.common.util.DateUtil;
import com.lgmma.salesPortal.common.util.StringUtil;

import freemarker.template.Configuration;

/**
 * DISS 스펙인 컨트롤러
 */
@Controller
@RequestMapping("/dissSpecIn")
public class DissSpecInController {

	private static Logger logger = LoggerFactory.getLogger(DissSpecInController.class);

	private final String REPORT_TEMPLATE_DISS_SPECIN_COLOR_PROPOSAL = "REPORT_TEMPLATE_DISS_SPECIN_COLOR_PROPOSAL";

	@Autowired
	CommonController commonController;

	@Autowired
	DissSpecInService dissSpecInService;

	@Autowired
	DissSampleOrderService dissSampleOrderService;

	@Autowired
	DissStepDao dissStepDao;

	@Autowired
	@Qualifier(value = "reportFreemarkerConfiguration")
	private Configuration reportTemplateConfiguration;
	/**
	 * 스펙인 리스트 화면
	 *
	 * @param mav
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/dissSpecInList")
	public ModelAndView dissSpecInList(ModelAndView mav, DissDashBoardVO dissDashBoardVO) throws Exception {
		mav.setViewName("dissSpecIn/dissSpecInList");
		mav.addObject("frYmd", DateUtil.defaultFormatDate(DateUtil.addMonth(DateUtil.getToday(), -12)));
		mav.addObject("toYmd", DateUtil.defaultFormatDate(DateUtil.getToday()));
		mav.addObject("apprStatList", ApprState.getDissApprStatList());
		return mav;
	}

	/**
	 * 스펙인 리스트 조회
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getSpecInList.json")
	public Map getSpecInList(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		List<DissSpecInVO> storeData = dissSpecInService.getDissSpecInList(param);
		int itemsCount = dissSpecInService.getDissSpecInListCount(param);
		return JsonResponse.asSuccess("itemsCount", itemsCount, "storeData", storeData);
	}

	/**
	 * 스펙인 등록 화면
	 *
	 * @param mav
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/dissSpecInRegAppr")
	public ModelAndView dissSpecInReg(ModelAndView mav
			, String taskId
	) throws Exception {
		DissSpecInVO dissSpecInVO = new DissSpecInVO();
		dissSpecInVO.setTaskId(StringUtil.nullConvert(taskId));
		dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInVO);
		mav.addObject("dissSpecInParam", dissSpecInVO);
		mav.setViewName("dissSpecIn/dissSpecInRegAppr");
		return mav;
	}

	/**
	 * 스펙인 정보 조회
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getDissSpecInInfoAll.json")
	public Map getSpecInInfoAll(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		// 스펙인 기본정보 조회
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		DissSpecInVO dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInInfoAll(param));

		List<DissScheduleVO> editedScheduleList = null;

		if(ApprType.APPR_TYPE_DISS_SPECIN_SCHEDULE_EDIT.getCode().equals(param.getApprType()) && !"".equals(param.getStepId()))
			editedScheduleList = dissSpecInService.getDissScheduleListHis(param.getStepId());

		return JsonResponse.asSuccess("storeData", dissSpecInVO, "editedScheduleList", editedScheduleList);
	}

	/**
	 * 스펙인 정보 조회(His)
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getDissSpecInInfoHisAll.json")
	public Map getSpecInInfoHisAll(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		// 스펙인 기본정보 조회
		DissSpecInVO dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInInfoHisAll(param));

		// TS담당자가 Gate Review를 처음 열어 보았을때 확인일자 업데이트
		if(param.getUpdtIdxx().equals(dissSpecInVO.getTsEmpId()) && "".equals(dissSpecInVO.getCheckDate())){
			if("100200".equals(dissSpecInVO.getStepCd()) && "1000".equals(dissSpecInVO.getApprStat())){
				DissStepVO dissStepVO = new DissStepVO();
				dissStepVO.setStepId(dissSpecInVO.getStepId());
				dissStepDao.updateCheckDate(dissStepVO);
				dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInInfoHisAll(param));
			}
		}
		return JsonResponse.asSuccess("storeData", dissSpecInVO);
	}

	/**
	 * 스펙인 등록 저장(임시저장)
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveSpecIn.json")
	public Map saveSpecIn(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.tempSaveDissSpecIn(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * 스펙인 삭제(임시저장인경우)
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/deleteSpecIn.json")
	public Map deleteSpecIn(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.deleteDissSpecIn(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * 스펙인 게이트리뷰 요청
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/reqGateReview.json")
	public Map reqGateReview(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.reqGateReview(param);
		return JsonResponse.asSuccess("storeData", param);
	}

	/**
	 * 스펙인 게이트리뷰 TS 담당자 변경
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/changeTsEmpGateReview.json")
	public Map changeTsEmpGateReview(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.changeTsEmpGateReview(param);
		return JsonResponse.asSuccess();
	}
	
	/**
	 * 스펙인 게이트리뷰 Spec-In 등급 변경
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/changeSpecInDevLevel.json")
	public Map changeDissSpecInDevLevel(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.changeSpecInDevLevel(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * 스펙인 게이트리뷰 저장
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveGateReview.json")
	public Map saveGateReview(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.tempSaveSpecInGateReview(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * 스펙인 게이트리뷰 완료
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/compGateReview.json")
	public Map compGateReview(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.compSpecInGateReview(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * 스펙인 게이트리뷰 취소
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/cancelGateReview.json")
	public Map cancelGateReview(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.cancelSpecInGateReview(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * 스펙인 게이트리뷰 이후 스펙인 등록 품의 결재 처리
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/applActDissSpecInAfterGateReview.json")
	public Map applActDissSpecInAfterGateReview(@RequestBody(required = true) DissApprCommonParamVO param) throws Exception {
		param = (DissApprCommonParamVO) StringUtil.nullToEmptyString(param);
		param.setApprEmpId(param.getUpdtIdxx()); // 결재자는 반드시 로그인한 사원으로 체크 한다.
		dissSpecInService.applActDissSpecInAfterGateReview(param);

		if(!param.getRelApprId().equals("")) {
			dissSampleOrderService.saveDissSampleOrderAfterApproval(param);
		}

		return JsonResponse.asSuccess();
	}

	/**
	 * 스펙인 반려건 재작성 처리
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/dissSpecInRewrite.json")
	public Map dissSpecInRewrite(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.dissSpecInRewrite(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * 스펙인 컬러개발 제안서 템플릿
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getColorProposalTemplate.json")
	public Map getColorProposalTemplate(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		StringBuffer content = new StringBuffer();
		content.append(reportTemplateConfiguration.getTemplate(REPORT_TEMPLATE_DISS_SPECIN_COLOR_PROPOSAL + ".txt"));
		return JsonResponse.asSuccess("template", content.toString());
	}

	/**
	 * 스펙인 컬러개발 정보 조회
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/searchColorProposalInfo.json")
	public Map searchColorProposalInfo(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		// 스펙인 기본정보 조회
		DissSpecInVO dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInInfoAll(param));
		// DissStep 정보
		DissStepVO dissStepVOparam = new DissStepVO();
		dissStepVOparam.setStepId(param.getStepId());
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO = dissStepDao.getDissStep(dissStepVOparam);
		return JsonResponse.asSuccess("dissSpecInVO", dissSpecInVO, "dissColorProposalInfo", dissStepVO);
	}

	/**
	 * 스펙인 컬러개발제안서 저장
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveColorProposal.json")
	public Map saveColorProposal(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.saveColorProposal(param);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	/**
	 * 스펙인 컬러개발 제안 결재처리
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/applColorProposal.json")
	public Map applColorProposal(@RequestBody(required = true) DissApprCommonParamVO dissApprCommonParamVO) throws Exception {
		dissApprCommonParamVO = (DissApprCommonParamVO) StringUtil.nullToEmptyString(dissApprCommonParamVO);
		dissApprCommonParamVO.setApprEmpId(dissApprCommonParamVO.getUpdtIdxx()); // 결재자는 반드시 로그인한 사원으로 체크 한다.
		dissSpecInService.applColorProposal(dissApprCommonParamVO);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}


	/**
	 * 스펙인 컬러개발결과보고서 정보 조회
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/searchColorPrescriptionInfo.json")
	public Map searchColorPrescriptionInfo(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		// 스펙인 기본정보 조회
		DissSpecInVO dissSpecInVO = (DissSpecInVO) StringUtil.nullToEmptyString(dissSpecInService.getDissSpecInInfoAll(param));
		// DissStep 정보
		DissStepVO dissStepVOparam = new DissStepVO();
		dissStepVOparam.setStepId(param.getStepId());
		DissStepVO dissStepVO = new DissStepVO();
		dissStepVO = dissStepDao.getDissStep(dissStepVOparam);
		return JsonResponse.asSuccess("dissSpecInVO", dissSpecInVO, "dissColorPrescriptionInfo", dissStepVO);
	}

	/**
	 * 스펙인 컬러개발결과보고서 저장
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/saveColorPrescription.json")
	public Map saveColorPrescription(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.saveColorPrescription(param);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	/**
	 * 스펙인 컬러개발결과보고서 결재처리
	 *
	 * @param dissApprCommonParamVO
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/applColorPrescription.json")
	public Map applColorPrescription(@RequestBody(required = true) DissApprCommonParamVO dissApprCommonParamVO) throws Exception {
		dissApprCommonParamVO = (DissApprCommonParamVO) StringUtil.nullToEmptyString(dissApprCommonParamVO);
		dissApprCommonParamVO.setApprEmpId(dissApprCommonParamVO.getUpdtIdxx()); // 결재자는 반드시 로그인한 사원으로 체크 한다.
		dissSpecInService.applColorPrescription(dissApprCommonParamVO);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	/**
	 * 스펙인 일정수정
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/editSpecInSchedule.json")
	public Map editSpecInSchedule(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.editSpecInSchedule(param);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	@Transactional
	@RequestMapping(value = "/updateSpecInSchedule.json")
	public Map updateSpecInSchedule(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.updateSpecInSchedule(param);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	@Transactional
	@RequestMapping(value = "/deleteSpecInScheduleEdit.json")
	public Map deleteSpecInScheduleEdit(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.deleteSpecInScheduleEdit(param);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	@Transactional
	@RequestMapping(value = "/applDissSpecInScheduleEdit.json")
	public Map applDissSpecInScheduleEdit(@RequestBody(required = true) DissApprCommonParamVO param) throws Exception {
		param = (DissApprCommonParamVO) StringUtil.nullToEmptyString(param);
		param.setApprEmpId(param.getUpdtIdxx()); // 결재자는 반드시 로그인한 사원으로 체크 한다.
		dissSpecInService.applDissSpecInScheduleEdit(param);
		return JsonResponse.asSuccess();
	}

	/**
	 * 스펙인 CTQ수정
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/editSpecInCtq.json")
	public Map editSpecInCtq(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		param = (DissSpecInVO) StringUtil.nullToEmptyString(param);
		dissSpecInService.editSpecInCtq(param);
		return JsonResponse.asSuccess("success", "처리 되었습니다.");
	}

	@Transactional
	@RequestMapping(value = "/getFailSpecInList.json")
	public Map getFailSpecInList(@RequestBody(required = true) DissSpecInVO param) throws Exception {
		return JsonResponse.asSuccess("storeData", dissSpecInService.getFailSpecInList(param), "itemsCount", dissSpecInService.getFailSpecInListCnt(param));
	}
}
