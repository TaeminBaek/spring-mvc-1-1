package com.lgmma.salesPortal.app.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgmma.salesPortal.app.dao.LoginDao;
import com.lgmma.salesPortal.security.authentication.UserInfo;

@Repository
public class LoginDaoImpl implements LoginDao {

	private static final String MAPPER_NAMESPACE = "LoginMapper.";
	
	@Autowired(required=true)
    protected SqlSession sqlSession;
	
	@Override
	public UserInfo getUserInfo(String empNo) {
		UserInfo userInfo = new UserInfo();
		return userInfo;
//		return sqlSession.selectOne(MAPPER_NAMESPACE + "getUserInfo", empNo);
	}

	@Override
	public UserInfo getEmpUserInfo(String userId) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getEmpUserInfo", userId);
	}

	@Override
	public UserInfo getPartnerUserInfo(String partnerId) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getPartnerUserInfo", partnerId);
	}

	@Override
	public String getEncryptPwd(String partnerPwd) {
		return sqlSession.selectOne(MAPPER_NAMESPACE + "getEncryptPwd", partnerPwd);
	}

	@Override
	public List<String> getVkorg(String compCode) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getVkorg", compCode);
	}

	@Override
	public List<UserInfo> getCreditEmpUserInfo(String userId) {
		return sqlSession.selectList(MAPPER_NAMESPACE + "getCreditEmpUserInfo", userId);
	}

}
