package com.lgmma.salesPortal.app.model;

public class CustomerCreditListVO extends PagingParamVO {
	
	//조회결과
	private String kvgr3;
	private String kunnr;
	private String kvgr2;
	private String gsber;
	private String vkbur;
	private String name1;
	private String bezei;
	private String vtweg;
	private String spart;
	private String lmsum;
	private String lmcas;
	private String lmbil;
	private String msale;
	private String mrsum;
	private String mreca;
	private String mrebi;
	private String cbica;
	private String notto;
	private String notca;
	private String notbi;
	private String debt;
	private String dmbtrA;
	
	//조회조건
	private String gjahr;
	
	public String getKvgr3() {
		return kvgr3;
	}
	public void setKvgr3(String kvgr3) {
		this.kvgr3 = kvgr3;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getKvgr2() {
		return kvgr2;
	}
	public void setKvgr2(String kvgr2) {
		this.kvgr2 = kvgr2;
	}
	public String getGsber() {
		return gsber;
	}
	public void setGsber(String gsber) {
		this.gsber = gsber;
	}
	public String getVkbur() {
		return vkbur;
	}
	public void setVkbur(String vkbur) {
		this.vkbur = vkbur;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getBezei() {
		return bezei;
	}
	public void setBezei(String bezei) {
		this.bezei = bezei;
	}
	public String getVtweg() {
		return vtweg;
	}
	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	public String getSpart() {
		return spart;
	}
	public void setSpart(String spart) {
		this.spart = spart;
	}
	public String getLmsum() {
		return lmsum;
	}
	public void setLmsum(String lmsum) {
		this.lmsum = lmsum;
	}
	public String getLmcas() {
		return lmcas;
	}
	public void setLmcas(String lmcas) {
		this.lmcas = lmcas;
	}
	public String getLmbil() {
		return lmbil;
	}
	public void setLmbil(String lmbil) {
		this.lmbil = lmbil;
	}
	public String getMsale() {
		return msale;
	}
	public void setMsale(String msale) {
		this.msale = msale;
	}
	public String getMrsum() {
		return mrsum;
	}
	public void setMrsum(String mrsum) {
		this.mrsum = mrsum;
	}
	public String getMreca() {
		return mreca;
	}
	public void setMreca(String mreca) {
		this.mreca = mreca;
	}
	public String getMrebi() {
		return mrebi;
	}
	public void setMrebi(String mrebi) {
		this.mrebi = mrebi;
	}
	public String getCbica() {
		return cbica;
	}
	public void setCbica(String cbica) {
		this.cbica = cbica;
	}
	public String getNotto() {
		return notto;
	}
	public void setNotto(String notto) {
		this.notto = notto;
	}
	public String getNotca() {
		return notca;
	}
	public void setNotca(String notca) {
		this.notca = notca;
	}
	public String getNotbi() {
		return notbi;
	}
	public void setNotbi(String notbi) {
		this.notbi = notbi;
	}
	public String getGjahr() {
		return gjahr;
	}
	public void setGjahr(String gjahr) {
		this.gjahr = gjahr;
	}
	public String getDebt() {
		return debt;
	}
	public void setDebt(String debt) {
		this.debt = debt;
	}
	public String getDmbtrA() {
		return dmbtrA;
	}
	public void setDmbtrA(String dmbtrA) {
		this.dmbtrA = dmbtrA;
	}
	
}
